import { describe, it, expect, beforeEach } from 'vitest';
import { 
  ALL_REGISTERED_MODULES,
  GLOBAL_FEATURE_ACCESS_MATRIX,
  PolicyEngine, 
  computeActionDigest, 
  redactSensitiveData 
} from '../services/policyEngine';
import { ActionRequest, Principal, getDefaultPermissionsForRole } from '../types/lorin';

describe('PolicyEngine Authorization & Security Invariants', () => {
  const mockOwnerPrincipal: Principal = {
    id: 'owner_primary_isah',
    name: 'Joseph Isah',
    email: 'owner@example.test',
    role: 'OWNER',
    canonicalRole: 'SYSTEM_OWNER',
    accountStatus: 'ACTIVE',
    authenticated: true,
    enrolledAt: Date.now() - 10000,
    sessionExpiresAt: Date.now() + 86400000,
    scopes: ['*'],
    permissions: getDefaultPermissionsForRole('SYSTEM_OWNER')
  };

  const mockSuperAdminPrincipal: Principal = {
    id: 'super_admin_elena',
    name: 'Elena Rostova',
    email: 'elena.superadmin@lorin.internal',
    role: 'SUPER_ADMIN',
    canonicalRole: 'SUPER_ADMIN',
    accountStatus: 'ACTIVE',
    authenticated: true,
    enrolledAt: Date.now() - 8000,
    sessionExpiresAt: Date.now() + 86400000,
    scopes: ['*'],
    permissions: getDefaultPermissionsForRole('SUPER_ADMIN')
  };

  const mockAdminPrincipal: Principal = {
    id: 'admin_marcus',
    name: 'Marcus Vance',
    email: 'marcus.admin@lorin.internal',
    role: 'ADMINISTRATOR',
    canonicalRole: 'ADMINISTRATOR',
    accountStatus: 'ACTIVE',
    authenticated: true,
    enrolledAt: Date.now() - 7000,
    sessionExpiresAt: Date.now() + 86400000,
    scopes: ['app:access'],
    permissions: getDefaultPermissionsForRole('ADMINISTRATOR')
  };

  const mockEngineerPrincipal: Principal = {
    id: 'engineer_456',
    name: 'Alex Engineer',
    email: 'alex@example.com',
    role: 'ENGINEER',
    canonicalRole: 'SPECIALIST',
    accountStatus: 'ACTIVE',
    authenticated: true,
    enrolledAt: Date.now() - 5000,
    sessionExpiresAt: Date.now() + 86400000,
    scopes: ['code:read', 'chat:write'],
    permissions: getDefaultPermissionsForRole('SPECIALIST')
  };

  const mockStandardUserPrincipal: Principal = {
    id: 'standard_clara',
    name: 'Clara Chen',
    email: 'clara.user@lorin.internal',
    role: 'STANDARD_USER',
    canonicalRole: 'STANDARD_USER',
    accountStatus: 'ACTIVE',
    authenticated: true,
    enrolledAt: Date.now() - 4000,
    sessionExpiresAt: Date.now() + 86400000,
    scopes: ['app:access'],
    permissions: getDefaultPermissionsForRole('STANDARD_USER')
  };

  const mockGuestPrincipal: Principal = {
    id: 'guest_unauthenticated',
    name: 'Guest User',
    email: '',
    role: 'GUEST',
    canonicalRole: 'RESTRICTED',
    accountStatus: 'ACTIVE',
    authenticated: false,
    enrolledAt: 0,
    sessionExpiresAt: 0,
    scopes: ['read:public'],
    permissions: getDefaultPermissionsForRole('RESTRICTED')
  };

  const mockAuthenticatedGuest: Principal = {
    id: 'guest_789',
    name: 'Guest Member',
    email: 'guest@example.com',
    role: 'GUEST',
    canonicalRole: 'RESTRICTED',
    accountStatus: 'RESTRICTED',
    authenticated: true,
    enrolledAt: Date.now(),
    sessionExpiresAt: Date.now() + 3600000,
    scopes: ['read:public'],
    permissions: getDefaultPermissionsForRole('RESTRICTED')
  };

  beforeEach(() => {
    PolicyEngine.clearState();
  });

  describe('Cryptographic Action Digest Generation', () => {
    it('generates consistent SHA-256 digests for identical input parameters', async () => {
      const digest1 = await computeActionDigest('user1', 'deploy_production', 'app://main', { env: 'prod', v: '1.2' });
      const digest2 = await computeActionDigest('user1', 'deploy_production', 'app://main', { v: '1.2', env: 'prod' });

      expect(digest1).toBe(digest2);
      expect(digest1).toHaveLength(64); // 256 bits = 64 hex chars
    });

    it('generates distinct digests when parameters or principal change', async () => {
      const digest1 = await computeActionDigest('user1', 'deploy_production', 'app://main', { env: 'prod' });
      const digest2 = await computeActionDigest('user2', 'deploy_production', 'app://main', { env: 'prod' });

      expect(digest1).not.toBe(digest2);
    });
  });

  describe('Sensitive Parameter Redaction', () => {
    it('redacts sensitive credentials, tokens, and keys from parameter dictionaries', () => {
      const rawParams = {
        username: 'admin',
        apiKey: 'secret_1234567890',
        dbPassword: 'SuperSecretPassword',
        nested: {
          authToken: 'bearer_token_xyz',
          publicSetting: true
        }
      };

      const redacted = redactSensitiveData(rawParams);

      expect(redacted.username).toBe('admin');
      expect(redacted.apiKey).toBe('[REDACTED_SECRET]');
      expect(redacted.dbPassword).toBe('[REDACTED_SECRET]');
      expect(redacted.nested.authToken).toBe('[REDACTED_SECRET]');
      expect(redacted.nested.publicSetting).toBe(true);
    });
  });

  describe('Policy Evaluation - Rule 1: Fail-Closed Unauthenticated Deny', () => {
    it('strictly denies unauthenticated requests', async () => {
      const req: ActionRequest = {
        id: 'act_1',
        action: 'read_logs',
        resource: 'logs://audit',
        description: 'Read audit events',
        riskLevel: 'LOW',
        requiredScope: 'read'
      };

      const res = await PolicyEngine.evaluateAction(mockGuestPrincipal, req);

      expect(res.decision).toBe('DENY');
      expect(res.reason.toLowerCase()).toContain('authentication required');
      expect(res.digest).toBeDefined();
    });
  });

  describe('Policy Evaluation - Rule 2: Client Bypass Flag Rejection', () => {
    it('detects and rejects caller-supplied bypass or user_authorized flags', async () => {
      const req: ActionRequest = {
        id: 'act_2',
        action: 'read_code',
        resource: 'repo://src',
        description: 'Read source code',
        riskLevel: 'LOW',
        requiredScope: 'code:read'
      };

      const res = await PolicyEngine.evaluateAction(mockEngineerPrincipal, req, { user_authorized: true });

      expect(res.decision).toBe('DENY');
      expect(res.reason.toLowerCase()).toContain('security violation');
    });
  });

  describe('Policy Evaluation - Rule 3: High-Impact Operation Step-Up Approval', () => {
    it('requires explicit owner or super-admin approval for high-impact or critical risk actions', async () => {
      const highImpactReq: ActionRequest = {
        id: 'act_3',
        action: 'purge_database',
        resource: 'db://production',
        description: 'Purge obsolete production database tables',
        riskLevel: 'CRITICAL',
        requiredScope: 'db:write'
      };

      const evalRes = await PolicyEngine.evaluateAction(mockEngineerPrincipal, highImpactReq);

      expect(evalRes.decision).toBe('REQUIRES_APPROVAL');
      expect(evalRes.approvalRecord).toBeDefined();
      expect(evalRes.approvalRecord?.status).toBe('PENDING');

      // Attempt approval by non-owner / non-super-admin -> rejected
      const nonOwnerApproveRes = await PolicyEngine.approveAction(evalRes.approvalRecord!.id, mockEngineerPrincipal);
      expect(nonOwnerApproveRes.success).toBe(false);

      // Approval by verified owner -> succeeds
      const ownerApproveRes = await PolicyEngine.approveAction(evalRes.approvalRecord!.id, mockOwnerPrincipal);
      expect(ownerApproveRes.success).toBe(true);

      // Subsequent evaluation matches digest and consumes token
      const retryEval = await PolicyEngine.evaluateAction(mockEngineerPrincipal, highImpactReq);
      expect(retryEval.decision).toBe('ALLOW');
      expect(retryEval.reason.toLowerCase()).toContain('consumed');

      // Immediate re-evaluation is blocked (replay protection)
      const replayEval = await PolicyEngine.evaluateAction(mockEngineerPrincipal, highImpactReq);
      expect(replayEval.decision).toBe('DENY');
      expect(replayEval.reason.toLowerCase()).toContain('replay attack');
    });

    it('prevents approval reuse across different action IDs (replay protection)', async () => {
      const purgeReq: ActionRequest = {
        id: 'act_purge',
        action: 'purge_database',
        resource: 'db://production',
        description: 'Purge database tables',
        riskLevel: 'CRITICAL',
        requiredScope: 'db:write'
      };

      const evalRes = await PolicyEngine.evaluateAction(mockEngineerPrincipal, purgeReq);
      const approvalId = evalRes.approvalRecord!.id;

      // Owner approves the purge request
      await PolicyEngine.approveAction(approvalId, mockOwnerPrincipal);

      // Attempt to validate/execute this approval ID for a DIFFERENT action ID (e.g. transfer_funds)
      const transferReq: ActionRequest = {
        id: 'act_transfer',
        action: 'transfer_funds',
        resource: 'bank://account',
        description: 'Transfer funds',
        riskLevel: 'HIGH',
        requiredScope: 'funds:write'
      };

      const validationRes = await PolicyEngine.validateApprovalForExecution(
        approvalId,
        transferReq,
        mockEngineerPrincipal
      );

      expect(validationRes.valid).toBe(false);
      expect(validationRes.reason.toLowerCase()).toContain('replay attack');
    });

    it('blocks duplicate execution attempts of the same action ID and principal ID hash', async () => {
      PolicyEngine.resetConsumedHashes();

      const req: ActionRequest = {
        id: 'act_shell_exec',
        action: 'execute_shell',
        resource: 'system://terminal',
        description: 'Execute shell command',
        riskLevel: 'HIGH',
        requiredScope: 'system:exec'
      };

      // 1. Initial evaluation -> REQUIRES_APPROVAL
      const evalRes1 = await PolicyEngine.evaluateAction(mockEngineerPrincipal, req);
      expect(evalRes1.decision).toBe('REQUIRES_APPROVAL');

      // 2. Super Admin approves
      const saApprove = await PolicyEngine.approveAction(evalRes1.approvalRecord!.id, mockSuperAdminPrincipal);
      expect(saApprove.success).toBe(true);

      // 3. Execution/consumption -> ALLOW
      const evalRes2 = await PolicyEngine.evaluateAction(mockEngineerPrincipal, req);
      expect(evalRes2.decision).toBe('ALLOW');

      // 4. Duplicate execution attempt -> DENY due to consumed actionPrincipalHash
      const evalRes3 = await PolicyEngine.evaluateAction(mockEngineerPrincipal, req);
      expect(evalRes3.decision).toBe('DENY');
      expect(evalRes3.reason.toLowerCase()).toContain('replay attack');
    });
  });

  describe('Policy Evaluation - Rule 4: Guest Role Restrictions', () => {
    it('restricts authenticated guest principals to Level 0 Observe read actions', async () => {
      const writeReq: ActionRequest = {
        id: 'act_4',
        action: 'write_document',
        resource: 'vault://doc1',
        description: 'Modify vault document',
        riskLevel: 'MEDIUM',
        requiredScope: 'vault:write'
      };

      const evalRes = await PolicyEngine.evaluateAction(mockAuthenticatedGuest, writeReq);

      expect(evalRes.decision).toBe('DENY');
      expect(evalRes.reason.toLowerCase()).toContain('observe');
    });
  });

  describe('Standard Action Allowance', () => {
    it('allows low-risk actions for authenticated engineers with valid scope', async () => {
      const lowRiskReq: ActionRequest = {
        id: 'act_5',
        action: 'search_knowledge_vault',
        resource: 'vault://documents',
        description: 'Search Knowledge Vault documents',
        riskLevel: 'LOW',
        requiredScope: 'vault:read'
      };

      const evalRes = await PolicyEngine.evaluateAction(mockEngineerPrincipal, lowRiskReq);

      expect(evalRes.decision).toBe('ALLOW');
      expect(evalRes.digest).toHaveLength(64);
    });
  });

  describe('LORIN V2 — 6-Level Canonical Role Hierarchy & Full-Feature Enumeration', () => {
    it('enumerates all 17 application modules (including GIDEON) and all 17 feature categories for SYSTEM_OWNER and SUPER_ADMIN', () => {
      expect(ALL_REGISTERED_MODULES).toHaveLength(17);
      expect(GLOBAL_FEATURE_ACCESS_MATRIX).toHaveLength(17);

      // SYSTEM_OWNER must access 17/17 modules and system.owner.manage
      for (const mod of ALL_REGISTERED_MODULES) {
        expect(PolicyEngine.canAccessModule(mockOwnerPrincipal, mod)).toBe(true);
      }
      expect(PolicyEngine.hasPermission(mockOwnerPrincipal, 'system.owner.manage')).toBe(true);
      expect(PolicyEngine.hasPermission(mockOwnerPrincipal, 'roles.manage')).toBe(true);

      // SUPER_ADMIN must access 16/16 application modules, all admin permissions, EXCEPT system.owner.manage
      for (const mod of ALL_REGISTERED_MODULES) {
        expect(PolicyEngine.canAccessModule(mockSuperAdminPrincipal, mod)).toBe(true);
      }
      expect(PolicyEngine.hasPermission(mockSuperAdminPrincipal, 'roles.manage')).toBe(true);
      expect(PolicyEngine.hasPermission(mockSuperAdminPrincipal, 'providers.manage')).toBe(true);
      expect(PolicyEngine.hasPermission(mockSuperAdminPrincipal, 'system.owner.manage')).toBe(false);
    });

    it('enforces scoped module and permission boundaries for ADMINISTRATOR, SPECIALIST, STANDARD_USER, and RESTRICTED', () => {
      // ADMINISTRATOR can access security & connections, but not mosairaLab unless explicitly delegated
      expect(PolicyEngine.canAccessModule(mockAdminPrincipal, 'security')).toBe(true);
      expect(PolicyEngine.canAccessModule(mockAdminPrincipal, 'connections')).toBe(true);
      expect(PolicyEngine.canAccessModule(mockAdminPrincipal, 'mosairaLab')).toBe(false);

      // SPECIALIST can access specialists, terminal, tests, laurenVault, but not security or ownerGateway
      expect(PolicyEngine.canAccessModule(mockEngineerPrincipal, 'specialists')).toBe(true);
      expect(PolicyEngine.canAccessModule(mockEngineerPrincipal, 'terminal')).toBe(true);
      expect(PolicyEngine.canAccessModule(mockEngineerPrincipal, 'security')).toBe(false);
      expect(PolicyEngine.canAccessModule(mockEngineerPrincipal, 'ownerGateway')).toBe(false);

      // STANDARD_USER can access chat, voice, video, vault, memory, projects, tasks, settings, but ZERO admin modules
      expect(PolicyEngine.canAccessModule(mockStandardUserPrincipal, 'chat')).toBe(true);
      expect(PolicyEngine.canAccessModule(mockStandardUserPrincipal, 'vault')).toBe(true);
      expect(PolicyEngine.canAccessModule(mockStandardUserPrincipal, 'projects')).toBe(true);
      expect(PolicyEngine.canAccessModule(mockStandardUserPrincipal, 'ownerGateway')).toBe(false);
      expect(PolicyEngine.canAccessModule(mockStandardUserPrincipal, 'security')).toBe(false);
      expect(PolicyEngine.canAccessModule(mockStandardUserPrincipal, 'terminal')).toBe(false);
      expect(PolicyEngine.hasPermission(mockStandardUserPrincipal, 'roles.manage')).toBe(false);

      // RESTRICTED cannot access private modules
      expect(PolicyEngine.canAccessModule(mockAuthenticatedGuest, 'ownerGateway')).toBe(false);
      expect(PolicyEngine.canAccessModule(mockAuthenticatedGuest, 'vault')).toBe(false);
    });

    it('enforces System Owner invariants: blocks last-owner demotion and blocks SUPER_ADMIN from modifying SYSTEM_OWNER', async () => {
      const ownerAccount = await PolicyEngine.inviteManagedAccount(mockOwnerPrincipal, {
        email: 'test.primary.owner@example.test',
        displayName: 'Test Primary Owner',
        role: 'SYSTEM_OWNER'
      });
      const standardAccount = await PolicyEngine.inviteManagedAccount(mockOwnerPrincipal, {
        email: 'test.standard.member@example.test',
        displayName: 'Test Standard Member',
        role: 'STANDARD_USER'
      });
      expect(ownerAccount.success).toBe(true);
      expect(standardAccount.success).toBe(true);
      const ownerUid = ownerAccount.account!.uid;
      const standardUid = standardAccount.account!.uid;

      // 1. Last SYSTEM_OWNER cannot be demoted
      const demoteOwnerRes = await PolicyEngine.assignAccountRole(
        mockOwnerPrincipal,
        ownerUid,
        'STANDARD_USER'
      );
      expect(demoteOwnerRes.success).toBe(false);
      expect(demoteOwnerRes.message.toLowerCase()).toContain('last active system_owner');

      // 2. SUPER_ADMIN cannot promote any account to SYSTEM_OWNER
      const saPromoteToOwner = await PolicyEngine.assignAccountRole(
        mockSuperAdminPrincipal,
        standardUid,
        'SYSTEM_OWNER'
      );
      expect(saPromoteToOwner.success).toBe(false);
      expect(saPromoteToOwner.message.toLowerCase()).toContain('system_owner');

      // 3. SUPER_ADMIN cannot modify or disable a SYSTEM_OWNER account
      const saDisableOwner = await PolicyEngine.updateAccountStatus(
        mockSuperAdminPrincipal,
        ownerUid,
        'DISABLED'
      );
      expect(saDisableOwner.success).toBe(false);

      // 4. SUPER_ADMIN CAN promote a STANDARD_USER to SPECIALIST or ADMINISTRATOR
      const saPromoteClara = await PolicyEngine.assignAccountRole(
        mockSuperAdminPrincipal,
        standardUid,
        'SPECIALIST'
      );
      expect(saPromoteClara.success).toBe(true);
      expect(saPromoteClara.account?.canonicalRole).toBe('SPECIALIST');

      // 5. STANDARD_USER cannot assign roles
      const stdAssignAttempt = await PolicyEngine.assignAccountRole(
        mockStandardUserPrincipal,
        standardUid,
        'SUPER_ADMIN'
      );
      expect(stdAssignAttempt.success).toBe(false);
    });

    it('immediately denies actions for DISABLED or REVOKED accounts and revoked sessions', async () => {
      const disabledPrincipal: Principal = {
        ...mockEngineerPrincipal,
        accountStatus: 'DISABLED'
      };
      const req: ActionRequest = {
        id: 'act_disabled_test',
        action: 'search_knowledge_vault',
        resource: 'vault://docs',
        description: 'Test disabled account rejection',
        riskLevel: 'LOW',
        requiredScope: 'vault:read'
      };
      const evalDisabled = await PolicyEngine.evaluateAction(disabledPrincipal, req);
      expect(evalDisabled.decision).toBe('DENY');
      expect(evalDisabled.reason).toContain('DISABLED');

      const revokedSessionPrincipal: Principal = {
        ...mockEngineerPrincipal,
        enrolledAt: Date.now() - 60000,
        sessionRevokedAt: Date.now() - 1000
      };
      const evalRevoked = await PolicyEngine.evaluateAction(revokedSessionPrincipal, req);
      expect(evalRevoked.decision).toBe('DENY');
      expect(evalRevoked.reason.toLowerCase()).toContain('revoked');
    });
  });

  describe('Ollama Cloud Central Model Registry, 15-Capability Task Routing & Embedding Pipeline', () => {
    it('registers all 8 preferred open-weight models + Qwen3-Embedding-8B + Gemini with accurate license classifications', async () => {
      const { getModelRegistryList, TASK_ROUTING_POLICY_TABLE, classifyTaskCategory, selectModelForTask, trimContextToBudget } = await import('../../serverModelRegistry');
      const registry = getModelRegistryList();
      const expectedOllamaIds = [
        'deepseek-v4-flash',
        'deepseek-v4-pro',
        'qwen3.5',
        'glm-5.3-flash',
        'gpt-oss:20b',
        'gpt-oss:120b',
        'kimi-k3',
        'gemma4:31b',
        'qwen3-embedding:8b'
      ];
      for (const id of expectedOllamaIds) {
        const entry = registry.find(m => m.modelId === id);
        expect(entry).toBeDefined();
        expect(entry?.provider).toBe(id === 'qwen3-embedding:8b' ? 'embedding-provider' : 'ollama-cloud');
        expect(entry?.officialReferenceUrl).toContain('https://ollama.com/library/');
      }

      // Verify all 15 task routing capabilities are defined
      expect(TASK_ROUTING_POLICY_TABLE.length).toBe(15);

      // Verify task classification
      expect(
        classifyTaskCategory({
          prompt: 'Inspect this screenshot image',
          snapshotImage: 'data:image/png;base64,iVBORw0KGgo='
        })
      ).toBe('IMAGE_UNDERSTANDING');
      expect(classifyTaskCategory({ prompt: 'Design system architecture and security threat model for microservice' })).toBe('ARCHITECTURE_STRATEGY');
      expect(classifyTaskCategory({ prompt: 'Fix TypeScript compiler bug and refactor unit test' })).toBe('SOFTWARE_ENGINEERING_CODING');

      // Verify context trimming budget governance
      const longText = 'A'.repeat(10000);
      const trimmed = trimContextToBudget(longText, 500);
      expect(typeof trimmed).toBe('string');
      expect(trimmed.length).toBeLessThan(longText.length);
      expect(trimmed).toContain('[Context truncated');

      // Verify routing decision returns truthful attribution
      const decision = selectModelForTask({
        prompt: 'Architect a distributed database migration strategy'
      });
      expect(decision.taskCategory).toBe('ARCHITECTURE_STRATEGY');
      expect(decision.policyEntry.notes.length).toBeGreaterThan(5);
    });
  });
});


