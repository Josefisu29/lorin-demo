import { describe, it, expect, beforeEach } from 'vitest';
import { SPECIALISTS } from '../data/specialists';
import { GideonService } from '../services/gideonService';
import {
  ALL_CANONICAL_PERMISSIONS,
  getDefaultPermissionsForRole,
  Principal
} from '../types/lorin';
import { ALL_REGISTERED_MODULES, MODULE_REQUIRED_PERMISSIONS, PolicyEngine } from '../services/policyEngine';

describe('GIDEON Systems & Timeline Intelligence Suite', () => {
  const testOwner: Principal = {
    id: 'usr_owner_gideon_test',
    name: 'Joseph Isah',
    email: 'owner@example.test',
    role: 'OWNER',
    canonicalRole: 'SYSTEM_OWNER',
    accountStatus: 'ACTIVE',
    authenticated: true,
    enrolledAt: Date.now(),
    sessionExpiresAt: Date.now() + 86400000,
    scopes: ['*'],
    permissions: getDefaultPermissionsForRole('SYSTEM_OWNER')
  };

  const standardUser: Principal = {
    id: 'usr_standard_clara',
    name: 'Clara Chen',
    email: 'clara@lorin.internal',
    role: 'STANDARD_USER',
    canonicalRole: 'STANDARD_USER',
    accountStatus: 'ACTIVE',
    authenticated: true,
    enrolledAt: Date.now(),
    sessionExpiresAt: Date.now() + 86400000,
    scopes: ['app:access'],
    permissions: getDefaultPermissionsForRole('STANDARD_USER')
  };

  beforeEach(() => {
    GideonService.setActiveUser(testOwner.id);
  });

  it('1. Registers GIDEON as native 6th specialist in central specialist registry', () => {
    const gideon = SPECIALISTS.GIDEON_SYSTEMS;
    expect(gideon).toBeDefined();
    expect(gideon.name).toBe('GIDEON');
    expect(gideon.role).toBe('GIDEON_SYSTEMS');
    expect(gideon.title).toBe('Systems Intelligence');
    expect(gideon.accentColor).toBe('#E5A93C');
    expect(gideon.domain).toContain('Timeline intelligence');
    expect(gideon.guidingQuestion.length).toBeGreaterThan(15);

    const coreKeys = Object.keys(SPECIALISTS);
    expect(coreKeys.length).toBe(6);
  });

  it('2. Records persistent timeline events with server timestamps and category validation', async () => {
    const event = await GideonService.recordEvent({
      ownerUid: testOwner.id,
      projectId: 'proj_lorin_core',
      category: 'code_change',
      title: 'Integrated GIDEON Timeline Engine',
      summary: 'Added persistent event store and correlation analyzer.',
      source: 'Unit Test',
      occurredAt: Date.now() - 500,
      verificationStatus: 'verified'
    }, testOwner);

    expect(event.eventId).toContain('gid_evt_');
    expect(event.schemaVersion).toBe(1);
    expect(event.title).toBe('Integrated GIDEON Timeline Engine');

    const timeline = await GideonService.getTimeline({
      projectId: 'proj_lorin_core',
      category: 'code_change'
    });

    expect(timeline.events.some(e => e.eventId === event.eventId)).toBe(true);
    expect(timeline.total).toBeGreaterThan(0);
  });

  it('3. Preserves Architectural Decision Records (ADRs) with rationale and evidence', async () => {
    const decision = await GideonService.recordDecision({
      projectId: 'proj_lorin_core',
      title: 'Zero-Trust RBAC Multi-Layer Enforcement',
      decisionDescription: 'Every sensitive operation must pass through backend serverAuth middleware and client-side gate.',
      alternativesConsidered: ['Frontend-only route protection', 'Static API keys in client'],
      reasoning: 'Guarantees that unauthorized API requests are rejected even if client UI is manipulated.',
      supportingEvidence: ['OWASP Top 10 API Security', 'Master System Instructions Section 11'],
      decisionOwner: 'System Owner',
      status: 'APPROVED'
    }, testOwner);

    expect(decision.decisionId).toContain('gid_dec_');
    expect(decision.status).toBe('PROPOSED');
    expect(decision.alternativesConsidered.length).toBe(2);

    const decisions = await GideonService.getProjectDecisions('proj_lorin_core');
    expect(decisions.some(d => d.decisionId === decision.decisionId)).toBe(true);
  });

  it('4. Correlates sequential events with evidence separation and hypothesis tagging', async () => {
    const e1 = await GideonService.recordEvent({
      ownerUid: testOwner.id,
      projectId: 'proj_lorin_core',
      category: 'configuration',
      title: 'Modified Firebase Firestore Security Rules',
      summary: 'Updated access control rules for /gideon_events collection.',
      source: 'DevOps',
      occurredAt: Date.now() - 120000,
      verificationStatus: 'verified'
    });

    const e2 = await GideonService.recordEvent({
      ownerUid: testOwner.id,
      projectId: 'proj_lorin_core',
      category: 'diagnostic',
      title: 'Database Rule Audit Completed',
      summary: 'Automated policy rule check verified default-deny on gideon collection.',
      source: 'Security Engine',
      occurredAt: Date.now(),
      verificationStatus: 'verified'
    });

    const correlations = await GideonService.correlateEvents([e1.eventId, e2.eventId]);
    expect(correlations.length).toBe(1);
    expect(correlations[0].identifiedEvents[0].eventId).toBe(e1.eventId);
    expect(correlations[0].identifiedEvents[1].eventId).toBe(e2.eventId);
    expect(correlations[0].availableEvidence.length).toBeGreaterThan(1);
  });

  it('5. Refuses to fabricate predictions without verified telemetry and a provider', async () => {
    await expect(GideonService.generatePrediction(
      'Database Migration Latency Horizon',
      'proj_lorin_core',
      'Next 24h'
    )).rejects.toThrow();
  });

  it('6. Executes system diagnostics with truthful service status and latency', async () => {
    const diag = await GideonService.runDiagnostics();
    expect(diag.checkedAt).toBeGreaterThan(0);
    expect(['HEALTHY', 'DEGRADED', 'UNAVAILABLE']).toContain(diag.overallStatus);
    expect(diag.observations.length).toBeGreaterThan(1);

    const beObs = diag.observations.find(o => o.metricCategory === 'api');
    expect(beObs).toBeDefined();
    expect(beObs?.observedValueOrStatus).toBeDefined();
  });

  it('7. Simulates hypothetical scenarios without committing unapproved operations', async () => {
    const scenario = await GideonService.simulateScenario(
      'Evaluate PostgreSQL / Cloud SQL Migration',
      ['Provision dedicated Cloud SQL PostgreSQL instance', 'Run Drizzle schema migration script']
    );

    expect(scenario.scenarioId).toContain('gid_scen_');
    expect(scenario.status).toBe('HYPOTHETICAL');
    expect(scenario.expectedBenefits.length).toBeGreaterThan(0);
    expect(scenario.potentialRisks.length).toBeGreaterThan(0);
    expect(scenario.recommendedNextAction).toContain('Owen');
  });

  it('8. Answers timeline inquiries grounded in real chronological events', async () => {
    const res = await GideonService.queryGideon(
      'What was the most recent deployment milestone recorded?',
      'proj_lorin_core'
    );

    expect(res.answer.length).toBeGreaterThan(0);
    expect(res.confidence).toBeDefined();
    expect(res.recommendedNextStep.length).toBeGreaterThan(5);
  });

  it('9. Enforces canonical RBAC permissions and module access for GIDEON workspace', () => {
    expect(ALL_REGISTERED_MODULES).toContain('gideon');
    expect(MODULE_REQUIRED_PERMISSIONS.gideon).toEqual(['gideon.access']);

    expect(PolicyEngine.canAccessModule(testOwner, 'gideon')).toBe(true);
    expect(PolicyEngine.canAccessModule(standardUser, 'gideon')).toBe(true);

    const restrictedUser: Principal = {
      ...standardUser,
      accountStatus: 'DISABLED'
    };
    expect(PolicyEngine.canAccessModule(restrictedUser, 'gideon')).toBe(false);

    expect(ALL_CANONICAL_PERMISSIONS).toContain('gideon.access');
    expect(ALL_CANONICAL_PERMISSIONS).toContain('gideon.timeline.read');
    expect(ALL_CANONICAL_PERMISSIONS).toContain('gideon.timeline.write');
    expect(ALL_CANONICAL_PERMISSIONS).toContain('gideon.diagnostics.read');
    expect(ALL_CANONICAL_PERMISSIONS).toContain('gideon.predictions.create');
    expect(ALL_CANONICAL_PERMISSIONS).toContain('gideon.scenarios.create');
  });
});
