import { describe, it, expect, beforeEach } from 'vitest';

if (typeof localStorage === 'undefined') {
  let store: Record<string, string> = {};
  (globalThis as any).localStorage = {
    getItem: (key: string) => (key in store ? store[key] : null),
    setItem: (key: string, val: string) => {
      store[key] = String(val);
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    }
  };
}

import {
  PolicyEngine,
  hasPermission,
  requirePermission,
  isSystemOwner,
  isSuperAdmin,
  isPrivilegedUser,
  assertAuthenticated,
  assertActiveAccount
} from '../services/policyEngine';
import {
  buildUserStoragePath,
  validateStorageUpload,
  MAX_STORAGE_FILE_SIZE_BYTES
} from '../services/firebase';
import {
  bootstrapOneTimeSystemOwner,
  inviteOrCreateManagedAccount,
  updateManagedAccountRole,
  updateManagedAccountStatus,
  revokeManagedAccountSessions
} from '../../serverAuth';
import { Principal } from '../types/lorin';

const SYSTEM_OWNER_PRINCIPAL: Principal = {
  id: 'uid_sys_owner_1',
  name: 'Primary System Owner',
  email: 'owner@lorin.private',
  role: 'SYSTEM_OWNER',
  canonicalRole: 'SYSTEM_OWNER',
  accountStatus: 'ACTIVE',
  authenticated: true,
  emailVerified: true,
  enrolledAt: Date.now() - 10_000,
  sessionExpiresAt: Date.now() + 3_600_000,
  scopes: ['*']
};

const SUPER_ADMIN_PRINCIPAL: Principal = {
  id: 'uid_super_admin_1',
  name: 'Designated Super Admin',
  email: 'superadmin@lorin.private',
  role: 'SUPER_ADMIN',
  canonicalRole: 'SUPER_ADMIN',
  accountStatus: 'ACTIVE',
  authenticated: true,
  emailVerified: true,
  enrolledAt: Date.now() - 10_000,
  sessionExpiresAt: Date.now() + 3_600_000,
  scopes: ['*']
};

const STANDARD_USER_A: Principal = {
  id: 'uid_std_user_a',
  name: 'Standard User Alpha',
  email: 'alpha@lorin.private',
  role: 'STANDARD_USER',
  canonicalRole: 'STANDARD_USER',
  accountStatus: 'ACTIVE',
  authenticated: true,
  emailVerified: true,
  enrolledAt: Date.now() - 10_000,
  sessionExpiresAt: Date.now() + 3_600_000,
  scopes: ['chat:write', 'vault:read']
};

const UNAUTHENTICATED_GUEST: Principal = {
  id: 'guest_unverified',
  name: 'Unauthenticated Visitor',
  email: '',
  role: 'GUEST',
  canonicalRole: 'RESTRICTED',
  accountStatus: 'RESTRICTED',
  authenticated: false,
  enrolledAt: 0,
  sessionExpiresAt: 0,
  scopes: []
};

describe('LORIN Section 20 — Complete Auth, RBAC, Ownership & Firebase Security Suite', () => {
  beforeEach(() => {
    localStorage.clear();
    PolicyEngine.clearState();
  });

  it('1. Rejects unauthenticated principals across centralized permission helpers', () => {
    expect(isSystemOwner(UNAUTHENTICATED_GUEST)).toBe(false);
    expect(isSuperAdmin(UNAUTHENTICATED_GUEST)).toBe(false);
    expect(isPrivilegedUser(UNAUTHENTICATED_GUEST)).toBe(false);
    expect(hasPermission(UNAUTHENTICATED_GUEST, 'chat.access')).toBe(false);
    expect(() => assertAuthenticated(UNAUTHENTICATED_GUEST)).toThrow(/Authentication required/);
    expect(() => requirePermission(UNAUTHENTICATED_GUEST, 'chat.access')).toThrow(/Authentication required/);
  });

  it('2. Allows STANDARD_USER to access personal assistant permissions and own resources, but blocks cross-user and admin access', () => {
    expect(isSystemOwner(STANDARD_USER_A)).toBe(false);
    expect(isSuperAdmin(STANDARD_USER_A)).toBe(false);
    expect(isPrivilegedUser(STANDARD_USER_A)).toBe(false);

    // Permitted personal assistant features
    expect(hasPermission(STANDARD_USER_A, 'chat.access')).toBe(true);
    expect(hasPermission(STANDARD_USER_A, 'voice.access')).toBe(true);
    expect(hasPermission(STANDARD_USER_A, 'vision.access')).toBe(true);
    expect(hasPermission(STANDARD_USER_A, 'research.access')).toBe(true);
    expect(hasPermission(STANDARD_USER_A, 'knowledge.access')).toBe(true);
    expect(hasPermission(STANDARD_USER_A, 'projects.access')).toBe(true);
    expect(hasPermission(STANDARD_USER_A, 'files.manage_own', { resourceOwnerId: STANDARD_USER_A.id })).toBe(true);

    // Cross-user resource isolation: STANDARD_USER A cannot access User B's resources
    expect(hasPermission(STANDARD_USER_A, 'files.manage_own', { resourceOwnerId: 'uid_std_user_b' })).toBe(false);
    expect(() =>
      requirePermission(STANDARD_USER_A, 'files.manage_own', { resourceOwnerId: 'uid_std_user_b' })
    ).toThrow(/Forbidden/);

    // Administrative & ownership scopes strictly denied to STANDARD_USER
    expect(hasPermission(STANDARD_USER_A, 'users.read')).toBe(false);
    expect(hasPermission(STANDARD_USER_A, 'users.manage')).toBe(false);
    expect(hasPermission(STANDARD_USER_A, 'roles.manage')).toBe(false);
    expect(hasPermission(STANDARD_USER_A, 'providers.manage')).toBe(false);
    expect(hasPermission(STANDARD_USER_A, 'security.manage')).toBe(false);
    expect(hasPermission(STANDARD_USER_A, 'ownership.manage')).toBe(false);
  });

  it('3. Grants SUPER_ADMIN full LORIN operational & admin permissions while blocking ownership.manage', () => {
    expect(isSuperAdmin(SUPER_ADMIN_PRINCIPAL)).toBe(true);
    expect(isSystemOwner(SUPER_ADMIN_PRINCIPAL)).toBe(false);
    expect(isPrivilegedUser(SUPER_ADMIN_PRINCIPAL)).toBe(true);

    const operationalScopes = [
      'chat.access',
      'voice.access',
      'vision.access',
      'research.access',
      'coding.access',
      'knowledge.access',
      'projects.access',
      'files.manage_own',
      'users.read',
      'users.manage',
      'roles.read',
      'roles.manage',
      'system.read',
      'system.manage',
      'providers.read',
      'providers.manage',
      'integrations.manage',
      'security.read',
      'security.manage',
      'audit.read',
      'backup.manage',
      'device_operations.execute'
    ] as const;

    for (const perm of operationalScopes) {
      expect(hasPermission(SUPER_ADMIN_PRINCIPAL, perm)).toBe(true);
    }

    // Ownership authority is strictly reserved for SYSTEM_OWNER
    expect(hasPermission(SUPER_ADMIN_PRINCIPAL, 'ownership.manage')).toBe(false);
    expect(hasPermission(SUPER_ADMIN_PRINCIPAL, 'system.owner.manage')).toBe(false);
    expect(() => requirePermission(SUPER_ADMIN_PRINCIPAL, 'ownership.manage')).toThrow(/Forbidden/);
  });

  it('4. Enforces that ONLY SYSTEM_OWNER can appoint, promote, demote, or disable SUPER_ADMIN or SYSTEM_OWNER (Client & Server RBAC)', async () => {
    // 1. SYSTEM_OWNER can appoint a SUPER_ADMIN
    const ownerAppointSA = await PolicyEngine.inviteManagedAccount(SYSTEM_OWNER_PRINCIPAL, {
      email: 'appointed.sa@lorin.private',
      displayName: 'Appointed Super Admin',
      role: 'SUPER_ADMIN'
    });
    expect(ownerAppointSA.success).toBe(true);
    expect(ownerAppointSA.account?.canonicalRole).toBe('SUPER_ADMIN');

    // 2. SUPER_ADMIN CANNOT invite or appoint another SUPER_ADMIN
    const saAppointSA = await PolicyEngine.inviteManagedAccount(SUPER_ADMIN_PRINCIPAL, {
      email: 'rogue.sa@lorin.private',
      displayName: 'Unauthorized Super Admin',
      role: 'SUPER_ADMIN'
    });
    expect(saAppointSA.success).toBe(false);
    expect(saAppointSA.message).toContain('Only System Owner');

    // 3. SUPER_ADMIN CANNOT modify or disable an existing SUPER_ADMIN
    const saDisableSA = await PolicyEngine.updateAccountStatus(
      SUPER_ADMIN_PRINCIPAL,
      ownerAppointSA.account!.uid,
      'DISABLED'
    );
    expect(saDisableSA.success).toBe(false);
    expect(saDisableSA.message).toContain('Only System Owner');

    // 4. Server-side enforcement in serverAuth.ts matches identically
    const serverSaAttemptInviteSA = inviteOrCreateManagedAccount(
      { id: SUPER_ADMIN_PRINCIPAL.id, email: SUPER_ADMIN_PRINCIPAL.email, canonicalRole: 'SUPER_ADMIN' },
      { email: 'server.rogue.sa@lorin.private', role: 'SUPER_ADMIN' }
    );
    expect(serverSaAttemptInviteSA.success).toBe(false);

    const serverOwnerCreateStd = inviteOrCreateManagedAccount(
      { id: SYSTEM_OWNER_PRINCIPAL.id, email: SYSTEM_OWNER_PRINCIPAL.email, canonicalRole: 'SYSTEM_OWNER' },
      { email: 'server.std.member@lorin.private', role: 'STANDARD_USER' }
    );
    expect(serverOwnerCreateStd.success).toBe(true);

    // SUPER_ADMIN cannot promote STANDARD_USER to SUPER_ADMIN or SYSTEM_OWNER on backend
    const serverSaPromoteToSA = updateManagedAccountRole(
      { id: SUPER_ADMIN_PRINCIPAL.id, email: SUPER_ADMIN_PRINCIPAL.email, canonicalRole: 'SUPER_ADMIN' },
      serverOwnerCreateStd.account!.uid,
      'SUPER_ADMIN'
    );
    expect(serverSaPromoteToSA.success).toBe(false);

    // SYSTEM_OWNER CAN promote STANDARD_USER to SUPER_ADMIN and later revoke SUPER_ADMIN back to STANDARD_USER
    const serverOwnerPromoteToSA = updateManagedAccountRole(
      { id: SYSTEM_OWNER_PRINCIPAL.id, email: SYSTEM_OWNER_PRINCIPAL.email, canonicalRole: 'SYSTEM_OWNER' },
      serverOwnerCreateStd.account!.uid,
      'SUPER_ADMIN'
    );
    expect(serverOwnerPromoteToSA.success).toBe(true);
    expect(serverOwnerPromoteToSA.account?.canonicalRole).toBe('SUPER_ADMIN');

    // SUPER_ADMIN cannot revoke sessions or disable another SUPER_ADMIN on backend
    const serverSaRevokeSA = revokeManagedAccountSessions(
      { id: SUPER_ADMIN_PRINCIPAL.id, email: SUPER_ADMIN_PRINCIPAL.email, canonicalRole: 'SUPER_ADMIN' },
      serverOwnerCreateStd.account!.uid
    );
    expect(serverSaRevokeSA.success).toBe(false);

    const serverSaDisableSA = updateManagedAccountStatus(
      { id: SUPER_ADMIN_PRINCIPAL.id, email: SUPER_ADMIN_PRINCIPAL.email, canonicalRole: 'SUPER_ADMIN' },
      serverOwnerCreateStd.account!.uid,
      'DISABLED'
    );
    expect(serverSaDisableSA.success).toBe(false);

    // SYSTEM_OWNER revokes SUPER_ADMIN back to STANDARD_USER
    const serverOwnerDemoteSA = updateManagedAccountRole(
      { id: SYSTEM_OWNER_PRINCIPAL.id, email: SYSTEM_OWNER_PRINCIPAL.email, canonicalRole: 'SYSTEM_OWNER' },
      serverOwnerCreateStd.account!.uid,
      'STANDARD_USER'
    );
    expect(serverOwnerDemoteSA.success).toBe(true);
    expect(serverOwnerDemoteSA.account?.canonicalRole).toBe('STANDARD_USER');
  });

  it('5. Enforces one-time System Owner bootstrap safety (initializes once, is idempotent, and refuses replacement or unauthorized duplicate)', () => {
    // 1. Initial one-time bootstrap succeeds when no active SYSTEM_OWNER exists yet
    const initialBootstrap = bootstrapOneTimeSystemOwner({
      email: 'initial.owner@lorin.private',
      displayName: 'Initial System Owner'
    });
    expect(initialBootstrap.success).toBe(true);
    expect(initialBootstrap.account?.canonicalRole).toBe('SYSTEM_OWNER');

    // 2. Re-running bootstrap for the same owner is idempotent
    const idempotentBootstrap = bootstrapOneTimeSystemOwner({
      email: 'initial.owner@lorin.private',
      displayName: 'Initial System Owner'
    });
    expect(idempotentBootstrap.success).toBe(true);
    expect(idempotentBootstrap.alreadyBootstrapped).toBe(true);

    // 3. Attempting to bootstrap a different email when an active SYSTEM_OWNER already exists is strictly refused
    const duplicateAttempt = bootstrapOneTimeSystemOwner({
      email: 'attacker.replacement@lorin.private',
      displayName: 'Unauthorized Replacement'
    });
    expect(duplicateAttempt.success).toBe(false);
    expect(duplicateAttempt.alreadyBootstrapped).toBe(true);
    expect(duplicateAttempt.message).toContain('Bootstrap refused');
  });

  it('6. Validates Firebase Storage ownership paths, MIME types, file sizes, and blocks cross-user or executable uploads', () => {
    const knowledgePath = buildUserStoragePath('uid_std_user_a', 'knowledge', 'doc_101');
    const attachmentPath = buildUserStoragePath('uid_std_user_a', 'attachments', 'att_202', {
      conversationId: 'conv_55'
    });
    const imagePath = buildUserStoragePath('uid_std_user_a', 'images', 'img_303');

    expect(knowledgePath).toBe('users/uid_std_user_a/knowledge/doc_101/original');
    expect(attachmentPath).toBe('users/uid_std_user_a/attachments/conv_55/att_202');
    expect(imagePath).toBe('users/uid_std_user_a/images/img_303');

    // Valid own upload
    const validRes = validateStorageUpload({
      uid: 'uid_std_user_a',
      activeUid: 'uid_std_user_a',
      fileName: 'architecture.md',
      mimeType: 'text/markdown',
      sizeBytes: 4096,
      storagePath: knowledgePath
    });
    expect(validRes.valid).toBe(true);

    // Cross-user upload by standard user -> blocked
    const crossUserRes = validateStorageUpload({
      uid: 'uid_std_user_b',
      activeUid: 'uid_std_user_a',
      isPrivileged: false,
      fileName: 'notes.md',
      mimeType: 'text/markdown',
      sizeBytes: 1024,
      storagePath: 'users/uid_std_user_b/knowledge/doc_1/original'
    });
    expect(crossUserRes.valid).toBe(false);
    expect(crossUserRes.reason).toContain('Cross-user');

    // Executable file extension -> blocked
    const executableRes = validateStorageUpload({
      uid: 'uid_std_user_a',
      activeUid: 'uid_std_user_a',
      fileName: 'payload.exe',
      mimeType: 'application/pdf',
      sizeBytes: 1024,
      storagePath: knowledgePath
    });
    expect(executableRes.valid).toBe(false);
    expect(executableRes.reason).toContain('Executable');

    // Oversized file (>25MB) -> blocked
    const oversizedRes = validateStorageUpload({
      uid: 'uid_std_user_a',
      activeUid: 'uid_std_user_a',
      fileName: 'huge.pdf',
      mimeType: 'application/pdf',
      sizeBytes: MAX_STORAGE_FILE_SIZE_BYTES + 1024,
      storagePath: knowledgePath
    });
    expect(oversizedRes.valid).toBe(false);
    expect(oversizedRes.reason).toContain('File size');
  });

  it('7. Immediately blocks DISABLED, REVOKED, or session-revoked accounts in assertActiveAccount', () => {
    const disabledUser: Principal = {
      ...STANDARD_USER_A,
      accountStatus: 'DISABLED'
    };
    expect(() => assertActiveAccount(disabledUser)).toThrow(/DISABLED/);

    const revokedSessionUser: Principal = {
      ...STANDARD_USER_A,
      enrolledAt: Date.now() - 60_000,
      sessionRevokedAt: Date.now() - 5_000
    };
    expect(() => assertActiveAccount(revokedSessionUser)).toThrow(/revoked/);
  });
});
