import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckCircle2,
  Circle,
  Plus,
  Target,
  Trash2,
  Link2,
  Sparkles
} from 'lucide-react';
import { DailyEngineeringGoal, DurableTaskRecord, Principal } from '../types/lorin';
import { MAX_DAILY_GOALS, TaskQueueService } from '../services/taskQueueService';
import { ProjectStore } from '../services/projectStore';

interface DailyGoalsTrackerProps {
  principal: Principal;
  activeProjectId: string;
  onGoalsChanged?: (message?: string) => void;
}

export const DailyGoalsTracker: React.FC<DailyGoalsTrackerProps> = ({
  principal,
  activeProjectId,
  onGoalsChanged
}) => {
  const [goals, setGoals] = useState<DailyEngineeringGoal[]>([]);
  const [tasksById, setTasksById] = useState<Record<string, DurableTaskRecord>>({});
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState<string>(activeProjectId || 'proj_lorin_core');
  const [statusFeedback, setStatusFeedback] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const projects = ProjectStore.getProjects();
  const todayDateKey = TaskQueueService.getTodayDateKey();

  const loadSyncedState = useCallback(() => {
    TaskQueueService.setActiveUser(principal.id);
    const todayGoals = TaskQueueService.getDailyGoals(undefined, todayDateKey);
    const allTasks = TaskQueueService.getTasks();
    const map: Record<string, DurableTaskRecord> = {};
    for (const t of allTasks) {
      map[t.id] = t;
    }
    setGoals(todayGoals);
    setTasksById(map);
  }, [principal.id, todayDateKey]);

  useEffect(() => {
    if (activeProjectId && activeProjectId !== 'ALL') {
      setSelectedProjectId(activeProjectId);
    }
  }, [activeProjectId]);

  useEffect(() => {
    loadSyncedState();
    const unsubscribe = TaskQueueService.subscribe(() => {
      loadSyncedState();
    });
    return () => unsubscribe();
  }, [loadSyncedState]);

  const showTransientFeedback = (msg: string) => {
    setStatusFeedback(msg);
    setTimeout(() => {
      setStatusFeedback((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalTitle.trim() || goals.length >= MAX_DAILY_GOALS) return;

    const res = TaskQueueService.addDailyGoal(
      newGoalTitle,
      selectedProjectId || activeProjectId || 'proj_lorin_core',
      principal
    );
    showTransientFeedback(res.message);
    if (res.success) {
      setNewGoalTitle('');
      loadSyncedState();
      if (onGoalsChanged) onGoalsChanged(res.message);
    }
  };

  const handleToggleGoal = async (goalId: string) => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    try {
      const res = await TaskQueueService.toggleDailyGoalCompleted(goalId, principal);
      showTransientFeedback(res.message);
      loadSyncedState();
      if (onGoalsChanged) onGoalsChanged(res.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRemoveGoal = (goalId: string) => {
    const res = TaskQueueService.removeDailyGoal(goalId, principal);
    showTransientFeedback(res.message);
    if (res.success) {
      loadSyncedState();
      if (onGoalsChanged) onGoalsChanged(res.message);
    }
  };

  const completedCount = goals.filter((g) => g.status === 'completed').length;
  const totalDefined = goals.length;
  const remainingSlots = Math.max(0, MAX_DAILY_GOALS - totalDefined);
  const progressPct = Math.round((completedCount / MAX_DAILY_GOALS) * 100);
  const isDailyLimitReached = totalDefined >= MAX_DAILY_GOALS;

  return (
    <section
      aria-label="Daily Engineering Goals Tracker"
      className="rounded-xl bg-[#111821] border border-[#283544] p-4 sm:p-5 space-y-4"
    >
      {/* Top Row: Title, Date & Tabular Progress Summary */}
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#283544] pb-3.5">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-[#66E3CB] shrink-0" />
            <h2 className="text-sm font-bold text-white tracking-tight">
              Daily Engineering Goals Tracker
            </h2>
          </div>
          <p className="text-xs text-[#A2AFBF]">
            Define and complete up to {MAX_DAILY_GOALS} focused development tasks for today · Synced bidirectionally with TaskQueueService
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono tabular-nums">
          <div className="text-right">
            <div className="text-[#F1F5F9] font-bold">
              {completedCount} / {MAX_DAILY_GOALS} COMPLETED ({progressPct}%)
            </div>
            <div className="text-[11px] text-[#738297]">
              Date: {todayDateKey} · {remainingSlots} {remainingSlots === 1 ? 'slot' : 'slots'} remaining
            </div>
          </div>
        </div>
      </div>

      {/* 5-Slot Segmented Progress Bar */}
      <div className="space-y-1.5">
        <div className="grid grid-cols-5 gap-1.5 h-2">
          {Array.from({ length: MAX_DAILY_GOALS }).map((_, slotIdx) => {
            const goalAtSlot = goals[slotIdx];
            const isCompleted = goalAtSlot?.status === 'completed';
            const isDefined = Boolean(goalAtSlot);

            return (
              <div
                key={slotIdx}
                className="h-full rounded-sm bg-[#0B0F14] border border-[#283544] overflow-hidden relative"
                title={
                  goalAtSlot
                    ? `Slot ${slotIdx + 1}: ${goalAtSlot.title} (${goalAtSlot.status})`
                    : `Slot ${slotIdx + 1}: Available`
                }
              >
                <motion.div
                  initial={false}
                  animate={{
                    width: isCompleted ? '100%' : isDefined ? '35%' : '0%',
                    backgroundColor: isCompleted
                      ? '#10B981'
                      : isDefined
                      ? '#66E3CB'
                      : '#17212C'
                  }}
                  transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                  className="h-full"
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Daily Goal Input Form */}
      <form onSubmit={handleAddGoal} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
        <input
          type="text"
          value={newGoalTitle}
          onChange={(e) => setNewGoalTitle(e.target.value)}
          disabled={isDailyLimitReached || principal.role === 'GUEST'}
          placeholder={
            isDailyLimitReached
              ? `Daily cap of ${MAX_DAILY_GOALS} tasks reached — complete or remove a goal to free a slot`
              : 'Define a small development task for today (e.g. Add unit test for OAuth token refresh)...'
          }
          className="flex-1 bg-[#0B0F14] border border-[#283544] focus:border-[#66E3CB] rounded-lg px-3 py-2 text-xs text-white placeholder-[#738297] focus:outline-none disabled:opacity-50"
        />

        <select
          value={selectedProjectId}
          onChange={(e) => setSelectedProjectId(e.target.value)}
          disabled={isDailyLimitReached || principal.role === 'GUEST'}
          aria-label="Target project for daily goal"
          className="bg-[#0B0F14] border border-[#283544] rounded-lg px-2.5 py-2 text-xs font-mono text-[#A2AFBF] focus:outline-none focus:border-[#66E3CB] disabled:opacity-50"
        >
          {projects.map((p) => (
            <option key={p.id} value={p.id}>
              {p.slug}
            </option>
          ))}
        </select>

        <button
          type="submit"
          disabled={
            isDailyLimitReached ||
            !newGoalTitle.trim() ||
            principal.role === 'GUEST'
          }
          className="px-3.5 py-2 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] disabled:opacity-40 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Daily Goal ({totalDefined}/{MAX_DAILY_GOALS})</span>
        </button>
      </form>

      {/* Status Notice */}
      <AnimatePresence>
        {statusFeedback && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            className="text-[11px] font-mono text-[#66E3CB] flex items-center justify-between bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-1.5"
          >
            <span>{statusFeedback}</span>
            <button
              type="button"
              onClick={() => setStatusFeedback(null)}
              className="text-[#738297] hover:text-white ml-2 cursor-pointer"
            >
              ✕
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Daily Goals List */}
      <div className="divide-y divide-[#283544] border-t border-[#283544]">
        {goals.length === 0 ? (
          <div className="py-6 text-center text-xs text-[#738297] font-mono">
            No daily engineering goals defined for {todayDateKey}. Add up to {MAX_DAILY_GOALS} tasks above to sync with TaskQueueService.
          </div>
        ) : (
          <AnimatePresence initial={false}>
            {goals.map((goal, index) => {
              const isCompleted = goal.status === 'completed';
              const linkedTask = goal.linkedTaskId ? tasksById[goal.linkedTaskId] : undefined;
              const proj = projects.find((p) => p.id === goal.projectId);

              return (
                <motion.div
                  key={goal.id}
                  layout
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  transition={{ duration: 0.18 }}
                  className="py-2.5 flex items-center justify-between gap-3 group"
                >
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <button
                      type="button"
                      onClick={() => handleToggleGoal(goal.id)}
                      disabled={isSubmitting || principal.role === 'GUEST'}
                      aria-label={
                        isCompleted
                          ? `Mark "${goal.title}" as pending`
                          : `Mark "${goal.title}" as completed`
                      }
                      className="mt-0.5 text-[#A2AFBF] hover:text-[#66E3CB] disabled:opacity-50 cursor-pointer shrink-0 transition-colors"
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Circle className="w-4 h-4 text-[#738297] group-hover:text-[#66E3CB]" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11px] font-mono tabular-nums text-[#738297]">
                          0{index + 1}.
                        </span>
                        <span
                          className={`text-xs font-medium transition-colors ${
                            isCompleted
                              ? 'line-through text-[#738297]'
                              : 'text-[#F1F5F9]'
                          }`}
                        >
                          {goal.title}
                        </span>
                      </div>

                      {/* Unboxed Metadata Trail with middle-dot separators */}
                      <div className="text-[11px] font-mono tabular-nums text-[#738297] mt-0.5 flex flex-wrap items-center gap-1.5">
                        <span>Status: <strong className={isCompleted ? 'text-emerald-400' : 'text-amber-300'}>{goal.status}</strong></span>
                        <span>·</span>
                        <span>Project: {proj ? proj.slug : goal.projectId}</span>
                        {linkedTask && (
                          <>
                            <span>·</span>
                            <span className="inline-flex items-center gap-1 text-[#A2AFBF]">
                              <Link2 className="w-3 h-3 text-[#66E3CB]" />
                              TaskQueue [{linkedTask.state}]
                            </span>
                          </>
                        )}
                        {goal.completedAt && (
                          <>
                            <span>·</span>
                            <span>
                              Completed {new Date(goal.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleToggleGoal(goal.id)}
                      disabled={isSubmitting || principal.role === 'GUEST'}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-mono cursor-pointer transition-colors whitespace-nowrap ${
                        isCompleted
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/25'
                          : 'bg-[#17212C] text-[#66E3CB] border border-[#3A4B5F] hover:bg-[#283544]'
                      }`}
                    >
                      {isCompleted ? 'Completed ✓' : 'Mark Completed'}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleRemoveGoal(goal.id)}
                      disabled={principal.role === 'GUEST'}
                      title="Remove daily goal slot"
                      aria-label={`Remove daily goal ${goal.title}`}
                      className="p-1.5 rounded-lg text-[#738297] hover:text-rose-400 hover:bg-rose-950/30 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}
      </div>

      {/* Completion Banner when all 5 daily goals are completed */}
      {completedCount === MAX_DAILY_GOALS && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="pt-2 flex items-center gap-2 text-xs font-mono text-emerald-400"
        >
          <Sparkles className="w-4 h-4 shrink-0" />
          <span>All {MAX_DAILY_GOALS}/{MAX_DAILY_GOALS} daily engineering goals completed and verified in TaskQueueService.</span>
        </motion.div>
      )}
    </section>
  );
};
