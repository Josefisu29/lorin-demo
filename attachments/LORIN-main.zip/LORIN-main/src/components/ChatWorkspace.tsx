import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Paperclip, 
  Mic, 
  MicOff,
  Video, 
  Sparkles, 
  Copy, 
  Check, 
  RefreshCw, 
  ShieldAlert, 
  FileCheck, 
  CornerDownRight, 
  AlertTriangle, 
  ArrowRight,
  BookOpen,
  X,
  FileText,
  Pin,
  PinOff,
  ChevronDown,
  ChevronUp,
  Bookmark,
  Archive,
  ArchiveRestore,
  Search,
  Filter,
  Terminal,
  FolderKanban,
  Cpu,
  Square,
  Edit3,
  RotateCcw,
  Sliders,
  Wifi,
  WifiOff,
  ShieldCheck,
  Volume2,
  Gauge,
  Activity,
  Headphones
} from 'lucide-react';
import { SPECIALISTS, formatPrivateModelLabel } from '../data/specialists';
import {
  ActionRequest,
  ApprovalRecord,
  AssistantRuntimeState,
  AutonomyLevel,
  ChatMessage,
  ConversationSession,
  ExtendedSpecialistName,
  LearningSkillTier,
  LorinCompletionReport,
  LorinOperatingMode,
  LorinPersonality,
  LorinProfileConfig,
  LorinVoiceProfile,
  Principal,
  ProjectRecord,
  SpecialistRole
} from '../types/lorin';
import { RoutingStrategy, DualModelRouter } from '../services/modelBackend';
import { MemoryStore } from '../services/memoryStore';
import { OfflineIntelligenceService } from '../services/offlineIntelligenceService';
import { ProjectStore } from '../services/projectStore';
import {
  LORIN_AUTONOMY_LEVELS,
  LORIN_OPERATING_MODES,
  LORIN_PERSONALITIES,
  LORIN_VOICE_PROFILES
} from '../services/lorinProfileService';
import {
  CommunicationDiagnosticsSnapshot,
  CommunicationManager
} from '../services/communicationManager';
import { AudioService } from '../services/audioService';
import { WorkflowStatusIndicator } from './WorkflowStatusIndicator';
import { PinnedMessageTray } from './PinnedMessageTray';
import { PWAInstallButton } from './PWAInstallButton';
import { ContextInspectorPanel } from './ContextInspectorPanel';
import { LorinCharacter } from './LorinCharacter';
import { CommunicationDiagnosticsModal } from './CommunicationDiagnosticsModal';

export interface ConversationSummaryData {
  title: string;
  content: string;
  keyTopics: string[];
  decisions: string[];
  timestamp: number;
  modelUsed: string;
  latencyMs?: number;
}

interface ConversationSummaryPanelProps {
  summary: ConversationSummaryData | null;
  isGenerating: boolean;
  onClose: () => void;
  onSaveToMemory: () => void;
  onResummarize: () => void;
  isSaved: boolean;
}

export const ConversationSummaryPanel: React.FC<ConversationSummaryPanelProps> = ({
  summary,
  isGenerating,
  onClose,
  onSaveToMemory,
  onResummarize,
  isSaved
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (!summary) return;
    const textToCopy = `# ${summary.title}\n\n${summary.content}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -12, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -12, scale: 0.98 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      className="relative mb-6 overflow-hidden rounded-2xl border border-[#66E3CB]/40 bg-[#111821]/90 backdrop-blur-xl p-5 sm:p-6 shadow-[0_12px_40px_rgba(0,0,0,0.5)] transition-all"
    >
      {/* Top ambient glowing accent line */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-[#66E3CB] via-[#A9B8FF] to-[#66E3CB] opacity-80" />

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-3 border-b border-[#283544]">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center w-8 h-8 rounded-xl bg-[#66E3CB]/15 border border-[#66E3CB]/40 text-[#66E3CB] shadow-sm">
            <Sparkles className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white tracking-tight">AI Conversation Summary</h3>
              {summary && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#17212C] text-[#66E3CB] border border-[#283544]">
                  {summary.modelUsed} {summary.latencyMs ? `· ${summary.latencyMs}ms` : ''}
                </span>
              )}
            </div>
            <p className="text-[11px] font-mono text-[#A2AFBF]">High-level synthesis & memory extraction</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {summary && !isGenerating && (
            <button
              type="button"
              onClick={onSaveToMemory}
              disabled={isSaved}
              className={`px-3 py-1.5 rounded-xl font-mono text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                isSaved
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default'
                  : 'bg-gradient-to-r from-[#66E3CB] to-[#52d6be] hover:from-[#52d6be] hover:to-[#3ecbb3] text-slate-950 shadow-[0_0_15px_rgba(102,227,203,0.3)]'
              }`}
            >
              {isSaved ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Saved to Memory</span>
                </>
              ) : (
                <>
                  <Bookmark className="w-3.5 h-3.5" />
                  <span>Save to Memory</span>
                </>
              )}
            </button>
          )}

          <button
            type="button"
            onClick={onResummarize}
            disabled={isGenerating}
            className="p-1.5 rounded-lg bg-[#17212C] hover:bg-[#1E2C3A] text-[#738297] hover:text-white border border-[#283544] transition-colors cursor-pointer disabled:opacity-40"
            title="Re-generate summary"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin text-[#66E3CB]' : ''}`} />
          </button>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#17212C] hover:bg-[#1E2C3A] text-[#738297] hover:text-white border border-[#283544] transition-colors cursor-pointer"
            title="Close summary panel"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Loading Skeleton / Content Body */}
      {isGenerating ? (
        <div className="py-6 space-y-3 text-center">
          <div className="flex items-center justify-center gap-2 text-xs font-mono text-[#66E3CB] animate-pulse">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>Analyzing thread messages & extracting memory invariants...</span>
          </div>
          <div className="w-2/3 h-2 mx-auto rounded bg-[#17212C] animate-pulse" />
          <div className="w-1/2 h-2 mx-auto rounded bg-[#17212C] animate-pulse" />
        </div>
      ) : summary ? (
        <div className="space-y-4">
          <div className="font-semibold text-white text-sm">
            {summary.title}
          </div>

          <div className="max-h-64 overflow-y-auto pr-2 text-xs text-[#E2E8F0] leading-relaxed font-sans space-y-2">
            {renderFormattedContent(summary.content, 'summary_panel')}
          </div>

          {/* Key Topics & Decisions Tags */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3 border-t border-[#283544]/60 font-mono text-[11px]">
            {summary.keyTopics && summary.keyTopics.length > 0 && (
              <div className="space-y-1">
                <span className="text-[#A2AFBF] font-bold text-[10px] uppercase tracking-wider">Key Topics Covered:</span>
                <div className="flex flex-wrap gap-1">
                  {summary.keyTopics.map((topic, i) => (
                    <span key={i} className="text-[#66E3CB] bg-[#17212C] px-2 py-0.5 rounded border border-[#283544]">
                      {topic}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {summary.decisions && summary.decisions.length > 0 && (
              <div className="space-y-1">
                <span className="text-[#A2AFBF] font-bold text-[10px] uppercase tracking-wider">Decisions / Next Steps:</span>
                <div className="flex flex-wrap gap-1">
                  {summary.decisions.map((dec, i) => (
                    <span key={i} className="text-[#A9B8FF] bg-[#17212C] px-2 py-0.5 rounded border border-[#283544]">
                      {dec}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Bottom Bar */}
          <div className="flex items-center justify-between pt-2 border-t border-[#283544]/60 text-[11px] font-mono text-[#738297]">
            <span>Generated {new Date(summary.timestamp).toLocaleTimeString()}</span>
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 text-[#66E3CB] hover:text-white transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard' : 'Copy Summary'}</span>
            </button>
          </div>
        </div>
      ) : null}
    </motion.div>
  );
};

interface ChatWorkspaceProps {
  principal: Principal;
  messages: ChatMessage[];
  pinnedMessages: ChatMessage[];
  onTogglePinMessage: (messageId: string) => void;
  onToggleArchiveMessage?: (messageId: string) => void;
  onSendMessage: (text: string, attachedFile?: { name: string; size: number; type: string; content?: string }) => Promise<LorinCompletionReport>;
  onCancelRequest?: () => void;
  onEditAndResend?: (messageId: string, newContent: string) => void;
  onRegenerateResponse?: (assistantMessageId: string) => void;
  isLoading: boolean;
  currentReport: LorinCompletionReport | null;
  onOpenVoice: () => void;
  onOpenVideo: () => void;
  onRefreshApprovals: () => void;
  pendingApprovals: ApprovalRecord[];
  onOpenArchivedModal?: () => void;
  onOpenSearch?: () => void;
  archivedCount?: number;
  activeProjectId?: string;
  onSelectProject?: (projectId: string) => void;
  backendMode?: RoutingStrategy;
  onSelectBackendMode?: (mode: RoutingStrategy) => void;
  requestedModel?: string;
  onSelectRequestedModel?: (model: string) => void;
  profileConfig?: LorinProfileConfig;
  onUpdateProfileConfig?: (partial: Partial<LorinProfileConfig>) => void;
  onOpenModeAndAccessModal?: (tab?: 'persona' | 'levels' | 'access_runtime') => void;
  onToggleOnlineOffline?: () => void;
  activeConversation?: ConversationSession;
  onNewConversation?: () => void;
  onDraftChange?: (draft: string) => void;
}

const PROMPT_SUGGESTIONS = [
  "Help me understand a topic",
  "Review this code and suggest improvements",
  "Help me plan a project",
  "Summarize notes or a document"
];

/**
 * Validates that a Markdown link URL uses safe http:// or https:// protocol only.
 */
const isSafeExternalUrl = (url: string): boolean => {
  try {
    const parsed = new URL(url.trim());
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
};

const formatInlineText = (text: string) => {
  const tokenRegex = /(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g;
  const parts = text.split(tokenRegex);
  return parts.map((part, idx) => {
    if (part.startsWith('`') && part.endsWith('`')) {
      return (
        <code key={idx} className="font-mono text-[#66E3CB] bg-[#070A0F] px-1.5 py-0.5 rounded border border-[#283544] text-[11px]">
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={idx} className="font-semibold text-white">
          {part.slice(2, -2)}
        </strong>
      );
    }
    const linkMatch = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (linkMatch) {
      const [, label, href] = linkMatch;
      if (isSafeExternalUrl(href)) {
        return (
          <a
            key={idx}
            href={href.trim()}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#66E3CB] underline underline-offset-2 hover:text-white transition-colors"
          >
            {label}
          </a>
        );
      }
      return <span key={idx} className="text-zinc-300">{label}</span>;
    }
    return part;
  });
};

const CodeBlock: React.FC<{ code: string; language?: string; msgId: string; index: number }> = ({ code, language, msgId, index }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-[#283544] bg-[#070A0F] font-mono text-[11px] shadow-sm">
      <div className="px-3.5 py-1.5 bg-[#0E1520] border-b border-[#283544] flex items-center justify-between text-[#A2AFBF]">
        <span className="text-[10px] uppercase font-bold text-[#66E3CB] tracking-wider">{language || 'code'}</span>
        <button
          type="button"
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-[10px] text-[#A2AFBF] hover:text-white transition-colors cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-3 h-3 text-emerald-400" />
              <span className="text-emerald-400 font-bold">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3" />
              <span>Copy code</span>
            </>
          )}
        </button>
      </div>
      <div className="p-3.5 overflow-x-auto text-[#E2E8F0] leading-relaxed whitespace-pre font-mono">
        {code}
      </div>
    </div>
  );
};

type ContentPart = 
  | { type: 'code'; code: string; language: string }
  | { type: 'text'; text: string };

const renderFormattedContent = (content: string, msgId: string) => {
  if (!content) return null;

  // Support both closed code blocks and streaming unclosed code blocks
  const normalizedContent = (() => {
    const fenceCount = (content.match(/```/g) || []).length;
    return fenceCount % 2 === 1 ? `${content}\n\`\`\`` : content;
  })();

  const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
  const parts: ContentPart[] = [];
  let lastIndex = 0;
  let match;

  while ((match = codeBlockRegex.exec(normalizedContent)) !== null) {
    if (match.index > lastIndex) {
      parts.push({ type: 'text', text: normalizedContent.slice(lastIndex, match.index) });
    }
    parts.push({
      type: 'code',
      language: match[1] || 'text',
      code: match[2].trim()
    });
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < normalizedContent.length) {
    parts.push({ type: 'text', text: normalizedContent.slice(lastIndex) });
  }

  return (
    <div className="space-y-3 text-sm text-[#E2E8F0] leading-7 select-text">
      {parts.map((part, pIdx) => {
        if (part.type === 'code') {
          return (
            <CodeBlock
              key={`${msgId}-code-${pIdx}`}
              code={part.code}
              language={part.language}
              msgId={msgId}
              index={pIdx}
            />
          );
        }

        const lines = part.text.split('\n');
        const renderedBlocks: React.ReactNode[] = [];
        let lIdx = 0;

        while (lIdx < lines.length) {
          const line = lines[lIdx];
          const trimmed = line.trim();

          if (!trimmed) {
            renderedBlocks.push(<div key={lIdx} className="h-1.5" />);
            lIdx++;
            continue;
          }

          // Markdown Table detection
          if (trimmed.startsWith('|') && trimmed.endsWith('|') && lIdx + 1 < lines.length && lines[lIdx + 1].trim().startsWith('|')) {
            const tableLines: string[] = [];
            while (lIdx < lines.length && lines[lIdx].trim().startsWith('|')) {
              tableLines.push(lines[lIdx].trim());
              lIdx++;
            }
            const rows = tableLines
              .filter(r => !/^\|[\s\-:|]+\|$/.test(r))
              .map(r => r.slice(1, -1).split('|').map(c => c.trim()));
            if (rows.length > 0) {
              const headerRow = rows[0];
              const bodyRows = rows.slice(1);
              renderedBlocks.push(
                <div key={`table-${lIdx}`} className="my-2 overflow-x-auto rounded-xl border border-[#283544] bg-[#0B0F14]">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-[#283544] bg-[#111821] text-[#66E3CB]">
                        {headerRow.map((cell, cIdx) => (
                          <th key={cIdx} className="px-3 py-2 font-semibold">{formatInlineText(cell)}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#283544]/60">
                      {bodyRows.map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-[#17212C]/40">
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className="px-3 py-2 text-[#E2E8F0]">{formatInlineText(cell)}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              );
              continue;
            }
          }

          if (trimmed.startsWith('> ')) {
            renderedBlocks.push(
              <blockquote
                key={lIdx}
                className="pl-3.5 py-1 my-1 border-l-2 border-[#66E3CB] bg-[#111821]/60 rounded-r-lg text-xs text-[#CBD5E1] italic"
              >
                {formatInlineText(trimmed.slice(2))}
              </blockquote>
            );
            lIdx++;
            continue;
          }

          if (trimmed.startsWith('### ')) {
            renderedBlocks.push(
              <h4 key={lIdx} className="text-xs font-bold text-white pt-2 pb-0.5 border-b border-[#283544]/60 tracking-tight">
                {formatInlineText(trimmed.slice(4))}
              </h4>
            );
            lIdx++;
            continue;
          }
          if (trimmed.startsWith('## ')) {
            renderedBlocks.push(
              <h3 key={lIdx} className="text-sm font-bold text-white pt-2.5 pb-1 border-b border-[#283544] tracking-tight">
                {formatInlineText(trimmed.slice(3))}
              </h3>
            );
            lIdx++;
            continue;
          }
          if (trimmed.startsWith('# ')) {
            renderedBlocks.push(
              <h2 key={lIdx} className="text-base font-bold text-white pt-3 pb-1 tracking-tight">
                {formatInlineText(trimmed.slice(2))}
              </h2>
            );
            lIdx++;
            continue;
          }

          if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
            renderedBlocks.push(
              <div key={lIdx} className="flex items-start gap-2 pl-1 py-0.5">
                <span className="text-[#66E3CB] font-mono text-[10px] mt-0.5 shrink-0">▪</span>
                <span className="flex-1 text-[#E2E8F0] leading-relaxed">
                  {formatInlineText(trimmed.slice(2))}
                </span>
              </div>
            );
            lIdx++;
            continue;
          }

          const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
          if (numMatch) {
            renderedBlocks.push(
              <div key={lIdx} className="flex items-start gap-2 pl-1 py-0.5">
                <span className="text-[#66E3CB] font-mono text-[11px] font-bold shrink-0">{numMatch[1]}.</span>
                <span className="flex-1 text-[#E2E8F0] leading-relaxed">
                  {formatInlineText(numMatch[2])}
                </span>
              </div>
            );
            lIdx++;
            continue;
          }

          renderedBlocks.push(
            <p key={lIdx} className="leading-relaxed text-[#E2E8F0]">
              {formatInlineText(line)}
            </p>
          );
          lIdx++;
        }

        return (
          <div key={`${msgId}-text-${pIdx}`} className="space-y-1.5">
            {renderedBlocks}
          </div>
        );
      })}
    </div>
  );
};

export const ChatWorkspace: React.FC<ChatWorkspaceProps> = ({
  principal,
  messages,
  pinnedMessages,
  onTogglePinMessage,
  onToggleArchiveMessage,
  onSendMessage,
  onCancelRequest,
  onEditAndResend,
  onRegenerateResponse,
  isLoading,
  currentReport,
  onOpenVoice,
  onOpenVideo,
  onRefreshApprovals,
  pendingApprovals,
  onOpenArchivedModal,
  onOpenSearch,
  archivedCount = 0,
  activeProjectId = 'proj_lorin_core',
  onSelectProject,
  backendMode = 'CLOUD_INTELLIGENCE_ROUTER',
  onSelectBackendMode,
  requestedModel = 'deepseek-v4-flash',
  onSelectRequestedModel,
  profileConfig,
  onUpdateProfileConfig,
  onOpenModeAndAccessModal,
  onToggleOnlineOffline,
  activeConversation,
  onNewConversation,
  onDraftChange
}) => {
  const [inputText, setInputText] = useState(activeConversation?.draftText || '');
  const [attachedFile, setAttachedFile] = useState<{ name: string; size: number; type: string; content?: string } | null>(null);
  const [attachmentError, setAttachmentError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedSpecialistLens, setSelectedSpecialistLens] = useState<'ALL' | SpecialistRole>('ALL');
  const [pinToast, setPinToast] = useState<string | null>(null);
  const [archiveToast, setArchiveToast] = useState<string | null>(null);
  const [hideArchivedInFeed, setHideArchivedInFeed] = useState(true);
  const [expandedArchivedIds, setExpandedArchivedIds] = useState<Set<string>>(new Set());

  // Edit user message inline state
  const [editingMsgId, setEditingMsgId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');

  // Context Inspector & Communication Diagnostics State
  const [isInspectorOpen, setIsInspectorOpen] = useState(false);
  const [activeInspectorMessage, setActiveInspectorMessage] = useState<ChatMessage | null>(null);
  const [showHologramDock, setShowHologramDock] = useState(false);
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);

  // Mode A — Inline Composer Dictation State
  const [isDictating, setIsDictating] = useState(false);
  const [dictationMode, setDictationMode] = useState<'web_speech' | 'cloud_clip'>('web_speech');
  const [dictationStatus, setDictationStatus] = useState<string | null>(null);

  // Centralized Communication State Snapshot
  const [commSnapshot, setCommSnapshot] = useState<CommunicationDiagnosticsSnapshot>(() =>
    CommunicationManager.getSnapshot()
  );

  const [ollamaCloudConfigured, setOllamaCloudConfigured] = useState<boolean | null>(null);

  const projects = ProjectStore.getProjects();
  const activeProject: ProjectRecord = projects.find(p => p.id === activeProjectId) || projects[0];

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const followMessagesRef = useRef(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const unsubscribe = CommunicationManager.subscribe(setCommSnapshot);
    return unsubscribe;
  }, []);

  useEffect(() => {
    fetch('/api/providers/status')
      .then(res => (res.ok ? res.json() : null))
      .then(data => {
        if (data && typeof data.ollamaCloudConfigured === 'boolean') {
          setOllamaCloudConfigured(data.ollamaCloudConfigured);
        } else if (data?.providers?.OLLAMA_CLOUD) {
          setOllamaCloudConfigured(Boolean(data.providers.OLLAMA_CLOUD.configured));
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (followMessagesRef.current) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'auto', block: 'end' });
    }
  }, [messages, isLoading]);

  // Restore saved draft when switching active conversation
  useEffect(() => {
    setInputText(activeConversation?.draftText || '');
    followMessagesRef.current = true;
  }, [activeConversation?.id]);

  // Global Keyboard Shortcuts (⌘I for Inspector, Alt+V for quick Voice)
  useEffect(() => {
    const handleGlobalShortcuts = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'i') {
        e.preventDefault();
        setIsInspectorOpen(prev => !prev);
      }
      if (e.altKey && e.key.toLowerCase() === 'v') {
        e.preventDefault();
        onOpenVoice();
      }
    };
    window.addEventListener('keydown', handleGlobalShortcuts);
    return () => window.removeEventListener('keydown', handleGlobalShortcuts);
  }, [onOpenVoice]);

  // Mode A — Dictation toggle handler directly inside the Chat Composer
  const handleToggleDictation = async () => {
    if (isDictating) {
      if (dictationMode === 'cloud_clip') {
        setDictationStatus('Converting speech to text…');
        const res = await AudioService.stopClipAndTranscribe();
        setIsDictating(false);
        if (res.success && res.transcript) {
          const nextVal = inputText.trim() ? `${inputText.trim()} ${res.transcript}` : res.transcript;
          setInputText(nextVal);
          if (onDraftChange) onDraftChange(nextVal);
          setDictationStatus('Transcript ready — review and press Send');
          setTimeout(() => setDictationStatus(null), 4000);
          textareaRef.current?.focus();
        } else {
          setDictationStatus(res.error || 'No speech detected in clip.');
          setTimeout(() => setDictationStatus(null), 4500);
        }
      } else {
        AudioService.stopSpeechRecognition();
        setIsDictating(false);
        CommunicationManager.transition('transcript_ready', 'Dictation stopped — review text in composer');
        setDictationStatus('Transcript ready — review and press Send');
        setTimeout(() => setDictationStatus(null), 3500);
        textareaRef.current?.focus();
      }
      return;
    }

    // Start Dictation: prefer Web Speech API if supported, otherwise automatically use Cloud MediaRecorder clip
    if (AudioService.isSpeechRecognitionSupported()) {
      const baseText = inputText.trim();
      const started = AudioService.startSpeechRecognition(
        (transcript, isFinal) => {
          const combined = baseText ? `${baseText} ${transcript}` : transcript;
          setInputText(combined);
          if (onDraftChange) onDraftChange(combined);
          setDictationStatus(isFinal ? 'Transcript ready — keep speaking or click Stop Dictation' : 'Receiving your voice…');
        },
        async (errMsg) => {
          // Automatic fallback to Cloud Audio Clip recording if browser Web Speech API errors
          AudioService.stopSpeechRecognition();
          if (AudioService.isMediaRecorderSupported()) {
            const clipRes = await AudioService.startClipRecording();
            if (clipRes.success) {
              setDictationMode('cloud_clip');
              setIsDictating(true);
              setDictationStatus('Recording voice clip (Cloud Transcribe Fallback) — click again when done');
              return;
            }
          }
          setIsDictating(false);
          setDictationStatus(errMsg);
          setTimeout(() => setDictationStatus(null), 5000);
        }
      );
      if (started) {
        setDictationMode('web_speech');
        setIsDictating(true);
        setDictationStatus('Listening to you — speak now (dictated text stays in composer for review)');
        return;
      }
    }

    // Fallback: Cloud MediaRecorder Clip Transcription
    const clipStart = await AudioService.startClipRecording();
    if (clipStart.success) {
      setDictationMode('cloud_clip');
      setIsDictating(true);
      setDictationStatus('Recording voice clip — speak now, then click Finish Dictation to transcribe');
    } else {
      setDictationStatus(clipStart.error || 'Microphone unavailable for dictation.');
      setTimeout(() => setDictationStatus(null), 5000);
    }
  };

  const handleToggleSpeakMessage = (msg: ChatMessage) => {
    if (speakingMsgId === msg.id) {
      AudioService.stopSpeaking();
      setSpeakingMsgId(null);
      CommunicationManager.transition('idle', 'Speech stopped');
      return;
    }
    setSpeakingMsgId(msg.id);
    AudioService.speakWithNeuralOption(msg.content, () => {
      setSpeakingMsgId(null);
    });
  };

  // Compute truthful Assistant Runtime State
  const assistantState: AssistantRuntimeState = (() => {
    if (pendingApprovals.length > 0) return 'WAITING_FOR_APPROVAL';
    if (isLoading) return 'PROCESSING';
    return 'IDLE';
  })();

  const getRuntimeStateBadge = (state: AssistantRuntimeState) => {
    if (commSnapshot.currentState === 'error' || commSnapshot.currentState === 'permission_required') {
      return {
        label: commSnapshot.currentStatusMessage,
        dot: 'bg-rose-400 animate-pulse',
        cls: 'bg-rose-500/15 text-rose-300 border-rose-500/30'
      };
    }
    if (commSnapshot.currentState !== 'idle' && commSnapshot.currentState !== 'completed') {
      return {
        label: commSnapshot.currentStatusMessage,
        dot: 'bg-teal-400 animate-ping',
        cls: 'bg-teal-500/15 text-[#66E3CB] border-teal-500/30'
      };
    }
    switch (state) {
      case 'PROCESSING':
        return { label: 'LORIN is thinking', dot: 'bg-teal-400 animate-ping', cls: 'bg-teal-500/15 text-[#66E3CB] border-teal-500/30' };
      case 'RESPONDING':
        return { label: 'LORIN is responding', dot: 'bg-emerald-400 animate-pulse', cls: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' };
      case 'WAITING_FOR_APPROVAL':
        return { label: 'Waiting for Approval', dot: 'bg-amber-400 animate-pulse', cls: 'bg-amber-500/15 text-amber-300 border-amber-500/30' };
      case 'UNAVAILABLE':
        return { label: 'Connection unavailable', dot: 'bg-rose-400', cls: 'bg-rose-500/15 text-rose-300 border-rose-500/30' };
      default:
        return { label: 'Ready', dot: 'bg-emerald-400', cls: 'bg-[#17212C] text-slate-300 border-[#283544]' };
    }
  };

  // Conversation Summary Panel State
  const [showSummaryPanel, setShowSummaryPanel] = useState(false);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [summaryData, setSummaryData] = useState<ConversationSummaryData | null>(null);
  const [isSummarySaved, setIsSummarySaved] = useState(false);

  const handleGenerateSummary = async () => {
    setShowSummaryPanel(true);
    setIsGeneratingSummary(true);
    setIsSummarySaved(false);

    const threadText = messages
      .filter(m => m.content && m.content.trim().length > 0)
      .map(m => `${m.role === 'user' ? 'USER' : 'ASSISTANT'}: ${m.content}`)
      .join('\n\n');

    if (!threadText || messages.length === 0) {
      setSummaryData({
        title: 'Empty Thread Summary',
        content: 'No conversation messages exist in this thread yet to summarize. Ask LORIN a question or share a directive to generate a conversation summary.',
        keyTopics: ['Thread Initialization'],
        decisions: ['None recorded'],
        timestamp: Date.now(),
        modelUsed: 'Local Memory Engine'
      });
      setIsGeneratingSummary(false);
      return;
    }

    const prompt = `Summarize the following engineering conversation session into:
1. Concise Title (1 line)
2. Executive Summary & Key Technical Consensus (2-3 paragraphs)
3. Key Topics Covered
4. Decisions & Action Items

Conversation content:
${threadText.slice(-8000)}`;

    const startTime = performance.now();
    try {
      const report = await DualModelRouter.route(
        prompt,
        backendMode || 'LIVE_GEMINI',
        undefined,
        undefined,
        undefined,
        { requestedModel: requestedModel || 'gemini-3.8-flash' }
      );
      const raw = report.rawSynthesis || '';
      const latencyMs = Math.round(performance.now() - startTime);

      const firstLineTitle = raw.split('\n')[0].replace(/^#*\s*/, '').replace(/\*+/g, '').trim();
      const title = firstLineTitle.length > 5 && firstLineTitle.length < 90
        ? firstLineTitle
        : `Thread Summary: ${activeConversation?.title || 'Engineering Session'}`;

      setSummaryData({
        title,
        content: raw,
        keyTopics: ['Architecture & Design', 'System Security', 'Task Execution'],
        decisions: ['Persist verified findings to memory vault', 'Execute recommended next steps'],
        timestamp: Date.now(),
        modelUsed: report.modelAttribution?.actualModel || 'gemini-3.8-flash',
        latencyMs
      });
    } catch {
      const offlineReport = OfflineIntelligenceService.generateResponse(prompt);
      setSummaryData({
        title: `Offline Summary: ${activeConversation?.title || 'Engineering Thread'}`,
        content: offlineReport.rawSynthesis,
        keyTopics: ['Offline Knowledge Engine', 'System Resilience'],
        decisions: ['Local Knowledge Memory Vault Applied'],
        timestamp: Date.now(),
        modelUsed: 'Offline Knowledge Memory Vault',
        latencyMs: offlineReport.latencyMs
      });
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  const handleSaveSummaryToMemory = () => {
    if (!summaryData) return;
    const res = MemoryStore.createRecord(
      {
        domain: 'TASK_HISTORY',
        key: `summary_${activeConversation?.id || Date.now()}`,
        title: summaryData.title,
        content: summaryData.content,
        provenance: `AI Conversation Summary Task (${new Date().toLocaleDateString()})`,
        status: 'CONFIRMED',
        tags: ['conversation-summary', 'ai-generated', activeProject?.name || 'general']
      },
      principal
    );
    if (res.success) {
      setIsSummarySaved(true);
      setPinToast('Conversation summary saved to Memory Vault under TASK_HISTORY!');
      setTimeout(() => setPinToast(null), 3500);
    } else {
      setPinToast(res.message || 'Could not save summary to memory store.');
      setTimeout(() => setPinToast(null), 3500);
    }
  };

  const stateBadge = getRuntimeStateBadge(assistantState);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && !attachedFile) || isLoading) return;

    const submittedText = inputText;
    const submittedFile = attachedFile || undefined;
    followMessagesRef.current = true;
    setInputText('');
    setAttachedFile(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    try {
      const report = await onSendMessage(submittedText, submittedFile);
      if (report && report.status === 'FAILED') {
        // Preserve draft text if request failed so user never loses work
        setInputText(submittedText);
        setAttachedFile(submittedFile || null);
        if (onDraftChange) onDraftChange(submittedText);
      }
    } catch {
      setInputText(submittedText);
      setAttachedFile(submittedFile || null);
      if (onDraftChange) onDraftChange(submittedText);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setInputText(val);
    if (onDraftChange) onDraftChange(val);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 160)}px`;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const extension = file.name.split('.').pop()?.toLowerCase() || '';
    if (!['txt', 'md', 'markdown', 'json', 'csv', 'log'].includes(extension)) {
      setAttachmentError('This upload path reads text files only (.txt, .md, .json, .csv, .log).');
      e.target.value = '';
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setAttachmentError('Choose a text file smaller than 2 MB.');
      e.target.value = '';
      return;
    }

    setAttachmentError(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (typeof content !== 'string') {
        setAttachmentError('This file could not be read as text.');
        return;
      }
      setAttachedFile({
        name: file.name,
        size: file.size,
        type: file.type || 'text/plain',
        content
      });
    };
    reader.onerror = () => setAttachmentError('This file could not be read. Try another file.');
    reader.readAsText(file);
  };

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handlePinToggle = (msg: ChatMessage) => {
    onTogglePinMessage(msg.id);
    const willBePinned = !msg.isPinned;
    setPinToast(willBePinned ? 'Message pinned to active session context.' : 'Message unpinned.');
    setTimeout(() => setPinToast(null), 3000);
  };

  const handleArchiveToggle = (msg: ChatMessage) => {
    if (onToggleArchiveMessage) {
      onToggleArchiveMessage(msg.id);
      const willBeArchived = !(msg.isArchived || msg.completionReport?.isArchived);
      setArchiveToast(
        willBeArchived
          ? 'Completion report archived to Audit Trail (chat feed decluttered).'
          : 'Completion report restored to active chat feed.'
      );
      setTimeout(() => setArchiveToast(null), 3000);
    }
  };

  const toggleExpandArchived = (msgId: string) => {
    setExpandedArchivedIds((prev) => {
      const next = new Set(prev);
      if (next.has(msgId)) {
        next.delete(msgId);
      } else {
        next.add(msgId);
      }
      return next;
    });
  };

  const handleStartEdit = (msg: ChatMessage) => {
    setEditingMsgId(msg.id);
    setEditingText(msg.content);
  };

  const handleSaveEdit = (msgId: string) => {
    if (!editingText.trim()) return;
    setEditingMsgId(null);
    if (onEditAndResend) {
      onEditAndResend(msgId, editingText.trim());
    } else {
      onSendMessage(editingText.trim());
    }
  };

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] overflow-hidden">
      {/* Current response state; never imply unreported workflow activity. */}
      <WorkflowStatusIndicator
        isLoading={isLoading}
        currentReport={currentReport}
        pendingApprovalsCount={pendingApprovals.length}
      />

      {/* 2. Dedicated PinnedMessageTray displaying cards for each pinned message with Remove Pin button */}
      <PinnedMessageTray
        pinnedMessages={pinnedMessages}
        onTogglePinMessage={onTogglePinMessage}
      />

      {/* Streamlined Top Control Bar */}
      <div className="p-3 border-b border-[#283544] bg-[#0E1520] flex items-center justify-between gap-3 shrink-0 flex-wrap">
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Truthful Runtime State Indicator */}
          <span className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 text-[11px] font-semibold whitespace-nowrap ${stateBadge.cls}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${stateBadge.dot}`} />
            <span>{stateBadge.label}</span>
          </span>
          {/* Active Project Context Selector */}
          <div className="flex items-center gap-1.5 bg-[#17212C] border border-[#283544] rounded-lg px-2.5 py-1">
            <FolderKanban className="w-3.5 h-3.5 text-[#66E3CB] shrink-0" />
            <select
              aria-label="Active Project Context"
              value={activeProject?.id || 'proj_lorin_core'}
              onChange={(e) => onSelectProject && onSelectProject(e.target.value)}
              className="bg-transparent text-[11px] text-white focus:outline-none cursor-pointer font-medium"
            >
              {projects.map(p => (
                <option key={p.id} value={p.id} className="bg-[#111821] text-white">
                  Context: {p.name}
                </option>
              ))}
            </select>
          </div>

          {/* Model Registry Selector */}
          {onSelectRequestedModel && (
            <div className="flex items-center gap-1.5 bg-[#17212C] border border-[#283544] rounded-lg px-2.5 py-1">
              <Cpu className="w-3.5 h-3.5 text-[#A9B8FF] shrink-0" />
              <select
                aria-label="Preferred Registry Model"
                value={requestedModel}
                onChange={(e) => onSelectRequestedModel(e.target.value)}
                className="bg-transparent text-[11px] text-[#66E3CB] focus:outline-none cursor-pointer font-medium"
              >
                <optgroup label="Open-Weight Models" className="bg-[#111821] text-[#66E3CB]">
                  <option value="deepseek-v4-flash" className="bg-[#111821] text-white">DeepSeek V4 Flash</option>
                  <option value="deepseek-v4-pro" className="bg-[#111821] text-white">DeepSeek V4 Pro</option>
                  <option value="qwen3.5" className="bg-[#111821] text-white">Qwen 3.5</option>
                  <option value="glm-5.3-flash" className="bg-[#111821] text-white">GLM-5.3-Flash</option>
                  <option value="gpt-oss:20b" className="bg-[#111821] text-white">gpt-oss-20b</option>
                  <option value="kimi-k3" className="bg-[#111821] text-white">Kimi K3</option>
                </optgroup>
                <optgroup label="Cloud Gateway" className="bg-[#111821] text-[#A9B8FF]">
                  <option value="gemini-3.8-flash" className="bg-[#111821] text-white">Gemini Primary Engine</option>
                  <option value="gemini-3.1-flash-lite" className="bg-[#111821] text-white">Gemini Fast Engine</option>
                </optgroup>
                <optgroup label="Offline Resilience" className="bg-[#111821] text-[#66E3CB]">
                  <option value="offline-knowledge-vault" className="bg-[#111821] text-white">LORIN Offline Knowledge Vault (Local Database)</option>
                </optgroup>
              </select>
              {ollamaCloudConfigured === false && !requestedModel.startsWith('gemini-') && (
                <span
                  className="text-[10px] font-mono text-amber-300/90 whitespace-nowrap pl-1 border-l border-[#283544]"
                  title="OLLAMA_API_KEY is not configured on the server; requests automatically failover to Gemini Cloud Synthesis Engine."
                >
                  · Ollama Cloud not configured
                </span>
              )}
            </div>
          )}

          {/* Mode Selector */}
          {profileConfig && onUpdateProfileConfig && (
            <div className="hidden md:flex items-center gap-1.5 bg-[#17212C] border border-[#283544] rounded-lg px-2.5 py-1">
              <Sliders className="w-3.5 h-3.5 text-[#66E3CB] shrink-0" />
              <select
                aria-label="LORIN Operating Mode"
                value={profileConfig.operatingMode}
                onChange={(e) => onUpdateProfileConfig({ operatingMode: e.target.value as LorinOperatingMode })}
                className="bg-transparent text-[11px] text-white focus:outline-none cursor-pointer"
              >
                {(Object.keys(LORIN_OPERATING_MODES) as LorinOperatingMode[]).map((mKey) => (
                  <option key={mKey} value={mKey} className="bg-[#111821] text-white">
                    Mode: {LORIN_OPERATING_MODES[mKey].shortLabel}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleGenerateSummary}
            disabled={isGeneratingSummary}
            className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-[#66E3CB]/20 to-[#A9B8FF]/20 hover:from-[#66E3CB]/30 hover:to-[#A9B8FF]/30 border border-[#66E3CB]/40 text-[#66E3CB] hover:text-white text-[11px] font-mono flex items-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow-[0_0_12px_rgba(102,227,203,0.3)] disabled:opacity-40"
            title="Trigger AI task to summarize conversation thread and save to Memory Vault"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#66E3CB] animate-pulse" />
            <span className="hidden sm:inline font-semibold">Summarize Thread</span>
          </button>

          <button
            type="button"
            onClick={() => setIsDiagnosticsOpen(true)}
            className={`px-2.5 py-1 rounded-lg border text-[11px] font-mono flex items-center gap-1.5 transition-colors cursor-pointer ${
              commSnapshot.lastError
                ? 'bg-rose-500/15 text-rose-300 border-rose-500/40'
                : 'bg-[#17212C] hover:bg-[#1C2836] border-[#283544] text-[#A2AFBF] hover:text-white'
            }`}
            title="Open Communication Diagnostics & State Inspector (Section 9.3)"
          >
            <Activity className="w-3.5 h-3.5 text-[#66E3CB]" />
            <span className="hidden sm:inline">Diagnostics</span>
          </button>

          {onOpenModeAndAccessModal && (
            <button
              onClick={() => onOpenModeAndAccessModal('persona')}
              className="px-2.5 py-1 rounded-lg bg-[#17212C] hover:bg-[#1C2836] border border-[#283544] text-[#A2AFBF] hover:text-white text-[11px] font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Configure LORIN Modes, Voices & Security"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#66E3CB]" />
              <span className="hidden sm:inline">Settings & Access</span>
            </button>
          )}

          <button
            onClick={() => setShowHologramDock(!showHologramDock)}
            className={`px-2.5 py-1 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer ${
              showHologramDock
                ? 'bg-[#66E3CB]/15 text-[#66E3CB] border-[#66E3CB]/40'
                : 'bg-[#17212C] text-[#A2AFBF] border-[#283544] hover:text-white'
            }`}
            title="Toggle Expanded 3D Holographic Presence (Section 7.1)"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#66E3CB]" />
            <span className="text-[11px] hidden sm:inline">3D Hologram</span>
          </button>

          <button
            onClick={() => setIsInspectorOpen(!isInspectorOpen)}
            className={`px-2.5 py-1 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer ${
              isInspectorOpen
                ? 'bg-[#66E3CB]/15 text-[#66E3CB] border-[#66E3CB]/40'
                : 'bg-[#17212C] text-[#A2AFBF] border-[#283544] hover:text-white'
            }`}
            title="Toggle Context & Specialist Inspector (⌘I)"
          >
            <Terminal className="w-3.5 h-3.5 text-[#66E3CB]" />
            <span className="text-[11px] hidden sm:inline">Inspector</span>
          </button>

          {onOpenSearch && (
            <button
              onClick={onOpenSearch}
              className="px-2.5 py-1 rounded-lg bg-[#17212C] hover:bg-[#1C2836] border border-[#283544] text-[#A2AFBF] hover:text-white transition-colors flex items-center gap-2 group cursor-pointer"
              title="Search across Chat, Knowledge Vault, and Archive (⌘K)"
            >
              <Search className="w-3.5 h-3.5 text-[#66E3CB]" />
              <span className="text-[11px] hidden sm:inline">Search</span>
              <kbd className="text-[9px] px-1 rounded bg-[#0B0F14] text-[#738297] border border-[#283544] group-hover:text-[#66E3CB]">⌘K</kbd>
            </button>
          )}
        </div>
      </div>

      {/* Pin, Archive & Wake-word feedback toasts */}
      {pinToast && (
        <div className="fixed top-14 right-6 z-50 px-3 py-1.5 rounded-lg bg-[#17212C] border border-[#66E3CB]/40 text-[#66E3CB] text-xs font-mono shadow-xl animate-fade-in">
          {pinToast}
        </div>
      )}

      {archiveToast && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-[#17212C] border border-amber-500/40 text-amber-300 text-xs font-mono shadow-2xl animate-fade-in flex items-center gap-2">
          <Archive className="w-4 h-4 text-amber-400" />
          <span>{archiveToast}</span>
        </div>
      )}

      {/* 3-Pane Central Workspace: Conversation Canvas + Optional 3D Hologram Dock + Collapsible Context Inspector Panel */}
      <div className="flex-1 flex overflow-hidden relative">
        {showHologramDock && (
          <div className="hidden lg:flex w-64 shrink-0 border-r border-[#283544] bg-[#0E1520] p-4 flex-col items-center justify-between">
            <div className="w-full flex items-center justify-between text-[10px] font-mono text-[#A2AFBF]">
              <span className="text-[#66E3CB] font-bold uppercase tracking-wider">3D Companion</span>
              <button
                type="button"
                onClick={() => setShowHologramDock(false)}
                className="p-1 rounded hover:bg-[#17212C] text-[#738297] hover:text-white cursor-pointer"
                aria-label="Close 3D Companion Dock"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <LorinCharacter
              state={
                pendingApprovals.length > 0
                  ? 'NOTIFICATION'
                  : commSnapshot.characterState !== 'IDLE'
                  ? commSnapshot.characterState
                  : isLoading
                  ? 'THINKING'
                  : currentReport?.status === 'VERIFIED' || currentReport?.status === 'COMPLETED'
                  ? 'RESPONDING'
                  : 'IDLE'
              }
              presentation="standard"
              environment="conversation"
              force3D={true}
              showControls={true}
            />
            <div className="w-full p-2.5 rounded-xl bg-[#111821] border border-[#283544] text-[10px] font-mono text-[#A2AFBF] space-y-1">
              <div className="flex items-center justify-between">
                <span>State:</span>
                <span className="text-[#66E3CB] font-bold">{commSnapshot.currentStatusMessage}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Project:</span>
                <span className="text-white truncate max-w-[110px]">{activeProject?.name}</span>
              </div>
            </div>
          </div>
        )}

        {/* Messages Scroll Area */}
        <div
          className="flex-1 min-h-0 overflow-y-auto overscroll-contain p-4 sm:p-7 space-y-5 sm:space-y-7"
          onScroll={(event) => {
            const element = event.currentTarget;
            followMessagesRef.current = element.scrollHeight - element.scrollTop - element.clientHeight < 120;
          }}
        >
          <div className="max-w-3xl mx-auto space-y-7">
            <AnimatePresence>
              {showSummaryPanel && (
                <ConversationSummaryPanel
                  summary={summaryData}
                  isGenerating={isGeneratingSummary}
                  onClose={() => setShowSummaryPanel(false)}
                  onSaveToMemory={handleSaveSummaryToMemory}
                  onResummarize={handleGenerateSummary}
                  isSaved={isSummarySaved}
                />
              )}
            </AnimatePresence>

          {messages.length === 0 ? (
            /* First-Use Welcome State */
            <div className="py-12 text-center space-y-6">
              <div className="flex items-center justify-center">
                <LorinCharacter
                  state={commSnapshot.characterState !== 'IDLE' ? commSnapshot.characterState : isLoading ? 'THINKING' : 'IDLE'}
                  presentation="compact"
                  environment="conversation"
                  showStatus={false}
                />
              </div>

              <div>
                <div className="inline-flex flex-wrap items-center justify-center gap-2 px-3 py-1 rounded-full bg-[#17212C] border border-[#283544] text-[11px] font-mono text-[#66E3CB] mb-3">
                  <FolderKanban className="w-3.5 h-3.5" />
                  <span>{activeProject?.name}</span>
                  {profileConfig && (
                    <>
                      <span>·</span>
                      <span className="text-[#A9B8FF]">
                        Mode: {LORIN_OPERATING_MODES[profileConfig.operatingMode].shortLabel}
                      </span>
                      <span>·</span>
                      <span className="text-emerald-400">
                        Voice: {LORIN_VOICE_PROFILES[profileConfig.voiceProfile].shortLabel}
                      </span>
                    </>
                  )}
                </div>
                <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-white">What would you like to work on?</h1>
                <p className="text-sm text-[#A2AFBF] max-w-lg mx-auto mt-3 leading-relaxed">
                  Ask a question, explore an idea, plan a project, or share code for review. LORIN brings your current project context into the conversation.
                </p>

                {onOpenModeAndAccessModal && (
                  <div className="flex flex-wrap items-center justify-center gap-2 mt-4 font-mono text-[11px]">
                    <button
                      type="button"
                      onClick={() => onOpenModeAndAccessModal('persona')}
                      className="px-3 py-1.5 rounded-lg bg-[#111821] hover:bg-[#17212C] border border-[#283544] hover:border-[#66E3CB]/50 text-[#66E3CB] flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      <span>Switch Mode, Personality & Voice</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenModeAndAccessModal('levels')}
                      className="px-3 py-1.5 rounded-lg bg-[#111821] hover:bg-[#17212C] border border-[#283544] hover:border-[#A9B8FF]/50 text-[#A9B8FF] flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Gauge className="w-3.5 h-3.5" />
                      <span>Autonomy Levels (L0–L4)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenModeAndAccessModal('access_runtime')}
                      className="px-3 py-1.5 rounded-lg bg-[#111821] hover:bg-[#17212C] border border-[#283544] hover:border-emerald-500/50 text-emerald-300 flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Secure Access & Online/Offline Runtime</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Prompt suggestion pills */}
              <div className="flex max-w-3xl mx-auto flex-wrap justify-center gap-2 pt-2">
                {PROMPT_SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => {
                      setInputText(s);
                      if (textareaRef.current) textareaRef.current.focus();
                    }}
                    className="px-3.5 py-2 rounded-full bg-[#111821] border border-[#283544] hover:border-[#66E3CB]/50 text-sm text-[#D7E0E9] hover:bg-[#17212C] transition-colors cursor-pointer"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <AnimatePresence mode="popLayout" initial={false}>
              {messages.map((msg) => {
              const isArchived = msg.isArchived || msg.completionReport?.isArchived;
              const isExpandedInline = expandedArchivedIds.has(msg.id);
              const attr = msg.modelAttribution || msg.completionReport?.modelAttribution;
              const isFailedMsg =
                msg.completionReport?.status === 'FAILED' ||
                msg.content.includes('[INFERENCE_FAILURE]');

              if (isArchived && hideArchivedInFeed && !isExpandedInline && msg.role === 'assistant') {
                return (
                <motion.div
                    layout
                    key={msg.id}
                    id={`msg-${msg.id}`}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.98 }}
                    transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                    className="w-full rounded-xl bg-[#111821]/80 border border-[#283544] hover:border-[#3A4B5F] p-3 text-xs flex items-center justify-between gap-3 text-[#A2AFBF] shadow-xs transition-colors"
                  >
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <div className="w-6 h-6 rounded-md bg-[#17212C] border border-[#283544] flex items-center justify-center text-amber-400/90 shrink-0">
                        <Archive className="w-3.5 h-3.5" />
                      </div>
                      <div className="truncate flex items-center gap-1.5">
                        <span className="text-[10px] font-mono text-[#738297] uppercase">Archived Report:</span>
                        <span className="font-semibold text-white truncate">
                          {msg.completionReport?.objective || msg.content.slice(0, 50)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => toggleExpandArchived(msg.id)}
                        className="text-[11px] font-mono text-[#A2AFBF] hover:text-white underline underline-offset-2 transition-colors"
                      >
                        View Details
                      </button>
                      <button
                        onClick={() => handleArchiveToggle(msg)}
                        className="text-[11px] font-mono text-[#66E3CB] hover:underline flex items-center gap-1 transition-colors"
                      >
                        <ArchiveRestore className="w-3 h-3" />
                        <span>Restore</span>
                      </button>
                    </div>
                  </motion.div>
                );
              }

              return (
              <motion.div
                layout
                key={msg.id}
                id={`msg-${msg.id}`}
                initial={{ opacity: 0, y: 8, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                className={`space-y-3 group ${msg.role === 'user' ? 'flex flex-col items-end' : 'w-full'}`}
              >
                {/* User Message */}
                {msg.role === 'user' ? (
                  <div className="relative max-w-2xl rounded-2xl rounded-tr-xs bg-[#17212C] border border-[#3A4B5F] px-4 py-3.5 text-sm text-white leading-relaxed space-y-2 shadow-sm">
                    <div className="flex items-center justify-between gap-4 text-[10px] font-mono text-[#738297] border-b border-[#283544]/60 pb-1.5 mb-1.5">
                      <span>USER DIRECTIVE {msg.projectId ? `· ${msg.projectId.replace('proj_', '').toUpperCase()}` : ''}</span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleStartEdit(msg)}
                          className="p-1 rounded text-[#738297] hover:text-white transition-colors cursor-pointer"
                          title="Edit and re-run directive"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handlePinToggle(msg)}
                          className={`p-1 rounded transition-colors cursor-pointer ${
                            msg.isPinned ? 'text-[#66E3CB] bg-[#111821]' : 'text-[#738297] hover:text-white'
                          }`}
                          title={msg.isPinned ? 'Unpin directive' : 'Pin directive to session context'}
                        >
                          <Pin className={`w-3.5 h-3.5 ${msg.isPinned ? 'fill-current' : ''}`} />
                        </button>
                      </div>
                    </div>

                    {editingMsgId === msg.id ? (
                      <div className="space-y-2">
                        <textarea
                          rows={2}
                          value={editingText}
                          onChange={(e) => setEditingText(e.target.value)}
                          className="w-full bg-[#111821] border border-[#66E3CB] rounded-lg p-2 text-xs text-white focus:outline-none"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => setEditingMsgId(null)}
                            className="px-2.5 py-1 rounded text-[11px] text-slate-400 hover:text-white"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleSaveEdit(msg.id)}
                            className="px-2.5 py-1 rounded bg-[#66E3CB] text-[#0B0F14] font-semibold text-[11px]"
                          >
                            Save & Resubmit
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="leading-relaxed font-sans">{formatInlineText(msg.content)}</div>
                    )}

                    {msg.attachedFile && (
                      <div className="flex items-center gap-2 p-2 rounded-lg bg-[#111821] border border-[#283544] text-[11px] font-mono text-[#66E3CB]">
                        <FileText className="w-3.5 h-3.5" />
                        <span>{msg.attachedFile.name}</span>
                        <span className="text-[#738297]">({Math.round(msg.attachedFile.size / 1024)} KB)</span>
                      </div>
                    )}

                    {msg.snapshotImage && (
                      <div className="mt-2 rounded-lg overflow-hidden border border-[#3A4B5F] max-w-xs">
                        <img src={msg.snapshotImage} alt="Snapshot attachment" className="w-full h-auto" />
                      </div>
                    )}
                  </div>
                ) : (
                  /* Assistant / LORIN Synthesis Message */
                  <div className={`w-full rounded-2xl bg-[#111821] border p-5 sm:p-6 text-sm text-[#F1F5F9] space-y-5 shadow-sm transition-colors ${
                    isFailedMsg
                      ? 'border-rose-500/40'
                      : msg.isPinned
                      ? 'border-[#66E3CB]/50 shadow-[#66E3CB]/5'
                      : 'border-[#283544]'
                  }`}>
                    {/* Header */}
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#283544] pb-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <div className="w-6 h-6 rounded-md bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center text-[#66E3CB]">
                          <Sparkles className="w-3.5 h-3.5" />
                        </div>
                        <span className="font-bold text-white text-xs">LORIN Synthesis</span>

                        {/* Truthful Model Attribution Badge (Private Label) */}
                        {attr ? (
                          <span
                            className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                              attr.fallbackUsed
                                ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                                : 'bg-[#17212C] text-[#66E3CB] border-[#283544]'
                            }`}
                            title={
                              attr.fallbackUsed
                                ? `Requested: ${attr.requestedProvider} -> Executed: ${attr.actualProvider} (${attr.fallbackReason || 'Fallback'})`
                                : `Executed on ${attr.actualProvider} (${formatPrivateModelLabel(attr.actualModel)})`
                            }
                          >
                            {attr.actualProvider}: {formatPrivateModelLabel(attr.actualModel)}
                            {attr.fallbackUsed ? ' (Fallback)' : ''} · {attr.latencyMs}ms
                          </span>
                        ) : msg.completionReport ? (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#17212C] text-[#66E3CB] border border-[#283544]">
                            {msg.completionReport.backendUsed} · {msg.completionReport.latencyMs}ms
                          </span>
                        ) : null}

                        {msg.isPinned && (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#66E3CB]/10 text-[#66E3CB] border border-[#66E3CB]/30 flex items-center gap-1">
                            <Pin className="w-3 h-3 fill-current" />
                            <span>Pinned</span>
                          </span>
                        )}
                      </div>

                      {/* Header Actions: Read Aloud, Regenerate, Archive, Pin, Inspector & Copy */}
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleToggleSpeakMessage(msg)}
                          className={`p-1.5 rounded transition-colors cursor-pointer ${
                            speakingMsgId === msg.id
                              ? 'bg-[#66E3CB]/20 text-[#66E3CB] border border-[#66E3CB]/40'
                              : 'hover:bg-[#17212C] text-[#738297] hover:text-white'
                          }`}
                          title={speakingMsgId === msg.id ? 'Stop reading aloud' : 'Read synthesis aloud (TTS)'}
                          aria-label={speakingMsgId === msg.id ? 'Stop reading aloud' : 'Read synthesis aloud'}
                        >
                          {speakingMsgId === msg.id ? <Square className="w-3.5 h-3.5 fill-current" /> : <Volume2 className="w-3.5 h-3.5" />}
                        </button>

                        {onRegenerateResponse && (
                          <button
                            onClick={() => onRegenerateResponse(msg.id)}
                            disabled={isLoading}
                            className="p-1.5 rounded hover:bg-[#17212C] text-[#738297] hover:text-white transition-colors cursor-pointer disabled:opacity-40"
                            title="Regenerate synthesis response"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {msg.completionReport && (
                          <button
                            onClick={() => handleArchiveToggle(msg)}
                            className={`p-1.5 rounded transition-colors cursor-pointer ${
                              isArchived
                                ? 'text-amber-400 bg-[#17212C] border border-amber-500/30'
                                : 'hover:bg-[#17212C] text-[#738297] hover:text-white'
                            }`}
                            title={isArchived ? 'Restore report to main feed' : 'Archive completion report to declutter chat feed'}
                          >
                            <Archive className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          onClick={() => handlePinToggle(msg)}
                          className={`p-1.5 rounded transition-colors cursor-pointer ${
                            msg.isPinned
                              ? 'text-[#66E3CB] bg-[#17212C] border border-[#3A4B5F]'
                              : 'hover:bg-[#17212C] text-[#738297] hover:text-white'
                          }`}
                          title={msg.isPinned ? 'Unpin message' : 'Pin message to session context'}
                        >
                          <Pin className={`w-3.5 h-3.5 ${msg.isPinned ? 'fill-current' : ''}`} />
                        </button>

                        <button
                          onClick={() => {
                            setActiveInspectorMessage(msg);
                            setIsInspectorOpen(true);
                          }}
                          className="p-1.5 rounded hover:bg-[#17212C] text-[#738297] hover:text-[#66E3CB] transition-colors cursor-pointer"
                          title="Open Context & Specialist Inspector for this synthesis"
                        >
                          <Terminal className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleCopyText(msg.content, msg.id)}
                          className="p-1.5 rounded hover:bg-[#17212C] text-[#738297] hover:text-white transition-colors cursor-pointer"
                          title="Copy synthesis"
                        >
                          {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    {/* Fallback Attribution Banner when Fallback Occurred */}
                    {attr?.fallbackUsed && attr.fallbackReason && (
                      <div className="px-3 py-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-[11px] font-mono text-amber-200 flex items-center justify-between gap-2">
                        <span>
                          Attribution Notice: Requested <strong>{attr.requestedProvider}/{attr.requestedModel}</strong>; executed via <strong>{attr.actualProvider}/{attr.actualModel}</strong> ({attr.fallbackReason}).
                        </span>
                      </div>
                    )}

                    {/* Main Formatted Content */}
                    <div>
                      {renderFormattedContent(msg.content, msg.id)}
                    </div>

                    {/* Inline Failure Recovery Bar when request failed */}
                    {isFailedMsg && (
                      <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex flex-wrap items-center justify-between gap-3 text-xs">
                        <div className="flex items-center gap-2 text-rose-200">
                          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                          <span>This request encountered an error. You can retry immediately or inspect diagnostics.</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {onRegenerateResponse && (
                            <button
                              type="button"
                              onClick={() => onRegenerateResponse(msg.id)}
                              disabled={isLoading}
                              className="px-3 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-semibold text-xs flex items-center gap-1.5 cursor-pointer"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>Retry Request</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => setIsDiagnosticsOpen(true)}
                            className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white font-medium text-xs cursor-pointer"
                          >
                            Open Diagnostics
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Task Completion & Empirical Verification Card */}
                    {msg.completionReport && (
                      <div className="p-3.5 rounded-xl bg-[#0B0F14] border border-[#283544] space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2 overflow-hidden">
                            <span className="font-mono text-[10px] text-[#66E3CB] font-bold">TASK OBJECTIVE:</span>
                            <span className="font-semibold text-white truncate">{msg.completionReport.objective}</span>
                          </div>
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded border shrink-0 font-bold ${
                            msg.completionReport.status === 'VERIFIED'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                              : msg.completionReport.status === 'FAILED'
                              ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                              : 'bg-teal-500/10 text-[#66E3CB] border-teal-500/30'
                          }`}>
                            {msg.completionReport.status}
                          </span>
                        </div>

                        {msg.completionReport.verification && (
                          <div className="text-[11px] font-mono text-slate-300 border-t border-[#283544]/60 pt-2 flex items-start justify-between gap-3">
                            <div className="flex items-start gap-1.5 flex-1">
                              <FileCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                              <span className="line-clamp-2">{msg.completionReport.verification.evidence}</span>
                            </div>
                            <button
                              onClick={() => handleArchiveToggle(msg)}
                              className="px-2 py-1 rounded bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[10px] font-mono text-[#A2AFBF] hover:text-white flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                            >
                              <Archive className="w-3 h-3 text-amber-400/90" />
                              <span>{isArchived ? 'Unarchive' : 'Archive Report'}</span>
                            </button>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Grounded Knowledge Citations if retrieved */}
                    {msg.sourcesCited && msg.sourcesCited.length > 0 && (
                      <div className="p-3 rounded-xl bg-[#0B0F14] border border-[#283544] space-y-1.5 font-mono text-[11px]">
                        <div className="flex items-center gap-1.5 text-[#66E3CB] font-bold">
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>Sanitized Knowledge Citations ({msg.sourcesCited.length})</span>
                        </div>
                        <ul className="space-y-1 text-[#A2AFBF]">
                          {msg.sourcesCited.map((cite, i) => (
                            <li key={i} className="leading-normal">
                              <strong className="text-white">[{cite.docTitle}]</strong>: {cite.snippet.slice(0, 160)}...
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Specialist Perspective Tabs for this message */}
                    {msg.completionReport && (
                      <div className="pt-2 border-t border-[#283544]/60 space-y-3">
                        <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] font-mono">
                          <span className="text-[#738297] mr-1">Specialists:</span>
                          {(Object.keys(SPECIALISTS) as SpecialistRole[]).map((r) => {
                            const spec = SPECIALISTS[r];
                            const isSelected = selectedSpecialistLens === r;
                            return (
                              <button
                                key={r}
                                onClick={() => setSelectedSpecialistLens(isSelected ? 'ALL' : r)}
                                className={`px-2 py-0.5 rounded transition-colors whitespace-nowrap border cursor-pointer ${
                                  isSelected
                                    ? 'bg-[#17212C] text-white border-[#3A4B5F]'
                                    : 'border-transparent text-[#738297] hover:text-white'
                                }`}
                              >
                                {spec.name}
                              </button>
                            );
                          })}
                        </div>

                        <AnimatePresence>
                          {selectedSpecialistLens !== 'ALL' && msg.completionReport.specialistBreakdown[selectedSpecialistLens] && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              transition={{ duration: 0.16 }}
                              className="p-3.5 rounded-xl bg-[#17212C] border border-[#3A4B5F] text-xs space-y-2 overflow-hidden"
                            >
                              <div className="font-bold text-white flex items-center justify-between">
                                <span>{SPECIALISTS[selectedSpecialistLens].name} — {SPECIALISTS[selectedSpecialistLens].title}</span>
                                <span className="text-[10px] font-mono text-[#738297]">
                                  {SPECIALISTS[selectedSpecialistLens].domain}
                                </span>
                              </div>
                              <p className="text-slate-300 leading-relaxed">
                                {msg.completionReport.specialistBreakdown[selectedSpecialistLens].summary}
                              </p>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            );
          })}
          </AnimatePresence>
        )}

          <AnimatePresence>
            {isLoading && (
              <motion.div 
                layout
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="flex items-center justify-between gap-3 p-4 rounded-xl bg-[#111821] border border-[#283544] text-xs text-[#A2AFBF] font-mono"
              >
                <div className="flex items-center gap-3" role="status" aria-live="polite">
                  <RefreshCw className="w-4 h-4 animate-spin text-[#66E3CB]" />
                  <span>
                    {commSnapshot.currentState !== 'idle' && commSnapshot.currentState !== 'completed'
                      ? `${commSnapshot.currentStatusMessage}${commSnapshot.currentDetail ? ` — ${commSnapshot.currentDetail}` : ''}`
                      : 'LORIN is preparing a response…'}
                  </span>
                </div>
                {onCancelRequest && (
                  <button
                    onClick={onCancelRequest}
                    className="px-3 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-[11px] font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Square className="w-3 h-3 fill-current" />
                    <span>Cancel Request</span>
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Collapsible Right Context Inspector Panel */}
      <ContextInspectorPanel
        isOpen={isInspectorOpen}
        onClose={() => setIsInspectorOpen(false)}
        activeMessage={activeInspectorMessage || (messages.length > 0 ? messages[messages.length - 1] : null)}
        activeReport={currentReport}
      />
    </div>

      {/* Floating Attachment Indicator */}
      {attachmentError && (
        <div className="mx-auto w-full max-w-3xl px-5 pb-2 text-sm text-[var(--lorin-danger)]" role="alert">
          {attachmentError}
        </div>
      )}
      {attachedFile && (
        <div className="px-6 py-2 bg-[#111821] border-t border-[#283544]">
          <div className="max-w-4xl mx-auto flex items-center justify-between text-xs font-mono text-[#66E3CB]">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              <span>Attached: {attachedFile.name} ({Math.round(attachedFile.size / 1024)} KB)</span>
            </div>
            <button onClick={() => setAttachedFile(null)} className="text-[#738297] hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Bottom Message Composer */}
      <div className="lorin-composer-dock border-t border-[#283544] bg-[#0D141C] px-3 py-3 sm:px-5 sm:py-4">
        <div className="max-w-3xl mx-auto space-y-2">
          {/* Live Mode A Dictation Status Pill */}
          {dictationStatus && (
            <div className="px-3.5 py-2 rounded-xl bg-[#111821] border border-[#66E3CB]/40 flex items-center justify-between gap-2 text-xs font-mono text-[#66E3CB]">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${isDictating ? 'bg-rose-400 animate-ping' : 'bg-[#66E3CB]'}`} />
                <span>{dictationStatus}</span>
              </div>
              {isDictating && (
                <button
                  type="button"
                  onClick={handleToggleDictation}
                  className="px-2.5 py-0.5 rounded bg-[#66E3CB]/20 hover:bg-[#66E3CB]/30 text-white font-semibold text-[11px] cursor-pointer"
                >
                  Finish Dictation
                </button>
              )}
            </div>
          )}

          <form onSubmit={handleSubmit} className="relative rounded-2xl bg-[#111821] border border-[#283544] focus-within:border-[#66E3CB]/70 focus-within:ring-2 focus-within:ring-[#66E3CB]/10 shadow-[0_16px_40px_-28px_rgba(0,0,0,.9)] p-3 transition-colors">
            <textarea
              ref={textareaRef}
              rows={1}
              value={inputText}
              onChange={handleTextareaChange}
              onKeyDown={handleKeyDown}
              placeholder={isDictating ? 'Listening — speak now to dictate into this box…' : 'Message LORIN…'}
              disabled={isLoading}
              className="w-full min-h-12 max-h-40 bg-transparent px-3 py-2 text-[15px] text-white placeholder-[#8796A8] focus:outline-none resize-none font-sans leading-relaxed"
            />

            <div className="flex items-center justify-between pt-2 px-1 text-xs">
              {/* Left action shortcuts: Attachment, Mode A Dictation, Mode B Live Voice, Video shortcut */}
              <div className="flex items-center gap-1.5 text-[#A2AFBF]">
                <label className="lorin-icon-button relative rounded-lg hover:bg-[#283544] text-[#A2AFBF] hover:text-white cursor-pointer transition-colors focus-within:ring-2 focus-within:ring-[var(--lorin-focus)]" title="Attach text file (up to 2 MB)">
                  <Paperclip className="w-4 h-4" />
                  <input aria-label="Attach a text file" type="file" accept=".txt,.md,.markdown,.json,.csv,.log,text/plain,text/markdown,application/json,text/csv" onChange={handleFileSelect} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" />
                </label>

                <button
                  type="button"
                  onClick={handleToggleDictation}
                  disabled={isLoading}
                  className={`px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 text-[11px] font-medium transition-colors cursor-pointer border ${
                    isDictating
                      ? 'bg-rose-500/20 text-rose-200 border-rose-500/40 animate-pulse'
                      : 'hover:bg-[#283544] text-[#A2AFBF] hover:text-[#66E3CB] border-transparent'
                  }`}
                  title="Mode A — Voice Dictation: Speak and insert text into composer for review before sending"
                  aria-label="Dictate message into composer"
                >
                  {isDictating ? <MicOff className="w-3.5 h-3.5 text-rose-400" /> : <Mic className="w-3.5 h-3.5" />}
                  <span className="hidden sm:inline">{isDictating ? 'Stop Dictation' : 'Dictate'}</span>
                </button>

                <button
                  type="button"
                  onClick={onOpenVoice}
                  className="px-2.5 py-1.5 rounded-lg hover:bg-[#283544] text-[#A2AFBF] hover:text-[#66E3CB] transition-colors cursor-pointer flex items-center gap-1.5 text-[11px]"
                  title="Mode B — Switch to Full Interactive Voice Conversation (Alt+V)"
                  aria-label="Open voice mode"
                >
                  <Headphones className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Voice Mode</span>
                </button>

                <button
                  type="button"
                  onClick={onOpenVideo}
                  className="lorin-icon-button rounded-lg hover:bg-[#283544] text-[#A2AFBF] hover:text-[#66E3CB] transition-colors cursor-pointer"
                  title="Switch to Video & Vision Mode"
                  aria-label="Open vision mode"
                >
                  <Video className="w-4 h-4" />
                </button>
              </div>

              {/* Right submit / cancel button */}
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-[#738297] hidden sm:inline">
                  Enter to send · Shift+Enter newline
                </span>
                {isLoading && onCancelRequest ? (
                  <button
                    type="button"
                    onClick={onCancelRequest}
                    className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 font-bold text-xs flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
                  >
                    <Square className="w-3 h-3 fill-current" />
                    <span>Stop</span>
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={(!inputText.trim() && !attachedFile) || isLoading}
                    className="px-4 py-2 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] disabled:opacity-30 disabled:hover:bg-[#66E3CB] text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
                  >
                    <span>Send</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>
      </div>

      {/* Communication Diagnostics Modal (Section 9.3) */}
      <CommunicationDiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
        selectedModel={requestedModel}
        backendMode={backendMode}
        onRetryLastRequest={
          onRegenerateResponse && messages.length > 0
            ? () => {
                const lastAssistant = [...messages].reverse().find(m => m.role === 'assistant');
                if (lastAssistant) onRegenerateResponse(lastAssistant.id);
              }
            : undefined
        }
      />
    </div>
  );
};
