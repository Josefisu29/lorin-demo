import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  Clock,
  Play,
  Plus,
  RotateCcw,
  ShieldAlert,
  Square,
  Trash2,
  AlertTriangle,
  Layers,
  Lock,
  Server,
  ChevronDown,
  ChevronUp,
  FolderKanban
} from 'lucide-react';
import {
  DurableTaskRecord,
  DurableTaskState,
  Principal,
  RiskLevel
} from '../types/lorin';
import { TaskQueueService } from '../services/taskQueueService';
import { ProjectStore } from '../services/projectStore';
import { DailyGoalsTracker } from './DailyGoalsTracker';

interface TasksWorkspaceProps {
  principal: Principal;
  activeProjectId: string;
  onRefreshApprovals?: () => void;
}

const STATE_BADGES: Record<DurableTaskState, { label: string; cls: string }> = {
  QUEUED: {
    label: 'Queued',
    cls: 'bg-slate-500/15 text-slate-300 border-slate-500/30'
  },
  RUNNING: {
    label: 'Running',
    cls: 'bg-teal-500/15 text-[#66E3CB] border-teal-500/40 animate-pulse'
  },
  AWAITING_APPROVAL: {
    label: 'Awaiting Approval',
    cls: 'bg-amber-500/15 text-amber-300 border-amber-500/40'
  },
  SUCCEEDED: {
    label: 'Succeeded',
    cls: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
  },
  FAILED: {
    label: 'Failed',
    cls: 'bg-rose-500/15 text-rose-400 border-rose-500/30'
  },
  CANCELLED: {
    label: 'Cancelled',
    cls: 'bg-slate-700/30 text-slate-400 border-slate-600/40'
  },
  BLOCKED: {
    label: 'Blocked',
    cls: 'bg-purple-500/15 text-purple-300 border-purple-500/30'
  }
};

export const TasksWorkspace: React.FC<TasksWorkspaceProps> = ({
  principal,
  activeProjectId,
  onRefreshApprovals
}) => {
  const [tasks, setTasks] = useState<DurableTaskRecord[]>([]);
  const [stateFilter, setStateFilter] = useState<'ALL' | DurableTaskState>('ALL');
  const [projectFilter, setProjectFilter] = useState<string>('ALL');
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>('task_dur_02');
  const [notice, setNotice] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New Task Form
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'>('HIGH');
  const [riskLevel, setRiskLevel] = useState<RiskLevel>('LOW');
  const [selectedDep, setSelectedDep] = useState<string>('');

  const projects = ProjectStore.getProjects();

  const refreshTasks = () => {
    TaskQueueService.setActiveUser(principal.id);
    setTasks(TaskQueueService.getTasks());
    if (onRefreshApprovals) onRefreshApprovals();
  };

  useEffect(() => {
    refreshTasks();
    TaskQueueService.syncFromBackend().then(() => {
      setTasks(TaskQueueService.getTasks());
    });
    const unsubscribe = TaskQueueService.subscribe(() => {
      setTasks(TaskQueueService.getTasks());
    });
    return () => unsubscribe();
  }, [principal.id, activeProjectId]);

  const showNotice = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(null), 4000);
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    const res = TaskQueueService.createTask(
      {
        title,
        description,
        projectId: activeProjectId,
        priority,
        riskLevel,
        dependencies: selectedDep ? [selectedDep] : []
      },
      principal
    );
    showNotice(res.message);
    if (res.success) {
      setTitle('');
      setDescription('');
      setIsModalOpen(false);
      refreshTasks();
    }
  };

  const handleRunTask = async (taskId: string) => {
    const res = await TaskQueueService.executeTask(taskId, principal);
    showNotice(res.message);
    refreshTasks();
  };

  const handleApproveAndRun = async (taskId: string) => {
    const res = await TaskQueueService.approveAndExecuteTask(taskId, principal);
    showNotice(res.message);
    refreshTasks();
  };

  const handleCancelTask = (taskId: string) => {
    const res = TaskQueueService.cancelTask(taskId, principal);
    showNotice(res.message);
    refreshTasks();
  };

  const handleRetryTask = async (taskId: string) => {
    const res = await TaskQueueService.retryTask(taskId, principal);
    showNotice(res.message);
    refreshTasks();
  };

  const handleDeleteTask = (taskId: string) => {
    const res = TaskQueueService.deleteTask(taskId, principal);
    showNotice(res.message);
    refreshTasks();
  };

  const filteredTasks = tasks.filter(t => {
    if (stateFilter !== 'ALL' && t.state !== stateFilter) return false;
    if (projectFilter !== 'ALL' && t.projectId !== projectFilter) return false;
    return true;
  });

  return (
    <div className="lorin-module-page flex-1 overflow-y-auto bg-[#0B0F14] p-4 sm:p-6 space-y-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#283544] pb-4 flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center text-[#66E3CB]">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">
                Durable Tasks, Scheduling & Authorized Automation
              </h1>
              <p className="text-xs text-[#A2AFBF] mt-0.5">
                Multistep task orchestration with explicit dependencies, bounded retries, and cryptographic Lena policy gates.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsModalOpen(true)}
              disabled={principal.role === 'GUEST'}
              className="px-3.5 py-2 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] disabled:opacity-40 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>New Durable Task</span>
            </button>
          </div>
        </div>

        {/* Daily Engineering Goals Tracker (Up to 5 tasks/day synced with TaskQueueService) */}
        <DailyGoalsTracker
          principal={principal}
          activeProjectId={activeProjectId}
          onGoalsChanged={() => refreshTasks()}
        />

        {/* Truthful Vercel Serverless Execution Architecture Notice (Part O Section 16) */}
        <div className="p-3.5 rounded-xl bg-[#111821] border border-[#283544] flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <Server className="w-4 h-4 text-[#A9B8FF] shrink-0" />
            <span className="text-[#F1F5F9]">
              <strong>Execution Architecture Disclosure:</strong> Interactive API tasks execute directly through the backend policy boundary. On Vercel serverless hosting, invocations are request-scoped (not always-on daemons); continuous background workers require an external managed queue or local companion runner.
            </span>
          </div>
          <span className="px-2 py-0.5 rounded bg-[#17212C] border border-[#3A4B5F] text-[10px] font-mono text-[#66E3CB] shrink-0">
            7 Canonical States Active
          </span>
        </div>

        {notice && (
          <div className="p-3 rounded-xl bg-[#17212C] border border-[#66E3CB]/40 text-[#66E3CB] text-xs font-mono flex items-center justify-between">
            <span>{notice}</span>
            <button onClick={() => setNotice(null)} className="text-[#738297] hover:text-white">✕</button>
          </div>
        )}

        {/* State Summary Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setStateFilter('ALL')}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono border transition-colors cursor-pointer ${
                stateFilter === 'ALL'
                  ? 'bg-[#17212C] text-[#66E3CB] border-[#66E3CB]/50 font-bold'
                  : 'bg-[#111821] text-[#A2AFBF] border-[#283544] hover:text-white'
              }`}
            >
              All ({tasks.length})
            </button>
            {(Object.keys(STATE_BADGES) as DurableTaskState[]).map((st) => {
              const count = tasks.filter(t => t.state === st).length;
              return (
                <button
                  key={st}
                  onClick={() => setStateFilter(st)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono border transition-colors cursor-pointer ${
                    stateFilter === st
                      ? 'bg-[#17212C] text-[#66E3CB] border-[#66E3CB]/50 font-bold'
                      : 'bg-[#111821] text-[#A2AFBF] border-[#283544] hover:text-white'
                  }`}
                >
                  {STATE_BADGES[st].label} ({count})
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <FolderKanban className="w-3.5 h-3.5 text-[#66E3CB]" />
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className="bg-[#111821] border border-[#283544] rounded-lg px-2.5 py-1 text-xs text-white"
            >
              <option value="ALL">All Projects</option>
              {projects.map(p => (
                <option key={p.id} value={p.id}>{p.name} ({p.slug})</option>
              ))}
            </select>
          </div>
        </div>

        {/* Task Cards */}
        <div className="space-y-3">
          {filteredTasks.length === 0 ? (
            <div className="p-10 text-center rounded-xl bg-[#111821] border border-[#283544] text-xs font-mono text-[#738297]">
              No durable tasks match the selected filter.
            </div>
          ) : (
            filteredTasks.map((task) => {
              const badge = STATE_BADGES[task.state];
              const isExpanded = expandedTaskId === task.id;
              const completedSteps = task.steps.filter(s => s.status === 'COMPLETED').length;
              const proj = projects.find(p => p.id === task.projectId);

              return (
                <div
                  key={task.id}
                  className="rounded-xl bg-[#111821] border border-[#283544] hover:border-[#3A4B5F] transition-all p-4 space-y-3 text-xs"
                >
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-white">{task.title}</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${badge.cls}`}>
                          {badge.label.toUpperCase()}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-[#0B0F14] border border-[#283544] text-[10px] font-mono text-[#A2AFBF]">
                          Priority: {task.priority} · Risk: {task.riskLevel}
                        </span>
                        {proj && (
                          <span className="px-2 py-0.5 rounded bg-[#17212C] border border-[#283544] text-[10px] font-mono text-[#66E3CB]">
                            {proj.slug}
                          </span>
                        )}
                      </div>
                      <p className="text-[#A2AFBF] leading-relaxed">{task.description}</p>
                    </div>

                    {/* Action Controls */}
                    <div className="flex items-center gap-2 flex-wrap">
                      {(task.state === 'QUEUED' || task.state === 'BLOCKED') && (
                        <button
                          onClick={() => handleRunTask(task.id)}
                          className="px-3 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>Execute</span>
                        </button>
                      )}

                      {task.state === 'AWAITING_APPROVAL' && principal.role === 'OWNER' && (
                        <button
                          onClick={() => handleApproveAndRun(task.id)}
                          className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Owner Approve & Execute</span>
                        </button>
                      )}

                      {(task.state === 'FAILED' || task.state === 'CANCELLED') && (
                        <button
                          onClick={() => handleRetryTask(task.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[#66E3CB] font-mono text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Retry ({task.retryCount}/{task.maxRetries})</span>
                        </button>
                      )}

                      {(task.state === 'QUEUED' || task.state === 'RUNNING' || task.state === 'AWAITING_APPROVAL') && (
                        <button
                          onClick={() => handleCancelTask(task.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 font-mono text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Square className="w-3 h-3 fill-current" />
                          <span>Cancel</span>
                        </button>
                      )}

                      <button
                        onClick={() => setExpandedTaskId(isExpanded ? null : task.id)}
                        className="p-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] text-[#A2AFBF] hover:text-white cursor-pointer"
                        title="Toggle multistep plan & execution log"
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>

                      {principal.role === 'OWNER' && (
                        <button
                          onClick={() => handleDeleteTask(task.id)}
                          className="p-1.5 rounded-lg bg-[#17212C] hover:bg-rose-950/50 text-[#738297] hover:text-rose-400 cursor-pointer"
                          title="Delete task record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Step Progress Bar & Meta */}
                  <div className="flex items-center justify-between text-[11px] font-mono text-[#738297] pt-2 border-t border-[#283544]">
                    <div className="flex items-center gap-4">
                      <span>Steps: <strong className="text-white">{completedSteps}/{task.steps.length}</strong></span>
                      <span>Retries: <strong className="text-white">{task.retryCount}/{task.maxRetries}</strong></span>
                      {task.dependencies.length > 0 && (
                        <span>Dependencies: <strong className="text-[#A9B8FF]">{task.dependencies.join(', ')}</strong></span>
                      )}
                    </div>
                    <span>Updated {new Date(task.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>

                  {/* Expanded Multistep Plan & Audit Execution Log */}
                  {isExpanded && (
                    <div className="pt-3 border-t border-[#283544] grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <div className="text-[11px] font-mono uppercase tracking-wider text-[#66E3CB] font-bold">
                          Multistep Specialist Execution Plan
                        </div>
                        <div className="space-y-1.5">
                          {task.steps.map((step, i) => (
                            <div
                              key={step.id}
                              className="p-2.5 rounded-lg bg-[#0B0F14] border border-[#283544] flex items-start justify-between gap-2"
                            >
                              <div>
                                <div className="font-semibold text-white">
                                  {i + 1}. {step.title}
                                </div>
                                <div className="text-[10px] font-mono text-[#738297] mt-0.5">
                                  Specialist: {step.specialist} {step.output ? `· ${step.output}` : ''}
                                </div>
                              </div>
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${
                                step.status === 'COMPLETED'
                                  ? 'bg-emerald-500/15 text-emerald-400'
                                  : 'bg-[#17212C] text-[#A2AFBF]'
                              }`}>
                                {step.status}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="text-[11px] font-mono uppercase tracking-wider text-[#A9B8FF] font-bold">
                          Auditable Execution Log
                        </div>
                        <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] font-mono text-[11px] text-[#A2AFBF] space-y-1 max-h-44 overflow-y-auto">
                          {task.executionLog.map((line, idx) => (
                            <div key={idx} className="leading-relaxed">
                              {line}
                            </div>
                          ))}
                        </div>
                        {task.resultSummary && (
                          <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-mono">
                            <strong>Verified Outcome:</strong> {task.resultSummary}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Create Task Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <form
            onSubmit={handleCreateTask}
            className="w-full max-w-lg bg-[#111821] border border-[#3A4B5F] rounded-2xl p-5 space-y-4 text-xs shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <h3 className="text-sm font-bold text-white">Create Durable Engineering Task</h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-[#738297] hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-[#A2AFBF] mb-1">Task Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Verify Firestore composite indexes and security rules"
                  className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div>
                <label className="block text-[#A2AFBF] mb-1">Description & Acceptance Criteria</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Specify the target resources, verification steps, and expected evidence..."
                  className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 font-mono">
                <div>
                  <label className="block text-[#A2AFBF] mb-1 font-sans">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white"
                  >
                    <option value="CRITICAL">CRITICAL</option>
                    <option value="HIGH">HIGH</option>
                    <option value="MEDIUM">MEDIUM</option>
                    <option value="LOW">LOW</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#A2AFBF] mb-1 font-sans">Security Risk Classification</label>
                  <select
                    value={riskLevel}
                    onChange={(e) => setRiskLevel(e.target.value as RiskLevel)}
                    className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white"
                  >
                    <option value="LOW">LOW (Standard Execution)</option>
                    <option value="MEDIUM">MEDIUM (Audited Execution)</option>
                    <option value="HIGH">HIGH (Requires Owner Approval)</option>
                    <option value="CRITICAL">CRITICAL (Strict Owner Gate)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[#A2AFBF] mb-1">Prerequisite Task Dependency (Optional)</label>
                <select
                  value={selectedDep}
                  onChange={(e) => setSelectedDep(e.target.value)}
                  className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white font-mono"
                >
                  <option value="">None (Ready immediately)</option>
                  {tasks.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.title} [{t.state}]
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-[#283544]">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-[#17212C] text-[#A2AFBF] hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold cursor-pointer"
              >
                Create Task
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
