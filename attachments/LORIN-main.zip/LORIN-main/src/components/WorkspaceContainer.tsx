import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, 
  Search, 
  FolderKanban, 
  ShieldCheck, 
  Bell, 
  Sparkles,
  Wifi,
  WifiOff,
  Cpu,
  Terminal,
  Settings
} from 'lucide-react';
import {
  ApprovalRecord,
  AuditEvent,
  ChatMessage,
  ConversationSession,
  ExtendedSpecialistName,
  LorinCompletionReport,
  LorinProfileConfig,
  Principal,
  WorkspaceView,
  normalizeCanonicalRole
} from '../types/lorin';
import { PolicyEngine } from '../services/policyEngine';
import { RoutingStrategy } from '../services/modelBackend';
import { ProjectStore } from '../services/projectStore';
import { GoogleDriveService } from '../services/googleDriveService';

// Child Workspaces
import { ChatWorkspace } from './ChatWorkspace';
import { ProjectsWorkspace } from './ProjectsWorkspace';
import { NetworkDeviceControlCenter } from './NetworkDeviceControlCenter';
import { ConnectionsWorkspace } from './ConnectionsWorkspace';
import { SpecialistConsole } from './SpecialistConsole';
import { VoiceChatView } from './VoiceChatView';
import { VideoVisionView } from './VideoVisionView';
import { KnowledgeVaultView } from './KnowledgeVaultView';
import { MemoryConsole } from './MemoryConsole';
import { TasksWorkspace } from './TasksWorkspace';
import { SecurityDashboard } from './SecurityDashboard';
import { TerminalWorkbench } from './TerminalWorkbench';
import { VerificationSuite } from './VerificationSuite';
import { UnifiedOwnerGateway } from './UnifiedOwnerGateway';
import { MosairaLabHub } from './lab/MosairaLabHub';
import { LaurenVaultHub } from './vault/LaurenVaultHub';
import { GideonWorkspace } from './GideonWorkspace';
import { PWAInstallButton } from './PWAInstallButton';

export interface WorkspaceContainerProps {
  currentView: WorkspaceView;
  setCurrentView: (view: WorkspaceView) => void;
  principal: Principal;
  activeProjectId: string;
  setActiveProjectId: (id: string) => void;
  onSelectProject: (id: string) => void;
  
  // Mobile Navigation
  onOpenMobileMenu: () => void;
  
  // Search & Modals
  onOpenSearch: () => void;
  onOpenArchivedModal: () => void;
  onOpenModeAndAccessModal: (tab?: 'persona' | 'levels' | 'access_runtime') => void;
  
  // Chat Props
  messages: ChatMessage[];
  pinnedMessages: ChatMessage[];
  activeConversationObj?: ConversationSession;
  archivedCount: number;
  isLoading: boolean;
  currentReport: LorinCompletionReport | null;
  handleTogglePinMessage: (id: string) => void;
  handleToggleArchiveMessage: (id: string) => void;
  handleExecutePrompt: (text: string, file?: any, image?: string, overrideSpecs?: ExtendedSpecialistName[]) => Promise<LorinCompletionReport>;
  handleCancelRequest: () => void;
  handleEditAndResend: (id: string, text: string) => void;
  handleRegenerateResponse: (id: string) => void;
  handleNewConversation: () => void;
  handleDraftChange: (draft: string) => void;
  
  // Policy & Security
  pendingApprovals: ApprovalRecord[];
  allApprovals: ApprovalRecord[];
  auditEvents: AuditEvent[];
  refreshPolicyState: () => void;
  
  // Model & Profile Config
  backendMode: RoutingStrategy;
  setBackendMode: (mode: RoutingStrategy) => void;
  requestedModel: string;
  setRequestedModel: (model: string) => void;
  activeExtendedSpecialists: ExtendedSpecialistName[];
  handleToggleExtendedSpecialist: (name: ExtendedSpecialistName) => void;
  handleActivateAllExtendedSpecialists: () => void;
  profileConfig: LorinProfileConfig;
  handleUpdateProfileConfig: (partial: Partial<LorinProfileConfig>) => void;
  handleToggleOnlineOffline: () => void;
  
  // Hardware Active Indicators
  isMicActive: boolean;
  setIsMicActive: (active: boolean) => void;
  isCameraActive: boolean;
  setIsCameraActive: (active: boolean) => void;
  
  // Public Tab Nav
  setActivePublicTab: (tab: any) => void;
}

const VIEW_METADATA: Record<WorkspaceView, { title: string; subtitle: string }> = {
  chat: { title: 'Chat Workspace', subtitle: 'Multi-Thread Intelligence' },
  projects: { title: 'Engineering Projects', subtitle: 'Context Isolation & ADRs' },
  specialists: { title: 'Specialist Console', subtitle: '6 Core Perspectives' },
  voice: { title: 'Voice Stage', subtitle: 'Real-Time Audio Stage' },
  video: { title: 'Vision Stage', subtitle: 'Snapshot Analysis' },
  vault: { title: 'Knowledge Vault', subtitle: 'Local RAG Search' },
  memory: { title: 'Personal Memory', subtitle: '5-Domain Governance' },
  tasks: { title: 'Durable Tasks', subtitle: 'Task Orchestration' },
  security: { title: 'Security & Policy', subtitle: 'RBAC Policy Engine' },
  connections: { title: 'Integrations', subtitle: 'External Services' },
  terminal: { title: 'CLI Workbench', subtitle: 'Developer Terminal' },
  tests: { title: 'Verification Suite', subtitle: 'System Verification' },
  settings: { title: 'Settings', subtitle: 'Preferences & Config' },
  mosairaLab: { title: 'MOSAIRA AI Lab', subtitle: 'Model Lab & Datasets' },
  laurenVault: { title: 'Lauren Private Vault', subtitle: 'Encrypted Vault' },
  ownerGateway: { title: 'Owner Gateway', subtitle: 'System Control Plane' },
  gideon: { title: 'GIDEON Timeline', subtitle: 'Systems Intelligence' },
  deviceCenter: { title: 'LORIN Network & Device Control', subtitle: 'Primary Node, Tailscale & Multi-Device Sync' }
};

export const WorkspaceContainer: React.FC<WorkspaceContainerProps> = (props) => {
  const {
    currentView,
    setCurrentView,
    principal,
    activeProjectId,
    setActiveProjectId,
    onSelectProject,
    onOpenMobileMenu,
    onOpenSearch,
    onOpenArchivedModal,
    onOpenModeAndAccessModal,
    messages,
    pinnedMessages,
    activeConversationObj,
    archivedCount,
    isLoading,
    currentReport,
    handleTogglePinMessage,
    handleToggleArchiveMessage,
    handleExecutePrompt,
    handleCancelRequest,
    handleEditAndResend,
    handleRegenerateResponse,
    handleNewConversation,
    handleDraftChange,
    pendingApprovals,
    allApprovals,
    auditEvents,
    refreshPolicyState,
    backendMode,
    setBackendMode,
    requestedModel,
    setRequestedModel,
    activeExtendedSpecialists,
    handleToggleExtendedSpecialist,
    handleActivateAllExtendedSpecialists,
    profileConfig,
    handleUpdateProfileConfig,
    handleToggleOnlineOffline,
    isMicActive,
    setIsMicActive,
    isCameraActive,
    setIsCameraActive,
    setActivePublicTab
  } = props;

  const projects = ProjectStore.getProjects();
  const activeProject = projects.find(p => p.id === activeProjectId) || projects[0];
  const viewMeta = VIEW_METADATA[currentView] || { title: 'Workspace', subtitle: 'Engineering Environment' };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0B0F17] text-[#F1F5F9] overflow-hidden relative">
      {/* Standardized Viewport Top Header */}
      <header className="h-14 px-4 sm:px-6 bg-[#0E1520] border-b border-[#283544] flex items-center justify-between gap-4 shrink-0 z-20">
        {/* Left: Mobile Menu + Title Breadcrumb + Active Project Badge */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenMobileMenu}
            className="md:hidden p-1.5 rounded-lg bg-[#17212C] border border-[#283544] text-[#A2AFBF] hover:text-white cursor-pointer"
            aria-label="Open menu"
          >
            <Menu className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="font-bold text-white text-sm tracking-tight">{viewMeta.title}</span>
            <span className="text-[#738297] hidden sm:inline" aria-hidden="true">·</span>
            <span className="text-[#A2AFBF] hidden sm:inline">{viewMeta.subtitle}</span>
          </div>

          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#17212C] border border-[#283544] text-[11px] font-mono text-slate-300">
            <FolderKanban className="w-3.5 h-3.5 text-[#66E3CB] shrink-0" />
            <select
              aria-label="Active Project Context"
              value={activeProjectId}
              onChange={(e) => onSelectProject(e.target.value)}
              className="bg-transparent text-white focus:outline-none cursor-pointer font-medium"
            >
              {projects.map(p => (
                <option key={p.id} value={p.id} className="bg-[#111821] text-white">
                  Context: {p.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Right: Quick Actions & State Indicators */}
        <div className="flex items-center gap-2 shrink-0">
          {pendingApprovals.length > 0 && (
            <button
              onClick={() => setCurrentView('security')}
              className="px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono flex items-center gap-1.5 cursor-pointer animate-pulse"
              title={`${pendingApprovals.length} Action Approvals Pending`}
            >
              <Bell className="w-3.5 h-3.5 text-amber-400" />
              <span className="tabular-nums font-bold">{pendingApprovals.length} Pending</span>
            </button>
          )}

          <button
            onClick={() => onOpenModeAndAccessModal('persona')}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#17212C] hover:bg-[#1C2836] border border-[#283544] text-[#A2AFBF] hover:text-white text-xs font-mono transition-colors cursor-pointer"
            title="Configure LORIN Operating Modes & Access"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#66E3CB]" />
            <span className="hidden md:inline">Settings & Access</span>
          </button>

          <button
            onClick={onOpenSearch}
            className="px-2.5 py-1 rounded-lg bg-[#17212C] hover:bg-[#1C2836] border border-[#283544] text-[#A2AFBF] hover:text-white text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer group"
            title="Global Search (⌘K)"
          >
            <Search className="w-3.5 h-3.5 text-[#66E3CB]" />
            <span className="hidden sm:inline">Search</span>
            <kbd className="hidden sm:inline text-[9px] px-1 rounded bg-[#0B0F14] text-[#738297] border border-[#283544] group-hover:text-[#66E3CB]">⌘K</kbd>
          </button>
        </div>
      </header>

      {/* Main Animated Viewport Container */}
      <main className="flex-1 overflow-hidden relative">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            layout
            layoutId={`workspace-viewport-${currentView}`}
            key={currentView}
            initial={{ opacity: 0, y: 8, scale: 0.995 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.995 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="w-full h-full flex flex-col overflow-hidden"
          >
            {!PolicyEngine.canAccessModule(principal, currentView) ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#0B0F14]">
                <div className="max-w-md p-6 rounded-2xl bg-[#111821] border border-rose-500/30 space-y-4">
                  <h2 className="text-base font-bold text-white">Access Denied — Insufficient Role Clearance</h2>
                  <p className="text-xs text-slate-400">
                    Your current canonical role (<span className="font-mono text-amber-300">{normalizeCanonicalRole(principal.canonicalRole || principal.role)}</span>) does not have permission to open the <span className="font-mono text-white">{viewMeta.title}</span> module.
                  </p>
                  <button
                    onClick={() => setCurrentView('chat')}
                    className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs cursor-pointer font-mono"
                  >
                    Return to Chat Workspace
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col w-full h-full min-h-0 overflow-hidden relative">
                {currentView === 'chat' && (
              <ChatWorkspace
                principal={principal}
                messages={messages}
                pinnedMessages={pinnedMessages}
                onTogglePinMessage={handleTogglePinMessage}
                onToggleArchiveMessage={handleToggleArchiveMessage}
                onSendMessage={handleExecutePrompt}
                onCancelRequest={handleCancelRequest}
                onEditAndResend={handleEditAndResend}
                onRegenerateResponse={handleRegenerateResponse}
                isLoading={isLoading}
                currentReport={currentReport}
                onOpenVoice={() => setCurrentView('voice')}
                onOpenVideo={() => setCurrentView('video')}
                onRefreshApprovals={refreshPolicyState}
                pendingApprovals={pendingApprovals}
                onOpenArchivedModal={onOpenArchivedModal}
                onOpenSearch={onOpenSearch}
                archivedCount={archivedCount}
                activeProjectId={activeProjectId}
                onSelectProject={onSelectProject}
                backendMode={backendMode}
                onSelectBackendMode={setBackendMode}
                requestedModel={requestedModel}
                onSelectRequestedModel={setRequestedModel}
                profileConfig={profileConfig}
                onUpdateProfileConfig={handleUpdateProfileConfig}
                onOpenModeAndAccessModal={onOpenModeAndAccessModal}
                onToggleOnlineOffline={handleToggleOnlineOffline}
                activeConversation={activeConversationObj}
                onNewConversation={handleNewConversation}
                onDraftChange={handleDraftChange}
              />
            )}

            {currentView === 'projects' && (
              <ProjectsWorkspace
                activeProjectId={activeProjectId}
                onSelectActiveProject={onSelectProject}
                onOpenChatWithProject={(projId) => {
                  onSelectProject(projId);
                  setCurrentView('chat');
                }}
              />
            )}

            {currentView === 'connections' && (
              <ConnectionsWorkspace
                driveAccessToken={GoogleDriveService.getAccessToken()}
              />
            )}

            {currentView === 'specialists' && (
              <SpecialistConsole
                principal={principal}
                onRunInference={async (p, overrideSpecs) => handleExecutePrompt(p, undefined, undefined, overrideSpecs)}
                currentReport={currentReport}
                isLoading={isLoading}
                onRefreshApprovals={refreshPolicyState}
                pendingApprovals={pendingApprovals}
                activeExtendedSpecialists={activeExtendedSpecialists}
                onToggleExtendedSpecialist={handleToggleExtendedSpecialist}
                onActivateAllSpecialists={handleActivateAllExtendedSpecialists}
              />
            )}

            {currentView === 'voice' && (
              <VoiceChatView
                onSendMessage={(text) => handleExecutePrompt(text)}
                onSwitchToChat={() => setCurrentView('chat')}
                isMicActive={isMicActive}
                setIsMicActive={setIsMicActive}
                activeVoiceProfile={profileConfig.voiceProfile}
                onSelectVoiceProfile={(vp) => handleUpdateProfileConfig({ voiceProfile: vp })}
              />
            )}

            {currentView === 'video' && (
              <VideoVisionView
                onAnalyzeSnapshot={(prompt, img) => handleExecutePrompt(prompt, undefined, img)}
                onSwitchToChat={() => setCurrentView('chat')}
                isCameraActive={isCameraActive}
                setIsCameraActive={setIsCameraActive}
              />
            )}

            {currentView === 'vault' && (
              <KnowledgeVaultView />
            )}

            {currentView === 'memory' && (
              <MemoryConsole principal={principal} />
            )}

            {currentView === 'tasks' && (
              <TasksWorkspace
                principal={principal}
                activeProjectId={activeProjectId}
                onRefreshApprovals={refreshPolicyState}
              />
            )}

            {currentView === 'security' && (
              <SecurityDashboard
                principal={principal}
                auditEvents={auditEvents}
                pendingApprovals={pendingApprovals}
                allApprovals={allApprovals}
                onRefreshData={refreshPolicyState}
              />
            )}

            {currentView === 'terminal' && (
              <TerminalWorkbench
                principal={principal}
                backendMode={backendMode}
                onNavigateToTab={(v) => setCurrentView(v)}
                pendingApprovalsCount={pendingApprovals.length}
              />
            )}

            {currentView === 'tests' && (
              <VerificationSuite />
            )}

            {currentView === 'ownerGateway' && (
              <UnifiedOwnerGateway
                principal={principal}
                onReturnToPublic={() => setActivePublicTab('discovery')}
                profileConfig={profileConfig}
                onOpenModeAndAccessModal={onOpenModeAndAccessModal}
                onToggleOnlineOffline={handleToggleOnlineOffline}
              />
            )}

            {currentView === 'mosairaLab' && (
              <MosairaLabHub
                principal={principal}
                onSwitchToLaurenVault={() => setCurrentView('laurenVault')}
              />
            )}

            {currentView === 'laurenVault' && (
              <LaurenVaultHub
                principal={principal}
                onSwitchToMosairaLab={() => setCurrentView('mosairaLab')}
              />
            )}

            {currentView === 'gideon' && (
              <GideonWorkspace
                principal={principal}
                activeProjectId={activeProjectId}
                onNavigateToProject={(projId) => {
                  setActiveProjectId(projId);
                  setCurrentView('projects');
                }}
                onNavigateToChat={() => setCurrentView('chat')}
              />
            )}

            {currentView === 'deviceCenter' && (
              <NetworkDeviceControlCenter
                principal={principal}
              />
            )}
          </div>
        )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
};
