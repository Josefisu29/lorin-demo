import {
  AccountStatus,
  ActionRequest,
  ALL_CANONICAL_PERMISSIONS,
  ApprovalRecord,
   assertActiveAccount,
  assertAuthenticated,
  AuditEvent,
  BackupSnapshotRecord,
  CanonicalPermissionScope,
  CanonicalRole,
  FeatureAccessMatrixRow,
  getDefaultPermissionsForRole,
  isPrivilegedUser,
  isSuperAdmin,
  isSuperAdminOrOwnerPrincipal,
  isSystemOwner,
  isSystemOwnerPrincipal,
  LorinPermission,
  ManagedUserAccount,
  normalizeCanonicalRole,
  normalizePermissionScope,
  PolicyDecision,
  Principal,
  SUPER_ADMIN_PERMISSIONS,
  SystemControlConfig,
  UserRole,
  WorkspaceView
} from '../types/lorin';
import { persistApprovalAudit, persistSecurityEventRemote, persistUserRoleAssignmentRemote } from './firebase';
import { getAuthHeaders } from './authHeaders';

/**
 * Generates a cryptographic SHA-256 hexadecimal digest for action binding
 */
export async function computeActionDigest(
  principalId: string,
  action: string,
  resource: string,
  parameters: Record<string, any> = {}
): Promise<string> {
  const canonicalString = JSON.stringify({
    principalId,
    action: action.trim().toLowerCase(),
    resource: resource.trim().toLowerCase(),
    parameters: Object.keys(parameters).sort().reduce((acc, k) => {
      acc[k] = parameters[k];
      return acc;
    }, {} as Record<string, any>)
  });

  const encoder = new TextEncoder();
  const data = encoder.encode(canonicalString);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Computes a cryptographic SHA-256 hash of the action ID and principal ID
 * for strict replay-protection tracking.
 */
export async function computeActionPrincipalHash(
  actionId: string,
  principalId: string,
  digest?: string
): Promise<string> {
  const canonical = `${actionId.trim().toLowerCase()}:${principalId.trim().toLowerCase()}:${digest || ''}`;
  const encoder = new TextEncoder();
  const data = encoder.encode(canonical);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Redacts known sensitive keywords from parameter objects
 */
export function redactSensitiveData(obj: Record<string, any>): Record<string, any> {
  const SENSITIVE_KEYS = ['secret', 'token', 'key', 'password', 'credential', 'auth', 'apikey'];
  const result: Record<string, any> = {};

  for (const [k, v] of Object.entries(obj)) {
    const isSensitive = SENSITIVE_KEYS.some(s => k.toLowerCase().includes(s));
    if (isSensitive) {
      result[k] = '[REDACTED_SECRET]';
    } else if (v && typeof v === 'object' && !Array.isArray(v)) {
      result[k] = redactSensitiveData(v);
    } else {
      result[k] = v;
    }
  }

  return result;
}

/**
 * Global Feature Access Matrix (17 Canonical Categories — LORIN V2 Section 6)
 */
export const GLOBAL_FEATURE_ACCESS_MATRIX: FeatureAccessMatrixRow[] = [
  {
    categoryId: 'cat_01_auth_profile',
    categoryNumber: 1,
    categoryTitle: 'Authentication & Profile Settings',
    description: 'Firebase sign-in, session management, operating modes, personalities, voices, and theme preferences.',
    requiredPermissions: ['conversations.read'],
    associatedModules: ['settings'],
    protectedEndpoints: ['/api/me', '/api/rbac/me'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'FULL',
      SPECIALIST: 'FULL',
      STANDARD_USER: 'FULL',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_02_conversations_chat',
    categoryNumber: 2,
    categoryTitle: 'Conversations & Chat',
    description: 'Multi-thread engineering conversations, pinned context, archived completion reports, and draft recovery.',
    requiredPermissions: ['conversations.read', 'conversations.manage'],
    associatedModules: ['chat'],
    protectedEndpoints: ['/api/gemini/infer', '/api/gemini/stream'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'FULL',
      SPECIALIST: 'FULL',
      STANDARD_USER: 'FULL',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_03_voice_multimodal',
    categoryNumber: 3,
    categoryTitle: 'Voice & Multimodal Tools',
    description: 'Tap-to-talk Web Audio DSP voice stage, speech synthesis profiles, and snapshot vision analysis.',
    requiredPermissions: ['models.use', 'conversations.manage'],
    associatedModules: ['voice', 'video'],
    protectedEndpoints: ['/api/gemini/infer'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'FULL',
      SPECIALIST: 'FULL',
      STANDARD_USER: 'LIMITED',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_04_personal_memory',
    categoryNumber: 4,
    categoryTitle: 'Personal Memory Governance',
    description: '5-domain persistent memory records, candidate confirmation/rejection, and provenance tracking.',
    requiredPermissions: ['memory.read', 'memory.manage'],
    associatedModules: ['memory'],
    protectedEndpoints: ['/api/rbac/me'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'FULL',
      SPECIALIST: 'SCOPED',
      STANDARD_USER: 'LIMITED',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_05_knowledge_vault',
    categoryNumber: 5,
    categoryTitle: 'Knowledge Vault & Document Tools',
    description: 'Private Lauren Knowledge Vault, BM25 RAG indexing, source citations, and untrusted document isolation.',
    requiredPermissions: ['knowledge.read', 'knowledge.manage'],
    associatedModules: ['vault', 'laurenVault'],
    protectedEndpoints: ['/api/rbac/me'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'FULL',
      SPECIALIST: 'SCOPED',
      STANDARD_USER: 'LIMITED',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_06_projects_workspaces',
    categoryNumber: 6,
    categoryTitle: 'Projects & Workspaces',
    description: 'Independent software project workspaces, architecture decisions, requirements, and 7-day activity sparklines.',
    requiredPermissions: ['projects.read', 'projects.manage'],
    associatedModules: ['projects'],
    protectedEndpoints: ['/api/rbac/me'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'SCOPED',
      STANDARD_USER: 'LIMITED',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_07_engineering_research',
    categoryNumber: 7,
    categoryTitle: 'Engineering & Research Tools',
    description: '15-Specialist orchestration console, CLI Terminal Workbench, and automated Verification Suite.',
    requiredPermissions: ['models.use', 'projects.read'],
    associatedModules: ['specialists', 'terminal', 'tests'],
    protectedEndpoints: ['/api/gemini/infer'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'FULL',
      SPECIALIST: 'SCOPED',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_08_provider_model_selection',
    categoryNumber: 8,
    categoryTitle: 'AI Provider & Model Selection',
    description: 'Selecting cloud server-proxy vs local Ollama runtime and switching approved model tiers.',
    requiredPermissions: ['providers.read', 'models.use'],
    associatedModules: ['chat', 'settings'],
    protectedEndpoints: ['/api/providers/status', '/api/gemini/infer'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'FULL',
      SPECIALIST: 'SCOPED',
      STANDARD_USER: 'LIMITED',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_09_provider_model_admin',
    categoryNumber: 9,
    categoryTitle: 'Provider & Model Administration',
    description: 'Configuring global provider routing policies, MOSAIRA AI Lab datasets, LoRA adapters, and model registry.',
    requiredPermissions: ['providers.manage', 'models.configure'],
    associatedModules: ['mosairaLab', 'ownerGateway'],
    protectedEndpoints: ['/api/rbac/system-config', '/api/mosaira/keys'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'NONE',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_10_task_orchestration',
    categoryNumber: 10,
    categoryTitle: 'Task Creation, Execution & Cancellation',
    description: 'Durable task queue state machine and daily engineering goals tracker (up to 5 daily tasks).',
    requiredPermissions: ['tasks.create', 'tasks.execute', 'tasks.cancel'],
    associatedModules: ['tasks'],
    protectedEndpoints: ['/api/policy/evaluate'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'FULL',
      SPECIALIST: 'SCOPED',
      STANDARD_USER: 'LIMITED',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_11_approvals_high_impact',
    categoryNumber: 11,
    categoryTitle: 'Approvals & High-Impact Operations',
    description: 'Reviewing, signing, and denying action-bound SHA-256 cryptographic approval tokens.',
    requiredPermissions: ['approvals.review'],
    associatedModules: ['security', 'ownerGateway'],
    protectedEndpoints: ['/api/policy/approvals', '/api/policy/approve', '/api/policy/deny', '/api/policy/validate-approval'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'NONE',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_12_integrations_external',
    categoryNumber: 12,
    categoryTitle: 'Integrations & External Services',
    description: 'Managing Google Drive AI_DATA_VAULT connectors, Ollama local endpoints, and permission boundaries.',
    requiredPermissions: ['integrations.manage'],
    associatedModules: ['connections', 'ownerGateway'],
    protectedEndpoints: ['/api/providers/status'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'SCOPED',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_13_user_role_management',
    categoryNumber: 13,
    categoryTitle: 'User, Role & Session Management',
    description: 'Creating/inviting accounts, assigning 6-level roles, disabling accounts, and revoking active sessions.',
    requiredPermissions: ['users.read', 'users.manage', 'roles.read', 'roles.manage'],
    associatedModules: ['ownerGateway', 'security'],
    protectedEndpoints: [
      '/api/rbac/users',
      '/api/rbac/users/invite',
      '/api/rbac/users/:uid/role',
      '/api/rbac/users/:uid/status',
      '/api/rbac/users/:uid/revoke-sessions'
    ],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'NONE',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_14_security_settings_events',
    categoryNumber: 14,
    categoryTitle: 'Security Settings, Owner Invariants & Events',
    description: 'System Owner bootstrap protection, fail-closed security configuration, and security event monitoring.',
    requiredPermissions: ['system.security.manage', 'system.owner.manage'],
    associatedModules: ['security', 'ownerGateway'],
    protectedEndpoints: ['/api/owner/emails', '/api/owner/whitelist', '/api/rbac/bootstrap-owner'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'NONE',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_15_audit_logs',
    categoryNumber: 15,
    categoryTitle: 'Tamper-Evident Audit Logs',
    description: 'Inspecting and exporting administrative, policy, and inference execution audit records.',
    requiredPermissions: ['system.audit.read'],
    associatedModules: ['security', 'ownerGateway'],
    protectedEndpoints: ['/api/policy/audits'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'NONE',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_16_usage_rate_limits_budgets',
    categoryNumber: 16,
    categoryTitle: 'Usage, Rate Limits & Budgets',
    description: 'Configuring RPM rate limits, daily token budgets, and developer API quotas.',
    requiredPermissions: ['system.configuration.manage', 'providers.manage'],
    associatedModules: ['ownerGateway'],
    protectedEndpoints: ['/api/rbac/system-config'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'NONE',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  },
  {
    categoryId: 'cat_17_backup_recovery_retention',
    categoryNumber: 17,
    categoryTitle: 'Backup, Export, Retention & Recovery Controls',
    description: 'Generating SHA-256 verified system state snapshots, retention policies, and recovery checkpoints.',
    requiredPermissions: ['backups.manage', 'system.configuration.manage'],
    associatedModules: ['ownerGateway'],
    protectedEndpoints: ['/api/rbac/backups', '/api/rbac/backups/create'],
    roleAccess: {
      SYSTEM_OWNER: 'FULL',
      SUPER_ADMIN: 'FULL',
      ADMINISTRATOR: 'DELEGATED',
      SPECIALIST: 'NONE',
      STANDARD_USER: 'NONE',
      RESTRICTED: 'NONE'
    }
  }
];

/**
 * Authoritative mapping of all 16 LORIN WorkspaceView modules to required canonical permissions.
 * SYSTEM_OWNER and SUPER_ADMIN always have unrestricted access to all 16 modules.
 */
export const MODULE_REQUIRED_PERMISSIONS: Record<WorkspaceView, CanonicalPermissionScope[]> = {
  chat: ['conversations.read'],
  projects: ['projects.read'],
  memory: ['memory.read'],
  tasks: ['tasks.create'],
  specialists: ['models.use'],
  voice: ['models.use'],
  video: ['models.use'],
  vault: ['knowledge.read'],
  laurenVault: ['knowledge.read'],
  connections: ['integrations.manage'],
  terminal: ['projects.read', 'tasks.execute'],
  tests: ['projects.read'],
  settings: ['conversations.read'],
  security: ['system.audit.read'],
  mosairaLab: ['providers.manage'],
  ownerGateway: ['users.read', 'system.configuration.manage'],
  gideon: ['gideon.access'],
  deviceCenter: ['integrations.manage']
};

export const ALL_REGISTERED_MODULES: WorkspaceView[] = [
  'chat',
  'projects',
  'memory',
  'tasks',
  'specialists',
  'voice',
  'video',
  'vault',
  'security',
  'connections',
  'terminal',
  'tests',
  'settings',
  'mosairaLab',
  'laurenVault',
  'ownerGateway',
  'gideon'
];

const AUDIT_STORAGE_KEY = 'lorin_audit_events_v2';
const APPROVALS_STORAGE_KEY = 'lorin_action_approvals_v2';
const CONSUMED_HASHES_STORAGE_KEY = 'lorin_consumed_hashes_v2';
const SYSTEM_CONFIG_STORAGE_KEY = 'lorin_system_control_config_v2';
const BACKUPS_STORAGE_KEY = 'lorin_system_backups_v2';

const DEFAULT_SYSTEM_CONTROL_CONFIG: SystemControlConfig = {
  registrationPolicy: 'INVITE_ONLY',
  requireEmailVerification: true,
  sessionTimeoutMinutes: 60,
  defaultRoutingStrategy: 'LIVE_GEMINI',
  allowedGeminiModels: ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-3.1-flash-lite-image'],
  globalRateLimitRpm: 60,
  dailyTokenBudget: 250000,
  highImpactRequiresApproval: true,
  auditRetentionDays: 90,
  updatedAt: Date.now(),
  updatedBy: 'system'
};

export class PolicyEngine {
  private static auditEvents: AuditEvent[] = [];
  private static approvals: Map<string, ApprovalRecord> = new Map();
  private static consumedActionHashes: Set<string> = new Set();
  private static managedAccounts: Map<string, ManagedUserAccount> = new Map();
  private static systemConfig: SystemControlConfig = { ...DEFAULT_SYSTEM_CONTROL_CONFIG };
  private static backupSnapshots: BackupSnapshotRecord[] = [];
  private static failClosedWhenServerOffline = false;

  static setFailClosedMode(enabled: boolean): void {
    this.failClosedWhenServerOffline = enabled;
  }

  static isFailClosedMode(): boolean {
    return this.failClosedWhenServerOffline;
  }

  static initialize(): void {
    try {
      const storedAudit = localStorage.getItem(AUDIT_STORAGE_KEY);
      if (storedAudit) {
        this.auditEvents = JSON.parse(storedAudit);
      }
      const storedApprovals = localStorage.getItem(APPROVALS_STORAGE_KEY);
      if (storedApprovals) {
        const arr: ApprovalRecord[] = JSON.parse(storedApprovals);
        arr.forEach(a => this.approvals.set(a.id, a));
      }
      const storedConsumed = localStorage.getItem(CONSUMED_HASHES_STORAGE_KEY);
      if (storedConsumed) {
        const arr: string[] = JSON.parse(storedConsumed);
        arr.forEach(h => this.consumedActionHashes.add(h));
      }
      localStorage.removeItem('lorin_rbac_managed_users_v2');
      const storedCfg = localStorage.getItem(SYSTEM_CONFIG_STORAGE_KEY);
      if (storedCfg) {
        this.systemConfig = { ...DEFAULT_SYSTEM_CONTROL_CONFIG, ...JSON.parse(storedCfg) };
      }
      const storedBackups = localStorage.getItem(BACKUPS_STORAGE_KEY);
      if (storedBackups) {
        this.backupSnapshots = JSON.parse(storedBackups);
      }
    } catch {
      this.auditEvents = [];
    }

    // Account and role data comes only from the authenticated backend.
    this.syncFromBackend();
  }

  private static persist(): void {
    try {
      localStorage.setItem(AUDIT_STORAGE_KEY, JSON.stringify(this.auditEvents.slice(-200)));
      localStorage.setItem(APPROVALS_STORAGE_KEY, JSON.stringify(Array.from(this.approvals.values())));
      localStorage.setItem(CONSUMED_HASHES_STORAGE_KEY, JSON.stringify(Array.from(this.consumedActionHashes)));
      localStorage.setItem(SYSTEM_CONFIG_STORAGE_KEY, JSON.stringify(this.systemConfig));
      localStorage.setItem(BACKUPS_STORAGE_KEY, JSON.stringify(this.backupSnapshots.slice(0, 50)));
    } catch {
      // Ignore quota errors
    }
  }

  static resetConsumedHashes(): void {
    this.consumedActionHashes.clear();
    this.persist();
  }

  static clearState(): void {
    this.auditEvents = [];
    this.approvals.clear();
    this.consumedActionHashes.clear();
    this.managedAccounts.clear();
    this.persist();
  }

  /**
   * Clears in-memory session state upon sign-out so no residual approvals or audits leak across sessions
   */
  static clearSessionCache(): void {
    this.auditEvents = [];
    this.approvals.clear();
  }

  /**
   * Centralized Permission Engine (LORIN V2 Section 5 & Section 6)
   * Evaluates:
   * - Authenticated identity
   * - Account status (ACTIVE vs RESTRICTED / DISABLED / REVOKED)
   * - Session revocation state
   * - Canonical 6-level role hierarchy
   * - Explicit & delegated permissions
   * - Resource ownership & project scope
   */
  static hasPermission(
    principal: Principal | null | undefined,
    permissionInput: CanonicalPermissionScope | LorinPermission,
    context?: {
      resourceOwnerId?: string;
      projectId?: string;
    }
  ): boolean {
    if (!principal || !principal.authenticated) return false;
    if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') return false;
    if (principal.sessionRevokedAt && principal.enrolledAt && principal.sessionRevokedAt >= principal.enrolledAt) {
      return false;
    }

    const permission = normalizePermissionScope(permissionInput);
    const canonicalRole = normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus);
    if (canonicalRole === 'RESTRICTED') return false;

    // Level 1: SYSTEM_OWNER has unrestricted access to all permissions
    if (canonicalRole === 'SYSTEM_OWNER') return true;

    // Level 2: SUPER_ADMIN has unrestricted access to all permissions EXCEPT system.owner.manage / ownership.manage
    if (canonicalRole === 'SUPER_ADMIN') {
      return permission !== 'system.owner.manage';
    }

    // Resolve effective permissions for ADMINISTRATOR, SPECIALIST, STANDARD_USER
    const effectivePermissions =
      principal.permissions && principal.permissions.length > 0
        ? principal.permissions
        : getDefaultPermissionsForRole(canonicalRole, principal.delegatedPermissions || [], principal.accountStatus || 'ACTIVE');

    if (!effectivePermissions.includes(permission)) {
      return false;
    }

    // Check project scope if specified for non-owner/non-super-admin
    if (
      context?.projectId &&
      principal.projectScopes &&
      principal.projectScopes.length > 0 &&
      !principal.projectScopes.includes('*')
    ) {
      if (!principal.projectScopes.includes(context.projectId)) {
        return false;
      }
    }

    // Check resource ownership if specified for STANDARD_USER
    if (
      canonicalRole === 'STANDARD_USER' &&
      context?.resourceOwnerId &&
      context.resourceOwnerId !== principal.id
    ) {
      return false;
    }

    return true;
  }

  static requirePermission(
    principal: Principal | null | undefined,
    permissionInput: CanonicalPermissionScope | LorinPermission,
    context?: {
      resourceOwnerId?: string;
      projectId?: string;
    }
  ): void {
    assertActiveAccount(principal);
    if (!this.hasPermission(principal, permissionInput, context)) {
      const role = normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus);
      throw new Error(`Forbidden: role ${role} lacks required permission '${permissionInput}'.`);
    }
  }

  /**
   * Evaluates whether a principal is authorized to access a registered LORIN application module (WorkspaceView).
   * SYSTEM_OWNER and SUPER_ADMIN have full access to ALL 16 registered modules.
   */
  static canAccessModule(principal: Principal | null | undefined, view: WorkspaceView): boolean {
    if (!principal || !principal.authenticated) return false;
    if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') return false;
    if (principal.sessionRevokedAt && principal.enrolledAt && principal.sessionRevokedAt >= principal.enrolledAt) {
      return false;
    }

    const canonicalRole = normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus);
    if (canonicalRole === 'RESTRICTED') return false;

    // SYSTEM_OWNER and SUPER_ADMIN have unrestricted access to all LORIN modules and control planes
    if (canonicalRole === 'SYSTEM_OWNER' || canonicalRole === 'SUPER_ADMIN') {
      return true;
    }

    const requiredPerms = MODULE_REQUIRED_PERMISSIONS[view] || [];
    if (requiredPerms.length === 0) return true;

    // For ownerGateway, allow ADMINISTRATOR if they have at least one delegated admin permission (users.read or system.configuration.manage)
    if (view === 'ownerGateway') {
      return canonicalRole === 'ADMINISTRATOR' && requiredPerms.some(p => this.hasPermission(principal, p));
    }

    return requiredPerms.every(p => this.hasPermission(principal, p));
  }

  static getGlobalFeatureAccessMatrix(): FeatureAccessMatrixRow[] {
    return GLOBAL_FEATURE_ACCESS_MATRIX;
  }

  static getManagedAccounts(): ManagedUserAccount[] {
    return Array.from(this.managedAccounts.values()).sort((a, b) => {
      const order: CanonicalRole[] = [
        'SYSTEM_OWNER',
        'SUPER_ADMIN',
        'ADMINISTRATOR',
        'SPECIALIST',
        'STANDARD_USER',
        'RESTRICTED'
      ];
      const diff = order.indexOf(a.canonicalRole) - order.indexOf(b.canonicalRole);
      return diff !== 0 ? diff : b.updatedAt - a.updatedAt;
    });
  }

  static countActiveSystemOwners(): number {
    return Array.from(this.managedAccounts.values()).filter(
      a => a.canonicalRole === 'SYSTEM_OWNER' && a.accountStatus === 'ACTIVE'
    ).length;
  }

  /**
   * Assigns a role to a target account with strict enforcement of System Owner & Super Admin invariants.
   */
  static async assignAccountRole(
    actor: Principal,
    targetUid: string,
    desiredRoleInput: CanonicalRole | UserRole,
    delegatedPermissions?: CanonicalPermissionScope[],
    projectScopes?: string[]
  ): Promise<{ success: boolean; message: string; account?: ManagedUserAccount }> {
    if (!actor || !actor.authenticated) {
      return { success: false, message: 'Authentication required.' };
    }
    if (actor.accountStatus === 'DISABLED' || actor.accountStatus === 'REVOKED') {
      return { success: false, message: 'Forbidden: Actor account is disabled or revoked.' };
    }

    const actorCanonical = normalizeCanonicalRole(actor.canonicalRole || actor.role, actor.accountStatus);
    if (actorCanonical !== 'SYSTEM_OWNER' && actorCanonical !== 'SUPER_ADMIN') {
      this.recordAudit({
        principalId: actor.id,
        role: actor.role,
        action: 'rbac_role_assignment_denied',
        resource: `iam://users/${targetUid}`,
        decision: 'DENY',
        reason: `Role ${actorCanonical} is not authorized to assign roles.`
      });
      return { success: false, message: 'Forbidden: Only System Owner or Super Admin can assign roles.' };
    }

    const target = this.managedAccounts.get(targetUid) ||
      Array.from(this.managedAccounts.values()).find(u => u.email.toLowerCase() === targetUid.toLowerCase());

    if (!target) {
      return { success: false, message: 'Target user account not found.' };
    }

    const desiredRole = normalizeCanonicalRole(desiredRoleInput, 'ACTIVE');

    // Invariant 1: SUPER_ADMIN cannot promote itself or anyone else to SYSTEM_OWNER or SUPER_ADMIN
    if ((desiredRole === 'SYSTEM_OWNER' || desiredRole === 'SUPER_ADMIN') && actorCanonical !== 'SYSTEM_OWNER') {
      this.recordAudit({
        principalId: actor.id,
        role: actor.role,
        action: 'rbac_privilege_escalation_blocked',
        resource: `iam://users/${target.email}`,
        decision: 'DENY',
        reason: `Security Invariant Violation: Super Admin attempted to promote account to ${desiredRole}.`
      });
      return {
        success: false,
        message:
          desiredRole === 'SYSTEM_OWNER'
            ? 'Security Invariant Violation: Super Admin cannot promote itself or any user to SYSTEM_OWNER.'
            : 'Security Invariant Violation: Only System Owner can appoint or promote a user to SUPER_ADMIN.'
      };
    }

    // Invariant 2: SUPER_ADMIN cannot modify or demote an existing SYSTEM_OWNER or SUPER_ADMIN
    if ((target.canonicalRole === 'SYSTEM_OWNER' || target.canonicalRole === 'SUPER_ADMIN') && actorCanonical !== 'SYSTEM_OWNER') {
      this.recordAudit({
        principalId: actor.id,
        role: actor.role,
        action: 'rbac_owner_modification_blocked',
        resource: `iam://users/${target.email}`,
        decision: 'DENY',
        reason: `Security Invariant Violation: Super Admin attempted to modify a ${target.canonicalRole} account.`
      });
      return {
        success: false,
        message:
          target.canonicalRole === 'SYSTEM_OWNER'
            ? 'Security Invariant Violation: Super Admin cannot demote or modify a SYSTEM_OWNER account.'
            : 'Security Invariant Violation: Only System Owner can revoke or modify a SUPER_ADMIN account.'
      };
    }

    // Invariant 3: Primary System Owner cannot be demoted
    if (target.isPrimarySystemOwner && desiredRole !== 'SYSTEM_OWNER') {
      return {
        success: false,
        message: 'Security Invariant Violation: Primary System Owner (last active SYSTEM_OWNER) account cannot be demoted.'
      };
    }

    // Invariant 4: Cannot demote the last active SYSTEM_OWNER
    if (target.canonicalRole === 'SYSTEM_OWNER' && desiredRole !== 'SYSTEM_OWNER' && this.countActiveSystemOwners() <= 1) {
      return {
        success: false,
        message: 'Security Invariant Violation: Cannot demote or remove the last active SYSTEM_OWNER.'
      };
    }

    // Try backend first when in browser
    if (typeof window !== 'undefined') {
      try {
        const res = await fetch(`/api/rbac/users/${encodeURIComponent(target.uid)}/role`, {
          method: 'PUT',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            role: desiredRole,
            delegatedPermissions,
            projectScopes
          })
        });
        if (res.ok) {
          const data = await res.json();
          if (data.account) {
            this.managedAccounts.set(data.account.uid, data.account);
            this.persist();
            persistUserRoleAssignmentRemote(data.account, actor.id).catch(() => {});
          }
          return { success: true, message: data.message, account: data.account };
        }
      } catch {
        // Fallback to local state below
      }
    }

    const cleanDelegated = (delegatedPermissions ?? target.delegatedPermissions).filter(
      p => p !== 'system.owner.manage'
    );
    target.canonicalRole = desiredRole;
    target.legacyRole = desiredRole === 'SYSTEM_OWNER' ? 'OWNER' : desiredRole === 'SPECIALIST' ? 'ENGINEER' : desiredRole;
    target.delegatedPermissions = cleanDelegated;
    target.permissions = getDefaultPermissionsForRole(desiredRole, cleanDelegated, target.accountStatus);
    if (projectScopes) {
      target.projectScopes = projectScopes;
    }
    target.updatedAt = Date.now();

    this.managedAccounts.set(target.uid, target);
    this.persist();
    persistUserRoleAssignmentRemote(target, actor.id).catch(() => {});

    this.recordAudit({
      principalId: actor.id,
      role: actor.role,
      action: 'rbac_role_updated',
      resource: `iam://users/${target.email}`,
      decision: 'EXECUTED',
      reason: `Assigned role ${desiredRole} to ${target.email}`
    });

    return {
      success: true,
      message: `Updated ${target.email} to role ${desiredRole}.`,
      account: target
    };
  }

  static async inviteManagedAccount(
    actor: Principal,
    params: {
      email: string;
      displayName?: string;
      role: CanonicalRole;
      delegatedPermissions?: CanonicalPermissionScope[];
      projectScopes?: string[];
    }
  ): Promise<{ success: boolean; message: string; account?: ManagedUserAccount }> {
    if (!actor || !actor.authenticated) {
      return { success: false, message: 'Authentication required.' };
    }
    const actorCanonical = normalizeCanonicalRole(actor.canonicalRole || actor.role, actor.accountStatus);
    if (actorCanonical !== 'SYSTEM_OWNER' && actorCanonical !== 'SUPER_ADMIN') {
      return { success: false, message: 'Forbidden: Only System Owner or Super Admin can invite accounts.' };
    }
    if ((params.role === 'SYSTEM_OWNER' || params.role === 'SUPER_ADMIN') && actorCanonical !== 'SYSTEM_OWNER') {
      return {
        success: false,
        message:
          params.role === 'SYSTEM_OWNER'
            ? 'Security Invariant Violation: Super Admin cannot create or promote a SYSTEM_OWNER account.'
            : 'Security Invariant Violation: Only System Owner can appoint or invite a SUPER_ADMIN account.'
      };
    }

    const email = (params.email || '').trim().toLowerCase();
    if (!email || !email.includes('@')) {
      return { success: false, message: 'Valid email address is required.' };
    }

    if (typeof window !== 'undefined') {
      try {
        const res = await fetch('/api/rbac/users/invite', {
          method: 'POST',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify(params)
        });
        if (res.ok) {
          const data = await res.json();
          if (data.account) {
            this.managedAccounts.set(data.account.uid, data.account);
            this.persist();
            persistUserRoleAssignmentRemote(data.account, actor.id).catch(() => {});
          }
          return { success: true, message: data.message, account: data.account };
        }
      } catch {
        // Local fallback below
      }
    }

    const delegated = (params.delegatedPermissions || []).filter(p => p !== 'system.owner.manage');
    const newAcc: ManagedUserAccount = {
      uid: `usr_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`,
      email,
      displayName: params.displayName?.trim() || email.split('@')[0] || 'Invited User',
      canonicalRole: params.role,
      legacyRole: params.role === 'SYSTEM_OWNER' ? 'OWNER' : params.role === 'SPECIALIST' ? 'ENGINEER' : params.role,
      accountStatus: 'ACTIVE',
      emailVerified: true,
      permissions: getDefaultPermissionsForRole(params.role, delegated, 'ACTIVE'),
      delegatedPermissions: delegated,
      projectScopes: params.projectScopes && params.projectScopes.length > 0 ? params.projectScopes : ['proj_lorin_core'],
      isPrimarySystemOwner: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      invitedBy: actor.email
    };

    this.managedAccounts.set(newAcc.uid, newAcc);
    this.persist();
    persistUserRoleAssignmentRemote(newAcc, actor.id).catch(() => {});

    this.recordAudit({
      principalId: actor.id,
      role: actor.role,
      action: 'rbac_user_invited',
      resource: `iam://users/${email}`,
      decision: 'EXECUTED',
      reason: `Invited ${email} with role ${params.role}`
    });

    return {
      success: true,
      message: `Account ${email} provisioned with role ${params.role}.`,
      account: newAcc
    };
  }

  static async updateAccountStatus(
    actor: Principal,
    targetUid: string,
    newStatus: AccountStatus
  ): Promise<{ success: boolean; message: string; account?: ManagedUserAccount }> {
    if (!actor || !actor.authenticated) {
      return { success: false, message: 'Authentication required.' };
    }
    const actorCanonical = normalizeCanonicalRole(actor.canonicalRole || actor.role, actor.accountStatus);
    if (actorCanonical !== 'SYSTEM_OWNER' && actorCanonical !== 'SUPER_ADMIN') {
      return { success: false, message: 'Forbidden: Only System Owner or Super Admin can update account status.' };
    }

    const target = this.managedAccounts.get(targetUid) ||
      Array.from(this.managedAccounts.values()).find(u => u.email.toLowerCase() === targetUid.toLowerCase());
    if (!target) {
      return { success: false, message: 'Target user account not found.' };
    }

    if ((target.canonicalRole === 'SYSTEM_OWNER' || target.canonicalRole === 'SUPER_ADMIN') && actorCanonical !== 'SYSTEM_OWNER') {
      return {
        success: false,
        message:
          target.canonicalRole === 'SYSTEM_OWNER'
            ? 'Security Invariant Violation: Super Admin cannot disable or modify a SYSTEM_OWNER account.'
            : 'Security Invariant Violation: Only System Owner can disable or revoke a SUPER_ADMIN account.'
      };
    }

    if (target.isPrimarySystemOwner && newStatus !== 'ACTIVE') {
      return {
        success: false,
        message: 'Security Invariant Violation: Primary System Owner account cannot be disabled or revoked.'
      };
    }

    if (target.canonicalRole === 'SYSTEM_OWNER' && newStatus !== 'ACTIVE' && this.countActiveSystemOwners() <= 1) {
      return {
        success: false,
        message: 'Security Invariant Violation: Cannot disable or revoke the last active SYSTEM_OWNER.'
      };
    }

    if (typeof window !== 'undefined') {
      try {
        const res = await fetch(`/api/rbac/users/${encodeURIComponent(target.uid)}/status`, {
          method: 'PUT',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ status: newStatus })
        });
        if (res.ok) {
          const data = await res.json();
          if (data.account) {
            this.managedAccounts.set(data.account.uid, data.account);
            this.persist();
            persistUserRoleAssignmentRemote(data.account, actor.id).catch(() => {});
          }
          return { success: true, message: data.message, account: data.account };
        }
      } catch {
        // Fallback below
      }
    }

    target.accountStatus = newStatus;
    target.permissions = getDefaultPermissionsForRole(target.canonicalRole, target.delegatedPermissions, newStatus);
    if (newStatus === 'DISABLED' || newStatus === 'REVOKED') {
      target.sessionRevokedAt = Date.now();
    }
    target.updatedAt = Date.now();

    this.managedAccounts.set(target.uid, target);
    this.persist();
    persistUserRoleAssignmentRemote(target, actor.id).catch(() => {});

    this.recordAudit({
      principalId: actor.id,
      role: actor.role,
      action: 'rbac_account_status_changed',
      resource: `iam://users/${target.email}`,
      decision: 'EXECUTED',
      reason: `Changed account status of ${target.email} to ${newStatus}`
    });

    return {
      success: true,
      message: `Account ${target.email} status updated to ${newStatus}.`,
      account: target
    };
  }

  static async revokeAccountSessions(
    actor: Principal,
    targetUid: string
  ): Promise<{ success: boolean; message: string; revokedAt?: number }> {
    if (!actor || !actor.authenticated) {
      return { success: false, message: 'Authentication required.' };
    }
    const actorCanonical = normalizeCanonicalRole(actor.canonicalRole || actor.role, actor.accountStatus);
    if (actorCanonical !== 'SYSTEM_OWNER' && actorCanonical !== 'SUPER_ADMIN') {
      return { success: false, message: 'Forbidden: Only System Owner or Super Admin can revoke sessions.' };
    }

    const target = this.managedAccounts.get(targetUid) ||
      Array.from(this.managedAccounts.values()).find(u => u.email.toLowerCase() === targetUid.toLowerCase());
    if (!target) {
      return { success: false, message: 'Target user account not found.' };
    }

    if (target.canonicalRole === 'SYSTEM_OWNER' && actorCanonical !== 'SYSTEM_OWNER') {
      return {
        success: false,
        message: 'Security Invariant Violation: Super Admin cannot revoke SYSTEM_OWNER sessions.'
      };
    }

    if (typeof window !== 'undefined') {
      try {
        const res = await fetch(`/api/rbac/users/${encodeURIComponent(target.uid)}/revoke-sessions`, {
          method: 'POST',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' })
        });
        if (res.ok) {
          const data = await res.json();
          if (data.account) {
            this.managedAccounts.set(data.account.uid, data.account);
            this.persist();
          }
          return { success: true, message: data.message, revokedAt: data.revokedAt };
        }
      } catch {
        // Fallback below
      }
    }

    const revokedAt = Date.now();
    target.sessionRevokedAt = revokedAt;
    target.updatedAt = revokedAt;
    this.managedAccounts.set(target.uid, target);
    this.persist();

    this.recordAudit({
      principalId: actor.id,
      role: actor.role,
      action: 'rbac_sessions_revoked',
      resource: `iam://users/${target.email}/sessions`,
      decision: 'EXECUTED',
      reason: `Revoked active sessions for ${target.email}`
    });

    return {
      success: true,
      message: `Active sessions revoked for ${target.email}.`,
      revokedAt
    };
  }

  static getSystemControlConfig(): SystemControlConfig {
    return { ...this.systemConfig };
  }

  static async updateSystemControlConfig(
    actor: Principal,
    partial: Partial<SystemControlConfig>
  ): Promise<{ success: boolean; message: string; config?: SystemControlConfig }> {
    if (!this.hasPermission(actor, 'system.configuration.manage')) {
      return { success: false, message: 'Forbidden: Missing system.configuration.manage permission.' };
    }

    this.systemConfig = {
      ...this.systemConfig,
      ...partial,
      updatedAt: Date.now(),
      updatedBy: actor.email || actor.id
    };
    this.persist();

    if (typeof window !== 'undefined') {
      try {
        await fetch('/api/rbac/system-config', {
          method: 'PUT',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify(this.systemConfig)
        });
      } catch {
        // Local state updated
      }
    }

    this.recordAudit({
      principalId: actor.id,
      role: actor.role,
      action: 'system_control_config_updated',
      resource: 'system://control_config',
      decision: 'EXECUTED',
      reason: `Updated system control plane configuration`
    });

    return {
      success: true,
      message: 'System control configuration updated and synchronized.',
      config: this.systemConfig
    };
  }

  static getBackupSnapshots(): BackupSnapshotRecord[] {
    return [...this.backupSnapshots];
  }

  static async createBackupSnapshot(
    actor: Principal,
    label = 'Manual Control Plane Snapshot'
  ): Promise<{ success: boolean; message: string; snapshot?: BackupSnapshotRecord }> {
    if (!this.hasPermission(actor, 'backups.manage')) {
      return { success: false, message: 'Forbidden: Missing backups.manage permission.' };
    }

    const digest = await computeActionDigest(actor.id, 'create_backup', label, {
      users: this.managedAccounts.size,
      approvals: this.approvals.size,
      audits: this.auditEvents.length
    });

    const snapshot: BackupSnapshotRecord = {
      id: `bkp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      label,
      createdBy: actor.email || actor.id,
      createdByRole: normalizeCanonicalRole(actor.canonicalRole || actor.role, actor.accountStatus),
      createdAt: Date.now(),
      counts: {
        managedUsers: this.managedAccounts.size,
        approvals: this.approvals.size,
        auditEvents: this.auditEvents.length
      },
      integritySha256: digest
    };

    this.backupSnapshots.unshift(snapshot);
    this.persist();

    this.recordAudit({
      principalId: actor.id,
      role: actor.role,
      action: 'backup_snapshot_created',
      resource: `backup://${snapshot.id}`,
      decision: 'EXECUTED',
      reason: `Created verified state snapshot '${label}' (${digest.slice(0, 12)}...)`,
      digest
    });

    return {
      success: true,
      message: `Backup snapshot ${snapshot.id} created and verified.`,
      snapshot
    };
  }

  static async syncFromBackend(): Promise<void> {
    if (typeof window === 'undefined') return;
    try {
      const headers = await getAuthHeaders();
      const [appRes, audRes, usrRes, cfgRes] = await Promise.all([
        fetch('/api/policy/approvals', { headers }).catch(() => null),
        fetch('/api/policy/audits', { headers }).catch(() => null),
        fetch('/api/rbac/users', { headers }).catch(() => null),
        fetch('/api/rbac/system-config', { headers }).catch(() => null)
      ]);

      if (appRes && appRes.ok) {
        const { approvals } = await appRes.json();
        if (Array.isArray(approvals)) {
          approvals.forEach((a: ApprovalRecord) => {
            this.approvals.set(a.id, a);
          });
        }
      }

      if (audRes && audRes.ok) {
        const { auditEvents } = await audRes.json();
        if (Array.isArray(auditEvents)) {
          const existingIds = new Set(this.auditEvents.map(e => e.id));
          const newEvents = auditEvents.filter((e: AuditEvent) => !existingIds.has(e.id));
          this.auditEvents = [...newEvents, ...this.auditEvents].slice(0, 300);
        }
      }

      if (usrRes && usrRes.ok) {
        const { users } = await usrRes.json();
        if (Array.isArray(users) && users.length > 0) {
          users.forEach((u: ManagedUserAccount) => {
            this.managedAccounts.set(u.uid, u);
          });
        }
      }

      if (cfgRes && cfgRes.ok) {
        const { config } = await cfgRes.json();
        if (config) {
          this.systemConfig = { ...this.systemConfig, ...config };
        }
      }

      this.persist();
    } catch (e) {
      console.warn('Backend policy sync deferred:', e);
    }
  }

  /**
   * Evaluates action against authoritative server policy when reachable,
   * with fail-closed option or local policy boundary enforcement for client isolation and testing.
   */
  static async evaluateAction(
    principal: Principal,
    request: ActionRequest,
    callerSuppliedFlags?: Record<string, any>
  ): Promise<{
    decision: PolicyDecision;
    reason: string;
    approvalRecord?: ApprovalRecord;
    digest: string;
  }> {
    const digest = await computeActionDigest(principal.id, request.action, request.resource, request.parameters);

    // Pre-check disabled / revoked account status before network or local evaluation
    if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') {
      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'DENY',
        reason: `Account status is ${principal.accountStatus}. All protected operations are rejected.`,
        digest
      });
      return {
        decision: 'DENY',
        reason: `Forbidden: Account status is ${principal.accountStatus}. Access has been revoked.`,
        digest
      };
    }

    if (principal.sessionRevokedAt && principal.enrolledAt && principal.sessionRevokedAt >= principal.enrolledAt) {
      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'DENY',
        reason: 'Session token has been revoked by an administrator.',
        digest
      });
      return {
        decision: 'DENY',
        reason: 'Forbidden: Session has been revoked. Please re-authenticate.',
        digest
      };
    }

    // 1. Try server-authoritative evaluation
    if (typeof window !== 'undefined') {
      try {
        const res = await fetch('/api/policy/evaluate', {
          method: 'POST',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ request, callerSuppliedFlags })
        });
        if (res.ok) {
          const data = await res.json();
          if (data && data.decision) {
            if (data.approvalRecord) {
              this.approvals.set(data.approvalRecord.id, data.approvalRecord);
              this.persist();
            }
            this.recordAudit({
              principalId: principal.id,
              role: principal.role,
              action: request.action,
              resource: request.resource,
              decision: data.decision,
              reason: `[Server Authority] ${data.reason}`,
              digest: data.digest
            });
            return data;
          }
        } else if (this.failClosedWhenServerOffline) {
          return {
            decision: 'DENY',
            reason: `Fail-closed security boundary: Authoritative policy server rejected evaluation (HTTP ${res.status}).`,
            digest
          };
        }
      } catch (e) {
        if (this.failClosedWhenServerOffline) {
          this.recordAudit({
            principalId: principal.id,
            role: principal.role,
            action: request.action,
            resource: request.resource,
            decision: 'DENY',
            reason: 'Fail-closed security boundary: Authoritative policy server unreachable.',
            digest
          });
          return {
            decision: 'DENY',
            reason: 'Fail-closed security boundary: Authoritative policy server is unreachable.',
            digest
          };
        }
        console.warn('Server policy evaluate network call failed, falling back to local policy:', e);
      }
    } else if (this.failClosedWhenServerOffline) {
      return {
        decision: 'DENY',
        reason: 'Fail-closed security boundary: Authoritative server policy service is offline.',
        digest
      };
    }

    // Local Policy Boundary Fallback (matches server invariants)
    const actionPrincipalHash = await computeActionPrincipalHash(request.action, principal.id, digest);

    // Rule 0: Replay Protection - Deny execution if action ID and principal ID hash was already consumed
    if (this.consumedActionHashes.has(actionPrincipalHash)) {
      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'DENY',
        reason: `Security violation: Replay attack detected. Action ID '${request.action}' has already been executed by principal '${principal.id}'.`,
        digest
      });
      return {
        decision: 'DENY',
        reason: 'Security violation: Replay attack detected. Action ID has already been executed by principal.',
        digest
      };
    }

    // Rule 1: Deny unauthenticated access
    if (!principal.authenticated) {
      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'DENY',
        reason: 'Authentication required. Principal identity is unverified.',
        digest
      });
      return {
        decision: 'DENY',
        reason: 'Authentication required. Principal identity is unverified.',
        digest
      };
    }

    // Rule 2: Reject caller-supplied user_authorized bypass flags
    if (callerSuppliedFlags && (callerSuppliedFlags.user_authorized === true || callerSuppliedFlags.bypass_policy === true)) {
      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'DENY',
        reason: 'Security violation: Caller attempted client-side user_authorized bypass flag',
        digest
      });
      return {
        decision: 'DENY',
        reason: 'Security violation: Client-supplied user_authorized flags are untrusted and rejected by policy.',
        digest
      };
    }

    // Rule 3: High impact operations require explicit approval
    const HIGH_IMPACT_ACTIONS = [
      'deploy_production',
      'purge_database',
      'delete_file',
      'modify_permissions',
      'execute_shell',
      'reveal_credentials',
      'transfer_funds'
    ];

    const isHighImpact = HIGH_IMPACT_ACTIONS.some(a => request.action.toLowerCase().includes(a)) ||
      request.riskLevel === 'HIGH' ||
      request.riskLevel === 'CRITICAL';

    if (isHighImpact) {
      // Check if an existing approved token exists with matching digest
      const existingApproval = Array.from(this.approvals.values()).find(
        app => app.actionDigest === digest &&
          app.status === 'APPROVED' &&
          app.expiresAt > Date.now()
      );

      if (existingApproval) {
        // Explicit Action ID & Resource Replay Protection Check
        if (existingApproval.action.toLowerCase() !== request.action.toLowerCase() ||
            existingApproval.resource.toLowerCase() !== request.resource.toLowerCase()) {
          this.recordAudit({
            principalId: principal.id,
            role: principal.role,
            action: request.action,
            resource: request.resource,
            decision: 'DENY',
            reason: `Replay attack blocked: Approval action ID (${existingApproval.action}) does not match request action (${request.action})`,
            digest
          });
          return {
            decision: 'DENY',
            reason: 'Security violation: Approval record action ID mismatch.',
            digest
          };
        }

        // Single-use consumption & Action-Principal Hash Recording
        existingApproval.status = 'CONSUMED';
        this.consumedActionHashes.add(actionPrincipalHash);
        this.persist();

        this.recordAudit({
          principalId: principal.id,
          role: principal.role,
          action: request.action,
          resource: request.resource,
          decision: 'ALLOW',
          reason: `Action authorized via valid single-use cryptographic approval ${existingApproval.id}. Token consumed.`,
          digest
        });

        return {
          decision: 'ALLOW',
          reason: 'Approved by owner via cryptographic digest match. Token consumed.',
          approvalRecord: existingApproval,
          digest
        };
      }

      // Create a pending action-bound approval record
      const approvalRecord: ApprovalRecord = {
        id: `appr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        actionDigest: digest,
        action: request.action,
        resource: request.resource,
        principalId: principal.id,
        riskLevel: request.riskLevel,
        parameters: redactSensitiveData(request.parameters || {}),
        createdAt: Date.now(),
        expiresAt: Date.now() + 15 * 60 * 1000,
        status: 'PENDING'
      };

      this.approvals.set(approvalRecord.id, approvalRecord);
      this.persist();
      try {
        persistApprovalAudit(principal.id, approvalRecord).catch(console.warn);
      } catch {}

      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'REQUIRES_APPROVAL',
        reason: `High risk operation requires explicit owner confirmation. Approval ID: ${approvalRecord.id}`,
        digest
      });

      return {
        decision: 'REQUIRES_APPROVAL',
        reason: 'High-impact operation requires verified owner confirmation. Action-bound digest generated.',
        approvalRecord,
        digest
      };
    }

    // Rule 4: Guest / Restricted role restricted to Level 0
    const canonicalRole = normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus);
    if (principal.role === 'GUEST' || canonicalRole === 'RESTRICTED') {
      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'DENY',
        reason: 'Guest/Restricted principal restricted to read-only observation',
        digest
      });
      return {
        decision: 'DENY',
        reason: 'Guests are restricted to Level 0 (Observe) permissions.',
        digest
      };
    }

    this.recordAudit({
      principalId: principal.id,
      role: principal.role,
      action: request.action,
      resource: request.resource,
      decision: 'ALLOW',
      reason: 'Action validated against standard policy rules',
      digest
    });

    return {
      decision: 'ALLOW',
      reason: 'Action authorized under active policy privileges.',
      digest
    };
  }

  /**
   * Approves a pending action-bound approval record (System Owner or Super Admin only)
   */
  static async approveAction(approvalId: string, principal: Principal): Promise<{ success: boolean; message: string }> {
    if (!isSuperAdminOrOwnerPrincipal(principal)) {
      return { success: false, message: 'Only an authenticated OWNER or SUPER_ADMIN can approve actions.' };
    }

    // Try server backend
    if (typeof window !== 'undefined') {
      try {
        const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
        const res = await fetch('/api/policy/approve', {
          method: 'POST',
          headers,
          body: JSON.stringify({ approvalId })
        });
        if (res.ok) {
          const data = await res.json();
          await this.syncFromBackend();
          fetch('/api/gideon/events', {
            method: 'POST',
            headers,
            body: JSON.stringify({
              projectId: 'proj_lorin_core',
              category: 'security',
              title: `High-Impact Action Approved: ${approvalId}`,
              summary: `Authorized principal ${principal.email || principal.id} approved cryptographic action record ${approvalId}.`,
              sourceType: 'security',
              verificationStatus: 'verified',
              tags: ['security', 'approval', 'lena-guardian']
            })
          }).catch(() => {});
          return { success: true, message: data.message || 'Action approved on server.' };
        } else {
          const errData = await res.json().catch(() => ({}));
          return { success: false, message: errData.error || 'Server rejected approval.' };
        }
      } catch (e) {
        console.warn('Backend approval request failed, falling back to local:', e);
      }
    }

    // Local fallback
    const record = this.approvals.get(approvalId);
    if (!record) {
      return { success: false, message: 'Approval record not found.' };
    }

    if (record.status !== 'PENDING') {
      return { success: false, message: `Record is already ${record.status}. Cannot re-approve.` };
    }

    if (record.expiresAt < Date.now()) {
      record.status = 'EXPIRED';
      this.persist();
      return { success: false, message: 'Approval record has expired.' };
    }

    record.status = 'APPROVED';
    record.approvedBy = principal.id;
    record.approvedAt = Date.now();
    this.persist();
    try {
      persistApprovalAudit(principal.id, record).catch(console.warn);
    } catch {}

    this.recordAudit({
      principalId: principal.id,
      role: principal.role,
      action: `approve_${record.action}`,
      resource: record.resource,
      decision: 'ALLOW',
      reason: `Authorized ${principal.canonicalRole || principal.role} approved cryptographic action digest ${record.actionDigest.slice(0, 12)}...`,
      digest: record.actionDigest
    });

    return { success: true, message: 'Action approved successfully. Ready for single-use execution.' };
  }

  /**
   * Validates an ApprovalRecord for single-use execution, enforcing server-side action ID,
   * resource, and cryptographic digest checks to prevent action ID replay and substitution attacks.
   */
  static async validateApprovalForExecution(
    approvalId: string,
    request: ActionRequest,
    principal: Principal
  ): Promise<{
    valid: boolean;
    reason: string;
    approvalRecord?: ApprovalRecord;
    digest?: string;
  }> {
    if (!principal || !principal.authenticated) {
      return { valid: false, reason: 'Authentication required for approval validation.' };
    }
    if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') {
      return { valid: false, reason: 'Account is disabled or revoked.' };
    }

    const digest = await computeActionDigest(
      principal.id,
      request.action,
      request.resource,
      request.parameters || {}
    );
    const actionPrincipalHash = await computeActionPrincipalHash(request.action, principal.id, digest);

    if (this.consumedActionHashes.has(actionPrincipalHash)) {
      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'DENY',
        reason: `Replay attack blocked: Action ID '${request.action}' and principal ID hash has already been executed.`,
        digest
      });
      return {
        valid: false,
        reason: `Replay attack blocked: Duplicate execution detected. Action ID '${request.action}' has already been executed.`
      };
    }

    // Attempt server-side authoritative validation
    if (typeof window !== 'undefined') {
      try {
        const res = await fetch('/api/policy/validate-approval', {
          method: 'POST',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ approvalId, request })
        });
        if (res.ok) {
          const data = await res.json();
          if (data.approvalRecord) {
            this.approvals.set(data.approvalRecord.id, data.approvalRecord);
            this.consumedActionHashes.add(actionPrincipalHash);
            this.persist();
          }
          return data;
        } else {
          const errData = await res.json().catch(() => ({}));
          return { valid: false, reason: errData.error || 'Server rejected approval validation.' };
        }
      } catch (e) {
        console.warn('Server validation request deferred, checking local policy:', e);
      }
    }

    // Local policy validation fallback
    const record = this.approvals.get(approvalId);
    if (!record) {
      return { valid: false, reason: 'Approval record not found.' };
    }

    if (record.status !== 'APPROVED') {
      return { valid: false, reason: `Approval record status is ${record.status}, expected APPROVED.` };
    }

    if (record.expiresAt < Date.now()) {
      record.status = 'EXPIRED';
      this.persist();
      return { valid: false, reason: 'Approval record has expired.' };
    }

    // Explicit Action ID Replay Protection Check
    if (record.action.toLowerCase() !== request.action.toLowerCase()) {
      this.recordAudit({
        principalId: principal.id,
        role: principal.role,
        action: request.action,
        resource: request.resource,
        decision: 'DENY',
        reason: `Replay attack prevented: Approval action ID (${record.action}) does not match target action (${request.action}).`,
        digest
      });
      return {
        valid: false,
        reason: `Replay attack blocked: Approval action ID '${record.action}' does not match target action '${request.action}'.`
      };
    }

    // Resource matching check
    if (record.resource.toLowerCase() !== request.resource.toLowerCase()) {
      return {
        valid: false,
        reason: `Replay attack blocked: Approval resource '${record.resource}' does not match target resource '${request.resource}'.`
      };
    }

    // Cryptographic Digest matching check
    if (record.actionDigest !== digest) {
      return {
        valid: false,
        reason: 'Security violation: Action parameters or principal mismatch cryptographic digest.'
      };
    }

    // Single-use token consumption & replay protection recording
    record.status = 'CONSUMED';
    this.consumedActionHashes.add(actionPrincipalHash);
    this.persist();

    this.recordAudit({
      principalId: principal.id,
      role: principal.role,
      action: request.action,
      resource: request.resource,
      decision: 'ALLOW',
      reason: `Approval token ${approvalId} validated and consumed for single-use execution`,
      digest
    });

    return {
      valid: true,
      reason: 'Approval token validated and consumed.',
      approvalRecord: record,
      digest
    };
  }

  /**
   * Denies a pending action-bound approval record
   */
  static async denyAction(approvalId: string, principal: Principal, reason = 'Denied by operator'): Promise<{ success: boolean; message: string }> {
    if (typeof window !== 'undefined') {
      try {
        await fetch('/api/policy/deny', {
          method: 'POST',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ approvalId, reason })
        });
      } catch (e) {
        console.warn('Backend deny request failed:', e);
      }
    }

    const record = this.approvals.get(approvalId);
    if (record) {
      record.status = 'DENIED';
      this.persist();
    }

    this.recordAudit({
      principalId: principal.id,
      role: principal.role,
      action: `deny_${record?.action || approvalId}`,
      resource: record?.resource || 'system',
      decision: 'DENY',
      reason: `Action explicitly denied: ${reason}`,
      digest: record?.actionDigest || 'none'
    });

    return { success: true, message: 'Action denied.' };
  }

  /**
   * Appends an audit event with redacted payload
   */
  static recordAudit(event: Omit<AuditEvent, 'id' | 'timestamp'>): AuditEvent {
    const fullEvent: AuditEvent = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      ...event,
      metadata: event.metadata ? redactSensitiveData(event.metadata) : undefined
    };

    this.auditEvents.unshift(fullEvent);
    this.persist();
    try {
      persistSecurityEventRemote(fullEvent).catch(() => {});
    } catch {}
    return fullEvent;
  }

  static getAuditEvents(): AuditEvent[] {
    return [...this.auditEvents];
  }

  static getPendingApprovals(): ApprovalRecord[] {
    return Array.from(this.approvals.values()).filter(a => a.status === 'PENDING' && a.expiresAt > Date.now());
  }

  static getAllApprovals(): ApprovalRecord[] {
    return Array.from(this.approvals.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  /**
   * Separately records actual execution of an approved action (distinct from approval granting)
   */
  static async recordExecution(
    approvalId: string | undefined,
    action: string,
    resource: string,
    principal: Principal,
    status: 'SUCCEEDED' | 'FAILED' = 'SUCCEEDED',
    details?: string
  ): Promise<AuditEvent> {
    if (approvalId && this.approvals.has(approvalId)) {
      const rec = this.approvals.get(approvalId)!;
      rec.executedAt = Date.now();
      rec.executionStatus = status;
      this.persist();
    }

    if (typeof window !== 'undefined') {
      try {
        await fetch('/api/policy/record-execution', {
          method: 'POST',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ approvalId, action, resource, status, details })
        });
      } catch {
        // Recorded locally below
      }
    }

    return this.recordAudit({
      principalId: principal.id,
      role: principal.role,
      action,
      resource,
      decision: 'EXECUTED',
      reason: details || `Action executed (${status})`,
      digest: approvalId || 'direct_execution'
    });
  }

  static clearAuditLogs(principal: Principal): boolean {
    if (!isSystemOwnerPrincipal(principal)) return false;
    this.auditEvents = [];
    this.persist();

    if (typeof window !== 'undefined') {
      getAuthHeaders({ 'Content-Type': 'application/json' }).then(headers =>
        fetch('/api/policy/audits', {
          method: 'DELETE',
          headers
        })
      ).catch(console.warn);
    }
    return true;
  }
}

export function hasPermission(
  principal: Principal | null | undefined,
  permission: CanonicalPermissionScope | LorinPermission,
  context?: {
    resourceOwnerId?: string;
    projectId?: string;
  }
): boolean {
  return PolicyEngine.hasPermission(principal, permission, context);
}

export function requirePermission(
  principal: Principal | null | undefined,
  permission: CanonicalPermissionScope | LorinPermission,
  context?: {
    resourceOwnerId?: string;
    projectId?: string;
  }
): void {
  PolicyEngine.requirePermission(principal, permission, context);
}

export {
  isSystemOwner,
  isSuperAdmin,
  isPrivilegedUser,
  assertAuthenticated,
  assertActiveAccount
};

// Initialize on module load
PolicyEngine.initialize();
