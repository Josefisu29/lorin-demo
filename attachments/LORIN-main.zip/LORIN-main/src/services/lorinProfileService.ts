import {
  AutonomyLevel,
  LorinOperatingMode,
  LorinPersonality,
  LorinProfileConfig,
  LorinRuntimeActivation,
  LorinVoiceProfile,
  SpecialistRole
} from '../types/lorin';

const PROFILE_STORAGE_KEY_PREFIX = 'lorin_profile_config_v2';

export interface OperatingModeDefinition {
  id: LorinOperatingMode;
  label: string;
  shortLabel: string;
  leadSpecialist: SpecialistRole;
  description: string;
  systemDirective: string;
  badgeColor: string;
}

export interface PersonalityDefinition {
  id: LorinPersonality;
  label: string;
  shortLabel: string;
  toneSummary: string;
  systemDirective: string;
}

export interface VoiceProfileDefinition {
  id: LorinVoiceProfile;
  label: string;
  shortLabel: string;
  pitch: number;
  rate: number;
  preferredVoiceKeywords: string[];
  description: string;
  samplePhrase: string;
}

export interface AutonomyLevelDefinition {
  id: AutonomyLevel;
  levelNumber: number;
  label: string;
  shortLabel: string;
  approvalRequirement: string;
  description: string;
  allowedOperations: string[];
}

export interface SecureAccessVector {
  id: string;
  title: string;
  mechanism: string;
  shortcutOrEndpoint: string;
  verificationStandard: string;
  description: string;
  availability: 'ONLINE_AND_OFFLINE' | 'ONLINE_GATEWAY' | 'LOCAL_AIRGAPPED';
}

export const LORIN_OPERATING_MODES: Record<LorinOperatingMode, OperatingModeDefinition> = {
  ARCHITECT_STRATEGY: {
    id: 'ARCHITECT_STRATEGY',
    label: 'System Architect & Technical Strategy',
    shortLabel: 'Architect',
    leadSpecialist: 'NOLAN_STRATEGIST',
    description: 'Prioritizes clean system architecture, data modeling, API boundaries, scalability, and long-term maintainability.',
    systemDirective: 'Operate in System Architect & Strategy mode (Nolan-led): evaluate data schemas, service boundaries, trade-offs, failure modes, and long-term maintainability before proposing code.',
    badgeColor: 'text-[#A9B8FF] border-[#A9B8FF]/30 bg-[#A9B8FF]/10'
  },
  DEEP_RESEARCH: {
    id: 'DEEP_RESEARCH',
    label: 'Empirical Investigator & Deep Research',
    shortLabel: 'Research',
    leadSpecialist: 'IRIS_INVESTIGATOR',
    description: 'Focuses on primary-source verification, root-cause diagnostics, benchmark analysis, and separating verified facts from hypotheses.',
    systemDirective: 'Operate in Deep Research & Investigation mode (Iris-led): rigorously distinguish verified evidence from assumptions, cite concrete implementation mechanisms, and surface edge cases.',
    badgeColor: 'text-[#66E3CB] border-[#66E3CB]/30 bg-[#66E3CB]/10'
  },
  SECURITY_GUARDIAN: {
    id: 'SECURITY_GUARDIAN',
    label: 'Zero-Trust Security & Privacy Audit',
    shortLabel: 'Guardian',
    leadSpecialist: 'LENA_GUARDIAN',
    description: 'Applies strict OWASP standards, threat modeling, RBAC boundary audits, secret hygiene, and cryptographic verification.',
    systemDirective: 'Operate in Security Guardian mode (Lena-led): audit every input, authentication flow, permission boundary, and data store against zero-trust and OWASP principles.',
    badgeColor: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10'
  },
  RAPID_PAIR_ENGINEER: {
    id: 'RAPID_PAIR_ENGINEER',
    label: 'Hands-On Pair Engineer & Implementation',
    shortLabel: 'Pair Engineer',
    leadSpecialist: 'OWEN_COORDINATOR',
    description: 'Focused on high-velocity, production-grade code implementation, step-by-step task execution, and immediate verification.',
    systemDirective: 'Operate in Rapid Pair Engineer mode (Owen-led): sequence actionable implementation steps, deliver complete production-ready code, and specify immediate verification checks.',
    badgeColor: 'text-amber-300 border-amber-500/30 bg-amber-500/10'
  },
  LEARNING_MENTOR: {
    id: 'LEARNING_MENTOR',
    label: 'Adaptive Learning & Engineering Companion',
    shortLabel: 'Mentor',
    leadSpecialist: 'RILEY_COMPANION',
    description: 'Breaks down complex engineering concepts using clear mental models, visual analogies, and guided step-by-step explanations.',
    systemDirective: 'Operate in Learning Mentor mode (Riley-led): explain both what to do and why it works, adapting depth to build lasting technical intuition.',
    badgeColor: 'text-sky-300 border-sky-500/30 bg-sky-500/10'
  }
};

export const LORIN_PERSONALITIES: Record<LorinPersonality, PersonalityDefinition> = {
  ANALYTICAL_RIGOROUS: {
    id: 'ANALYTICAL_RIGOROUS',
    label: 'Analytical & Evidence-Driven',
    shortLabel: 'Analytical',
    toneSummary: 'Precise, questioning, objective, and methodically structured.',
    systemDirective: 'Maintain an analytical, evidence-driven tone: challenge weak assumptions respectfully and back every recommendation with concrete technical rationale.'
  },
  CALM_CONVERSATIONAL: {
    id: 'CALM_CONVERSATIONAL',
    label: 'Calm & Natural Conversational',
    shortLabel: 'Conversational',
    toneSummary: 'Warm, composed, articulate, and collaborative.',
    systemDirective: 'Communicate in a calm, natural, conversational manner while preserving full technical accuracy and clarity.'
  },
  CONCISE_TACTICAL: {
    id: 'CONCISE_TACTICAL',
    label: 'Concise & High-Signal Tactical',
    shortLabel: 'Tactical',
    toneSummary: 'Direct, scannable, zero-fluff executive & engineering brief.',
    systemDirective: 'Use a concise, high-signal tactical style: prioritize direct answers, compact bullet hierarchies, and immediate code or action items.'
  },
  SOCRATIC_CHALLENGER: {
    id: 'SOCRATIC_CHALLENGER',
    label: 'Constructive Socratic Challenger',
    shortLabel: 'Socratic',
    toneSummary: 'Probes architectural blind spots, trade-offs, and hidden risks.',
    systemDirective: 'Act as a constructive Socratic partner: highlight hidden trade-offs, ask clarifying architectural questions when warranted, and stress-test assumptions.'
  },
  ADAPTIVE_COMPANION: {
    id: 'ADAPTIVE_COMPANION',
    label: 'Supportive & Adaptive Companion',
    shortLabel: 'Adaptive',
    toneSummary: 'Encouraging, structured, and tailored to progressive mastery.',
    systemDirective: 'Adapt explanations progressively, pairing practical solutions with clear conceptual takeaways.'
  }
};

export const LORIN_VOICE_PROFILES: Record<LorinVoiceProfile, VoiceProfileDefinition> = {
  LAUREN_NATURAL: {
    id: 'LAUREN_NATURAL',
    label: 'Lauren — Natural Conversational',
    shortLabel: 'Lauren Natural',
    pitch: 1.02,
    rate: 1.03,
    preferredVoiceKeywords: ['Samantha', 'Natural', 'Google US English', 'Aria', 'Zira'],
    description: 'Balanced, warm, natural assistant cadence tuned for extended daily collaboration.',
    samplePhrase: 'Lauren Natural voice active. Private Knowledge Vault and five specialist perspectives are online and ready.'
  },
  LORIN_STUDIO: {
    id: 'LORIN_STUDIO',
    label: 'LORIN — Studio Technical',
    shortLabel: 'LORIN Studio',
    pitch: 0.96,
    rate: 1.08,
    preferredVoiceKeywords: ['Google UK English Female', 'Daniel', 'Alex', 'Guy', 'Natural'],
    description: 'Crisp, articulate, slightly brisk studio cadence optimized for code reviews and technical briefings.',
    samplePhrase: 'LORIN Studio voice calibrated. Ready for system architecture, code synthesis, and empirical verification.'
  },
  LENA_GUARDIAN: {
    id: 'LENA_GUARDIAN',
    label: 'Lena — Security Guardian',
    shortLabel: 'Lena Guardian',
    pitch: 0.92,
    rate: 1.0,
    preferredVoiceKeywords: ['Victoria', 'Google UK English Female', 'Moira', 'Karen'],
    description: 'Measured, composed, authoritative tone for security audits and policy gate notifications.',
    samplePhrase: 'Lena Guardian security voice active. Zero-trust boundaries and cryptographic approval gates are enforced.'
  },
  RILEY_COMPANION: {
    id: 'RILEY_COMPANION',
    label: 'Riley — Adaptive Companion',
    shortLabel: 'Riley Warm',
    pitch: 1.08,
    rate: 1.01,
    preferredVoiceKeywords: ['Samantha', 'Tessa', 'Google US English', 'Jenny'],
    description: 'Expressive, clear, and approachable cadence ideal for learning sessions and conceptual walkthroughs.',
    samplePhrase: 'Hi there! Riley Companion voice is active and ready to explore new concepts and projects together.'
  },
  NOLAN_ARCHITECT: {
    id: 'NOLAN_ARCHITECT',
    label: 'Nolan — Principal Strategist',
    shortLabel: 'Nolan Deep',
    pitch: 0.86,
    rate: 0.98,
    preferredVoiceKeywords: ['Daniel', 'Alex', 'Google UK English Male', 'Fred', 'David'],
    description: 'Deep, deliberate, resonant pacing suited for architectural strategy and system design.',
    samplePhrase: 'Nolan Strategist profile engaged. Evaluating architectural trade-offs, scalability, and long-term resilience.'
  }
};

export const LORIN_AUTONOMY_LEVELS: Record<AutonomyLevel, AutonomyLevelDefinition> = {
  LEVEL_0_OBSERVE: {
    id: 'LEVEL_0_OBSERVE',
    levelNumber: 0,
    label: 'Level 0 — Observe & Inspect Only',
    shortLabel: 'L0: Observe',
    approvalRequirement: 'Strictly Read-Only',
    description: 'LORIN inspects files, logs, and documentation without proposing or staging any state changes.',
    allowedOperations: ['Read files & logs', 'Query local Knowledge Vault', 'Inspect security audit trail']
  },
  LEVEL_1_RECOMMEND: {
    id: 'LEVEL_1_RECOMMEND',
    levelNumber: 1,
    label: 'Level 1 — Analyze & Recommend',
    shortLabel: 'L1: Recommend',
    approvalRequirement: 'Advisory Only',
    description: 'LORIN analyzes problems, evaluates trade-offs, and proposes concrete recommendations and code diffs.',
    allowedOperations: ['All L0 operations', 'Generate code diffs & architecture plans', 'Run non-mutating diagnostics']
  },
  LEVEL_2_PREPARE: {
    id: 'LEVEL_2_PREPARE',
    levelNumber: 2,
    label: 'Level 2 — Prepare & Stage',
    shortLabel: 'L2: Prepare',
    approvalRequirement: 'Pre-Execution Staging',
    description: 'LORIN drafts artifacts, stages migrations, and pre-validates policies without committing external changes.',
    allowedOperations: ['All L1 operations', 'Stage tasks & ADRs in ProjectStore', 'Prepare action digests for review']
  },
  LEVEL_3_EXECUTE_WITH_APPROVAL: {
    id: 'LEVEL_3_EXECUTE_WITH_APPROVAL',
    levelNumber: 3,
    label: 'Level 3 — Execute with Owner Approval',
    shortLabel: 'L3: Approval Gate',
    approvalRequirement: 'Cryptographic SHA-256 Owner Approval',
    description: 'Reversible development tasks proceed; any high-impact action requires explicit Owner SHA-256 digest approval.',
    allowedOperations: ['All L2 operations', 'Execute low-impact local tasks', 'Trigger Phase-2 Owner Approval Gate for high-impact ops']
  },
  LEVEL_4_BOUNDED_AUTOMATION: {
    id: 'LEVEL_4_BOUNDED_AUTOMATION',
    levelNumber: 4,
    label: 'Level 4 — Bounded Autonomous Execution',
    shortLabel: 'L4: Bounded Auto',
    approvalRequirement: 'Policy-Bounded Guardrails',
    description: 'Executes pre-authorized workflows within strict Lena Guardian policy boundaries; destructive actions remain gated.',
    allowedOperations: ['All L3 operations', 'Automated local RAG indexing & normalization', 'Continuous verification suite execution']
  }
};

export const LORIN_SECURE_ACCESS_VECTORS: SecureAccessVector[] = [
  {
    id: 'vec_stealth_shortcut',
    title: '1. Discreet Stealth Trigger & Keyboard Shortcut',
    mechanism: 'Encrypted Modal Gate from Public MOSAIRA Shell',
    shortcutOrEndpoint: 'Ctrl + Shift + L  (or ⌘ + Shift + L)',
    verificationStandard: 'Zero public DOM branding when Stealth Mode is active',
    description: 'From anywhere in the public MOSAIRA platform, press Ctrl+Shift+L (or click the discreet lock icon in the top navigation bar) to summon the private LORIN authentication gate without exposing private URLs.',
    availability: 'ONLINE_AND_OFFLINE'
  },
  {
    id: 'vec_google_rbac',
    title: '2. Verified Owner Google OAuth + Server RBAC',
    mechanism: 'Firebase ID Token Verification + Server Allowlist',
    shortcutOrEndpoint: 'GET /api/me  (Bearer ID Token)',
    verificationStandard: 'Server-enforced OWNER role (client escalation blocked)',
    description: 'Authenticates your identity via Google OAuth and validates your email against the server-side Owner Registry. Signing out immediately aborts in-flight streams and locks the private workspace.',
    availability: 'ONLINE_GATEWAY'
  },
  {
    id: 'vec_hmac_passphrase',
    title: '3. Cryptographic Session Token & Approval Digests',
    mechanism: 'Constant-Time HMAC-SHA256 Token & Action-Bound SHA-256',
    shortcutOrEndpoint: 'POST /api/lorin/auth  &  /api/policy/approve',
    verificationStandard: 'crypto.timingSafeEqual + single-use SHA-256 digest',
    description: 'Supports passphrase-backed HMAC session tokens and requires single-use cryptographic SHA-256 digests (`action:resource:principal`) before any high-impact operation can execute.',
    availability: 'ONLINE_GATEWAY'
  },
  {
    id: 'vec_airgapped_vault',
    title: '4. Air-Gapped Local Vault & AES-256-GCM Backups',
    mechanism: 'Web Crypto API PBKDF2 (100k iterations) + AES-GCM-256',
    shortcutOrEndpoint: 'local://lauren-vault  &  localhost:11434',
    verificationStandard: 'CloudPrivacyGate LOCAL_ONLY + Prompt Injection Sanitizer',
    description: 'When LORIN is set to Offline Air-Gapped mode, CloudPrivacyGate blocks all external transmission of Knowledge Vault and memory snippets, routing inference strictly to local Ollama or the Deterministic Engine.',
    availability: 'LOCAL_AIRGAPPED'
  },
  {
    id: 'vec_pwa_standalone',
    title: '5. Standalone PWA Desktop & Mobile App',
    mechanism: 'Manifest + Service Worker Offline Cache Hierarchy',
    shortcutOrEndpoint: 'Install App button in Workspace Header',
    verificationStandard: 'Isolated origin storage + offline shell availability',
    description: 'Install LORIN as a dedicated standalone application on macOS, Windows, Linux, iOS, or Android for instant launch and full offline access to your projects, tasks, and encrypted Vault.',
    availability: 'ONLINE_AND_OFFLINE'
  }
];

const DEFAULT_PROFILE_CONFIG: LorinProfileConfig = {
  operatingMode: 'ARCHITECT_STRATEGY',
  personality: 'ANALYTICAL_RIGOROUS',
  voiceProfile: 'LAUREN_NATURAL',
  autonomyLevel: 'LEVEL_3_EXECUTE_WITH_APPROVAL',
  runtimeActivation: 'ONLINE_ACTIVE',
  themeMode: 'dark',
  learningTier: 'INTERMEDIATE'
};

export class LorinProfileService {
  private static activeUserId = 'default';

  static setActiveUser(userId: string | undefined): void {
    this.activeUserId = userId && userId.trim() ? userId.trim() : 'default';
  }

  private static getStorageKey(): string {
    return this.activeUserId === 'default'
      ? PROFILE_STORAGE_KEY_PREFIX
      : `${PROFILE_STORAGE_KEY_PREFIX}_${this.activeUserId}`;
  }

  static applyTheme(themeMode: 'dark' | 'light' = 'dark'): void {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    if (themeMode === 'light') {
      root.classList.remove('dark');
      root.classList.add('lorin-light');
      root.setAttribute('data-theme', 'light');
    } else {
      root.classList.add('dark');
      root.classList.remove('lorin-light');
      root.setAttribute('data-theme', 'dark');
    }
  }

  static getProfileConfig(): LorinProfileConfig {
    try {
      const raw = localStorage.getItem(this.getStorageKey());
      if (raw) {
        const parsed = JSON.parse(raw);
        const cfg: LorinProfileConfig = {
          operatingMode: parsed.operatingMode in LORIN_OPERATING_MODES ? parsed.operatingMode : DEFAULT_PROFILE_CONFIG.operatingMode,
          personality: parsed.personality in LORIN_PERSONALITIES ? parsed.personality : DEFAULT_PROFILE_CONFIG.personality,
          voiceProfile: parsed.voiceProfile in LORIN_VOICE_PROFILES ? parsed.voiceProfile : DEFAULT_PROFILE_CONFIG.voiceProfile,
          autonomyLevel: parsed.autonomyLevel in LORIN_AUTONOMY_LEVELS ? parsed.autonomyLevel : DEFAULT_PROFILE_CONFIG.autonomyLevel,
          runtimeActivation: parsed.runtimeActivation === 'OFFLINE_AIRGAPPED' ? 'OFFLINE_AIRGAPPED' : 'ONLINE_ACTIVE',
          themeMode: parsed.themeMode === 'light' ? 'light' : 'dark',
          learningTier:
            parsed.learningTier === 'BEGINNER' || parsed.learningTier === 'ADVANCED'
              ? parsed.learningTier
              : 'INTERMEDIATE'
        };
        this.applyTheme(cfg.themeMode);
        return cfg;
      }
    } catch {}
    this.applyTheme(DEFAULT_PROFILE_CONFIG.themeMode);
    return { ...DEFAULT_PROFILE_CONFIG };
  }

  static saveProfileConfig(config: LorinProfileConfig): LorinProfileConfig {
    try {
      localStorage.setItem(this.getStorageKey(), JSON.stringify(config));
    } catch {}
    this.applyTheme(config.themeMode || 'dark');
    return config;
  }

  static updateProfileConfig(partial: Partial<LorinProfileConfig>): LorinProfileConfig {
    const current = this.getProfileConfig();
    const updated: LorinProfileConfig = { ...current, ...partial };
    return this.saveProfileConfig(updated);
  }

  static buildSystemDirective(config: LorinProfileConfig): string {
    const mode = LORIN_OPERATING_MODES[config.operatingMode];
    const personality = LORIN_PERSONALITIES[config.personality];
    const autonomy = LORIN_AUTONOMY_LEVELS[config.autonomyLevel];
    const voice = LORIN_VOICE_PROFILES[config.voiceProfile];
    const tier = config.learningTier || 'INTERMEDIATE';

    return [
      `[Active LORIN Configuration — Mode: ${mode.label} | Lead Perspective: ${mode.leadSpecialist} | Personality: ${personality.label} | Autonomy Level: ${autonomy.label} | Voice Profile: ${voice.label} | Runtime: ${config.runtimeActivation} | Learning Depth: ${tier}]`,
      `- Mode Directive: ${mode.systemDirective}`,
      `- Personality Directive: ${personality.systemDirective}`,
      `- Adaptive Learning Depth (${tier}): Tailor conceptual explanations, examples, and step-by-step walkthroughs to ${tier} mastery level.`,
      `- Autonomy Constraint (${autonomy.shortLabel}): ${autonomy.description} (${autonomy.approvalRequirement}).`
    ].join('\n');
  }
}

