/**
 * Attach Firebase ID tokens to private API requests.
 * Authorization must come from Firebase Auth — never from fabricated principal JSON.
 */
import { auth } from './firebase';

export const LORIN_AUTH_TOKEN_KEY = 'lorin_auth_token_v2';
export const LORIN_ENROLLED_DEVICE_ID_KEY = 'lorin_enrolled_device_id_v2';

export function getEnrolledClientDeviceId(): string {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const existing = window.localStorage.getItem(LORIN_ENROLLED_DEVICE_ID_KEY);
      if (existing && existing.trim()) {
        return existing.trim();
      }
      const isPrimaryHost =
        window.location?.hostname === 'localhost' || window.location?.hostname === '127.0.0.1';
      const generated = isPrimaryHost
        ? 'dev_primary_laptop_node'
        : `dev_client_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
      window.localStorage.setItem(LORIN_ENROLLED_DEVICE_ID_KEY, generated);
      return generated;
    }
  } catch {
    // ignore
  }
  return 'dev_primary_laptop_node';
}

export function setEnrolledClientDeviceId(deviceId: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage && deviceId.trim()) {
      window.localStorage.setItem(LORIN_ENROLLED_DEVICE_ID_KEY, deviceId.trim());
    }
  } catch {
    // ignore
  }
}

export function getStoredSessionToken(): string | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage.getItem(LORIN_AUTH_TOKEN_KEY);
    }
  } catch {
    // ignore
  }
  return null;
}

export function setStoredSessionToken(token: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(LORIN_AUTH_TOKEN_KEY, token);
    }
  } catch {
    // ignore
  }
}

export function clearStoredSessionToken(): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.removeItem(LORIN_AUTH_TOKEN_KEY);
    }
  } catch {
    // ignore
  }
}

export async function getAuthHeaders(
  extra: Record<string, string> = {}
): Promise<Record<string, string>> {
  const headers: Record<string, string> = {
    Accept: 'application/json',
    'X-Lorin-Device-Id': getEnrolledClientDeviceId(),
    ...extra
  };

  const user = auth.currentUser;
  if (user) {
    try {
      const idToken = await user.getIdToken();
      headers.Authorization = `Bearer ${idToken}`;
      return headers;
    } catch {
      // Fall through to stored session token
    }
  }

  let stored = getStoredSessionToken();
  if (!stored && typeof window !== 'undefined') {
    try {
      const bootRes = await fetch('/api/auth/session', { method: 'POST' });
      if (bootRes.ok) {
        const bootData = await bootRes.json();
        if (typeof bootData.token === 'string' && bootData.token.length > 0) {
          stored = bootData.token;
          setStoredSessionToken(bootData.token);
        }
      }
    } catch {
      // In offline mode, continue without cloud session
    }
  }

  if (stored) {
    headers.Authorization = `Bearer ${stored}`;
  }

  return headers;
}

export async function authFetch(
  input: RequestInfo | URL,
  init: RequestInit = {}
): Promise<Response> {
  const authHeaders = await getAuthHeaders(
    (init.headers as Record<string, string>) || {}
  );
  return fetch(input, {
    ...init,
    headers: {
      ...authHeaders,
      ...(init.headers || {})
    }
  });
}
