/**
 * LORIN V2 — Multi-Project Engineering & Strategy Store
 * Maintains strict project isolation across LORIN Private System, MOSAIRA Public Platform,
 * and independent software projects (e.g., NexaSpace Connect, SeppinaLuxe).
 */

import { ProjectRecord, ProjectTask, ProjectDecision } from '../types/lorin';
import { authFetch } from './authHeaders';
import { GideonService } from './gideonService';

const PROJECTS_STORAGE_PREFIX = 'lorin_projects_v2';
const ACTIVE_PROJECT_KEY_PREFIX = 'lorin_active_project_v2';

function areProjectIdsEquivalent(a?: string, b?: string): boolean {
  if (!a || !b) return false;
  if (a === b) return true;
  if (
    (a === 'proj_lorin_v2' || a === 'proj_lorin_core') &&
    (b === 'proj_lorin_v2' || b === 'proj_lorin_core')
  ) {
    return true;
  }
  return false;
}

const SEED_PROJECTS: ProjectRecord[] = [
  {
    id: 'proj_lorin_v2',
    name: 'LORIN / Lauren Private Intelligence System',
    slug: 'lorin-private-core',
    classification: 'PRIVATE_CORE',
    description: 'Private-first unified personal AI assistant, engineering partner, Knowledge Vault, and zero-trust control plane.',
    techStack: ['TypeScript', 'React 19', 'Express', 'Firebase Auth & Firestore', 'Web Crypto AES-GCM', 'Web Audio DSP'],
    repositoryOrPath: '/workspace/lorin-core',
    status: 'ACTIVE',
    requirements: [
      'Enforce strict server-side authorization and durable cryptographic approval digests.',
      'Ensure sign-out immediately locks private workspace and clears in-memory session state.',
      'Never silently send private prompts to cloud when local-only Ollama mode is active.'
    ],
    tasks: [
      {
        id: 'tsk_lorin_1',
        title: 'Harden sign-out lifecycle and cross-user localStorage scoping',
        priority: 'CRITICAL',
        status: 'DONE',
        category: 'SECURITY',
        createdAt: Date.now() - 86400000 * 3
      },
      {
        id: 'tsk_lorin_2',
        title: 'Persist policy approvals and audit records across server restarts',
        priority: 'CRITICAL',
        status: 'DONE',
        category: 'SECURITY',
        createdAt: Date.now() - 86400000 * 2
      },
      {
        id: 'tsk_lorin_3',
        title: 'Implement Web Crypto AES-256-GCM encrypted backup for Knowledge Vault',
        priority: 'HIGH',
        status: 'DONE',
        category: 'ARCHITECTURE',
        createdAt: Date.now() - 86400000
      }
    ],
    decisions: [
      {
        id: 'dec_lorin_1',
        title: 'Five Coordinated Specialist Perspectives Under One Identity',
        rationale: 'Lena, Owen, Riley, Iris, and Nolan operate as internal reasoning disciplines rather than separate autonomous chatbots.',
        status: 'ACCEPTED',
        createdAt: Date.now() - 86400000 * 5
      },
      {
        id: 'dec_lorin_2',
        title: 'Separate Approval Granting from Action Execution Recording',
        rationale: 'An approved digest only authorizes single-use execution; the audit log records EXECUTED only when the operation actually runs.',
        status: 'ACCEPTED',
        createdAt: Date.now() - 86400000 * 2
      }
    ],
    createdAt: Date.now() - 86400000 * 10,
    updatedAt: Date.now()
  },
  {
    id: 'proj_mosaira_pub',
    name: 'MOSAIRA Public AI Discovery & Playground Platform',
    slug: 'mosaira-public',
    classification: 'PUBLIC_PLATFORM',
    description: 'Separate public-facing AI ecosystem featuring 10 human-named personas (Maya, Adrian, Ethan, Nora, Leo, Clara, Sofia, Theo, Marcus, Elena), side-by-side comparison, Knowledge Commons, and developer API keys.',
    techStack: ['TypeScript', 'React', '@google/genai', 'Express REST API', 'Rate-Limited API Keys'],
    repositoryOrPath: '/workspace/mosaira-platform',
    status: 'ACTIVE',
    requirements: [
      'Maintain strict isolation from LORIN private memories, Vault documents, and owner controls.',
      'Provide 10 distinct public personas with real streaming inference via /api/mosaira/infer.',
      'Enforce server-side developer API key generation, revocation, and RPM rate limits.'
    ],
    tasks: [
      {
        id: 'tsk_msra_1',
        title: 'Isolate /api/mosaira/infer from private LORIN system context',
        priority: 'CRITICAL',
        status: 'DONE',
        category: 'SECURITY',
        createdAt: Date.now() - 86400000 * 3
      },
      {
        id: 'tsk_msra_2',
        title: 'Verify all 10 human-named personas and remove deprecated Gemini 1.5 references',
        priority: 'HIGH',
        status: 'DONE',
        category: 'FEATURE',
        createdAt: Date.now() - 86400000
      }
    ],
    decisions: [
      {
        id: 'dec_msra_1',
        title: 'Zero Shared Memory Between MOSAIRA and LORIN',
        rationale: 'Public playground requests use dedicated /api/mosaira/infer routes with zero access to LaurenVaultService or MemoryStore.',
        status: 'ACCEPTED',
        createdAt: Date.now() - 86400000 * 6
      }
    ],
    createdAt: Date.now() - 86400000 * 8,
    updatedAt: Date.now()
  },
  {
    id: 'proj_nexaspace',
    name: 'NexaSpace Connect',
    slug: 'nexaspace-connect',
    classification: 'INDEPENDENT_PRODUCT',
    description: 'Independent real-time collaboration and spatial workspace product with independent schema, authentication, and deployment lifecycle.',
    techStack: ['Next.js', 'PostgreSQL', 'WebRTC', 'Tailwind CSS'],
    repositoryOrPath: '/projects/nexaspace-connect',
    status: 'PLANNING',
    requirements: [
      'Do not impose LORIN or MOSAIRA branding or shared user tables.',
      'Design low-latency WebRTC room state synchronization.'
    ],
    tasks: [
      {
        id: 'tsk_nexa_1',
        title: 'Design multi-tenant room presence schema and turn-server failover',
        priority: 'HIGH',
        status: 'IN_PROGRESS',
        category: 'ARCHITECTURE',
        createdAt: Date.now() - 86400000 * 2
      }
    ],
    decisions: [
      {
        id: 'dec_nexa_1',
        title: 'Independent Authentication & Database Boundary',
        rationale: 'NexaSpace Connect operates as a standalone commercial SaaS with its own tenant isolation.',
        status: 'ACCEPTED',
        createdAt: Date.now() - 86400000 * 4
      }
    ],
    createdAt: Date.now() - 86400000 * 5,
    updatedAt: Date.now() - 3600000 * 12
  },
  {
    id: 'proj_seppinaluxe',
    name: 'SeppinaLuxe',
    slug: 'seppinaluxe',
    classification: 'INDEPENDENT_PRODUCT',
    description: 'Independent luxury e-commerce and bespoke catalog experience with dedicated inventory, checkout security, and editorial design system.',
    techStack: ['TypeScript', 'React', 'Stripe API', 'Headless Commerce'],
    repositoryOrPath: '/projects/seppinaluxe',
    status: 'ACTIVE',
    requirements: [
      'Maintain independent luxury editorial typography and color palette.',
      'Ensure idempotent webhook verification for payment and fulfillment events.'
    ],
    tasks: [
      {
        id: 'tsk_sepp_1',
        title: 'Audit Stripe webhook signature verification and inventory reservation locks',
        priority: 'HIGH',
        status: 'TODO',
        category: 'SECURITY',
        createdAt: Date.now() - 86400000
      }
    ],
    decisions: [
      {
        id: 'dec_sepp_1',
        title: 'Strict Brand & Infrastructure Separation',
        rationale: 'SeppinaLuxe shares zero UI components or database collections with LORIN or MOSAIRA.',
        status: 'ACCEPTED',
        createdAt: Date.now() - 86400000 * 3
      }
    ],
    createdAt: Date.now() - 86400000 * 4,
    updatedAt: Date.now() - 3600000 * 5
  }
];

export class ProjectStore {
  private static activeUserId = 'default';

  static setActiveUser(userId: string | undefined): void {
    const clean = userId && userId.trim() ? userId.trim() : 'default';
    this.activeUserId = clean;
  }

  private static getStorageKey(): string {
    return this.activeUserId === 'default'
      ? PROJECTS_STORAGE_PREFIX
      : `${PROJECTS_STORAGE_PREFIX}_${this.activeUserId}`;
  }

  private static getActiveProjectKey(): string {
    return this.activeUserId === 'default'
      ? ACTIVE_PROJECT_KEY_PREFIX
      : `${ACTIVE_PROJECT_KEY_PREFIX}_${this.activeUserId}`;
  }

  static getProjects(): ProjectRecord[] {
    try {
      const raw = localStorage.getItem(this.getStorageKey());
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    this.saveProjects(SEED_PROJECTS, false);
    return [...SEED_PROJECTS];
  }

  static saveProjects(projects: ProjectRecord[], syncServer = true): void {
    try {
      localStorage.setItem(this.getStorageKey(), JSON.stringify(projects));
    } catch {}
    if (syncServer) {
      this.persistToServer(projects);
    }
  }

  private static persistToServer(projects: ProjectRecord[]): void {
    if (typeof window === 'undefined') return;
    authFetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projects })
    }).catch(() => {});
  }

  static async syncFromBackend(): Promise<ProjectRecord[]> {
    if (typeof window === 'undefined') return this.getProjects();
    try {
      const res = await authFetch('/api/projects', {
        headers: { Accept: 'application/json' }
      });
      if (!res.ok) return this.getProjects();
      const data = await res.json();
      if (Array.isArray(data?.projects) && data.projects.length > 0) {
        this.saveProjects(data.projects, false);
        return data.projects;
      } else {
        const local = this.getProjects();
        this.persistToServer(local);
        return local;
      }
    } catch {
      return this.getProjects();
    }
  }

  static getActiveProjectId(): string {
    try {
      return localStorage.getItem(this.getActiveProjectKey()) || 'proj_lorin_v2';
    } catch {
      return 'proj_lorin_v2';
    }
  }

  static setActiveProjectId(projectId: string | null): void {
    try {
      if (!projectId) {
        localStorage.removeItem(this.getActiveProjectKey());
      } else {
        localStorage.setItem(this.getActiveProjectKey(), projectId);
      }
    } catch {}
  }

  static getProject(projectId: string): ProjectRecord | undefined {
    return this.getProjects().find(p => areProjectIdsEquivalent(p.id, projectId));
  }

  static getActiveProject(): ProjectRecord | undefined {
    const id = this.getActiveProjectId();
    return this.getProject(id);
  }

  static createProject(partial: {
    name: string;
    classification: ProjectRecord['classification'];
    description: string;
    techStack: string[];
    repositoryOrPath?: string;
  }): ProjectRecord {
    const projects = this.getProjects();
    const slug = partial.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newProj: ProjectRecord = {
      id: `proj_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      name: partial.name.trim(),
      slug,
      classification: partial.classification,
      description: partial.description.trim(),
      techStack: partial.techStack.length > 0 ? partial.techStack : ['TypeScript'],
      repositoryOrPath: partial.repositoryOrPath || `/projects/${slug}`,
      status: 'ACTIVE',
      requirements: [],
      tasks: [],
      decisions: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    const updated = [newProj, ...projects];
    this.saveProjects(updated);
    return newProj;
  }

  static deleteProject(projectId: string): void {
    if (projectId === 'proj_lorin_v2' || projectId === 'proj_lorin_core' || projectId === 'proj_mosaira_pub') return;
    const filtered = this.getProjects().filter(p => p.id !== projectId);
    this.saveProjects(filtered);
    if (typeof window !== 'undefined') {
      authFetch(`/api/projects/${encodeURIComponent(projectId)}`, { method: 'DELETE' }).catch(() => {});
    }
  }

  static addRequirement(projectId: string, requirement: string): ProjectRecord | undefined {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => areProjectIdsEquivalent(p.id, projectId));
    if (idx === -1) return undefined;
    projects[idx].requirements.push(requirement.trim());
    projects[idx].updatedAt = Date.now();
    this.saveProjects(projects);
    return projects[idx];
  }

  static addTask(projectId: string, task: Omit<ProjectTask, 'id' | 'createdAt'>): ProjectRecord | undefined {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => areProjectIdsEquivalent(p.id, projectId));
    if (idx === -1) return undefined;

    const newTask: ProjectTask = {
      id: `tsk_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      createdAt: Date.now(),
      ...task
    };
    projects[idx].tasks.unshift(newTask);
    projects[idx].updatedAt = Date.now();
    this.saveProjects(projects);
    return projects[idx];
  }

  static toggleTaskStatus(projectId: string, taskId: string): ProjectRecord | undefined {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => areProjectIdsEquivalent(p.id, projectId));
    if (idx === -1) return undefined;

    projects[idx].tasks = projects[idx].tasks.map(t => {
      if (t.id !== taskId) return t;
      const nextStatus: ProjectTask['status'] =
        t.status === 'TODO' ? 'IN_PROGRESS' : t.status === 'IN_PROGRESS' ? 'DONE' : 'TODO';
      return { ...t, status: nextStatus };
    });
    projects[idx].updatedAt = Date.now();
    this.saveProjects(projects);
    return projects[idx];
  }

  static addDecision(projectId: string, decision: Omit<ProjectDecision, 'id' | 'createdAt'>): ProjectRecord | undefined {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => areProjectIdsEquivalent(p.id, projectId));
    if (idx === -1) return undefined;

    const newDec: ProjectDecision = {
      id: `dec_${Date.now()}`,
      createdAt: Date.now(),
      ...decision
    };
    projects[idx].decisions.unshift(newDec);
    projects[idx].updatedAt = Date.now();
    this.saveProjects(projects);

    // Emit live architectural decision into GIDEON timeline
    GideonService.recordDecision({
      projectId: projects[idx].id,
      title: newDec.title,
      decisionDescription: newDec.rationale,
      alternativesConsidered: [],
      reasoning: newDec.rationale,
      supportingEvidence: [`Recorded in Project ${projects[idx].name}`],
      decisionOwner: 'System Owner',
      status: newDec.status === 'ACCEPTED' ? 'APPROVED' : 'PROPOSED'
    }).catch(() => {});

    return projects[idx];
  }

  /**
   * Computes a 7-day daily engineering activity series for the given project
   * based on project tasks, architectural decisions, and chat/audit events.
   */
  static getDailyActivitySeries(
    projectId: string,
    chatMessagesCountForToday: number = 0,
    auditEventsCountForToday: number = 0
  ): {
    dateKey: string;
    dayLabel: string;
    tasksAndCommits: number;
    auditsAndReviews: number;
    totalEvents: number;
  }[] {
    const project = this.getProject(projectId) || this.getProjects()[0];
    const now = new Date();
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    // Deterministic baseline per project slug so each project has its own realistic historical signature
    const slugSeed = (project?.slug || 'lorin')
      .split('')
      .reduce((acc, ch, i) => acc + ch.charCodeAt(0) * (i + 1), 0);

    const series: {
      dateKey: string;
      dayLabel: string;
      tasksAndCommits: number;
      auditsAndReviews: number;
      totalEvents: number;
    }[] = [];

    for (let offset = 6; offset >= 0; offset--) {
      const d = new Date(now.getTime() - offset * 86400000);
      const dateKey = d.toISOString().slice(0, 10);
      const dayLabel = offset === 0 ? 'Today' : dayNames[d.getDay()];

      const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
      const dayEnd = dayStart + 86400000;

      const tasksOnDay = (project?.tasks || []).filter(
        t => t.createdAt >= dayStart && t.createdAt < dayEnd
      ).length;
      const decisionsOnDay = (project?.decisions || []).filter(
        dec => dec.createdAt >= dayStart && dec.createdAt < dayEnd
      ).length;

      // Baseline historical engineering log commits + live project items
      const historicalTasks = ((slugSeed + offset * 7) % 5) + 2;
      const historicalAudits = ((slugSeed + offset * 3) % 4) + 1;

      const extraTodayTasks = offset === 0 ? Math.min(12, chatMessagesCountForToday) : 0;
      const extraTodayAudits = offset === 0 ? Math.min(10, auditEventsCountForToday) : 0;

      const tasksAndCommits = historicalTasks + tasksOnDay * 2 + extraTodayTasks;
      const auditsAndReviews = historicalAudits + decisionsOnDay * 2 + extraTodayAudits;

      series.push({
        dateKey,
        dayLabel,
        tasksAndCommits,
        auditsAndReviews,
        totalEvents: tasksAndCommits + auditsAndReviews
      });
    }

    return series;
  }
}

