import { MemoryDomain, MemoryRecord, Principal } from '../types/lorin';
import { persistMemoryRecordRemote } from './firebase';
import { authFetch } from './authHeaders';

const MEMORY_STORAGE_KEY = 'lorin_persistent_memory_v1';

const SEED_MEMORY_RECORDS: MemoryRecord[] = [
  {
    id: 'mem_pref_01',
    domain: 'USER_PREFERENCES',
    key: 'ui_interaction_mode',
    title: 'High-Density Engineering Display',
    content: 'Prefers tabular numerals, compact status badges, unboxed metadata, and direct access to raw specialist perspectives alongside synthesized summaries.',
    provenance: 'User onboarding configuration',
    status: 'CONFIRMED',
    tags: ['ui', 'display', 'preferences'],
    createdAt: Date.now() - 86400000 * 3,
    updatedAt: Date.now() - 86400000 * 3
  },
  {
    id: 'mem_req_01',
    domain: 'PROJECT_REQUIREMENTS',
    key: 'security_invariants',
    title: 'Phase 2 Centralized Policy Invariants',
    content: 'All high-impact operations must require action-bound cryptographic approval digests. Keyword matching alone is strictly prohibited as an access control boundary.',
    provenance: 'LORIN Specification v1.1 Section 29',
    status: 'CONFIRMED',
    tags: ['security', 'policy', 'invariants'],
    createdAt: Date.now() - 86400000 * 2,
    updatedAt: Date.now() - 86400000 * 2
  },
  {
    id: 'mem_req_02',
    domain: 'PROJECT_REQUIREMENTS',
    key: 'specialist_governance',
    title: 'Unified 15-Specialist Orchestration Protocol (5 Core + 10 Extended)',
    content: 'Core perspectives Lena (Guardian), Owen (Coordinator), Riley (Companion), Iris (Investigator), and Nolan (Strategist) collaborate seamlessly with the 10 domain specialists: Maya, Adrian, Ethan, Nora, Leo, Clara, Sofia, Theo, Marcus, and Elena under one coherent LORIN identity.',
    provenance: 'LORIN Specification v2.0 Section 3',
    status: 'CONFIRMED',
    tags: ['specialists', 'architecture', 'roster'],
    createdAt: Date.now() - 86400000 * 2,
    updatedAt: Date.now() - 86400000 * 2
  },
  {
    id: 'mem_kb_01',
    domain: 'KNOWLEDGE_BASE',
    key: 'api_contract_genai',
    title: 'Server-Side Cloud & Local Provider Architecture Standards',
    content: 'All cloud inference executes strictly through the backend server proxy using environment-secured credentials. Internal model identifiers and category strings are kept private and abstracted behind capability tiers.',
    provenance: 'LORIN Security & Provider Architecture Guidelines',
    status: 'CONFIRMED',
    tags: ['genai', 'security', 'providers'],
    createdAt: Date.now() - 86400000,
    updatedAt: Date.now() - 86400000
  },
  {
    id: 'mem_lesson_01',
    domain: 'OPERATIONAL_LESSONS',
    key: 'anti_hallucination_lesson',
    title: 'Non-Empty Output is Not Verification',
    content: 'Iris established that checking output length is insufficient to declare a task VERIFIED. Consequential claims must match explicit acceptance criteria and automated assertions.',
    provenance: 'Phase 1 Prototype Post-Mortem Audit',
    status: 'CONFIRMED',
    tags: ['testing', 'verification', 'lessons'],
    createdAt: Date.now() - 43200000,
    updatedAt: Date.now() - 43200000
  },
  {
    id: 'mem_task_01',
    domain: 'TASK_HISTORY',
    key: 'phase2_security_boundary_task',
    title: 'Phase 2 Foundation Verification',
    content: 'Established typed principal context, action-bound cryptographic digests, single-use approval expiry, and tamper-evident audit logging stream.',
    provenance: 'Automated Test Runner Run #1',
    status: 'CONFIRMED',
    tags: ['tasks', 'phase2', 'audit'],
    createdAt: Date.now() - 10000000,
    updatedAt: Date.now() - 10000000
  },
  {
    id: 'mem_prop_01',
    domain: 'USER_PREFERENCES',
    key: 'local_ollama_routing_preference',
    title: 'Candidate Suggestion: Prefer Qwen3.5 Local Model When Air-Gapped',
    content: 'When LORIN is switched to Offline Air-Gapped runtime, prioritize Qwen3.5 or Devstral local models on port 11434 before falling back to deterministic synthesis.',
    provenance: 'Proposed by Owen (Coordinator) from runtime telemetry',
    status: 'PROPOSED',
    tags: ['ollama', 'local-ai', 'routing'],
    createdAt: Date.now() - 3600000,
    updatedAt: Date.now() - 3600000
  }
];

export class MemoryStore {
  private static records: MemoryRecord[] = [];

  static initialize(): void {
    try {
      const stored = localStorage.getItem(MEMORY_STORAGE_KEY);
      if (stored) {
        this.records = JSON.parse(stored);
      } else {
        this.records = [...SEED_MEMORY_RECORDS];
        this.persist(false);
      }
    } catch {
      this.records = [...SEED_MEMORY_RECORDS];
    }
  }

  private static persist(syncServer = true): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(this.records));
      }
    } catch (e) {
      console.warn('MemoryStore persist error', e);
    }
    if (syncServer && typeof window !== 'undefined') {
      authFetch('/api/memories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ memories: this.records })
      }).catch(() => {});
    }
  }

  static async syncFromBackend(): Promise<MemoryRecord[]> {
    if (typeof window === 'undefined') return this.records;
    try {
      const res = await authFetch('/api/memories', {
        headers: { Accept: 'application/json' }
      });
      if (!res.ok) return this.records;
      const data = await res.json();
      if (Array.isArray(data?.memories) && data.memories.length > 0) {
        this.records = data.memories;
        this.persist(false);
        return this.records;
      } else {
        this.persist(true);
        return this.records;
      }
    } catch {
      return this.records;
    }
  }

  static getRecordsByDomain(domain: MemoryDomain): MemoryRecord[] {
    return this.records.filter(r => r.domain === domain);
  }

  static getAllRecords(): MemoryRecord[] {
    return [...this.records];
  }

  static getRecordById(id: string): MemoryRecord | undefined {
    return this.records.find(r => r.id === id);
  }

  static searchRecords(query: string, domain?: MemoryDomain, status?: 'CONFIRMED' | 'PROPOSED'): MemoryRecord[] {
    const q = query.toLowerCase().trim();
    return this.records.filter(r => {
      if (domain && r.domain !== domain) return false;
      if (status && r.status !== status) return false;
      if (!q) return true;
      return (
        r.title.toLowerCase().includes(q) ||
        r.content.toLowerCase().includes(q) ||
        r.key.toLowerCase().includes(q) ||
        r.tags.some(t => t.toLowerCase().includes(q))
      );
    });
  }

  static createRecord(
    record: Omit<MemoryRecord, 'id' | 'createdAt' | 'updatedAt'>,
    principal: Principal
  ): { success: boolean; record?: MemoryRecord; message: string } {
    if (!principal.authenticated) {
      return { success: false, message: 'Authentication required to write to persistent memory.' };
    }
    if (principal.role === 'GUEST') {
      return { success: false, message: 'Guest principals cannot create persistent records.' };
    }

    const newRecord: MemoryRecord = {
      id: `mem_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      ...record
    };

    this.records.unshift(newRecord);
    this.persist();
    persistMemoryRecordRemote(principal.id, newRecord).catch(() => {});
    return { success: true, record: newRecord, message: 'Memory record stored successfully.' };
  }

  static updateRecord(
    id: string,
    updates: Partial<Omit<MemoryRecord, 'id' | 'createdAt' | 'updatedAt'>>,
    principal: Principal
  ): { success: boolean; message: string } {
    if (!principal.authenticated || principal.role === 'GUEST') {
      return { success: false, message: 'Permission denied. Only authenticated members can modify memory.' };
    }

    const idx = this.records.findIndex(r => r.id === id);
    if (idx === -1) {
      return { success: false, message: 'Record not found.' };
    }

    this.records[idx] = {
      ...this.records[idx],
      ...updates,
      updatedAt: Date.now()
    };

    this.persist();
    persistMemoryRecordRemote(principal.id, this.records[idx]).catch(() => {});
    return { success: true, message: 'Record updated.' };
  }

  static confirmSuggestion(id: string, principal: Principal): { success: boolean; message: string } {
    return this.updateRecord(
      id,
      {
        status: 'CONFIRMED',
        provenance: `Confirmed by ${principal.name} (${principal.role}) on ${new Date().toLocaleDateString()}`
      },
      principal
    );
  }

  static rejectSuggestion(id: string, principal: Principal): { success: boolean; message: string } {
    if (!principal.authenticated || principal.role === 'GUEST') {
      return { success: false, message: 'Permission denied.' };
    }
    const before = this.records.length;
    this.records = this.records.filter(r => r.id !== id);
    if (this.records.length === before) {
      return { success: false, message: 'Candidate suggestion not found.' };
    }
    this.persist();
    return { success: true, message: 'Proposed memory suggestion rejected and removed.' };
  }

  static deleteRecord(id: string, principal: Principal): { success: boolean; message: string } {
    if (principal.role !== 'OWNER') {
      return { success: false, message: 'Permission denied. Only OWNER can delete persistent memory records.' };
    }

    const initialLength = this.records.length;
    this.records = this.records.filter(r => r.id !== id);
    if (this.records.length === initialLength) {
      return { success: false, message: 'Record not found.' };
    }

    this.persist();
    return { success: true, message: 'Record purged from storage.' };
  }

  /**
   * Builds a concise context summary of CONFIRMED personal memories relevant to the current prompt and active project.
   * Strictly separates confirmed personal memory from conversation history and Vault documents (Part G Section 8.2).
   */
  static getConfirmedContextSummary(prompt: string, activeProjectId?: string): string {
    const confirmed = this.records.filter(
      r => r.status === 'CONFIRMED' && (!r.projectId || r.projectId === activeProjectId)
    );
    if (confirmed.length === 0) return '';

    const q = (prompt || '').toLowerCase();
    const scored = confirmed
      .map(rec => {
        let score = rec.domain === 'USER_PREFERENCES' || rec.domain === 'PROJECT_REQUIREMENTS' ? 2 : 1;
        if (q && (rec.title.toLowerCase().includes(q) || rec.tags.some(t => q.includes(t.toLowerCase())))) {
          score += 3;
        }
        return { rec, score };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    return (
      `[Confirmed Personal Memory Records (Approved by Owner — Distinct from Vault Documents)]:\n` +
      scored.map(({ rec }) => `- [${rec.domain}] ${rec.title}: ${rec.content} (Source: ${rec.provenance})`).join('\n')
    );
  }

  static exportJson(): string {
    return JSON.stringify(this.records, null, 2);
  }

  static importJson(jsonString: string, principal: Principal): { success: boolean; count: number; message: string } {
    if (principal.role !== 'OWNER') {
      return { success: false, count: 0, message: 'Only OWNER can import memory records.' };
    }

    try {
      const parsed = JSON.parse(jsonString);
      if (!Array.isArray(parsed)) {
        return { success: false, count: 0, message: 'Invalid format: expected JSON array of memory records.' };
      }
      this.records = parsed;
      this.persist();
      return { success: true, count: parsed.length, message: `Successfully imported ${parsed.length} records.` };
    } catch (e: any) {
      return { success: false, count: 0, message: `Import failed: ${e.message}` };
    }
  }

  static resetToDefault(principal: Principal): boolean {
    if (principal.role !== 'OWNER') return false;
    this.records = [...SEED_MEMORY_RECORDS];
    this.persist();
    return true;
  }
}

MemoryStore.initialize();

