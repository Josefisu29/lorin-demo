# LORIN V2 security model

## Identity and roles

Firebase ID tokens are verified by `serverAuth.ts`; browser-supplied roles are not an authorization source. The client starts unauthenticated and only requests server role details after Firebase resolves. If Firebase becomes unauthenticated for any reason, protected client state is cleared. Owner email configuration is now `OWNER_EMAIL` only; an empty value grants no email-based owner identity. Firestore privileged role checks use the server-managed `user_roles/{uid}` record rather than a hard-coded email.

Owner and admin operations must continue to check verified server principals on each endpoint. UI visibility and local policy state are not security boundaries. Review `server_rbac_users.json` and the account provisioning flow before production use; repository-provided managed account records are not themselves proof of Firebase identity.

Newly observed verified accounts now default to `STANDARD_USER` with no project grants. Explicit project access must be provisioned; the browser does not substitute wildcard project scopes when the API omits them.

## Data and execution

- Provider credentials belong only in server environment variables (`GEMINI_API_KEY`, `OLLAMA_API_KEY`). Never use `VITE_` provider credentials.
- Cross-origin requests receive CORS permission only for exact entries in `CORS_ALLOWED_ORIGINS` (plus localhost development origins outside production); the API no longer sends wildcard CORS headers.
- Firestore rules default deny and grant user documents by authenticated UID ownership. Role records are only writable by privileged server-authorized roles under the rules.
- Approval and audit APIs exist, but current server snapshot persistence is not a transactional multi-instance store. Consequential side effects require a separate server-side authorization and approval check immediately before execution.
- Logs and provider diagnostics must omit tokens, keys and private prompt content.

## Threat boundaries and unresolved controls

Threats include forged browser role state, token expiry/account switching, cross-user object access, approval replay, oversized inference requests, provider failure/fallback confusion, prompt injection in retrieved files, and serverless instance loss. Authenticated inference and role middleware are present, but request schema limits, distributed quotas, durable atomic approvals, cancellation, Firebase emulator rules tests and secret scanning remain unverified.

## Recovery

Changes in this audit are limited to source and documentation. The baseline commit is `2e5244e`, and the original working tree was clean on branch `main`. Revert the auth/client/rules edits together if needed; before deployment, preserve any intentional changes made after this baseline. No production deployment or migration was performed.
