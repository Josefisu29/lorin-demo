# LORIN V2 feature matrix

Evidence snapshot: repository inspection on 2026-11-06. `PASS` means a named check actually ran; the presence of code or a UI does not mean an end-to-end feature passed. See [the consolidated implementation roadmap](LORIN_CONSOLIDATED_IMPLEMENTATION_ROADMAP.md) for sequencing, acceptance criteria, and unresolved decisions.

| Capability | Status | Evidence | Remaining gap |
|---|---|---|---|
| React/Vite client and PWA shell | PARTIAL | `package.json`, `vite.config.ts`, `src/App.tsx` | Responsive/accessibility journey not verified |
| React/Recharts dependency tree | PASS | `npm ls react react-dom recharts react-is` on 2026-11-05; React/React DOM 19.3.1, Recharts 3.10.1, `react-is` 19.3.1, deduped React | Keep lockfile/install reproducible in clean CI |
| Initial identity and sign-out reset | PARTIAL | `src/App.tsx` initializes guest and clears on null Firebase auth event | Browser lifecycle verification not run |
| Firebase token verification | PARTIAL | `serverAuth.ts`; protected `/api/me` and inference routes | Firebase credentials/emulator integration and direct authorization tests not run |
| Private Gemini/Ollama Cloud inference | PARTIAL | `server.ts`, `serverModelRegistry.ts`, `src/services/modelBackend.ts` | Real upstream inference, distributed limits and provider-failure journey not verified |
| Inference route authorization | PARTIAL | `/api/gemini/infer` and stream routes use `requireAuth` | Direct HTTP negative tests not executed |
| Owner configuration and least privilege | PARTIAL / HIGH PRIORITY | `serverAuth.ts` resolves owner privileges from verified identity and server-managed allowlist; client role editing and seeded client/server roles removed | Firebase negative tests, provisioning lifecycle, durable RBAC and distributed revocation remain unverified |
| Firestore ownership rules | PARTIAL | `firestore.rules` default-deny and UID-scoped documents | Emulator tests, edge cases and backend service identity not verified |
| Approval and audit | PARTIAL | Server policy endpoints in `server.ts` | Current persistence is not proven durable/atomic across instances; client policy cache remains |
| Knowledge Vault and personal memory | PARTIAL | Vault local cache is namespaced by authenticated UID and sample documents were removed; memory/Vault services exist | Extraction, real semantic embeddings, canonical offline/cloud persistence, authorized retrieval and deletion lifecycle need journey tests |
| Projects and conversations | PARTIAL | Project/conversation stores and Firestore helpers in `src/services` | Cross-user isolation and read-back synchronization not verified |
| GIDEON timeline and systems intelligence | PARTIAL | Authenticated endpoints scope records by verified UID; seed history removed; manual records cannot self-assert verification | Shared JSON/file storage is not durable across Vercel instances; telemetry and evidence-based forecasting are not implemented; forecasts return unavailable |
| MOSAIRA public inference | PARTIAL | `/api/mosaira/infer` uses configured providers; missing configuration returns 503; key management requires authenticated owner | Separate deployment, durable key storage, distributed abuse limits, public isolation tests and live inference remain unverified |
| MOSAIRA persona catalog | DECISION | Consolidated history contains two different ten-persona naming sets | Canonical names and verified model/provider/version per offer unresolved |
| Voice and vision | PARTIAL | `VoiceChatView.tsx`, `VideoVisionView.tsx`, audio/video services | Wake word, continuous video, provider modality, privacy lifecycle and device QA not established |
| Production build | PASS (local, 2026-11-06) | `npm run build` completed after the current implementation tranche; Vite generated PWA assets and esbuild bundled `server.js` | Vercel deployment and clean-install/runtime/API routing unverified; main JS chunk remains over Vite advisory threshold (2,241.62 kB minified, 587.67 kB gzip) |
| Automated test suite | FAIL (last recorded) | 36/37 passed | Ollama dependency/import issue in test environment; rerun after complete install |
| TypeScript check | BLOCKED (last recorded) | `@typescript/typescript-win32-x64` was missing | Restore complete platform dependency install and rerun |
| Gemini live inference | NOT RUN | No credential/provider smoke test executed | Authenticated staging smoke test and true model attribution |
| Ollama Cloud live inference | NOT RUN | No provider smoke test executed | Verify selected model, endpoint, streaming, capability and attribution |
| Firebase emulator / browser / accessibility QA | NOT RUN | No successful verification recorded | Add rules/API tests and run responsive, keyboard, screen-reader, and lifecycle review |
| Vercel deployment | NOT RUN | `vercel.json` configures root build/API routing | Verify project root, secrets, installation, build, runtime routes and deployed smoke tests |

## Historical findings revalidated

- Authenticated owner default in `src/App.tsx`: confirmed in the October 29 historical audit; current source starts as guest.
- Auth listener clearing only on explicit sign-out: confirmed historically; current source clears on unauthenticated transitions.
- Hard-coded owner email: removed from application source and the seeded RBAC JSON file. Owner authority is resolved from verified server identity and configured owner allowlist; emulator and direct negative tests remain unrun.
- `/api/gemini/infer` unauthenticated: not confirmed; current route uses `requireAuth`.
- Build missing generated `server.js`: not confirmed; current build script bundles it.
- Production build: PASS locally on 2026-11-05; this does not establish successful Vercel deployment.
- MOSAIRA no-credential path now returns `503 PROVIDER_NOT_CONFIGURED`; genuine provider inference still needs a credentialed staging smoke test.
- October 29 archive findings are historical and do not prove the current source still has the same defects.
