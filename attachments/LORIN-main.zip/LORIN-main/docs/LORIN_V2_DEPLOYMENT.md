# LORIN V2 deployment notes

## Current topology

- Frontend: Vite output in `dist`.
- Local API: Express app in `server.ts`; local dev runs `tsx server.ts` and production local start runs generated `server.js`.
- Vercel: `npm run build`, static output `dist`, `/api/*` rewritten to `api/index.ts`, other routes to `index.html`.
- Persistence/auth: Firebase Auth and Firestore; Vercel serverless API uses the Express export.
- Providers: Gemini and Ollama Cloud server-side adapters. No durable worker/queue is established by this audit.

## Environment

Set deployment secrets through the hosting provider's secret manager. Do not commit `.env` or put provider secrets in `VITE_*` variables.

- `GEMINI_API_KEY`: server-only Gemini credential.
- `OLLAMA_API_KEY`: server-only Ollama Cloud credential when enabled.
- `GEMINI_MODEL`, Ollama model settings: explicit configured model IDs.
- `OWNER_EMAIL`: optional server-side primary owner email; unset means no email-based primary owner.
- `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`: server Admin SDK configuration when required.
- `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_APP_ID`: public Firebase client configuration only.
- `PORT`, `NODE_ENV`, `APP_URL`: server runtime settings.
- `CORS_ALLOWED_ORIGINS`: comma-separated exact origins for deliberate cross-origin clients. Same-origin hosting needs no CORS entry; local development allows the localhost Vite/server origins.

The repository build/start scripts are configured, but this audit could not execute them because the global npm installation is missing and local Node binary resolution is denied by the environment. Do not treat the deployment path as verified until clean install, build, API routing and authenticated smoke checks pass.

## Health and rollout

`/api/health` is a process/configuration report, not proof of provider inference. Run an authenticated request against each configured provider and confirm returned model attribution. Use a staging Firebase project and validate auth/rules before exposing the app. Current JSON snapshot approval state is not suitable evidence of durable state across serverless instances. No deployment was made during this audit.
