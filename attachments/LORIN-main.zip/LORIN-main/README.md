# LORIN / LAUREN & MOSAIRA — Unified Intelligence & Engineering Platform

**System Classification:** Private Personal AI Assistant (`LORIN / LAUREN`) + Public AI Model Discovery, Dataset Lab & Playground Platform (`MOSAIRA`)  
**Architecture:** Full-Stack TypeScript, React 19, Express Server Proxy, `@google/genai` SDK, Local Ollama Runtime, and Firebase Authentication & Firestore.

---

## 1. Architecture & Security Boundaries

1. **Strict Identity & Data Separation:**
   - **LORIN / LAUREN (Private Assistant):** Protected behind Firebase Authentication and verified Owner clearance (`/api/me`, `/api/gemini/infer`, `/api/gemini/stream`, `/api/policy/*`). Manages the Private Knowledge Vault, AES-256-GCM encrypted backups, independent engineering projects, and the 15-specialist intelligence roster.
   - **MOSAIRA (Public AI Platform):** Public-facing model discovery, side-by-side comparison, playground, dataset governance lab, and developer API keys (`/api/mosaira/*`). Never accesses LORIN's private memories, Knowledge Vault, or owner controls.

2. **Server-Side Only Gemini API Integration:**
   - `GEMINI_API_KEY` is read exclusively by the backend (`server.ts` / `api/index.ts`).
   - It is **never** exposed in `VITE_*` client variables, browser `localStorage`, or frontend bundles.
   - Internal model identifiers are resolved authoritatively on the server (`GEMINI_MODEL`) and abstracted behind private capability tier labels in the user interface.

3. **Complete 15-Specialist Roster Working with LORIN:**
   - **5 Core Perspectives:** `Lena` (Guardian), `Owen` (Coordinator), `Riley` (Companion), `Iris` (Investigator), `Nolan` (Strategist).
   - **10 Extended Specialists:** `Maya` (NOVA), `Adrian` (ATLAS), `Ethan` (FORGE), `Nora` (VERA), `Leo` (SPARK), `Clara` (SAGE), `Sofia` (MUSE), `Theo` (PULSE), `Marcus` (AEGIS), `Elena` (PRISM).

---

## 2. Environment Variables

Copy `.env.example` to `.env` (or `backend/.env` on Windows):

| Variable | Scope | Description |
| :--- | :--- | :--- |
| `GEMINI_API_KEY` | **Backend Only** | Google Gemini API key used by `@google/genai` on the server. Never prefix with `VITE_`. |
| `GEMINI_MODEL` | **Backend Only** | Optional default model override (`gemini-3.8-flash` or `gemini-3.1-flash-lite`). |
| `OLLAMA_BASE_URL` | **Backend / Local** | Local Ollama server URL (default: `http://localhost:11434`). |
| `OWNER_EMAIL` | **Backend Only** | Primary verified owner email for LORIN administrative clearance. |
| `APP_URL` | **Backend** | Hosted base URL (default: `http://localhost:3000`). |
| `PORT` | **Backend** | HTTP server listen port (default: `3000`). |

---

## 3. Local Windows Development Setup

### Step 1 — Install Dependencies
Use Node.js **24.12 or newer** and npm **10.9.2** (the project versions are declared in `package.json`).

Open **PowerShell** or **Command Prompt (`cmd.exe`)** in the project root:
```powershell
npm install
```

### Step 2 — Configure `.env`
Create your local `.env` file from the template:
```powershell
# PowerShell
Copy-Item .env.example .env

# Or in cmd.exe:
copy .env.example .env
```
Open `.env` and set your `GEMINI_API_KEY` (and optional `OWNER_EMAIL`). Note: The server automatically checks both `./.env` and `./backend/.env`.

### Step 3 — Start the Full-Stack Development Server
```powershell
npm run dev
```
Open `http://localhost:3000` in your browser.

### Step 4 — Verify Health & Run Automated Tests
```powershell
# Check provider health endpoint
curl http://localhost:3000/api/health
curl http://localhost:3000/api/providers/status

# Run unit & security verification suite
npm test

# Run TypeScript static typecheck and production build
npm run lint
npm run build
```

---

## 4. Vercel Production Deployment Setup

The repository includes `vercel.json` and the serverless entry point `api/index.ts` which exports the Express `app` while serving the compiled Vite SPA from `dist/`.

1. **Import Project into Vercel:**
   - Connect your Git repository to Vercel.
   - Framework Preset: `Vite` (Build command: `npm run build`, Output directory: `dist`).

2. **Configure Vercel Environment Variables:**
   In **Vercel Project Settings → Environment Variables**, add:
   - `GEMINI_API_KEY` (Mark as Sensitive / Backend only — **do not** add `VITE_` prefix)
   - `GEMINI_MODEL` = `gemini-3.8-flash`
   - `OWNER_EMAIL` = `<your-verified-firebase-email>`

3. **Deploy & Verify:**
   - Deploy to Preview or Production.
   - Verify `/api/health` and `/api/providers/status` on your `.vercel.app` domain.
   - Note: Local `localhost:11434` Ollama daemons are only reachable when running locally; on Vercel, select **LORIN Cloud Gateway** or **Local-First with Cloud Fallback**.

---

## 5. Google AI Studio Environment

- In Google AI Studio Build, `GEMINI_API_KEY` is injected into the server environment automatically.
- The Express server runs on port `3000` (`npm run dev`) and proxies all `/api/*` routes while serving the React application.
