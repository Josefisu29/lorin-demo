import crypto from 'crypto';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { execFile } from 'child_process';
import { promisify } from 'util';
import type {
  ApprovedNodeCommandResult,
  ApprovedNodeCommandSpec,
  ChatMessage,
  ConversationSession,
  DeviceAuthorizationStatus,
  DeviceCapabilityScope,
  DeviceConnectionState,
  DevicePairingChallenge,
  EnrolledDeviceRecord,
  EnrolledDeviceType,
  PrimaryNodeLifecycleState,
  PrimaryNodeTelemetry,
  PrivateNetworkProviderType,
  PrivateNetworkStatus,
  SyncOutboxItem
} from './src/types/lorin';

const execFileAsync = promisify(execFile);

const DATA_DIR = path.resolve(process.cwd(), 'data');
const SQLITE_DB_PATH = path.resolve(DATA_DIR, 'lorin_primary_node.sqlite');
const FALLBACK_STATE_PATH = path.resolve(DATA_DIR, 'lorin_primary_node_store.json');

// Deterministic local node encryption key derived from machine host + node secret env
const NODE_ENCRYPTION_SECRET =
  process.env.LORIN_NODE_STORAGE_KEY ||
  `lorin_node_local_key_${os.hostname()}_${os.platform()}_v2`;
const DERIVED_AES_KEY = crypto.createHash('sha256').update(NODE_ENCRYPTION_SECRET).digest();

export function encryptLocalPayload(plainText: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', DERIVED_AES_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
}

export function decryptLocalPayload(cipherPayload: string): string {
  const parts = (cipherPayload || '').split(':');
  if (parts.length !== 3) return cipherPayload;
  try {
    const iv = Buffer.from(parts[0], 'hex');
    const tag = Buffer.from(parts[1], 'hex');
    const encrypted = Buffer.from(parts[2], 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', DERIVED_AES_KEY, iv);
    decipher.setAuthTag(tag);
    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    return decrypted.toString('utf8');
  } catch {
    return '';
  }
}

export const DEFAULT_DEVICE_PERMISSIONS: Record<EnrolledDeviceType, DeviceCapabilityScope[]> = {
  primary_laptop: [
    'chat.sync',
    'voice.access',
    'vision.access',
    'knowledge.local_query',
    'ollama.local_infer',
    'projects.sync',
    'tasks.sync',
    'node.commands.read',
    'node.commands.execute'
  ],
  mobile_phone: [
    'chat.sync',
    'voice.access',
    'vision.access',
    'knowledge.local_query',
    'ollama.local_infer',
    'projects.sync',
    'tasks.sync',
    'node.commands.read'
  ],
  tablet: [
    'chat.sync',
    'voice.access',
    'vision.access',
    'knowledge.local_query',
    'ollama.local_infer',
    'projects.sync',
    'tasks.sync',
    'node.commands.read'
  ],
  secondary_laptop: [
    'chat.sync',
    'voice.access',
    'vision.access',
    'knowledge.local_query',
    'ollama.local_infer',
    'projects.sync',
    'tasks.sync',
    'node.commands.read'
  ],
  desktop_workstation: [
    'chat.sync',
    'voice.access',
    'vision.access',
    'knowledge.local_query',
    'ollama.local_infer',
    'projects.sync',
    'tasks.sync',
    'node.commands.read'
  ]
};

/**
 * Section 10: Restricted & Approved Node Command Registry
 * Never allows arbitrary shell strings. Every operation is strictly typed, bounded, and audited.
 */
export const APPROVED_NODE_COMMAND_SPECS: ApprovedNodeCommandSpec[] = [
  {
    commandId: 'ollama_list_models',
    title: 'Inspect Local Ollama Runtime & Installed Models',
    description: 'Queries the local loopback Ollama daemon (127.0.0.1:11434) for installed open-weight models and readiness.',
    category: 'AI_LOCAL',
    riskLevel: 'LOW',
    requiresOwnerApproval: false,
    requiredScope: 'node.commands.read',
    timeoutMs: 3500
  },
  {
    commandId: 'vault_index_status',
    title: 'Verify Local Knowledge Vault & SQLite Index Integrity',
    description: 'Inspects local encrypted SQLite storage and reports indexed document/chunk counts on the Primary Node.',
    category: 'KNOWLEDGE_INDEX',
    riskLevel: 'LOW',
    requiresOwnerApproval: false,
    requiredScope: 'node.commands.read',
    timeoutMs: 3000
  },
  {
    commandId: 'system_memory_probe',
    title: 'Measure Primary Laptop CPU, Memory & Uptime Telemetry',
    description: 'Reads real operating-system CPU cores, 1-minute load average, and physical RAM utilization on the Primary Node.',
    category: 'DIAGNOSTICS',
    riskLevel: 'LOW',
    requiresOwnerApproval: false,
    requiredScope: 'node.commands.read',
    timeoutMs: 2000
  },
  {
    commandId: 'node_storage_check',
    title: 'Verify Local SQLite Checkpoint & Encrypted Backup Snapshot',
    description: 'Flushes pending synchronization records to the local encrypted SQLite database and verifies checksum integrity.',
    category: 'STORAGE_HEALTH',
    riskLevel: 'MEDIUM',
    requiresOwnerApproval: false,
    requiredScope: 'node.commands.execute',
    timeoutMs: 4000
  },
  {
    commandId: 'project_workspace_verify',
    title: 'Run Local Workspace Repository Integrity Check',
    description: 'Verifies local project directory structure and synchronization revisions on the Primary Node (Owner approval required for high-impact execution).',
    category: 'PROJECT_WORKSPACE',
    riskLevel: 'HIGH',
    requiresOwnerApproval: true,
    requiredScope: 'node.commands.execute',
    timeoutMs: 5000
  }
];

/**
 * Section 4.4: PrivateNetworkAdapter Abstraction
 * Supports Tailscale (Primary), Optional WireGuard, and Optional Secure LAN (HTTPS-only).
 */
export interface PrivateNetworkAdapter {
  readonly providerType: PrivateNetworkProviderType;
  probeStatus(): Promise<{
    reachable: boolean;
    endpoint?: string;
    secureTransport: boolean;
    details: string;
  }>;
}

export class TailscaleNetworkAdapter implements PrivateNetworkAdapter {
  public readonly providerType: PrivateNetworkProviderType = 'TAILSCALE';
  private configuredTailnetEndpoint: string | null = process.env.LORIN_TAILSCALE_ENDPOINT || null;

  public setConfiguredEndpoint(endpoint: string | null): { valid: boolean; error?: string; endpoint?: string } {
    if (!endpoint || !endpoint.trim()) {
      this.configuredTailnetEndpoint = null;
      return { valid: true };
    }
    const clean = endpoint.trim().replace(/\/+$/, '');
    if (!clean.startsWith('https://')) {
      return {
        valid: false,
        error: 'Tailscale Serve endpoint must use HTTPS (e.g., https://<device-name>.<tailnet>.ts.net). Plain HTTP is rejected.'
      };
    }
    if (clean.toLowerCase().includes('funnel')) {
      return {
        valid: false,
        error: 'Section 13 Violation: Public Tailscale Funnel exposure is forbidden. Use private Tailscale Serve only.'
      };
    }
    this.configuredTailnetEndpoint = clean;
    return { valid: true, endpoint: clean };
  }

  public getConfiguredEndpoint(): string | null {
    return this.configuredTailnetEndpoint;
  }

  public async probeRealTailscaleCli(): Promise<PrivateNetworkStatus['tailscale']> {
    const now = Date.now();
    try {
      const { stdout } = await execFileAsync('tailscale', ['status', '--json'], { timeout: 1800 });
      const parsed = JSON.parse(stdout || '{}');
      const backendState = parsed.BackendState || 'NoState';
      const selfNode = parsed.Self || {};
      const dnsName = typeof selfNode.DNSName === 'string' ? selfNode.DNSName.replace(/\.$/, '') : undefined;
      const tailscaleIps: string[] = Array.isArray(selfNode.TailscaleIPs) ? selfNode.TailscaleIPs : [];
      const magicDnsEndpoint = dnsName ? `https://${dnsName}` : this.configuredTailnetEndpoint || undefined;

      let serveConfigured = Boolean(this.configuredTailnetEndpoint);
      let funnelEnabled = false;
      try {
        const serveOut = await execFileAsync('tailscale', ['serve', 'status', '--json'], { timeout: 1500 });
        const serveJson = JSON.parse(serveOut.stdout || '{}');
        if (serveJson && Object.keys(serveJson).length > 0) {
          serveConfigured = true;
        }
        if (serveJson?.AllowFunnel && Object.values(serveJson.AllowFunnel).some(Boolean)) {
          funnelEnabled = true;
        }
      } catch {
        // tailscale serve status optional
      }

      return {
        installed: true,
        backendState: backendState === 'Running' ? 'Running' : backendState,
        selfHostname: selfNode.HostName || os.hostname(),
        tailnetDomain: parsed.MagicDNSSuffix || undefined,
        magicDnsEndpoint,
        tailscaleIps,
        serveConfigured,
        serveHttpsEndpoint: magicDnsEndpoint,
        funnelEnabled,
        lastProbedAt: now,
        statusDetail:
          backendState === 'Running'
            ? `Tailscale connected (${dnsName || tailscaleIps[0] || 'active tailnet'})`
            : `Tailscale installed (BackendState: ${backendState})`
      };
    } catch {
      return {
        installed: false,
        backendState: 'NotInstalled',
        selfHostname: os.hostname(),
        tailnetDomain: undefined,
        magicDnsEndpoint: this.configuredTailnetEndpoint || undefined,
        tailscaleIps: [],
        serveConfigured: Boolean(this.configuredTailnetEndpoint),
        serveHttpsEndpoint: this.configuredTailnetEndpoint || undefined,
        funnelEnabled: false,
        lastProbedAt: now,
        statusDetail: this.configuredTailnetEndpoint
          ? `Tailscale CLI not detected on this host; Owner-configured HTTPS endpoint registered (${this.configuredTailnetEndpoint}).`
          : 'Tailscale CLI not detected on this host. Install Tailscale on your laptop and run "tailscale serve --bg 4310" to enable private remote access.'
      };
    }
  }

  public async probeStatus() {
    const ts = await this.probeRealTailscaleCli();
    const reachable = ts.backendState === 'Running' || Boolean(ts.serveHttpsEndpoint);
    return {
      reachable,
      endpoint: ts.serveHttpsEndpoint,
      secureTransport: Boolean(!ts.serveHttpsEndpoint || ts.serveHttpsEndpoint.startsWith('https://')),
      details: ts.statusDetail
    };
  }
}

export class OptionalWireGuardAdapter implements PrivateNetworkAdapter {
  public readonly providerType: PrivateNetworkProviderType = 'WIREGUARD_OPTIONAL';
  public async probeStatus() {
    return {
      reachable: false,
      secureTransport: true,
      details: 'Optional WireGuard adapter standby. Tailscale is the primary private network provider.'
    };
  }
}

export class OptionalSecureLANAdapter implements PrivateNetworkAdapter {
  public readonly providerType: PrivateNetworkProviderType = 'SECURE_LAN_OPTIONAL';
  private httpsLanEndpoint: string | null = null;

  public configureLanHttpsEndpoint(endpoint: string): { valid: boolean; error?: string } {
    const clean = (endpoint || '').trim();
    if (!clean.startsWith('https://')) {
      return {
        valid: false,
        error: 'Section 13 Violation: Direct LAN fallback strictly requires HTTPS with valid TLS certificates. Plain HTTP is forbidden.'
      };
    }
    this.httpsLanEndpoint = clean;
    return { valid: true };
  }

  public async probeStatus() {
    return {
      reachable: Boolean(this.httpsLanEndpoint),
      endpoint: this.httpsLanEndpoint || undefined,
      secureTransport: true,
      details: this.httpsLanEndpoint
        ? `Verified HTTPS LAN endpoint configured (${this.httpsLanEndpoint})`
        : 'Optional HTTPS-only LAN fallback standby (requires TLS certificate verification).'
    };
  }
}

interface PersistedNodeStore {
  nodeId: string;
  nodeName: string;
  lifecycleState: PrimaryNodeLifecycleState;
  autoStartOnBootEnabled: boolean;
  startedAt: number;
  lastHeartbeatAt: number;
  configuredTailscaleEndpoint: string | null;
  devices: Record<string, EnrolledDeviceRecord>;
  pairingChallenges: Record<string, DevicePairingChallenge>;
  conversations: Record<string, ConversationSession>;
  conversationRevisions: Record<string, number>;
  syncOutbox: SyncOutboxItem[];
  commandHistory: ApprovedNodeCommandResult[];
}

export class PrimaryNodeRuntimeEngine {
  private store: PersistedNodeStore;
  private sqliteAvailable = false;
  private sqliteDb: any = null;
  public readonly tailscaleAdapter = new TailscaleNetworkAdapter();
  public readonly wireGuardAdapter = new OptionalWireGuardAdapter();
  public readonly secureLanAdapter = new OptionalSecureLANAdapter();

  constructor() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    this.store = {
      nodeId: `node_laptop_${crypto.createHash('sha1').update(os.hostname()).digest('hex').slice(0, 10)}`,
      nodeName: `${os.hostname()} (LORIN Primary Laptop Node)`,
      lifecycleState: 'RUNNING',
      autoStartOnBootEnabled: false,
      startedAt: Date.now(),
      lastHeartbeatAt: Date.now(),
      configuredTailscaleEndpoint: process.env.LORIN_TAILSCALE_ENDPOINT || null,
      devices: {},
      pairingChallenges: {},
      conversations: {},
      conversationRevisions: {},
      syncOutbox: [],
      commandHistory: []
    };

    this.initSqliteOrEncryptedStore();
    this.ensurePrimaryLaptopDeviceRegistered('owner_bootstrap');
  }

  private initSqliteOrEncryptedStore(): void {
    try {
      // Attempt native node:sqlite (Node 22.5+ / Node 24+)
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const sqliteMod = require('node:sqlite');
      if (sqliteMod && sqliteMod.DatabaseSync) {
        this.sqliteDb = new sqliteMod.DatabaseSync(SQLITE_DB_PATH);
        this.sqliteDb.exec(`
          CREATE TABLE IF NOT EXISTS lorin_node_kv (
            key TEXT PRIMARY KEY,
            encrypted_value TEXT NOT NULL,
            updated_at INTEGER NOT NULL
          );
        `);
        this.sqliteAvailable = true;
        const row = this.sqliteDb.prepare('SELECT encrypted_value FROM lorin_node_kv WHERE key = ?').get('master_state');
        if (row && typeof row.encrypted_value === 'string') {
          const decrypted = decryptLocalPayload(row.encrypted_value);
          if (decrypted) {
            const parsed = JSON.parse(decrypted);
            this.store = { ...this.store, ...parsed, lifecycleState: parsed.lifecycleState || 'RUNNING' };
            if (this.store.configuredTailscaleEndpoint) {
              this.tailscaleAdapter.setConfiguredEndpoint(this.store.configuredTailscaleEndpoint);
            }
            return;
          }
        }
      }
    } catch {
      this.sqliteAvailable = false;
    }

    // Fallback to AES-256-GCM encrypted file store in data/
    try {
      if (fs.existsSync(FALLBACK_STATE_PATH)) {
        const raw = fs.readFileSync(FALLBACK_STATE_PATH, 'utf8');
        const decrypted = decryptLocalPayload(raw);
        if (decrypted) {
          const parsed = JSON.parse(decrypted);
          this.store = { ...this.store, ...parsed };
          if (this.store.configuredTailscaleEndpoint) {
            this.tailscaleAdapter.setConfiguredEndpoint(this.store.configuredTailscaleEndpoint);
          }
        }
      } else {
        this.persistStore();
      }
    } catch (err) {
      console.warn('[PrimaryNodeRuntime] State load notice:', err);
    }
  }

  public persistStore(): void {
    try {
      const serialized = JSON.stringify(this.store);
      const encrypted = encryptLocalPayload(serialized);
      if (this.sqliteAvailable && this.sqliteDb) {
        const stmt = this.sqliteDb.prepare(`
          INSERT INTO lorin_node_kv (key, encrypted_value, updated_at)
          VALUES (?, ?, ?)
          ON CONFLICT(key) DO UPDATE SET
            encrypted_value = excluded.encrypted_value,
            updated_at = excluded.updated_at
        `);
        stmt.run('master_state', encrypted, Date.now());
      }
      fs.writeFileSync(FALLBACK_STATE_PATH, encrypted, 'utf8');
    } catch (err) {
      console.warn('[PrimaryNodeRuntime] Failed to persist encrypted local state:', err);
    }
  }

  public ensurePrimaryLaptopDeviceRegistered(ownerUid: string): EnrolledDeviceRecord {
    const primaryDeviceId = 'dev_primary_laptop_node';
    const existing = this.store.devices[primaryDeviceId];
    const now = Date.now();
    const isNodeOnline = this.store.lifecycleState === 'RUNNING';
    const record: EnrolledDeviceRecord = {
      deviceId: primaryDeviceId,
      ownerUid: existing?.ownerUid && existing.ownerUid !== 'owner_bootstrap' ? existing.ownerUid : ownerUid,
      deviceName: existing?.deviceName || `${os.hostname()} — Primary Laptop Node`,
      deviceType: 'primary_laptop',
      platformSummary: `${os.type()} ${os.release()} (${os.arch()})`,
      isPrimaryNode: true,
      connectionState: isNodeOnline ? 'online' : this.store.lifecycleState === 'SLEEPING' ? 'sleeping' : 'offline',
      authorizationStatus: 'APPROVED',
      connectionType: this.store.configuredTailscaleEndpoint ? 'TAILSCALE' : 'LOOPBACK_LOCAL',
      tailscaleHostname: os.hostname().toLowerCase(),
      appVersion: '2.4.0-hybrid-node',
      grantedPermissions: [...DEFAULT_DEVICE_PERMISSIONS.primary_laptop],
      enrolledAt: existing?.enrolledAt || now,
      lastActiveAt: isNodeOnline ? now : existing?.lastActiveAt || now,
      lastSyncAt: existing?.lastSyncAt || now,
      trustedCachePolicy: 'PERSISTENT_TRUSTED'
    };
    this.store.devices[primaryDeviceId] = record;
    return record;
  }

  public async probeLocalOllama(): Promise<PrimaryNodeTelemetry['ollamaStatus']> {
    const endpoint = process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434';
    const now = Date.now();
    if (this.store.lifecycleState !== 'RUNNING') {
      return {
        reachable: false,
        endpoint,
        availableModels: [],
        lastCheckedAt: now,
        error: `Primary Node is ${this.store.lifecycleState}. Local Ollama is unavailable.`
      };
    }
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 1500);
      const res = await fetch(`${endpoint.replace(/\/$/, '')}/api/tags`, {
        signal: controller.signal
      });
      clearTimeout(timer);
      if (!res.ok) {
        return {
          reachable: false,
          endpoint,
          availableModels: [],
          lastCheckedAt: now,
          error: `Ollama HTTP ${res.status}`
        };
      }
      const data: any = await res.json();
      const models = Array.isArray(data?.models)
        ? data.models.map((m: any) => String(m.name || m.model || '')).filter(Boolean)
        : [];
      return {
        reachable: true,
        endpoint,
        availableModels: models,
        lastCheckedAt: now
      };
    } catch {
      return {
        reachable: false,
        endpoint,
        availableModels: [],
        lastCheckedAt: now,
        error: 'Local Ollama daemon not reachable at 127.0.0.1:11434'
      };
    }
  }

  public async getTelemetry(localKnowledgeStats?: {
    indexedDocumentsCount: number;
    indexedChunksCount: number;
    lastIndexedAt: number | null;
  }): Promise<PrimaryNodeTelemetry> {
    const isRunning = this.store.lifecycleState === 'RUNNING';
    if (isRunning) {
      this.store.lastHeartbeatAt = Date.now();
    }
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = Math.max(0, totalMem - freeMem);
    const memoryTotalMb = Math.round(totalMem / (1024 * 1024));
    const memoryUsedMb = Math.round(usedMem / (1024 * 1024));
    const memoryUsagePercent = memoryTotalMb > 0 ? Math.round((memoryUsedMb / memoryTotalMb) * 100) : 0;
    const cpus = os.cpus() || [];
    const loadAvg1m = Number((os.loadavg()[0] || 0).toFixed(2));

    let dbSizeBytes = 0;
    try {
      if (fs.existsSync(SQLITE_DB_PATH)) {
        dbSizeBytes += fs.statSync(SQLITE_DB_PATH).size;
      }
      if (fs.existsSync(FALLBACK_STATE_PATH)) {
        dbSizeBytes += fs.statSync(FALLBACK_STATE_PATH).size;
      }
    } catch {}

    const ollamaStatus = await this.probeLocalOllama();

    return {
      nodeId: this.store.nodeId,
      nodeName: this.store.nodeName,
      hostPlatform: `${os.platform()} (${os.release()})`,
      hostArch: os.arch(),
      nodeVersion: '2.4.0-primary-node',
      lifecycleState: this.store.lifecycleState,
      bindAddress: '127.0.0.1',
      bindPort: Number(process.env.LORIN_NODE_PORT || process.env.PORT || 3000),
      startedAt: this.store.startedAt,
      uptimeSeconds: isRunning ? Math.max(1, Math.round((Date.now() - this.store.startedAt) / 1000)) : 0,
      lastHeartbeatAt: this.store.lastHeartbeatAt,
      autoStartOnBootEnabled: this.store.autoStartOnBootEnabled,
      cpuCount: cpus.length || 1,
      loadAvg1m,
      memoryUsedMb,
      memoryTotalMb,
      memoryUsagePercent,
      localDatabaseEngine: 'SQLITE_ENCRYPTED_LOCAL',
      localDatabasePath: fs.existsSync(SQLITE_DB_PATH) ? SQLITE_DB_PATH : FALLBACK_STATE_PATH,
      localDatabaseSizeBytes: dbSizeBytes,
      services: {
        coreApi: isRunning ? 'RUNNING' : 'STOPPED',
        aiOrchestrator: isRunning ? 'RUNNING' : 'STOPPED',
        ollamaLocal: isRunning && ollamaStatus.reachable ? 'ONLINE' : 'OFFLINE',
        knowledgeVaultIndex: isRunning ? 'READY' : 'OFFLINE',
        syncEngine: isRunning ? 'ACTIVE' : 'OFFLINE',
        deviceManager: isRunning ? 'ACTIVE' : 'STOPPED'
      },
      ollamaStatus,
      localKnowledgeStats: {
        indexedDocumentsCount: localKnowledgeStats?.indexedDocumentsCount ?? 0,
        indexedChunksCount: localKnowledgeStats?.indexedChunksCount ?? 0,
        localOnlyFilesCount: Object.keys(this.store.conversations).length,
        lastIndexedAt: localKnowledgeStats?.lastIndexedAt ?? null
      }
    };
  }

  public setLifecycleState(
    nextState: PrimaryNodeLifecycleState,
    ownerUid: string
  ): { previousState: PrimaryNodeLifecycleState; currentState: PrimaryNodeLifecycleState; timestamp: number } {
    const previousState = this.store.lifecycleState;
    this.store.lifecycleState = nextState;
    const now = Date.now();
    if (nextState === 'RUNNING') {
      this.store.startedAt = now;
      this.store.lastHeartbeatAt = now;
    }
    this.ensurePrimaryLaptopDeviceRegistered(ownerUid);
    this.persistStore();
    return {
      previousState,
      currentState: this.store.lifecycleState,
      timestamp: now
    };
  }

  public getLifecycleState(): PrimaryNodeLifecycleState {
    return this.store.lifecycleState;
  }

  public setAutoStartOnBoot(enabled: boolean): boolean {
    this.store.autoStartOnBootEnabled = Boolean(enabled);
    this.persistStore();
    return this.store.autoStartOnBootEnabled;
  }

  public async getPrivateNetworkStatus(corsAllowedOrigins: string[] = []): Promise<PrivateNetworkStatus> {
    const tailscale = await this.tailscaleAdapter.probeRealTailscaleCli();
    const lanStatus = await this.secureLanAdapter.probeStatus();
    const activeAdapter: PrivateNetworkProviderType =
      tailscale.backendState === 'Running' || tailscale.serveConfigured
        ? 'TAILSCALE'
        : lanStatus.reachable
        ? 'SECURE_LAN_OPTIONAL'
        : 'LOOPBACK_LOCAL';

    return {
      activeAdapter,
      tailscale,
      wireGuardAdapterReady: true,
      secureLanAdapterReady: true,
      secureTransportVerified: !tailscale.funnelEnabled,
      loopbackBindingEnforced: true,
      corsAllowedOrigins
    };
  }

  public configureTailscaleEndpoint(endpoint: string | null): { valid: boolean; error?: string; endpoint?: string } {
    const res = this.tailscaleAdapter.setConfiguredEndpoint(endpoint);
    if (res.valid) {
      this.store.configuredTailscaleEndpoint = res.endpoint || null;
      this.persistStore();
    }
    return res;
  }

  /**
   * Section 7.2: Single-Use, Short-Lived QR Pairing Challenge
   * Never embeds Firebase Admin secrets, permanent API keys, or Tailscale auth keys.
   */
  public createPairingChallenge(params: {
    ownerUid: string;
    createdByDeviceId?: string;
    targetDeviceType?: EnrolledDeviceType;
    proposedDeviceName?: string;
    ttlMs?: number;
    originUrl?: string;
  }): DevicePairingChallenge {
    const now = Date.now();
    const ttl = Math.min(Math.max(params.ttlMs || 5 * 60 * 1000, 1000), 15 * 60 * 1000);
    const challengeId = `pair_${now}_${crypto.randomBytes(6).toString('hex')}`;
    const oneTimeCode = crypto.randomBytes(4).toString('hex').toUpperCase();
    const expiresAt = now + ttl;

    const qrPayloadObj = {
      protocol: 'LORIN_DEVICE_PAIR_V2',
      challengeId,
      oneTimeCode,
      expiresAt,
      targetDeviceType: params.targetDeviceType || 'mobile_phone',
      origin: params.originUrl || 'https://lorin.local'
    };

    const challenge: DevicePairingChallenge = {
      challengeId,
      ownerUid: params.ownerUid,
      createdByDeviceId: params.createdByDeviceId || 'dev_primary_laptop_node',
      oneTimeCode,
      qrPayloadString: JSON.stringify(qrPayloadObj),
      targetDeviceType: params.targetDeviceType || 'mobile_phone',
      proposedDeviceName: params.proposedDeviceName || 'Authorized Mobile Companion',
      createdAt: now,
      expiresAt,
      status: 'PENDING'
    };

    this.store.pairingChallenges[challengeId] = challenge;
    this.persistStore();
    return challenge;
  }

  public redeemPairingChallenge(params: {
    challengeId: string;
    oneTimeCode: string;
    actorUid: string;
    deviceId: string;
    deviceName: string;
    deviceType: EnrolledDeviceType;
    platformSummary: string;
    connectionType?: PrivateNetworkProviderType;
    autoApproveForOwner?: boolean;
  }): {
    success: boolean;
    status: number;
    code: string;
    message: string;
    device?: EnrolledDeviceRecord;
  } {
    const challenge = this.store.pairingChallenges[params.challengeId];
    const now = Date.now();

    if (!challenge) {
      return {
        success: false,
        status: 404,
        code: 'CHALLENGE_NOT_FOUND',
        message: 'Pairing challenge ID was not found.'
      };
    }

    if (challenge.ownerUid !== params.actorUid) {
      return {
        success: false,
        status: 403,
        code: 'CROSS_USER_PAIRING_FORBIDDEN',
        message: 'Device pairing challenge belongs to a different account.'
      };
    }

    if (challenge.status === 'CONSUMED') {
      return {
        success: false,
        status: 409,
        code: 'CHALLENGE_ALREADY_CONSUMED',
        message: 'This single-use pairing token has already been used and cannot be replayed.'
      };
    }

    if (challenge.status === 'REVOKED') {
      return {
        success: false,
        status: 403,
        code: 'CHALLENGE_REVOKED',
        message: 'This pairing challenge was revoked.'
      };
    }

    if (now > challenge.expiresAt || challenge.status === 'EXPIRED') {
      challenge.status = 'EXPIRED';
      this.persistStore();
      return {
        success: false,
        status: 400,
        code: 'CHALLENGE_EXPIRED',
        message: 'Pairing challenge has expired. Generate a fresh QR code in LORIN Device Center.'
      };
    }

    if (challenge.oneTimeCode.toUpperCase() !== (params.oneTimeCode || '').trim().toUpperCase()) {
      return {
        success: false,
        status: 401,
        code: 'INVALID_ONE_TIME_CODE',
        message: 'Invalid one-time pairing verification code.'
      };
    }

    // Consume single-use challenge
    challenge.status = 'CONSUMED';
    challenge.consumedByDeviceId = params.deviceId;
    challenge.consumedAt = now;

    const cleanDeviceId = (params.deviceId || `dev_${now}_${crypto.randomBytes(4).toString('hex')}`).replace(
      /[^a-zA-Z0-9_-]/g,
      ''
    );
    const defaultPerms = DEFAULT_DEVICE_PERMISSIONS[params.deviceType] || DEFAULT_DEVICE_PERMISSIONS.mobile_phone;
    const authStatus: DeviceAuthorizationStatus = params.autoApproveForOwner ? 'APPROVED' : 'PENDING_APPROVAL';

    const device: EnrolledDeviceRecord = {
      deviceId: cleanDeviceId,
      ownerUid: params.actorUid,
      deviceName: (params.deviceName || challenge.proposedDeviceName || 'Enrolled LORIN Device').slice(0, 120),
      deviceType: params.deviceType || challenge.targetDeviceType || 'mobile_phone',
      platformSummary: (params.platformSummary || 'Web / PWA Client').slice(0, 160),
      isPrimaryNode: false,
      connectionState: authStatus === 'APPROVED' ? 'online' : 'unauthorized',
      authorizationStatus: authStatus,
      connectionType: params.connectionType || 'TAILSCALE',
      appVersion: '2.4.0-pwa',
      grantedPermissions: [...defaultPerms],
      enrolledAt: now,
      lastActiveAt: now,
      lastSyncAt: now,
      trustedCachePolicy: 'CLEAR_ON_LOGOUT'
    };

    this.store.devices[cleanDeviceId] = device;
    this.persistStore();

    return {
      success: true,
      status: 200,
      code: 'DEVICE_ENROLLED',
      message:
        authStatus === 'APPROVED'
          ? 'Device paired and authorized for your LORIN account.'
          : 'Device paired and awaiting System Owner approval in Device Center.',
      device
    };
  }

  public listDevicesForUser(ownerUid: string, isPrivileged: boolean = false): EnrolledDeviceRecord[] {
    this.ensurePrimaryLaptopDeviceRegistered(ownerUid);
    const now = Date.now();
    const STALE_THRESHOLD_MS = 5 * 60 * 1000; // 5 minutes without heartbeat -> offline

    return Object.values(this.store.devices)
      .filter((d) => isPrivileged || d.ownerUid === ownerUid || d.isPrimaryNode)
      .map((d): EnrolledDeviceRecord => {
        if (d.isPrimaryNode) {
          return {
            ...d,
            connectionState:
              this.store.lifecycleState === 'RUNNING'
                ? 'online'
                : this.store.lifecycleState === 'SLEEPING'
                ? 'sleeping'
                : 'offline'
          };
        }
        if (d.authorizationStatus === 'REVOKED') {
          return { ...d, connectionState: 'revoked' };
        }
        if (d.authorizationStatus !== 'APPROVED') {
          return { ...d, connectionState: 'unauthorized' };
        }
        // Truthful heartbeat check: do not fabricate online state from a stale timestamp
        const isFresh = now - d.lastActiveAt <= STALE_THRESHOLD_MS;
        return {
          ...d,
          connectionState: isFresh ? d.connectionState : 'offline'
        };
      })
      .sort((a, b) => (b.isPrimaryNode ? 1 : 0) - (a.isPrimaryNode ? 1 : 0) || b.lastActiveAt - a.lastActiveAt);
  }

  public getDevice(deviceId: string): EnrolledDeviceRecord | null {
    return this.store.devices[deviceId] || null;
  }

  public verifyDeviceAccess(
    deviceId: string | undefined,
    actorUid: string,
    requiredScope?: DeviceCapabilityScope
  ): { allowed: boolean; status: number; code: string; reason?: string; device?: EnrolledDeviceRecord } {
    if (this.store.lifecycleState !== 'RUNNING') {
      return {
        allowed: false,
        status: 503,
        code: 'PRIMARY_NODE_OFFLINE',
        reason: `LORIN Primary Node is currently ${this.store.lifecycleState}. Local node services are unavailable.`
      };
    }

    if (!deviceId) {
      return {
        allowed: false,
        status: 401,
        code: 'DEVICE_ID_REQUIRED',
        reason: 'Protected Primary Node operations require an enrolled device identifier (X-Lorin-Device-Id).'
      };
    }

    const device = this.store.devices[deviceId];
    if (!device) {
      return {
        allowed: false,
        status: 403,
        code: 'DEVICE_NOT_ENROLLED',
        reason: `Device '${deviceId}' is not enrolled in LORIN Device Center.`
      };
    }

    if (!device.isPrimaryNode && device.ownerUid !== actorUid) {
      return {
        allowed: false,
        status: 403,
        code: 'CROSS_USER_DEVICE_FORBIDDEN',
        reason: 'Device belongs to a different user identity.'
      };
    }

    if (device.authorizationStatus === 'REVOKED') {
      return {
        allowed: false,
        status: 403,
        code: 'DEVICE_REVOKED',
        reason: `Device '${device.deviceName}' has been revoked by the System Owner and cannot access LORIN.`
      };
    }

    if (device.authorizationStatus === 'SUSPENDED') {
      return {
        allowed: false,
        status: 403,
        code: 'DEVICE_SUSPENDED',
        reason: `Device '${device.deviceName}' is currently suspended.`
      };
    }

    if (device.authorizationStatus !== 'APPROVED') {
      return {
        allowed: false,
        status: 403,
        code: 'DEVICE_PENDING_APPROVAL',
        reason: `Device '${device.deviceName}' is awaiting System Owner approval.`
      };
    }

    if (requiredScope && !device.grantedPermissions.includes(requiredScope)) {
      return {
        allowed: false,
        status: 403,
        code: 'DEVICE_SCOPE_DENIED',
        reason: `Device '${device.deviceName}' does not have the '${requiredScope}' permission scope.`
      };
    }

    device.lastActiveAt = Date.now();
    device.connectionState = 'online';
    return { allowed: true, status: 200, code: 'OK', device };
  }

  public recordDeviceHeartbeat(params: {
    deviceId: string;
    actorUid: string;
    connectionType?: PrivateNetworkProviderType;
    state?: DeviceConnectionState;
  }): { success: boolean; status: number; message: string; device?: EnrolledDeviceRecord } {
    const check = this.verifyDeviceAccess(params.deviceId, params.actorUid);
    if (!check.allowed || !check.device) {
      return {
        success: false,
        status: check.status,
        message: check.reason || 'Device heartbeat rejected.'
      };
    }
    check.device.lastActiveAt = Date.now();
    if (params.connectionType) {
      check.device.connectionType = params.connectionType;
    }
    check.device.connectionState = params.state === 'sleeping' ? 'sleeping' : 'online';
    this.persistStore();
    return {
      success: true,
      status: 200,
      message: 'Heartbeat recorded.',
      device: check.device
    };
  }

  public updateDeviceStatusByOwner(params: {
    deviceId: string;
    action: 'APPROVE' | 'REVOKE' | 'SUSPEND' | 'RENAME' | 'UPDATE_PERMISSIONS';
    deviceName?: string;
    permissions?: DeviceCapabilityScope[];
     trustedCachePolicy?: 'PERSISTENT_TRUSTED' | 'CLEAR_ON_LOGOUT';
    reason?: string;
  }): { success: boolean; status: number; message: string; device?: EnrolledDeviceRecord } {
    const device = this.store.devices[params.deviceId];
    if (!device) {
      return { success: false, status: 404, message: 'Device not found.' };
    }

    if (device.isPrimaryNode && (params.action === 'REVOKE' || params.action === 'SUSPEND')) {
      return {
        success: false,
        status: 400,
        message: 'Cannot revoke the Primary Laptop Node. Use Stop Node if you wish to take it offline.'
      };
    }

    const now = Date.now();
    switch (params.action) {
      case 'APPROVE':
        device.authorizationStatus = 'APPROVED';
        device.connectionState = 'online';
        device.revokedAt = undefined;
        device.revokedReason = undefined;
        break;
      case 'REVOKE':
        device.authorizationStatus = 'REVOKED';
        device.connectionState = 'revoked';
        device.grantedPermissions = [];
        device.revokedAt = now;
        device.revokedReason = params.reason || 'Revoked by System Owner in LORIN Device Center';
        break;
      case 'SUSPEND':
        device.authorizationStatus = 'SUSPENDED';
        device.connectionState = 'unauthorized';
        break;
      case 'RENAME':
        if (params.deviceName && params.deviceName.trim()) {
          device.deviceName = params.deviceName.trim().slice(0, 120);
        }
        if (params.trustedCachePolicy) {
          device.trustedCachePolicy = params.trustedCachePolicy;
        }
        break;
      case 'UPDATE_PERMISSIONS':
        if (Array.isArray(params.permissions)) {
          device.grantedPermissions = params.permissions;
        }
        if (params.trustedCachePolicy) {
          device.trustedCachePolicy = params.trustedCachePolicy;
        }
        break;
    }

    this.persistStore();
    return {
      success: true,
      status: 200,
      message: `Device '${device.deviceName}' updated (${params.action}).`,
      device
    };
  }

  public removeDevice(deviceId: string): { success: boolean; status: number; message: string } {
    const device = this.store.devices[deviceId];
    if (!device) {
      return { success: false, status: 404, message: 'Device not found.' };
    }
    if (device.isPrimaryNode) {
      return { success: false, status: 400, message: 'Cannot remove the Primary Laptop Node record.' };
    }
    delete this.store.devices[deviceId];
    this.persistStore();
    return {
      success: true,
      status: 200,
      message: `Device '${device.deviceName}' removed and its LORIN authorization invalidated.`
    };
  }

  /**
   * Section 8.2 & 8.4: Multi-Device Append-Oriented Conversation Synchronization
   * Deduplicates messages by ID, preserves conversation identity, and prevents older revisions from overwriting newer messages.
   */
  public syncConversationMessages(params: {
    userId: string;
    deviceId: string;
    conversationId: string;
    title: string;
    projectId: string;
    messages: ChatMessage[];
    clientRevision?: number;
  }): {
    success: boolean;
    status: number;
    code?: string;
    message?: string;
    conversation?: ConversationSession;
    revision?: number;
    deduplicatedCount?: number;
    conflictDetected?: boolean;
  } {
    const deviceCheck = this.verifyDeviceAccess(params.deviceId, params.userId, 'chat.sync');
    if (!deviceCheck.allowed) {
      return {
        success: false,
        status: deviceCheck.status,
        code: deviceCheck.code,
        message: deviceCheck.reason
      };
    }

    const key = `${params.userId}::${params.conversationId}`;
    const existing = this.store.conversations[key];
    const currentRev = this.store.conversationRevisions[key] || 0;
    const now = Date.now();

    let conflictDetected = false;
    if (typeof params.clientRevision === 'number' && params.clientRevision < currentRev) {
      conflictDetected = true;
    }

    const existingMessages = existing?.messages || [];
    const messageById = new Map<string, ChatMessage>();
    for (const m of existingMessages) {
      if (m && m.id) {
        messageById.set(m.id, m);
      }
    }

    let newlyAppended = 0;
    for (const incomingMsg of params.messages || []) {
      if (!incomingMsg || !incomingMsg.id) continue;
      const prior = messageById.get(incomingMsg.id);
      if (!prior) {
        messageById.set(incomingMsg.id, {
          ...incomingMsg,
          conversationId: params.conversationId
        });
        newlyAppended++;
      } else if (
        incomingMsg.content &&
        incomingMsg.content.length >= (prior.content || '').length &&
        incomingMsg.timestamp >= prior.timestamp
      ) {
        // Allow streaming completion enrichment without regressing to an older/shorter cached copy
        messageById.set(incomingMsg.id, {
          ...prior,
          ...incomingMsg,
          conversationId: params.conversationId
        });
      }
    }

    const mergedMessages = Array.from(messageById.values()).sort((a, b) => a.timestamp - b.timestamp);
    const nextRev = newlyAppended > 0 || !existing ? currentRev + 1 : currentRev;

    const updatedConv: ConversationSession = {
      id: params.conversationId,
      userId: params.userId,
      title: params.title || existing?.title || 'Synchronized LORIN Thread',
      projectId: params.projectId || existing?.projectId || 'proj_lorin_core',
      messages: mergedMessages,
      createdAt: existing?.createdAt || now,
      updatedAt: now
    };

    this.store.conversations[key] = updatedConv;
    this.store.conversationRevisions[key] = nextRev;
    if (deviceCheck.device) {
      deviceCheck.device.lastSyncAt = now;
    }
    this.persistStore();

    return {
      success: true,
      status: 200,
      conversation: updatedConv,
      revision: nextRev,
      deduplicatedCount: mergedMessages.length,
      conflictDetected
    };
  }

  public getSynchronizedConversations(userId: string): Array<{
    conversation: ConversationSession;
    revision: number;
  }> {
    const prefix = `${userId}::`;
    const results: Array<{ conversation: ConversationSession; revision: number }> = [];
    for (const [key, conv] of Object.entries(this.store.conversations)) {
      if (key.startsWith(prefix)) {
        results.push({
          conversation: conv,
          revision: this.store.conversationRevisions[key] || 1
        });
      }
    }
    return results.sort((a, b) => b.conversation.updatedAt - a.conversation.updatedAt);
  }

  /**
   * Section 10: Execute Approved Node Command with strict validation & Owner approval enforcement
   */
  public async executeApprovedCommand(params: {
    commandId: string;
    deviceId: string;
    principalId: string;
    isSystemOwner: boolean;
    ownerApproved?: boolean;
    localKnowledgeStats?: {
      indexedDocumentsCount: number;
      indexedChunksCount: number;
      lastIndexedAt: number | null;
    };
  }): Promise<{ httpStatus: number; result: ApprovedNodeCommandResult }> {
    const startedAt = Date.now();
    const executionId = `cmd_exec_${startedAt}_${crypto.randomBytes(4).toString('hex')}`;
    const spec = APPROVED_NODE_COMMAND_SPECS.find((s) => s.commandId === params.commandId);

    if (!spec) {
      const denied: ApprovedNodeCommandResult = {
        executionId,
        commandId: params.commandId,
        deviceId: params.deviceId,
        principalId: params.principalId,
        status: 'DENIED',
        outputSummary: `Command '${params.commandId}' is not in the approved LORIN Primary Node command registry. Arbitrary shell commands are forbidden.`,
        startedAt,
        completedAt: Date.now(),
        durationMs: 0
      };
      return { httpStatus: 403, result: denied };
    }

    const access = this.verifyDeviceAccess(params.deviceId, params.principalId, spec.requiredScope);
    if (!access.allowed) {
      const denied: ApprovedNodeCommandResult = {
        executionId,
        commandId: params.commandId,
        deviceId: params.deviceId,
        principalId: params.principalId,
        status: 'DENIED',
        outputSummary: access.reason || 'Device is not authorized to execute this operation.',
        startedAt,
        completedAt: Date.now(),
        durationMs: 0
      };
      return { httpStatus: access.status, result: denied };
    }

    if (spec.requiresOwnerApproval && (!params.isSystemOwner || !params.ownerApproved)) {
      const awaiting: ApprovedNodeCommandResult = {
        executionId,
        commandId: params.commandId,
        deviceId: params.deviceId,
        principalId: params.principalId,
        status: 'AWAITING_APPROVAL',
        outputSummary: `Command '${spec.title}' is classified as ${spec.riskLevel} risk and requires explicit System Owner confirmation.`,
        startedAt,
        completedAt: Date.now(),
        durationMs: 0
      };
      return { httpStatus: 202, result: awaiting };
    }

    let outputSummary = '';
    let structuredData: Record<string, unknown> = {};

    if (spec.commandId === 'ollama_list_models') {
      const ollama = await this.probeLocalOllama();
      outputSummary = ollama.reachable
        ? `Ollama reachable at ${ollama.endpoint}. Installed models (${ollama.availableModels.length}): ${ollama.availableModels.join(', ') || 'none'}`
        : `Ollama daemon is offline at ${ollama.endpoint} (${ollama.error || 'unreachable'}).`;
      structuredData = { ...ollama };
    } else if (spec.commandId === 'vault_index_status') {
      const telemetry = await this.getTelemetry(params.localKnowledgeStats);
      outputSummary = `Local Encrypted SQLite Index (${telemetry.localDatabaseEngine}) ready. Indexed Documents: ${telemetry.localKnowledgeStats.indexedDocumentsCount}, Chunks: ${telemetry.localKnowledgeStats.indexedChunksCount}, Synchronized Threads: ${telemetry.localKnowledgeStats.localOnlyFilesCount}.`;
      structuredData = { ...telemetry.localKnowledgeStats, dbSizeBytes: telemetry.localDatabaseSizeBytes };
    } else if (spec.commandId === 'system_memory_probe') {
      const telemetry = await this.getTelemetry(params.localKnowledgeStats);
      outputSummary = `Host ${telemetry.nodeName}: ${telemetry.cpuCount} CPU cores (1m load: ${telemetry.loadAvg1m}), RAM ${telemetry.memoryUsedMb}MB / ${telemetry.memoryTotalMb}MB (${telemetry.memoryUsagePercent}%), Uptime ${telemetry.uptimeSeconds}s.`;
      structuredData = {
        cpuCount: telemetry.cpuCount,
        loadAvg1m: telemetry.loadAvg1m,
        memoryUsedMb: telemetry.memoryUsedMb,
        memoryTotalMb: telemetry.memoryTotalMb,
        memoryUsagePercent: telemetry.memoryUsagePercent,
        uptimeSeconds: telemetry.uptimeSeconds
      };
    } else if (spec.commandId === 'node_storage_check') {
      this.persistStore();
      const telemetry = await this.getTelemetry(params.localKnowledgeStats);
      outputSummary = `Encrypted local SQLite store checkpointed (${telemetry.localDatabaseSizeBytes} bytes at ${ path.basename(telemetry.localDatabasePath) }).`;
      structuredData = {
        localDatabaseEngine: telemetry.localDatabaseEngine,
        localDatabaseSizeBytes: telemetry.localDatabaseSizeBytes,
        checkpointedAt: Date.now()
      };
    } else if (spec.commandId === 'project_workspace_verify') {
      const syncConvs = this.getSynchronizedConversations(params.principalId);
      outputSummary = `Verified Primary Node workspace integrity. Active synchronized conversations: ${syncConvs.length}, Enrolled devices: ${Object.keys(this.store.devices).length}.`;
      structuredData = {
        synchronizedConversations: syncConvs.length,
        enrolledDevices: Object.keys(this.store.devices).length,
        verifiedAt: Date.now()
      };
    }

    const completedAt = Date.now();
    const record: ApprovedNodeCommandResult = {
      executionId,
      commandId: spec.commandId,
      deviceId: params.deviceId,
      principalId: params.principalId,
      status: 'COMPLETED',
      outputSummary,
      structuredData,
      startedAt,
      completedAt,
      durationMs: Math.max(1, completedAt - startedAt)
    };

    this.store.commandHistory.unshift(record);
    if (this.store.commandHistory.length > 50) {
      this.store.commandHistory.pop();
    }
    this.persistStore();

    return { httpStatus: 200, result: record };
  }

  public getCommandHistory(): ApprovedNodeCommandResult[] {
    return [...this.store.commandHistory];
  }
}

export const PrimaryNodeRuntime = new PrimaryNodeRuntimeEngine();
