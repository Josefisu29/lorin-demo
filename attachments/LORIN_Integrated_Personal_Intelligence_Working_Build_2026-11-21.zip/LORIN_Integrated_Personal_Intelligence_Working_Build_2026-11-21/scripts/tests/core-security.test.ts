import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { actionDigest, canonicalJson } from '../../src/core/security/canonical.ts';
import { CapabilityRegistry, validateCapabilityInput } from '../../src/core/capabilities/registry.ts';
import { evaluateCapabilityPolicy } from '../../src/core/security/policy.ts';
import { routeModelRequest } from '../../src/core/routing/modelRouter.ts';
import { VoiceActivityDetector } from '../../src/core/voice/voiceActivityDetector.ts';
import { LorinSqliteStore } from '../../src/core/persistence/sqliteStore.ts';
import { JobService, createBuiltinCapabilities } from '../../src/core/jobs/jobService.ts';

function makeStore() {
  const directory = mkdtempSync(join(tmpdir(), 'lorin-core-test-'));
  const store = new LorinSqliteStore({
    databasePath: join(directory, 'lorin.sqlite'),
    keyFilePath: join(directory, 'storage.key'),
    encryptionKey: Buffer.alloc(32, 0x5a)
  });
  return { store, directory };
}

const standardPrincipal = {
  id: 'user-001',
  authenticated: true,
  accountStatus: 'ACTIVE',
  canonicalRole: 'STANDARD_USER',
  permissions: ['providers.read', 'projects.manage']
} as const;

const superAdminPrincipal = {
  id: 'admin-001',
  authenticated: true,
  accountStatus: 'ACTIVE',
  canonicalRole: 'SUPER_ADMIN',
  permissions: ['providers.read', 'projects.manage', 'approvals.review']
} as const;

const systemOwnerPrincipal = {
  id: 'owner-001',
  authenticated: true,
  accountStatus: 'ACTIVE',
  canonicalRole: 'SYSTEM_OWNER',
  permissions: ['providers.read', 'projects.manage', 'approvals.review']
} as const;

test('canonical JSON sorts keys and rejects ambiguous JavaScript values', () => {
  assert.equal(canonicalJson({ b: 1, a: { y: 2, x: 3 } }), '{"a":{"x":3,"y":2},"b":1}');
  assert.throws(() => canonicalJson({ value: undefined }), /Undefined value/);
  assert.throws(() => canonicalJson({ value: Number.NaN }), /Non-finite number/);
  const circular: any = {}; circular.self = circular;
  assert.throws(() => canonicalJson(circular), /Circular value/);
});

test('action digest binds identity, capability, resource and exact parameters', () => {
  const base = { principalId: 'u1', capabilityId: 'files.write', resource: 'workspace/a.txt', parameters: { text: 'A' } };
  const digest = actionDigest(base);
  assert.equal(digest, actionDigest({ ...base, parameters: { text: 'A' } }));
  assert.notEqual(digest, actionDigest({ ...base, parameters: { text: 'B' } }));
  assert.notEqual(digest, actionDigest({ ...base, resource: 'workspace/b.txt' }));
  assert.notEqual(digest, actionDigest({ ...base, principalId: 'u2' }));
});

test('capability schema blocks unknown fields and invalid inputs', () => {
  const schema = { type: 'object' as const, properties: { name: { type: 'string' as const, minLength: 1, maxLength: 20 } }, required: ['name'], additionalProperties: false };
  assert.deepEqual(validateCapabilityInput({ name: 'LORIN' }, schema), []);
  assert.ok(validateCapabilityInput({ name: '', unexpected: true }, schema).length >= 2);
  const hostile = JSON.parse('{"name":"safe","constructor":{"prototype":{"polluted":true}}}');
  assert.ok(validateCapabilityInput(hostile, schema).some(issue => issue.message.includes('prohibited') || issue.message.includes('not an allowed')));
  assert.ok(validateCapabilityInput({ name: 'x'.repeat(70_000) }, schema).some(issue => issue.message.includes('byte input limit')));
  assert.throws(() => {
    const invalidRegistry = new CapabilityRegistry();
    invalidRegistry.register({
      id: 'test.open.nested', version: 1, title: 'Invalid', description: 'Open nested schema', category: 'SYSTEM', risk: 'READ',
      requiredPermissions: [], inputSchema: { type: 'object', additionalProperties: false, properties: { nested: { type: 'object', properties: {} } } },
      timeoutMs: 500, enabled: true, execute: () => 'no'
    });
  }, /additionalProperties=false/);
  const registry = new CapabilityRegistry();
  registry.register({
    id: 'test.safe.read', version: 1, title: 'Test', description: 'Test capability', category: 'SYSTEM', risk: 'READ',
    requiredPermissions: ['providers.read'], inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    timeoutMs: 500, enabled: true, execute: () => 'ok'
  });
  registry.seal();
  assert.throws(() => registry.register({
    id: 'test.other', version: 1, title: 'Other', description: 'Other', category: 'SYSTEM', risk: 'READ',
    requiredPermissions: [], inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    timeoutMs: 500, enabled: true, execute: () => 'no'
  }), /sealed/);
});

test('server policy is deny-by-default for identity, permissions, locality and critical risk', () => {
  const capability: any = {
    id: 'test.local.read', version: 1, title: 'Read', description: 'Read only', category: 'SYSTEM', risk: 'READ',
    requiredPermissions: ['providers.read'], inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    timeoutMs: 500, localOnly: true, enabled: true, execute: () => null
  };
  assert.equal(evaluateCapabilityPolicy({ ...standardPrincipal, authenticated: false }, capability, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id }).allowed, false);
  assert.equal(evaluateCapabilityPolicy({ ...standardPrincipal, permissions: [] }, capability, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id }).allowed, false);
  assert.equal(evaluateCapabilityPolicy(standardPrincipal, capability, { executionLocation: 'CLOUD', resourceOwnerId: standardPrincipal.id }).allowed, false);
  assert.equal(evaluateCapabilityPolicy(standardPrincipal, capability, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id }).allowed, true);
  assert.equal(evaluateCapabilityPolicy(standardPrincipal, capability, { executionLocation: 'LOCAL', resourceOwnerId: '' }).allowed, false);
  assert.equal(evaluateCapabilityPolicy(standardPrincipal, { ...capability, risk: 'CRITICAL' }, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id }).allowed, false);
  assert.equal(evaluateCapabilityPolicy(standardPrincipal, { ...capability, execute: undefined }, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id }).allowed, false);
});

test('local-first router never silently sends local-only requests to cloud', () => {
  const providers = [
    { id: 'ollama', kind: 'OLLAMA_LOCAL' as const, modelId: 'qwen-local', healthy: false, enabled: true, contextWindow: 32000, capabilities: ['CHAT'] as const, estimatedLatencyMs: 100, supportsStreaming: true, supportsTools: false, lastVerifiedAt: Date.now() },
    { id: 'gemini', kind: 'GEMINI_CLOUD' as const, modelId: 'gemini', healthy: true, enabled: true, contextWindow: 100000, capabilities: ['CHAT'] as const, estimatedLatencyMs: 250, estimatedCostUsdPer1kTokens: 0.001, supportsStreaming: true, supportsTools: true, lastVerifiedAt: Date.now() }
  ];
  const localOnly = routeModelRequest({ kind: 'CHAT', privacyMode: 'LOCAL_ONLY', estimatedInputTokens: 100, estimatedOutputTokens: 100 }, providers);
  assert.equal(localOnly.selected, undefined);
  assert.match(localOnly.reason, /not sent to a cloud provider/);
  const unverifiedHealth = routeModelRequest({ kind: 'CHAT', privacyMode: 'BALANCED', estimatedInputTokens: 10, estimatedOutputTokens: 10 }, [
    { id: 'unverified', kind: 'GEMINI_CLOUD', modelId: 'gemini', healthy: true, enabled: true, contextWindow: 100000, capabilities: ['CHAT'], supportsStreaming: true, supportsTools: true }
  ]);
  assert.equal(unverifiedHealth.selected, undefined);
  assert.match(unverifiedHealth.rejected[0].reason, /timestamp-verified/);
  const permittedFallback = routeModelRequest({ kind: 'CHAT', privacyMode: 'LOCAL_PREFERRED', allowCloudFallback: true, estimatedInputTokens: 100, estimatedOutputTokens: 100 }, providers);
  assert.equal(permittedFallback.selected?.id, 'gemini');
  assert.equal(permittedFallback.requiresUserNotice, true);
});

function frame(amplitude: number, length = 320): Float32Array {
  const samples = new Float32Array(length);
  for (let i = 0; i < length; i++) samples[i] = Math.sin((2 * Math.PI * 220 * i) / 16000) * amplitude;
  return samples;
}

test('voice detector uses onset, pre-roll and silence hangover boundaries', () => {
  const vad = new VoiceActivityDetector({ noiseFloorDbfs: -60, speechMarginDb: 10, onsetMs: 40, hangoverMs: 60, preRollMs: 40, minSpeechMs: 40, maxSegmentMs: 1000 });
  const firstQuiet = vad.processFrame(frame(0.0002), 20);
  assert.equal(firstQuiet.active, false);
  const onsetOne = vad.processFrame(frame(0.2), 20);
  assert.equal(onsetOne.started, false);
  const onsetTwo = vad.processFrame(frame(0.2), 20);
  assert.equal(onsetTwo.started, true);
  assert.equal(onsetTwo.active, true);
  assert.ok((onsetTwo.preRollFrames?.length || 0) >= 2, 'pre-roll must retain onset frames');
  const silenceOne = vad.processFrame(frame(0.0001), 20);
  assert.equal(silenceOne.ended, false);
  vad.processFrame(frame(0.0001), 20);
  const silenceThree = vad.processFrame(frame(0.0001), 20);
  assert.equal(silenceThree.ended, true);
  assert.equal(silenceThree.reason, 'SILENCE');
  assert.ok(silenceThree.segmentDurationMs >= 100, 'completed segment duration must be retained');
  assert.equal(vad.isActive, false);
});

test('encrypted SQLite core persists jobs, enforces transitions and verifies chained audit', async () => {
  const { store, directory } = makeStore();
  try {
    const registry = createBuiltinCapabilities(new CapabilityRegistry());
    const jobs = new JobService(store, registry);
    const created = jobs.create(standardPrincipal, {
      capabilityId: 'lorin.system.health.read', resource: 'local-node', parameters: {}
    }, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id });
    assert.equal(created.job.state, 'QUEUED');
    const running = store.claimNextJob('worker-test');
    assert.equal(running?.state, 'RUNNING');
    const completed = await jobs.runOne('worker-2', 'LOCAL_NODE', () => standardPrincipal);
    assert.equal(completed, undefined); // The only queue item was already claimed by worker-test.
    const finished = store.transitionJob({
      jobId: running!.id, workerId: 'worker-test', nextState: 'COMPLETED', actorUid: 'worker-test',
      receipt: { verified: false, output: 'read-only test' }, reason: 'Test completion receipt.'
    });
    assert.equal(finished.state, 'COMPLETED');
    assert.equal(store.getJob(finished.id, standardPrincipal.id)?.receipt && (store.getJob(finished.id, standardPrincipal.id)!.receipt as any).verified, false);
    assert.equal(store.verifyAuditChain().valid, true);

    const raw = (store as any).db.prepare('SELECT payload_ciphertext FROM lorin_jobs WHERE job_id = ?').get(created.job.id);
    assert.equal(String(raw.payload_ciphertext).includes('system'), false);

    const second = jobs.create(standardPrincipal, {
      capabilityId: 'lorin.system.health.read', resource: 'other-local-node', parameters: {}
    }, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id });
    const firstPayload = (store as any).db.prepare('SELECT payload_iv, payload_tag, payload_ciphertext FROM lorin_jobs WHERE job_id = ?').get(created.job.id);
    (store as any).db.prepare('UPDATE lorin_jobs SET payload_iv = ?, payload_tag = ?, payload_ciphertext = ? WHERE job_id = ?')
      .run(firstPayload.payload_iv, firstPayload.payload_tag, firstPayload.payload_ciphertext, second.job.id);
    assert.throws(() => store.getJob(second.job.id, standardPrincipal.id), /authenticate|state/i,
      'AES-GCM associated data must prevent ciphertext from being moved between job records');

    store.close();
    const reopened = new LorinSqliteStore({ databasePath: join(directory, 'lorin.sqlite'), keyFilePath: join(directory, 'storage.key'), encryptionKey: Buffer.alloc(32, 0x5a) });
    assert.equal(reopened.getJob(created.job.id, standardPrincipal.id)?.state, 'COMPLETED');
    assert.throws(() => reopened.transitionJob({ jobId: created.job.id, nextState: 'VERIFIED', actorUid: 'untrusted', reason: 'attempt' }), /INVALID_JOB_TRANSITION/);
    assert.equal(reopened.verifyAuditChain().valid, true);
    reopened.close();
  } finally {
    try { store.close(); } catch {}
    rmSync(directory, { recursive: true, force: true });
  }
});

test('approval is bound to exact owner, resource and parameters, then consumed once before execution', async () => {
  const { store, directory } = makeStore();
  let executions = 0;
  try {
    const registry = new CapabilityRegistry();
    registry.register({
      id: 'test.project.change', version: 1, title: 'Change project', description: 'Test approval path', category: 'PROJECT', risk: 'MODERATE',
      requiredPermissions: ['projects.manage'],
      inputSchema: { type: 'object', properties: { value: { type: 'string', minLength: 1, maxLength: 20 } }, required: ['value'], additionalProperties: false },
      timeoutMs: 1_000, enabled: true, requiresApproval: true,
      execute: (input: any, context) => { if (context.signal.aborted) throw new Error('ABORTED'); executions++; return { changed: input.value }; }
    });
    registry.seal();
    const jobs = new JobService(store, registry);
    const created = jobs.create(superAdminPrincipal, {
      capabilityId: 'test.project.change', resource: 'project/demo', parameters: { value: 'release' }
    }, { executionLocation: 'LOCAL', resourceOwnerId: superAdminPrincipal.id });
    assert.equal(created.job.state, 'AWAITING_APPROVAL');
    assert.ok(created.approval);
    assert.throws(() => jobs.approve(created.job.id, created.approval!.id, superAdminPrincipal), /INDEPENDENT_APPROVER_REQUIRED/);
    const queued = jobs.approve(created.job.id, created.approval!.id, systemOwnerPrincipal);
    assert.equal(queued.state, 'QUEUED');
    const completed = await jobs.runOne('trusted-worker', 'LOCAL_NODE', uid => uid === superAdminPrincipal.id ? superAdminPrincipal : null);
    assert.equal(completed?.state, 'COMPLETED');
    assert.equal(executions, 1);
    assert.equal(store.getApproval(created.approval!.id)?.status, 'CONSUMED');
    assert.equal(await jobs.runOne('trusted-worker-second-attempt', 'LOCAL_NODE', uid => uid === superAdminPrincipal.id ? superAdminPrincipal : null), undefined,
      'a completed job is not re-queued and its consumed approval cannot execute again');

    const ownerCreated = jobs.create(systemOwnerPrincipal, {
      capabilityId: 'test.project.change', resource: 'project/owner-change', parameters: { value: 'approved' }
    }, { executionLocation: 'LOCAL', resourceOwnerId: systemOwnerPrincipal.id });
    assert.throws(() => jobs.approve(ownerCreated.job.id, ownerCreated.approval!.id, systemOwnerPrincipal), /INDEPENDENT_APPROVER_REQUIRED/);
    const cancelled = jobs.cancel(ownerCreated.job.id, systemOwnerPrincipal);
    assert.equal(cancelled.state, 'CANCELLED');
    assert.equal(store.getApproval(ownerCreated.approval!.id)?.status, 'DENIED');
    assert.equal(store.verifyAuditChain().valid, true);
  } finally {
    store.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

test('queued jobs are re-authorized against current account permissions at execution time', async () => {
  const { store, directory } = makeStore();
  let executions = 0;
  try {
    const registry = new CapabilityRegistry();
    registry.register({
      id: 'test.project.publish', version: 1, title: 'Publish project', description: 'Requires current project write permission',
      category: 'PROJECT', risk: 'MODERATE', requiredPermissions: ['projects.publish'],
      inputSchema: { type: 'object', properties: { version: { type: 'string', minLength: 1, maxLength: 20 } }, required: ['version'], additionalProperties: false },
      timeoutMs: 1_000, enabled: true, requiresApproval: true,
      execute: () => { executions += 1; return { published: true }; }
    });
    registry.seal();
    const jobs = new JobService(store, registry);
    const creator = { ...standardPrincipal, permissions: ['providers.read', 'projects.publish'] };
    const created = jobs.create(creator, {
      capabilityId: 'test.project.publish', resource: 'project/demo', parameters: { version: '1.0.0' }
    }, { executionLocation: 'LOCAL', resourceOwnerId: creator.id });
    assert.ok(created.approval);
    jobs.approve(created.job.id, created.approval.id, systemOwnerPrincipal);

    // The permission is removed after approval but before the worker runs.
    const current = { ...creator, permissions: ['providers.read'] };
    const result = await jobs.runOne('revalidation-worker', 'LOCAL_NODE', uid => uid === creator.id ? current : null);
    assert.equal(result?.state, 'BLOCKED');
    assert.equal(result?.errorCode, 'EXECUTION_POLICY_REVALIDATION_FAILED');
    assert.equal(executions, 0, 'revoked permissions must block execution even after approval');
    assert.equal(store.getApproval(created.approval.id)?.status, 'CONSUMED', 'approval remains single-use even when policy revalidation denies execution');
  } finally {
    store.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

test('worker blocks execution when no trusted principal resolver is supplied', async () => {
  const { store, directory } = makeStore();
  let executions = 0;
  try {
    const registry = new CapabilityRegistry();
    registry.register({
      id: 'test.safe.read', version: 1, title: 'Safe read', description: 'Read-only fail-closed test',
      category: 'SYSTEM', risk: 'READ', requiredPermissions: ['providers.read'],
      inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
      timeoutMs: 500, enabled: true,
      execute: () => { executions += 1; return { ok: true }; }
    });
    registry.seal();
    const jobs = new JobService(store, registry);
    const created = jobs.create(standardPrincipal, {
      capabilityId: 'test.safe.read', resource: 'local', parameters: {}
    }, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id });

    const blocked = await jobs.runOne('resolver-missing-worker', 'LOCAL_NODE');
    assert.equal(blocked?.id, created.job.id);
    assert.equal(blocked?.state, 'BLOCKED');
    assert.equal(blocked?.errorCode, 'PRINCIPAL_REVALIDATION_FAILED');
    assert.equal(executions, 0, 'executor must never run without a trusted principal resolver');
  } finally {
    store.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

test('worker blocks jobs created before the owner session was revoked', async () => {
  const { store, directory } = makeStore();
  let executions = 0;
  try {
    const registry = new CapabilityRegistry();
    registry.register({
      id: 'test.safe.session-check', version: 1, title: 'Session check', description: 'Read-only session revocation test',
      category: 'SYSTEM', risk: 'READ', requiredPermissions: ['providers.read'],
      inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
      timeoutMs: 500, enabled: true,
      execute: () => { executions += 1; return { ok: true }; }
    });
    registry.seal();
    const jobs = new JobService(store, registry);
    const created = jobs.create(standardPrincipal, {
      capabilityId: 'test.safe.session-check', resource: 'local', parameters: {}
    }, { executionLocation: 'LOCAL', resourceOwnerId: standardPrincipal.id });

    const blocked = await jobs.runOne('revoked-session-worker', 'LOCAL_NODE', uid =>
      uid === standardPrincipal.id
        ? { ...standardPrincipal, sessionRevokedAt: created.job.createdAt + 1 }
        : null
    );
    assert.equal(blocked?.state, 'BLOCKED');
    assert.equal(blocked?.errorCode, 'SESSION_REVOKED_AFTER_JOB_CREATION');
    assert.equal(executions, 0, 'revoked sessions must not reach capability execution');
  } finally {
    store.close();
    rmSync(directory, { recursive: true, force: true });
  }
});

test('audit chain detects tampering', () => {
  const { store, directory } = makeStore();
  try {
    store.recordAudit({ ownerUid: 'u1', actorUid: 'u1', action: 'test', resource: 'r', decision: 'INFO', reason: 'original' });
    assert.equal(store.verifyAuditChain().valid, true);
    (store as any).db.prepare("UPDATE lorin_audit_events SET reason = 'tampered' WHERE sequence = 1").run();
    assert.equal(store.verifyAuditChain().valid, false);
  } finally {
    store.close();
    rmSync(directory, { recursive: true, force: true });
  }
});
