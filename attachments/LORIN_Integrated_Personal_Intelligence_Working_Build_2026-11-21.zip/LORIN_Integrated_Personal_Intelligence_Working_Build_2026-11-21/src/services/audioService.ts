/**
 * Real Web Audio API, Hybrid Speech Recognition (Web Speech API + Cloud Gemini 3.5 Transcribe),
 * and Dual-Engine Speech Synthesis (Gemini 3.8 Flash-Lite Neural TTS + Browser SpeechSynthesis) Service.
 */
import { CommunicationManager } from './communicationManager';
import { getAuthHeaders } from './authHeaders';
import { VoiceActivityDetector, type VoiceFrameResult } from '../core/voice/voiceActivityDetector';

export interface AudioDspConfig {
  enableHardwareSuppression: boolean;
  enableHighpass: boolean;
  enableDspBandpass?: boolean;
  highpassFreq: number; // 40Hz to 300Hz (default 85Hz)
  enableLowpass: boolean;
  lowpassFreq: number; // default 8000Hz
  noiseGateThreshold: number; // 0 to 50%
  isGateActive: boolean;
  attackTimeMs: number; // 10ms - 30ms (default 15ms)
  releaseTimeMs: number; // 100ms - 300ms (default 180ms)
  calibratedAmbientDbfs: number; // Calibrated ambient room noise floor in dBFS
}

export interface AudioVisualizerData {
  volume: number; // 0 to 100 (after noise gate)
  rawVolume: number; // 0 to 100 (before noise gate)
  frequencies: Uint8Array;
  isGateSuppressed: boolean;
  rmsDbfs: number; // Current measured RMS level in dBFS (-90 to 0)
  thresholdDbfs: number; // Current noise gate cutoff in dBFS
  currentGain: number; // 0.0 to 1.0 dynamic processor gain
  highpassFreq: number;
}

export class AudioService {
  private static audioContext: AudioContext | null = null;
  private static mediaStream: MediaStream | null = null;
  private static processedStream: MediaStream | null = null;
  private static analyserNode: AnalyserNode | null = null;
  private static rawAnalyserNode: AnalyserNode | null = null;
  private static sourceNode: MediaStreamAudioSourceNode | null = null;
  private static highpassFilter: BiquadFilterNode | null = null;
  private static lowpassFilter: BiquadFilterNode | null = null;
  private static processorNode: ScriptProcessorNode | null = null;
  private static processedDestination: MediaStreamAudioDestinationNode | null = null;
  private static gateGainNode: GainNode | null = null;
  private static recognition: any = null;
  private static voiceActivityDetector: VoiceActivityDetector | null = null;
  private static voiceActivityListener: ((event: VoiceFrameResult) => void) | null = null;
  private static wakeWordRecognition: any = null;
  private static mediaRecorder: MediaRecorder | null = null;
  private static recordedChunks: Blob[] = [];
  private static isRecordingAudioClip = false;
  private static activeAudioElement: HTMLAudioElement | null = null;
  private static isListeningSpeech = false;
  private static isListeningWakeWord = false;
  private static isCurrentlySpeaking = false;
  private static isPausedSpeech = false;
  private static preferCloudNeuralTts = false;

  private static currentGain = 1.0;
  private static isGateSuppressed = false;
  private static currentRmsDbfs = -90;
  private static currentThresholdDbfs = -55;

  private static dspConfig: AudioDspConfig = {
    enableHardwareSuppression: true,
    enableHighpass: true,
    enableDspBandpass: true,
    highpassFreq: 85,
    enableLowpass: true,
    lowpassFreq: 8000,
    noiseGateThreshold: 12,
    isGateActive: false,
    attackTimeMs: 15,
    releaseTimeMs: 180,
    calibratedAmbientDbfs: -55
  };

  /**
   * Feature detection
   */
  static isSpeechRecognitionSupported(): boolean {
    return typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window);
  }

  static isSpeechSynthesisSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  static getDspConfig(): AudioDspConfig {
    return { ...this.dspConfig };
  }

  static getProcessedMediaStream(): MediaStream | null {
    return this.processedStream || this.mediaStream;
  }

  static getAudioContext(): AudioContext | null {
    return this.audioContext;
  }

  static getAnalyserNode(): AnalyserNode | null {
    return this.analyserNode;
  }

  /**
   * Attach an optional VAD event listener to the live microphone DSP pipeline.
   * The listener receives speech start/end boundaries only; raw audio is never
   * persisted or transmitted by this detector.
   */
  static setVoiceActivityListener(listener: ((event: VoiceFrameResult) => void) | null): void {
    this.voiceActivityListener = listener;
    if (listener && !this.voiceActivityDetector) {
      this.voiceActivityDetector = new VoiceActivityDetector();
    }
    if (!listener) {
      this.voiceActivityDetector?.reset();
      this.voiceActivityDetector = null;
    }
  }

  static getVoiceActivityStatus(): { enabled: boolean; active: boolean; noiseFloorDbfs: number | null } {
    return {
      enabled: Boolean(this.voiceActivityListener && this.voiceActivityDetector),
      active: this.voiceActivityDetector?.isActive ?? false,
      noiseFloorDbfs: this.voiceActivityDetector?.currentNoiseFloorDbfs ?? null
    };
  }

  /**
   * Dynamically update DSP audio parameters in real time
   */
  static updateDspConfig(partial: Partial<AudioDspConfig>): void {
    this.dspConfig = { ...this.dspConfig, ...partial };

    if (this.highpassFilter && partial.highpassFreq !== undefined) {
      this.highpassFilter.frequency.setValueAtTime(
        this.dspConfig.highpassFreq,
        this.audioContext ? this.audioContext.currentTime : 0
      );
    }

    if (this.lowpassFilter && partial.lowpassFreq !== undefined) {
      this.lowpassFilter.frequency.setValueAtTime(
        this.dspConfig.lowpassFreq,
        this.audioContext ? this.audioContext.currentTime : 0
      );
    }

    if (partial.enableHighpass !== undefined || partial.enableLowpass !== undefined) {
      this.reconnectAudioChain();
    }
  }

  /**
   * Connects or bypasses the Web Audio API filter graph and noise gate processor
   */
  private static reconnectAudioChain(): void {
    if (!this.sourceNode || !this.analyserNode || !this.audioContext) return;

    try {
      this.sourceNode.disconnect();
      if (this.highpassFilter) this.highpassFilter.disconnect();
      if (this.lowpassFilter) this.lowpassFilter.disconnect();
      if (this.processorNode) this.processorNode.disconnect();
      if (this.gateGainNode) this.gateGainNode.disconnect();

      let lastNode: AudioNode = this.sourceNode;

      // 1. High-Pass Filter (removes low-frequency rumble, AC hum, wind)
      if (this.dspConfig.enableHighpass && this.highpassFilter) {
        lastNode.connect(this.highpassFilter);
        lastNode = this.highpassFilter;
      }

      // 2. Low-Pass Filter (cuts supersonic hiss)
      if (this.dspConfig.enableLowpass && this.lowpassFilter) {
        lastNode.connect(this.lowpassFilter);
        lastNode = this.lowpassFilter;
      }

      // 3. Web Audio API Noise Gate Processor Node
      if (this.processorNode) {
        lastNode.connect(this.processorNode);
        lastNode = this.processorNode;
      }

      // 4. Analyser Node for FFT frequency data & metering
      lastNode.connect(this.analyserNode);

      // 5. Route to Processed MediaStream Destination
      if (this.processedDestination) {
        this.analyserNode.connect(this.processedDestination);
      }
    } catch (e) {
      console.warn('Audio graph reconnect notice:', e);
    }
  }

  /**
   * Probes microphone permission status via getUserMedia and releases temporary tracks immediately.
   */
  static async requestMicrophonePermission(): Promise<{
    granted: boolean;
    state: 'granted' | 'denied' | 'prompt';
    error?: string;
  }> {
    try {
      if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return { granted: false, state: 'denied', error: 'getUserMedia is not supported in this browser.' };
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      return { granted: true, state: 'granted' };
    } catch (err: any) {
      return {
        granted: false,
        state: 'denied',
        error: err?.message || 'Microphone access denied.'
      };
    }
  }

  /**
   * Starts microphone capture, initializes Web Audio API DSP processor, and attaches AnalyserNode
   */
  static async startMicrophone(onAudioFrame?: (data: AudioVisualizerData) => void): Promise<{ success: boolean; error?: string }> {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return { success: false, error: 'Web Audio / getUserMedia is not supported in this browser environment.' };
      }

      // Explicit user-permission request with platform AEC + noise suppression constraints
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: this.dspConfig.enableHardwareSuppression,
          autoGainControl: true
        }
      });

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new AudioCtx();
      this.sourceNode = this.audioContext.createMediaStreamSource(this.mediaStream);
      if (this.voiceActivityListener && !this.voiceActivityDetector) {
        this.voiceActivityDetector = new VoiceActivityDetector();
      }
      this.voiceActivityDetector?.reset();

      // 1. High-Pass BiquadFilter (default 85Hz, Butterworth Q = 0.707)
      this.highpassFilter = this.audioContext.createBiquadFilter();
      this.highpassFilter.type = 'highpass';
      this.highpassFilter.frequency.setValueAtTime(this.dspConfig.highpassFreq, this.audioContext.currentTime);
      this.highpassFilter.Q.setValueAtTime(0.707, this.audioContext.currentTime);

      // 2. Low-Pass BiquadFilter (8000 Hz, Butterworth Q = 0.707)
      this.lowpassFilter = this.audioContext.createBiquadFilter();
      this.lowpassFilter.type = 'lowpass';
      this.lowpassFilter.frequency.setValueAtTime(this.dspConfig.lowpassFreq, this.audioContext.currentTime);
      this.lowpassFilter.Q.setValueAtTime(0.707, this.audioContext.currentTime);

      // 3. Web Audio API Stream Processor (1024 sample frame buffer)
      // Directly operates on sample buffers: calculates RMS dBFS and applies smooth attack/release noise gating
      this.processorNode = this.audioContext.createScriptProcessor(1024, 1, 1);
      this.processorNode.onaudioprocess = (event: AudioProcessingEvent) => {
        const inputData = event.inputBuffer.getChannelData(0);
        const outputData = event.outputBuffer.getChannelData(0);
        const sampleCount = inputData.length;

        // Calculate Block RMS
        let sumSquares = 0;
        for (let i = 0; i < sampleCount; i++) {
          sumSquares += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sumSquares / sampleCount);
        const dbfs = rms > 0.000001 ? 20 * Math.log10(rms) : -90;
        this.currentRmsDbfs = dbfs;

        // VAD observes the un-gated input so the DSP noise gate cannot clip the
        // first phoneme. It only emits timing/level boundaries; transcription
        // remains a separate, explicitly started user-facing operation.
        if (this.voiceActivityDetector && this.voiceActivityListener) {
          try {
            const frameDurationMs = (sampleCount / (this.audioContext?.sampleRate || 44_100)) * 1000;
            const voiceEvent = this.voiceActivityDetector.processFrame(inputData, frameDurationMs);
            if (voiceEvent.started || voiceEvent.ended) this.voiceActivityListener(voiceEvent);
          } catch (vadError) {
            console.warn('LORIN voice activity detection paused after invalid audio frame:', vadError);
            this.voiceActivityDetector.reset();
          }
        }

        // Map noiseGateThreshold (0-50%) to dBFS threshold (-65dBFS to -20dBFS)
        const thresholdDbfs = this.dspConfig.noiseGateThreshold === 0
          ? -100 // Threshold 0% = Gate always fully open
          : -65 + (this.dspConfig.noiseGateThreshold / 50) * 45;
        this.currentThresholdDbfs = thresholdDbfs;

        // Determine target gain
        const isAboveThreshold = dbfs >= thresholdDbfs || this.dspConfig.noiseGateThreshold === 0;
        const targetGain = isAboveThreshold ? 1.0 : 0.005; // -46dB suppression for ambient noise

        // Smooth attack / release envelope smoothing
        const sampleRate = this.audioContext?.sampleRate || 44100;
        const attackCoeff = Math.exp(-1 / ((this.dspConfig.attackTimeMs / 1000) * (sampleRate / 1024)));
        const releaseCoeff = Math.exp(-1 / ((this.dspConfig.releaseTimeMs / 1000) * (sampleRate / 1024)));
        const smoothingFactor = targetGain > this.currentGain ? (1 - attackCoeff) : (1 - releaseCoeff);

        this.currentGain += (targetGain - this.currentGain) * smoothingFactor;
        this.isGateSuppressed = this.currentGain < 0.1 && this.dspConfig.noiseGateThreshold > 0;
        this.dspConfig.isGateActive = this.isGateSuppressed;

        // Apply gain to output buffer samples
        for (let i = 0; i < sampleCount; i++) {
          outputData[i] = inputData[i] * this.currentGain;
        }
      };

      // 4. Analyser Node for FFT frequency & visualizer metering
      this.analyserNode = this.audioContext.createAnalyser();
      this.analyserNode.fftSize = 64;
      this.analyserNode.smoothingTimeConstant = 0.8;

      // 5. Raw Analyser Node for pre-gate comparison
      this.rawAnalyserNode = this.audioContext.createAnalyser();
      this.rawAnalyserNode.fftSize = 64;
      this.sourceNode.connect(this.rawAnalyserNode);

      // 6. MediaStreamDestination for the processed stream
      this.processedDestination = this.audioContext.createMediaStreamDestination();
      this.processedStream = this.processedDestination.stream;

      // Connect chained DSP nodes
      this.reconnectAudioChain();

      // Start visualizer loop if callback provided
      if (onAudioFrame) {
        this.runVisualizerLoop(onAudioFrame);
      }

      return { success: true };
    } catch (err: any) {
      this.stopMicrophone();
      return { success: false, error: err.message || 'Microphone access denied or hardware unavailable.' };
    }
  }

  /**
   * Room Noise Floor Calibration:
   * Measures room ambient noise for a set duration, calculates average baseline dBFS,
   * and automatically sets the optimal noise gate threshold right above the ambient floor.
   */
  static async calibrateNoiseFloor(
    durationMs: number = 1500,
    onProgress?: (percent: number) => void
  ): Promise<{ ambientDbfs: number; recommendedThreshold: number }> {
    if (!this.mediaStream || !this.mediaStream.active) {
      throw new Error('Microphone must be active to calibrate room noise floor.');
    }

    const samples: number[] = [];
    const intervalMs = 50;
    const totalSteps = Math.floor(durationMs / intervalMs);
    let step = 0;

    return new Promise((resolve) => {
      const timer = setInterval(() => {
        samples.push(this.currentRmsDbfs);
        step++;
        if (onProgress) {
          onProgress(Math.min(100, Math.round((step / totalSteps) * 100)));
        }

        if (step >= totalSteps) {
          clearInterval(timer);

          // Calculate average ambient noise in dBFS
          const validSamples = samples.filter(s => s > -85);
          const avgDbfs = validSamples.length > 0
            ? validSamples.reduce((a, b) => a + b, 0) / validSamples.length
            : -55;

          const roundedAvg = Math.round(avgDbfs * 10) / 10;

          // Recommend threshold ~4dB above ambient room noise floor
          const targetCutoffDbfs = roundedAvg + 4;
          // Invert formula: threshold% = ((cutoff - (-65)) / 45) * 50
          const recommended = Math.max(5, Math.min(45, Math.round(((targetCutoffDbfs - (-65)) / 45) * 50)));

          // Auto-apply calibration
          this.updateDspConfig({
            noiseGateThreshold: recommended,
            calibratedAmbientDbfs: roundedAvg
          });

          resolve({
            ambientDbfs: roundedAvg,
            recommendedThreshold: recommended
          });
        }
      }, intervalMs);
    });
  }

  private static runVisualizerLoop(callback: (data: AudioVisualizerData) => void): void {
    if (!this.analyserNode) return;

    const bufferLength = this.analyserNode.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    const rawDataArray = new Uint8Array(bufferLength);

    const update = () => {
      if (!this.analyserNode || !this.mediaStream || !this.mediaStream.active) return;
      this.analyserNode.getByteFrequencyData(dataArray);

      if (this.rawAnalyserNode) {
        this.rawAnalyserNode.getByteFrequencyData(rawDataArray);
      }

      // Calculate raw volume from rawAnalyserNode
      let rawSum = 0;
      for (let i = 0; i < bufferLength; i++) {
        rawSum += rawDataArray[i];
      }
      const rawAvg = rawSum / bufferLength;
      const rawVolume = Math.min(100, Math.round((rawAvg / 255) * 100 * 1.5));

      // Calculate processed volume
      let sum = 0;
      for (let i = 0; i < bufferLength; i++) {
        sum += dataArray[i];
      }
      const avg = sum / bufferLength;
      const volume = this.isGateSuppressed ? 0 : Math.min(100, Math.round((avg / 255) * 100 * 1.5));

      callback({
        volume,
        rawVolume,
        frequencies: this.isGateSuppressed ? new Uint8Array(bufferLength) : dataArray,
        isGateSuppressed: this.isGateSuppressed,
        rmsDbfs: Math.round(this.currentRmsDbfs * 10) / 10,
        thresholdDbfs: Math.round(this.currentThresholdDbfs * 10) / 10,
        currentGain: Math.round(this.currentGain * 100) / 100,
        highpassFreq: this.dspConfig.highpassFreq
      });

      if (this.mediaStream?.active) {
        requestAnimationFrame(update);
      }
    };

    requestAnimationFrame(update);
  }

  /**
   * Starts Web Speech API transcription with real-time state updates and fatal error recovery.
   */
  static startSpeechRecognition(
    onTranscript: (transcript: string, isFinal: boolean) => void,
    onError: (err: string) => void
  ): boolean {
    if (!this.isSpeechRecognitionSupported()) {
      onError('Browser Web Speech API is unavailable. Use the Cloud Voice Clip Recorder (Gemini 3.5 Transcribe) or Chrome/Edge.');
      return false;
    }

    try {
      this.stopSpeechRecognition();
      const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      this.recognition = new SpeechRec();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';

      this.recognition.onstart = () => {
        CommunicationManager.transition('listening', 'Listening for speech');
      };

      this.recognition.onspeechstart = () => {
        CommunicationManager.transition('receiving_audio', 'Detecting active voice input');
      };

      this.recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        const text = final || interim;
        if (text.trim()) {
          if (final) {
            CommunicationManager.transition('transcript_ready', 'Speech converted to text');
          } else {
            CommunicationManager.transition('receiving_audio', 'Transcribing live speech');
          }
          onTranscript(text.trim(), !!final);
        }
      };

      this.recognition.onerror = (event: any) => {
        const errCode = String(event?.error || 'unknown');
        console.warn('SpeechRecognition error:', errCode);
        if (errCode === 'aborted') {
          return;
        }
        if (errCode === 'no-speech') {
          // Non-fatal: keep listening or notify softly
          return;
        }
        // Fatal errors: stop infinite restart loop and report truthfully
        if (['not-allowed', 'service-not-allowed', 'audio-capture', 'network'].includes(errCode)) {
          this.isListeningSpeech = false;
          if (errCode === 'not-allowed' || errCode === 'service-not-allowed') {
            CommunicationManager.setMicrophoneStatus('denied', true);
            CommunicationManager.transition('permission_required', 'Microphone or speech recognition permission denied');
            onError('Speech recognition permission denied (`not-allowed`). Allow microphone access or use the Cloud Audio Clip Recorder.');
          } else if (errCode === 'network') {
            CommunicationManager.failRequestTrace({
              code: 'SPEECH_NETWORK_ERROR',
              message: 'Browser Web Speech service network error. Switch to Cloud Audio Clip Recorder (Gemini 3.5 Transcribe).',
              retryable: true
            });
            onError('Browser Web Speech API encountered a network error. Click "Record Cloud Clip" to transcribe via LORIN Cloud.');
          } else {
            onError(`Speech recognition hardware error: ${errCode}`);
          }
          return;
        }
        onError(`Speech recognition error: ${errCode}`);
      };

      this.recognition.onend = () => {
        if (this.isListeningSpeech && !this.isMicTrackMuted) {
          try {
            this.recognition.start();
          } catch {
            // Already restarted or stopped
          }
        }
      };

      this.isListeningSpeech = true;
      this.recognition.start();
      CommunicationManager.transition('listening', 'Listening to you');
      return true;
    } catch (e: any) {
      this.isListeningSpeech = false;
      onError(e.message || 'Failed to initialize speech recognition');
      return false;
    }
  }

  static stopSpeechRecognition(): void {
    this.isListeningSpeech = false;
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {
        // Ignore
      }
      this.recognition = null;
    }
  }

  /**
   * Cloud-Backed MediaRecorder Voice Capture (Works in all modern browsers with MediaRecorder,
   * even when Web Speech API is unsupported or blocked).
   */
  static isMediaRecorderSupported(): boolean {
    return typeof window !== 'undefined' && typeof MediaRecorder !== 'undefined';
  }

  static isRecordingClip(): boolean {
    return this.isRecordingAudioClip;
  }

  static async startClipRecording(): Promise<{ success: boolean; error?: string }> {
    try {
      if (!this.isMediaRecorderSupported()) {
        return { success: false, error: 'MediaRecorder API is not supported in this browser.' };
      }

      CommunicationManager.transition('initializing', 'Preparing microphone for voice capture');

      if (!this.mediaStream || !this.mediaStream.active) {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          CommunicationManager.setMicrophoneStatus('denied', false);
          return { success: false, error: 'Microphone capture (getUserMedia) is unavailable.' };
        }
        CommunicationManager.transition('requesting_permission', 'Requesting microphone access');
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
          }
        });
        CommunicationManager.setMicrophoneStatus('granted', true);
      }

      this.recordedChunks = [];
      const candidateMimeTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/mp4',
        'audio/ogg;codecs=opus'
      ];
      const supportedMime = candidateMimeTypes.find((m) => {
        try {
          return typeof MediaRecorder.isTypeSupported === 'function' && MediaRecorder.isTypeSupported(m);
        } catch {
          return false;
        }
      });

      this.mediaRecorder = supportedMime
        ? new MediaRecorder(this.mediaStream, { mimeType: supportedMime })
        : new MediaRecorder(this.mediaStream);

      this.mediaRecorder.ondataavailable = (event: BlobEvent) => {
        if (event.data && event.data.size > 0) {
          this.recordedChunks.push(event.data);
        }
      };

      this.mediaRecorder.start(200);
      this.isRecordingAudioClip = true;
      CommunicationManager.transition('receiving_audio', 'Recording voice clip');
      return { success: true };
    } catch (err: any) {
      this.isRecordingAudioClip = false;
      const msg = err?.message || 'Unable to start microphone recording.';
      if (msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('denied') || err?.name === 'NotAllowedError') {
        CommunicationManager.setMicrophoneStatus('denied', true);
        CommunicationManager.transition('permission_required', 'Microphone permission denied');
      } else {
        CommunicationManager.failRequestTrace({
          code: 'MIC_RECORD_ERROR',
          message: msg,
          retryable: true
        });
      }
      return { success: false, error: msg };
    }
  }

  static async stopClipAndTranscribe(language: string = 'English'): Promise<{
    success: boolean;
    transcript: string;
    modelUsed?: string;
    latencyMs?: number;
    error?: string;
  }> {
    const startTime = performance.now();
    if (!this.mediaRecorder || !this.isRecordingAudioClip) {
      return { success: false, transcript: '', error: 'No active voice recording in progress.' };
    }

    return new Promise((resolve) => {
      const recorder = this.mediaRecorder!;
      const mimeType = recorder.mimeType || 'audio/webm';

      recorder.onstop = async () => {
        this.isRecordingAudioClip = false;
        this.mediaRecorder = null;

        if (this.recordedChunks.length === 0) {
          CommunicationManager.failRequestTrace({
            code: 'EMPTY_AUDIO_CLIP',
            message: 'Recorded audio clip was empty. Please speak clearly and try again.',
            retryable: true
          });
          resolve({ success: false, transcript: '', error: 'Recorded audio clip was empty.' });
          return;
        }

        const audioBlob = new Blob(this.recordedChunks, { type: mimeType });
        this.recordedChunks = [];
        const result = await this.transcribeAudioBlob(audioBlob, mimeType, language, startTime);
        resolve(result);
      };

      try {
        recorder.stop();
      } catch (err: any) {
        this.isRecordingAudioClip = false;
        this.mediaRecorder = null;
        resolve({ success: false, transcript: '', error: err?.message || 'Failed to finalize audio clip.' });
      }
    });
  }

  static async transcribeAudioBlob(
    audioBlob: Blob,
    mimeType: string = 'audio/webm',
    language: string = 'English',
    startTimestamp?: number
  ): Promise<{
    success: boolean;
    transcript: string;
    modelUsed?: string;
    latencyMs?: number;
    error?: string;
  }> {
    const started = startTimestamp || performance.now();
    CommunicationManager.transition('transcribing', 'Converting speech to text');

    try {
      const base64Audio = await this.blobToBase64(audioBlob);
      const endpoint = typeof window !== 'undefined' ? '/api/audio/transcribe' : 'http://localhost:3000/api/audio/transcribe';
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          audioBase64: base64Audio,
          mimeType: mimeType.split(';')[0] || 'audio/webm',
          language
        })
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errMsg = data?.error || `Audio transcription failed (HTTP ${response.status})`;
        CommunicationManager.failRequestTrace({
          code: data?.code || `TRANSCRIBE_HTTP_${response.status}`,
          message: errMsg,
          retryable: response.status !== 400
        });
        return { success: false, transcript: '', error: errMsg };
      }

      const transcript = typeof data?.transcript === 'string' ? data.transcript.trim() : '';
      const durationMs = Math.round(performance.now() - started);
      CommunicationManager.recordTranscriptionMetric(durationMs);

      if (!transcript) {
        CommunicationManager.failRequestTrace({
          code: 'NO_SPEECH_DETECTED',
          message: 'No clear speech was detected in the recording. Please speak closer to the microphone.',
          retryable: true
        });
        return {
          success: false,
          transcript: '',
          modelUsed: data?.modelUsed,
          latencyMs: durationMs,
          error: 'No clear speech was detected in the recording.'
        };
      }

      CommunicationManager.transition('transcript_ready', 'Transcript ready');
      return {
        success: true,
        transcript,
        modelUsed: data?.modelUsed || 'gemini-3.5-transcribe',
        latencyMs: data?.latencyMs || durationMs
      };
    } catch (err: any) {
      const errMsg = err?.message || 'Network error during audio transcription.';
      CommunicationManager.failRequestTrace({
        code: 'TRANSCRIBE_NETWORK_ERROR',
        message: errMsg,
        retryable: true
      });
      return { success: false, transcript: '', error: errMsg };
    }
  }

  private static blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          const base64 = reader.result.includes(',') ? reader.result.split(',')[1] : reader.result;
          resolve(base64);
        } else {
          reject(new Error('Failed to encode audio blob as base64.'));
        }
      };
      reader.onerror = () => reject(new Error('FileReader error while reading audio blob.'));
      reader.readAsDataURL(blob);
    });
  }

  private static isMicTrackMuted = false;

  /**
   * Genuinely mutes or unmutes microphone hardware audio tracks and pauses/resumes recognition
   */
  static setMicrophoneMuted(muted: boolean): void {
    this.isMicTrackMuted = muted;
    if (this.mediaStream) {
      this.mediaStream.getAudioTracks().forEach(track => {
        track.enabled = !muted;
      });
    }
    if (this.processedStream) {
      this.processedStream.getAudioTracks().forEach(track => {
        track.enabled = !muted;
      });
    }
    if (muted) {
      this.isListeningSpeech = false;
      if (this.recognition) {
        try {
          this.recognition.stop();
        } catch {}
      }
    } else if (this.recognition) {
      this.isListeningSpeech = true;
      try {
        this.recognition.start();
      } catch {}
    }
  }

  static isMicrophoneMuted(): boolean {
    return this.isMicTrackMuted;
  }

  /**
   * Foreground Wake-Word Engine: Listens continuously for "Hey LORIN" trigger phrase
   */
  static startWakeWordDetection(
    onWakeWordDetected: () => void,
    onError?: (err: string) => void
  ): boolean {
    if (!this.isSpeechRecognitionSupported()) {
      onError?.('Speech recognition is not supported in this browser.');
      return false;
    }

    try {
      this.stopWakeWordDetection();
      const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      this.wakeWordRecognition = new SpeechRec();
      this.wakeWordRecognition.continuous = true;
      this.wakeWordRecognition.interimResults = true;
      this.wakeWordRecognition.lang = 'en-US';

      this.wakeWordRecognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript.toLowerCase();
        }

        const WAKE_PATTERNS = [
          'hey lorin',
          'hey lauren',
          'hey loren',
          'lorin',
          'ok lorin',
          'listen lorin'
        ];

        const matched = WAKE_PATTERNS.some(pat => transcript.includes(pat));
        if (matched) {
          onWakeWordDetected();
        }
      };

      this.wakeWordRecognition.onerror = (event: any) => {
        if (event.error !== 'no-speech' && event.error !== 'aborted') {
          console.warn('Wake word detector error:', event.error);
        }
      };

      this.wakeWordRecognition.onend = () => {
        if (this.isListeningWakeWord) {
          try {
            this.wakeWordRecognition?.start();
          } catch {
            // Restarted
          }
        }
      };

      this.isListeningWakeWord = true;
      this.wakeWordRecognition.start();
      return true;
    } catch (e: any) {
      onError?.(e.message || 'Failed to start wake-word detection');
      return false;
    }
  }

  static stopWakeWordDetection(): void {
    this.isListeningWakeWord = false;
    if (this.wakeWordRecognition) {
      try {
        this.wakeWordRecognition.stop();
      } catch {}
      this.wakeWordRecognition = null;
    }
  }

  static setPreferCloudNeuralTts(preferCloud: boolean): void {
    this.preferCloudNeuralTts = preferCloud;
  }

  static getPreferCloudNeuralTts(): boolean {
    return this.preferCloudNeuralTts;
  }

  static setNeuralTtsEnabled(enabled: boolean): void {
    this.preferCloudNeuralTts = enabled;
  }

  static isNeuralTtsEnabled(): boolean {
    return this.preferCloudNeuralTts;
  }

  /**
   * Speaks text via Cloud Neural TTS (/api/audio/tts — gemini-3.8-flash-lite-tts) when enabled,
   * with immediate automatic fallback to Browser SpeechSynthesis.
   */
  static async speakWithNeuralOption(
    text: string,
    onEnd?: () => void,
    options?: {
      useCloudNeuralTts?: boolean;
      voiceName?: string;
      pitch?: number;
      rate?: number;
      preferredVoiceKeywords?: string[];
      overrideVoiceProfile?: { pitch: number; rate: number; preferredVoiceKeywords: string[] };
    }
  ): Promise<void> {
    const startReqTime = performance.now();
    const cleanText = text.replace(/[*#`_>-]/g, '').trim();
    if (!cleanText) {
      onEnd?.();
      return;
    }

    const resolvedOverride =
      options?.overrideVoiceProfile ||
      (typeof options?.pitch === 'number' && typeof options?.rate === 'number'
        ? {
            pitch: options.pitch,
            rate: options.rate,
            preferredVoiceKeywords: options.preferredVoiceKeywords || ['Natural', 'Google', 'Samantha']
          }
        : undefined);

    const useNeural = options?.useCloudNeuralTts ?? this.preferCloudNeuralTts;
    if (useNeural && typeof window !== 'undefined' && typeof Audio !== 'undefined') {
      try {
        this.interrupt();
        const response = await fetch('/api/audio/tts', {
          method: 'POST',
          headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            text: cleanText.slice(0, 1200),
            voiceName: options?.voiceName || 'Kore'
          })
        });

        if (response.ok) {
          const data = await response.json();
          if (data?.audioBase64) {
            const audioUrl = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
            const audioEl = new Audio(audioUrl);
            this.activeAudioElement = audioEl;
            this.isCurrentlySpeaking = true;
            this.isPausedSpeech = false;

            const startupDelay = Math.round(performance.now() - startReqTime);
            CommunicationManager.recordAudioStartupMetric(startupDelay, 'GEMINI_NEURAL_TTS');
            CommunicationManager.transition('speaking', 'LORIN is speaking (Neural Cloud TTS)');

            const finishPlayback = () => {
              if (this.activeAudioElement === audioEl) {
                this.activeAudioElement = null;
              }
              this.isCurrentlySpeaking = false;
              this.isPausedSpeech = false;
              CommunicationManager.transition('completed', 'Speech playback finished');
              onEnd?.();
            };

            audioEl.onended = finishPlayback;
            audioEl.onerror = () => {
              this.activeAudioElement = null;
              this.isCurrentlySpeaking = false;
              this.speak(cleanText, onEnd, resolvedOverride);
            };

            await audioEl.play();
            return;
          }
        }
      } catch (err) {
        console.warn('Cloud Neural TTS unavailable, falling back to Browser SpeechSynthesis:', err);
      }
    }

    this.speak(cleanText, onEnd, resolvedOverride);
  }

  /**
   * Speaks text using the browser's native SpeechSynthesis tuned to the active LORIN Voice Profile
   */
  static speak(
    text: string,
    onEnd?: () => void,
    overrideVoiceProfile?: { pitch: number; rate: number; preferredVoiceKeywords: string[] }
  ): void {
    if (!this.isSpeechSynthesisSupported()) {
      onEnd?.();
      return;
    }

    const startTime = performance.now();
    this.interrupt();
    const cleanText = text.replace(/[*#`_>-]/g, '').trim();
    if (!cleanText) {
      onEnd?.();
      return;
    }

    let pitch = 1.02;
    let rate = 1.03;
    let keywords = ['Samantha', 'Natural', 'Google', 'Aria'];

    if (overrideVoiceProfile) {
      pitch = overrideVoiceProfile.pitch;
      rate = overrideVoiceProfile.rate;
      keywords = overrideVoiceProfile.preferredVoiceKeywords;
    } else {
      try {
        const raw = localStorage.getItem('lorin_profile_config_v2');
        if (raw) {
          const parsed = JSON.parse(raw);
          const vp = parsed.voiceProfile;
          if (vp === 'LORIN_STUDIO') {
            pitch = 0.96; rate = 1.08; keywords = ['Google UK English Female', 'Daniel', 'Alex', 'Natural'];
          } else if (vp === 'LENA_GUARDIAN') {
            pitch = 0.92; rate = 1.0; keywords = ['Victoria', 'Google UK English Female', 'Moira', 'Karen'];
          } else if (vp === 'RILEY_COMPANION') {
            pitch = 1.08; rate = 1.01; keywords = ['Samantha', 'Tessa', 'Google US English', 'Jenny'];
          } else if (vp === 'NOLAN_ARCHITECT') {
            pitch = 0.86; rate = 0.98; keywords = ['Daniel', 'Alex', 'Google UK English Male', 'David'];
          }
        }
      } catch {}
    }

    const utterance = new SpeechSynthesisUtterance(cleanText.slice(0, 750));
    utterance.rate = rate;
    utterance.pitch = pitch;

    const voices = window.speechSynthesis.getVoices();
    const matchedVoice =
      voices.find(v => v.lang.startsWith('en') && keywords.some(k => v.name.includes(k))) ||
      voices.find(v => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha')));
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    this.isCurrentlySpeaking = true;
    this.isPausedSpeech = false;

    const startupDelay = Math.round(performance.now() - startTime);
    CommunicationManager.recordAudioStartupMetric(startupDelay, 'BROWSER_SPEECH_SYNTHESIS');
    CommunicationManager.transition('speaking', 'LORIN is speaking');

    const handleEnd = () => {
      this.isCurrentlySpeaking = false;
      this.isPausedSpeech = false;
      CommunicationManager.transition('completed', 'Response complete');
      if (onEnd) onEnd();
    };

    utterance.onend = handleEnd;
    utterance.onerror = handleEnd;

    window.speechSynthesis.speak(utterance);
  }

  static pauseSpeaking(): void {
    if (this.activeAudioElement && !this.activeAudioElement.paused) {
      this.activeAudioElement.pause();
      this.isPausedSpeech = true;
      return;
    }
    if (this.isSpeechSynthesisSupported() && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      this.isPausedSpeech = true;
    }
  }

  static resumeSpeaking(): void {
    if (this.activeAudioElement && this.activeAudioElement.paused) {
      this.activeAudioElement.play().catch(() => {});
      this.isPausedSpeech = false;
      return;
    }
    if (this.isSpeechSynthesisSupported() && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      this.isPausedSpeech = false;
    }
  }

  static isSpeakingPaused(): boolean {
    return this.isPausedSpeech;
  }

  /**
   * Conversational Interruption: stops speech playback immediately
   */
  static interrupt(): void {
    if (this.activeAudioElement) {
      try {
        this.activeAudioElement.pause();
        this.activeAudioElement.currentTime = 0;
      } catch {}
      this.activeAudioElement = null;
    }
    if (this.isSpeechSynthesisSupported()) {
      window.speechSynthesis.cancel();
    }
    this.isCurrentlySpeaking = false;
    this.isPausedSpeech = false;
  }

  static stopSpeaking(): void {
    this.interrupt();
  }

  static isSpeaking(): boolean {
    if (this.activeAudioElement && !this.activeAudioElement.paused) {
      return true;
    }
    return this.isCurrentlySpeaking && typeof window !== 'undefined' && Boolean(window.speechSynthesis?.speaking);
  }

  /**
   * Releases all audio tracks and filters cleanly so the browser microphone badge turns off
   */
  static stopMicrophone(): void {
    this.stopSpeechRecognition();
    this.stopSpeaking();

    if (this.mediaRecorder && this.isRecordingAudioClip) {
      try {
        this.mediaRecorder.stop();
      } catch {}
      this.mediaRecorder = null;
      this.isRecordingAudioClip = false;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => {
        try {
          track.stop();
        } catch {
          // Track already closed
        }
      });
      this.mediaStream = null;
    }

    if (this.processedStream) {
      this.processedStream.getTracks().forEach(track => {
        try {
          track.stop();
        } catch {}
      });
      this.processedStream = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {}
      this.sourceNode = null;
    }

    if (this.highpassFilter) {
      try {
        this.highpassFilter.disconnect();
      } catch {}
      this.highpassFilter = null;
    }

    if (this.lowpassFilter) {
      try {
        this.lowpassFilter.disconnect();
      } catch {}
      this.lowpassFilter = null;
    }

    if (this.processorNode) {
      try {
        this.processorNode.disconnect();
        this.processorNode.onaudioprocess = null;
      } catch {}
      this.processorNode = null;
    }

    if (this.gateGainNode) {
      try {
        this.gateGainNode.disconnect();
      } catch {}
      this.gateGainNode = null;
    }

    if (this.audioContext) {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }

    this.analyserNode = null;
    this.rawAnalyserNode = null;
    this.processedDestination = null;
    this.voiceActivityDetector?.reset();
    this.voiceActivityDetector = this.voiceActivityListener ? new VoiceActivityDetector() : null;
  }
}
