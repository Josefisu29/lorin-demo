# LORIN V2 security model

## Identity and roles

The API verifies Firebase-issued ID tokens through Firebase Identity Toolkit `accounts:lookup` in `serverAuth.ts`; browser-supplied roles and principal JSON are not authorization sources. The client starts without a privileged principal, waits for Firebase Auth, and resolves role information from `/api/me`. If Firebase becomes unauthenticated, private client state is cleared. `OWNER_EMAIL` is an explicit server-side configuration; an empty value grants no primary email-based owner identity. Owner email allowlisting is not proof by itself: the current Firebase token must also resolve to that email with `emailVerified === true`. Configure `OWNER_UID` as well to bind the primary owner email to the exact Firebase Auth UID; when set, a different UID cannot inherit the primary owner role. Existing managed account records are bound to their stored Firebase UID, and same-email UID mismatch is refused.

Application-minted `lorin_sess_` HMAC bearer tokens are not accepted. `/api/auth/session` is compatibility-only and returns 401 without a valid active Firebase ID token; it never creates or upgrades a session. Anonymous owner bootstrap is disabled. The trusted CLI bootstrap requires both the verified owner's email and the real Firebase Auth UID. The CLI writes the server-managed local registry; **it does not provision the Firestore `user_roles/{uid}` document through an Admin SDK**. That authoritative Firestore role bootstrap must be completed through a separately trusted administrative process before Firestore rules that depend on that record can authorize privileged operations.

Newly observed verified Firebase accounts default to `STANDARD_USER` with no project grants. Explicit project access must be provisioned. The browser does not substitute wildcard project scopes when the API omits them. Identity Toolkit lookup does not implement Admin SDK `checkRevoked` semantics; revocation-aware validation remains a release blocker. The server currently caches successful token lookups for up to 60 seconds.

## Cryptography and secrets

- Provider credentials belong only in server environment variables (`GEMINI_API_KEY`, `OLLAMA_API_KEY`). Never use `VITE_` provider credentials.
- Production/serverless local-node state encryption requires `LORIN_NODE_STORAGE_KEY` with at least 32 bytes of high-entropy secret material. The local development key is generated randomly and stored outside the source tree. Back it up securely; losing it can make encrypted local state unrecoverable.
- A decrypt-only compatibility path is available for previous local ciphertext only in non-production local mode. It must not be enabled in serverless or production.
- A Firebase web API key in the client config is public application configuration, not an Admin SDK private key. Restrict it to required Firebase APIs and domains; enforce Firebase Authentication, App Check where configured, and Firestore/Storage rules.

## Data and execution

- Cross-origin requests receive CORS permission only for exact entries in `CORS_ALLOWED_ORIGINS` (plus localhost development origins outside production); the API does not use wildcard CORS headers.
- Firestore rules default deny and scope user records by authenticated UID. The `memory_records` rule now validates record ownership, ID, domain, content lengths and status.
- Personal memory uses a UID-scoped browser cache and authenticated Firestore records with a local pending-operation queue. Browser `localStorage` is not application-layer encrypted and should not be represented as encrypted-at-rest storage.
- Conversation, project, task, vault and policy snapshot endpoints still use process-local maps and JSON files. On Vercel, these files resolve to `/tmp`. This is not durable, transactional, shared multi-instance persistence. Do not run a multi-instance production deployment until these records are moved to an authoritative shared database.
- Approval and audit APIs exist, but snapshot persistence is not a transactional multi-instance store. Consequential side effects require server-side authorization and approval checks immediately before execution.
- Logs and provider diagnostics must omit tokens, keys and private prompt content.

## Threat boundaries and unresolved controls

Threats include forged browser role state, token expiry/account switching, Firebase token revocation, cross-user object access, approval replay, oversized inference requests, provider failure/fallback confusion, prompt injection in retrieved files, cross-instance state loss, and accidental public/private data mixing. Authenticated inference and role middleware are present, but distributed quotas, durable atomic approvals, Admin SDK revocation checks, Firestore Emulator tests, live provider tests, browser/device QA, and independent MOSAIRA/LORIN trust boundaries remain unverified.

## Recovery and release

This 9 November working build is derived from the latest Library archive available in the session. Runtime registries, secret files, local SQLite/JSON state and private IDE/session notes are excluded from the clean distributable package but have not been destroyed in the original archive. Back up and migrate them deliberately. No production deployment or database migration was performed. Do not mark this package production-ready until the current audit's release blockers are closed.
