# LORIN — Product UI/UX Design and Implementation

**Baseline:** `LORIN_M1_M6_Integrated_Intelligence_Build_2026-11-21.zip`  
**Upgrade:** 22 November 2026  
**Classification:** Implemented UI source upgrade; full application build remains blocked by the existing Node/dependency preflight.

## 1. Product direction

LORIN is one coherent private personal-intelligence product, not a generic admin dashboard, a movie-style HUD, or a collection of competing assistant personas. The conversational workspace remains the primary destination. Specialist capabilities (Lena, Owen, Riley, Iris, Nolan and GIDEON) support LORIN internally; they do not become separate top-level chat identities.

The experience should feel calm, precise, capable, private and approachable. Use a restrained palette, meaningful hierarchy, clear states and purposeful motion. Do not add decorative telemetry, fabricated provider health, fake completion metrics or implied device access.

MOSAIRA remains a separate platform. Its entry point is labelled as a separate platform and must not imply shared LORIN conversations, memory, credentials or device permissions.

## 2. Visual system

The implementation follows the established LORIN tokens:

- App background: `#0B0F14`
- Sidebar / navigation surface: `#0D141C`
- Main surface: `#111821`
- Elevated surface: `#17212C`
- Primary text: `#F1F5F9`
- Secondary text: `#A2AFBF`
- Muted text: `#738297`
- Border: `#283544`
- Teal accent: `#66E3CB`
- Secondary indigo: `#A9B8FF`
- Warm accent: `#E8BE78`

Surface depth comes from restrained gradients, subtle borders and soft shadows. Avoid large neon glows, noisy grids and dense decorative cards. Light theme continues to use the existing `lorin-light` token mapping.

## 3. Primary application shell

### Global header

The existing private LORIN header remains the product-level switcher. It exposes the LORIN presence identity, immersive character stage, PWA installation and separate MOSAIRA platform entry. It is not repurposed as a second navigation system for every workspace.

### Sidebar information architecture

The navigation is grouped by user intent:

**Your Workspace**
- Conversation
- Projects
- Tasks & automation
- Knowledge Vault
- Private Vault

**Intelligence**
- Capabilities
- GIDEON continuity
- Voice
- Vision
- Engineering workbench

**System & Privacy**
- Devices & companion
- Connections
- Memory
- Security & approvals
- Owner control
- Settings

Existing `WorkspaceView` IDs and `PolicyEngine.canAccessModule` checks are preserved. Standard Knowledge Vault (`vault`) and encrypted Private Vault (`laurenVault`) are separate destinations. Recent conversation controls, collapse behavior, mobile drawer focus management and PWA installation remain available.

### Workspace command bar

`LorinWorkspaceToolbar` adds a consistent command bar above every private workspace. It provides:
- Current workspace title and hierarchy label.
- A global active-project context selector.
- A private-workspace cue (not a claim that each integration is online).
- The configured runtime preference, explicitly distinguished from verified provider health.
- Visible microphone and camera indicators only while their application states are active.
- Global search.
- Pending approval count and direct access to Security & approvals.
- Operating mode and settings access.

No synthetic health percentage, token count, latency or provider uptime is shown. Those measurements must come from the relevant service.

## 4. Conversation experience

The first-use state presents one LORIN identity and four practical starting points:
- Research & learn.
- Build software.
- Plan a project.
- Understand a document.

Each action fills the composer for review; it does not submit automatically. The empty state also shows actual active project, configured operating mode and voice profile. It includes a direct route to review runtime/access controls.

The existing conversation renderer, provider attribution, error states, task completion evidence, citations, pinned messages, archives, code blocks, stop action and composer tools are retained. The global project selector lives in the command bar to avoid a duplicate project selector in the conversation toolbar. The conversation toolbar continues to expose the chat-specific model and operating controls.

The composer remains explicit about its supported text-file attachment types and size limit. Other document ingestion should use the Knowledge Vault's supported ingestion pipeline; the chat composer must not pretend it parses every document format.

## 5. Feature surface and UX expectations

| Area | Primary UX responsibility | Trust / state requirements |
|---|---|---|
| Intelligence / model routing | Choose or inspect the requested model and routing mode | Show actual provider attribution; distinguish configured from verified |
| Conversation | Central interaction surface | Preserve drafts on failure; support cancel, retry and citations |
| Memory | Review, edit, approve and delete personal memories | Show provenance, owner scope and sync status accurately |
| Knowledge Vault | Upload, organize, search and cite supported sources | Show parse/index status and exact source references |
| Private Vault | Protected private records | Clear encryption/access cues; never merge with MOSAIRA |
| Projects | Project context, files, decisions and progress | Do not fabricate project progress or task completion |
| GIDEON | Verified timeline and continuity | Distinguish confirmed events from inferred analysis |
| Tasks & automation | Queue, approvals, execution and result verification | Separate proposed, approved, running, completed and verified states |
| Capabilities | Internal specialist capabilities | Show one LORIN identity; do not simulate specialist activity |
| Voice | Explicitly activated microphone, STT/TTS and interruption | Visible recording state, permission handling and cleanup |
| Vision | Snapshot or explicitly enabled visual session | Clearly distinguish snapshot from live video |
| Devices & companion | Pair, inspect and revoke devices | Per-device scope, session state and revocation evidence |
| Connections | Manage external service access | Connected/configured/verified are separate states |
| Security & approvals | Review policy, audit events and pending actions | Exact target/parameters, actor, expiry and outcome |
| Engineering workbench | Inspect and test approved code/workspaces | Sandboxed commands only; no unrestricted shell |
| Owner control | Privileged configuration | Require server-verified role and action-specific permission |
| Settings | Runtime, presentation, voice, privacy and accessibility | User-controlled preferences; never imply hidden device activation |

## 6. Character and presence

The holographic character remains adaptive but subordinate to the conversation and task. Its state must follow real application signals (idle, listening, processing, speaking, researching, coding, analyzing, error or disconnected). It must not animate a false listening or thinking state.

The existing compact, standard, expanded, full, workspace and mobile presentations remain the basis for Companion, Compact, Immersive, Workspace and Ambient experiences. Immersive presentation stays user-invoked. More realistic Babylon.js/WebGPU rendering, speech-synchronized lip motion and native desktop overlay behavior remain subsequent integration work, not claims of this CSS/UI pass.

## 7. Responsive and accessible behavior

- Desktop: persistent collapsible sidebar, workspace command bar and full work surface.
- Tablet: narrower command bar, abbreviated metadata and preserved navigation access.
- Mobile: accessible slide-over navigation, compact command controls, one-column quick actions and safe-area-aware composer.
- Keyboard focus is visible; a skip-to-main-workspace link is provided.
- Navigation retains semantic labels and `aria-current` on the active route.
- Reduced-motion preferences disable nonessential movement.
- Controls must preserve accessible names, disabled states and permission feedback.

## 8. UI implementation changes in this release

- Added `src/components/LorinWorkspaceToolbar.tsx`.
- Integrated the workspace toolbar into the authenticated LORIN application shell.
- Added a skip link and main-workspace landmark.
- Updated sidebar wording and hierarchy while retaining route IDs and policy checks.
- Added separate Knowledge Vault and Private Vault navigation entries.
- Rebuilt the chat empty state with contextual project/mode/voice chips and four review-before-send quick starts.
- Removed the duplicate project selector from the chat-only toolbar; global project context is now in the shared workspace command bar.
- Added responsive command bar, sidebar, welcome-state, composer and accessibility styling.
- Updated MOSAIRA entry tooltip to clarify product separation.
- Removed fabricated initial online state and placeholder subsystem counts from the device centre until a real status response arrives.
- Removed random speech-amplitude telemetry from the immersive character.
- Removed fabricated default model context size and changed unknown latency to an explicit unmeasured state.

## 9. Verification and limitations

Executed in the available environment:
- `npm run test:core`: 34/34 PASS (includes 10 UI source-contract checks).
- `npm run test:security:static`: 38/38 PASS.
- TypeScript `transpileModule` syntax parse: 120 TS/TSX source files, zero syntax diagnostics.
- Relative source import check: zero missing relative imports.
- CSS brace-balance check: balanced.

Not certified by this UI change:
- Full semantic TypeScript typecheck.
- Vitest suite and browser component tests.
- Vite + Express production build.
- Cross-browser visual regression and real responsive-device QA.
- Live provider, Firebase, microphone, camera and Windows desktop acceptance.

The project remains subject to the pre-existing environment blockers: Node 22.16.0 is available while the project declares Node >=24.12.0; dependencies are not installed; and `package.json`/`package-lock.json` still need reconciliation. The new toolbar and styling are source-implemented, but a clean production build is not claimed.

## 10. Next UI/UX acceptance work

1. Resolve M0 build recovery, then run full semantic and browser builds.
2. Add Playwright coverage for desktop/tablet/mobile shell, keyboard navigation, sidebar drawer, dialogs, focus return and reduced motion.
3. Add real provider-health and model-selection states from M1 services, without synthetic metrics.
4. Finish unified memory/Vault/project sync states and source navigation under M2.
5. Complete voice/vision live state, interruption, permission and cleanup UX under M4.
6. Complete device pairing/revocation and disconnected/reconnected states under M5.
7. Complete Windows companion installation, permissions, DPAPI-backed local storage and update lifecycle UX under M6.
8. Run visual regression and accessibility audits against supported browsers and Windows 10/11 plus target mobile devices.

This release is a shared-shell and conversation-entry UI upgrade. Existing feature workspaces are preserved, but component-by-component visual redesign and browser-based acceptance for every workspace remain future work; they are not represented as completed here.
