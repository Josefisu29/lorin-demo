# LORIN V2 feature and verification matrix

**Current evidence snapshot:** 9 November 2026. This matrix describes the latest available source archive after the focused security/privacy changes in the working copy. A feature is not `VERIFIED` merely because source code or a UI exists. Historical build/test results are labeled by date and do not prove the current working copy builds.

| Capability | Current status | Evidence available in this session | Remaining gap |
|---|---|---|---|
| React/Vite client and PWA shell | PARTIAL | `package.json`, `vite.config.ts`, `src/App.tsx`, PWA configuration | Current production build and all routes not run; responsive/accessibility browser review outstanding |
| Initial identity and sign-out reset | PATCHED / STATIC VERIFIED | `src/App.tsx`, Firebase auth listener, least-privilege provisional principal | Real Firebase account lifecycle/token-expiry/revocation browser tests outstanding |
| Firebase ID-token verification | PARTIAL | `serverAuth.ts` uses Firebase Identity Toolkit lookup; protected routes use `requireAuth` | No Admin SDK revocation checks; current-session HTTP negative tests and emulator tests not run |
| App-minted HMAC sessions | PATCHED / STATIC VERIFIED | No `lorin_sess_` creation/acceptance; compatibility endpoint fails closed without Firebase ID token | Runtime HTTP tests not run |
| Owner configuration and bootstrap | PARTIAL | No hard-coded application owner email; CLI requires `OWNER_EMAIL` and real `OWNER_UID`; email verification is checked | Real owner provisioning, persistence, role document bootstrap and privileged-route tests outstanding |
| Local-node encryption | PATCHED / STATIC VERIFIED | Random local 32-byte key stored outside source tree; production requires `LORIN_NODE_STORAGE_KEY`; old key path is decrypt-only/local migration | Node 24+ runtime, rotation, recovery and production secret-manager tests outstanding |
| Server port configuration | PATCHED / STATIC VERIFIED | Validated `PORT` from 1–65535 | Real server listen test not run |
| Firestore baseline rules | PARTIAL | Default-deny and UID-scoped paths in `firestore.rules` | Firebase Emulator Suite not available; full rule coverage and privileged role bootstrap need tests |
| Personal memory storage | PATCHED / STATIC VERIFIED | UID-scoped local namespace, legacy global key quarantine, no seeded confirmed memories, schema checks and pending sync queue | Browser tests, queue concurrency/conflict/tombstone behavior and local-at-rest encryption remain outstanding |
| Personal memory cloud persistence | IMPLEMENTED IN SOURCE / NOT INTEGRATION VERIFIED | Authenticated user-scoped Firestore `memory_records` query/upsert/delete; record schema limits in rules | No live Firestore or rules-emulator test; remote synchronization cannot be claimed verified |
| Knowledge Vault | PARTIAL | Vault views/services and Firestore helpers exist | Document parsing, ACLs, indexing/retrieval quality, local/cloud lifecycle and deletion need end-to-end tests |
| Conversations/projects/tasks | PARTIAL | Client stores and Firestore persistence helpers exist; Express APIs are authenticated | Backend snapshot uses process-local maps/JSON and `/tmp` in Vercel; not a durable shared multi-instance database |
| Approval and audit | PARTIAL | Server-side policy endpoints and approval checks exist | Persistent transactional storage, concurrency/replay tests and distributed audit guarantees outstanding |
| GIDEON timeline and systems intelligence | PARTIAL | Authenticated timeline/event endpoints and local runtime code exist | Durable shared persistence, event correlation and forecast evaluation not verified |
| Gemini/Ollama Cloud/local inference | PARTIAL | Provider adapters and authenticated server endpoints exist | No configured provider credentials or live inference/streaming/model-attribution tests performed |
| Voice and vision | PARTIAL | `VoiceChatView.tsx`, `VideoVisionView.tsx`, audio/video services exist | Microphone lifecycle, speech recognition/synthesis, camera privacy, real provider modality and device QA outstanding |
| Specialist architecture | PARTIAL / SPECIFICATION CONFLICT | Six core capabilities (Lena, Owen, Riley, Iris, Nolan, GIDEON) and ten extended profiles exist in source | Verify orchestration; resolve whether extended profiles are private LORIN or a separate catalogue before release |
| Personal assistant tools/device control | PARTIAL | Approved command registry and authenticated device routes exist | Real device pairing, server approval, scope enforcement, audit, revocation and failure testing outstanding |
| MOSAIRA/public-private separation | NOT VERIFIED | MOSAIRA routes/views coexist in the same application/repository | Separate identities, trust boundaries, sessions, secrets, data stores and deployment need explicit proof before public access |
| Production install/build/typecheck | BLOCKED | Package declares Node >=24.12; current runtime here is Node 22.16; npm registry access returned `EAI_AGAIN` | Clean install, lint/typecheck, Vitest, Vite build and esbuild bundle on supported Node required |
| Static security regression | PASS — 26/26 | `node scripts/security-regression-check.mjs` | Static assertions are not penetration tests or integration tests; includes owner-bootstrap ordering/UID binding, protected system diagnostics and health-response redaction |
| TypeScript syntax transpilation | PASS — 108/108 | Global TypeScript 5.8.3 transpile-only check of `.ts`/`.tsx` source | Does not type-check imports/types or replace `tsc --noEmit` |
| Firebase emulator/provider/browser QA | NOT RUN | No emulator, provider credentials or live browser/device session available | Run authenticated end-to-end tests with supplied project configuration and secrets |
| Deployment | NOT RUN | No deployment action performed | Preview deployment, smoke tests, observability, recovery and production sign-off outstanding |

## Historical test notes

The earlier implementation log records a local build success on 5–6 November for an earlier source revision and 36/37 Vitest tests passing in a partially installed environment. Those historical results must not be attributed to the 8 November archive or this 9 November working copy. The current archive did not receive a full install, `tsc`, Vitest run or production build in this session.

## Release rule

Do not call LORIN production-ready until the critical/high security review is clear, all tests available in the supported environment pass, cloud persistence is durable and scoped, provider and browser/device journeys work, MOSAIRA/LORIN boundaries are verified, and a clean ZIP is produced with secrets and private runtime state excluded.


## Continuation security and privacy checks — 9 November 2026

- Owner bootstrap side effects occur only after successful one-time bootstrap; bootstrap now requires a real Firebase UID and binds idempotency to that UID.
- Global primary-node and private-network diagnostics require System Owner or Super Admin access.
- System health responses redact host, account and private-network details for standard users.
- Public MOSAIRA unauthenticated inference receives best-effort in-process per-IP/global limits and stricter request validation; multi-instance global quotas remain a deployment requirement.
- Cloud-context sharing of private memory/Vault content defaults to opt-in.
- Credential configuration is reported separately from a successful upstream inference probe.
- Static security regression is now 26/26; TypeScript syntax transpilation remains 108/108. Full test/build and live integration status remains blocked as detailed in the current build audit.


### UID-bound identity hardening — 9 November 2026

- Primary `OWNER_EMAIL` can be bound to `OWNER_UID`; Firebase identity resolution verifies the UID when configured.
- An email-only managed account match cannot transfer privileges to a different Firebase UID.
- Owner email allowlisting no longer creates synthetic UID records; real Firebase sign-in establishes the managed account.
- Legacy synthetic UID entries require explicit migration/recovery. Static regression suite: 26/26.


## Continuation and reference analysis — 21 November 2026

**Target evidence:** working copy based on `LORIN_CONTINUED_REMEDIATION_WORKING_BUILD_2026-11-09.zip`, modified 21 November after review of three reference repositories.

| Capability | Current status | New evidence from 21 November | Remaining gap |
|---|---|---|---|
| Default user projects/tasks/goals | PATCHED / STATIC VERIFIED | Removed synthetic seeded records; empty-state UI; manual daily goals are separate from executable tasks | Browser migration and account-switch tests; verify old persisted sample records are filtered without deleting legitimate user records |
| Task executor registry | FOUNDATION ONLY / FAIL-CLOSED | Executor registration contract exists; no trusted production executor is installed | Implement a server-owned durable worker, event stream, idempotency, timeout/cancel and evidence receipt |
| Historical task success claims | PATCHED / STATIC VERIFIED | Legacy/client completion claims without trusted evidence are downgraded to `BLOCKED` | Migration review on real user records and postcondition verifier for each real executor |
| Client action approvals | PATCHED / STATIC VERIFIED | Policy fails closed if authoritative server is unavailable; local-only fallback is explicit test/development behaviour | HTTP/browser tests, approval UX and distributed persistence |
| Primary-node high-impact commands | PATCHED / STATIC VERIFIED | Exact command/device action is bound to server approval; browser `ownerApproved` boolean no longer grants execution | Durable transactional approval store, replay/concurrency/expiry tests and real device acceptance |
| Task API trust boundary | PATCHED / STATIC VERIFIED | Server sanitizer rejects client-forged SUCCEEDED/COMPLETED claims without a trusted receipt | API integration tests and a verified worker receipt schema |
| External repository analysis | COMPLETE / DECISIONS DOCUMENTED | `docs/LORIN_REFERENCE_REPOSITORY_DECISIONS_2026-11-21.md` reviews all 3 uploaded archives, license evidence, safe concepts and rejected patterns | Implement VAD, bridge event lifecycle and registry improvements in later tested milestones; do not copy ULTRON source without licensing proof |
| Static security regression | PASS — 29/29 | `node scripts/security-regression-check.mjs` | Static assertions are not penetration tests or integration tests |
| TypeScript syntax transpilation | PASS — 108/108 | Global TypeScript transpile-only pass, 0 syntax diagnostics | Does not validate imports, dependency APIs or semantic types |
| Semantic typecheck | BLOCKED | Required Vite/PWA type definitions and compatible dependencies are not installed | Node >=24.12, lockfile reconciliation, clean install, then `tsc --noEmit` |
| npm lockfile consistency | FAIL | Manifest has 17 prod deps/9 dev deps/3 optional; lock root has 11/10/0 and mismatched placement | Resolve exact dependency graph and regenerate lockfile on supported runtime; do not use current `npm ci` |
| Vitest / production build | NOT RUN | No compatible full `node_modules` installation | Clean install and run all scripts on supported Node |
| Approval/task durable state | PARTIAL / NOT PRODUCTION READY | New server authorization improves trust, but several server stores remain Maps/JSON snapshots | Transactional persistent store with per-user access, migrations, concurrency and backups |
| Real Gemini/Ollama, Firebase, offline, voice, vision and device E2E | NOT RUN | Source code reviewed only | Real credentials/services and target Windows/browser/device test environment required |

The detailed reference comparison, file-level findings, license register, security decisions and engineering sequence are recorded in `docs/LORIN_REFERENCE_REPOSITORY_DECISIONS_2026-11-21.md`.

**Historical note:** the 26/26 result remains the historical 9 November result. The current 21 November static regression suite is 29/29. The 108-file syntax result is syntax-only. Do not interpret any static result as a live service connection or release certification.
