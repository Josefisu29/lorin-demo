# LORIN M1–M6 File Change Manifest

Compared with the exact 21 November integrated working build used as the M1–M6 base: **21 modified files, 10 added files, zero removed files**.

## Modified files

- `BUILD_STATUS_2026-11-21_ENHANCED.md`
- `README.md`
- `lorin-node/scripts/install.ps1`
- `lorin-node/scripts/start.ps1`
- `scripts/preflight.mjs`
- `scripts/security-regression-check.mjs`
- `scripts/tests/core-security.test.ts`
- `server.ts`
- `serverCore.ts`
- `src/App.tsx`
- `src/components/TasksWorkspace.tsx`
- `src/components/VoiceChatView.tsx`
- `src/core/capabilities/registry.ts`
- `src/core/jobs/jobService.ts`
- `src/core/persistence/sqliteStore.ts`
- `src/core/routing/modelRouter.ts`
- `src/services/audioService.ts`
- `src/services/gideonService.ts`
- `src/services/modelBackend.ts`
- `src/services/ollamaService.ts`
- `src/types/lorin.ts`

## Added files

- `docs/LORIN_M1_M6_COMPLETION_BACKLOG_2026-11-21.md`
- `docs/LORIN_M1_M6_IMPLEMENTATION_REPORT_2026-11-21.md`
- `docs/LORIN_M1_M6_FILE_CHANGE_MANIFEST.md`
- `docs/LORIN_M1_M6_VERIFICATION_2026-11-21.md`
- `lorin-node/scripts/doctor.ps1`
- `scripts/tests/ollama-stream.test.ts`
- `src/components/DurableCoreJobsPanel.tsx`
- `src/core/jobs/workerLoop.ts`
- `src/core/providers/ollamaNdjson.ts`
- `src/services/unifiedKnowledgeService.ts`
