# LORIN Enhanced — Architecture and Operator Guide

**Release candidate date:** 21 November 2026  
**Baseline:** `LORIN_Continued_Reference_Integrated_Working_Build_2026-11-21`  
**Classification:** source working build; not a production release or installer.

## Product rule

LORIN remains one private, owner-controlled assistant: **LORIN — Personal Intelligence. Everywhere.** Its internal specialist capabilities are Lena (Guardian), Owen (Coordinator), Riley (Companion), Iris (Investigator), Nolan (Strategist) and GIDEON (Systems Intelligence). They do not become competing public chat identities. MOSAIRA remains a separately governed product and does not inherit LORIN's private conversations, memory, credentials, files, devices or owner controls.

## What this release changes

This release keeps the existing React 19 / TypeScript / Vite client, Express server, Firebase identity, Gemini/Ollama adapters, PWA, Babylon.js character view, Memory, Knowledge Vault, projects, GIDEON, voice/vision and local-node surfaces. It adds a small server-core layer instead of replacing those systems or importing another application wholesale.

New modules:

| Module | Responsibility |
|---|---|
| `src/core/security/canonical.ts` | Deterministic JSON, SHA-256 action digests and constant-time digest comparison helper |
| `src/core/capabilities/registry.ts` | Server-owned, sealed capability allowlist; closed input schemas; bounded JSON input; cooperative timeout/cancellation |
| `src/core/security/policy.ts` | Deny-by-default identity, account, permission, resource-scope, local-only and risk checks |
| `src/core/persistence/sqliteStore.ts` | Local SQLite job/approval store; AES-256-GCM payload encryption with record-specific associated data; transactional state transitions; hash-chained audit events |
| `src/core/jobs/jobService.ts` | Job creation, approval binding, trusted worker dispatch and execution receipts |
| `src/core/routing/modelRouter.ts` | Explainable provider selection based on privacy, timestamped health, capability, context, latency and estimated cost |
| `src/core/voice/voiceActivityDetector.ts` | Frame-level VAD with adaptive noise floor, onset hysteresis, pre-roll and hangover; integrated into AudioService DSP events |
| `serverCore.ts` | Local-core lifecycle and lazy service access |
| `scripts/tests/core-security.test.ts` | Focused security and behavior tests |

## Capability and approval flow

1. A Firebase-authenticated request reaches an Express route protected by the existing `requireAuth` middleware.
2. The server resolves the verified principal. A browser role string, model message or client-side `ownerApproved` flag is not accepted as authorization.
3. The capability ID must already exist in the server-owned registry. The browser or model cannot register an executor.
4. The input is checked against a closed schema and a 64 KiB / depth / node-count envelope.
5. The server policy checks account state, permissions, local-only requirements, resource ownership and risk.
6. The action digest binds the verified principal, capability ID, exact resource and canonical parameters.
7. Moderate/high-risk jobs are stored as `AWAITING_APPROVAL`. Owner/Super Admin review validates the digest and approval binding. The approval is consumed transactionally once, immediately before the worker claims the action.
8. Before invoking the capability, the worker recomputes the digest from the decrypted job payload. A mismatch blocks execution.
9. A successful executor produces a `COMPLETED` receipt. This core never changes a job to `VERIFIED`; an independent trusted postcondition verifier has not been implemented.

Critical-risk actions are denied in this release. There is no general shell, arbitrary command, dynamic model-generated import, flashing, or broad device-control capability in the new registry.

## Built-in capabilities

Only two read-only examples are registered at startup:

- `lorin.system.health.read` — captures process/runtime measurements from the local Node process.
- `lorin.time.read` — captures host clock/time-zone information.

Neither one controls the operating system, sends network requests or modifies user files. A capability with no installed executor is blocked; the registry does not invent an executor.

## API surface added

All routes use the existing Firebase-authenticated Express stack.

| Route | Purpose |
|---|---|
| `GET /api/core/health` | Minimal authenticated local-core status; does not expose the host database path |
| `GET /api/core/capabilities` | Server-owned capability metadata filtered by the verified user's permissions |
| `GET /api/core/jobs` | Lists only the caller's jobs |
| `POST /api/core/jobs` | Creates a schema-validated, policy-checked job |
| `GET /api/core/jobs/:jobId` | Reads only a job owned by the caller |
| `POST /api/core/jobs/:jobId/approve` | Owner/Super Admin approval of a matching, pending action digest |
| `POST /api/core/jobs/:jobId/cancel` | Cancels an eligible job owned by the caller |
| `POST /api/core/worker/run-once` | Owner/Super Admin asks the trusted local worker to process one queued job |

Example request body:

```json
{
  "capabilityId": "lorin.system.health.read",
  "resource": "local-node",
  "parameters": {}
}
```

The `resource` is part of the digest; it should be a stable, server-understood resource identifier when new capabilities are added. New effectful capabilities must implement their own resource validation and scoped executor before being enabled.

## Local persistence and key handling

- Default database: `~/.lorin/data/lorin.sqlite`.
- Default key file: `~/.lorin/keys/storage.key`.
- Optional paths: `LORIN_DATA_DIR`, `LORIN_DATABASE_PATH`.
- Optional externally provisioned 32-byte key: `LORIN_STORAGE_KEY_HEX` (64 hex characters). Prefer an OS secret store or managed secret system for a production installation; do not commit this value.
- POSIX data directories are set to mode `0700`; database and key files to `0600`. Symlinks/special files are rejected for the configured data file and local key file.
- Job parameters, approval requests, receipts and audit metadata payloads are encrypted with AES-256-GCM. Associated data binds ciphertext to its record identity and metadata, preventing a valid encrypted payload from being moved to another job/approval and silently accepted.
- Some query/diagnostic metadata remains plaintext in SQLite (such as record IDs, owner UID, capability, resource, state and timestamps). This is **not full-database encryption**. Protect the host volume with OS full-disk encryption and strict OS account permissions.
- Windows ACL/DPAPI integration is not implemented here. Windows installers must configure and verify restrictive ACLs and an appropriate secret-storage mechanism before production use.
- The audit log is application-append-only and hash-chained to make ordinary row tampering detectable. It is not immutable against a privileged attacker who can replace the database and recompute the chain; export/anchor it to a separate trusted system for stronger evidence.
- SQLite uses Node's built-in `node:sqlite`. It may emit an experimental warning on some Node releases; test the exact declared Node runtime before production.

The new SQLite store is currently used by the **core job/approval engine only**. It does not claim to have migrated all existing conversation, Memory, Vault, project, GIDEON or MOSAIRA data into one database. Those stores still require a separate data-model and migration project.

## Local network exposure

The server now binds to loopback (`127.0.0.1`) by default. Non-loopback binding requires both:

```dotenv
LORIN_SERVER_HOST=192.168.1.20
LORIN_ALLOW_NETWORK_BIND=true
LORIN_NETWORK_TLS_TERMINATED=true
```

`LORIN_NETWORK_TLS_TERMINATED=true` is an operator acknowledgement, not TLS implementation. A trusted reverse proxy/load balancer must actually terminate HTTPS, enforce host/origin restrictions, and apply firewall and authentication rules. Do not expose the plain Express listener directly to the public internet.

## Provider routing and voice status

- `modelRouter.ts` is an explainable **decision helper**, not a replacement provider executor. It rejects providers without a timestamped successful health result and never silently routes a `LOCAL_ONLY` request to cloud. The existing Gemini/Ollama adapters remain in place; this new helper is not yet wired into every inference request.
- `voiceActivityDetector.ts` is a tested standalone VAD algorithm module. It is **not yet connected** to `AudioService`, microphone capture, transcription or TTS. The existing audio implementation must remain the source of actual microphone behavior until a separate integration and browser-device acceptance pass is completed.
- No wake word or background microphone listening is enabled by this work.

## Development commands

Use the runtime declared by this project: **Node.js >=24.12.0** and the project package manager version (`npm@10.9.2`).

```powershell
Copy-Item .env.example .env
npm install
npm run dev
```

Run focused checks:

```powershell
npm run test:core
npm run test:security:static
npm run core:health
```

The supplied execution environment for this build had Node `22.16.0`, not the declared Node `24.12.0`. The package manifest and lockfile are also inconsistent. A lockfile-only refresh was attempted but timed out without changing the lockfile. Do **not** run `npm ci` on the supplied lockfile; reconcile dependencies with the supported Node version, then complete semantic typecheck, Vitest, frontend/server build and live integration tests.

## Current boundaries

- The worker endpoint processes one item on request; there is no automatic long-running worker loop, retry scheduler, event stream, or UI job manager wired to these endpoints.
- The only live examples are local read-only capabilities. No new file, shell, email, smart-home, Android, browser or device automation has been enabled.
- Provider routing is not yet integrated into the full chat/inference path.
- VAD boundary events are integrated into the live microphone DSP callback; transcript turn assembly, echo handling, barge-in and device QA remain unfinished.
- Cloud/serverless durable persistence adapter is not implemented. The local SQLite store explicitly refuses serverless runtimes rather than pretending `/tmp` is durable.
- Existing Firebase, Gemini, Ollama, browser, voice, camera, offline and Windows runtime still need full acceptance verification.


## Continuation hardening

Queued jobs are now re-authorized at execution time. The local worker resolves the current server-managed account by exact Firebase UID, checks active account status, recorded session revocation, current capability permissions and the required single-use consumed approval, then checks the action digest again. Missing account resolution fails closed. The server-side worker uses `resolveCurrentManagedJobPrincipal`; test-only callers must supply an explicit principal resolver.

`npm run preflight` checks the declared Node/npm runtime, dependency root alignment, direct package lock entries, installed modules and `node:sqlite` availability. It is expected to report blockers in the supplied environment until the package lock is reconciled on a supported network-enabled runtime.

## Firebase deployment boundary

The inherited Firebase project identity was not confirmed as the intended LORIN backend. This source build therefore ships with `SET_YOUR_*` placeholders and the `(default)` Firestore database target. The owner must supply the intended project configuration before live auth, Firestore or Storage use. See `docs/FIREBASE_PROJECT_CONFIGURATION_REQUIRED.md`.
