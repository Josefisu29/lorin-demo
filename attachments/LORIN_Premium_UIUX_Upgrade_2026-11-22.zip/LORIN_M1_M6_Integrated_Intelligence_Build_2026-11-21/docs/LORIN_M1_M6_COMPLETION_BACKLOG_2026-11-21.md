# LORIN M1–M6 Completion Backlog

This backlog lists what must still happen before each milestone meets its full acceptance statement.

## M1 — Real AI intelligence integration

- [ ] Reconcile dependencies and complete semantic typecheck/build first.
- [ ] Configure a real server-only Gemini key and verify live health, streaming, cancellation, attribution and quota/error behavior.
- [ ] Configure Ollama Cloud secrets on server and verify actual cloud requests.
- [ ] Test local Ollama against a real loopback daemon, including model missing, daemon down, timeout, abort and output truncation.
- [ ] Run full automatic/manual routing integration tests with supported capabilities and real provider health.
- [ ] Verify local-first fallback only after explicit mode choice; verify sensitive prompts, `LOCAL_ONLY`, image attachments, partial streamed output and cloud-context consent all block unintended disclosure.
- [ ] Validate token, latency and cost reporting against provider-reported usage; never synthesize missing measurements.

## M2 — Unified memory and knowledge

- [ ] Define canonical versioned records and migrations across conversations, Memory, Vault, projects and GIDEON.
- [ ] Complete extraction/chunking/metadata for supported file types and versioned source lifecycle.
- [ ] Add local embedding generation and vector retrieval where the selected model is actually available; keep keyword retrieval available offline.
- [ ] Make citations resolve to exact source document/version/page/section and mark unverified content clearly.
- [ ] Implement authenticated owner-scoped cloud sync, tombstones/deletion propagation and conflict resolution after Firebase project is supplied.
- [ ] Implement encrypted backup export/import, integrity checks, restore-point rotation and an actual restore rehearsal.
- [ ] Test account switching, sign-out, export/delete, restart and multiple-device conflict scenarios.

## M3 — Complete automation

- [ ] Add a durable scheduler/worker supervisor with graceful restart/shutdown and multi-process database contention tests.
- [ ] Add idempotency keys and receipts for every executor.
- [ ] Build an isolated coding executor: disposable worktree/container/VM, no default network, CPU/memory/time limits, allowlisted commands, protected host boundaries and captured logs.
- [ ] Add repository inspect/test/build executors only within that sandbox.
- [ ] Expand independent postcondition verifiers; never upgrade a job to VERIFIED from its own executor claim.
- [ ] Add queue observability, dead-letter handling and operator controls without leaking global tenant data.
- [ ] Add UI acceptance for approvals, retries, cancellation, worker disconnect and blocked jobs.

## M4 — Complete voice and vision

- [ ] Integrate streaming STT and VAD boundaries with actual segment creation and transcript timestamps.
- [ ] Test barge-in, TTS echo suppression, microphone denial, device changes and cleanup on Chrome/Edge/Firefox as supported.
- [ ] Add native optional wake-word service only with explicit OS permission and visible indicator; browser click-to-arm is not equivalent.
- [ ] Add local/offline STT/TTS models and test without network.
- [ ] Define separate snapshot vs live-video capabilities; implement live video only with explicit camera start/stop and observable frames.
- [ ] Test camera/microphone privacy cleanup, resource limits and supported device matrix.

## M5 — Devices and offline intelligence

- [ ] Complete secure local companion bridge pairing, challenge expiry, revocation, key rotation and TLS/origin validation.
- [ ] Test real Android/Windows/browser pairings and cross-device ownership/tenant boundaries.
- [ ] Add capability-based device access and per-device approval/revocation, not generic unrestricted control.
- [ ] Test Ollama model discovery, local inference, offline document retrieval and app behavior after network loss/reconnect.
- [ ] Keep cloud content excluded in `LOCAL_ONLY` mode and validate network traces.

## M6 — Windows desktop companion

- [ ] Reconcile lockfile and pass clean Node/npm install first.
- [ ] Implement DPAPI-backed protection for the local SQLite encryption key and safe migration from any development key file.
- [ ] Apply and verify restrictive Windows ACLs to `%USERPROFILE%\.lorin` and data directories.
- [ ] Build signed installer/uninstaller; include upgrade, rollback, clean uninstall and user-data retention controls.
- [ ] Implement native secure IPC with explicit pairing, local authentication and allowed-origin checks.
- [ ] Test Windows 10+ and Windows 11 on clean user accounts, including Defender/SmartScreen, restart, sleep/resume and offline use.

## Final production gate

No milestone is production-complete until the semantic typecheck, full unit/integration tests, frontend/server build, authorization tests, provider tests and its real supported-device acceptance matrix pass. Record version, environment, command, result and evidence for every gate.
