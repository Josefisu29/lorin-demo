# LORIN working build — security remediation tranche

**Package type:** Security-remediated working source package; not a production release.

## Source baseline

Derived from the latest available user Library archive `LORIN-main(2).zip` (8 November 2026). Existing functional code was retained; focused changes address session identity, owner configuration, local-node key handling, runtime configuration, memory privacy and source packaging.

## What changed

- Removed app-minted HMAC session bearer tokens; private API requests use Firebase ID tokens.
- Disabled anonymous owner-session bootstrap and removed hard-coded owner email defaults.
- Required actual Firebase UID in the trusted owner bootstrap CLI.
- Made local-node encryption keys random per-install and required an explicit high-entropy secret in production/serverless environments.
- Validated the `PORT` setting.
- Scoped personal memory by Firebase UID, quarantined the legacy unscoped memory key, removed fabricated confirmed memory seeds, validated memory records and added user-scoped Firestore synchronization with an offline pending queue.
- Added Firestore memory record schema/ownership rules.
- Updated documentation, static security checks and package metadata.

## Checks that passed

- `npm run test:security:static` — 26/26 static security assertions.
- TypeScript 5.8.3 syntax transpilation — 108/108 `.ts` and `.tsx` files.
- JSON parse checks for package, lockfile and deployment configuration.
- Original archive integrity; output ZIP integrity and private-file exclusion are checked during packaging.

## Not verified / release blockers

- The project declares Node.js >=24.12.0. The available environment had Node.js 22.16.0.
- Dependency installation was blocked by npm registry DNS failure (`EAI_AGAIN`).
- Full TypeScript typecheck, Vitest suite, Vite production build and generated Express server bundle were not run.
- No Firebase Auth/Firestore emulator tests, Admin SDK revocation tests, live Gemini/Ollama inference, browser/device/accessibility QA, or Vercel deployment tests were run.
- Conversation, project, task, vault and approval snapshot APIs still rely on process-local maps and JSON files or `/tmp` in serverless deployments. This is not durable multi-instance persistence.
- Browser memory cache is user-scoped but not application-layer encrypted. Memory Firestore changes are source-level only and require live emulator/online tests.
- Public MOSAIRA and private LORIN separation, full multimodal workflows, specialist orchestration and device automation are not end-to-end verified.

## Files intentionally excluded

The working ZIP omits `.lorin_session_secret`, actual `.env` files, owner/RBAC registries, policy/conversation/workspace snapshots, GIDEON runtime data, local SQLite/JSON databases, generated `server.js`, `.aistudio` workspace notes, `.git`, dependency folders, build output and caches. The original Library archive was not modified or deleted; back up and migrate user runtime state deliberately before replacing any existing deployment.

`firebase-applet-config.json` remains because the frontend requires public Firebase client configuration. It is not an Admin SDK private key. Restrict its API key to the necessary Firebase APIs/domains and enforce Auth, App Check where configured, Firestore and Storage rules.

## Release decision

**Do not deploy this package as production or describe it as fully implemented.** Treat it as the latest security-remediated source handoff. Complete the release blockers in `LORIN_CURRENT_BUILD_AUDIT_2026-11-09.md` on Node.js >=24.12 with dependencies and live integrations available, then generate a separately verified final release ZIP.


## Continuation tranche — 9 November 2026

Additional remediation in this working copy:

- Corrected the owner-bootstrap route so a refused bootstrap cannot trigger owner-registry promotion.
- Owner bootstrap now requires a real Firebase UID and rejects an email record bound to a different UID.
- Restricted global primary-node and private-network diagnostics to System Owner/Super Admin.
- Redacted global account/owner counts and host/internal-network/provider details from the standard-user health-matrix response.
- Added best-effort per-IP and global per-process rate limits plus request validation for anonymous MOSAIRA inference.
- Made cloud transmission of private Vault/memory context opt-in by default.
- Provider status no longer implies a credential is proof of a successful upstream model connection.
- The health matrix now states when browser, voice, vision, cloud storage and other services have not been probed.

Additional checks:

- Static security regression assertions: 26/26 PASS.
- TypeScript syntax transpilation: 108/108 PASS (syntax-only; does not perform type resolution or type checking).
- JSON configuration parse: PASS for eight configuration/manifest files.
- `npm ci --offline`: BLOCKED because `@babylonjs/core` is not present in npm cache.
- Online dependency installation timed out; Node available is 22.16.0 while `package.json` requires >=24.12.0.
- Full typecheck, Vitest, production build, Firebase/provider/browser-device tests and deployment remain unverified.

This tranche improves source-level security and honesty but does not close the outstanding durable-persistence, live-provider, multi-instance, complete UI QA or release-build requirements. This remains a working build, not a final release.


### Owner identity binding follow-up — 9 November 2026

- Added optional `OWNER_UID` binding for the primary owner email.
- Firebase token verification rejects a same-email managed record whose stored Firebase UID differs from the token's UID.
- Owner allowlisting no longer creates synthetic managed account identifiers; new owners receive managed account records only after real Firebase sign-in.
- Owner bootstrap script requires explicit `OWNER_EMAIL` and real `OWNER_UID` environment configuration.
- Static security regression assertions now pass 26/26.

Migration caution: do not overwrite existing runtime RBAC files without backing them up. Legacy synthetic owner IDs require controlled review/rebinding by an authorized operator; they are not silently migrated.
