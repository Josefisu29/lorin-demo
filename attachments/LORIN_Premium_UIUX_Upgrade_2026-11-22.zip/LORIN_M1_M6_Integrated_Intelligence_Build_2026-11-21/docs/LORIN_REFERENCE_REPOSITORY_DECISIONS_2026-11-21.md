# LORIN — External Repository Analysis & Integration Decisions

**Review date:** 21 November 2026  
**Reviewed inputs:** `jarvis-main (1).zip`, `Ultron-main.zip`, `J.A.R.V.I.S-main.zip`  
**Target:** the saved LORIN continued-remediation working build dated 9 November 2026, continued in this working copy on 21 November 2026.  
**Review type:** archive integrity, file inventory, source inspection, architecture comparison, security review and selective LORIN remediation. This is not a live deployment, penetration test or hardware acceptance test.

## 1. Executive decision

Do not merge the three repositories wholesale and do not replace LORIN's React/TypeScript + Node.js architecture with a Python/PyQt desktop application. LORIN already has model routing, Firebase identity, a Node backend, a local-node runtime, policy enforcement, memory, Knowledge Vault, voice/vision, device-control, task, project, GIDEON and MOSAIRA subsystems. The main engineering problem is incomplete end-to-end wiring, durability and verification—not absence of another assistant codebase.

Use the repositories as follows:

- **JARVIS (newer React/Node project):** strongest reference for a local bridge, continuous voice interaction, interruption/barge-in, capability probing, WebSocket event transport and policy enforced at the actual tool invocation boundary.
- **ULTRON (Python/PyQt project):** reference only for action schema design, local companion concepts, hardware/service health, SQLite graph-style retrieval and a visible human-confirmation interaction. The supplied archive has no `LICENSE` file, contains unsafe arbitrary-command and self-modifying-code patterns, and includes claims of verification without actual execution. Do not copy its code absent upstream licensing clarification and a separate security review.
- **J.A.R.V.I.S. (legacy Python/PyQt5 project):** historical reference for basic voice utility routing only. Its old dependency stack, monolithic architecture and direct operating-system commands are not suitable for LORIN.

LORIN remains one private, owner-controlled assistant. Lena, Owen, Riley, Iris, Nolan and GIDEON remain internal specialist capabilities. MOSAIRA remains separately governed and must not inherit LORIN's private memory, credentials, devices, owner controls or conversations.

## 2. Archive verification and provenance

| Input | Size | Archive contents | ZIP test | SHA-256 |
|---|---:|---:|---|---|
| `jarvis-main (1).zip` | 2,962,898 bytes | 81 entries; 69 files | PASS | `d10027a12bfbfc634a192801d52ee0172422838ac8d514e5dc36cfee52ca433b` |
| `Ultron-main.zip` | 1,671,386 bytes | 109 entries; 101 files | PASS | `e1ff702cc8134bd8b4b55244636e0387349640a436232a4303b1ab711ca538ff` |
| `J.A.R.V.I.S-main.zip` | 23,668,959 bytes | 43 entries; 36 files | PASS | `32c6af4be2a2cc91200cbce42cefcc44209399e6194d957d0a1fc17af653f1be` |

The three source archives were extracted into a separate analysis workspace. They are not copied into the LORIN application tree and are not included in the LORIN release ZIP. This avoids dependency collisions, duplicate application identities, unreviewed plugins and accidental transfer of unsafe execution patterns.

## 3. Repository A — JARVIS (newer React/Node/WebSocket assistant)

### Architecture observed

The repository combines a React/Vite user interface, a Three.js/React Three Fiber visual scene, browser audio capture and voice state, a Node.js local bridge, a persistent WebSocket channel, the Claude Agent SDK as its agent runtime, and optional voice/wake-word services. Its README requires a local Claude Code login and a supported Chromium browser/WebGL/microphone environment. This differs from LORIN's intended Gemini + Ollama provider architecture and should not replace it.

### Strong ideas worth adopting

1. **One local bridge between UI and privileged capabilities.** Keep UI and model orchestration away from direct device/OS commands. Use an authenticated, loopback-bound companion service with explicit origin/host checks and versioned request schemas.
2. **Voice activity detection and interruption.** `src/lib/vad.ts` uses a smoothed RMS energy level, an adapting noise floor, hysteresis, a short speech-confirmation window, a pre-started recorder to preserve the first phoneme, a silence end window, a maximum segment duration and an echo guard while TTS is playing. Its current reference values are 110 ms speech confirmation, 650 ms silence, and 20 s maximum segment. These are starting points, not universal settings.
3. **Separate audio segmentation from turn completion.** Audio silence determines when a clip should be sent for transcription; transcript/turn logic determines whether the user finished a thought. Do not conflate the two.
4. **Barge-in.** Detect real user speech while LORIN is speaking, stop/suspend the current TTS output, and route the new input without corrupting the transcript queue.
5. **Capability probing.** Probe available STT/TTS/model/device capabilities rather than assuming browser APIs or providers are operational. Distinguish detected, configured, connected and end-to-end verified states.
6. **Persistent bridge events.** A WebSocket or equivalent authenticated event channel can stream task status, local-node health and voice state. It must reconnect safely, identify stale state and never report success solely because a socket is open.
7. **Policy at the last execution boundary.** `bridge/policy.mjs` explains a meaningful failure mode: an SDK's higher-level permission callback may not see every built-in call. Its `PreToolUse` hook is used as an additional pre-execution enforcement point. LORIN should similarly enforce policy in its trusted server/worker immediately before dispatch, not only in UI controls, model prompts or initial tool listing.
8. **Network and filesystem safety.** The bridge includes loopback defaults, Host/Origin checks, DNS/IP vetting, private-network/metadata blocking, path-root validation, symlink-aware path checks and secret-path restrictions. These are useful review patterns for LORIN's local-node service and any future connectors.

### Limitations and cautions

- A name-based read/write heuristic is useful as a secondary guard but cannot be the only authorization engine. LORIN should use typed action IDs, schemas, resource scope, requested effect, principal, device grant and risk policy.
- A voice loop must not silently become an always-on microphone. LORIN's first supported mode remains user-initiated tap-to-talk; wake-word operation requires explicit enrollment/consent, a persistent visible indicator, and an easy stop control.
- The JARVIS repository depends on Anthropic/Claude Code tooling. Do not substitute this for LORIN's real Gemini and Ollama adapters or imply the different providers are equivalent.
- The newer JARVIS repository includes an MIT license. Any direct source reuse would require preserving the copyright and license notices and documenting the imported files. This continuation does not copy JARVIS source code.

### LORIN decision

Adopt the **architecture patterns** for VAD/barge-in, the authenticated local bridge, capability probes, structured event streaming and actual-execution policy gates. Implement them natively in the current LORIN TypeScript/Node codebase with tests. Defer voice VAD coding until the clean dependency/build pipeline and audio lifecycle tests are available.

## 4. Repository B — ULTRON (Python/PyQt local assistant)

### Architecture observed

The repository is a Python 3.11–3.13 / PyQt6 desktop application with a HUD/avatar, Gemini/OpenAI-compatible/Ollama client paths, voice/STT/TTS modules, local memory and an action/plugin registry. It advertises many device, network, browser, Android, IoT and computer-control actions. Its size and feature count are not evidence that those actions are secure or production-ready.

### Useful concepts, not direct code reuse

1. **Schema-first action declarations.** A tool should have a stable ID, description, validated parameter schema, capability requirements, risk classification, timeout, audit metadata and an explicit server-side executor. LORIN's existing action and policy systems should converge on one typed registry rather than discovering arbitrary scripts.
2. **Visible owner confirmation.** `core/confirm.py` demonstrates that an effectful action should pause and ask the human through a visible UI. However, ULTRON's implementation has a single pending request slot and holds a callable in process memory; it is not a robust approval protocol. LORIN's action-bound server approval records are a better foundation, but must become durable and transactional before multi-instance production use.
3. **Local graph memory.** `memory/cerebro_graph.py` stores nodes, weighted edges and token/trigram vectors in SQLite and traverses related nodes for retrieval. This can inform LORIN's local Knowledge Vault and GIDEON retrieval design, but its vectors are lightweight bag-of-token/trigram representations—not evidence of a modern dense-embedding model. The visible SQLite connection code does not establish database encryption at rest, despite broader encryption language elsewhere.
4. **Capability health.** The desktop concept is useful for showing actual microphone, speaker, model, local service and device readiness. Reuse the status design only with measured probes and truthful state transitions.

### Critical unsafe patterns rejected

- **Dynamic action import:** `core/action_loader.py` uses Python module import/`exec_module` to discover action files. Importing a file executes its module-level code. A generated or untrusted action must never be imported into the privileged LORIN process simply because it passes a schema check.
- **Self-evolution:** `actions/self_evolution.py` writes generated Python into an executable action/plugin directory, performs only basic AST/regex validation, compiles/imports the module and registers it. The template can return “Execution verified”/“100% Passed” based on code validation rather than a real execution result. Reject this approach completely.
- **Arbitrary shell:** `actions/system_command.py` executes arbitrary command strings through PowerShell or Bash, with only a small denylist. Do not expose a general shell tool to a language model.
- **Broad Android/ADB/fastboot:** the Android action module contains shell, install, push/pull, reboot and flashing pathways. LORIN should allow only separately designed, enumerated, device-scoped actions; never general shell/flash/EDL control.
- **Camera/background surveillance and broad device/network control:** not enabled by default. Explicit device permission, purpose, visible status, access duration, scope and revocation are mandatory.
- **Fake operational metrics/results:** never display a “verified” result because code parsed, compiled, was generated or returned a success-shaped string. Verification must be tied to an actual executor, observable output and independent postcondition checks.

### Licensing decision

The supplied ULTRON ZIP contains a README badge referring to MIT but no `LICENSE` file in the archive. A badge is not a license grant. Do not copy its source files into LORIN until the actual upstream license and ownership are verified. Its patterns may be discussed as technical observations; source reuse remains prohibited pending clarification.

### LORIN decision

Use the schema-registry and local graph ideas as design inputs. Retain LORIN's existing typed service boundaries and security policy. Do not import ULTRON's dynamic loader, self-evolution, unrestricted command, ADB/fastboot, surveillance or “autonomous overlord” concepts.

## 5. Repository C — legacy J.A.R.V.I.S. (Python/PyQt5)

### Architecture observed

The archive is a largely monolithic Python/PyQt5 desktop assistant from the 2021-era dependency ecosystem. It uses SpeechRecognition, pyttsx3/PyAudio, older OpenCV/pytube libraries and direct desktop command helpers. It has a separate MIT license.

### Lessons

- Simple intent-to-utility mapping is easy to understand and can be useful for basic user-facing helpers.
- Utility handlers should be separated into small, testable functions rather than being coupled to a UI class.

### Problems that make it unsuitable as a base

- Old fixed dependency versions and Python/PyQt5-era structure require modernization before they would be safe or compatible.
- Direct `os.system` calls are used for shutdown/restart/suspend/process actions, without a modern scoped authorization layer.
- Email examples instruct users to insert account credentials into source-level placeholders; LORIN must use server-side secret storage/OAuth and must never put passwords in source or UI configuration.
- The app lacks LORIN's multi-provider routing, durable user-scoped memory/Vault, trusted action approvals, multi-user identity model and audit architecture.

### LORIN decision

Do not port or merge the legacy application. Retain the general idea of small utility adapters only; LORIN already has a stronger Node/TypeScript service architecture.

## 6. Existing LORIN systems — avoid duplication

The audited LORIN source already contains these foundations:

- React/Vite/PWA client and Express/TypeScript backend.
- Firebase identity/token handling and owner bootstrap paths.
- `serverModelRegistry.ts` plus Gemini/Ollama provider adapters.
- `serverPrimaryNode.ts` local companion and encrypted local-node state.
- `src/services/policyEngine.ts` and server-side approval routes.
- `src/services/memoryStore.ts` and user-scoped Firestore memory paths.
- `src/services/vaultStore.ts` and Knowledge Vault UI.
- `src/services/audioService.ts`, `VoiceChatView.tsx` and `videoService.ts`/`VideoVisionView.tsx`.
- `src/services/deviceCenterService.ts` and network/device control UI.
- `src/services/projectStore.ts`, `taskQueueService.ts`, verification runner and project/task workspaces.
- GIDEON services/workspace and MOSAIRA routes/services.

The review found that the application has existing audio capture, browser SpeechRecognition, cloud audio clip transcription and interruption methods, but no demonstrated equivalent of the newer JARVIS RMS/noise-floor VAD pipeline. Therefore VAD/barge-in is a **target for an engineering phase**, not a feature claimed as already delivered.

## 7. Changes applied to the LORIN working copy on 21 November 2026

1. Removed built-in sample projects, tasks and daily goals from the user-facing default state. Existing project/task UI now starts with honest empty states instead of invented history.
2. Separated manual daily goals from executable automation tasks. Marking a personal goal complete does not create or run an automation job.
3. Added a task executor registration contract, but no production executor is installed. Execution remains fail-closed until a real trusted worker exists.
4. Added compatibility handling for old task records claiming success without evidence. Such records are downgraded to `BLOCKED`, and unsupported “verified” output is removed pending re-verification.
5. Changed client policy to fail closed when the authoritative policy server is unavailable. Local-only approval fallback is available only when explicitly selected by isolated tests/development code.
6. Changed primary-node high-impact command execution to require a server-issued approval bound to the authenticated principal, exact command and device/resource. A browser-provided `ownerApproved` boolean is no longer accepted.
7. Changed task persistence API to sanitize submitted tasks and reject client-forged completion claims; client-submitted `SUCCEEDED`/`COMPLETED` records and completed steps are downgraded to `BLOCKED` without a trusted server execution receipt.
8. Extended the static security regression script from 26 to 29 assertions.

### Verification performed

| Check | Result | Interpretation |
|---|---|---|
| `node scripts/security-regression-check.mjs` | PASS — 29/29 | Static source assertions, not an integration or penetration test |
| TypeScript syntax transpilation | PASS — 108 files; 0 syntax diagnostics | Syntax-only; not semantic typechecking |
| ZIP integrity of all 3 uploaded references | PASS | Archive integrity only |
| Full `tsc --noEmit` | BLOCKED | Dependencies/types missing in current environment (`vite-plugin-pwa/client`, `vite/client`); runtime is Node 22.16.0 but LORIN requires >=24.12.0 |
| npm lockfile consistency | FAIL | Root dependency declarations do not match `package.json` |
| Vitest suite | NOT RUN | No complete compatible `node_modules` installation |
| Vite + server production build | NOT RUN | Same runtime/dependency/lockfile blockers |
| Firebase/Firestore Emulator, Gemini, Ollama, browser/device QA | NOT RUN | Requires actual configured project, credentials, services and target-device environment |
| Deployment | NOT RUN | No deployment action performed or claimed |

## 8. Critical limitations still open

### 8.1 Build reproducibility

The current working environment has Node 22.16.0, while `package.json` requires Node >=24.12.0. `package.json` and `package-lock.json` disagree: the lock root omits six declared production dependencies (`@babylonjs/core`, `esbuild`, `ollama`, `react-is`, `recharts`, `vite-plugin-pwa`), omits `vitest` from dev dependencies, places `esbuild` and `vite-plugin-pwa` under dev dependencies instead, and does not mirror the three optional platform packages. Do not run `npm ci` against this lockfile. First use the declared supported Node version, reconcile dependency versions deliberately, regenerate the lock from the reviewed manifest, then perform a clean install and all checks.

### 8.2 Durable state and approvals

The current server stores several conversation, project, task, approval and audit structures in process memory and JSON snapshots. `/tmp`/ephemeral filesystem storage on a serverless host is not a durable shared database. Action-bound approvals are safer than client booleans but remain vulnerable to loss/race issues across restarts and instances until migrated to transactional persistent storage with atomic single-use consumption, actor binding, expiry, idempotency and audit records.

### 8.3 Real executor boundary

The client executor registry is not a security boundary. The server correctly rejects untrusted client success claims, but there is not yet a verified server-owned job worker with durable job state, scoped tool executor, event stream, timeout/cancellation, execution receipt and postcondition verification. Keep all real task execution marked blocked until implemented.

### 8.4 Providers, offline, voice, vision and desktop

Provider adapters in source do not establish real model inference. Gemini and Ollama need authenticated request/stream tests with real provider identity, latency, failure and usage reporting. Offline operation needs a real local model and tests with network disconnected. Voice needs explicit microphone lifecycle, VAD, echo handling, transcript assembly, barge-in and stop tests. Camera/vision must clearly distinguish snapshots from real-time streaming. Windows desktop packaging is not delivered merely by building a web frontend and Node bundle.

### 8.5 MOSAIRA separation

MOSAIRA must remain a separately authorized public platform with distinct credentials, API authorization, data store or provably isolated namespaces, rate limits and audit. No public request may access private LORIN memory, vault, conversations, device registry, owner controls or local companion.

## 9. Recommended engineering sequence

### M0 — Reproducible baseline

- Build on Node >=24.12.0.
- Reconcile package manifest and lockfile.
- Run clean install, `tsc --noEmit`, Vitest, source checks, Vite build and server bundle.
- Fix every actual compile/test issue; record `PASS`, `FAIL`, `BLOCKED` and `NOT RUN` distinctly.

### M1 — Trusted state and task integrity

- Choose a durable persistence abstraction supporting local-first Windows storage and cloud sync.
- Use SQLite with migrations and encryption/key lifecycle for the local runtime; use authenticated Firestore or another approved shared database for cloud sync.
- Add schema versioning, backup/restore, account scoping, tombstones, conflict policy and import/export.
- Make approval creation, approval consumption, audit writes and job transitions transactional and idempotent.
- Implement server-owned task workers before enabling any automation.

### M2 — Capability registry and policy

- Consolidate action schemas in a typed registry with stable IDs and versions.
- Define read/write/network/device/file/system capability classes, principal scope, resource scope, risk, timeout, idempotency and rollback.
- Enforce deny-by-default immediately before every real tool invocation.
- Keep arbitrary shell, generated-code hot loading and unrestricted device control unavailable.
- Add adversarial tests for path traversal, symlinks, DNS rebinding/SSRF, prompt injection, approval replay, cross-user/device access and cancellation races.

### M3 — Voice interaction

- Keep tap-to-talk as baseline.
- Implement a tested VAD pipeline inspired by JARVIS: adaptive noise floor, smoothing, hysteresis, short onset confirmation, first-phoneme pre-roll, silence segment end, maximum duration and TTS echo guard.
- Separate segment completion from turn completion.
- Add barge-in that stops current playback and safely serializes queued transcripts.
- Add visible mic state, permission explanation and one-action stop/release of capture tracks.
- Keep wake-word mode explicit opt-in and disabled by default.

### M4 — Honest model routing and offline

- Test actual Gemini and Ollama requests, streaming, model identifiers and provider errors.
- Do not silently substitute canned output if inference fails.
- Use smallest capable model subject to quality, privacy, latency and cost; always disclose provider/model routing when useful.
- Measure target Windows hardware before selecting local models.
- Verify local-only execution with the network disconnected.

### M5 — Windows companion and multimodal expansion

- Select a desktop shell only after M0–M4 are stable.
- Use renderer isolation, strict CSP, loopback-only backend, authenticated IPC, explicit device permissions, secure key storage, crash recovery, installer/update strategy and clean uninstall/data-retention controls.
- Test on supported Windows 10/11 hardware before claiming native desktop or offline capability.

### M6 — System-wide acceptance

- Verify auth/account isolation, memory/Vault deletion, backups/restores, task/action approval, provider failover, local/offline inference, voice stop, snapshot privacy, device scopes, MOSAIRA isolation, mobile/desktop UX, performance and recovery.
- Produce an evidence-backed release report. Any critical/high security gap means NOT READY.

## 10. License and reuse register

| Repository | License evidence in supplied ZIP | Source reuse decision |
|---|---|---|
| Newer JARVIS | MIT `LICENSE` present | Possible only for selected reviewed files with preserved notices; this continuation copied no source files |
| ULTRON | No `LICENSE` file present; README badge alone is insufficient | No source copying until upstream license/ownership is verified |
| Legacy J.A.R.V.I.S. | MIT `LICENSE` present | Technically obsolete and unsafe patterns; no source copying in this continuation |

## 11. Final assessment

**LORIN is a security-remediated working prototype, not a production release.** The three repositories provide useful patterns, especially JARVIS's voice/bridge/policy boundary and selected ULTRON concepts for structured capabilities and local graph retrieval. None removes the need to repair LORIN's dependency pipeline, durable persistence, trusted execution worker, provider verification, offline testing and Windows packaging. The correct path is incremental integration into the existing LORIN source, backed by tests and explicit permissions—not wholesale merging or adding more unverified features.
