# LORIN V2 as-built architecture

Audit snapshot: 2026-11-05, branch `main`, baseline commit `2e5244e`.

## Runtime boundaries

```mermaid
flowchart LR
  Browser[React 19 + Vite PWA] -->|Firebase ID token| API[Express API in server.ts]
  Browser -->|public Firebase config| Firebase[Firebase Auth / Firestore]
  API -->|verify ID token| Auth[serverAuth.ts]
  API -->|provider request| Gemini[Google Gemini]
  API -->|provider request| Ollama[Ollama Cloud]
  API -->|admin SDK when configured| Firebase
  API -->|local policy persistence| State[server memory + JSON snapshot]
  Vercel[Vercel rewrites] --> API
  Vercel --> Browser
```

The browser is a React/Vite application with a PWA plugin. `server.ts` owns Express API routes and, for local development, Vite middleware. `api/index.ts` exports the Express app for Vercel. `npm run build` builds the frontend and bundles `server.ts` to `server.js`; `npm start` runs that generated bundle. `firestore.rules` defines client Firestore access. Gemini and Ollama Cloud adapters are implemented in server-side modules; the browser's Ollama service also supports a configured endpoint path, whose hosted/local pairing safety requires further review.

## Request paths

1. Firebase Auth emits a browser user; the client gets an ID token.
2. The client calls `/api/me` and inference endpoints with a bearer token.
3. `serverAuth.ts` verifies Firebase tokens, resolves a managed account/owner, and attaches a server principal.
4. Protected API handlers enforce auth and, on privileged routes, role/scope middleware.
5. Inference chooses a configured provider/model and returns provider attribution or a typed failure.

The app now starts with a guest principal and clears protected client state on every Firebase unauthenticated transition. Provider calls remain server-side. The verified model inference path has not been exercised in this environment.

## Persistence and trust limits

- Firebase Auth provides browser identity. Firestore is configured through `firebase-applet-config.json` and environment overrides; the rules use per-user ownership checks and a server-managed `user_roles` collection for privileged role checks.
- Client stores also exist for projects, conversations, memory, Vault, preferences and policy UI. Their persistence is not equivalent to a trusted server authorization boundary.
- Policy approvals/audits have server endpoints and a JSON snapshot fallback; the current snapshot implementation is process/filesystem dependent and is not a durable multi-instance transactional store.
- Vercel routes `/api/*` to `api/index.ts`; static paths fall back to `index.html`.

## Important gaps

The system still needs production-grade durable approval/audit storage, bounded request schemas and body-size limits, rate/concurrency budgets across instances, Firebase emulator rules tests, and verified provider smoke tests. The generic `/api/health` response is not inference evidence. Hosted access to a user's local Ollama requires a paired connector and is not established by the current code.
