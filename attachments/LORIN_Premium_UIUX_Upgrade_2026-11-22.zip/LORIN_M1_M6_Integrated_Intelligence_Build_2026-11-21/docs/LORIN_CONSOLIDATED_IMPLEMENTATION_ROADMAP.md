# LORIN consolidated implementation roadmap

**Snapshot:** 2026-11-06  
**Repository:** `main`, commit `8b30c10`  
**Purpose:** Single implementation register for the consolidated LORIN history. This document records repository evidence separately from the intended product vision. A feature mentioned in a plan or represented by a screen is not considered complete until its real path and acceptance checks pass.

## Product definition

LORIN is intended to be one private, multimodal personal AI and engineering assistant. It should use the relevant expertise from six complementary capabilities, preserve user-approved context, work across projects, and execute tools only within explicit permissions. It should distinguish actual results from previews, local model access from cloud inference, and retrieval from model training.

The six private capabilities are Lena (security), Owen (coordination), Riley (communication and learning), Iris (research), Nolan (engineering strategy), and GIDEON (timeline, continuity, diagnostics, and evidence-based forecasting). They belong to one assistant experience rather than six competing chatbots.

MOSAIRA is a separate public AI platform direction for public model discovery, evaluation, developer APIs, datasets, and community knowledge. It must not inherit LORIN's private memory, identity, permissions, or owner controls. Shared model-serving infrastructure, if used, must have an explicit boundary.

## Status vocabulary

- **PASS:** named verification ran and passed.
- **PARTIAL:** code or UI exists, but the full user journey, trust boundary, or acceptance checks are incomplete.
- **MISSING:** required capability was not found in the inspected implementation.
- **NOT RUN:** no verification evidence exists for the capability.
- **DECISION:** implementation depends on an unresolved product or architecture choice.
- **BLOCKED:** a known prerequisite prevents completion.

These labels describe the evidence available at this snapshot, not a guarantee about production behavior.

## Current verified position

| Area | Status | Evidence and limit |
|---|---|---|
| React/Vite application, Express API, Firebase integration and Vercel configuration | PARTIAL | Present in repository; full hosted user journey not verified. |
| React/Recharts dependency tree | PASS | `react`, `react-dom`, `recharts`, and `react-is` inspected on 2026-11-05; React is deduped and `react-is` is production dependency. |
| Production build | PASS | `npm run build` passed 2026-11-06 after the current implementation tranche; Vite produced PWA assets and esbuild bundled `server.js`. Main chunk advisory: 2,241.62 kB minified (587.67 kB gzip). |
| Auth/session and role boundaries | PARTIAL / HIGH PRIORITY | This implementation removes fixed owner identity fallbacks, demo owner role seeding, local role editing, and cross-UID owner aliases. Server allowlist and verified principal now govern owner access; Firebase emulator, direct negative tests, durable RBAC, and full lifecycle QA remain unrun. |
| Firestore ownership rules | PARTIAL | Default-deny and UID-scoped rules exist; emulator tests and service identity review remain. |
| Gemini and Ollama Cloud adapters | PARTIAL / NOT RUN | Server adapters and routes exist; no real authenticated provider smoke test is recorded. Hosted access to the user's local Ollama is not established. |
| Approval and audit records | PARTIAL | Endpoints now scope personal records to the verified principal; current JSON/process-based state is not durable or atomic across serverless instances. |
| Chat, memory, Vault, projects and task UI | PARTIAL | Modules exist; persistence, retrieval, isolation, and end-to-end journeys are not fully verified. |
| GIDEON | PARTIAL | Demo timeline/decision/prediction state is removed from server and local empty states. User-scoped routes and unverified manual events are implemented; durable shared storage, verified telemetry, and evidence-grounded predictions remain missing. |
| MOSAIRA | PARTIAL | Missing provider configuration now returns 503; owner-only developer key routes and actual provider usage metadata are enforced. Public endpoint isolation, separate deployment, durable key storage, and real provider behavior remain unverified. |
| Voice and vision | PARTIAL | Browser speech and media capture code exists; wake-word detection, continuous video understanding, provider modality, privacy lifecycle, and device QA are not established. |
| Automated test suite | FAIL | Last recorded run: 36/37 passed with an Ollama test-environment dependency/import failure. |
| TypeScript check | BLOCKED | Last recorded run lacked the platform TypeScript package. |
| Browser, responsive, accessibility and device QA | NOT RUN | No visual/browser QA evidence in the verification report. |
| Vercel deployment | NOT RUN | No deployment result. Root `npm run build` is configured; hosted root/settings/secrets and runtime routes are not verified. |

Evidence sources: `LORIN_V2_IMPLEMENTATION_AND_VERIFICATION_REPORT.md`, `docs/LORIN_V2_FEATURE_MATRIX.md`, `docs/LORIN_V2_ARCHITECTURE.md`, `package.json`, `server.ts`, `serverAuth.ts`, and service/component code. The October 29 archive audit is historical context only and is not treated as proof of the present source state.

## Phased plan

Phases are ordered by dependency and risk. Each phase closes with its acceptance criteria before dependent features are promoted as ready. A phase may contain UI already present; that does not change the status of its operational acceptance checks.

### Phase 0 — Product and evidence baseline

**Status: PARTIAL.** This roadmap and current source review establish the baseline; two public persona naming sets remain unresolved. Seeded owner identities and demo records were removed or neutralized in the current implementation tranche.

Scope:
- Keep LORIN as the canonical private assistant name; MOSAIRA remains the separate public platform.
- Preserve six LORIN capabilities and their roles, with GIDEON as the latest addition.
- Decide the canonical MOSAIRA ten-persona set: NOVA/SAGE/ATLAS/ORBIT/PIXEL/ECHO/LINGO/PULSE/FORGE/SENTINEL or Maya/Adrian/Ethan/Nora/Leo/Clara/Sofia/Theo/Marcus/Elena.
- Record which capabilities are product-ready, preview-only, local-only, cloud-only, or not implemented.
- Reconcile the offline design: proposed SQLite canonical local store + FTS5 + one vector store + local embeddings, versus existing Firebase/server and browser-local stores. Choose migration and sync semantics before replacing persistence.

**Done when:** decisions have one source of truth; each row in the feature matrix links to code and a runnable acceptance check; all mock/preview behavior is explicitly labeled or removed.

### Phase 1 — Release foundation, identity, and security

**Status: PARTIAL; release gate.** Client-side owner/role elevation and server demo-role seeding have been removed, and owner authority is derived from verified identity plus server configuration. Owner-scoped audit reads, UID isolation, account switching, and provider key access were tightened. Direct API/emulator authorization tests, distributed limits, and durable atomic security state remain release blockers.

Scope:
- Finish Firebase authentication lifecycle, token verification, account provisioning, owner recovery, and least-privilege role/scope assignment.
- Add direct API authorization tests and Firebase emulator tests for UID isolation, default deny, owner/admin controls, and session invalidation.
- Validate every request shape and size; establish distributed rate/concurrency/usage budgets rather than relying on per-process counters.
- Replace process/file-backed approval, audit, MOSAIRA key, and other security-critical persistence with durable, atomic storage suitable for serverless instances.
- Remove client-side fixed-email role/owner checks and hard-coded defaults from settings, audit actors, seed/demo content, and UI fallback labels. Resolve owner authority only on the server from verified identity and server-managed configuration; use neutral test fixtures.
- Threat-model public MOSAIRA endpoints, developer keys, abuse protection, origin policy, and public/private data boundaries.

**Done when:** unauthorized and cross-user requests fail in automated tests; administrative changes are auditable and durable; no client-side fixed-email role elevation or embedded owner identity/secret remains; limits work across instances; security rules and API enforcement agree.

### Phase 2 — Real provider routing and truthful responses

**Status: PARTIAL; live checks NOT RUN.** Missing MOSAIRA credentials no longer yield generated preview answers, and usage metadata is reported only when supplied by the provider. Authenticated Gemini/Ollama Cloud smoke tests, streaming/fallback validation, and privacy routing checks remain outstanding.

Scope:
- Verify Gemini and Ollama Cloud requests using staging credentials, supported model names, streaming, timeout, cancellation, error handling, and attribution.
- Ensure the backend reports the provider/model actually used, including controlled fallback; privacy settings must prevent prohibited cloud routing.
- Make missing credentials return a clear unavailable/configuration state. Do not present generated template text as model output.
- Separate the local Ollama service from Ollama Cloud and document the missing authenticated local companion/bridge.
- Record token/cost/latency data only when the provider actually supplies it; do not invent estimates and label them as actual usage.

**Done when:** authenticated smoke tests prove each configured route and model attribution; missing credentials and provider failures are truthful; local requests cannot leak to cloud via silent fallback.

### Phase 3 — Unified chat and six capability orchestration

**Status: PARTIAL.**

Scope:
- Make the main conversation the single center of the app: history, search, project context, streaming, stop, regenerate/edit, code/markdown rendering, attachment processing, errors, and model selection.
- Route tasks to relevant capabilities, not all specialists for every prompt; keep simple greetings natural.
- Treat Lena, Owen, Riley, Iris, Nolan, and GIDEON as capabilities coordinated through one assistant. A single underlying model with role prompts must not be represented as six separately running models.
- Show sources, active capability, provider/model identity, and tool actions accurately.

**Done when:** end-to-end chat journeys pass for greeting, factual research, engineering, multimodal input, interruptions, provider failure, and context selection; specialist/model claims match actual execution.

### Phase 4 — Durable conversations, memory, and Knowledge Vault

**Status: PARTIAL; architecture decision required.**

Scope:
- Decide canonical storage and sync behavior before changing data: cloud Firestore/server persistence, local-first SQLite companion, or an explicit hybrid with conflict/backup rules.
- Build document import for each supported format only when a real parser is wired; validate, extract, normalize, chunk, deduplicate, version, and delete content.
- Provide lexical search and semantic embeddings/retrieval with access filters, cited source passages, reranking where justified, and visible provenance.
- Add memory review/edit/delete/export and ensure user deletion propagates to all indexes, copies, and backups according to retention policy.
- Keep RAG distinct from training; imported material is not model training.

**Done when:** retrieval answers cite authorized source passages; tests prove project/user isolation, update/deletion propagation, backup/restore, and offline behavior exactly as specified.

### Phase 5 — GIDEON timeline, continuity, diagnostics, and forecasts

**Status: PARTIAL; real data sources missing/unverified.** Seeded records and fabricated forecast fallback were removed; manual timeline entries are unverified and forecasting reports unavailable without real sources. Durable shared persistence, telemetry integrations, and forecast calibration are not implemented.

Scope:
- Persist real, timestamped project decisions, deployments, incidents, code changes, and approved system events with provenance.
- Connect supported telemetry sources explicitly; expose freshness and missing data.
- Correlate events with evidence and explain causal uncertainty; separate observations from forecasts.
- Replace seed/demo timeline claims in production views with empty states until actual events exist.
- Produce risk/prediction outputs only from traceable history and calibrated evidence; never invent operational telemetry.

**Done when:** test fixtures are distinguishable from production; questions like “what changed?” resolve to sourced event records; forecasts disclose assumptions and can be evaluated against outcomes.

### Phase 6 — Projects and safe engineering workspace

**Status: PARTIAL.**

Scope:
- Complete independent project workspaces, specs, tasks, decisions, files/repositories, milestones, changelogs, and project-aware conversations.
- Add actual repository browsing/editing, Git operations, build/test execution, bug tracking, and deployment previews only through a registered tool service.
- Use a scoped sandbox with explicit workspace roots, resource limits, secret redaction, command allow/deny rules, cancellation, and durable approval for high-impact actions.
- Keep separate projects (including NexaSpace Connect, SeppinaLuxe, and MOSAIRA) isolated.

**Done when:** project isolation and file/tool permissions are tested; previews show diffs and command outputs; destructive, external, or production operations require explicit approval and are audited.

### Phase 7 — UI/UX, accessibility, and responsive quality

**Status: PARTIAL; browser QA NOT RUN.**

Scope:
- Finish a coherent visual system across shell, chat, workspaces, settings, loading/error/empty states, and mobile layouts.
- Add purposeful animations/transitions, audio-reactive state only when driven by actual audio, keyboard navigation, focus visibility, contrast, screen-reader semantics, and reduced-motion handling.
- Ensure responsive behavior at narrow mobile/tablet/desktop sizes and practical touch targets.
- Run real browser review of the common journeys after changes.

**Done when:** key flows pass keyboard and screen-reader checks; responsive screenshots/QA cover agreed viewport sizes; reduced-motion and error/empty/loading states work; no animation implies a system action that did not occur.

### Phase 8 — Voice and vision

**Status: PARTIAL.**

Scope in order:
1. Reliable foreground tap-to-talk, speech-to-text, text-to-speech, interruption, mute, transcript, and teardown.
2. Foreground “Hey LORIN” wake-word detection only with a real supported engine and explicit microphone controls.
3. Background activation only through a separately built native companion and supported OS APIs; a browser PWA must not claim closed/locked-screen listening.
- Add image upload, camera preview, explicit snapshot submission, supported vision inference, privacy indicators, and hardware/session cleanup.
- Treat continuous video understanding as a distinct capability requiring a supported realtime provider and tested consent/retention controls.

**Done when:** hardware stops on every exit/error path; users can interrupt; model modality is verified; UI accurately distinguishes snapshots from a continuous stream.

### Phase 9 — Integrations, automation, and device coordination

**Status: MISSING/PARTIAL; defer privileged execution until Phase 1 and Phase 6.**

Scope:
- Define an integration registry with owner, scopes, credential storage, consent, revocation, health, data retention, and audit history.
- Add calendar, email, files, local desktop, browser, and household/device integrations one at a time through least-privilege adapters.
- Add scheduled/background jobs with idempotency, retries, monitoring, cancellation, and human approval gates.
- Treat computer control and household automation as high-impact actions; default to suggest/preview, then approve/execute.

**Done when:** each integration has data-flow documentation, scoped credentials, revocation and failure tests; no unapproved action can execute.

### Phase 10 — MOSAIRA public platform

**Status: PARTIAL; public production readiness unverified.** Missing-provider output and ungrounded usage estimates were removed; developer key mutations require the authenticated server owner. Separate production boundary, durable key storage, abuse limits, isolation tests, and live inference remain outstanding.

Scope:
- Establish its own deployment boundary, identity/account model, data store, secrets, quotas, moderation, terms, and public abuse controls.
- Resolve persona names and define each model offer by verified provider, model/version, license, supported modality, and availability.
- Implement model discovery, genuine playground/comparison, developer API, docs, scoped keys/quotas, public knowledge commons, and safe dataset workflow.
- Remove or visibly label offline preview behavior; a persona prompt alone is not a distinct model.
- Prove no private LORIN memory, project data, owner controls, or private training data can enter public requests/corpora.

**Done when:** public endpoints are independently tested and operated; model identity is verifiable; no fabricated inference or token figures are returned; privacy boundary tests pass.

### Phase 11 — Dataset evaluation, training, and deployment lifecycle

**Status: MISSING as an end-to-end production system.**

Scope:
- Build provenance, consent/license, validation, cleaning, versioning, evaluation, artifact storage, model registry, deployment, rollback, and monitoring.
- Distinguish prompt configuration, RAG, fine-tuning, and full model training in UI and docs.
- Require reproducible evaluations and a review gate before public release.

**Done when:** dataset lineage and model artifacts are auditable; evaluations are reproducible; releases can be rolled back; private LORIN data is excluded unless separately and explicitly authorized.

### Phase 12 — Release, operations, and recovery

**Status: NOT READY; deployment NOT RUN.**

Scope:
- Restore a reproducible dependency install, resolve TypeScript and test-runner failures, and run the full supported suite.
- Verify Vercel project root, package manager/lockfile, secrets, build command, API rewrite, static output, serverless runtime, database access, and health/observability.
- Run staging auth, provider, persistence, stream, upload, error, rate-limit, responsive, accessibility, and security tests.
- Add backups, restore drills, migrations, rollback, incident response and release monitoring.

**Done when:** clean install, typecheck, tests, production build and staging acceptance pass; deployment URL is checked end-to-end; rollback and data recovery are demonstrated. A local build is not proof of deployment success.

## Recommended next implementation sequence

1. Close Phase 0 persona and persistence decisions; map every matrix row to an automated acceptance check.
2. Complete Phase 1 direct API/Firebase security tests, distributed limits, and durable approval/audit/key persistence.
3. Complete Phase 2 authenticated Gemini and Ollama Cloud staging smoke tests and privacy-routing verification.
4. Repair complete dependency installation, typecheck and test failures, then run the full regression suite.
5. Finish Phase 3 real chat journeys before expanding further into memory and tools.
6. Decide and implement Phase 4 persistence topology; then connect GIDEON to real events in Phase 5.
7. Complete browser/accessibility QA and only then claim the UI refresh is release-ready.
8. Gate integrations, MOSAIRA production, training, background voice, and device control on their prerequisites and threat models.

## Unresolved decisions to keep visible

- Which ten MOSAIRA persona names are canonical?
- Is SQLite/local-first a required product target, and what is the supported local companion architecture?
- What is the authoritative cloud persistence layer for private user content and security-critical records?
- Is MOSAIRA to remain within this codebase temporarily, or move to its own deployment and operational account before public launch?
- Which exact provider/model versions are approved for each LORIN capability and MOSAIRA persona?
- Which device integrations are in the first supported release, and what approval level does each need?

Do not claim full project completion until each phase's acceptance criteria has evidence in a current verification report.
