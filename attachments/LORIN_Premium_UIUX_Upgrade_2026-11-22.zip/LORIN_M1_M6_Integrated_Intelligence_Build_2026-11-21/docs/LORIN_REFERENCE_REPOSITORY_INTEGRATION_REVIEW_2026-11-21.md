# LORIN — Supplementary Reference Repository Review

**Date:** 21 November 2026  
**Scope:** second upload batch for the LORIN enhancement work.  
**Disposition:** use architectural ideas selectively; preserve LORIN's TypeScript/React/Node architecture; do not transplant a second assistant application.

## 1. Exact archives

| Archive | SHA-256 | License found in supplied archive | Review outcome |
|---|---|---|---|
| `OpenJarvis-main.zip` | `fa2383d47ea61986e920251ed513c274e64432b4ba21737e7f0ed223757321ae` | Apache License 2.0 (`OpenJarvis-main/LICENSE`) | Rich local-first architecture reference; do not merge the full Python/Rust/Tauri stack |
| `Jarvis-Desktop-Voice-Assistant-main.zip` | `a6199d224763d7f7525f02f384fb03457c83d44ea4ad46edd4b4cbe758a885ea` | MIT (`Jarvis-Desktop-Voice-Assistant-main/LICENSE`, copyright Kishan Kumar Rai, 2021) | Small historical desktop voice assistant; limited concepts only |
| `jarvis-main.zip` | `d10027a12bfbfc634a192801d52ee0172422838ac8d514e5dc36cfee52ca433b` | Same archive hash as previously reviewed `jarvis-main (1).zip` | Duplicate archive, not a new independent implementation |

The original first review remains at `docs/LORIN_REFERENCE_REPOSITORY_DECISIONS_2026-11-21.md` and covers the newer MIT JARVIS reference, ULTRON archive (no license file present in the supplied ZIP), and legacy MIT J.A.R.V.I.S. archive.

## 2. OpenJarvis — strongest broader architecture reference

### Ideas worth using

- **Local-first as a measurable policy:** distinguish local-only, local-preferred, balanced and cloud-allowed modes; make fallback explicit; report provider identity, health evidence, latency, cost and context support rather than silently substituting providers.
- **Separation of intelligence, engine, agents and memory:** provider/model decisions, tool execution, retrieval/memory and user interaction should be modular contracts, not one giant assistant class.
- **Typed structured tools:** tools have a name, description, input schema, execution policy and bounded executor rather than accepting free-form shell commands.
- **Trace-based evaluation:** record prompts/inputs, selected provider, tool requests, execution output and expected outcomes in a controlled test harness; use measured pass/fail instead of UI assertions.
- **Retrieval and storage abstraction:** support keyword/vector/hybrid retrieval with explicit provenance and source deletion lifecycle. LORIN already has a Knowledge Vault foundation; this should be improved in place rather than replaced with a second memory stack.
- **Voice provider abstraction:** keep STT, TTS, VAD, audio routing and assistant turn management as separate testable layers. A streaming connection alone is not evidence that the end-to-end voice interaction works.
- **Desktop packaging discipline:** isolate the privileged local runtime, package it independently from the web UI, apply explicit IPC permissions and test install/update/uninstall and recovery.
- **QA runbook and evaluation gates:** each provider, model, tool, memory backend and device capability needs a reproducible test before it can be marked verified.

### Why a wholesale merge is rejected

OpenJarvis is a much broader local-first project with its own Python framework, backend/engine abstractions, agent interfaces, memory backends, evaluation and Learning layer, voice providers and Rust/Tauri desktop application. Copying it into LORIN would duplicate concepts already implemented in `serverModelRegistry.ts`, the LORIN services, local-node runtime and existing UI; it would also introduce a second runtime and another dependency/update surface. Its components should be evaluated separately and only integrated when a clear LORIN contract and acceptance test exists.

### License handling

The supplied archive contains an Apache License 2.0 `LICENSE` file. This enhancement uses the architecture as a technical reference and does not copy OpenJarvis source files. Any future direct source reuse must preserve the license, applicable notices and attribution and comply with Apache 2.0, including review of any `NOTICE` file and dependency licenses.

## 3. Desktop Voice Assistant — simple interaction reference

The supplied project is a small Python desktop assistant using SpeechRecognition, pyttsx3, PyAutoGUI, Wikipedia lookup and direct desktop utilities. Its README and code illustrate basic user-facing voice/utility patterns but are not a suitable LORIN runtime.

### Useful concepts

- Keep individual utility operations small and separately testable.
- Separate speech recognition, intent matching, response generation and text-to-speech rather than tying everything to a single UI event handler.
- Provide clear feedback when recognition fails or an intent is not understood.

### Patterns rejected for LORIN

The supplied `Jarvis/jarvis.py` includes voice-triggered OS shutdown/restart via direct `os.system` calls. This is not acceptable as a general assistant capability. It bypasses LORIN's trusted executor, exact-resource authorization, independent approval, safety interlocks and audit boundaries. Do not port it.

The project is also much narrower than LORIN: it does not provide LORIN's user-scoped Firebase identity, private Memory/Knowledge Vault, multimodel policy router, GIDEON chronology, separate MOSAIRA boundary or safe capability worker.

### License handling

The archive includes an MIT License. This enhancement does not copy its source code. Any future direct reuse must preserve the MIT copyright and permission notices and meet the license conditions.

## 4. What was carried into the enhanced LORIN build

The following are new, independently implemented TypeScript components rather than copied source files:

| LORIN addition | Reference idea | LORIN-specific safeguard |
|---|---|---|
| Timestamp-aware model route planner | Local-first routing and provider health evidence | Local-only is absolute; no automatic cloud fallback; missing/stale health evidence rejects a provider |
| Server-side capability registry | Schema-first tools | Registry is server-owned/sealed; no model or browser executor registration; closed nested schemas; 64 KiB input cap |
| Durable job/approval core | Persistent jobs and human confirmation | SQLite transactions; single-use approval consumed immediately before execution; exact principal/capability/resource/parameter digest |
| AES-256-GCM record encryption with associated data | Local storage/security patterns | Ciphertext bound to its job/approval/receipt record identity; symlink/special-file checks; local directory/file modes |
| Hash-chained audit events | Trace/evaluation discipline | Events carry actor, resource and decision; chain verification detects row changes but is not claimed to be immutable against a privileged database attacker |
| Standalone VAD core | JARVIS/OpenJarvis voice pipeline concepts | Adaptive noise floor, onset, pre-roll and hangover tested as a pure algorithm; not misrepresented as live microphone integration |
| Focused test suite and runbook | OpenJarvis QA discipline | Measured assertions and explicit PASS / NOT RUN / BLOCKED status |

## 5. Repositories not merged and why

- No full repository, UI, agent/persona system, model runtime or code bundle was copied into LORIN.
- The ULTRON archive remains reference-only because its supplied ZIP does not include a license file and it contains unsafe arbitrary-command/self-modifying patterns. Its source should not be reused without license clarification and a separate security review.
- Legacy PyQt/PyQt5 and Python desktop assistant projects do not become a second LORIN client. Cross-platform native packaging is a separate engineering milestone.
- The same-hash `jarvis-main.zip` is treated as a duplicate of `jarvis-main (1).zip`.

## 6. Conclusion

The right path is to make LORIN's own provider, memory, capability, voice, local companion and project subsystems real and verifiable. This build selectively adds a durable action core, stricter capability contracts, record-bound encryption and testable routing/VAD algorithms. It does not claim that OpenJarvis's full stack, all desktop assistant functions or hardware-level device control have been ported.
