# LORIN UI implementation plan

**Updated:** 2026-11-06  
**Scope:** Current React/Vite workspace; preserve existing view identifiers, authentication boundaries, service contracts, and separate MOSAIRA public surfaces.

## Current architecture

The app uses one React entry point (`src/App.tsx`) with conditional workspace views rather than URL routes. The private shell is `NavigationShell` + `SidebarNavigation`; the primary conversation is `ChatWorkspace`; feature views are separate components. Styling is Tailwind CSS 4 plus shared rules in `src/index.css`; Motion is already installed. Dark and light themes already exist. No additional UI dependencies are planned.

## View map

| Surface | Current component | Status in this pass |
|---|---|---|
| Private chat | `ChatWorkspace`, `WorkflowStatusIndicator` | Implemented: calmer first-use state, readable message width/type, status that reflects actual report state, responsive composer, text-only attachment validation, preserved file/text on failed requests, IME-safe Enter, and no forced scroll while the reader is up. Removed false all-specialists-live and canned verified workflow UI. |
| Navigation shell | `NavigationShell`, `SidebarNavigation` | Implemented: clearer primary hierarchy, Connections link, no fake live/AES/count/activity signals, 40 px nav targets, mobile dialog focus/escape handling, and reserved footer for install/account actions. |
| Projects and tasks | `ProjectsWorkspace`, `TasksWorkspace` | Shared tokens and module typography only; route interaction QA not run. |
| Knowledge and memory | `KnowledgeVaultView`, `LaurenVaultHub`, `MemoryConsole` | Shared tokens and module typography only; route behavior not changed in this UI pass. |
| Intelligence | `SpecialistConsole`, `GideonWorkspace` | Shared tokens; main-chat idle specialist roster removed. GIDEON route visual QA not run. |
| Voice and vision | `VoiceChatView`, `VideoVisionView`, `LorinCharacter` | Voice and camera retain explicit user-started permissions. The humanoid presence reflects actual mic, speech synthesis, camera, and frame-analysis states. Camera tracks stop on teardown. Route visual/device QA not run. |
| Intelligence | `GideonWorkspace`, `LorinCharacter` | Presence reflects actual GIDEON data loading, diagnostics, and query operations; no synthetic activity metrics are shown. |
| Connections and security | `ConnectionsWorkspace`, `SecurityDashboard`, `SettingsModal` | Connections is now in primary navigation. Existing role checks preserved; route visual/accessibility QA not run. |
| Advanced and owner | `TerminalWorkbench`, `VerificationSuite`, `UnifiedOwnerGateway` | No view redesign in this pass; existing authorization gates preserved. |
| MOSAIRA public | Discovery, playground, comparison, commons, dataset lab, developer | Kept separate; no route redesign in this pass. Shared theme tokens remain available. |

## Shared design system

- Dark-first surfaces: `#0B0F14`, `#0D141C`, `#111821`, `#17212C`; light-theme equivalents remain supported.
- Text: `#F1F5F9` primary, `#A2AFBF` secondary, `#8796A8` subtle; teal `#66E3CB` is reserved for primary emphasis, with indigo and warm amber for secondary/info and caution.
- Typography: existing Plus Jakarta Sans for UI and JetBrains Mono for technical metadata; no new font dependency.
- Spacing: existing quarter-rem base with 4/8/12/16/20/24/32 px rhythm.
- Radii: 8 px small, 12 px controls, 16 px panels, 20 px large composer surfaces.
- Motion: 150 ms control response, about 200 ms view/theme transition, 240 ms drawer transition; honor reduced-motion preferences.
- LORIN presence: a custom SVG 2.5D humanoid character changes restrained color, glow, and motion from typed application state. The interface does not claim a 3D avatar, real-time research, or other provider capability that is not active.
- Accessibility: visible focus, 40 px navigation targets, safe-area composer padding, labeled icon buttons, modal semantics and focus management for the mobile navigation drawer.

## Completion checklist

- [x] Inspect existing app shell, view map, styling, package scripts, and current workspace interactions.
- [x] Establish shared semantic color, radius, spacing, and motion tokens without adding dependencies.
- [x] Improve chat welcome, message width/readability, composer sizing, text attachment restrictions, and IME-safe Enter handling.
- [x] Prevent forced scroll jumps when the reader has moved up the conversation.
- [x] Remove fake idle specialist/workflow activity and manufactured sidebar activity records.
- [x] Improve sidebar navigation hierarchy, remove unsupported live/encryption/count badges, and add Connections.
- [x] Add keyboard focus management and dialog semantics to the mobile navigation drawer.
- [x] Add adaptive humanoid presence driven by actual voice, camera, GIDEON, approval, and request states; preserve explicit mic/camera controls and reduced-motion styling.
- [x] Run the production build after the presence integration; record exact result below.
- [ ] Run lint/type check, unit tests, and verification suite; launchers/environment previously blocked.
- [ ] Inspect desktop and mobile rendering in a browser and address visible regressions (blocked: local dev server cannot start through the broken npm launcher).
- [ ] Review implemented feature routes for contrast, interaction labels, loading/error states, and reduced motion.

## Known boundaries

The holographic character is a lightweight SVG/CSS 2.5D illustration, not a real-time 3D model or video avatar. This pass does not create missing backend capabilities, change model/API contracts, add live-provider credentials, or claim Vercel deployment readiness. The renderer continues using the app's existing safe text/code formatter because no Markdown renderer dependency is installed. Live browser/device and screen-reader verification remains required before claiming full accessibility acceptance.

## Verification evidence

- `npm run build` — **PASS** on 2026-11-06 after the final voice-state corrections. Vite transformed 2,158 modules, generated PWA assets, and esbuild produced `server.js` (251.8 kB). Main JavaScript bundle: 1,889.55 kB minified / 487.46 kB gzip; Vite retains its >500 kB advisory based on minified size.
- `npm run lint`, `npm test`, `npm run test:suite` — **BLOCKED** before their scripts started: the global npm launcher attempts to load missing `C:\Users\USER\AppData\Roaming\npm\node_modules\npm\bin\npm-cli.js`.
- Direct project-local TypeScript, Vitest, and tsx entry points — **BLOCKED** by Node `EPERM` while resolving `C:\Users\USER`.
- `npm run dev -- --host 127.0.0.1` — **BLOCKED** by the same missing global npm launcher; browser visual QA could not be performed.
- The initial lint/test baseline was not captured before source edits; no baseline pass is claimed.
