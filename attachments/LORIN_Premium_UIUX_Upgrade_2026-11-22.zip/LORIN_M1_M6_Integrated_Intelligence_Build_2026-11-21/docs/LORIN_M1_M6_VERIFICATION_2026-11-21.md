# LORIN M1–M6 Verification Evidence — 21 November 2026

## Automated checks run in the current environment

| Check | Result | Command / method |
|---|---|---|
| Core integration/security tests | **24/24 PASS** | `npm run test:core` |
| Static security regressions | **38/38 PASS** | `npm run test:security:static` |
| TypeScript/TSX syntax parse | **120 files; 0 syntax diagnostics** | Global TypeScript 5.8.3 `transpileModule`; `.d.ts` files excluded; not semantic checking |
| Preflight | **2/6 PASS; exit blocked** | `node scripts/preflight.mjs` |

## Core test coverage

The 24 focused tests cover canonical JSON and action digests; strict capability schemas; deny-by-default policy; router handling of unknown provider metadata and local-only requests; voice activity thresholds; encrypted SQLite job persistence and audit integrity; exact one-time approval binding; execution-time principal, permission and session revalidation; continuous worker concurrency and stop behavior; crash lease behavior; owner-isolated encrypted knowledge indexing and restart/search/citation/deletion; bounded approved file creation and independent SHA-256 verification; retry limits; and Ollama NDJSON stream chunking, truncated response rejection, malformed packets, provider errors, output caps and final done packet behavior.

## Why the release build is not certified

Preflight reports:

- Node.js available: **22.16.0**; required by `package.json`: **>=24.12.0**.
- npm available: **10.9.2**; required: **10.9.2**.
- `package.json` root declarations are not aligned with `package-lock.json`: some direct dependencies are missing from the lock root, `esbuild`/`vite-plugin-pwa` are in inconsistent dependency sections, and some declared platform optionals are missing.
- `node_modules` is absent. The available environment has no package registry connectivity to install or reconcile dependencies.
- Built-in `node:sqlite` check passes.

Therefore semantic TypeScript checking, full Vitest, Vite build, esbuild server bundle and full app startup were not run successfully. Do not infer they pass from syntax-only transpilation.

## Live tests not run

- Gemini API key and upstream response tests.
- Ollama Cloud API key and upstream response tests.
- Local Ollama daemon `/api/tags` and `/api/generate` tests.
- Firebase Auth/Firestore Emulator and live project tests.
- Browser routes, SSE/stream cancellation, task API end-to-end.
- Microphone, STT/TTS, wake phrase, camera and snapshot tests on physical devices.
- Paired Android/desktop device lifecycle and revocation.
- Windows PowerShell scripts, ACLs, DPAPI, installer/uninstaller and offline startup.

## Required next verification gate

Run on a clean machine or CI runner with Node.js >=24.12.0 and npm 10.9.2, reconcile and review the lockfile, then run `npm ci`, semantic typecheck, all Vitest tests, production frontend/server build and server startup. Only then begin live provider/Firebase and physical-device acceptance. Keep every unrun item labelled NOT RUN until evidence exists.
