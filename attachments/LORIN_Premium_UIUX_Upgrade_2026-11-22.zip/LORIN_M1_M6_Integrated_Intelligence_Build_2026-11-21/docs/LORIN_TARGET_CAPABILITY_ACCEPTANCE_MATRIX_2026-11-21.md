# LORIN Target Capability Acceptance Matrix

**Release:** Integrated engineering continuation — 21 November 2026  
**Purpose:** Translate the user's finished-LORIN capability list into testable delivery criteria.  
**Status convention:** `PARTIAL` means some relevant source exists but end-to-end acceptance is incomplete. `FOUNDATION` means a secure building block exists but the user-facing capability is not delivered. `NOT VERIFIED` means source presence is not proof of live operation.

## Acceptance matrix

| Area | Intended finished experience | Current evidence in this source tree | Current status | Acceptance criteria still required |
|---|---|---|---|---|
| Intelligence | Understand, reason, research and solve problems | Gemini/Ollama adapters, offline knowledge service, specialist orchestration and a capability-based route-decision helper | PARTIAL | Wire the route-decision helper into real inference dispatch; test task selection, privacy, fallback, citations, timeouts, cancellation, provider attribution and error truthfulness with real providers |
| Conversation | Natural text and voice conversations | React conversation interface, conversation persistence service, streaming adapters, Web Speech/MediaRecorder, STT/TTS endpoints and new VAD callback in the microphone DSP path | PARTIAL | Prove end-to-end text, tap-to-talk, interruption, transcript assembly, TTS cleanup, offline voice, browser compatibility and failure recovery |
| Memory | Remember approved context with provenance | Account-scoped MemoryStore, approval states, Firebase sync and delete methods | PARTIAL | Complete provenance/version history, review/edit/export/delete lifecycle, conflict resolution, cross-device sync and security tests against real Firestore rules |
| Knowledge | Search and understand personal documents | Knowledge Vault components, document store, embedding/index endpoints and offline knowledge retrieval | PARTIAL | Validate every advertised parser, chunking, OCR where explicitly supported, keyword/vector/hybrid retrieval, source citations, ACLs, deletion propagation and large-file limits |
| Coding | Inspect, write, test and debug software | Project workspace, terminal/workbench UI, repository-related services and verification runner | PARTIAL | Add a real isolated workspace executor with explicit roots, no ambient shell privilege, command allowlists, resource/time limits, network policy, cancellation, diffs, test receipts and postcondition verification |
| Projects | Manage real projects and their histories | ProjectStore, project API, ProjectsWorkspace and GIDEON project history/decision endpoints | PARTIAL | Verify durable multi-device storage, project permissions, decision provenance, linked tasks, imported repository history and export/restore |
| Automation | Execute permitted actions with proper authorization | Sealed server-side capability registry, closed schemas, action digest, approvals, local SQLite persistence, one-shot worker and execution-time principal/permission/approval revalidation | FOUNDATION | Add long-running worker, durable retry/backoff, lease recovery, idempotency keys, progress events, job UI, cooperative cancellation and independent result verification |
| Devices | Control approved, paired devices | DeviceCenter, pairing/heartbeat/action routes, local primary-node architecture and existing allowlisted command policy | PARTIAL | Implement platform-specific pairing and revocation, per-device scopes, signed transport, replay protection, live Android/Windows device tests, command receipts and rollback-safe allowlisted actions |
| Vision | Understand provided images and supported live visual input | Snapshot vision flow, VideoVision view and backend multimodal inference paths | PARTIAL | Prove upload/snapshot handling, size/type limits, privacy routing, camera cleanup and accurate distinction between still-image analysis and genuine live-video sessions |
| Offline | Work locally without depending on cloud services | Ollama local adapter, offline knowledge service and local-node foundations | PARTIAL | Disconnect network and verify chat, documents, memory, project access, voice/STT/TTS and tasks; demonstrate no cloud requests; package/embed required assets and recover cleanly after restart |
| Online | Use approved cloud models when beneficial | Server-side Gemini and Ollama Cloud adapters, Firebase identity and CloudPrivacyGate | PARTIAL | Live authenticated inference/stream tests, quota/usage attribution, cancellation, provider outage handling, rate limits, secret rotation and explicit context-sharing consent tests |
| Continuity | Maintain verified history through GIDEON | GIDEON timeline, diagnostics, project history/decisions and correlation services | PARTIAL | Ensure every event has actor/source/time/evidence, prevent fabricated state, link to original records, support corrections/deletion policy and test chronology across restarts/devices |
| Privacy | Keep private information under your control | Firebase identity checks, role/permission enforcement, scoped Memory rules, local-only context gate, loopback-first listener, encrypted job payloads and action-bound approvals | PARTIAL | Complete threat model, secret storage, Windows ACL/DPAPI, cloud tenant isolation, full data lifecycle, backup encryption, penetration review and production rule/emulator tests |

## Work completed in this continuation

1. Added execution-time revalidation for queued jobs. A job is blocked if the owner UID no longer resolves to the same active server-managed principal, permissions have changed, a recorded session revocation occurred after job creation, the capability policy now denies the action, or the action's independent single-use approval cannot be validated in its consumed state. A worker called without a trusted principal resolver also fails closed.
2. Connected the adaptive `VoiceActivityDetector` to the existing `AudioService` microphone DSP callback. Detection is opt-in through a listener; it observes raw microphone frames only while the microphone is already explicitly started. It emits speech-start/end boundaries and does not start the microphone, run transcription, persist raw audio or transmit audio.
3. Added a dependency/runtime preflight script and npm command. It detects Node version mismatch, npm version mismatch, package manifest/lockfile drift, missing direct package-lock entries, absent `node_modules`, and `node:sqlite` availability.
4. Increased focused core tests from 9 to 12 and static security assertions from 34 to 36. Added execution-time permission-revocation, missing-principal-resolver and session-revocation regression coverage.

## Build/release gates still open

- Supported Node `>=24.12.0` and the declared npm version must be available.
- `package.json` and `package-lock.json` must be regenerated/reconciled online; do not use `npm ci` on the current inconsistent lock.
- Clean install, semantic TypeScript check, Vitest, Vite frontend build, bundled Express server build and runtime smoke test must all pass.
- Route-level tests are still needed for core jobs, auth, ownership, approval, cancellation and error responses.
- Firebase is deliberately unconfigured in this release because the inherited project target was not confirmed as LORIN-owned. Firebase Emulator/live rules, Gemini, Ollama Local/Cloud, browser microphone/camera, cross-device/offline behavior and Windows installation have not been accepted in this environment.
- A Windows installer, continuous worker, full executor library and independent postcondition verifier remain unbuilt.

## Exit criteria for calling LORIN production-ready

Do not call the application production-ready until every intended release capability has a named owner, an automated test or documented manual acceptance procedure, an evidence artifact, and an explicit `PASS`. `PARTIAL`, `FOUNDATION`, `NOT VERIFIED`, `BLOCKED`, and `NOT RUN` are not production acceptance states.
