# LORIN V2 deployment notes

## Current topology

- Frontend: Vite output in `dist`.
- Local API: Express app in `server.ts`; local dev runs `tsx server.ts` and production local start runs generated `server.js`.
- Vercel: `npm run build`, static output `dist`, `/api/*` rewritten to `api/index.ts`, other routes to `index.html`.
- Persistence/auth: Firebase Auth and Firestore; Vercel serverless API uses the Express export.
- Providers: Gemini and Ollama Cloud server-side adapters. No durable worker/queue is established by this audit.

## Environment

Set deployment secrets through the hosting provider's secret manager. Do not commit `.env` or put provider secrets in `VITE_*` variables.

- `GEMINI_API_KEY`: server-only Gemini credential.
- `OLLAMA_API_KEY`: server-only Ollama Cloud credential when enabled.
- `GEMINI_MODEL`, Ollama model settings: explicit configured model IDs.
- `OWNER_EMAIL`: optional server-side primary owner email; unset means no email-based primary owner. Owner bootstrap requires the real Firebase Auth UID (`OWNER_UID`) and must be run from a trusted administrator shell. Bind `OWNER_EMAIL` to `OWNER_UID` in production.
- `FIREBASE_PROJECT_ID`: server-side project identifier used for configuration checks. The current backend verifies Firebase ID tokens through Identity Toolkit; Admin SDK-backed revocation checks are not yet implemented.
- `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_APP_ID`: public Firebase client configuration only.
- `LORIN_NODE_STORAGE_KEY`: required high-entropy secret (at least 32 bytes) for production/serverless local-node payload encryption. Keep it in the host secret manager; never commit it. Local development provisions a per-install key outside the repository.
- `PORT`, `NODE_ENV`, `APP_URL`: server runtime settings; `PORT` is validated as an integer from 1 to 65535.
- `CORS_ALLOWED_ORIGINS`: comma-separated exact origins for deliberate cross-origin clients. Same-origin hosting needs no CORS entry; local development allows the localhost Vite/server origins.

The repository declares Node.js >=24.12. The current working environment used for this audit has Node.js 22.16 and could not reach the npm registry during dependency installation. Do not treat the deployment path as verified until a clean install on the supported Node version, build, API routing and authenticated smoke checks pass.

## Health and rollout

`/api/health` is a process/configuration report, not proof of provider inference. Run an authenticated request against each configured provider and confirm returned model attribution. Use a staging Firebase project and validate auth/rules before exposing the app. Current JSON snapshot policy, conversation and workspace state is stored in process-local maps and local JSON files (or `/tmp` on Vercel). This is not a durable, shared multi-instance database. Migrate those records to Firestore or another transactional cloud database before production multi-instance use. No deployment was made during this audit.
