# LORIN current build audit — 9 November 2026

## Executive assessment

**Release status: NOT READY.** This work session applied a focused security and privacy remediation tranche to the latest available source archive, `LORIN-main(2).zip` (uploaded 8 November 2026). It did not complete every LORIN roadmap phase and did not establish production readiness.

The working archive has 213 entries and 100 files under `src/`. The original ZIP passed `zipfile.testzip()` with no corrupt member. The source contains a React/Vite client, Express/TypeScript API, Firebase Auth/Firestore integrations, Gemini and Ollama adapters, local-node services, voice/vision components, knowledge and memory stores, specialist definitions, and MOSAIRA screens/routes.

## Changes made in this working copy

### Identity and session security

- Removed application-minted stateless HMAC `lorin_sess_` token creation and acceptance from `serverAuth.ts`.
- Changed `/api/auth/session` into a compatibility-only route that requires an active Firebase ID token and never creates a new app session.
- Removed the hard-coded owner-email fallback. An owner must be configured explicitly through the server-side owner configuration/registry and must authenticate with a Firebase account whose email is verified.
- Changed `isVerifiedOwner` to fail closed by default when the caller omits the email-verification result.
- Removed anonymous app-session bootstrap from the React client. Private API helpers now use only the currently authenticated Firebase user's ID token and clear the obsolete local token key.
- The client provisional principal is a least-privileged standard user while server role resolution is pending; 401/403 role lookup responses clear private state.
- The one-time owner bootstrap CLI now requires the real Firebase Authentication UID (`OWNER_UID`) as well as `OWNER_EMAIL`; it no longer generates a synthetic account UID.
- Unauthenticated `/api/auth/status` no longer receives owner-email information.

### Local-node cryptography and runtime configuration

- Removed machine-metadata-derived keys for new local-node encryption. Local development provisions a random 32-byte key outside the source tree with restrictive file permissions. Production/serverless operation fails closed unless `LORIN_NODE_STORAGE_KEY` is configured.
- A compatibility path can decrypt old local ciphertext only in non-production local environments and re-encrypts successfully loaded state under the new installation key. It is not used for new encryption and is disabled in production/serverless environments.
- `PORT` is parsed and validated as an integer in the range 1–65535.
- `.env.example`, README and deployment/security documents were updated to remove the obsolete HMAC-session guidance and describe production key provisioning.

### Memory and personal-data isolation

- Replaced the global browser memory key with per-Firebase-UID local namespaces.
- Guest state has no persistent memory writes. Account switches clear the in-memory collection before loading the next account's namespace.
- The old unscoped v1 memory key is quarantined as a legacy backup; it is not automatically assigned to whichever user signs in next because its historical owner cannot be proven.
- Removed fabricated seeded memories marked `CONFIRMED`; a new account starts empty.
- Memory records are validated for ID, domain, field lengths, tags, status and timestamps. Memory import is capped at 1,000 validated records.
- Remote memory synchronization now reads/writes user-scoped Firestore `memory_records`, with Firestore rules enforcing record owner, domain, content length and status constraints.
- A per-account local pending-operation queue retains upserts/deletes while offline and retries during later synchronization. Firestore wins for matching IDs unless the local record has a newer `updatedAt` timestamp.
- Suggestion rejection can only remove `PROPOSED` records. Owner-only bulk deletion requires a second confirmation and queues remote deletions.
- The actual owner email was removed from the static offline knowledge source and from synthetic verification fixture names.

### Source hygiene

- `.gitignore` now excludes `.lorin_session_secret`, owner/RBAC/policy/conversation/workspace runtime state, local SQLite/JSON state, `.gideon_data`, generated `server.js` and `.aistudio` workspace/session notes.
- The final working ZIP intentionally excludes private runtime state and credentials. It keeps only `.env.example` as an environment template.
- The Firebase web API key in `firebase-applet-config.json` is client configuration, not an Admin SDK private key. It remains part of the frontend configuration and must be protected with Firebase API restrictions, Authentication settings, App Check where appropriate, and correct Firestore/Storage rules.

## Feature and release status

Status meanings: **PATCHED** means a source change is present; **STATIC VERIFIED** means a focused source-level regression passed; neither implies an end-to-end integration test.

| Workstream | Current status | What remains before release |
|---|---|---|
| Full baseline/source audit | PARTIAL | Full runtime call-graph, dependency, UI and data-flow review still required. |
| Firebase authentication | PATCHED / STATIC VERIFIED | Test real ID-token validation, expiration, refresh, account disablement and revocation. Current backend uses Identity Toolkit lookup; Admin SDK revocation checks are not implemented. |
| Owner provisioning and RBAC | PARTIAL | Configure real `OWNER_EMAIL` and `OWNER_UID` in a trusted environment; verify persistent owner role records and Firestore privileged role bootstrap. |
| Stateless app session | PATCHED / STATIC VERIFIED | Full HTTP negative tests against a running server remain blocked. |
| Local-node encryption | PATCHED / STATIC VERIFIED | Test key rotation, backup/restore, legacy data migration and production secret provisioning with Node 24.12+. |
| Server port handling | PATCHED / STATIC VERIFIED | Runtime listen and health tests remain unrun. |
| Memory account isolation | PATCHED / STATIC VERIFIED | Browser auth lifecycle and cross-account Firestore emulator tests remain unrun. |
| Memory Firestore persistence | IMPLEMENTED IN SOURCE / NOT INTEGRATION VERIFIED | Test Firestore rules, online/offline queue replay, concurrent updates and cross-device delete conflicts. Browser local cache is UID-scoped but not application-layer encrypted. |
| Conversations/projects/tasks/vault API persistence | PARTIAL | Server snapshot stores use process-local maps and JSON files; Vercel paths target `/tmp`. They are not a durable shared multi-instance cloud database. Migrate remaining authoritative records to Firestore or another transactional store. |
| Knowledge Vault / document ingestion | PARTIAL | Validate actual PDF/Office extraction, indexing, retrieval quality, ACLs, prompt-injection treatment and offline use. |
| Gemini/Ollama inference | PARTIAL | Provider adapters exist, but no configured credentials, live inference, cancellation, streaming or model-attribution smoke test was performed here. |
| Voice and vision | PARTIAL | Components/services exist. Microphone lifecycle, speech quality, camera permissions, device support and any live-vision claim need real browser/device testing. |
| Six core specialist capabilities | CONFIGURED IN SOURCE | Verify orchestration behavior and evidence-based specialist outputs. The code also defines ten extended specialist profiles; the canonical public/private role of that extended roster remains a specification conflict and has not been silently removed. |
| GIDEON timeline intelligence | PARTIAL | Timeline persistence, event correlation and forecast accuracy need test data and multi-instance persistence. |
| Tools and device coordination | PARTIAL | Approved command registry exists; real enrolled device pairing, approval enforcement, audit persistence and revocation remain unverified. |
| UI/UX and responsive behavior | PARTIAL | The interface contains the relevant workspaces; full page-by-page visual, mobile, accessibility and reduced-motion QA was not run. |
| MOSAIRA/public-private separation | NOT VERIFIED | Public and private surfaces coexist in this repository. Route separation is not a sufficient trust boundary; separate identity, data, sessions, secrets and deployment boundaries must be tested before public release. |
| Production build | BLOCKED | The available Node runtime is v22.16.0; the package declares Node >=24.12.0. Dependency installation also failed on npm registry DNS resolution (`EAI_AGAIN`). |
| Full test suite/typecheck | BLOCKED | No complete `node_modules`; Vitest, `tsc --noEmit`, production Vite/esbuild build, Firebase emulator, browser/device QA and real provider tests were not run in this session. |
| Deployment | NOT RUN | No Vercel or other production deployment was attempted. |
| Final release packaging | NOT READY | This document accompanies a security-remediated working source package, not a production-complete final release. |

## Verification performed in this session

| Check | Result | Scope/limitation |
|---|---|---|
| Original ZIP integrity | PASS | No corrupt ZIP members. |
| Focused security regression script | PASS — 26/26 | Static source assertions for authentication, sessions, owner bootstrap, local-node key, port, memory sync/rules and runtime-file exclusions. Not an HTTP penetration test. |
| TypeScript syntax transpilation | PASS — 108/108 | Global TypeScript 5.8.3 transpile-only syntax pass; this is not a typecheck and does not resolve imports. |
| Full dependency install | BLOCKED | Offline install lacks cached `@babylonjs/core` registry metadata; online install timed out. Dependencies were not installed. |
| Node runtime requirement | BLOCKED | Runtime available here: v22.16.0; project declares >=24.12.0. |
| `npm run lint` / `tsc --noEmit` | BLOCKED | Attempted; TypeScript cannot resolve `vite-plugin-pwa/client` and `vite/client` because project dependencies are not installed. |
| `npm test` / Vitest | BLOCKED | Attempted; `vitest` executable is not installed. |
| `npm run build` | BLOCKED | Attempted; `vite` executable is not installed. |
| `npm run test:auth` | BLOCKED | Attempted; `tsx` executable is not installed. |
| Firebase Auth/Firestore emulator | NOT RUN | No emulator credentials/process available. |
| Gemini/Ollama live inference | NOT RUN | No provider credentials supplied to this session. |
| Browser, camera, microphone, accessibility and device QA | NOT RUN | No live browser/device session for this project. |
| Cloud deployment and multi-instance checks | NOT RUN | No LORIN repository/deployment connection exposed. |

## Known release blockers and next engineering tasks

1. Run a clean install using Node.js >=24.12 and npm 10.9.2 on a network that can reach the package registry; resolve all type, lint, test and build errors.
2. Add automated HTTP security tests for anonymous `/api/auth/session`, `/api/me`, inference, owner, policy, device and RBAC endpoints. Verify owner bootstrap is one-time and bound to a real Firebase UID.
3. Use Firebase Admin SDK or an equivalent trusted token verification mechanism for revocation-aware validation. Configure secrets only in a secret manager.
4. Move server policy, approval, audit, conversation, project, task, memory and vault state away from process-local maps/JSON/`/tmp` and into a shared transactional persistence layer. Define migrations and recover existing user state before rollout.
5. Run Firebase Emulator Suite tests against Firestore and Storage rules. Verify owner bootstrap and role records against the authoritative role collection.
6. Complete memory queue tests for offline create/update/delete, account switching, stale updates, remote deletes and multiple devices. Add conflict/tombstone semantics where needed.
7. Run real Gemini and Ollama inference and streaming with server-only credentials; prove provider identity and actual model attribution.
8. Test voice, vision, camera/microphone resource release, document parsers and offline functionality on supported devices.
9. Review every screen and route at phone/tablet/desktop sizes; perform keyboard, screen-reader, contrast and reduced-motion QA.
10. Establish a genuine public/private separation for MOSAIRA and LORIN before exposing public accounts or model APIs.
11. Produce the final ZIP only after all applicable release gates pass; include `.env.example` but exclude credentials, local keys, private user databases, owner registries, session secrets and generated build caches.

## Operational notes for the owner

- The recurring automation was disabled at the owner's request. No further scheduled work is configured.
- No private deployment credentials, Firebase Admin credentials or model-provider keys were supplied in this session.
- Do not deploy the working package as production without completing the blockers above.
- Existing runtime state was not deleted from the working extraction. It is excluded from the clean distributable ZIP; retain and back up the original archive/library copy for migration.


## 2026-11-09 continuation pass — authorization, diagnostics and provider honesty

The following additional source changes were made after the initial security/privacy tranche:

- Fixed the System Owner bootstrap route ordering. It no longer adds/promotes the requester in the owner registry before checking whether one-time bootstrap was refused. Registry promotion occurs only after a successful bootstrap result.
- `bootstrapOneTimeSystemOwner` now requires a real, non-empty Firebase UID. An idempotent bootstrap is accepted only when both the verified email and Firebase UID match the existing System Owner record; a different UID is refused and must use a controlled recovery/transfer path.
- The primary-node status and private-network status endpoints now require System Owner or Super Admin authorization. Standard authenticated accounts cannot retrieve host telemetry, Tailscale/LAN endpoints or primary-node diagnostics from those global routes.
- The system health matrix now redacts global account counts, system-owner counts, internal database identifiers, host telemetry, local Ollama endpoints/model inventories, private-network details and process-wide audit/approval counts for non-privileged accounts. Device counts remain scoped to the authenticated account.
- The anonymous MOSAIRA playground is bounded by a per-IP and per-process global rate limit (15 and 120 requests per minute respectively) with input-size/type validation. This limiter is best-effort per process; production multi-instance operation still requires a shared rate-limit store.
- Private conversation/memory/Vault context now stays out of cloud inference unless the user explicitly enables cloud-context transmission.
- Provider health surfaces distinguish credential presence/configuration from a verified upstream inference connection. A configured Gemini or Ollama credential is not represented as a successful live provider probe.
- Health-matrix entries for browser-only, voice, vision, storage deployment, Firestore connectivity and other unprobed services remain `NOT_VERIFIED` rather than being presented as healthy.
- Added regression assertions for bootstrap ordering, UID binding, privileged-only system diagnostics and standard-user health-matrix redaction. Added a Vitest regression case for missing and mismatched bootstrap UIDs.

Continuation-pass verification:

| Check | Result | Scope/limitation |
|---|---|---|
| `node scripts/security-regression-check.mjs` | PASS — 26/26 | Static source assertions only; not HTTP penetration/integration tests. |
| TypeScript syntax transpilation | PASS — 108/108 | Global TypeScript 5.8.3 transpile-only check for `.ts`/`.tsx`, excluding `.d.ts`; not a semantic typecheck. |
| Project JSON/config parse | PASS | Eight JSON configuration/manifest files parse successfully. |
| Dependency installation | BLOCKED | `npm ci --offline` cannot find the cached `@babylonjs/core` registry metadata; online `npm ci` timed out. |
| Node runtime | BLOCKED | Available Node is v22.16.0; project declares Node >=24.12.0. |
| `tsc --noEmit`, Vitest, Vite/esbuild production build | NOT RUN | Required dependencies are not installed and supported Node runtime is unavailable. |
| Firebase/Auth/Firestore, Gemini/Ollama, browser/camera/microphone, multi-instance and deployment QA | NOT RUN | Requires live credentials/services, supported devices and deployment access. |

The current deliverable remains a security-remediated working source package. It is not a complete or production-verified LORIN release. Do not deploy it as production until the remaining release blockers above are satisfied.


### Identity registry follow-up — 9 November 2026

- Owner email allowlisting no longer fabricates a synthetic managed-account UID. A person without an authenticated Firebase account remains an allowlist entry only; their managed account is created from the actual Firebase UID when they authenticate.
- Added optional `OWNER_UID` configuration to bind the primary `OWNER_EMAIL` to the designated Firebase UID. When set, role assignment verifies the UID.
- Firebase token verification now refuses to inherit an existing managed account's role through an email match when its stored UID differs from the Firebase token's `localId`. Account recreation or UID mismatch must use an explicit recovery/transfer procedure.
- `scripts/bootstrapSystemOwner.ts` now requires `OWNER_EMAIL` from the trusted server environment rather than accepting a CLI email override, and always requires `OWNER_UID`.
- Added a static regression check for UID mismatch rejection and removed synthetic UID creation. Static security regression now passes 26/26 assertions.

Existing runtime RBAC files may contain synthetic `usr_owner_*` records created by earlier builds. They are deliberately not auto-rebound. Back up the original runtime state and use a controlled owner-UID recovery/migration before deploying this source over an environment that has such records.
