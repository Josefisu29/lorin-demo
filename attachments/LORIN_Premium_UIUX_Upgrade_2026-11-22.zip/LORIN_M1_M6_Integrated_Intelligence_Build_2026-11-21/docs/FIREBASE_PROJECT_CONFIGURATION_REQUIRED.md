# Firebase Project Configuration Required Before Live Use

The inherited source configuration identified a Firebase project named `hospitalmanagtsystem` and a non-default Firestore database. The project identity was not confirmed as the user's LORIN production backend. This release therefore removes that inherited target and its embedded public web configuration rather than silently connecting to it.

## Configure the intended LORIN Firebase project

1. Create or identify the Firebase project that is explicitly intended for LORIN.
2. Confirm the Firebase project ID, Web App ID, Web API key, Auth domain, Storage bucket, Messaging Sender ID and Firestore database ID in the Firebase console.
3. Configure the `VITE_FIREBASE_*` values in the deployment environment before building the frontend. These values are Firebase web-app configuration; the Web API key is public configuration, not a server secret, and should still have appropriate API restrictions.
4. Configure `FIREBASE_PROJECT_ID` and `FIREBASE_FIRESTORE_DATABASE_ID` on the server. Do not put service-account JSON, private keys or Admin credentials in any `VITE_*` variable.
5. Set up Firebase Authentication providers, authorized domains, App Check, Firestore indexes, Firestore rules and Storage rules for that exact project.
6. Test Auth, UID isolation, account disable/revocation, App Check, Firestore reads/writes, Storage upload/download/delete and rules using the Firebase Emulator Suite first, then the intended staging project.
7. Never assume that copying a project ID or web config proves that rules are deployed or connectivity is secure.

## Current safe defaults in this source build

- `firebase-applet-config.json` contains explicit `SET_YOUR_*` placeholders, not the inherited project credentials.
- `firebase.json` targets the standard `(default)` database unless changed by the owner.
- `FIREBASE_FIRESTORE_DATABASE_ID` and `VITE_FIREBASE_FIRESTORE_DATABASE_ID` allow the owner to select a confirmed database ID.
- The Settings panel labels the Firebase project as `NOT CONFIGURED` and disables its database-ping button until real details are supplied.
- Server authentication fails closed with `FIREBASE_NOT_CONFIGURED` (HTTP 503), and public health reports Firebase/database as unconfigured until both project ID and API key are real values.
- Firebase live Auth/Firestore integration is intentionally not accepted or claimed as complete in this archive.

The build cannot safely connect to a live Firebase backend until the owner configures and verifies the intended LORIN project.
