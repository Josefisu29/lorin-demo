# LORIN — Next Release Completion Plan

**Baseline:** LORIN Enhanced Engineering Build, 21 November 2026  
**Target:** Integrated Personal Intelligence release candidate  
**Approach:** Stabilize the existing codebase and integrate current subsystems; do not replace LORIN with another starter or merge unrelated assistant identities.

## Workstream 0 — Reproducible build recovery (blocking)

1. Use Node `>=24.12.0` and npm `10.9.2` as declared.
2. Reconcile `package.json`, `package-lock.json`, and the retained `bun.lock`; choose one authoritative installer workflow and regenerate its lock on a network-enabled supported runtime.
3. Perform a clean dependency install with lifecycle scripts reviewed.
4. Run `npm run preflight`, `npm run test:security:static`, `npm run test:core`, semantic TypeScript checking, Vitest, the Vite build and Express server bundle.
5. Start the built server, test health/auth/core APIs and confirm that no private keys or environment files are included in the release package.
6. Fix every actionable compilation, lint, test and runtime failure before adding more large features.

**Exit:** Clean reproducible install; typecheck, automated tests and production build all pass; server smoke test passes.

## Workstream 1 — Identity and data foundations

1. Verify the correct Firebase project and Firestore database identity before enabling production traffic. The current source configuration must not be assumed to be the intended LORIN project without owner confirmation.
2. Test Firebase Authentication, UID-bound role resolution, account disable/revocation, App Check, Firestore rules and Storage rules using the Emulator Suite.
3. Inventory each current data store: conversations, Memory, Knowledge Vault, tasks, projects, GIDEON, local node, core jobs and MOSAIRA.
4. Define canonical owner/user/project IDs, schemas, provenance and deletion semantics before migration.
5. Build a migration/export/import tool with dry-run, backups, checksums and rollback; do not silently merge or delete existing records.
6. Keep LORIN private data and MOSAIRA public data in distinct authorization and storage boundaries.

**Exit:** Emulator tests pass, data inventory is complete, migration can be reversed, and cross-user isolation is demonstrated.

## Workstream 2 — Unified intelligence and provider dispatch

1. Adapt the core route-decision helper to real Gemini and Ollama provider candidates using measured, timestamped health probes.
2. Add explicit task/capability metadata for chat, research, code, vision, audio and long-context requests.
3. Make privacy mode explicit in each request; `LOCAL_ONLY` must never select a cloud provider. Cloud fallback requires the user's explicit setting and a visible notice.
4. Add one provider-dispatch boundary for both streaming and non-streaming requests.
5. Record actual provider/model, measured latency, request ID, failure, token usage and cost only when the upstream actually returns them.
6. Preserve honest provider failures. An offline knowledge response must be labeled as local retrieval/deterministic output, never as successful Gemini/Ollama inference.
7. Add rate limits, deadlines, cancellation and bounded retries with no duplicate side effects.

**Exit:** Real authenticated test calls pass for Gemini and Ollama; local-only and cloud-consent tests pass; fallback and failure labels are accurate.

## Workstream 3 — Memory, Vault, projects and GIDEON continuity

1. Establish canonical persistence interfaces with local-first adapters and a separately authorized cloud-sync adapter.
2. Store conversation, Memory, documents/chunks, projects/tasks and GIDEON events with stable IDs, timestamps, actor, source and provenance.
3. Add sync queues, conflict strategy, idempotent writes, tombstones and deletion propagation.
4. Make Memory reviewable, editable, exportable and deletable; keep proposals separate from confirmed memories.
5. Make Vault ingestion versioned and bounded; support only file types with a real tested parser; create citations with document/version/page or chunk references.
6. Add hybrid retrieval and verify citations against the exact stored source; remove chunks/embeddings when a source or its version is deleted.
7. Make GIDEON consume verified events and references rather than inventing events or reconstructing facts from unsupported narrative.

**Exit:** Import/restore, restart, cross-device sync, ACL, retrieval citation, data export and deletion tests pass.

## Workstream 4 — Trusted automation and engineering workspace

1. Create a continuously running local worker with durable leases, retries, dead-letter handling, idempotency and process restart recovery.
2. Add live cancellation with cooperative executor contract and explicit states for requested/confirmed cancellation.
3. Add capability categories gradually: read-only knowledge/project status first; then workspace file operations; then narrowly scoped repository operations.
4. Every file operation must resolve paths under an explicitly enrolled workspace root, reject symlink escapes, cap size, and use atomic writes/backups where appropriate.
5. Coding tools must run in an isolated process/container with CPU/memory/time limits, explicit network policy, no production credentials by default, command allowlists and captured logs/diffs.
6. Require approvals for effectful/high-impact actions, with exact parameter digests, expiry, one-time use and execution-time permission checks.
7. Add independent postcondition verifiers. Only the verifier can mark a job `VERIFIED`.
8. Add a task/job UI showing proposal, required access, exact target, approval status, progress, outcome, error and evidence.

**Exit:** Worker restart, duplicate submission, cancellation, approval expiry/replay, changed permissions, resource-scope escape, execution timeout and postcondition tests pass.

## Workstream 5 — Voice, vision and companion

1. Integrate VAD events with explicit tap-to-talk turn control and transcript lifecycle; the VAD itself must never grant microphone access.
2. Add adaptive noise floor, onset/pre-roll, hangover, max-duration and echo suppression tests on supported physical devices.
3. Complete STT/TTS selection with local/cloud privacy, streaming, interruption and resource cleanup.
4. Treat wake word as optional foreground/background platform-specific functionality; require consent, a visible indicator, battery controls and immediate stop.
5. Keep image upload/snapshot distinct from real-time video; add camera indicator, permission, cleanup and frame-rate limits.
6. Synchronize avatar expressions and lip movement with actual speech/playback state only.

**Exit:** Device/browser matrix passes on Windows and Android; iOS/browser limitations are documented; no hidden microphone/camera behavior exists.

## Workstream 6 — Windows local companion and offline release

1. Choose a supported desktop shell and IPC architecture after threat-model review.
2. Package the local Node runtime, React UI, SQLite migrations and local model connector.
3. Use Windows DPAPI/credential vault and restrictive ACLs; do not reuse plaintext local secrets.
4. Pair browser/mobile clients with the local host using short-lived enrollment codes and signed device credentials; revoke devices centrally.
5. Use loopback by default; any remote access must use authenticated TLS through a trusted private gateway.
6. Verify install, update, rollback, uninstall, data backup/restore, startup/shutdown and crash recovery on clean Windows machines.
7. Verify offline behavior with the network physically disabled; record which capabilities still require cloud services.

**Exit:** Signed or trusted installer is produced and tested; offline acceptance evidence is captured; no cloud requirement is hidden.

## Workstream 7 — Production, security and performance acceptance

1. Complete threat model and authorization matrix; perform abuse, prompt-injection, SSRF, path traversal, replay and tenant-isolation testing.
2. Validate rate limits, memory/resource caps, file uploads, event streams and concurrency.
3. Add observability that reports real measurements only; redact secrets and private content from logs.
4. Encrypt backups and test disaster recovery and key rotation.
5. Verify MOSAIRA isolation and its explicit approved-content ingestion route.
6. Benchmark route latency, tokens/cost, memory usage, local startup and common UI tasks against a recorded baseline. Do not claim multiplicative performance improvements without measured results.
7. Deploy to private staging, run acceptance, then production rollout with monitoring and rollback.

**Exit:** Each feature has PASS evidence, release owner approval and a tested rollback plan.

## Immediate next action

Complete Workstream 0 first. The current execution environment cannot fetch dependencies and uses Node 22.16.0, below the declared Node requirement. The preflight script documents this directly. Do not mark the production build, live providers, full offline experience or Windows companion as complete until those real checks have passed.
