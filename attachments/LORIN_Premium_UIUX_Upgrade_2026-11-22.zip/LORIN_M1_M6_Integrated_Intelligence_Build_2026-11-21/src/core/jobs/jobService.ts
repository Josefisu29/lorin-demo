import { createHash, randomUUID } from 'node:crypto';
import { closeSync, constants, fsyncSync, lstatSync, openSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { isAbsolute, join, relative, resolve, sep } from 'node:path';
import type { CapabilityContext, CapabilityRegistry } from '../capabilities/registry.ts';
import { validateCapabilityInput } from '../capabilities/registry.ts';
import { actionDigest, canonicalJson } from '../security/canonical.ts';
import { evaluateCapabilityPolicy, type PolicyContext, type PolicyPrincipal } from '../security/policy.ts';
import { LorinSqliteStore, type DurableApproval, type DurableJob } from '../persistence/sqliteStore.ts';

export interface JobPrincipal extends PolicyPrincipal {
  email?: string;
  /** A server-recorded revocation timestamp, when one exists. */
  sessionRevokedAt?: number;
}

export type JobPrincipalResolver = (uid: string) => JobPrincipal | null | Promise<JobPrincipal | null>;

function canonicalResultJson(value: unknown): string {
  return canonicalJson(value);
}

export interface JobCreateRequest {
  capabilityId: string;
  resource: string;
  parameters: unknown;
  approvalId?: string;
}

export class JobService {
  constructor(
    private readonly store: LorinSqliteStore,
    private readonly capabilities: CapabilityRegistry
  ) {}

  create(principal: JobPrincipal, request: JobCreateRequest, policyContext: PolicyContext): {
    job: DurableJob;
    approval?: DurableApproval;
    policy: ReturnType<typeof evaluateCapabilityPolicy>;
  } {
    if (!request || typeof request.resource !== 'string' || !request.resource.trim() || request.resource.length > 300) {
      throw new Error('JOB_RESOURCE_INVALID');
    }
    const capability = this.capabilities.get(request.capabilityId);
    if (!capability) throw new Error('CAPABILITY_NOT_FOUND');
    const validation = validateCapabilityInput(request.parameters, capability.inputSchema);
    if (validation.length) {
      const error = new Error('CAPABILITY_INPUT_INVALID');
      Object.assign(error, { issues: validation });
      throw error;
    }

    const policy = evaluateCapabilityPolicy(principal, capability, policyContext);
    if (!policy.allowed) {
      this.store.recordAudit({
        ownerUid: principal.id, actorUid: principal.id, action: 'capability.denied', resource: request.resource,
        decision: 'DENY', reason: policy.reasons.join(' '),
        metadata: { capabilityId: capability.id, policy }
      });
      throw new Error(`POLICY_DENIED:${policy.reasons.join(' ')}`);
    }

    const digest = actionDigest({
      principalId: principal.id,
      capabilityId: capability.id,
      resource: request.resource,
      parameters: request.parameters
    });

    if (policy.requiresApproval) {
      const created = this.store.createJobWithApproval({
        ownerUid: principal.id,
        capabilityId: capability.id,
        capabilityVersion: capability.version,
        resource: request.resource,
        parameters: request.parameters,
        actionDigest: digest
      });
      return { job: created.job, approval: created.approval, policy };
    }

    const job = this.store.createJob({
      ownerUid: principal.id,
      capabilityId: capability.id,
      capabilityVersion: capability.version,
      resource: request.resource,
      parameters: request.parameters,
      actionDigest: digest,
      state: capability.execute ? 'QUEUED' : 'BLOCKED'
    });
    return { job, policy };

  }

  approve(jobId: string, approvalId: string, approver: JobPrincipal): DurableJob {
    if (!['SYSTEM_OWNER', 'SUPER_ADMIN'].includes(approver.canonicalRole)) throw new Error('APPROVER_ROLE_REQUIRED');
    const job = this.store.getJob(jobId);
    if (!job) throw new Error('JOB_NOT_FOUND');
    if (job.state !== 'AWAITING_APPROVAL') throw new Error('JOB_NOT_AWAITING_APPROVAL');
    if (approver.id === job.ownerUid) throw new Error('INDEPENDENT_APPROVER_REQUIRED');
    const approval = this.store.getApproval(approvalId, job.ownerUid);
    if (!approval || approval.status !== 'PENDING') throw new Error('APPROVAL_NOT_PENDING');
    if (approval.capabilityId !== job.capabilityId || approval.resource !== job.resource || approval.actionDigest !== job.actionDigest) {
      throw new Error('APPROVAL_BINDING_MISMATCH');
    }
    const expectedDigest = actionDigest({
      principalId: job.ownerUid,
      capabilityId: job.capabilityId,
      resource: job.resource,
      parameters: job.parameters
    });
    if (approval.actionDigest !== expectedDigest) throw new Error('APPROVAL_PARAMETER_DIGEST_MISMATCH');
    return this.store.approveJobWithApproval(jobId, approvalId, approver.id);
  }

  async runOne(
    workerId: string,
    source: CapabilityContext['source'] = 'LOCAL_NODE',
    resolvePrincipal?: JobPrincipalResolver
  ): Promise<DurableJob | undefined> {
    const job = this.store.claimNextJob(workerId);
    if (!job) return undefined;
    const leaseHeartbeat = setInterval(() => {
      try { this.store.renewJobLease(job.id, workerId, 180_000); } catch { /* lease expiry blocks rather than replays */ }
    }, 30_000);
    leaseHeartbeat.unref?.();

    try {
    // Re-authorize against the latest server-owned account state immediately
    // before invoking the executor. Missing resolver means fail closed.
    let currentPrincipal: JobPrincipal | null = null;
    try {
      currentPrincipal = resolvePrincipal ? await resolvePrincipal(job.ownerUid) : null;
    } catch {
      currentPrincipal = null;
    }
    if (!currentPrincipal || currentPrincipal.id !== job.ownerUid || !currentPrincipal.authenticated ||
        !['ACTIVE', 'ENABLED'].includes(currentPrincipal.accountStatus)) {
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'BLOCKED', actorUid: workerId,
        errorCode: 'PRINCIPAL_REVALIDATION_FAILED',
        reason: 'The current server-managed account could not be revalidated; execution was denied.'
      });
    }
    if (typeof currentPrincipal.sessionRevokedAt === 'number' && currentPrincipal.sessionRevokedAt > job.createdAt) {
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'BLOCKED', actorUid: workerId,
        errorCode: 'SESSION_REVOKED_AFTER_JOB_CREATION',
        reason: 'The owner session was revoked after this job was created; a new action must be submitted.'
      });
    }

    const expectedDigest = actionDigest({
      principalId: job.ownerUid,
      capabilityId: job.capabilityId,
      resource: job.resource,
      parameters: job.parameters
    });
    if (!job.actionDigest || expectedDigest !== job.actionDigest) {
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'BLOCKED', actorUid: workerId,
        errorCode: 'ACTION_DIGEST_MISMATCH', reason: 'Encrypted job payload no longer matches its original action digest.'
      });
    }
    const capability = this.capabilities.get(job.capabilityId);
    if (!capability || !capability.enabled || !capability.execute || capability.version !== job.capabilityVersion) {
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'BLOCKED', actorUid: workerId,
        errorCode: 'CAPABILITY_UNAVAILABLE', reason: 'The pinned capability version or trusted executor is unavailable.'
      });
    }

    const policy = evaluateCapabilityPolicy(currentPrincipal, capability, {
      executionLocation: source === 'LOCAL_NODE' || source === 'SCHEDULED' ? 'LOCAL' : 'CLOUD',
      resourceOwnerId: job.ownerUid
    });
    if (!policy.allowed) {
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'BLOCKED', actorUid: workerId,
        errorCode: 'EXECUTION_POLICY_REVALIDATION_FAILED',
        reason: `Execution-time policy revalidation denied the job: ${policy.reasons.join(' ')}`
      });
    }
    if (policy.requiresApproval) {
      const approval = job.approvalId ? this.store.getApproval(job.approvalId, job.ownerUid) : undefined;
      if (!approval || approval.status !== 'CONSUMED' || !approval.approvedBy ||
          approval.approvedBy === job.ownerUid || approval.actionDigest !== job.actionDigest ||
          approval.capabilityId !== job.capabilityId || approval.resource !== job.resource ||
          !approval.consumedAt) {
        return this.store.transitionJob({
          jobId: job.id, workerId, nextState: 'BLOCKED', actorUid: workerId,
          errorCode: 'EXECUTION_APPROVAL_REVALIDATION_FAILED',
          reason: 'The required independent, single-use approval could not be revalidated at execution time.'
        });
      }
    }

    const startedAt = Date.now();
    try {
      const result = await this.capabilities.invoke(job.capabilityId, job.parameters, {
        principalId: job.ownerUid,
        requestId: randomUUID(),
        source,
        locale: 'en'
      });
      const finishedAt = Date.now();
      const receiptResultJson = canonicalResultJson(result);
      if (Buffer.byteLength(receiptResultJson, 'utf8') > 256 * 1024) throw new Error('CAPABILITY_RECEIPT_TOO_LARGE');
      const receipt = {
        receiptVersion: 1,
        jobId: job.id,
        capabilityId: capability.id,
        capabilityVersion: capability.version,
        workerId,
        startedAt,
        finishedAt,
        durationMs: finishedAt - startedAt,
        result
      };
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'COMPLETED', actorUid: workerId,
        receipt, reason: 'Registered server-side capability returned successfully; completion recorded, not independently verified.'
      });
    } catch (error: any) {
      const candidate = typeof error?.message === 'string' ? error.message : '';
      const code = /^[A-Z0-9_:-]{1,80}$/.test(candidate) ? candidate : 'CAPABILITY_EXECUTION_FAILED';
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'FAILED', actorUid: workerId,
        errorCode: code, reason: 'Registered capability failed; no success claim was recorded.'
      });
    }
    } finally {
      clearInterval(leaseHeartbeat);
    }
  }

  retry(jobId: string, principal: JobPrincipal): DurableJob {
    if (!principal.authenticated || !['ACTIVE', 'ENABLED'].includes(principal.accountStatus)) throw new Error('PRINCIPAL_REVALIDATION_FAILED');
    return this.store.retryJob(jobId, principal.id, 3);
  }

  async verifyCompleted(jobId: string, requesterUid: string, resolvePrincipal: JobPrincipalResolver): Promise<DurableJob> {
    const job = this.store.getJob(jobId);
    if (!job) throw new Error('JOB_NOT_FOUND');
    if (job.ownerUid !== requesterUid) throw new Error('JOB_NOT_FOUND');
    if (job.state !== 'COMPLETED') throw new Error('JOB_NOT_AWAITING_VERIFICATION');
    const principal = await resolvePrincipal(job.ownerUid);
    if (!principal || principal.id !== job.ownerUid || !principal.authenticated || !['ACTIVE', 'ENABLED'].includes(principal.accountStatus)) {
      throw new Error('PRINCIPAL_REVALIDATION_FAILED');
    }
    if (typeof principal.sessionRevokedAt === 'number' && principal.sessionRevokedAt > job.createdAt) {
      throw new Error('SESSION_REVOKED_AFTER_JOB_CREATION');
    }
    const capability = this.capabilities.get(job.capabilityId);
    if (!capability?.verify) throw new Error('CAPABILITY_VERIFIER_NOT_INSTALLED');
    const receipt = job.receipt as any;
    if (!receipt || receipt.capabilityId !== job.capabilityId || receipt.jobId !== job.id || !Object.hasOwn(receipt, 'result')) {
      throw new Error('JOB_EXECUTION_RECEIPT_INVALID');
    }
    const verdict = await this.capabilities.verify(job.capabilityId, job.parameters, receipt.result, {
      principalId: principal.id, requestId: randomUUID(), source: 'LOCAL_NODE', locale: 'en'
    });
    if (!verdict.verified) throw new Error('POSTCONDITION_NOT_VERIFIED');
    return this.store.markJobVerified(job.id, job.ownerUid, `verifier:${job.capabilityId}`, {
      verified: true, evidence: verdict.evidence, checkedAt: Date.now()
    });
  }

  cancel(jobId: string, principal: JobPrincipal): DurableJob {
    return this.store.cancelJob(jobId, principal.id);
  }
}

function resolveSafeWorkspaceFile(relativePath: string, allowMissingFinal = false): { root: string; target: string } {
  const configuredRoot = process.env.LORIN_WORKSPACE_ROOT?.trim();
  if (!configuredRoot) throw new Error('WORKSPACE_ROOT_NOT_CONFIGURED');
  if (!relativePath || relativePath.length > 500 || relativePath.includes('\0') || isAbsolute(relativePath)) throw new Error('WORKSPACE_PATH_INVALID');
  const segments = relativePath.replace(/\\/g, '/').split('/');
  if (segments.some(segment => !segment || segment === '.' || segment === '..' || segment.includes(':'))) throw new Error('WORKSPACE_PATH_INVALID');
  const root = realpathSync(resolve(configuredRoot));
  const target = resolve(root, ...segments);
  const rel = relative(root, target);
  if (!rel || rel.startsWith(`..${sep}`) || rel === '..' || isAbsolute(rel)) throw new Error('WORKSPACE_PATH_OUTSIDE_ROOT');
  let current = root;
  for (let i = 0; i < segments.length; i++) {
    current = join(current, segments[i]);
    try {
      const stat = lstatSync(current);
      if (stat.isSymbolicLink()) throw new Error('WORKSPACE_SYMLINK_REJECTED');
      if (i < segments.length - 1 && !stat.isDirectory()) throw new Error('WORKSPACE_PARENT_NOT_DIRECTORY');
      if (i === segments.length - 1 && !stat.isFile()) throw new Error('WORKSPACE_TARGET_NOT_FILE');
    } catch (error: any) {
      if (error?.code === 'ENOENT' && allowMissingFinal && i === segments.length - 1) break;
      if (error?.code === 'ENOENT') throw new Error('WORKSPACE_PATH_NOT_FOUND');
      throw error;
    }
  }
  return { root, target };
}

export function createBuiltinCapabilities(registry: CapabilityRegistry): CapabilityRegistry {
  registry.register({
    id: 'lorin.system.health.read',
    version: 1,
    title: 'Read local runtime health',
    description: 'Returns real, non-sensitive runtime process measurements from the local worker.',
    category: 'SYSTEM',
    risk: 'READ',
    requiredPermissions: ['providers.read'],
    inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    timeoutMs: 2_000,
    localOnly: true,
    enabled: true,
    execute: (_input, context) => {
      if (context.signal.aborted) throw new Error('CAPABILITY_CANCELLED');
      const memory = process.memoryUsage();
      return {
        capturedAt: new Date().toISOString(),
        runtime: process.release.name,
        nodeVersion: process.version,
        platform: process.platform,
        architecture: process.arch,
        uptimeSeconds: Math.floor(process.uptime()),
        memory: { rssBytes: memory.rss, heapUsedBytes: memory.heapUsed, heapTotalBytes: memory.heapTotal }
      };
    }
  });
  registry.register({
    id: 'lorin.time.read',
    version: 1,
    title: 'Read current local-node time',
    description: 'Returns the local host clock timestamp and timezone offset.',
    category: 'SYSTEM',
    risk: 'READ',
    requiredPermissions: ['providers.read'],
    inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    timeoutMs: 1_000,
    localOnly: true,
    enabled: true,
    execute: (_input, context) => {
      if (context.signal.aborted) throw new Error('CAPABILITY_CANCELLED');
      const now = new Date();
      return { iso: now.toISOString(), local: now.toString(), offsetMinutes: -now.getTimezoneOffset() };
    }
  });
  registry.register({
    id: 'lorin.workspace.file.read', version: 1,
    title: 'Read a file in the approved workspace',
    description: 'Reads a bounded regular file beneath LORIN_WORKSPACE_ROOT. Symlinks and path traversal are rejected.',
    category: 'FILE', risk: 'READ', requiredPermissions: ['knowledge.read'],
    inputSchema: { type: 'object', properties: { path: { type: 'string', minLength: 1, maxLength: 500 } }, required: ['path'], additionalProperties: false },
    timeoutMs: 5_000, localOnly: true, enabled: true,
    execute: (input: { path: string }, context) => {
      if (context.signal.aborted) throw new Error('CAPABILITY_CANCELLED');
      const { target } = resolveSafeWorkspaceFile(input.path, false);
      const stat = lstatSync(target);
      if (stat.size > 64 * 1024) throw new Error('WORKSPACE_FILE_TOO_LARGE');
      const content = readFileSync(target, 'utf8');
      return { path: input.path, bytes: Buffer.byteLength(content, 'utf8'), content };
    }
  });
  registry.register({
    id: 'lorin.workspace.file.create', version: 1,
    title: 'Create a new file in the approved workspace',
    description: 'Creates a new file only; never overwrites. Requires independent approval and postcondition verification.',
    category: 'FILE', risk: 'MODERATE', requiredPermissions: ['knowledge.manage'],
    inputSchema: { type: 'object', properties: {
      path: { type: 'string', minLength: 1, maxLength: 500 },
      content: { type: 'string', maxLength: 32_000 }
    }, required: ['path', 'content'], additionalProperties: false },
    timeoutMs: 5_000, localOnly: true, enabled: process.platform !== 'win32' || typeof (constants as any).O_NOFOLLOW === 'number', requiresApproval: true,
    execute: (input: { path: string; content: string }, context) => {
      if (context.signal.aborted) throw new Error('CAPABILITY_CANCELLED');
      const { root, target } = resolveSafeWorkspaceFile(input.path, true);
      const contentBytes = Buffer.from(input.content, 'utf8');
      if (contentBytes.length > 32 * 1024) throw new Error('WORKSPACE_FILE_TOO_LARGE');
      const noFollow = (constants as any).O_NOFOLLOW || 0;
      const fd = openSync(target, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | noFollow, 0o600);
      try {
        writeFileSync(fd, contentBytes);
        fsyncSync(fd);
      } finally {
        closeSync(fd);
      }
      const canonicalTarget = realpathSync(target);
      const rel = relative(root, canonicalTarget);
      if (!rel || rel.startsWith(`..${sep}`) || rel === '..' || isAbsolute(rel)) throw new Error('WORKSPACE_PATH_OUTSIDE_ROOT');
      const digest = createHash('sha256').update(contentBytes).digest('hex');
      return { path: input.path, created: true, bytes: contentBytes.length, sha256: digest };
    },
    verify: (input: { path: string; content: string }, result: any) => {
      const { target } = resolveSafeWorkspaceFile(input.path, false);
      const actual = readFileSync(target);
      const expected = Buffer.from(input.content, 'utf8');
      const actualHash = createHash('sha256').update(actual).digest('hex');
      const expectedHash = createHash('sha256').update(expected).digest('hex');
      const verified = actualHash === expectedHash && result?.created === true && result?.sha256 === expectedHash && actual.length === expected.length;
      return { verified, evidence: verified
        ? `Re-opened ${input.path}; byte length (${actual.length}) and SHA-256 matched the requested content.`
        : `Postcondition mismatch for ${input.path}; the file bytes did not match the requested content.` };
    }
  });
  registry.seal();
  return registry;
}
