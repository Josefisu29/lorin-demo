import { randomUUID } from 'node:crypto';
import type { JobPrincipalResolver, JobService } from './jobService.ts';

export interface WorkerSnapshot {
  enabled: boolean;
  running: boolean;
  workerId?: string;
  startedAt?: number;
  lastPollAt?: number;
  lastJobAt?: number;
  processedCount: number;
  lastErrorCode?: string;
}

/**
 * Opt-in single-concurrency local worker. It never starts itself: the owner must
 * start it through the authenticated control endpoint and the host must set
 * LORIN_ENABLE_CORE_WORKER=true. Stopping prevents another claim; an in-flight
 * capability is bounded by that capability's own execution timeout.
 */
export class ContinuousJobWorker {
  private active = false;
  private timer: ReturnType<typeof setTimeout> | undefined;
  private workerId = '';
  private startedAt?: number;
  private lastPollAt?: number;
  private lastJobAt?: number;
  private processedCount = 0;
  private lastErrorCode?: string;
  private inFlight = false;

  constructor(
    private readonly jobs: JobService,
    private readonly resolvePrincipal: JobPrincipalResolver,
    private readonly pollIntervalMs = 1_500
  ) {
    if (!Number.isInteger(pollIntervalMs) || pollIntervalMs < 500 || pollIntervalMs > 30_000) {
      throw new RangeError('Worker poll interval must be between 500ms and 30000ms.');
    }
  }

  start(): WorkerSnapshot {
    if (this.active) return this.snapshot();
    this.active = true;
    this.workerId = `local-worker:${process.pid}:${randomUUID()}`;
    this.startedAt = Date.now();
    this.lastErrorCode = undefined;
    void this.poll();
    return this.snapshot();
  }

  stop(): WorkerSnapshot {
    this.active = false;
    if (this.timer) clearTimeout(this.timer);
    this.timer = undefined;
    return this.snapshot();
  }

  snapshot(): WorkerSnapshot {
    return {
      enabled: process.env.LORIN_ENABLE_CORE_WORKER === 'true',
      running: this.active,
      workerId: this.workerId || undefined,
      startedAt: this.startedAt,
      lastPollAt: this.lastPollAt,
      lastJobAt: this.lastJobAt,
      processedCount: this.processedCount,
      lastErrorCode: this.lastErrorCode
    };
  }

  private async poll(): Promise<void> {
    if (!this.active || this.inFlight) return;
    this.inFlight = true;
    this.lastPollAt = Date.now();
    try {
      const job = await this.jobs.runOne(this.workerId, 'LOCAL_NODE', this.resolvePrincipal);
      if (job) {
        this.processedCount += 1;
        this.lastJobAt = Date.now();
      }
      this.lastErrorCode = undefined;
    } catch (error: any) {
      const message = typeof error?.message === 'string' ? error.message : '';
      this.lastErrorCode = /^[A-Z0-9_:-]{1,80}$/.test(message) ? message : 'WORKER_POLL_FAILED';
    } finally {
      this.inFlight = false;
      if (this.active) this.timer = setTimeout(() => void this.poll(), this.pollIntervalMs);
    }
  }
}
