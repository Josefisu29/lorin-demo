export interface VoiceActivityConfig {
  noiseFloorDbfs: number;
  speechMarginDb: number;
  hangoverMs: number;
  onsetMs: number;
  preRollMs: number;
  maxSegmentMs: number;
  minSpeechMs: number;
  adaptRate: number;
}

export interface VoiceFrameResult {
  active: boolean;
  started: boolean;
  ended: boolean;
  levelDbfs: number;
  thresholdDbfs: number;
  segmentDurationMs: number;
  reason?: 'SILENCE' | 'MAX_DURATION' | 'STOPPED' | 'TOO_SHORT';
  preRollFrames?: Float32Array[];
}

const DEFAULTS: VoiceActivityConfig = {
  noiseFloorDbfs: -58,
  speechMarginDb: 10,
  hangoverMs: 420,
  onsetMs: 80,
  preRollMs: 160,
  maxSegmentMs: 18_000,
  minSpeechMs: 120,
  adaptRate: 0.025
};

function rmsDbfs(samples: Float32Array): number {
  if (!samples.length || samples.length > 8_192) throw new RangeError('Audio frame must contain between 1 and 8192 samples.');
  let sum = 0;
  for (let i = 0; i < samples.length; i++) {
    if (!Number.isFinite(samples[i])) throw new TypeError('Audio frame contains a non-finite sample.');
    sum += samples[i] * samples[i];
  }
  const rms = Math.sqrt(sum / samples.length);
  return rms > 1e-7 ? 20 * Math.log10(rms) : -96;
}

/** Frame-based VAD with adaptive floor, onset hysteresis, pre-roll and hangover. */
export class VoiceActivityDetector {
  private readonly config: VoiceActivityConfig;
  private noiseFloor: number;
  private active = false;
  private onsetMs = 0;
  private silenceMs = 0;
  private speechMs = 0;
  private segmentMs = 0;
  private preRoll: Float32Array[] = [];

  constructor(config: Partial<VoiceActivityConfig> = {}) {
    this.config = { ...DEFAULTS, ...config };
    const numericSettings = Object.values(this.config);
    if (numericSettings.some(value => !Number.isFinite(value)) ||
        this.config.noiseFloorDbfs < -96 || this.config.noiseFloorDbfs > -12 ||
        this.config.speechMarginDb < 3 || this.config.speechMarginDb > 40 ||
        this.config.hangoverMs < 0 || this.config.hangoverMs > 2_000 ||
        this.config.onsetMs < 0 || this.config.onsetMs > 1_000 ||
        this.config.preRollMs < 0 || this.config.preRollMs > 1_000 ||
        this.config.maxSegmentMs < 500 || this.config.maxSegmentMs > 120_000 ||
        this.config.minSpeechMs < 0 || this.config.minSpeechMs > this.config.maxSegmentMs ||
        this.config.adaptRate <= 0 || this.config.adaptRate > 1) {
      throw new RangeError('Invalid voice activity detector configuration.');
    }
    this.noiseFloor = this.config.noiseFloorDbfs;
  }

  get isActive(): boolean { return this.active; }
  get currentNoiseFloorDbfs(): number { return this.noiseFloor; }

  processFrame(samples: Float32Array, frameDurationMs: number): VoiceFrameResult {
    if (!(frameDurationMs > 0) || !Number.isFinite(frameDurationMs)) throw new RangeError('Frame duration must be positive.');
    const level = rmsDbfs(samples);
    const threshold = Math.max(-75, Math.min(-22, this.noiseFloor + this.config.speechMarginDb));
    const speechLike = level >= threshold;
    let started = false;
    let ended = false;
    let reason: VoiceFrameResult['reason'];
    let preRollFrames: Float32Array[] | undefined;
    let endedSegmentDurationMs: number | undefined;

    if (!this.active) {
      if (speechLike) {
        this.onsetMs += frameDurationMs;
      } else {
        this.onsetMs = 0;
        // Only adapt while below the speech threshold; loud transient speech should not raise the floor.
        this.noiseFloor += (level - this.noiseFloor) * this.config.adaptRate;
      }
      // Include quiet context and the onset frames so the beginning of a spoken word is not clipped.
      this.preRoll.push(samples.slice());
      const maxFrames = Math.max(1, Math.ceil(this.config.preRollMs / frameDurationMs));
      while (this.preRoll.length > maxFrames) this.preRoll.shift();
      if (speechLike && this.onsetMs >= this.config.onsetMs) {
        this.active = true;
        started = true;
        this.speechMs = this.onsetMs;
        this.segmentMs = this.onsetMs;
        this.silenceMs = 0;
        preRollFrames = this.preRoll.map(frame => frame.slice());
        this.preRoll = [];
      }
    } else {
      this.segmentMs += frameDurationMs;
      if (speechLike) {
        this.speechMs += frameDurationMs;
        this.silenceMs = 0;
      } else {
        this.silenceMs += frameDurationMs;
      }
      if (this.segmentMs >= this.config.maxSegmentMs) {
        ended = true;
        reason = 'MAX_DURATION';
      } else if (this.silenceMs >= this.config.hangoverMs) {
        ended = true;
        reason = this.speechMs >= this.config.minSpeechMs ? 'SILENCE' : 'TOO_SHORT';
      }
      if (ended) {
        endedSegmentDurationMs = this.segmentMs;
        this.active = false;
        this.onsetMs = 0;
        this.silenceMs = 0;
        this.speechMs = 0;
        this.segmentMs = 0;
        this.preRoll = [];
      }
    }

    return {
      active: this.active, started, ended, levelDbfs: level, thresholdDbfs: threshold,
      segmentDurationMs: endedSegmentDurationMs ?? this.segmentMs, reason, preRollFrames
    };
  }

  reset(): void {
    this.active = false;
    this.onsetMs = 0;
    this.silenceMs = 0;
    this.speechMs = 0;
    this.segmentMs = 0;
    this.preRoll = [];
  }
}
