export interface OllamaNdjsonResult {
  success: boolean;
  text?: string;
  modelUsed?: string;
  error?: string;
}

export interface OllamaNdjsonOptions {
  maxOutputCharacters?: number;
  signal?: AbortSignal;
}

/**
 * Consume Ollama's newline-delimited /api/generate stream.
 * A response is successful only after an explicit { done: true } packet.
 * Partial output is returned only through onChunk, never as a successful result.
 */
export async function consumeOllamaNdjsonStream(
  body: ReadableStream<Uint8Array>,
  initialModel: string,
  onChunk: (accumulatedText: string) => void,
  options: OllamaNdjsonOptions = {}
): Promise<OllamaNdjsonResult> {
  const maxOutputCharacters = options.maxOutputCharacters ?? 500_000;
  if (!Number.isSafeInteger(maxOutputCharacters) || maxOutputCharacters < 1) {
    return { success: false, modelUsed: initialModel, error: 'LOCAL_OLLAMA_OUTPUT_LIMIT_INVALID' };
  }

  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let accumulated = '';
  let actualModel = initialModel;
  let donePacketSeen = false;
  let shouldCancel = false;

  const processLine = (line: string): string | null => {
    if (!line.trim()) return null;
    let packet: any;
    try { packet = JSON.parse(line); }
    catch { return 'LOCAL_OLLAMA_INVALID_STREAM_PACKET'; }
    if (!packet || typeof packet !== 'object' || Array.isArray(packet)) {
      return 'LOCAL_OLLAMA_INVALID_STREAM_PACKET';
    }
    if (typeof packet.error === 'string' && packet.error) {
      return packet.error.slice(0, 500);
    }
    if (typeof packet.model === 'string' && packet.model.trim()) actualModel = packet.model.slice(0, 200);
    if (typeof packet.response === 'string' && packet.response) {
      accumulated += packet.response;
      if (accumulated.length > maxOutputCharacters) return 'LOCAL_OLLAMA_OUTPUT_LIMIT_EXCEEDED';
      onChunk(accumulated);
    }
    if (packet.done === true) donePacketSeen = true;
    return null;
  };

  try {
    while (true) {
      if (options.signal?.aborted) {
        shouldCancel = true;
        return { success: false, modelUsed: actualModel, error: 'LOCAL_OLLAMA_REQUEST_ABORTED' };
      }
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';
      for (const line of lines) {
        const error = processLine(line);
        if (error) {
          shouldCancel = true;
          return { success: false, modelUsed: actualModel, error };
        }
        if (donePacketSeen) {
          return accumulated
            ? { success: true, text: accumulated, modelUsed: actualModel }
            : { success: false, modelUsed: actualModel, error: 'LOCAL_OLLAMA_EMPTY_RESPONSE' };
        }
      }
    }

    buffer += decoder.decode();
    if (buffer.trim()) {
      const error = processLine(buffer);
      if (error) return { success: false, modelUsed: actualModel, error };
    }

    if (!donePacketSeen) {
      return { success: false, modelUsed: actualModel, error: 'LOCAL_OLLAMA_STREAM_INCOMPLETE' };
    }
    return accumulated
      ? { success: true, text: accumulated, modelUsed: actualModel }
      : { success: false, modelUsed: actualModel, error: 'LOCAL_OLLAMA_EMPTY_RESPONSE' };
  } catch (error: any) {
    shouldCancel = true;
    return {
      success: false,
      modelUsed: actualModel,
      error: error?.name === 'AbortError' ? 'LOCAL_OLLAMA_REQUEST_ABORTED' : 'LOCAL_OLLAMA_STREAM_READ_FAILED'
    };
  } finally {
    if (shouldCancel) {
      try { await reader.cancel(); } catch { /* stream may already be closed */ }
    }
    try { reader.releaseLock(); } catch { /* reader may already be released */ }
  }
}
