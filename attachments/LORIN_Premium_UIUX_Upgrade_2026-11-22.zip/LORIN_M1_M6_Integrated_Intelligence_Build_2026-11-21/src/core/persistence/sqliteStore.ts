import { createHmac, randomBytes, randomUUID, createCipheriv, createDecipheriv } from 'node:crypto';
import { chmodSync, existsSync, lstatSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { canonicalJson, sha256Hex } from '../security/canonical.ts';

export type DurableJobState =
  | 'AWAITING_APPROVAL'
  | 'QUEUED'
  | 'RUNNING'
  | 'BLOCKED'
  | 'FAILED'
  | 'CANCELLED'
  | 'COMPLETED'
  | 'VERIFIED';

export interface DurableJob {
  id: string;
  ownerUid: string;
  capabilityId: string;
  capabilityVersion: number;
  resource: string;
  approvalId?: string;
  actionDigest?: string;
  state: DurableJobState;
  parameters: unknown;
  createdAt: number;
  updatedAt: number;
  expiresAt: number;
  attempts: number;
  workerId?: string;
  errorCode?: string;
  receipt?: unknown;
}

export interface DurableApproval {
  id: string;
  ownerUid: string;
  capabilityId: string;
  resource: string;
  actionDigest: string;
  status: 'PENDING' | 'APPROVED' | 'CONSUMED' | 'DENIED' | 'EXPIRED';
  createdAt: number;
  expiresAt: number;
  approvedBy?: string;
  approvedAt?: number;
  consumedAt?: number;
  request: unknown;
}

export interface AuditEventInput {
  ownerUid: string;
  actorUid: string;
  action: string;
  resource: string;
  decision: 'ALLOW' | 'DENY' | 'INFO';
  reason: string;
  metadata?: unknown;
}

export type KnowledgeDomain = 'CONVERSATION' | 'MEMORY' | 'VAULT' | 'PROJECT' | 'GIDEON';
export type KnowledgeVerification = 'VERIFIED' | 'UNVERIFIED' | 'INFERRED';
export interface KnowledgeRecordInput {
  domain: KnowledgeDomain;
  sourceId: string;
  projectId?: string;
  title: string;
  content: string;
  sourceLabel?: string;
  verificationStatus?: KnowledgeVerification;
  occurredAt?: number;
  metadata?: Record<string, string | number | boolean | null>;
}
export interface KnowledgeSearchResult {
  recordId: string;
  domain: KnowledgeDomain;
  sourceId: string;
  projectId?: string;
  title: string;
  snippet: string;
  verificationStatus: KnowledgeVerification;
  occurredAt: number;
  updatedAt: number;
  score: number;
  citation: { id: string; title: string; domain: KnowledgeDomain; sourceId: string };
}

interface EncryptedPayload { iv: string; tag: string; ciphertext: string; }

const JOB_TRANSITIONS: Record<DurableJobState, ReadonlySet<DurableJobState>> = {
  AWAITING_APPROVAL: new Set(['QUEUED', 'BLOCKED', 'CANCELLED']),
  QUEUED: new Set(['RUNNING', 'BLOCKED', 'CANCELLED']),
  RUNNING: new Set(['COMPLETED', 'FAILED', 'BLOCKED', 'CANCELLED']),
  BLOCKED: new Set(['QUEUED', 'CANCELLED']),
  FAILED: new Set(['QUEUED', 'CANCELLED']),
  CANCELLED: new Set(),
  // Verification is intentionally not available through generic state transitions.
  // A future trusted postcondition verifier must own this transition.
  COMPLETED: new Set(),
  VERIFIED: new Set()
};

function ensurePrivateDirectory(path: string): void {
  mkdirSync(path, { recursive: true, mode: 0o700 });
  const stat = lstatSync(path);
  if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error(`LORIN storage directory must be a real directory: ${path}`);
  if (process.platform !== 'win32') chmodSync(path, 0o700);
}

function loadEncryptionKey(keyFile: string): Buffer {
  const envKey = process.env.LORIN_STORAGE_KEY_HEX?.trim();
  if (envKey) {
    if (!/^[a-f0-9]{64}$/i.test(envKey)) throw new Error('LORIN_STORAGE_KEY_HEX must be exactly 64 hexadecimal characters (32 bytes).');
    return Buffer.from(envKey, 'hex');
  }

  ensurePrivateDirectory(dirname(keyFile));
  if (existsSync(keyFile)) {
    const stat = lstatSync(keyFile);
    if (stat.isSymbolicLink() || !stat.isFile()) throw new Error('LORIN storage key must be a regular file, not a symlink or special file.');
    const key = readFileSync(keyFile);
    if (key.length !== 32) throw new Error('LORIN storage key file is invalid; expected exactly 32 bytes.');
    if (process.platform !== 'win32') chmodSync(keyFile, 0o600);
    return key;
  }

  const key = randomBytes(32);
  try {
    writeFileSync(keyFile, key, { flag: 'wx', mode: 0o600 });
  } catch (error: any) {
    // Another LORIN process may have won the first-start race. Re-read rather than overwrite.
    if (error?.code !== 'EEXIST') throw error;
    const stat = lstatSync(keyFile);
    if (stat.isSymbolicLink() || !stat.isFile()) throw new Error('Concurrent LORIN key creation produced an unsafe key path.');
    const existing = readFileSync(keyFile);
    if (existing.length !== 32) throw new Error('Concurrent LORIN key creation produced an invalid key file.');
    if (process.platform !== 'win32') chmodSync(keyFile, 0o600);
    return existing;
  }
  if (process.platform !== 'win32') chmodSync(keyFile, 0o600);
  return key;
}

function encryptPayload(key: Buffer, payload: unknown, associatedData: string): EncryptedPayload {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(Buffer.from(associatedData, 'utf8'));
  const ciphertext = Buffer.concat([cipher.update(canonicalJson(payload), 'utf8'), cipher.final()]);
  return {
    iv: iv.toString('hex'),
    tag: cipher.getAuthTag().toString('hex'),
    ciphertext: ciphertext.toString('base64')
  };
}

function decryptPayload<T>(key: Buffer, payload: EncryptedPayload, associatedData: string): T {
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(payload.iv, 'hex'));
  decipher.setAAD(Buffer.from(associatedData, 'utf8'));
  decipher.setAuthTag(Buffer.from(payload.tag, 'hex'));
  const cleartext = Buffer.concat([
    decipher.update(Buffer.from(payload.ciphertext, 'base64')),
    decipher.final()
  ]).toString('utf8');
  return JSON.parse(cleartext) as T;
}

/**
 * Encrypted, transactional local-first store. It deliberately refuses serverless
 * runtimes: ephemeral /tmp storage is not a durable source of truth.
 */
export class LorinSqliteStore {
  readonly databasePath: string;
  private readonly db: DatabaseSync;
  private readonly encryptionKey: Buffer;
  private closed = false;

  constructor(options: { databasePath?: string; keyFilePath?: string; encryptionKey?: Buffer } = {}) {
    if (process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME || process.env.NETLIFY) {
      throw new Error('DURABLE_LOCAL_STORE_UNAVAILABLE: Use the configured cloud persistence adapter in serverless deployments.');
    }

    const dataDir = resolve(process.env.LORIN_DATA_DIR || join(homedir(), '.lorin', 'data'));
    ensurePrivateDirectory(dataDir);
    this.databasePath = resolve(options.databasePath || process.env.LORIN_DATABASE_PATH || join(dataDir, 'lorin.sqlite'));
    ensurePrivateDirectory(dirname(this.databasePath));
    if (existsSync(this.databasePath)) {
      const databaseStat = lstatSync(this.databasePath);
      if (databaseStat.isSymbolicLink() || !databaseStat.isFile()) {
        throw new Error('LORIN database path must be a regular file, not a symlink or special file.');
      }
    }

    const keyFile = resolve(options.keyFilePath || join(homedir(), '.lorin', 'keys', 'storage.key'));
    this.encryptionKey = options.encryptionKey ? Buffer.from(options.encryptionKey) : loadEncryptionKey(keyFile);
    if (this.encryptionKey.length !== 32) throw new Error('LORIN storage encryption key must be 32 bytes.');

    this.db = new DatabaseSync(this.databasePath);
    this.db.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA synchronous = FULL;
      PRAGMA foreign_keys = ON;
      PRAGMA busy_timeout = 5000;
      PRAGMA trusted_schema = OFF;
      PRAGMA secure_delete = ON;
      PRAGMA temp_store = MEMORY;
      CREATE TABLE IF NOT EXISTS lorin_schema_migrations (
        version INTEGER PRIMARY KEY,
        applied_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS lorin_jobs (
        job_id TEXT PRIMARY KEY,
        owner_uid TEXT NOT NULL,
        capability_id TEXT NOT NULL,
        capability_version INTEGER NOT NULL,
        resource TEXT NOT NULL,
        approval_id TEXT,
        action_digest TEXT,
        state TEXT NOT NULL,
        payload_iv TEXT NOT NULL,
        payload_tag TEXT NOT NULL,
        payload_ciphertext TEXT NOT NULL,
        receipt_iv TEXT,
        receipt_tag TEXT,
        receipt_ciphertext TEXT,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0,
        worker_id TEXT,
        worker_lease_until INTEGER,
        error_code TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_lorin_jobs_owner_updated ON lorin_jobs(owner_uid, updated_at DESC);
      CREATE INDEX IF NOT EXISTS idx_lorin_jobs_queue ON lorin_jobs(state, created_at ASC);
      CREATE TABLE IF NOT EXISTS lorin_approvals (
        approval_id TEXT PRIMARY KEY,
        owner_uid TEXT NOT NULL,
        capability_id TEXT NOT NULL,
        resource TEXT NOT NULL,
        action_digest TEXT NOT NULL,
        status TEXT NOT NULL,
        request_iv TEXT NOT NULL,
        request_tag TEXT NOT NULL,
        request_ciphertext TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL,
        approved_by TEXT,
        approved_at INTEGER,
        consumed_at INTEGER
      );
      CREATE INDEX IF NOT EXISTS idx_lorin_approvals_owner ON lorin_approvals(owner_uid, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_lorin_approvals_digest ON lorin_approvals(action_digest, status);
      CREATE TABLE IF NOT EXISTS lorin_audit_events (
        sequence INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id TEXT NOT NULL UNIQUE,
        owner_uid TEXT NOT NULL,
        actor_uid TEXT NOT NULL,
        action TEXT NOT NULL,
        resource TEXT NOT NULL,
        decision TEXT NOT NULL,
        reason TEXT NOT NULL,
        payload_iv TEXT NOT NULL,
        payload_tag TEXT NOT NULL,
        payload_ciphertext TEXT NOT NULL,
        previous_hash TEXT NOT NULL,
        event_hash TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_lorin_audit_owner ON lorin_audit_events(owner_uid, sequence DESC);
      CREATE TABLE IF NOT EXISTS lorin_knowledge_records (
        record_id TEXT PRIMARY KEY,
        owner_uid TEXT NOT NULL,
        domain TEXT NOT NULL,
        source_id TEXT NOT NULL,
        project_id TEXT,
        content_hash TEXT NOT NULL,
        payload_iv TEXT NOT NULL,
        payload_tag TEXT NOT NULL,
        payload_ciphertext TEXT NOT NULL,
        occurred_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        UNIQUE(owner_uid, domain, source_id)
      );
      CREATE INDEX IF NOT EXISTS idx_lorin_knowledge_owner_updated ON lorin_knowledge_records(owner_uid, updated_at DESC);
      CREATE INDEX IF NOT EXISTS idx_lorin_knowledge_owner_project ON lorin_knowledge_records(owner_uid, project_id, updated_at DESC);
      CREATE TABLE IF NOT EXISTS lorin_knowledge_terms (
        owner_uid TEXT NOT NULL,
        record_id TEXT NOT NULL,
        term_hash TEXT NOT NULL,
        frequency INTEGER NOT NULL,
        PRIMARY KEY(owner_uid, record_id, term_hash),
        FOREIGN KEY(record_id) REFERENCES lorin_knowledge_records(record_id) ON DELETE CASCADE
      );
      CREATE INDEX IF NOT EXISTS idx_lorin_knowledge_terms_lookup ON lorin_knowledge_terms(owner_uid, term_hash);
    `);
    const jobColumns = this.db.prepare('PRAGMA table_info(lorin_jobs)').all() as Array<{ name: string }>;
    if (!jobColumns.some(column => column.name === 'approval_id')) this.db.exec('ALTER TABLE lorin_jobs ADD COLUMN approval_id TEXT');
    if (!jobColumns.some(column => column.name === 'action_digest')) this.db.exec('ALTER TABLE lorin_jobs ADD COLUMN action_digest TEXT');
    if (!jobColumns.some(column => column.name === 'worker_lease_until')) this.db.exec('ALTER TABLE lorin_jobs ADD COLUMN worker_lease_until INTEGER');
    this.db.prepare('INSERT OR IGNORE INTO lorin_schema_migrations(version, applied_at) VALUES(4, ?)').run(Date.now());
    this.db.prepare('INSERT OR IGNORE INTO lorin_schema_migrations(version, applied_at) VALUES(5, ?)').run(Date.now());
    if (process.platform !== 'win32') chmodSync(this.databasePath, 0o600);
  }

  private assertOpen(): void {
    if (this.closed) throw new Error('LORIN local store is closed.');
  }

  private transaction<T>(operation: () => T): T {
    this.assertOpen();
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const result = operation();
      this.db.exec('COMMIT');
      return result;
    } catch (error) {
      this.db.exec('ROLLBACK');
      throw error;
    }
  }

  private appendAudit(input: AuditEventInput): string {
    const now = Date.now();
    const id = randomUUID();
    const payload = encryptPayload(this.encryptionKey, input.metadata ?? {}, canonicalJson([
      'lorin-audit-v1', id, input.ownerUid, input.actorUid, input.action, input.resource
    ]));
    const last = this.db.prepare('SELECT event_hash FROM lorin_audit_events ORDER BY sequence DESC LIMIT 1').get() as { event_hash?: string } | undefined;
    const previousHash = last?.event_hash || 'GENESIS';
    const eventHash = sha256Hex([
      previousHash, id, input.ownerUid, input.actorUid, input.action, input.resource,
      input.decision, input.reason, payload.iv, payload.tag, payload.ciphertext, String(now)
    ].join('\n'));

    this.db.prepare(`
      INSERT INTO lorin_audit_events(
        event_id, owner_uid, actor_uid, action, resource, decision, reason,
        payload_iv, payload_tag, payload_ciphertext, previous_hash, event_hash, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id, input.ownerUid, input.actorUid, input.action, input.resource, input.decision,
      input.reason, payload.iv, payload.tag, payload.ciphertext, previousHash, eventHash, now
    );
    return eventHash;
  }

  recordAudit(input: AuditEventInput): string {
    return this.transaction(() => this.appendAudit(input));
  }

  verifyAuditChain(): { valid: boolean; checked: number; brokenAt?: number } {
    this.assertOpen();
    const rows = this.db.prepare(`
      SELECT sequence, event_id, owner_uid, actor_uid, action, resource, decision, reason,
        payload_iv, payload_tag, payload_ciphertext, previous_hash, event_hash, created_at
      FROM lorin_audit_events ORDER BY sequence ASC
    `).all() as Array<Record<string, string | number>>;
    let previousHash = 'GENESIS';
    for (const row of rows) {
      if (row.previous_hash !== previousHash) return { valid: false, checked: Number(row.sequence), brokenAt: Number(row.sequence) };
      const expected = sha256Hex([
        previousHash, row.event_id, row.owner_uid, row.actor_uid, row.action, row.resource,
        row.decision, row.reason, row.payload_iv, row.payload_tag, row.payload_ciphertext, String(row.created_at)
      ].join('\n'));
      if (expected !== row.event_hash) return { valid: false, checked: Number(row.sequence), brokenAt: Number(row.sequence) };
      previousHash = String(row.event_hash);
    }
    return { valid: true, checked: rows.length };
  }

  getApproval(approvalId: string, visibleToUid?: string): DurableApproval | undefined {
    this.assertOpen();
    const row = this.db.prepare('SELECT * FROM lorin_approvals WHERE approval_id = ?').get(approvalId) as any;
    if (!row || (visibleToUid && row.owner_uid !== visibleToUid)) return undefined;
    return this.mapApproval(row);
  }

  listApprovals(ownerUid: string, limit = 100): DurableApproval[] {
    this.assertOpen();
    const rows = this.db.prepare('SELECT * FROM lorin_approvals WHERE owner_uid = ? ORDER BY created_at DESC LIMIT ?')
      .all(ownerUid, Math.min(Math.max(limit, 1), 250)) as any[];
    return rows.map(row => this.mapApproval(row));
  }

  private mapApproval(row: any): DurableApproval {
    return {
      id: row.approval_id,
      ownerUid: row.owner_uid,
      capabilityId: row.capability_id,
      resource: row.resource,
      actionDigest: row.action_digest,
      status: row.status,
      createdAt: row.created_at,
      expiresAt: row.expires_at,
      approvedBy: row.approved_by || undefined,
      approvedAt: row.approved_at || undefined,
      consumedAt: row.consumed_at || undefined,
      request: decryptPayload(this.encryptionKey, {
        iv: row.request_iv, tag: row.request_tag, ciphertext: row.request_ciphertext
      }, canonicalJson(['lorin-approval-v1', row.approval_id, row.owner_uid, row.capability_id, row.resource, row.action_digest]))
    };
  }

  createJob(input: {
    ownerUid: string;
    capabilityId: string;
    capabilityVersion: number;
    resource: string;
    parameters: unknown;
    actionDigest: string;
    state: DurableJobState;
    ttlMs?: number;
  }): DurableJob {
    if (!input.ownerUid || !input.capabilityId || !input.resource || !/^[a-f0-9]{64}$/i.test(input.actionDigest)) {
      throw new TypeError('Job owner, capability, resource and action digest are required.');
    }
    if (!['AWAITING_APPROVAL', 'QUEUED', 'BLOCKED'].includes(input.state)) throw new Error('Initial job state is not permitted.');
    const now = Date.now();
    const id = randomUUID();
    const expiresAt = now + Math.min(Math.max(input.ttlMs ?? 24 * 60 * 60_000, 60_000), 7 * 24 * 60 * 60_000);
    const encrypted = encryptPayload(this.encryptionKey, input.parameters, canonicalJson([
      'lorin-job-v1', id, input.ownerUid, input.capabilityId, input.capabilityVersion, input.resource
    ]));
    this.transaction(() => {
      this.db.prepare(`INSERT INTO lorin_jobs(
        job_id, owner_uid, capability_id, capability_version, resource, approval_id, action_digest, state,
        payload_iv, payload_tag, payload_ciphertext, created_at, updated_at, expires_at
      ) VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
        id, input.ownerUid, input.capabilityId, input.capabilityVersion, input.resource, input.actionDigest, input.state,
        encrypted.iv, encrypted.tag, encrypted.ciphertext, now, now, expiresAt
      );
      this.appendAudit({
        ownerUid: input.ownerUid, actorUid: input.ownerUid, action: 'job.created', resource: input.resource,
        decision: 'INFO', reason: `Job created in state ${input.state}.`,
        metadata: { jobId: id, capabilityId: input.capabilityId, state: input.state }
      });
    });
    return { id, ownerUid: input.ownerUid, capabilityId: input.capabilityId, capabilityVersion: input.capabilityVersion,
      resource: input.resource, actionDigest: input.actionDigest, state: input.state, parameters: input.parameters, createdAt: now, updatedAt: now,
      expiresAt, attempts: 0 };
  }

  createJobWithApproval(input: {
    ownerUid: string;
    capabilityId: string;
    capabilityVersion: number;
    resource: string;
    parameters: unknown;
    actionDigest: string;
    ttlMs?: number;
  }): { job: DurableJob; approval: DurableApproval } {
    if (!input.ownerUid || !input.capabilityId || !input.resource || !/^[a-f0-9]{64}$/i.test(input.actionDigest)) {
      throw new TypeError('Invalid action-bound job creation request.');
    }
    const now = Date.now();
    const jobId = randomUUID();
    const approvalId = randomUUID();
    const expiresAt = now + Math.min(Math.max(input.ttlMs ?? 24 * 60 * 60_000, 60_000), 7 * 24 * 60 * 60_000);
    const approvalExpiresAt = Math.min(expiresAt, now + 5 * 60_000);
    const encryptedParameters = encryptPayload(this.encryptionKey, input.parameters, canonicalJson([
      'lorin-job-v1', jobId, input.ownerUid, input.capabilityId, input.capabilityVersion, input.resource
    ]));
    const approvalRequest = {
      jobId, capabilityId: input.capabilityId, resource: input.resource,
      parameters: input.parameters, actionDigest: input.actionDigest
    };
    const encryptedApproval = encryptPayload(this.encryptionKey, approvalRequest, canonicalJson([
      'lorin-approval-v1', approvalId, input.ownerUid, input.capabilityId, input.resource, input.actionDigest
    ]));

    this.transaction(() => {
      this.db.prepare(`INSERT INTO lorin_jobs(
        job_id, owner_uid, capability_id, capability_version, resource, approval_id, action_digest, state,
        payload_iv, payload_tag, payload_ciphertext, created_at, updated_at, expires_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'AWAITING_APPROVAL', ?, ?, ?, ?, ?, ?)`)
        .run(jobId, input.ownerUid, input.capabilityId, input.capabilityVersion, input.resource,
          approvalId, input.actionDigest, encryptedParameters.iv, encryptedParameters.tag,
          encryptedParameters.ciphertext, now, now, expiresAt);
      this.db.prepare(`INSERT INTO lorin_approvals(
        approval_id, owner_uid, capability_id, resource, action_digest, status,
        request_iv, request_tag, request_ciphertext, created_at, expires_at
      ) VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, ?)`)
        .run(approvalId, input.ownerUid, input.capabilityId, input.resource, input.actionDigest,
          encryptedApproval.iv, encryptedApproval.tag, encryptedApproval.ciphertext, now, approvalExpiresAt);
      this.appendAudit({
        ownerUid: input.ownerUid, actorUid: input.ownerUid, action: 'job.created', resource: input.resource,
        decision: 'INFO', reason: 'Action-bound job created and held for approval.',
        metadata: { jobId, capabilityId: input.capabilityId, state: 'AWAITING_APPROVAL', approvalId, actionDigest: input.actionDigest }
      });
      this.appendAudit({
        ownerUid: input.ownerUid, actorUid: input.ownerUid, action: 'approval.requested', resource: input.resource,
        decision: 'INFO', reason: 'Single-use approval request created for the exact job parameters.',
        metadata: { approvalId, jobId, capabilityId: input.capabilityId, actionDigest: input.actionDigest }
      });
    });

    return {
      job: {
        id: jobId, ownerUid: input.ownerUid, capabilityId: input.capabilityId,
        capabilityVersion: input.capabilityVersion, resource: input.resource, approvalId,
        actionDigest: input.actionDigest, state: 'AWAITING_APPROVAL', parameters: input.parameters,
        createdAt: now, updatedAt: now, expiresAt, attempts: 0
      },
      approval: {
        id: approvalId, ownerUid: input.ownerUid, capabilityId: input.capabilityId, resource: input.resource,
        actionDigest: input.actionDigest, status: 'PENDING', createdAt: now,
        expiresAt: approvalExpiresAt, request: approvalRequest
      }
    };
  }

  approveJobWithApproval(jobId: string, approvalId: string, approverUid: string): DurableJob {
    const now = Date.now();
    const result = this.transaction(() => {
      const job = this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(jobId) as any;
      const approval = this.db.prepare('SELECT * FROM lorin_approvals WHERE approval_id = ?').get(approvalId) as any;
      if (!job || !approval || job.approval_id !== approvalId) return { error: 'APPROVAL_BINDING_MISMATCH' as const };
      if (job.state !== 'AWAITING_APPROVAL' || approval.status !== 'PENDING') return { error: 'APPROVAL_NOT_PENDING' as const };
      if (job.owner_uid !== approval.owner_uid || job.capability_id !== approval.capability_id ||
          job.resource !== approval.resource || job.action_digest !== approval.action_digest) {
        return { error: 'APPROVAL_BINDING_MISMATCH' as const };
      }
      if (approval.expires_at <= now || job.expires_at <= now) {
        this.db.prepare("UPDATE lorin_approvals SET status = 'EXPIRED' WHERE approval_id = ? AND status = 'PENDING'").run(approvalId);
        this.db.prepare("UPDATE lorin_jobs SET state = 'BLOCKED', updated_at = ?, error_code = 'APPROVAL_EXPIRED' WHERE job_id = ? AND state = 'AWAITING_APPROVAL'").run(now, jobId);
        this.appendAudit({ ownerUid: job.owner_uid, actorUid: approverUid, action: 'approval.expired', resource: job.resource,
          decision: 'DENY', reason: 'Approval or job expired before authorization.', metadata: { jobId, approvalId } });
        return { error: 'APPROVAL_EXPIRED' as const };
      }
      this.db.prepare("UPDATE lorin_approvals SET status = 'APPROVED', approved_by = ?, approved_at = ? WHERE approval_id = ? AND status = 'PENDING'")
        .run(approverUid, now, approvalId);
      this.db.prepare("UPDATE lorin_jobs SET state = 'QUEUED', updated_at = ?, error_code = NULL WHERE job_id = ? AND state = 'AWAITING_APPROVAL'")
        .run(now, jobId);
      this.appendAudit({ ownerUid: job.owner_uid, actorUid: approverUid, action: 'approval.approved', resource: job.resource,
        decision: 'ALLOW', reason: 'Authorized reviewer approved the exact action-bound request.',
        metadata: { jobId, approvalId, actionDigest: job.action_digest } });
      this.appendAudit({ ownerUid: job.owner_uid, actorUid: approverUid, action: 'job.queued', resource: job.resource,
        decision: 'INFO', reason: 'Approved job atomically released to the trusted worker queue.', metadata: { jobId, approvalId } });
      return { job: this.mapJob(this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(jobId) as any) };
    });
    if ('error' in result) throw new Error(result.error);
    return result.job;
  }

  getJob(jobId: string, ownerUid?: string): DurableJob | undefined {
    this.assertOpen();
    const row = ownerUid
      ? this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ? AND owner_uid = ?').get(jobId, ownerUid) as any
      : this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(jobId) as any;
    return row ? this.mapJob(row) : undefined;
  }

  listJobs(ownerUid: string, limit = 100): DurableJob[] {
    this.assertOpen();
    const rows = this.db.prepare('SELECT * FROM lorin_jobs WHERE owner_uid = ? ORDER BY created_at DESC LIMIT ?')
      .all(ownerUid, Math.min(Math.max(limit, 1), 250)) as any[];
    return rows.map(row => this.mapJob(row));
  }

  private mapJob(row: any): DurableJob {
    let receipt: unknown;
    if (row.receipt_iv && row.receipt_tag && row.receipt_ciphertext) {
      receipt = decryptPayload(this.encryptionKey, { iv: row.receipt_iv, tag: row.receipt_tag, ciphertext: row.receipt_ciphertext },
        canonicalJson(['lorin-receipt-v1', row.job_id, row.owner_uid, row.capability_id]));
    }
    return {
      id: row.job_id, ownerUid: row.owner_uid, capabilityId: row.capability_id,
      capabilityVersion: row.capability_version, resource: row.resource,
      approvalId: row.approval_id || undefined, actionDigest: row.action_digest || undefined, state: row.state,
      parameters: decryptPayload(this.encryptionKey, { iv: row.payload_iv, tag: row.payload_tag, ciphertext: row.payload_ciphertext },
        canonicalJson(['lorin-job-v1', row.job_id, row.owner_uid, row.capability_id, row.capability_version, row.resource])),
      createdAt: row.created_at, updatedAt: row.updated_at, expiresAt: row.expires_at,
      attempts: row.attempts, workerId: row.worker_id || undefined, errorCode: row.error_code || undefined, receipt
    };
  }

  claimNextJob(workerId: string, leaseDurationMs = 180_000): DurableJob | undefined {
    if (!workerId.trim()) throw new TypeError('Worker ID is required.');
    if (!Number.isInteger(leaseDurationMs) || leaseDurationMs < 100 || leaseDurationMs > 600_000) {
      throw new RangeError('Worker lease must be between 100ms and 600000ms.');
    }
    return this.transaction(() => {
      const now = Date.now();
      // A crashed worker is never silently re-run: expired RUNNING jobs are
      // moved to BLOCKED for operator review because their side effects may be unknown.
      const staleRunning = this.db.prepare(`SELECT job_id, owner_uid, resource, worker_id FROM lorin_jobs
        WHERE state = 'RUNNING' AND (worker_lease_until IS NULL OR worker_lease_until <= ?)`)
        .all(now) as any[];
      for (const stale of staleRunning) {
        this.db.prepare("UPDATE lorin_jobs SET state = 'BLOCKED', updated_at = ?, error_code = 'WORKER_LEASE_EXPIRED', worker_lease_until = NULL WHERE job_id = ? AND state = 'RUNNING'")
          .run(now, stale.job_id);
        this.appendAudit({ ownerUid: stale.owner_uid, actorUid: workerId, action: 'job.worker_interrupted', resource: stale.resource,
          decision: 'DENY', reason: 'A worker lease expired before a completion receipt was recorded. The job was blocked rather than replayed because side effects may be unknown.',
          metadata: { jobId: stale.job_id, previousWorkerId: stale.worker_id || null } });
      }
      this.db.prepare("UPDATE lorin_approvals SET status = 'EXPIRED' WHERE status IN ('PENDING', 'APPROVED') AND expires_at <= ?")
        .run(now);
      this.db.prepare("UPDATE lorin_jobs SET state = 'BLOCKED', updated_at = ?, error_code = 'JOB_EXPIRED' WHERE state IN ('AWAITING_APPROVAL', 'QUEUED') AND expires_at <= ?")
        .run(now, now);
      const row = this.db.prepare("SELECT * FROM lorin_jobs WHERE state = 'QUEUED' AND expires_at > ? ORDER BY created_at ASC LIMIT 1")
        .get(now) as any;
      if (!row) return undefined;
      if (row.approval_id) {
        const consumed = this.db.prepare(`UPDATE lorin_approvals SET status = 'CONSUMED', consumed_at = ?
          WHERE approval_id = ? AND owner_uid = ? AND capability_id = ? AND resource = ?
            AND action_digest = ? AND status = 'APPROVED' AND expires_at > ?`)
          .run(now, row.approval_id, row.owner_uid, row.capability_id, row.resource, row.action_digest, now);
        if (Number(consumed.changes) !== 1) {
          this.db.prepare("UPDATE lorin_jobs SET state = 'BLOCKED', updated_at = ?, error_code = 'APPROVAL_INVALID_EXPIRED_OR_ALREADY_USED' WHERE job_id = ? AND state = 'QUEUED'")
            .run(now, row.job_id);
          this.appendAudit({ ownerUid: row.owner_uid, actorUid: workerId, action: 'job.blocked', resource: row.resource,
            decision: 'DENY', reason: 'The action-bound approval was missing, expired or already consumed.',
            metadata: { jobId: row.job_id, approvalId: row.approval_id } });
          return this.mapJob(this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(row.job_id) as any);
        }
        this.appendAudit({ ownerUid: row.owner_uid, actorUid: workerId, action: 'approval.consumed', resource: row.resource,
          decision: 'ALLOW', reason: 'Single-use approval consumed atomically immediately before execution.',
          metadata: { jobId: row.job_id, approvalId: row.approval_id, actionDigest: row.action_digest } });
      }
      const update = this.db.prepare("UPDATE lorin_jobs SET state = 'RUNNING', updated_at = ?, attempts = attempts + 1, worker_id = ?, worker_lease_until = ? WHERE job_id = ? AND state = 'QUEUED'")
        .run(now, workerId, now + leaseDurationMs, row.job_id);
      if (Number(update.changes) !== 1) return undefined;
      this.appendAudit({ ownerUid: row.owner_uid, actorUid: workerId, action: 'job.claimed', resource: row.resource,
        decision: 'ALLOW', reason: 'Trusted local worker claimed the queued job.', metadata: { jobId: row.job_id, workerId } });
      return this.mapJob(this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(row.job_id) as any);
    });
  }

  renewJobLease(jobId: string, workerId: string, leaseDurationMs = 180_000): boolean {
    this.assertOpen();
    if (!Number.isInteger(leaseDurationMs) || leaseDurationMs < 100 || leaseDurationMs > 600_000) {
      throw new RangeError('Worker lease must be between 100ms and 600000ms.');
    }
    const result = this.db.prepare("UPDATE lorin_jobs SET worker_lease_until = ?, updated_at = ? WHERE job_id = ? AND state = 'RUNNING' AND worker_id = ?")
      .run(Date.now() + leaseDurationMs, Date.now(), jobId, workerId);
    return Number(result.changes) === 1;
  }

  transitionJob(input: {
    jobId: string;
    workerId?: string;
    nextState: DurableJobState;
    errorCode?: string;
    receipt?: unknown;
    actorUid: string;
    reason: string;
  }): DurableJob {
    const now = Date.now();
    return this.transaction(() => {
      const row = this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(input.jobId) as any;
      if (!row) throw new Error('JOB_NOT_FOUND');
      const currentState = row.state as DurableJobState;
      if (!JOB_TRANSITIONS[currentState]?.has(input.nextState)) throw new Error(`INVALID_JOB_TRANSITION:${currentState}->${input.nextState}`);
      if (currentState === 'RUNNING' && input.workerId !== row.worker_id) throw new Error('JOB_WORKER_MISMATCH');
      const receipt = input.receipt === undefined ? undefined : encryptPayload(this.encryptionKey, input.receipt,
        canonicalJson(['lorin-receipt-v1', row.job_id, row.owner_uid, row.capability_id]));
      this.db.prepare(`UPDATE lorin_jobs SET state = ?, updated_at = ?, error_code = ?,
        receipt_iv = ?, receipt_tag = ?, receipt_ciphertext = ?, worker_lease_until = NULL WHERE job_id = ?`)
        .run(input.nextState, now, input.errorCode || null, receipt?.iv || null, receipt?.tag || null, receipt?.ciphertext || null, input.jobId);
      this.appendAudit({
        ownerUid: row.owner_uid, actorUid: input.actorUid, action: `job.${input.nextState.toLowerCase()}`,
        resource: row.resource, decision: input.nextState === 'FAILED' || input.nextState === 'BLOCKED' ? 'DENY' : 'INFO',
        reason: input.reason, metadata: { jobId: input.jobId, previousState: currentState, nextState: input.nextState, ...(input.errorCode ? { errorCode: input.errorCode } : {}) }
      });
      return this.mapJob(this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(input.jobId) as any);
    });
  }

  retryJob(jobId: string, ownerUid: string, maximumAttempts = 3): DurableJob {
    this.assertOpen();
    return this.transaction(() => {
      const row = this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ? AND owner_uid = ?').get(jobId, ownerUid) as any;
      if (!row) throw new Error('JOB_NOT_FOUND');
      if (!['FAILED', 'BLOCKED'].includes(row.state)) throw new Error('JOB_NOT_RETRYABLE');
      if (row.attempts >= maximumAttempts) throw new Error('JOB_RETRY_LIMIT_REACHED');
      // An approval is single-use. Approved jobs must be submitted again so a
      // fresh independent approval can be reviewed and consumed exactly once.
      if (row.approval_id) throw new Error('NEW_APPROVAL_REQUIRED');
      if (row.expires_at <= Date.now()) throw new Error('JOB_EXPIRED');
      this.db.prepare(`UPDATE lorin_jobs SET state = 'QUEUED', updated_at = ?, error_code = NULL,
        receipt_iv = NULL, receipt_tag = NULL, receipt_ciphertext = NULL, worker_id = NULL, worker_lease_until = NULL
        WHERE job_id = ? AND owner_uid = ?`).run(Date.now(), jobId, ownerUid);
      this.appendAudit({ ownerUid, actorUid: ownerUid, action: 'job.retried', resource: row.resource,
        decision: 'INFO', reason: 'Owner re-queued a failed/blocked job within the retry limit; single-use approved jobs require a new submission.',
        metadata: { jobId, previousAttempts: row.attempts, maximumAttempts } });
      return this.mapJob(this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(jobId) as any);
    });
  }

  markJobVerified(jobId: string, ownerUid: string, verifierId: string, verification: { verified: true; evidence: string; checkedAt: number }): DurableJob {
    this.assertOpen();
    if (!verifierId || verifierId.length > 160 || !verification?.verified || !verification.evidence || verification.evidence.length > 4_000) {
      throw new TypeError('A trusted verifier and bounded verification evidence are required.');
    }
    return this.transaction(() => {
      const row = this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ? AND owner_uid = ?').get(jobId, ownerUid) as any;
      if (!row) throw new Error('JOB_NOT_FOUND');
      if (row.state !== 'COMPLETED') throw new Error('JOB_NOT_AWAITING_VERIFICATION');
      const originalReceipt = row.receipt_iv && row.receipt_tag && row.receipt_ciphertext
        ? decryptPayload<any>(this.encryptionKey, { iv: row.receipt_iv, tag: row.receipt_tag, ciphertext: row.receipt_ciphertext },
            canonicalJson(['lorin-receipt-v1', row.job_id, row.owner_uid, row.capability_id]))
        : {};
      const nextReceipt = { ...originalReceipt, independentVerification: verification };
      const encrypted = encryptPayload(this.encryptionKey, nextReceipt,
        canonicalJson(['lorin-receipt-v1', row.job_id, row.owner_uid, row.capability_id]));
      this.db.prepare(`UPDATE lorin_jobs SET state = 'VERIFIED', updated_at = ?, receipt_iv = ?, receipt_tag = ?, receipt_ciphertext = ?
        WHERE job_id = ? AND owner_uid = ? AND state = 'COMPLETED'`)
        .run(Date.now(), encrypted.iv, encrypted.tag, encrypted.ciphertext, jobId, ownerUid);
      this.appendAudit({ ownerUid, actorUid: verifierId, action: 'job.verified', resource: row.resource,
        decision: 'ALLOW', reason: 'A registered server-side postcondition verifier independently confirmed the completed operation.',
        metadata: { jobId, capabilityId: row.capability_id, verification } });
      return this.mapJob(this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(jobId) as any);
    });
  }

  cancelJob(jobId: string, ownerUid: string): DurableJob {
    const now = Date.now();
    return this.transaction(() => {
      const row = this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ? AND owner_uid = ?').get(jobId, ownerUid) as any;
      if (!row) throw new Error('JOB_NOT_FOUND');
      const state = row.state as DurableJobState;
      if (!['AWAITING_APPROVAL', 'QUEUED', 'BLOCKED', 'FAILED'].includes(state)) {
        throw new Error('JOB_CANNOT_BE_CANCELLED_IN_CURRENT_STATE');
      }
      this.db.prepare("UPDATE lorin_jobs SET state = 'CANCELLED', updated_at = ?, error_code = NULL WHERE job_id = ? AND owner_uid = ?")
        .run(now, jobId, ownerUid);
      let revoked = 0;
      if (row.approval_id) {
        const result = this.db.prepare("UPDATE lorin_approvals SET status = 'DENIED' WHERE approval_id = ? AND owner_uid = ? AND status IN ('PENDING', 'APPROVED')")
          .run(row.approval_id, ownerUid);
        revoked = Number(result.changes);
      }
      this.appendAudit({ ownerUid, actorUid: ownerUid, action: 'job.cancelled', resource: row.resource,
        decision: 'INFO', reason: 'Owner cancelled the job before execution.', metadata: { jobId, previousState: state } });
      if (revoked) {
        this.appendAudit({ ownerUid, actorUid: ownerUid, action: 'approval.revoked', resource: row.resource,
          decision: 'DENY', reason: 'Approval was revoked because its associated job was cancelled.', metadata: { jobId, approvalId: row.approval_id } });
      }
      return this.mapJob(this.db.prepare('SELECT * FROM lorin_jobs WHERE job_id = ?').get(jobId) as any);
    });
  }

  private knowledgeTokenHash(token: string): string {
    return createHmac('sha256', this.encryptionKey).update(token, 'utf8').digest('hex');
  }

  private tokenizeKnowledgeText(text: string): Map<string, number> {
    const tokens = (String(text || '').normalize('NFKC').toLocaleLowerCase('en')
      .match(/[\p{L}\p{N}]{2,}/gu) || []).slice(0, 20_000);
    const stop = new Set(['the', 'and', 'for', 'with', 'that', 'this', 'from', 'are', 'was', 'were', 'you', 'your', 'have', 'has', 'had', 'not', 'but', 'into', 'about', 'then', 'than', 'when', 'where', 'what', 'which', 'who', 'will', 'would', 'could', 'should']);
    const result = new Map<string, number>();
    for (const token of tokens) {
      if (stop.has(token) || token.length > 48) continue;
      result.set(token, Math.min(1_000, (result.get(token) || 0) + 1));
      if (result.size >= 4_000) break;
    }
    return result;
  }

  upsertKnowledgeRecord(ownerUid: string, input: KnowledgeRecordInput): { recordId: string; updatedAt: number; contentHash: string } {
    this.assertOpen();
    const validDomains: KnowledgeDomain[] = ['CONVERSATION', 'MEMORY', 'VAULT', 'PROJECT', 'GIDEON'];
    if (!ownerUid || ownerUid.length > 160) throw new TypeError('A valid owner UID is required.');
    if (!input || !validDomains.includes(input.domain)) throw new TypeError('Invalid knowledge domain.');
    if (typeof input.sourceId !== 'string' || !input.sourceId.trim() || input.sourceId.length > 200) throw new TypeError('A stable sourceId is required.');
    if (typeof input.title !== 'string' || !input.title.trim() || input.title.length > 300) throw new TypeError('Knowledge title must contain 1–300 characters.');
    if (typeof input.content !== 'string' || !input.content.trim() || input.content.length > 200_000) throw new TypeError('Knowledge content must contain 1–200000 characters.');
    if (input.projectId !== undefined && (typeof input.projectId !== 'string' || input.projectId.length > 180)) throw new TypeError('Invalid projectId.');
    const verificationStatus = input.verificationStatus || 'UNVERIFIED';
    if (!['VERIFIED', 'UNVERIFIED', 'INFERRED'].includes(verificationStatus)) throw new TypeError('Invalid verification status.');

    const recordId = sha256Hex(`${ownerUid}\n${input.domain}\n${input.sourceId}`).slice(0, 40);
    const occurredAt = Number.isFinite(input.occurredAt) ? Number(input.occurredAt) : Date.now();
    const updatedAt = Date.now();
    const payload = {
      domain: input.domain, sourceId: input.sourceId,
      ...(input.projectId ? { projectId: input.projectId } : {}),
      title: input.title.trim(), content: input.content,
      ...(input.sourceLabel ? { sourceLabel: input.sourceLabel.slice(0, 160) } : {}),
      verificationStatus, occurredAt,
      ...(input.metadata ? { metadata: input.metadata } : {})
    };
    const contentHash = sha256Hex(canonicalJson(payload));
    const encrypted = encryptPayload(this.encryptionKey, payload, canonicalJson(['lorin-knowledge-v1', recordId, ownerUid, input.domain, input.sourceId]));
    const termFrequency = this.tokenizeKnowledgeText(`${input.title}\n${input.content}`);

    this.transaction(() => {
      this.db.prepare(`INSERT INTO lorin_knowledge_records(record_id, owner_uid, domain, source_id, project_id, content_hash, payload_iv, payload_tag, payload_ciphertext, occurred_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(owner_uid, domain, source_id) DO UPDATE SET
          content_hash=excluded.content_hash, payload_iv=excluded.payload_iv, payload_tag=excluded.payload_tag,
          payload_ciphertext=excluded.payload_ciphertext, project_id=excluded.project_id,
          occurred_at=excluded.occurred_at, updated_at=excluded.updated_at`)
        .run(recordId, ownerUid, input.domain, input.sourceId, input.projectId || null, contentHash,
          encrypted.iv, encrypted.tag, encrypted.ciphertext, occurredAt, updatedAt);
      this.db.prepare('DELETE FROM lorin_knowledge_terms WHERE owner_uid = ? AND record_id = ?').run(ownerUid, recordId);
      const insertTerm = this.db.prepare('INSERT INTO lorin_knowledge_terms(owner_uid, record_id, term_hash, frequency) VALUES (?, ?, ?, ?)');
      for (const [token, frequency] of termFrequency) insertTerm.run(ownerUid, recordId, this.knowledgeTokenHash(token), frequency);
      this.appendAudit({ ownerUid, actorUid: ownerUid, action: 'knowledge.indexed', resource: `knowledge://${input.domain}/${input.sourceId}`,
        decision: 'INFO', reason: 'Knowledge record indexed with encrypted content and owner-scoped blind token hashes.',
        metadata: { recordId, domain: input.domain, sourceId: input.sourceId, contentHash } });
    });
    return { recordId, updatedAt, contentHash };
  }

  upsertKnowledgeRecords(ownerUid: string, records: KnowledgeRecordInput[]): Array<{ recordId: string; updatedAt: number; contentHash: string }> {
    if (!Array.isArray(records) || records.length > 50) throw new TypeError('A knowledge batch must contain at most 50 records.');
    return records.map(record => this.upsertKnowledgeRecord(ownerUid, record));
  }

  searchKnowledgeRecords(ownerUid: string, query: string, options: { projectId?: string; domains?: KnowledgeDomain[]; limit?: number } = {}): KnowledgeSearchResult[] {
    this.assertOpen();
    if (!ownerUid || typeof query !== 'string' || query.length > 500) return [];
    const tokens = [...this.tokenizeKnowledgeText(query).keys()].slice(0, 12);
    if (!tokens.length) return [];
    const hashes = tokens.map(token => this.knowledgeTokenHash(token));
    const placeholders = hashes.map(() => '?').join(',');
    const params: unknown[] = [ownerUid, ...hashes];
    let filters = '';
    if (options.projectId) { filters += ' AND r.project_id = ?'; params.push(options.projectId); }
    if (options.domains?.length) {
      const domains = options.domains.filter(domain => ['CONVERSATION', 'MEMORY', 'VAULT', 'PROJECT', 'GIDEON'].includes(domain)).slice(0, 5);
      if (domains.length) { filters += ` AND r.domain IN (${domains.map(() => '?').join(',')})`; params.push(...domains); }
    }
    const limit = Math.max(1, Math.min(50, Math.floor(options.limit || 8)));
    const rows = this.db.prepare(`SELECT r.*, SUM(t.frequency) AS score
      FROM lorin_knowledge_terms t JOIN lorin_knowledge_records r ON r.record_id=t.record_id AND r.owner_uid=t.owner_uid
      WHERE t.owner_uid = ? AND t.term_hash IN (${placeholders}) ${filters}
      GROUP BY r.record_id ORDER BY score DESC, r.updated_at DESC LIMIT ?`)
      .all(...params, limit) as any[];
    return rows.map(row => {
      const payload = decryptPayload<any>(this.encryptionKey, {
        iv: row.payload_iv, tag: row.payload_tag, ciphertext: row.payload_ciphertext
      }, canonicalJson(['lorin-knowledge-v1', row.record_id, row.owner_uid, row.domain, row.source_id]));
      const normalizedContent = String(payload.content || '');
      const queryLower = query.toLocaleLowerCase('en');
      const contentLower = normalizedContent.toLocaleLowerCase('en');
      const matchAt = contentLower.indexOf(queryLower);
      const center = matchAt >= 0 ? matchAt : 0;
      const start = Math.max(0, center - 180);
      const snippet = normalizedContent.slice(start, Math.min(normalizedContent.length, start + 640)).trim();
      return {
        recordId: row.record_id, domain: payload.domain, sourceId: payload.sourceId,
        projectId: payload.projectId, title: payload.title, snippet,
        verificationStatus: payload.verificationStatus || 'UNVERIFIED',
        occurredAt: payload.occurredAt, updatedAt: row.updated_at, score: Number(row.score) || 0,
        citation: { id: row.record_id, title: payload.title, domain: payload.domain, sourceId: payload.sourceId }
      } as KnowledgeSearchResult;
    });
  }

  deleteKnowledgeRecord(ownerUid: string, recordId: string): boolean {
    this.assertOpen();
    if (!ownerUid || !recordId) return false;
    return this.transaction(() => {
      const row = this.db.prepare('SELECT domain, source_id FROM lorin_knowledge_records WHERE owner_uid = ? AND record_id = ?').get(ownerUid, recordId) as any;
      if (!row) return false;
      this.db.prepare('DELETE FROM lorin_knowledge_terms WHERE owner_uid = ? AND record_id = ?').run(ownerUid, recordId);
      const result = this.db.prepare('DELETE FROM lorin_knowledge_records WHERE owner_uid = ? AND record_id = ?').run(ownerUid, recordId);
      this.appendAudit({ ownerUid, actorUid: ownerUid, action: 'knowledge.deleted', resource: `knowledge://${row.domain}/${row.source_id}`,
        decision: 'INFO', reason: 'Owner deleted a knowledge record and its blind search tokens.', metadata: { recordId } });
      return Number(result.changes) === 1;
    });
  }

  close(): void {
    if (!this.closed) {
      this.db.close();
      this.encryptionKey.fill(0);
      this.closed = true;
    }
  }
}

export function defaultLorinDatabasePath(): string {
  return resolve(process.env.LORIN_DATABASE_PATH || join(process.env.LORIN_DATA_DIR || join(homedir(), '.lorin', 'data'), 'lorin.sqlite'));
}
