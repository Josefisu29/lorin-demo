import { createHash, timingSafeEqual } from 'node:crypto';

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };

/**
 * Produces deterministic JSON for cryptographic action binding.
 * Rejects values JSON.stringify would silently erase or transform.
 */
export function canonicalJson(value: unknown): string {
  const seen = new WeakSet<object>();

  const normalize = (input: unknown, path: string): JsonValue => {
    if (input === null || typeof input === 'string' || typeof input === 'boolean') return input;
    if (typeof input === 'number') {
      if (!Number.isFinite(input)) throw new TypeError(`Non-finite number at ${path}`);
      return Object.is(input, -0) ? 0 : input;
    }
    if (typeof input !== 'object') {
      throw new TypeError(`Unsupported value at ${path}: ${typeof input}`);
    }
    if (seen.has(input as object)) throw new TypeError(`Circular value at ${path}`);
    seen.add(input as object);

    let result: JsonValue;
    if (Array.isArray(input)) {
      result = input.map((entry, index) => normalize(entry, `${path}[${index}]`));
    } else {
      const prototype = Object.getPrototypeOf(input);
      if (prototype !== Object.prototype && prototype !== null) {
        throw new TypeError(`Only plain objects are accepted at ${path}`);
      }
      const output: Record<string, JsonValue> = Object.create(null);
      for (const key of Object.keys(input as Record<string, unknown>).sort()) {
        const entry = (input as Record<string, unknown>)[key];
        if (entry === undefined) throw new TypeError(`Undefined value at ${path}.${key}`);
        output[key] = normalize(entry, `${path}.${key}`);
      }
      result = output;
    }
    seen.delete(input as object);
    return result;
  };

  return JSON.stringify(normalize(value, '$'));
}

export function sha256Hex(value: string | Uint8Array): string {
  return createHash('sha256').update(value).digest('hex');
}

export function actionDigest(input: {
  principalId: string;
  capabilityId: string;
  resource: string;
  parameters: unknown;
}): string {
  if (!input.principalId.trim() || !input.capabilityId.trim() || !input.resource.trim()) {
    throw new TypeError('principalId, capabilityId and resource are required for action binding');
  }
  const body = canonicalJson({
    principalId: input.principalId,
    capabilityId: input.capabilityId.trim().toLowerCase(),
    resource: input.resource,
    parameters: input.parameters
  });
  return sha256Hex(body);
}

export function constantTimeHexEqual(a: string, b: string): boolean {
  if (!/^[a-f0-9]+$/i.test(a) || !/^[a-f0-9]+$/i.test(b) || a.length !== b.length || a.length % 2 !== 0) {
    return false;
  }
  return timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));
}
