import type { CapabilityDefinition } from '../capabilities/registry.ts';

export interface PolicyPrincipal {
  id: string;
  authenticated: boolean;
  accountStatus: string;
  canonicalRole: string;
  permissions: readonly string[];
}

export interface PolicyContext {
  executionLocation: 'LOCAL' | 'CLOUD';
  resourceOwnerId: string;
  resourceScope?: string;
}

export interface PolicyDecision {
  allowed: boolean;
  requiresApproval: boolean;
  risk: CapabilityDefinition['risk'];
  reasons: string[];
  capabilityId: string;
}

const ACTIVE_ACCOUNT_STATES = new Set(['ACTIVE', 'ENABLED']);
const PRIVILEGED_ROLES = new Set(['SYSTEM_OWNER', 'SUPER_ADMIN']);
const APPROVAL_RISK = new Set(['MODERATE', 'HIGH', 'CRITICAL']);

/**
 * Evaluate from verified server principal + server-owned capability metadata.
 * Browser-supplied flags, model assertions and client role strings are never inputs.
 */
export function evaluateCapabilityPolicy(
  principal: PolicyPrincipal,
  capability: CapabilityDefinition,
  context: PolicyContext
): PolicyDecision {
  const reasons: string[] = [];
  const deny = (reason: string): PolicyDecision => ({
    allowed: false,
    requiresApproval: false,
    risk: capability.risk,
    reasons: [...reasons, reason],
    capabilityId: capability.id
  });

  if (!principal?.authenticated || !principal.id) return deny('A verified authenticated principal is required.');
  if (!ACTIVE_ACCOUNT_STATES.has(principal.accountStatus)) return deny('The account is not active.');
  if (!capability.enabled) return deny('This capability is disabled by server policy.');
  if (typeof capability.execute !== 'function') return deny('No trusted server executor is registered for this capability.');
  if (capability.localOnly && context.executionLocation !== 'LOCAL') return deny('This capability is restricted to the trusted local node.');
  if (!context.resourceOwnerId) return deny('A server-resolved resource owner is required.');
  if (context.resourceOwnerId !== principal.id && !PRIVILEGED_ROLES.has(principal.canonicalRole)) {
    return deny('The requested resource is outside this principal’s ownership scope.');
  }

  const missing = capability.requiredPermissions.filter(permission => !principal.permissions.includes(permission));
  if (missing.length) return deny(`Missing required permission(s): ${missing.join(', ')}.`);

  if (capability.risk === 'CRITICAL') {
    return deny('Critical-risk actions are disabled in this release and cannot be approved through this generic capability path.');
  }

  reasons.push('Identity, account state, capability status, scope and required permissions passed server-side checks.');
  const requiresApproval = Boolean(capability.requiresApproval) || APPROVAL_RISK.has(capability.risk);
  if (requiresApproval && !PRIVILEGED_ROLES.has(principal.canonicalRole)) {
    reasons.push('This action requires approval by an authorized owner or super administrator.');
  }
  return {
    allowed: true,
    requiresApproval,
    risk: capability.risk,
    reasons,
    capabilityId: capability.id
  };
}
