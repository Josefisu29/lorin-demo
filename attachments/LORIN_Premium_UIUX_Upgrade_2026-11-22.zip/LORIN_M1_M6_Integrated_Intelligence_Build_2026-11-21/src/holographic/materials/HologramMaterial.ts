/**
 * LORIN Holographic Engine — Physically Based Material & Optical Shader System (Sections 3.4 & 4.2)
 * Implements PBR skin with subsurface translucency, clear-coated cornea/iris eyes,
 * anisotropic groom hair layers, and Fresnel-iridescent holographic garment materials.
 */
import { Color3 } from '@babylonjs/core/Maths/math.color';
import { FresnelParameters } from '@babylonjs/core/Materials/fresnelParameters';
import { PBRMaterial } from '@babylonjs/core/Materials/PBR/pbrMaterial';
import { StandardMaterial } from '@babylonjs/core/Materials/standardMaterial';
import { Scene } from '@babylonjs/core/scene';
import { QualityProfileSettings } from '../core/QualityManager';
import { LorinCharacterState, LorinEnvironment } from '../../services/lorinPresence';

export interface LorinMaterialPalette {
  skinMat: PBRMaterial;
  lipMat: PBRMaterial;
  scleraMat: PBRMaterial;
  irisMat: PBRMaterial;
  pupilMat: PBRMaterial;
  corneaMat: PBRMaterial;
  hairMat: PBRMaterial;
  browMat: PBRMaterial;
  garmentMat: PBRMaterial;
  collarInnerMat: PBRMaterial;
  neuralAccentMat: StandardMaterial;
  projectionRingMat: StandardMaterial;
}

export function getStateAccentColor(state: LorinCharacterState, env: LorinEnvironment): Color3 {
  switch (state) {
    case 'ERROR':
    case 'DISCONNECTED':
      return Color3.FromHexString('#FB7185'); // Soft rose alert
    case 'NOTIFICATION':
      return Color3.FromHexString('#E8BE78'); // Warm amber attention
    case 'THINKING':
    case 'PROCESSING':
    case 'RESEARCHING':
      return Color3.FromHexString('#A9B8FF'); // Indigo-periwinkle analytical reasoning
    case 'SPEAKING':
    case 'LISTENING':
      return Color3.FromHexString('#66E3CB'); // Signature LORIN cyan-mint active voice
    case 'ANALYZING':
    case 'VISION_ACTIVE':
      return Color3.FromHexString('#7DD3FC'); // Optical sky cyan
    case 'CODING':
      return Color3.FromHexString('#5EEAD4'); // Precision engineering teal
    case 'IDLE':
    default:
      return env === 'research'
        ? Color3.FromHexString('#A9B8FF')
        : env === 'coding'
        ? Color3.FromHexString('#7CE8D3')
        : Color3.FromHexString('#66E3CB');
  }
}

export function createLorinMaterialPalette(
  scene: Scene,
  quality: QualityProfileSettings
): LorinMaterialPalette {
  // 1. Hybrid Digital-Human Skin PBR Material with Subsurface Translucency & Fresnel Rim
  const skinMat = new PBRMaterial('lorin_hybrid_skin_pbr', scene);
  skinMat.albedoColor = Color3.FromHexString('#D8E8E6');
  skinMat.metallic = 0.08;
  skinMat.roughness = 0.38;
  skinMat.alpha = 0.96;
  skinMat.emissiveColor = Color3.FromHexString('#132E35');
  skinMat.emissiveIntensity = 0.42;

  if (quality.enableSubsurfaceScattering) {
    skinMat.subSurface.isTranslucencyEnabled = true;
    skinMat.subSurface.translucencyIntensity = 0.65;
    skinMat.subSurface.tintColor = Color3.FromHexString('#74E3D0');
    skinMat.subSurface.minimumThickness = 0.1;
    skinMat.subSurface.maximumThickness = 1.8;
  }

  if (quality.enableIridescence) {
    skinMat.iridescence.isEnabled = true;
    skinMat.iridescence.intensity = 0.28;
    skinMat.iridescence.minimumThickness = 120;
    skinMat.iridescence.maximumThickness = 380;
  }

  // 2. Sculpted Lip Material (slightly warmer/smoother micro-roughness)
  const lipMat = new PBRMaterial('lorin_lip_pbr', scene);
  lipMat.albedoColor = Color3.FromHexString('#B5D4D6');
  lipMat.metallic = 0.12;
  lipMat.roughness = 0.26;
  lipMat.emissiveColor = Color3.FromHexString('#1B3F46');
  lipMat.emissiveIntensity = 0.45;
  if (quality.enableSubsurfaceScattering) {
    lipMat.subSurface.isTranslucencyEnabled = true;
    lipMat.subSurface.translucencyIntensity = 0.72;
    lipMat.subSurface.tintColor = Color3.FromHexString('#8CE5D7');
  }

  // 3. Eye Sclera Material
  const scleraMat = new PBRMaterial('lorin_eye_sclera_pbr', scene);
  scleraMat.albedoColor = Color3.FromHexString('#EFFAF8');
  scleraMat.metallic = 0.02;
  scleraMat.roughness = 0.14;
  scleraMat.emissiveColor = Color3.FromHexString('#23464A');
  scleraMat.emissiveIntensity = 0.35;

  // 4. Detailed Luminous Iris Material
  const irisMat = new PBRMaterial('lorin_eye_iris_pbr', scene);
  irisMat.albedoColor = Color3.FromHexString('#66E3CB');
  irisMat.metallic = 0.25;
  irisMat.roughness = 0.18;
  irisMat.emissiveColor = Color3.FromHexString('#48CBB3');
  irisMat.emissiveIntensity = 0.85;

  // 5. Deep Optical Pupil Material
  const pupilMat = new PBRMaterial('lorin_eye_pupil_pbr', scene);
  pupilMat.albedoColor = Color3.FromHexString('#050A0E');
  pupilMat.metallic = 0.05;
  pupilMat.roughness = 0.06;

  // 6. Wet Corneal ClearCoat Layer (Corneal Reflections)
  const corneaMat = new PBRMaterial('lorin_eye_cornea_pbr', scene);
  corneaMat.albedoColor = Color3.FromHexString('#FFFFFF');
  corneaMat.metallic = 0.0;
  corneaMat.roughness = 0.03;
  corneaMat.alpha = 0.22;
  if (quality.enableClearCoatEyes) {
    corneaMat.clearCoat.isEnabled = true;
    corneaMat.clearCoat.intensity = 1.0;
    corneaMat.clearCoat.roughness = 0.02;
  }

  // 7. Groom-Inspired Strand Hair Material
  const hairMat = new PBRMaterial('lorin_hair_groom_pbr', scene);
  hairMat.albedoColor = Color3.FromHexString('#1E3442');
  hairMat.metallic = 0.32;
  hairMat.roughness = 0.34;
  hairMat.emissiveColor = Color3.FromHexString('#183642');
  hairMat.emissiveIntensity = 0.5;
  if (quality.enableIridescence) {
    hairMat.anisotropy.isEnabled = true;
    hairMat.anisotropy.intensity = 0.65;
  }

  // 8. Eyebrow Material
  const browMat = new PBRMaterial('lorin_eyebrow_pbr', scene);
  browMat.albedoColor = Color3.FromHexString('#1B313E');
  browMat.metallic = 0.2;
  browMat.roughness = 0.42;
  browMat.emissiveColor = Color3.FromHexString('#244E59');
  browMat.emissiveIntensity = 0.4;

  // 9. Holographic Structured Upper Garment & Collar
  const garmentMat = new PBRMaterial('lorin_garment_pbr', scene);
  garmentMat.albedoColor = Color3.FromHexString('#162634');
  garmentMat.metallic = 0.58;
  garmentMat.roughness = 0.28;
  garmentMat.alpha = 0.92;
  garmentMat.emissiveColor = Color3.FromHexString('#102933');
  garmentMat.emissiveIntensity = 0.55;
  if (quality.enableIridescence) {
    garmentMat.iridescence.isEnabled = true;
    garmentMat.iridescence.intensity = 0.45;
  }

  const collarInnerMat = new PBRMaterial('lorin_collar_inner_pbr', scene);
  collarInnerMat.albedoColor = Color3.FromHexString('#0D1720');
  collarInnerMat.metallic = 0.45;
  collarInnerMat.roughness = 0.35;

  // 10. Neural Conduit & Temple Array Emissive Material with Fresnel Edge Illumination
  const neuralAccentMat = new StandardMaterial('lorin_neural_accent_mat', scene);
  neuralAccentMat.diffuseColor = Color3.FromHexString('#66E3CB');
  neuralAccentMat.emissiveColor = Color3.FromHexString('#66E3CB');
  neuralAccentMat.specularColor = Color3.FromHexString('#FFFFFF');
  neuralAccentMat.alpha = 0.86;
  const fresnel = new FresnelParameters();
  fresnel.bias = 0.25;
  fresnel.power = 2.2;
  fresnel.leftColor = Color3.FromHexString('#A9FFF0');
  fresnel.rightColor = Color3.FromHexString('#1D4B54');
  neuralAccentMat.emissiveFresnelParameters = fresnel;

  // 11. Spatial Projection Ring Material
  const projectionRingMat = new StandardMaterial('lorin_projection_ring_mat', scene);
  projectionRingMat.diffuseColor = Color3.FromHexString('#66E3CB');
  projectionRingMat.emissiveColor = Color3.FromHexString('#66E3CB');
  projectionRingMat.alpha = 0.42;
  projectionRingMat.backFaceCulling = false;

  return {
    skinMat,
    lipMat,
    scleraMat,
    irisMat,
    pupilMat,
    corneaMat,
    hairMat,
    browMat,
    garmentMat,
    collarInnerMat,
    neuralAccentMat,
    projectionRingMat
  };
}

export function updatePaletteForState(
  palette: LorinMaterialPalette,
  state: LorinCharacterState,
  env: LorinEnvironment,
  audioLevel: number
): void {
  const accent = getStateAccentColor(state, env);
  const pulseBoost = Math.min(0.45, (audioLevel / 100) * 0.45);

  palette.irisMat.emissiveColor = accent.scale(0.82 + pulseBoost * 0.35);
  palette.neuralAccentMat.emissiveColor = accent.scale(0.9 + pulseBoost * 0.3);
  palette.projectionRingMat.emissiveColor = accent.scale(0.75 + pulseBoost * 0.4);
  palette.projectionRingMat.alpha = Math.min(0.72, 0.34 + pulseBoost * 0.45);
}
