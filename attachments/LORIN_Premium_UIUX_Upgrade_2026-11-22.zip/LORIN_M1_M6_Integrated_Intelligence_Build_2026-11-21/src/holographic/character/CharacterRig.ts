/**
 * LORIN Holographic Engine — 3D Articulated Digital-Human Rig, Facial Blendshape Controller,
 * Eye Gaze/Blinking System, and Real-Time Viseme Lip-Sync Controller (Sections 3, 5 & 6)
 */
import { Mesh } from '@babylonjs/core/Meshes/mesh';
import { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder';
import { TransformNode } from '@babylonjs/core/Meshes/transformNode';
import { Vector3 } from '@babylonjs/core/Maths/math.vector';
import { Scene } from '@babylonjs/core/scene';
import { QualityProfileSettings } from '../core/QualityManager';
import { LorinMaterialPalette, updatePaletteForState } from '../materials/HologramMaterial';
import {
  FacialExpressionPreset,
  LorinCharacterState,
  LorinEnvironment,
  resolveExpressionForState
} from '../../services/lorinPresence';

export interface ExpressionTargetWeights {
  browRaiseLeft: number;
  browRaiseRight: number;
  browFurrow: number;
  eyeSquint: number;
  eyeWide: number;
  smileCorner: number;
  jawOpen: number;
  lipPucker: number;
  headPitch: number;
  headYaw: number;
  headRoll: number;
}

const EXPRESSION_PRESETS: Record<FacialExpressionPreset, ExpressionTargetWeights> = {
  neutral: {
    browRaiseLeft: 0.0,
    browRaiseRight: 0.0,
    browFurrow: 0.0,
    eyeSquint: 0.0,
    eyeWide: 0.0,
    smileCorner: 0.08,
    jawOpen: 0.0,
    lipPucker: 0.0,
    headPitch: 0.0,
    headYaw: 0.0,
    headRoll: 0.0
  },
  attentive: {
    browRaiseLeft: 0.18,
    browRaiseRight: 0.18,
    browFurrow: 0.0,
    eyeSquint: 0.05,
    eyeWide: 0.14,
    smileCorner: 0.14,
    jawOpen: 0.0,
    lipPucker: 0.0,
    headPitch: -0.03,
    headYaw: 0.0,
    headRoll: 0.02
  },
  listening: {
    browRaiseLeft: 0.22,
    browRaiseRight: 0.2,
    browFurrow: 0.0,
    eyeSquint: 0.08,
    eyeWide: 0.12,
    smileCorner: 0.16,
    jawOpen: 0.02,
    lipPucker: 0.0,
    headPitch: 0.03,
    headYaw: 0.04,
    headRoll: 0.045
  },
  thinking: {
    browRaiseLeft: 0.12,
    browRaiseRight: -0.05,
    browFurrow: 0.28,
    eyeSquint: 0.18,
    eyeWide: 0.0,
    smileCorner: 0.02,
    jawOpen: 0.0,
    lipPucker: 0.12,
    headPitch: -0.04,
    headYaw: -0.07,
    headRoll: -0.025
  },
  speaking: {
    browRaiseLeft: 0.16,
    browRaiseRight: 0.16,
    browFurrow: 0.05,
    eyeSquint: 0.06,
    eyeWide: 0.08,
    smileCorner: 0.15,
    jawOpen: 0.25,
    lipPucker: 0.08,
    headPitch: 0.0,
    headYaw: 0.0,
    headRoll: 0.0
  },
  confident: {
    browRaiseLeft: 0.14,
    browRaiseRight: 0.12,
    browFurrow: 0.0,
    eyeSquint: 0.1,
    eyeWide: 0.05,
    smileCorner: 0.24,
    jawOpen: 0.0,
    lipPucker: 0.0,
    headPitch: -0.02,
    headYaw: 0.02,
    headRoll: 0.015
  },
  friendly: {
    browRaiseLeft: 0.2,
    browRaiseRight: 0.2,
    browFurrow: 0.0,
    eyeSquint: 0.14,
    eyeWide: 0.08,
    smileCorner: 0.3,
    jawOpen: 0.03,
    lipPucker: 0.0,
    headPitch: 0.01,
    headYaw: 0.0,
    headRoll: 0.03
  },
  serious: {
    browRaiseLeft: -0.04,
    browRaiseRight: -0.04,
    browFurrow: 0.32,
    eyeSquint: 0.2,
    eyeWide: 0.0,
    smileCorner: 0.0,
    jawOpen: 0.0,
    lipPucker: 0.05,
    headPitch: 0.025,
    headYaw: 0.0,
    headRoll: 0.0
  },
  acknowledgement: {
    browRaiseLeft: 0.24,
    browRaiseRight: 0.24,
    browFurrow: 0.0,
    eyeSquint: 0.08,
    eyeWide: 0.15,
    smileCorner: 0.2,
    jawOpen: 0.0,
    lipPucker: 0.0,
    headPitch: 0.06,
    headYaw: 0.0,
    headRoll: 0.02
  },
  concern: {
    browRaiseLeft: 0.18,
    browRaiseRight: 0.18,
    browFurrow: 0.38,
    eyeSquint: 0.12,
    eyeWide: 0.0,
    smileCorner: -0.1,
    jawOpen: 0.02,
    lipPucker: 0.06,
    headPitch: 0.03,
    headYaw: -0.03,
    headRoll: -0.02
  }
};

export class LorinDigitalHumanRig {
  public readonly rootNode: TransformNode;
  public readonly chestNode: TransformNode;
  public readonly neckNode: TransformNode;
  public readonly headNode: TransformNode;
  public readonly jawNode: TransformNode;

  private readonly eyeLeftGroup: TransformNode;
  private readonly eyeRightGroup: TransformNode;
  private readonly upperEyelidLeft: Mesh;
  private readonly upperEyelidRight: Mesh;
  private readonly lowerEyelidLeft: Mesh;
  private readonly lowerEyelidRight: Mesh;
  private readonly browLeft: Mesh;
  private readonly browRight: Mesh;
  private readonly upperLip: Mesh;
  private readonly lowerLip: Mesh;
  private readonly outerRing1: Mesh;
  private readonly outerRing2: Mesh;
  private readonly shoulderLeftNode: TransformNode;
  private readonly shoulderRightNode: TransformNode;
  private readonly shadowCasters: Mesh[] = [];

  private currentWeights: ExpressionTargetWeights = { ...EXPRESSION_PRESETS.neutral };
  private blinkTimer = 0;
  private nextBlinkInterval = 3.4;
  private blinkProgress = 0;
  private isBlinking = false;

  private saccadeTimer = 0;
  private nextSaccadeInterval = 2.1;
  private targetGazeX = 0;
  private targetGazeY = 0;
  private currentGazeX = 0;
  private currentGazeY = 0;
  private pointerGazeX = 0;
  private pointerGazeY = 0;
  private visemePhase = 0;

  constructor(
    private readonly scene: Scene,
    private readonly palette: LorinMaterialPalette,
    private readonly quality: QualityProfileSettings
  ) {
    const segs = quality.meshSubdivisions;

    this.rootNode = new TransformNode('lorin_rig_root', scene);
    this.chestNode = new TransformNode('lorin_chest_node', scene);
    this.chestNode.parent = this.rootNode;
    this.chestNode.position = new Vector3(0, -0.78, 0);

    // 1. Upper Torso & Structured Holographic Coat
    const torsoCore = MeshBuilder.CreateCylinder(
      'lorin_torso_core',
      { height: 0.92, diameterTop: 0.72, diameterBottom: 1.18, tessellation: segs },
      scene
    );
    torsoCore.parent = this.chestNode;
    torsoCore.position = new Vector3(0, -0.18, 0.02);
    torsoCore.scaling = new Vector3(1.18, 1.0, 0.62);
    torsoCore.material = palette.garmentMat;
    this.shadowCasters.push(torsoCore);

    // Sculpted Shoulders
    this.shoulderLeftNode = new TransformNode('lorin_shoulder_left', scene);
    this.shoulderLeftNode.parent = this.chestNode;
    this.shoulderLeftNode.position = new Vector3(-0.56, 0.14, 0.02);

    const shoulderLeftMesh = MeshBuilder.CreateSphere(
      'lorin_shoulder_left_mesh',
      { diameterX: 0.44, diameterY: 0.34, diameterZ: 0.38, segments: segs },
      scene
    );
    shoulderLeftMesh.parent = this.shoulderLeftNode;
    shoulderLeftMesh.material = palette.garmentMat;

    this.shoulderRightNode = new TransformNode('lorin_shoulder_right', scene);
    this.shoulderRightNode.parent = this.chestNode;
    this.shoulderRightNode.position = new Vector3(0.56, 0.14, 0.02);

    const shoulderRightMesh = MeshBuilder.CreateSphere(
      'lorin_shoulder_right_mesh',
      { diameterX: 0.44, diameterY: 0.34, diameterZ: 0.38, segments: segs },
      scene
    );
    shoulderRightMesh.parent = this.shoulderRightNode;
    shoulderRightMesh.material = palette.garmentMat;

    // High Collar & Neural Conduit Trim
    const collarOuter = MeshBuilder.CreateTorus(
      'lorin_collar_outer',
      { diameter: 0.56, thickness: 0.085, tessellation: segs },
      scene
    );
    collarOuter.parent = this.chestNode;
    collarOuter.position = new Vector3(0, 0.29, 0.01);
    collarOuter.rotation.x = Math.PI * 0.08;
    collarOuter.scaling = new Vector3(1.08, 1.0, 0.88);
    collarOuter.material = palette.collarInnerMat;

    const collarNeuralRing = MeshBuilder.CreateTorus(
      'lorin_collar_neural_ring',
      { diameter: 0.59, thickness: 0.016, tessellation: segs },
      scene
    );
    collarNeuralRing.parent = this.chestNode;
    collarNeuralRing.position = new Vector3(0, 0.31, 0.02);
    collarNeuralRing.rotation.x = Math.PI * 0.08;
    collarNeuralRing.scaling = new Vector3(1.08, 1.0, 0.88);
    collarNeuralRing.material = palette.neuralAccentMat;

    // 2. Articulated Neck & Clavicle Base
    this.neckNode = new TransformNode('lorin_neck_node', scene);
    this.neckNode.parent = this.chestNode;
    this.neckNode.position = new Vector3(0, 0.34, 0.0);

    const neckMesh = MeshBuilder.CreateCylinder(
      'lorin_neck_mesh',
      { height: 0.38, diameterTop: 0.29, diameterBottom: 0.34, tessellation: segs },
      scene
    );
    neckMesh.parent = this.neckNode;
    neckMesh.position = new Vector3(0, 0.14, -0.01);
    neckMesh.material = palette.skinMat;
    this.shadowCasters.push(neckMesh);

    // 3. Sculpted Digital-Human Head & Cranial Anatomy
    this.headNode = new TransformNode('lorin_head_node', scene);
    this.headNode.parent = this.neckNode;
    this.headNode.position = new Vector3(0, 0.52, 0.03);

    // Upper cranium & facial ovoid
    const cranium = MeshBuilder.CreateSphere(
      'lorin_cranium',
      { diameterX: 0.64, diameterY: 0.78, diameterZ: 0.68, segments: segs },
      scene
    );
    cranium.parent = this.headNode;
    cranium.position = new Vector3(0, 0.06, -0.02);
    cranium.material = palette.skinMat;
    this.shadowCasters.push(cranium);

    // Lower Face / Cheekbones & Sculpted Jaw Contour
    const midFace = MeshBuilder.CreateSphere(
      'lorin_midface',
      { diameterX: 0.58, diameterY: 0.52, diameterZ: 0.56, segments: segs },
      scene
    );
    midFace.parent = this.headNode;
    midFace.position = new Vector3(0, -0.08, 0.05);
    midFace.material = palette.skinMat;

    // Left & Right Zygomatic Cheekbones for natural facial planes
    const cheekLeft = MeshBuilder.CreateSphere(
      'lorin_cheek_left',
      { diameterX: 0.22, diameterY: 0.21, diameterZ: 0.22, segments: Math.max(16, segs - 8) },
      scene
    );
    cheekLeft.parent = this.headNode;
    cheekLeft.position = new Vector3(-0.17, -0.04, 0.21);
    cheekLeft.material = palette.skinMat;

    const cheekRight = MeshBuilder.CreateSphere(
      'lorin_cheek_right',
      { diameterX: 0.22, diameterY: 0.21, diameterZ: 0.22, segments: Math.max(16, segs - 8) },
      scene
    );
    cheekRight.parent = this.headNode;
    cheekRight.position = new Vector3(0.17, -0.04, 0.21);
    cheekRight.material = palette.skinMat;

    // Articulated Jaw & Chin Node
    this.jawNode = new TransformNode('lorin_jaw_node', scene);
    this.jawNode.parent = this.headNode;
    this.jawNode.position = new Vector3(0, -0.16, 0.06);

    const chinMesh = MeshBuilder.CreateSphere(
      'lorin_chin_mesh',
      { diameterX: 0.38, diameterY: 0.28, diameterZ: 0.38, segments: segs },
      scene
    );
    chinMesh.parent = this.jawNode;
    chinMesh.position = new Vector3(0, -0.09, 0.09);
    chinMesh.material = palette.skinMat;

    // 4. Sculpted Nose Bridge & Tip
    const noseBridge = MeshBuilder.CreateCylinder(
      'lorin_nose_bridge',
      { height: 0.19, diameterTop: 0.046, diameterBottom: 0.078, tessellation: 20 },
      scene
    );
    noseBridge.parent = this.headNode;
    noseBridge.position = new Vector3(0, -0.01, 0.31);
    noseBridge.rotation.x = -0.22;
    noseBridge.material = palette.skinMat;

    const noseTip = MeshBuilder.CreateSphere(
      'lorin_nose_tip',
      { diameterX: 0.082, diameterY: 0.068, diameterZ: 0.088, segments: 20 },
      scene
    );
    noseTip.parent = this.headNode;
    noseTip.position = new Vector3(0, -0.088, 0.342);
    noseTip.material = palette.skinMat;

    // 5. Realistic Multi-Layer Eyes (Sclera + Iris + Pupil + Wet ClearCoat Cornea + Eyelids)
    const buildEyeAssembly = (side: 'left' | 'right'): {
      eyeGroup: TransformNode;
      upperLid: Mesh;
      lowerLid: Mesh;
    } => {
      const sign = side === 'left' ? -1 : 1;
      const socketPos = new Vector3(sign * 0.132, 0.048, 0.258);

      const eyeGroup = new TransformNode(`lorin_eye_group_${side}`, scene);
      eyeGroup.parent = this.headNode;
      eyeGroup.position = socketPos.clone();

      const sclera = MeshBuilder.CreateSphere(
        `lorin_sclera_${side}`,
        { diameter: 0.096, segments: 24 },
        scene
      );
      sclera.parent = eyeGroup;
      sclera.material = palette.scleraMat;

      const iris = MeshBuilder.CreateDisc(
        `lorin_iris_${side}`,
        { radius: 0.026, tessellation: 28 },
        scene
      );
      iris.parent = eyeGroup;
      iris.position = new Vector3(0, 0, 0.045);
      iris.material = palette.irisMat;

      const pupil = MeshBuilder.CreateDisc(
        `lorin_pupil_${side}`,
        { radius: 0.011, tessellation: 24 },
        scene
      );
      pupil.parent = eyeGroup;
      pupil.position = new Vector3(0, 0, 0.0465);
      pupil.material = palette.pupilMat;

      const cornea = MeshBuilder.CreateSphere(
        `lorin_cornea_${side}`,
        { diameter: 0.101, segments: 24 },
        scene
      );
      cornea.parent = eyeGroup;
      cornea.position = new Vector3(0, 0, 0.003);
      cornea.material = palette.corneaMat;

      // Upper & Lower Eyelids (parented to headNode around the eye socket)
      const upperLid = MeshBuilder.CreateSphere(
        `lorin_upper_lid_${side}`,
        { diameterX: 0.112, diameterY: 0.056, diameterZ: 0.106, segments: 20, slice: 0.55 },
        scene
      );
      upperLid.parent = this.headNode;
      upperLid.position = socketPos.add(new Vector3(0, 0.022, 0.004));
      upperLid.rotation.x = -0.18;
      upperLid.material = palette.skinMat;

      const lowerLid = MeshBuilder.CreateSphere(
        `lorin_lower_lid_${side}`,
        { diameterX: 0.108, diameterY: 0.042, diameterZ: 0.102, segments: 20, slice: 0.5 },
        scene
      );
      lowerLid.parent = this.headNode;
      lowerLid.position = socketPos.add(new Vector3(0, -0.026, 0.003));
      lowerLid.rotation.z = Math.PI;
      lowerLid.rotation.x = 0.12;
      lowerLid.material = palette.skinMat;

      return { eyeGroup, upperLid, lowerLid };
    };

    const leftEye = buildEyeAssembly('left');
    const rightEye = buildEyeAssembly('right');
    this.eyeLeftGroup = leftEye.eyeGroup;
    this.eyeRightGroup = rightEye.eyeGroup;
    this.upperEyelidLeft = leftEye.upperLid;
    this.upperEyelidRight = rightEye.upperLid;
    this.lowerEyelidLeft = leftEye.lowerLid;
    this.lowerEyelidRight = rightEye.lowerLid;

    // 6. Articulated Eyebrows
    this.browLeft = MeshBuilder.CreateCapsule(
      'lorin_brow_left',
      { height: 0.135, radius: 0.014, tessellation: 16 },
      scene
    );
    this.browLeft.parent = this.headNode;
    this.browLeft.position = new Vector3(-0.135, 0.115, 0.285);
    this.browLeft.rotation.z = Math.PI * 0.47;
    this.browLeft.rotation.y = -0.18;
    this.browLeft.material = palette.browMat;

    this.browRight = MeshBuilder.CreateCapsule(
      'lorin_brow_right',
      { height: 0.135, radius: 0.014, tessellation: 16 },
      scene
    );
    this.browRight.parent = this.headNode;
    this.browRight.position = new Vector3(0.135, 0.115, 0.285);
    this.browRight.rotation.z = -Math.PI * 0.47;
    this.browRight.rotation.y = 0.18;
    this.browRight.material = palette.browMat;

    // 7. Lips & Mouth Geometry (Viseme-Driven)
    this.upperLip = MeshBuilder.CreateCapsule(
      'lorin_upper_lip',
      { height: 0.145, radius: 0.018, tessellation: 20 },
      scene
    );
    this.upperLip.parent = this.headNode;
    this.upperLip.position = new Vector3(0, -0.158, 0.296);
    this.upperLip.rotation.z = Math.PI * 0.5;
    this.upperLip.scaling = new Vector3(0.85, 1.0, 1.15);
    this.upperLip.material = palette.lipMat;

    this.lowerLip = MeshBuilder.CreateCapsule(
      'lorin_lower_lip',
      { height: 0.138, radius: 0.02, tessellation: 20 },
      scene
    );
    this.lowerLip.parent = this.jawNode;
    this.lowerLip.position = new Vector3(0, -0.022, 0.232);
    this.lowerLip.rotation.z = Math.PI * 0.5;
    this.lowerLip.scaling = new Vector3(0.9, 1.0, 1.15);
    this.lowerLip.material = palette.lipMat;

    // 8. Multi-Volume Groomed Hair Cap & Swept Strands
    const hairCrown = MeshBuilder.CreateSphere(
      'lorin_hair_crown',
      { diameterX: 0.685, diameterY: 0.76, diameterZ: 0.72, segments: segs, slice: 0.64 },
      scene
    );
    hairCrown.parent = this.headNode;
    hairCrown.position = new Vector3(0, 0.11, -0.035);
    hairCrown.rotation.x = -0.18;
    hairCrown.material = palette.hairMat;
    this.shadowCasters.push(hairCrown);

    if (quality.enableHairStrandLayers) {
      const hairSweepLeft = MeshBuilder.CreateCapsule(
        'lorin_hair_sweep_left',
        { height: 0.46, radius: 0.095, tessellation: 20 },
        scene
      );
      hairSweepLeft.parent = this.headNode;
      hairSweepLeft.position = new Vector3(-0.26, 0.08, 0.07);
      hairSweepLeft.rotation.z = -0.34;
      hairSweepLeft.rotation.x = 0.22;
      hairSweepLeft.material = palette.hairMat;

      const hairSweepRight = MeshBuilder.CreateCapsule(
        'lorin_hair_sweep_right',
        { height: 0.44, radius: 0.09, tessellation: 20 },
        scene
      );
      hairSweepRight.parent = this.headNode;
      hairSweepRight.position = new Vector3(0.26, 0.09, 0.06);
      hairSweepRight.rotation.z = 0.36;
      hairSweepRight.rotation.x = 0.2;
      hairSweepRight.material = palette.hairMat;
    }

    // 9. Hybrid AI Temple Neural Interface Arrays (Subtle, Signature LORIN Identity)
    const templeLeft = MeshBuilder.CreateTorus(
      'lorin_temple_array_left',
      { diameter: 0.11, thickness: 0.012, tessellation: 24 },
      scene
    );
    templeLeft.parent = this.headNode;
    templeLeft.position = new Vector3(-0.315, 0.03, 0.04);
    templeLeft.rotation.z = Math.PI * 0.5;
    templeLeft.material = palette.neuralAccentMat;

    const templeRight = MeshBuilder.CreateTorus(
      'lorin_temple_array_right',
      { diameter: 0.11, thickness: 0.012, tessellation: 24 },
      scene
    );
    templeRight.parent = this.headNode;
    templeRight.position = new Vector3(0.315, 0.03, 0.04);
    templeRight.rotation.z = Math.PI * 0.5;
    templeRight.material = palette.neuralAccentMat;

    // 10. Spatial Holographic Projection Pedestal Rings
    this.outerRing1 = MeshBuilder.CreateTorus(
      'lorin_proj_ring_1',
      { diameter: 1.48, thickness: 0.012, tessellation: 48 },
      scene
    );
    this.outerRing1.parent = this.rootNode;
    this.outerRing1.position = new Vector3(0, -1.16, 0);
    this.outerRing1.material = palette.projectionRingMat;

    this.outerRing2 = MeshBuilder.CreateTorus(
      'lorin_proj_ring_2',
      { diameter: 1.76, thickness: 0.007, tessellation: 48 },
      scene
    );
    this.outerRing2.parent = this.rootNode;
    this.outerRing2.position = new Vector3(0, -1.21, 0);
    this.outerRing2.material = palette.projectionRingMat;
  }

  public getShadowCasters(): Mesh[] {
    return this.shadowCasters;
  }

  public setPointerGazeOffset(normalizedX: number, normalizedY: number): void {
    this.pointerGazeX = Math.max(-1, Math.min(1, normalizedX)) * 0.12;
    this.pointerGazeY = Math.max(-1, Math.min(1, normalizedY)) * 0.08;
  }

  /**
   * Advances character breathing, blinking, saccadic eye movement, expression blending,
   * and audio/speech-synchronized viseme jaw & lip articulation.
   */
  public updateFrame(
    dtSeconds: number,
    timeSeconds: number,
    state: LorinCharacterState,
    env: LorinEnvironment,
    audioLevel: number,
    isActivelySpeaking: boolean,
    prefersReducedMotion: boolean
  ): void {
    const dt = Math.min(0.1, Math.max(0.001, dtSeconds));
    const motionScale = prefersReducedMotion ? 0.15 : 1.0;

    // 1. Update material accents based on real assistant state & audio level
    updatePaletteForState(this.palette, state, env, audioLevel);

    // 2. Smoothly blend facial expression weights toward target state preset
    const targetPresetName = resolveExpressionForState(state);
    const target = EXPRESSION_PRESETS[targetPresetName];
    const blendRate = Math.min(1, dt * 6.5);

    (Object.keys(target) as Array<keyof ExpressionTargetWeights>).forEach(k => {
      this.currentWeights[k] += (target[k] - this.currentWeights[k]) * blendRate;
    });

    // 3. Natural Breathing & Upper-Body Micro-Posture
    const breathWave = Math.sin(timeSeconds * 1.85) * 0.014 * motionScale;
    const secondaryWave = Math.cos(timeSeconds * 0.92) * 0.008 * motionScale;
    this.chestNode.position.y = -0.78 + breathWave;
    this.shoulderLeftNode.position.y = 0.14 + breathWave * 0.65;
    this.shoulderRightNode.position.y = 0.14 + breathWave * 0.65;

    // 4. Head & Neck Orientation (blending preset posture + organic micro-drift)
    const idleYaw = Math.sin(timeSeconds * 0.55) * 0.032 * motionScale;
    const idlePitch = Math.cos(timeSeconds * 0.72) * 0.018 * motionScale;
    const listeningNod =
      state === 'LISTENING' ? Math.sin(timeSeconds * 3.1) * 0.022 * motionScale : 0;

    this.headNode.rotation.y =
      this.currentWeights.headYaw + idleYaw + this.pointerGazeX * 0.35;
    this.headNode.rotation.x =
      this.currentWeights.headPitch + idlePitch + listeningNod - this.pointerGazeY * 0.25;
    this.headNode.rotation.z = this.currentWeights.headRoll + secondaryWave;

    // 5. Saccadic Eye Gaze & Focusing
    this.saccadeTimer += dt;
    if (this.saccadeTimer >= this.nextSaccadeInterval) {
      this.saccadeTimer = 0;
      this.nextSaccadeInterval = 1.6 + Math.random() * 2.4;
      if (state === 'LISTENING' || state === 'SPEAKING') {
        // Maintain stronger eye contact during active conversation
        this.targetGazeX = (Math.random() - 0.5) * 0.04;
        this.targetGazeY = (Math.random() - 0.5) * 0.03;
      } else if (state === 'THINKING' || state === 'RESEARCHING') {
        this.targetGazeX = (Math.random() - 0.5) * 0.12;
        this.targetGazeY = 0.03 + (Math.random() - 0.5) * 0.06;
      } else {
        this.targetGazeX = (Math.random() - 0.5) * 0.08;
        this.targetGazeY = (Math.random() - 0.5) * 0.05;
      }
    }

    const gazeBlend = Math.min(1, dt * 10);
    this.currentGazeX += (this.targetGazeX + this.pointerGazeX - this.currentGazeX) * gazeBlend;
    this.currentGazeY += (this.targetGazeY - this.pointerGazeY - this.currentGazeY) * gazeBlend;

    this.eyeLeftGroup.rotation.y = this.currentGazeX;
    this.eyeRightGroup.rotation.y = this.currentGazeX;
    this.eyeLeftGroup.rotation.x = this.currentGazeY;
    this.eyeRightGroup.rotation.x = this.currentGazeY;

    // 6. Natural Eyelid Blinking
    this.blinkTimer += dt;
    if (!this.isBlinking && this.blinkTimer >= this.nextBlinkInterval) {
      this.isBlinking = true;
      this.blinkTimer = 0;
      this.blinkProgress = 0;
      this.nextBlinkInterval = 2.6 + Math.random() * 3.1;
    }

    let lidClosure = this.currentWeights.eyeSquint * 0.25 - this.currentWeights.eyeWide * 0.18;
    if (this.isBlinking) {
      this.blinkProgress += dt * 9.5;
      if (this.blinkProgress >= Math.PI) {
        this.isBlinking = false;
        this.blinkProgress = 0;
      } else {
        lidClosure = Math.max(lidClosure, Math.sin(this.blinkProgress));
      }
    }
    lidClosure = Math.max(-0.12, Math.min(1.0, lidClosure));

    this.upperEyelidLeft.position.y = 0.048 + 0.022 * (1 - lidClosure * 0.85);
    this.upperEyelidRight.position.y = 0.048 + 0.022 * (1 - lidClosure * 0.85);
    this.lowerEyelidLeft.position.y = 0.048 - 0.026 * (1 - lidClosure * 0.45);
    this.lowerEyelidRight.position.y = 0.048 - 0.026 * (1 - lidClosure * 0.45);

    // 7. Eyebrow Articulation
    const furrowOffset = this.currentWeights.browFurrow * 0.014;
    this.browLeft.position.y = 0.115 + this.currentWeights.browRaiseLeft * 0.024 - furrowOffset * 0.5;
    this.browRight.position.y = 0.115 + this.currentWeights.browRaiseRight * 0.024 - furrowOffset * 0.5;
    this.browLeft.rotation.z = Math.PI * 0.47 - this.currentWeights.browFurrow * 0.14;
    this.browRight.rotation.z = -Math.PI * 0.47 + this.currentWeights.browFurrow * 0.14;

    // 8. Audio-Reactive & Speech-Synchronized Viseme Lip-Sync (Section 5.2)
    // Only animate speech visemes when actual voice output or audio playback is active.
    let jawOpenAmount = 0;
    let lipWidthScale = 0.88 + this.currentWeights.smileCorner * 0.28;

    if (isActivelySpeaking || state === 'SPEAKING') {
      this.visemePhase += dt * 15.5;
      const normalizedAudio = audioLevel > 2 ? Math.min(1, audioLevel / 75) : 0.48;
      const syllableEnvelope =
        (Math.sin(this.visemePhase) * 0.5 + 0.5) * 0.65 +
        (Math.sin(this.visemePhase * 2.3 + 1.1) * 0.5 + 0.5) * 0.35;
      jawOpenAmount = normalizedAudio * syllableEnvelope * 0.042;
      const vowelRounding = Math.cos(this.visemePhase * 1.4) * 0.12 * normalizedAudio;
      lipWidthScale = Math.max(0.74, Math.min(1.12, lipWidthScale + vowelRounding));
    }

    this.jawNode.position.y = -0.16 - jawOpenAmount;
    this.jawNode.rotation.x = jawOpenAmount * 1.85;
    this.upperLip.scaling.y = 0.85 * lipWidthScale;
    this.lowerLip.scaling.y = 0.9 * lipWidthScale;

    // 9. Subtle Spatial Pedestal Ring Rotation
    this.outerRing1.rotation.y = timeSeconds * 0.24 * motionScale;
    this.outerRing2.rotation.y = -timeSeconds * 0.16 * motionScale;
  }
}
