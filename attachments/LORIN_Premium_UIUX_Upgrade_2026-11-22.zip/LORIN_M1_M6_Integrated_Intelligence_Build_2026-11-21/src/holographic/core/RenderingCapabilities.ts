/**
 * LORIN Holographic Engine — Hardware & Graphics Capability Detector (Section 2.2 & 13)
 * Detects WebGPU, WebGL 2, WebGL 1, reduced-motion, device memory, and form factor.
 */

export type ActiveRendererBackend = 'WebGPU' | 'WebGL2' | 'WebGL1' | 'SVG_Fallback' | 'UnrealPixelStream';

export interface RenderingCapabilitiesReport {
  webgpuSupported: boolean;
  webgpuAdapterAvailable: boolean;
  webgl2Supported: boolean;
  webgl1Supported: boolean;
  preferredNativeBackend: ActiveRendererBackend;
  devicePixelRatio: number;
  hardwareConcurrency: number;
  deviceMemoryGb: number;
  isMobileViewport: boolean;
  prefersReducedMotion: boolean;
  maxTextureSize: number;
  gpuVendorHint: string;
}

let cachedCapabilities: RenderingCapabilitiesReport | null = null;

export function detectRenderingCapabilitiesSync(): RenderingCapabilitiesReport {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return {
      webgpuSupported: false,
      webgpuAdapterAvailable: false,
      webgl2Supported: false,
      webgl1Supported: false,
      preferredNativeBackend: 'SVG_Fallback',
      devicePixelRatio: 1,
      hardwareConcurrency: 4,
      deviceMemoryGb: 8,
      isMobileViewport: false,
      prefersReducedMotion: false,
      maxTextureSize: 4096,
      gpuVendorHint: 'Server / Headless'
    };
  }

  const nav = window.navigator as Navigator & {
    gpu?: { requestAdapter?: () => Promise<unknown> };
    deviceMemory?: number;
  };

  const webgpuSupported = Boolean(nav && 'gpu' in nav && typeof nav.gpu?.requestAdapter === 'function');
  let webgl2Supported = false;
  let webgl1Supported = false;
  let maxTextureSize = 2048;
  let gpuVendorHint = 'Browser GPU';

  try {
    const canvas = document.createElement('canvas');
    const gl2 = canvas.getContext('webgl2');
    if (gl2) {
      webgl2Supported = true;
      webgl1Supported = true;
      maxTextureSize = Number(gl2.getParameter(gl2.MAX_TEXTURE_SIZE)) || 4096;
      const dbg = gl2.getExtension('WEBGL_debug_renderer_info');
      if (dbg) {
        gpuVendorHint = String(gl2.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || 'WebGL2 GPU');
      }
    } else {
      const gl1 = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (gl1) {
        webgl1Supported = true;
      }
    }
  } catch {
    // Headless or restricted canvas context
  }

  const prefersReducedMotion =
    typeof window.matchMedia === 'function' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const isMobileViewport =
    window.innerWidth < 768 ||
    (typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches);

  const preferredNativeBackend: ActiveRendererBackend = webgpuSupported
    ? 'WebGPU'
    : webgl2Supported
    ? 'WebGL2'
    : webgl1Supported
    ? 'WebGL1'
    : 'SVG_Fallback';

  const report: RenderingCapabilitiesReport = {
    webgpuSupported,
    webgpuAdapterAvailable: cachedCapabilities?.webgpuAdapterAvailable ?? false,
    webgl2Supported,
    webgl1Supported,
    preferredNativeBackend,
    devicePixelRatio: Math.min(window.devicePixelRatio || 1, 2.5),
    hardwareConcurrency: nav?.hardwareConcurrency || 4,
    deviceMemoryGb: nav?.deviceMemory || 8,
    isMobileViewport,
    prefersReducedMotion,
    maxTextureSize,
    gpuVendorHint
  };

  cachedCapabilities = report;
  return report;
}

export async function probeRenderingCapabilitiesAsync(): Promise<RenderingCapabilitiesReport> {
  const base = detectRenderingCapabilitiesSync();
  if (!base.webgpuSupported || typeof window === 'undefined') {
    return base;
  }

  try {
    const nav = window.navigator as Navigator & {
      gpu?: { requestAdapter?: (options?: { powerPreference?: string }) => Promise<unknown | null> };
    };
    const adapter = await nav.gpu?.requestAdapter?.({ powerPreference: 'high-performance' });
    const hasAdapter = Boolean(adapter);
    cachedCapabilities = {
      ...base,
      webgpuAdapterAvailable: hasAdapter,
      preferredNativeBackend: hasAdapter
        ? 'WebGPU'
        : base.webgl2Supported
        ? 'WebGL2'
        : base.webgl1Supported
        ? 'WebGL1'
        : 'SVG_Fallback'
    };
    return cachedCapabilities;
  } catch {
    cachedCapabilities = {
      ...base,
      webgpuAdapterAvailable: false,
      preferredNativeBackend: base.webgl2Supported
        ? 'WebGL2'
        : base.webgl1Supported
        ? 'WebGL1'
        : 'SVG_Fallback'
    };
    return cachedCapabilities;
  }
}
