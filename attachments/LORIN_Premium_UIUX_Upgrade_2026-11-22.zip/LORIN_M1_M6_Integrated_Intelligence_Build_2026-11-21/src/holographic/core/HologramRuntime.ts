/**
 * LORIN Holographic Engine — Babylon.js WebGPU / WebGL 2 Runtime & Camera/Lighting Pipeline (Sections 2.2, 9 & 13)
 */
import { ArcRotateCamera } from '@babylonjs/core/Cameras/arcRotateCamera';
import { Color3, Color4 } from '@babylonjs/core/Maths/math.color';
import { Vector3 } from '@babylonjs/core/Maths/math.vector';
import { DirectionalLight } from '@babylonjs/core/Lights/directionalLight';
import { HemisphericLight } from '@babylonjs/core/Lights/hemisphericLight';
import { PointLight } from '@babylonjs/core/Lights/pointLight';
import { ShadowGenerator } from '@babylonjs/core/Lights/Shadows/shadowGenerator';
import '@babylonjs/core/Lights/Shadows/shadowGeneratorSceneComponent';
import { Engine } from '@babylonjs/core/Engines/engine';
import { WebGPUEngine } from '@babylonjs/core/Engines/webgpuEngine';
import { GlowLayer } from '@babylonjs/core/Layers/glowLayer';
import '@babylonjs/core/Layers/effectLayerSceneComponent';
import { Mesh } from '@babylonjs/core/Meshes/mesh';
import { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder';
import { Scene } from '@babylonjs/core/scene';
import { StandardMaterial } from '@babylonjs/core/Materials/standardMaterial';
import {
  ActiveRendererBackend,
  detectRenderingCapabilitiesSync
} from './RenderingCapabilities';
import { QualityManager, QualityProfileSettings } from './QualityManager';
import { createLorinMaterialPalette, getStateAccentColor, LorinMaterialPalette } from '../materials/HologramMaterial';
import { LorinDigitalHumanRig } from '../character/CharacterRig';
import {
  CharacterPresentation,
  LorinCharacterState,
  LorinEnvironment
} from '../../services/lorinPresence';

export type CameraFramingPreset = 'portrait' | 'upper_body' | 'full_stage' | 'cinematic';

interface CameraTargetSpec {
  alpha: number;
  beta: number;
  radius: number;
  targetY: number;
}

const CAMERA_FRAMING_MAP: Record<CameraFramingPreset, CameraTargetSpec> = {
  portrait: { alpha: -Math.PI / 2, beta: 1.5, radius: 1.38, targetY: 0.08 },
  upper_body: { alpha: -Math.PI / 2, beta: 1.48, radius: 1.85, targetY: -0.14 },
  full_stage: { alpha: -Math.PI / 2, beta: 1.44, radius: 2.45, targetY: -0.32 },
  cinematic: { alpha: -Math.PI / 2 + 0.18, beta: 1.46, radius: 1.98, targetY: -0.18 }
};

export function resolveDefaultFramingForPresentation(
  presentation: CharacterPresentation
): CameraFramingPreset {
  switch (presentation) {
    case 'compact':
    case 'mobile':
      return 'portrait';
    case 'full':
      return 'full_stage';
    case 'expanded':
    case 'workspace':
    case 'standard':
    default:
      return 'upper_body';
  }
}

export class HologramRuntime {
  private engine: Engine | WebGPUEngine | null = null;
  private scene: Scene | null = null;
  private camera: ArcRotateCamera | null = null;
  private rimLight: PointLight | null = null;
  private keyLight: DirectionalLight | null = null;
  private glowLayer: GlowLayer | null = null;
  private palette: LorinMaterialPalette | null = null;
  private rig: LorinDigitalHumanRig | null = null;
  private ambientMotes: Array<{ mesh: Mesh; basePos: Vector3; speed: number; phase: number }> = [];

  private activeBackend: ActiveRendererBackend = 'SVG_Fallback';
  private activeQuality: QualityProfileSettings = QualityManager.getActiveProfile();
  private state: LorinCharacterState = 'IDLE';
  private environment: LorinEnvironment = 'conversation';
  private presentation: CharacterPresentation = 'standard';
  private cameraPreset: CameraFramingPreset = 'upper_body';
  private audioLevel = 0;
  private isSpeaking = false;
  private disposed = false;
  private startTimeMs = performance.now();
  private fpsSampleTimer = 0;
  private resizeObserver: ResizeObserver | null = null;

  public async initialize(
    canvas: HTMLCanvasElement,
    initialPresentation: CharacterPresentation = 'standard'
  ): Promise<{ success: boolean; backend: ActiveRendererBackend }> {
    this.presentation = initialPresentation;
    this.cameraPreset = resolveDefaultFramingForPresentation(initialPresentation);
    const caps = detectRenderingCapabilitiesSync();
    this.activeQuality = QualityManager.getActiveProfile();

    // 1. Prefer WebGPU when supported & adapter available, with automatic WebGL 2 fallback
    let initializedEngine: Engine | WebGPUEngine | null = null;
    if (caps.webgpuSupported) {
      try {
        const webgpuSupportedAsync = await WebGPUEngine.IsSupportedAsync;
        if (webgpuSupportedAsync && !this.disposed) {
          const wgpu = new WebGPUEngine(canvas, {
            antialias: true,
            adaptToDeviceRatio: true
          });
          await wgpu.initAsync();
          initializedEngine = wgpu;
          this.activeBackend = 'WebGPU';
        }
      } catch {
        initializedEngine = null;
      }
    }

    if (!initializedEngine && !this.disposed && (caps.webgl2Supported || caps.webgl1Supported)) {
      try {
        initializedEngine = new Engine(
          canvas,
          true,
          {
            preserveDrawingBuffer: false,
            stencil: true,
            powerPreference: 'high-performance',
            alpha: true
          },
          true
        );
        this.activeBackend = caps.webgl2Supported ? 'WebGL2' : 'WebGL1';
      } catch {
        initializedEngine = null;
      }
    }

    if (!initializedEngine || this.disposed) {
      if (initializedEngine) {
        initializedEngine.dispose();
      }
      this.activeBackend = 'SVG_Fallback';
      return { success: false, backend: 'SVG_Fallback' };
    }

    this.engine = initializedEngine;
    this.engine.setHardwareScalingLevel(this.activeQuality.hardwareScalingLevel);

    // 2. Build Scene, Camera, 3-Point PBR Lighting, and Digital-Human Rig
    const scene = new Scene(this.engine);
    scene.clearColor = new Color4(0, 0, 0, 0); // Transparent canvas for seamless holographic composite
    this.scene = scene;

    const initialFraming = CAMERA_FRAMING_MAP[this.cameraPreset];
    const camera = new ArcRotateCamera(
      'lorin_holo_camera',
      initialFraming.alpha,
      initialFraming.beta,
      initialFraming.radius,
      new Vector3(0, initialFraming.targetY, 0),
      scene
    );
    camera.lowerRadiusLimit = 1.05;
    camera.upperRadiusLimit = 3.2;
    camera.lowerBetaLimit = 1.15;
    camera.upperBetaLimit = 1.78;
    camera.wheelDeltaPercentage = 0.015;
    camera.panningSensibility = 0;
    camera.attachControl(canvas, true);
    this.camera = camera;

    // Studio Fill & Ambient Hemispheric Light
    const hemiLight = new HemisphericLight('lorin_hemi_light', new Vector3(0, 1, 0.25), scene);
    hemiLight.intensity = 0.88;
    hemiLight.diffuse = Color3.FromHexString('#E2F8F5');
    hemiLight.groundColor = Color3.FromHexString('#132230');

    // Warm/Neutral Key Directional Light for Facial Modeling
    const keyLight = new DirectionalLight('lorin_key_light', new Vector3(-0.45, -0.55, -0.7), scene);
    keyLight.position = new Vector3(1.5, 2.2, 2.5);
    keyLight.intensity = 1.45;
    keyLight.diffuse = Color3.FromHexString('#F8FAFC');
    this.keyLight = keyLight;

    // Holographic Cyan/Periwinkle Rim Point Light
    const rimLight = new PointLight('lorin_rim_light', new Vector3(0, 0.35, -1.65), scene);
    rimLight.intensity = 1.65;
    rimLight.diffuse = Color3.FromHexString('#66E3CB');
    this.rimLight = rimLight;

    // Materials & Rig
    this.palette = createLorinMaterialPalette(scene, this.activeQuality);
    this.rig = new LorinDigitalHumanRig(scene, this.palette, this.activeQuality);

    // Optional Shadow Generator on HIGH/ULTRA
    if (this.activeQuality.enableShadows) {
      try {
        const sg = new ShadowGenerator(this.activeQuality.shadowMapSize, keyLight);
        sg.useBlurExponentialShadowMap = true;
        sg.blurKernel = 16;
        for (const mesh of this.rig.getShadowCasters()) {
          sg.addShadowCaster(mesh);
        }
      } catch {
        // Ignore shadow map fallback on constrained drivers
      }
    }

    // Controlled Optical Glow Layer
    if (this.activeQuality.enablePostProcessGlow) {
      try {
        const glow = new GlowLayer('lorin_optical_glow', scene, {
          mainTextureFixedSize: 512,
          blurKernelSize: 24
        });
        glow.intensity = 0.38;
        this.glowLayer = glow;
      } catch {
        // Ignore glow fallback
      }
    }

    // Subtle Spatial Projection Motes (restrained, depth-separated)
    this.buildAmbientMotes(scene, this.activeQuality.ambientParticleCount);

    // Resize Observer
    if (typeof ResizeObserver !== 'undefined') {
      this.resizeObserver = new ResizeObserver(() => {
        if (this.engine && !this.disposed) {
          this.engine.resize();
        }
      });
      this.resizeObserver.observe(canvas);
    }

    // Render Loop
    this.startTimeMs = performance.now();
    this.engine.runRenderLoop(() => {
      if (this.disposed || !this.scene || !this.engine) return;
      if (typeof document !== 'undefined' && document.hidden) return;

      const dtSeconds = this.engine.getDeltaTime() / 1000;
      const elapsedSeconds = (performance.now() - this.startTimeMs) / 1000;

      this.updateCameraAndScene(dtSeconds, elapsedSeconds);
      this.scene.render();

      this.fpsSampleTimer += dtSeconds;
      if (this.fpsSampleTimer >= 0.5) {
        this.fpsSampleTimer = 0;
        QualityManager.reportMeasuredFps(this.engine.getFps());
      }
    });

    return { success: true, backend: this.activeBackend };
  }

  private buildAmbientMotes(scene: Scene, count: number): void {
    for (const item of this.ambientMotes) {
      item.mesh.dispose();
    }
    this.ambientMotes = [];
    if (count <= 0) return;

    const moteMat = new StandardMaterial('lorin_mote_mat', scene);
    moteMat.emissiveColor = Color3.FromHexString('#66E3CB');
    moteMat.diffuseColor = Color3.FromHexString('#66E3CB');
    moteMat.alpha = 0.36;

    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const radius = 0.65 + (i % 5) * 0.14;
      const y = -0.95 + ((i * 17) % 100) / 55;
      const basePos = new Vector3(Math.cos(angle) * radius, y, Math.sin(angle) * radius * 0.65 - 0.15);
      const mote = MeshBuilder.CreateSphere(
        `lorin_mote_${i}`,
        { diameter: 0.014 + (i % 3) * 0.005, segments: 6 },
        scene
      );
      mote.position = basePos.clone();
      mote.material = moteMat;
      this.ambientMotes.push({
        mesh: mote,
        basePos,
        speed: 0.35 + (i % 4) * 0.15,
        phase: i * 0.7
      });
    }
  }

  private updateCameraAndScene(dtSeconds: number, timeSeconds: number): void {
    const caps = detectRenderingCapabilitiesSync();
    if (this.rig) {
      this.rig.updateFrame(
        dtSeconds,
        timeSeconds,
        this.state,
        this.environment,
        this.audioLevel,
        this.isSpeaking,
        caps.prefersReducedMotion
      );
    }

    // Smooth camera framing transition
    if (this.camera) {
      const targetSpec = CAMERA_FRAMING_MAP[this.cameraPreset];
      const lerp = Math.min(1, dtSeconds * 4.5);
      this.camera.radius += (targetSpec.radius - this.camera.radius) * lerp;
      this.camera.target.y += (targetSpec.targetY - this.camera.target.y) * lerp;

      if (this.cameraPreset === 'cinematic' && !caps.prefersReducedMotion) {
        const orbitOffset = Math.sin(timeSeconds * 0.35) * 0.22;
        this.camera.alpha += (-Math.PI / 2 + orbitOffset - this.camera.alpha) * lerp;
      }
    }

    // Rim light state synchronization
    if (this.rimLight) {
      this.rimLight.diffuse = getStateAccentColor(this.state, this.environment);
      this.rimLight.intensity = 1.55 + Math.min(0.8, (this.audioLevel / 100) * 0.8);
    }

    // Ambient mote drift
    if (!caps.prefersReducedMotion) {
      for (const m of this.ambientMotes) {
        m.mesh.position.y = m.basePos.y + Math.sin(timeSeconds * m.speed + m.phase) * 0.07;
      }
    }
  }

  public syncState(params: {
    state: LorinCharacterState;
    environment: LorinEnvironment;
    presentation: CharacterPresentation;
    audioLevel: number;
    isSpeaking: boolean;
  }): void {
    this.state = params.state;
    this.environment = params.environment;
    if (this.presentation !== params.presentation) {
      this.presentation = params.presentation;
      this.cameraPreset = resolveDefaultFramingForPresentation(params.presentation);
    }
    this.audioLevel = params.audioLevel;
    this.isSpeaking = params.isSpeaking;
  }

  public setCameraFramingPreset(preset: CameraFramingPreset): void {
    this.cameraPreset = preset;
    if (this.camera) {
      const spec = CAMERA_FRAMING_MAP[preset];
      this.camera.alpha = spec.alpha;
      this.camera.beta = spec.beta;
    }
  }

  public getCameraFramingPreset(): CameraFramingPreset {
    return this.cameraPreset;
  }

  public setPointerGaze(normalizedX: number, normalizedY: number): void {
    this.rig?.setPointerGazeOffset(normalizedX, normalizedY);
  }

  public applyQualityProfile(profile: QualityProfileSettings): void {
    this.activeQuality = profile;
    if (this.engine) {
      this.engine.setHardwareScalingLevel(profile.hardwareScalingLevel);
    }
    if (this.scene) {
      this.buildAmbientMotes(this.scene, profile.ambientParticleCount);
    }
  }

  public getActiveBackend(): ActiveRendererBackend {
    return this.activeBackend;
  }

  public dispose(): void {
    this.disposed = true;
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    if (this.glowLayer) {
      this.glowLayer.dispose();
      this.glowLayer = null;
    }
    if (this.scene) {
      this.scene.dispose();
      this.scene = null;
    }
    if (this.engine) {
      this.engine.stopRenderLoop();
      this.engine.dispose();
      this.engine = null;
    }
  }
}
