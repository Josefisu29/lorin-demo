/**
 * LORIN Holographic Engine — Adaptive Quality Profile Manager (Section 13)
 * Profiles: ULTRA, HIGH, BALANCED, LOW, MOBILE
 */
import { detectRenderingCapabilitiesSync, RenderingCapabilitiesReport } from './RenderingCapabilities';

export type HologramQualityProfile = 'ULTRA' | 'HIGH' | 'BALANCED' | 'LOW' | 'MOBILE';

export interface QualityProfileSettings {
  profile: HologramQualityProfile;
  label: string;
  targetFps: number;
  hardwareScalingLevel: number; // 1.0 = full native DPI, 1.5 = scaled down
  meshSubdivisions: number;
  enableSubsurfaceScattering: boolean;
  enableClearCoatEyes: boolean;
  enableIridescence: boolean;
  enableShadows: boolean;
  shadowMapSize: number;
  ambientParticleCount: number;
  enablePostProcessGlow: boolean;
  enableHairStrandLayers: boolean;
}

export const QUALITY_PROFILE_CONFIGS: Record<HologramQualityProfile, QualityProfileSettings> = {
  ULTRA: {
    profile: 'ULTRA',
    label: 'Ultra (Photorealistic PBR + SSS + High-Res Shadows)',
    targetFps: 60,
    hardwareScalingLevel: 0.85,
    meshSubdivisions: 48,
    enableSubsurfaceScattering: true,
    enableClearCoatEyes: true,
    enableIridescence: true,
    enableShadows: true,
    shadowMapSize: 2048,
    ambientParticleCount: 44,
    enablePostProcessGlow: true,
    enableHairStrandLayers: true
  },
  HIGH: {
    profile: 'HIGH',
    label: 'High (Full PBR + Subsurface + Soft Glow)',
    targetFps: 60,
    hardwareScalingLevel: 1.0,
    meshSubdivisions: 36,
    enableSubsurfaceScattering: true,
    enableClearCoatEyes: true,
    enableIridescence: true,
    enableShadows: true,
    shadowMapSize: 1024,
    ambientParticleCount: 28,
    enablePostProcessGlow: true,
    enableHairStrandLayers: true
  },
  BALANCED: {
    profile: 'BALANCED',
    label: 'Balanced (Standard PBR + Smooth 60 FPS)',
    targetFps: 60,
    hardwareScalingLevel: 1.15,
    meshSubdivisions: 28,
    enableSubsurfaceScattering: true,
    enableClearCoatEyes: true,
    enableIridescence: false,
    enableShadows: false,
    shadowMapSize: 512,
    ambientParticleCount: 16,
    enablePostProcessGlow: true,
    enableHairStrandLayers: true
  },
  LOW: {
    profile: 'LOW',
    label: 'Low Power (Lightweight Geometry & Materials)',
    targetFps: 30,
    hardwareScalingLevel: 1.5,
    meshSubdivisions: 18,
    enableSubsurfaceScattering: false,
    enableClearCoatEyes: false,
    enableIridescence: false,
    enableShadows: false,
    shadowMapSize: 256,
    ambientParticleCount: 6,
    enablePostProcessGlow: false,
    enableHairStrandLayers: false
  },
  MOBILE: {
    profile: 'MOBILE',
    label: 'Mobile Adaptive (30 FPS Compact Battery-Safe)',
    targetFps: 30,
    hardwareScalingLevel: 1.35,
    meshSubdivisions: 22,
    enableSubsurfaceScattering: false,
    enableClearCoatEyes: true,
    enableIridescence: false,
    enableShadows: false,
    shadowMapSize: 512,
    ambientParticleCount: 10,
    enablePostProcessGlow: false,
    enableHairStrandLayers: false
  }
};

const STORAGE_KEY = 'lorin_hologram_quality_profile_v1';

export class QualityManager {
  private static manualOverride: HologramQualityProfile | null = null;
  private static measuredFps = 60;
  private static listeners = new Set<(profile: QualityProfileSettings, fps: number) => void>();

  static selectRecommendedProfile(caps?: RenderingCapabilitiesReport): HologramQualityProfile {
    const c = caps || detectRenderingCapabilitiesSync();
    if (c.prefersReducedMotion) return 'LOW';
    if (c.isMobileViewport) return 'MOBILE';
    if (!c.webgl2Supported && !c.webgpuSupported) return 'LOW';
    if (c.webgpuSupported && c.hardwareConcurrency >= 8 && c.deviceMemoryGb >= 8) {
      return 'ULTRA';
    }
    if (c.webgl2Supported && c.hardwareConcurrency >= 6) {
      return 'HIGH';
    }
    return 'BALANCED';
  }

  static getActiveProfile(): QualityProfileSettings {
    if (!this.manualOverride && typeof localStorage !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY) as HologramQualityProfile | null;
      if (saved && saved in QUALITY_PROFILE_CONFIGS) {
        this.manualOverride = saved;
      }
    }
    const profileName = this.manualOverride || this.selectRecommendedProfile();
    return QUALITY_PROFILE_CONFIGS[profileName];
  }

  static setQualityProfile(profile: HologramQualityProfile | 'AUTO'): QualityProfileSettings {
    if (profile === 'AUTO') {
      this.manualOverride = null;
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem(STORAGE_KEY);
      }
    } else {
      this.manualOverride = profile;
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY, profile);
      }
    }
    const active = this.getActiveProfile();
    this.notify();
    return active;
  }

  static isManualOverrideActive(): boolean {
    return this.manualOverride !== null;
  }

  static reportMeasuredFps(fps: number): void {
    this.measuredFps = Math.max(1, Math.min(144, Math.round(fps)));
  }

  static getMeasuredFps(): number {
    return this.measuredFps;
  }

  static subscribe(listener: (profile: QualityProfileSettings, fps: number) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private static notify(): void {
    const active = this.getActiveProfile();
    for (const l of this.listeners) {
      l(active, this.measuredFps);
    }
  }
}
