import { TaskStatus, VoiceState, VideoState, WorkspaceView } from '../types/lorin';

export type LorinCharacterState =
  | 'IDLE'
  | 'LISTENING'
  | 'PROCESSING'
  | 'THINKING'
  | 'SPEAKING'
  | 'RESPONDING'
  | 'RESEARCHING'
  | 'CODING'
  | 'ANALYZING'
  | 'VISION_ACTIVE'
  | 'NOTIFICATION'
  | 'ERROR'
  | 'DISCONNECTED';

export type LorinCharacterStateLower =
  | 'idle'
  | 'listening'
  | 'processing'
  | 'thinking'
  | 'speaking'
  | 'responding'
  | 'researching'
  | 'coding'
  | 'analyzing'
  | 'vision_active'
  | 'notification'
  | 'error'
  | 'disconnected';

export type LorinCharacterStateInput = LorinCharacterState | LorinCharacterStateLower;

export type LorinEnvironment =
  | 'conversation'
  | 'voice'
  | 'research'
  | 'coding'
  | 'vision'
  | 'knowledge'
  | 'immersive';

export type CharacterPresentation =
  | 'compact'
  | 'standard'
  | 'expanded'
  | 'full'
  | 'workspace'
  | 'mobile';

export type LorinPresentation = CharacterPresentation;

export type FacialExpressionPreset =
  | 'neutral'
  | 'attentive'
  | 'listening'
  | 'thinking'
  | 'speaking'
  | 'confident'
  | 'friendly'
  | 'serious'
  | 'acknowledgement'
  | 'concern';

export interface LorinPresenceInput {
  currentView: WorkspaceView;
  isLoading: boolean;
  isMicActive: boolean;
  isCameraActive: boolean;
  voiceState: VoiceState | 'IDLE';
  videoState: VideoState | 'IDLE';
  gideonActivity: 'IDLE' | 'PROCESSING' | 'RESEARCHING';
  reportStatus?: TaskStatus;
  pendingApprovals: number;
  isImmersiveOpen?: boolean;
  isMobileViewport?: boolean;
  isProviderDisconnected?: boolean;
}

export interface LorinPresence {
  state: LorinCharacterState;
  stateLower: LorinCharacterStateLower;
  environment: LorinEnvironment;
  presentation: CharacterPresentation;
  expression: FacialExpressionPreset;
}

export function normalizeCharacterState(state: LorinCharacterStateInput | string | undefined): LorinCharacterState {
  if (!state) return 'IDLE';
  const upper = state.toUpperCase().trim();
  switch (upper) {
    case 'IDLE':
    case 'LISTENING':
    case 'PROCESSING':
    case 'THINKING':
    case 'SPEAKING':
    case 'RESPONDING':
    case 'RESEARCHING':
    case 'CODING':
    case 'ANALYZING':
    case 'VISION_ACTIVE':
    case 'NOTIFICATION':
    case 'ERROR':
    case 'DISCONNECTED':
      return upper as LorinCharacterState;
    default:
      return 'IDLE';
  }
}

export function toLowerCharacterState(state: LorinCharacterStateInput): LorinCharacterStateLower {
  return normalizeCharacterState(state).toLowerCase() as LorinCharacterStateLower;
}

export function resolveExpressionForState(state: LorinCharacterStateInput): FacialExpressionPreset {
  const canonical = normalizeCharacterState(state);
  switch (canonical) {
    case 'LISTENING':
      return 'listening';
    case 'THINKING':
    case 'PROCESSING':
      return 'thinking';
    case 'SPEAKING':
      return 'speaking';
    case 'RESPONDING':
      return 'confident';
    case 'RESEARCHING':
    case 'CODING':
    case 'ANALYZING':
      return 'serious';
    case 'VISION_ACTIVE':
      return 'attentive';
    case 'NOTIFICATION':
      return 'acknowledgement';
    case 'ERROR':
    case 'DISCONNECTED':
      return 'concern';
    case 'IDLE':
    default:
      return 'neutral';
  }
}

export function resolveLorinEnvironment(view: WorkspaceView, isImmersiveOpen = false): LorinEnvironment {
  if (isImmersiveOpen) return 'immersive';
  if (view === 'voice') return 'voice';
  if (view === 'video') return 'vision';
  if (view === 'vault' || view === 'laurenVault' || view === 'memory') return 'knowledge';
  if (view === 'gideon' || view === 'specialists') return 'research';
  if (view === 'projects' || view === 'tasks' || view === 'terminal' || view === 'tests') return 'coding';
  return 'conversation';
}

export function resolveLorinPresentation(
  environment: LorinEnvironment,
  isMobileViewport = false
): CharacterPresentation {
  if (environment === 'immersive') return 'full';
  if (isMobileViewport && environment === 'conversation') return 'mobile';
  switch (environment) {
    case 'voice':
      return 'expanded';
    case 'research':
    case 'coding':
      return 'workspace';
    case 'knowledge':
    case 'vision':
      return 'standard';
    default:
      return 'compact';
  }
}

export function resolveLorinCharacterState(input: LorinPresenceInput): LorinCharacterState {
  if (input.isProviderDisconnected) return 'DISCONNECTED';
  if (input.pendingApprovals > 0) return 'NOTIFICATION';

  if (input.currentView === 'voice') {
    if (input.voiceState === 'ERROR') return 'ERROR';
    if (input.voiceState === 'PROCESSING') return 'PROCESSING';
    if (input.voiceState === 'SPEAKING') return 'SPEAKING';
    if (input.voiceState === 'LISTENING' && input.isMicActive) return 'LISTENING';
  }

  if (input.currentView === 'video') {
    if (input.videoState === 'ERROR') return 'ERROR';
    if (input.videoState === 'ANALYZING_FRAME') return 'ANALYZING';
    if (input.videoState === 'PREVIEW_ACTIVE' && input.isCameraActive) return 'VISION_ACTIVE';
    if (input.videoState === 'STARTING') return 'PROCESSING';
  }

  if (input.currentView === 'gideon' && input.gideonActivity !== 'IDLE') {
    return input.gideonActivity;
  }

  if (input.isLoading) {
    if (input.currentView === 'projects' || input.currentView === 'terminal' || input.currentView === 'tasks') {
      return 'CODING';
    }
    if (input.currentView === 'specialists' || input.currentView === 'gideon') {
      return 'RESEARCHING';
    }
    return 'THINKING';
  }
  if (input.currentView === 'chat' && input.reportStatus === 'FAILED') return 'ERROR';
  return 'IDLE';
}

export function resolveLorinPresence(input: LorinPresenceInput): LorinPresence {
  const environment = resolveLorinEnvironment(input.currentView, input.isImmersiveOpen);
  const state = resolveLorinCharacterState(input);
  return {
    state,
    stateLower: toLowerCharacterState(state),
    environment,
    presentation: resolveLorinPresentation(environment, input.isMobileViewport),
    expression: resolveExpressionForState(state)
  };
}
