import { getDefaultPermissionsForRole, Principal } from '../types/lorin';

/** Safe identity used before Firebase resolves and whenever Firebase reports no user. */
export function createUnauthenticatedPrincipal(): Principal {
  return {
    id: 'guest_unauthenticated',
    name: 'Guest Operator',
    email: '',
    role: 'GUEST',
    canonicalRole: 'RESTRICTED',
    accountStatus: 'ACTIVE',
    authenticated: false,
    enrolledAt: 0,
    sessionExpiresAt: 0,
    scopes: ['read:public'],
    permissions: getDefaultPermissionsForRole('RESTRICTED')
  };
}
