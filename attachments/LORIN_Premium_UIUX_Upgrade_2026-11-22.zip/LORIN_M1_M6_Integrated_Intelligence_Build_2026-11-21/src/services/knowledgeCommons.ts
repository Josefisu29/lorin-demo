/**
 * MOSAIRA Public Knowledge Commons RAG Service (v6.0)
 * Publicly searchable document repository with rights tracking and citation formatting.
 * Strictly isolated: private Lauren files and memories are never ingested here.
 */
import { MosairaKnowledgeSource } from '../types/mosaira';

const PUBLIC_COMMONS_KEY = 'mosaira_knowledge_commons_v1';

const DEFAULT_SOURCES: MosairaKnowledgeSource[] = [
  {
    id: 'commons_doc_1',
    title: 'MOSAIRA Open AI Ecosystem Architecture & Governance (2026)',
    publisher: 'MOSAIRA Open Systems Research',
    url: 'https://mosaira.ai/docs/architecture-v6',
    license: 'CC-BY-4.0',
    category: 'Architecture',
    importedAt: Date.now() - 86400000 * 5,
    content: 'MOSAIRA is a public AI platform designed for discovering, evaluating, comparing, and fine-tuning multiple distinct open-weight and hosted AI models. It enforces strict separation between public model playground traffic and private personal assistant environments.',
    chunks: [
      'MOSAIRA is a public AI platform designed for discovering, evaluating, comparing, and fine-tuning multiple distinct open-weight and hosted AI models.',
      'It enforces strict separation between public model playground traffic and private personal assistant environments.'
    ],
    citationCount: 42
  },
  {
    id: 'commons_doc_2',
    title: 'Model Cards & Responsible Weight Governance Standards',
    publisher: 'AI Alignment & Safety Foundation',
    url: 'https://aisafety.org/standards/model-cards',
    license: 'Apache 2.0',
    category: 'Standards',
    importedAt: Date.now() - 86400000 * 10,
    content: 'A comprehensive model card must disclose publisher identity, exact model architecture revision, weights download URL, context limits, training data provenance, licensing terms, and commercial reuse permissions.',
    chunks: [
      'A comprehensive model card must disclose publisher identity, exact model architecture revision, weights download URL, context limits, training data provenance, licensing terms, and commercial reuse permissions.'
    ],
    citationCount: 28
  },
  {
    id: 'commons_doc_3',
    title: 'Unbundled Data Consent & Granular Contribution Rights',
    publisher: 'Open Data Rights Initiative',
    url: 'https://opendatagov.org/consent-framework',
    license: 'ODC-By 1.0',
    category: 'Governance',
    importedAt: Date.now() - 86400000 * 2,
    content: 'User data contribution for model improvement must remain unbundled from general terms of service. Users must separately grant explicit consent for RAG Commons indexing, internal evaluation, or model training.',
    chunks: [
      'User data contribution for model improvement must remain unbundled from general terms of service.',
      'Users must separately grant explicit consent for RAG Commons indexing, internal evaluation, or model training.'
    ],
    citationCount: 19
  }
];

export class KnowledgeCommonsService {
  private static sources: MosairaKnowledgeSource[] = [];

  static initialize(): void {
    try {
      const stored = localStorage.getItem(PUBLIC_COMMONS_KEY);
      if (stored) {
        this.sources = JSON.parse(stored);
      } else {
        this.sources = [...DEFAULT_SOURCES];
        this.persist();
      }
    } catch {
      this.sources = [...DEFAULT_SOURCES];
    }
  }

  private static persist(): void {
    try {
      localStorage.setItem(PUBLIC_COMMONS_KEY, JSON.stringify(this.sources));
    } catch {}
  }

  static getSources(): MosairaKnowledgeSource[] {
    if (this.sources.length === 0) this.initialize();
    return [...this.sources];
  }

  static search(query: string): { source: MosairaKnowledgeSource; chunk: string; score: number }[] {
    if (this.sources.length === 0) this.initialize();
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const results: { source: MosairaKnowledgeSource; chunk: string; score: number }[] = [];

    this.sources.forEach(source => {
      source.chunks.forEach(chunk => {
        const lowerChunk = chunk.toLowerCase();
        let score = 0;
        const words = q.split(/\s+/);
        words.forEach(w => {
          if (w.length > 2 && lowerChunk.includes(w)) {
            score += 1;
          }
        });
        if (score > 0) {
          results.push({ source, chunk, score });
        }
      });
    });

    return results.sort((a, b) => b.score - a.score);
  }

  static addSource(source: Omit<MosairaKnowledgeSource, 'id' | 'importedAt' | 'citationCount'>): MosairaKnowledgeSource {
    if (this.sources.length === 0) this.initialize();
    const newDoc: MosairaKnowledgeSource = {
      id: `commons_doc_${Date.now()}`,
      importedAt: Date.now(),
      citationCount: 0,
      ...source
    };
    this.sources.unshift(newDoc);
    this.persist();
    return newDoc;
  }
}

KnowledgeCommonsService.initialize();
