/**
 * Stealth Service
 * Dynamic Favicon Neutralization & Anti-Detection System for LORIN / Private Gateway
 * Ensures that casual observers, crawlers, and automated bots see only a generic system node.
 */

const STEALTH_STORAGE_KEY = 'lorin_stealth_mode_v1';
const LISTENERS: Array<(enabled: boolean) => void> = [];

// Discreet neutral dot/square favicon SVG
const NEUTRAL_FAVICON_SVG = `data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16"><rect width="6" height="6" x="5" y="5" rx="1.5" fill="%234A5568"/></svg>`;
const DEFAULT_FAVICON_HREF = '/favicon.ico';

export class StealthService {
  /**
   * Check if stealth mode is currently active
   */
  static isStealthEnabled(): boolean {
    try {
      return localStorage.getItem(STEALTH_STORAGE_KEY) === 'true';
    } catch {
      return false;
    }
  }

  /**
   * Enable or disable stealth mode and update favicon + title dynamically
   */
  static setStealthMode(enabled: boolean): void {
    try {
      localStorage.setItem(STEALTH_STORAGE_KEY, enabled ? 'true' : 'false');
      this.applyFavicon(enabled);
      this.applyDocumentTitle(enabled);
      LISTENERS.forEach((cb) => cb(enabled));
    } catch (err) {
      console.warn('Failed to update stealth mode state', err);
    }
  }

  /**
   * Apply favicon according to current stealth state
   */
  static applyFavicon(stealthActive?: boolean): void {
    const isStealth = stealthActive !== undefined ? stealthActive : this.isStealthEnabled();
    let link = document.querySelector("link[rel*='icon']") as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }

    if (isStealth) {
      link.href = NEUTRAL_FAVICON_SVG;
    } else {
      link.href = DEFAULT_FAVICON_HREF;
    }
  }

  /**
   * Mask page title when in stealth mode
   */
  static applyDocumentTitle(stealthActive?: boolean): void {
    const isStealth = stealthActive !== undefined ? stealthActive : this.isStealthEnabled();
    if (isStealth) {
      if (document.title.includes('LORIN') || document.title.includes('Lauren') || document.title.includes('Master Intelligence')) {
        document.title = 'Workspace Console';
      }
    } else {
      if (document.title === 'Workspace Console') {
        document.title = 'MOSAIRA Ecosystem';
      }
    }
  }

  /**
   * Subscribe to stealth mode state changes
   */
  static subscribe(callback: (enabled: boolean) => void): () => void {
    LISTENERS.push(callback);
    return () => {
      const idx = LISTENERS.indexOf(callback);
      if (idx !== -1) LISTENERS.splice(idx, 1);
    };
  }
}
