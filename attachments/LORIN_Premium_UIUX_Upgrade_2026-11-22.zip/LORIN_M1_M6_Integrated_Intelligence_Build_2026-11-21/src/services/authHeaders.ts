/**
 * Attach Firebase ID tokens to private API requests.
 * Authorization must come from Firebase Auth — never from fabricated principal JSON.
 */
import { auth } from './firebase';

export const LORIN_AUTH_TOKEN_KEY = 'lorin_auth_token_v2';
export const LORIN_ENROLLED_DEVICE_ID_KEY = 'lorin_enrolled_device_id_v2';

export function getEnrolledClientDeviceId(): string {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const existing = window.localStorage.getItem(LORIN_ENROLLED_DEVICE_ID_KEY);
      if (existing && existing.trim()) {
        return existing.trim();
      }
      const isPrimaryHost =
        window.location?.hostname === 'localhost' || window.location?.hostname === '127.0.0.1';
      const generated = isPrimaryHost
        ? 'dev_primary_laptop_node'
        : `dev_client_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
      window.localStorage.setItem(LORIN_ENROLLED_DEVICE_ID_KEY, generated);
      return generated;
    }
  } catch {
    // ignore
  }
  return 'dev_primary_laptop_node';
}

export function setEnrolledClientDeviceId(deviceId: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage && deviceId.trim()) {
      window.localStorage.setItem(LORIN_ENROLLED_DEVICE_ID_KEY, deviceId.trim());
    }
  } catch {
    // ignore
  }
}

export function clearStoredSessionToken(): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.removeItem(LORIN_AUTH_TOKEN_KEY);
    }
  } catch {
    // ignore
  }
}

// Revoke legacy app-minted browser tokens left by previous builds.
clearStoredSessionToken();

export async function getAuthHeaders(
  extra: Record<string, string> = {}
): Promise<Record<string, string>> {
  const safeExtra: Record<string, string> = {};
  for (const [key, value] of Object.entries(extra)) {
    const normalized = key.toLowerCase();
    if (normalized !== 'authorization' && normalized !== 'x-firebase-id-token') {
      safeExtra[key] = value;
    }
  }
  const headers: Record<string, string> = {
    Accept: 'application/json',
    'X-Lorin-Device-Id': getEnrolledClientDeviceId(),
    ...safeExtra
  };

  // Remove tokens minted by the obsolete anonymous-session bootstrap.
  // A private request is authenticated only by the current Firebase user.
  clearStoredSessionToken();
  const user = auth.currentUser;
  if (!user) return headers;

  try {
    const idToken = await user.getIdToken();
    if (idToken) headers.Authorization = `Bearer ${idToken}`;
  } catch {
    // Fail closed: do not fall back to local, cached, or application-minted tokens.
  }
  return headers;
}

export async function authFetch(
  input: RequestInfo | URL,
  init: RequestInit = {}
): Promise<Response> {
  const authHeaders = await getAuthHeaders();
  const requestHeaders = new Headers(init.headers || {});
  for (const [key, value] of Object.entries(authHeaders)) {
    requestHeaders.set(key, value);
  }
  return fetch(input, {
    ...init,
    headers: requestHeaders
  });
}
