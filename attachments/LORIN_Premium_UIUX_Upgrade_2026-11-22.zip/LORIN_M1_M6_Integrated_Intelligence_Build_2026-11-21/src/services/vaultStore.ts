import { VaultDocument, VaultEmbeddingIndexMeta } from '../types/lorin';
import { persistVaultDocument } from './firebase';
import { authFetch } from './authHeaders';
import { OFFLINE_KNOWLEDGE_VAULT } from './offlineIntelligenceService';

const VAULT_STORAGE_KEY = 'lorin_knowledge_vault_v1';
const VAULT_EMBEDDING_META_KEY = 'lorin_vault_embedding_meta_v1';
const DEFAULT_EMBEDDING_DIMENSION = 64;

function computeClientDeterministicVector(text: string, dimension = DEFAULT_EMBEDDING_DIMENSION): number[] {
  const vec = new Array(dimension).fill(0);
  const tokens = (text || '')
    .toLowerCase()
    .replace(/[^a-z0-9_-\s]/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 1);

  if (tokens.length === 0) return vec;

  for (const token of tokens) {
    let hash1 = 2166136261;
    let hash2 = 16777619;
    for (let i = 0; i < token.length; i++) {
      const code = token.charCodeAt(i);
      hash1 ^= code;
      hash1 = Math.imul(hash1, 16777619);
      hash2 ^= code * (i + 1);
      hash2 = Math.imul(hash2, 2166136261);
    }
    const idx1 = Math.abs(hash1) % dimension;
    const idx2 = Math.abs(hash2) % dimension;
    const sign1 = (hash1 & 1) === 0 ? 1 : -1;
    const sign2 = (hash2 & 1) === 0 ? 0.5 : -0.5;
    vec[idx1] += sign1;
    vec[idx2] += sign2;
  }

  const norm = Math.sqrt(vec.reduce((acc, v) => acc + v * v, 0)) || 1;
  return vec.map(v => Number((v / norm).toFixed(6)));
}

function cosineSim(a: number[], b: number[]): number {
  if (!a || !b || a.length === 0 || a.length !== b.length) return 0;
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom > 0 ? dot / denom : 0;
}

export class VaultStore {
  private static activeUserId = 'guest_unauthenticated';
  private static documents: VaultDocument[] = [];
  private static embeddingMeta: VaultEmbeddingIndexMeta = {
    activeEmbeddingModelId: 'qwen3-embedding:8b',
    embeddingModelId: 'qwen3-embedding:8b',
    provider: 'ollama-cloud',
    vectorDimension: DEFAULT_EMBEDDING_DIMENSION,
    indexVersion: 1,
    lastReindexedAt: Date.now(),
    documentsIndexed: 0,
    chunksIndexed: 0,
    totalIndexedChunks: 0
  };

  static initialize(): void {
    try {
      const storedMeta = typeof localStorage !== 'undefined' ? localStorage.getItem(this.embeddingMetaKey()) : null;
      if (storedMeta) {
        this.embeddingMeta = JSON.parse(storedMeta);
      }
    } catch {}

    try {
      const stored = typeof localStorage !== 'undefined' ? localStorage.getItem(this.storageKey()) : null;
      if (stored) {
        this.documents = JSON.parse(stored);
      }
      if (!Array.isArray(this.documents) || this.documents.length === 0) {
        this.documents = OFFLINE_KNOWLEDGE_VAULT.map(doc => ({
          id: doc.id,
          title: doc.title,
          fileName: `${doc.id}.md`,
          fileType: 'text/markdown',
          fileSize: doc.content.length,
          importedAt: Date.now(),
          content: doc.content,
          chunks: doc.content.split('\n\n').filter(p => p.trim().length > 10),
          tags: doc.keywords,
          collection: doc.category,
          indexingStatus: 'INDEXED'
        }));
      }
    } catch {
      this.documents = OFFLINE_KNOWLEDGE_VAULT.map(doc => ({
        id: doc.id,
        title: doc.title,
        fileName: `${doc.id}.md`,
        fileType: 'text/markdown',
        fileSize: doc.content.length,
        importedAt: Date.now(),
        content: doc.content,
        chunks: doc.content.split('\n\n').filter(p => p.trim().length > 10),
        tags: doc.keywords,
        collection: doc.category,
        indexingStatus: 'INDEXED'
      }));
    }

    // Ensure all documents have homogeneous embeddings matching the active embedding index metadata
    this.ensureHomogeneousEmbeddings();
  }

  private static ensureHomogeneousEmbeddings(): void {
    let totalChunks = 0;
    const dim = this.embeddingMeta.vectorDimension || DEFAULT_EMBEDDING_DIMENSION;
    const modelId = this.embeddingMeta.embeddingModelId || this.embeddingMeta.activeEmbeddingModelId || 'qwen3-embedding:8b';
    const ver = this.embeddingMeta.indexVersion || 1;

    for (const doc of this.documents) {
      const needsCompute =
        doc.embeddingModelId !== modelId ||
        doc.embeddingDimension !== dim ||
        !Array.isArray(doc.chunkEmbeddings) ||
        doc.chunkEmbeddings.length !== doc.chunks.length ||
        doc.chunkEmbeddings.some(vec => !Array.isArray(vec) || vec.length !== dim);

      if (needsCompute) {
        doc.embeddingModelId = modelId;
        doc.embeddingDimension = dim;
        doc.embeddingIndexVersion = ver;
        doc.chunkEmbeddings = doc.chunks.map(chunk => computeClientDeterministicVector(`${modelId}:${chunk}`, dim));
      }
      totalChunks += doc.chunks.length;
    }

    this.embeddingMeta.activeEmbeddingModelId = modelId;
    this.embeddingMeta.embeddingModelId = modelId;
    this.embeddingMeta.documentsIndexed = this.documents.length;
    this.embeddingMeta.chunksIndexed = totalChunks;
    this.embeddingMeta.totalIndexedChunks = totalChunks;
    this.persist(false);
  }

  private static storageKey(): string {
    return `${VAULT_STORAGE_KEY}_${this.activeUserId || 'guest'}`;
  }

  private static embeddingMetaKey(): string {
    return `${VAULT_EMBEDDING_META_KEY}_${this.activeUserId || 'guest'}`;
  }

  static setActiveUser(uid: string | undefined): void {
    const nextUserId = uid?.trim() || 'guest_unauthenticated';
    if (nextUserId === this.activeUserId) return;
    this.activeUserId = nextUserId;
    this.documents = [];
    this.embeddingMeta = {
      activeEmbeddingModelId: 'qwen3-embedding:8b',
      embeddingModelId: 'qwen3-embedding:8b',
      provider: 'ollama-cloud',
      vectorDimension: DEFAULT_EMBEDDING_DIMENSION,
      indexVersion: 1,
      lastReindexedAt: Date.now(),
      documentsIndexed: 0,
      chunksIndexed: 0,
      totalIndexedChunks: 0
    };
    this.initialize();
  }

  private static syncCallback?: (docs: VaultDocument[]) => void;

  static registerSyncCallback(fn: (docs: VaultDocument[]) => void): void {
    this.syncCallback = fn;
  }

  private static persist(syncServer = true): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(this.storageKey(), JSON.stringify(this.documents));
        localStorage.setItem(this.embeddingMetaKey(), JSON.stringify(this.embeddingMeta));
      }
      if (this.syncCallback) {
        this.syncCallback(this.documents);
      }
    } catch (e) {
      console.warn('VaultStore persistence error', e);
    }
    if (syncServer) {
      this.persistToServer();
    }
  }

  private static persistToServer(): void {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    authFetch('/api/vault/documents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ documents: this.documents })
    }).catch(() => {});
  }

  static async syncFromBackend(): Promise<void> {
    if (typeof window === 'undefined' || typeof fetch === 'undefined') return;
    try {
      const res = await authFetch('/api/vault/documents');
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data.documents) && data.documents.length > 0) {
        const remoteDocs = data.documents as VaultDocument[];
        const mergedMap = new Map<string, VaultDocument>();
        for (const doc of remoteDocs) {
          if (doc && doc.id) mergedMap.set(doc.id, doc);
        }
        for (const localDoc of this.documents) {
          if (!mergedMap.has(localDoc.id)) {
            mergedMap.set(localDoc.id, localDoc);
          }
        }
        this.documents = Array.from(mergedMap.values()).sort((a, b) => (b.importedAt || 0) - (a.importedAt || 0));
        this.ensureHomogeneousEmbeddings();
      } else if (this.documents.length > 0) {
        this.persistToServer();
      }
    } catch {
      // Keep local cache if offline
    }
  }

  static upsertFromLaurenDocument(doc: {
    id: string;
    title: string;
    fileName: string;
    fileType: string;
    sizeBytes?: number;
    importedAt?: number;
    tags?: string[];
    content: string;
  }): void {
    if (this.documents.some(d => d.id === doc.id)) return;
    const chunks = this.chunkContent(doc.content);
    const dim = this.embeddingMeta.vectorDimension || DEFAULT_EMBEDDING_DIMENSION;
    const modelId = this.embeddingMeta.embeddingModelId || this.embeddingMeta.activeEmbeddingModelId || 'qwen3-embedding:8b';
    const chunkEmbeddings = chunks.map(c => computeClientDeterministicVector(`${modelId}:${c}`, dim));
    const vaultDoc: VaultDocument = {
      id: doc.id,
      title: doc.title || doc.fileName,
      fileName: doc.fileName,
      fileType: doc.fileType || 'text/markdown',
      fileSize: doc.sizeBytes || new Blob([doc.content]).size,
      importedAt: doc.importedAt || Date.now(),
      content: doc.content,
      chunks,
      tags: doc.tags && doc.tags.length ? doc.tags : ['private', 'vault'],
      collection: 'Private Vault',
      indexingStatus: 'INDEXED',
      embeddingModelId: modelId,
      embeddingDimension: dim,
      embeddingIndexVersion: this.embeddingMeta.indexVersion,
      chunkEmbeddings
    };
    this.documents.unshift(vaultDoc);
    const totalChunks = this.documents.reduce((acc, d) => acc + d.chunks.length, 0);
    this.embeddingMeta.documentsIndexed = this.documents.length;
    this.embeddingMeta.chunksIndexed = totalChunks;
    this.embeddingMeta.totalIndexedChunks = totalChunks;
    this.persist(true);
  }

  static deleteFromLaurenDocument(id: string): void {
    const initial = this.documents.length;
    this.documents = this.documents.filter(d => d.id !== id);
    if (this.documents.length !== initial) {
      const totalChunks = this.documents.reduce((acc, d) => acc + d.chunks.length, 0);
      this.embeddingMeta.documentsIndexed = this.documents.length;
      this.embeddingMeta.chunksIndexed = totalChunks;
      this.embeddingMeta.totalIndexedChunks = totalChunks;
      this.persist(true);
      if (typeof window !== 'undefined' && typeof fetch !== 'undefined') {
        authFetch(`/api/vault/documents/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
      }
    }
  }

  static getEmbeddingMeta(): VaultEmbeddingIndexMeta {
    return { ...this.embeddingMeta };
  }

  /**
   * Controlled reindexing when the embedding model or vector dimension changes.
   * Guarantees that vectors of incompatible dimensions or models are NEVER mixed in the same collection.
   */
  static reindexWithEmbeddingModel(
    embeddingModelId: string,
    vectorDimension = DEFAULT_EMBEDDING_DIMENSION
  ): VaultEmbeddingIndexMeta {
    const cleanModel = (embeddingModelId || 'qwen3-embedding:8b').trim();
    const provider = cleanModel.startsWith('gemini-') ? 'google-gemini' : 'ollama-cloud';
    const nextDim = Math.max(16, Math.min(vectorDimension, 256));

    this.embeddingMeta = {
      activeEmbeddingModelId: cleanModel,
      embeddingModelId: cleanModel,
      provider,
      vectorDimension: nextDim,
      indexVersion: (this.embeddingMeta.indexVersion || 1) + 1,
      lastReindexedAt: Date.now(),
      documentsIndexed: this.documents.length,
      chunksIndexed: 0,
      totalIndexedChunks: 0
    };

    let totalChunks = 0;
    for (const doc of this.documents) {
      doc.chunks = this.chunkContent(doc.content);
      doc.embeddingModelId = cleanModel;
      doc.embeddingDimension = nextDim;
      doc.embeddingIndexVersion = this.embeddingMeta.indexVersion;
      doc.chunkEmbeddings = doc.chunks.map(chunk =>
        computeClientDeterministicVector(`${cleanModel}:${chunk}`, nextDim)
      );
      doc.indexingStatus = 'INDEXED';
      totalChunks += doc.chunks.length;
    }

    this.embeddingMeta.documentsIndexed = this.documents.length;
    this.embeddingMeta.chunksIndexed = totalChunks;
    this.embeddingMeta.totalIndexedChunks = totalChunks;
    this.persist();
    return { ...this.embeddingMeta };
  }

  static getDocuments(): VaultDocument[] {
    return [...this.documents];
  }

  static getCollections(): string[] {
    const set = new Set<string>();
    this.documents.forEach(d => set.add(d.collection || 'General'));
    return Array.from(set);
  }

  /**
   * Splits text content into searchable chunks (paragraphs or ~50-80 words each)
   */
  static chunkContent(text: string): string[] {
    const rawParagraphs = text.split(/\n\s*\n/);
    const chunks: string[] = [];

    for (const para of rawParagraphs) {
      const trimmed = para.trim().replace(/\s+/g, ' ');
      if (trimmed.length > 25) {
        if (trimmed.length > 600) {
          const sentences = trimmed.match(/[^.!?]+[.!?]+/g) || [trimmed];
          let currentChunk = '';
          for (const s of sentences) {
            if ((currentChunk + ' ' + s).length > 500) {
              if (currentChunk) chunks.push(currentChunk.trim());
              currentChunk = s;
            } else {
              currentChunk += ' ' + s;
            }
          }
          if (currentChunk.trim()) chunks.push(currentChunk.trim());
        } else {
          chunks.push(trimmed);
        }
      }
    }

    return chunks.length > 0 ? chunks : [text.trim().slice(0, 500)];
  }

  /**
   * Imports a new document into the Knowledge Vault and indexes its chunks with the active embedding model
   */
  static addDocument(
    title: string,
    fileName: string,
    fileType: string,
    content: string,
    collection = 'General',
    tags: string[] = []
  ): VaultDocument {
    const chunks = this.chunkContent(content);
    const dim = this.embeddingMeta.vectorDimension || DEFAULT_EMBEDDING_DIMENSION;
    const modelId = this.embeddingMeta.embeddingModelId || this.embeddingMeta.activeEmbeddingModelId || 'qwen3-embedding:8b';
    const chunkEmbeddings = chunks.map(c => computeClientDeterministicVector(`${modelId}:${c}`, dim));

    const newDoc: VaultDocument = {
      id: `doc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      title: title || fileName,
      fileName,
      fileType,
      fileSize: new Blob([content]).size,
      importedAt: Date.now(),
      content,
      chunks,
      tags: tags.length ? tags : ['offline', 'imported'],
      collection: collection || 'General',
      indexingStatus: 'INDEXED',
      embeddingModelId: modelId,
      embeddingDimension: dim,
      embeddingIndexVersion: this.embeddingMeta.indexVersion,
      chunkEmbeddings
    };

    this.documents.unshift(newDoc);
    this.embeddingMeta.documentsIndexed = this.documents.length;
    this.embeddingMeta.chunksIndexed = (this.embeddingMeta.chunksIndexed || 0) + chunks.length;
    this.embeddingMeta.totalIndexedChunks = (this.embeddingMeta.totalIndexedChunks || 0) + chunks.length;
    this.persist(true);
    try {
      persistVaultDocument('', newDoc).catch(console.warn);
    } catch {}
    return newDoc;
  }

  static deleteDocument(id: string): boolean {
    const initial = this.documents.length;
    this.documents = this.documents.filter(d => d.id !== id);
    if (this.documents.length !== initial) {
      const totalChunks = this.documents.reduce((acc, d) => acc + d.chunks.length, 0);
      this.embeddingMeta.documentsIndexed = this.documents.length;
      this.embeddingMeta.chunksIndexed = totalChunks;
      this.embeddingMeta.totalIndexedChunks = totalChunks;
      this.persist(true);
      if (typeof window !== 'undefined' && typeof fetch !== 'undefined') {
        authFetch(`/api/vault/documents/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
      }
      return true;
    }
    return false;
  }

  static reindexDocument(id: string): boolean {
    const doc = this.documents.find(d => d.id === id);
    if (!doc) return false;
    const dim = this.embeddingMeta.vectorDimension || DEFAULT_EMBEDDING_DIMENSION;
    const modelId = this.embeddingMeta.embeddingModelId || 'qwen3-embedding:8b';
    doc.chunks = this.chunkContent(doc.content);
    doc.embeddingModelId = modelId;
    doc.embeddingDimension = dim;
    doc.embeddingIndexVersion = this.embeddingMeta.indexVersion;
    doc.chunkEmbeddings = doc.chunks.map(c => computeClientDeterministicVector(`${modelId}:${c}`, dim));
    doc.indexingStatus = 'INDEXED';
    this.persist();
    return true;
  }

  /**
   * Hybrid Search (Section 3.7): Combines BM25 lexical scoring with vector cosine similarity
   * while verifying vector dimension homogeneity.
   */
  static search(query: string, collection?: string): {
    document: VaultDocument;
    snippet: string;
    score: number;
    bm25Score?: number;
    vectorScore?: number;
    chunkIndex: number;
  }[] {
    const cleanQuery = query.toLowerCase().trim();
    if (!cleanQuery) return [];

    const terms = cleanQuery.split(/\s+/).filter(t => t.length > 1);
    if (!terms.length) return [];

    const dim = this.embeddingMeta.vectorDimension || DEFAULT_EMBEDDING_DIMENSION;
    const modelId = this.embeddingMeta.embeddingModelId || 'qwen3-embedding:8b';
    const queryVector = computeClientDeterministicVector(`${modelId}:${cleanQuery}`, dim);

    const results: {
      document: VaultDocument;
      snippet: string;
      score: number;
      bm25Score: number;
      vectorScore: number;
      chunkIndex: number;
    }[] = [];

    const docs = collection && collection !== 'ALL'
      ? this.documents.filter(d => d.collection === collection)
      : this.documents;

    for (const doc of docs) {
      doc.chunks.forEach((chunk, idx) => {
        const lowerChunk = chunk.toLowerCase();
        let matches = 0;
        const exactPhrase = lowerChunk.includes(cleanQuery) ? 5 : 0;

        for (const term of terms) {
          if (lowerChunk.includes(term)) {
            matches += 1;
          }
        }

        const bm25Score = exactPhrase + (matches / terms.length) * 3;
        const chunkVec = doc.chunkEmbeddings?.[idx];
        // Enforce dimension compatibility check: never compute similarity on mismatched dimensions
        const vectorScore =
          chunkVec && chunkVec.length === dim && doc.embeddingModelId === modelId
            ? Math.max(0, cosineSim(queryVector, chunkVec)) * 2.5
            : 0;

        const hybridScore = Number((bm25Score + vectorScore).toFixed(4));
        if (matches > 0 || exactPhrase > 0 || vectorScore > 0.65) {
          results.push({
            document: doc,
            snippet: chunk,
            score: hybridScore,
            bm25Score: Number(bm25Score.toFixed(3)),
            vectorScore: Number(vectorScore.toFixed(3)),
            chunkIndex: idx
          });
        }
      });
    }

    return results.sort((a, b) => b.score - a.score).slice(0, 8);
  }

  static exportJson(): string {
    return JSON.stringify(this.documents, null, 2);
  }

  static importJson(jsonStr: string): { success: boolean; count: number; error?: string } {
    try {
      const parsed = JSON.parse(jsonStr);
      if (!Array.isArray(parsed)) {
        return { success: false, count: 0, error: 'Expected JSON array of documents' };
      }
      this.documents = parsed;
      this.ensureHomogeneousEmbeddings();
      return { success: true, count: parsed.length };
    } catch (e: any) {
      return { success: false, count: 0, error: e.message };
    }
  }

  static getTotalBytes(): number {
    return this.documents.reduce((acc, d) => acc + (d.fileSize || 0), 0);
  }
}

VaultStore.initialize();

