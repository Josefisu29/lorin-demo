import {
  ExtendedSpecialistName,
  LorinCompletionReport,
  SpecialistRole
} from '../types/lorin';
import { EXTENDED_SPECIALISTS, formatPrivateModelLabel } from '../data/specialists';
import { OllamaService } from './ollamaService';
import { getAuthHeaders } from './authHeaders';
import { CommunicationManager, InputCommunicationMode } from './communicationManager';
import { OfflineIntelligenceService } from './offlineIntelligenceService';
import { classifyQueryKind, routeModelRequest, type PrivacyMode, type ProviderCandidate } from '../core/routing/modelRouter';

const CLOUD_PRIVACY_STORAGE_KEY = 'lorin_cloud_context_permission_v1';

/**
 * Controls whether LORIN is permitted to transmit private persistent memory and
 * Knowledge Vault snippets to cloud inference providers (Part 8 Privacy Boundary).
 */
export class CloudPrivacyGate {
  static isCloudContextPermitted(): boolean {
    try {
      if (typeof localStorage !== 'undefined') {
        const raw = localStorage.getItem(CLOUD_PRIVACY_STORAGE_KEY);
        if (raw !== null) {
          return raw === 'true';
        }
      }
    } catch {
      // Fallback
    }
    // Privacy by default: private memory and Vault context stay local until the
    // user explicitly enables cloud-context transmission in Settings/Online mode.
    return false;
  }

  static setCloudContextPermitted(permitted: boolean): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(CLOUD_PRIVACY_STORAGE_KEY, permitted ? 'true' : 'false');
      }
    } catch {
      // Ignore storage error
    }
  }
}

export interface ProviderHealthStatus {
  healthy: boolean;
  provider: 'LIVE_GEMINI' | 'OLLAMA_CLOUD' | 'OLLAMA_LOCAL' | 'DETERMINISTIC_MOCK';
  model: string;
  latencyMs: number;
  message: string;
  checkedAt: number;
  liveAvailable: boolean;
  endpoint?: string;
  error?: string;
}

export interface InferenceOptions {
  requestId?: string;
  messageId?: string;
  conversationId?: string;
  inputMode?: InputCommunicationMode;
  requestedModel?: string;
  requestedProvider?: 'LIVE_GEMINI' | 'OLLAMA_CLOUD';
  taskCategory?: string;
  projectContext?: { id: string; name: string; description: string };
  activeSpecialists?: ExtendedSpecialistName[];
  allowCloudContextTransmission?: boolean;
  /** Controls which providers may receive this request. Defaults are strategy-specific and fail closed for sensitive data. */
  privacyMode?: PrivacyMode;
  allowCloudFallback?: boolean;
  sensitive?: boolean;
  requireStreaming?: boolean;
  signal?: AbortSignal;
}

export function createLorinInferenceFailureReport(
  prompt: string,
  reason: string,
  requestedProvider = 'NONE',
  requestedModel = 'none',
  blocked = false
): LorinCompletionReport {
  const status = blocked ? 'BLOCKED' : 'FAILED';
  const summary = `${blocked ? '[REQUEST_CANCELLED]' : '[INFERENCE_FAILURE]'}: ${reason}. No offline mock or synthetic model response was substituted.`;
  const specialistBreakdown = {
    LENA_GUARDIAN: { role: 'LENA_GUARDIAN' as SpecialistRole, summary: 'Request stopped at the provider or privacy boundary.', keyInsights: ['No unauthorized provider fallback occurred'] },
    OWEN_COORDINATOR: { role: 'OWEN_COORDINATOR' as SpecialistRole, summary: 'The requested inference could not be completed.', keyInsights: ['No completion was recorded'] },
    RILEY_COMPANION: { role: 'RILEY_COMPANION' as SpecialistRole, summary: 'The failure is reported explicitly.', keyInsights: ['No fabricated answer was presented'] },
    IRIS_INVESTIGATOR: { role: 'IRIS_INVESTIGATOR' as SpecialistRole, summary: 'Provider availability or routing requirements were not satisfied.', keyInsights: [reason], riskOrVerificationNotes: 'The request requires a new attempt after the issue is resolved.' },
    NOLAN_STRATEGIST: { role: 'NOLAN_STRATEGIST' as SpecialistRole, summary: 'Execution halted without switching to an unapproved provider.', keyInsights: ['Provider routing remained within the selected policy'] },
    GIDEON_SYSTEMS: { role: 'GIDEON_SYSTEMS' as SpecialistRole, summary: 'An inference failure event is available for diagnostics.', keyInsights: ['No successful inference event was claimed'] }
  };
  return {
    objective: prompt.trim(), status: status as any, autonomyLevel: 'LEVEL_0_OBSERVE', completed: [],
    verification: { tested: false, evidence: reason, acceptanceCriteriaMet: false },
    outstanding: [reason], risks: ['No model response was produced.'],
    nextStep: 'Check provider health, privacy mode, model availability and authentication, then retry.',
    specialistBreakdown, rawSynthesis: summary, backendUsed: 'NONE', latencyMs: 0,
    modelAttribution: { requestedProvider, requestedModel, actualProvider: 'NONE', actualModel: 'none', fallbackUsed: false, fallbackReason: reason, latencyMs: 0 }
  };
}

export interface ModelBackend {
  name: string;
  type: 'LIVE_GEMINI' | 'OLLAMA_CLOUD' | 'DETERMINISTIC_MOCK' | 'OLLAMA_LOCAL';
  infer(prompt: string, context?: string, snapshotImage?: string, options?: InferenceOptions): Promise<LorinCompletionReport>;
  inferStream?(
    prompt: string,
    onChunk: (text: string) => void,
    context?: string,
    snapshotImage?: string,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport>;
  healthCheck(): Promise<ProviderHealthStatus>;
}

/**
 * Live Gemini API Backend with Multimodal Vision Support
 * Truthful execution: does not fall back to mock data or falsify test results on failure.
 * Features an explicit HEALTH_CHECK method that validates connectivity to the model provider.
 */
export class LiveGeminiBackend implements ModelBackend {
  name = 'LORIN Cloud Intelligence Gateway';
  type = 'LIVE_GEMINI' as const;

  /**
   * Explicit HEALTH_CHECK: Actively probes the server endpoint and upstream model provider
   * without relying on cached flags, state, or mock responses.
   */
  async healthCheck(): Promise<ProviderHealthStatus> {
    const startTime = performance.now();
    const endpoint = typeof window !== 'undefined' ? '/api/health' : 'http://localhost:3000/api/health';

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const response = await fetch(endpoint, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      const latencyMs = Math.round(performance.now() - startTime);

      if (!response.ok) {
        return {
          healthy: false,
          provider: 'LIVE_GEMINI',
          model: 'gemini-3.1-flash-lite',
          latencyMs,
          message: `Health check probe failed: HTTP ${response.status}`,
          checkedAt: Date.now(),
          liveAvailable: false,
          endpoint,
          error: `HTTP ${response.status} ${response.statusText}`
        };
      }

      const data = await response.json();
      const credentialConfigured = data.geminiConfigured === true;
      const upstreamVerified = data.providerConnectivityVerified === true && data.liveGeminiAvailable === true;

      return {
        healthy: upstreamVerified,
        provider: 'LIVE_GEMINI',
        model: data.defaultModel || 'gemini-3.8-flash',
        latencyMs,
        message: upstreamVerified
          ? `Live Gemini upstream verified (latency: ${latencyMs}ms)`
          : credentialConfigured
          ? 'API server is reachable and a Gemini credential is configured, but upstream inference has not been tested.'
          : 'API server is reachable, but GEMINI_API_KEY is not configured.',
        checkedAt: Date.now(),
        liveAvailable: upstreamVerified,
        endpoint,
        error: upstreamVerified ? undefined : credentialConfigured ? 'UPSTREAM_NOT_PROBED' : 'GEMINI_API_KEY missing'
      };
    } catch (err: any) {
      const latencyMs = Math.round(performance.now() - startTime);
      return {
        healthy: false,
        provider: 'LIVE_GEMINI',
        model: 'gemini-3.1-flash-lite',
        latencyMs,
        message: `Health check probe unreachable: ${err.message}`,
        checkedAt: Date.now(),
        liveAvailable: false,
        endpoint,
        error: err.message
      };
    }
  }

  async infer(
    prompt: string,
    context?: string,
    snapshotImage?: string,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport> {
    const startTime = performance.now();
    const cleanPrompt = prompt.toLowerCase().trim();
    const isRoutine = ['hello', 'hi', 'hey', 'greetings', 'who are you', 'how are you', 'thanks', 'thank you'].includes(
      cleanPrompt.replace(/[!.,?]/g, '')
    );
    const requestedModel = options?.requestedModel || (isRoutine ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash');
    const requestId = options?.requestId || CommunicationManager.createRequestId();
    const allowCloudContext =
      options?.allowCloudContextTransmission !== undefined
        ? options.allowCloudContextTransmission
        : CloudPrivacyGate.isCloudContextPermitted();
    const effectiveContext = allowCloudContext ? context : undefined;

    CommunicationManager.transition('connecting', `Connecting to ${requestedModel}`, requestId);

    try {
      const inferUrl = typeof window !== 'undefined' ? '/api/gemini/infer' : 'http://localhost:3000/api/gemini/infer';
      const response = await fetch(inferUrl, {
        method: 'POST',
        headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
        signal: options?.signal,
        body: JSON.stringify({
          requestId,
          prompt,
          context: effectiveContext,
          snapshotImage,
          requestedModel,
          requestedProvider: options?.requestedProvider,
          taskCategory: options?.taskCategory,
          projectContext: options?.projectContext,
          activeSpecialists: options?.activeSpecialists,
          allowCloudContextTransmission: allowCloudContext,
          routineMode: isRoutine
        })
      });

      CommunicationManager.recordBackendAck(requestId, options?.requestedProvider || 'LIVE_GEMINI', requestedModel);

      if (!response.ok) {
        let errBody: any = {};
        try {
          errBody = await response.json();
        } catch {}
        const errObj: any = new Error(errBody.error || errBody.details || `Server responded with HTTP ${response.status}`);
        errObj.code = errBody.code || `HTTP_${response.status}`;
        errObj.status = response.status;
        throw errObj;
      }

      const parsed = await response.json();
      if (!parsed || parsed.error) {
        throw new Error(parsed?.error || 'Failed to parse live cloud model response');
      }

      const latencyMs = Math.round(performance.now() - startTime);
      const nowLive = Date.now();
      const actualModelName = parsed.modelAttribution?.actualModel || parsed.modelUsed || requestedModel;
      const privateLabel = formatPrivateModelLabel(actualModelName);

      CommunicationManager.transition('rendering', 'Formatting response', requestId);
      CommunicationManager.completeRequestTrace(
        requestId,
        parsed.backendUsed === 'OLLAMA_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
        actualModelName
      );

      const specialistBreakdown = parsed.specialistBreakdown || {
        LENA_GUARDIAN: {
          role: 'LENA_GUARDIAN' as SpecialistRole,
          summary: parsed.specialists?.LENA?.summary || 'Security review completed via LORIN Cloud Gateway.',
          keyInsights: parsed.specialists?.LENA?.keyInsights || [
            'Policy enforced at server boundary',
            allowCloudContext ? 'Authorized context transmitted via encrypted proxy' : 'Private Vault context held locally per Cloud Privacy Gate'
          ],
          riskOrVerificationNotes: parsed.specialists?.LENA?.riskOrVerificationNotes
        },
        OWEN_COORDINATOR: {
          role: 'OWEN_COORDINATOR' as SpecialistRole,
          summary: parsed.specialists?.OWEN?.summary || 'Task sequencing coordinated.',
          keyInsights: parsed.specialists?.OWEN?.keyInsights || ['Stages sequenced without duplicate work']
        },
        RILEY_COMPANION: {
          role: 'RILEY_COMPANION' as SpecialistRole,
          summary: parsed.specialists?.RILEY?.summary || 'Clarity and readability verified.',
          keyInsights: parsed.specialists?.RILEY?.keyInsights || ['Accessible formatting applied']
        },
        IRIS_INVESTIGATOR: {
          role: 'IRIS_INVESTIGATOR' as SpecialistRole,
          summary: parsed.specialists?.IRIS?.summary || 'Evidence and acceptance criteria examined.',
          keyInsights: parsed.specialists?.IRIS?.keyInsights || ['Acceptance criteria checked against model response'],
          riskOrVerificationNotes: parsed.specialists?.IRIS?.riskOrVerificationNotes
        },
        NOLAN_STRATEGIST: {
          role: 'NOLAN_STRATEGIST' as SpecialistRole,
          summary: parsed.specialists?.NOLAN?.summary || 'Architecture and trade-offs evaluated.',
          keyInsights: parsed.specialists?.NOLAN?.keyInsights || ['Design pattern verified']
        },
        GIDEON_SYSTEMS: {
          role: 'GIDEON_SYSTEMS' as SpecialistRole,
          summary: parsed.specialists?.GIDEON?.summary || 'Timeline continuity and system telemetry evaluated.',
          keyInsights: parsed.specialists?.GIDEON?.keyInsights || [
            'Chronological state and architectural dependencies checked',
            'System health and predictive impacts grounded'
          ],
          riskOrVerificationNotes: parsed.specialists?.GIDEON?.riskOrVerificationNotes
        }
      };

      return {
        objective: parsed.objective || prompt.trim(),
        status: parsed.status || 'COMPLETED',
        autonomyLevel: parsed.autonomyLevel || 'LEVEL_1_RECOMMEND',
        completed: parsed.completed || [`Executed live multimodal inference via ${privateLabel}`],
        verification: parsed.verification || {
          tested: false,
          evidence: parsed.verificationEvidence || `Live response received from ${privateLabel} and schema-validated.`,
          acceptanceCriteriaMet: true
        },
        outstanding: parsed.outstanding || [],
        risks: parsed.risks || ['Probabilistic model output: verify consequential system operations before deployment.'],
        nextStep: parsed.nextStep || 'Review recommendations or execute verification suite.',
        specialistBreakdown,
        proposedActions: parsed.proposedActions,
        rawSynthesis: parsed.rawSynthesis || JSON.stringify(parsed),
        backendUsed: parsed.backendUsed === 'OLLAMA_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
        latencyMs,
        modelAttribution: parsed.modelAttribution || {
          requestedProvider: options?.requestedProvider || 'LIVE_GEMINI',
          requestedModel,
          actualProvider: parsed.backendUsed === 'OLLAMA_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
          actualModel: actualModelName,
          fallbackUsed: false,
          latencyMs
        },
        workflowStages: [
          {
            id: 'stg_ingest',
            name: 'Context & Ingestion',
            specialist: 'OWEN_COORDINATOR',
            status: 'COMPLETED',
            description: snapshotImage
              ? 'Processed multimodal visual frame and user prompt'
              : 'Owen ingested objective and context citations',
            durationMs: Math.round(latencyMs * 0.15),
            outputSummary: 'Ingestion validated',
            completedAt: nowLive - Math.round(latencyMs * 0.85)
          },
          {
            id: 'stg_security',
            name: 'Trust Boundary & RBAC',
            specialist: 'LENA_GUARDIAN',
            status: 'COMPLETED',
            description: 'Evaluated permissions and parameters against deny-by-default server policy',
            durationMs: Math.round(latencyMs * 0.25),
            outputSummary: 'Policy Allow',
            completedAt: nowLive - Math.round(latencyMs * 0.6)
          },
          {
            id: 'stg_infer',
            name: 'Live Cloud Intelligence Inference',
            specialist: 'NOLAN_STRATEGIST',
            status: 'COMPLETED',
            description: `Generated content using ${privateLabel}`,
            durationMs: Math.round(latencyMs * 0.4),
            outputSummary: `${privateLabel} executed`,
            completedAt: nowLive - Math.round(latencyMs * 0.2)
          },
          {
            id: 'stg_verification',
            name: 'Evidence & Verification',
            specialist: 'IRIS_INVESTIGATOR',
            status: 'COMPLETED',
            description: 'Iris validated response schema against LORIN acceptance criteria',
            durationMs: Math.round(latencyMs * 0.2),
            outputSummary: 'Criteria verified',
            completedAt: nowLive
          }
        ]
      };
    } catch (err: any) {
      const latencyMs = Math.round(performance.now() - startTime);
      const isAborted =
        Boolean(options?.signal?.aborted) ||
        err?.name === 'AbortError' ||
        err?.message?.toLowerCase().includes('abort');

      if (isAborted) {
        CommunicationManager.cancelRequestTrace(requestId, 'Request cancelled by operator');
      } else {
        CommunicationManager.failRequestTrace({
          requestId,
          code: err?.code || 'INFERENCE_FAILURE',
          message: err?.message || 'Live Cloud inference failed.',
          retryable: err?.status !== 400
        });
      }
      console.error('Live Gemini inference error (truthful failure returned):', err.message);

      return {
        objective: prompt.trim(),
        status: isAborted ? 'BLOCKED' : 'FAILED',
        autonomyLevel: 'LEVEL_0_OBSERVE',
        completed: [],
        verification: {
          tested: false,
          evidence: isAborted
            ? 'Request cancelled by operator.'
            : `Live inference failed: ${err.message}. No synthetic mock data returned.`,
          acceptanceCriteriaMet: false
        },
        outstanding: [
          isAborted
            ? 'Request was cancelled by user.'
            : 'Resolve live inference service error to proceed with AI generation.'
        ],
        risks: [
          isAborted
            ? 'Partial stream aborted cleanly.'
            : 'Inference request was not fulfilled. Verify server GEMINI_API_KEY and network availability.'
        ],
        nextStep: 'Check system settings, verify GEMINI_API_KEY in environment, or select an explicit fallback provider.',
        specialistBreakdown: {
          LENA_GUARDIAN: {
            role: 'LENA_GUARDIAN' as SpecialistRole,
            summary: `Security boundary maintained: ${isAborted ? 'cancelled request' : `failed call (${err.message})`} did not leak state.`,
            keyInsights: ['Error isolated cleanly at gateway', 'Zero mock data substituted'],
            riskOrVerificationNotes: 'Inference aborted at gateway'
          },
          OWEN_COORDINATOR: {
            role: 'OWEN_COORDINATOR' as SpecialistRole,
            summary: isAborted ? 'Task cancelled by user.' : 'Task execution halted due to provider failure.',
            keyInsights: ['Execution paused', 'No speculative output passed to pipeline']
          },
          RILEY_COMPANION: {
            role: 'RILEY_COMPANION' as SpecialistRole,
            summary: 'Reported failure truthfully to operator without deceptive mock fallback.',
            keyInsights: ['Zero deceptive mock responses']
          },
          IRIS_INVESTIGATOR: {
            role: 'IRIS_INVESTIGATOR' as SpecialistRole,
            summary: `Verified failure state: HTTP or SDK error occurred (${err.message}).`,
            keyInsights: ['Evidence records unfulfilled request'],
            riskOrVerificationNotes: 'Acceptance criteria unmet'
          },
          NOLAN_STRATEGIST: {
            role: 'NOLAN_STRATEGIST' as SpecialistRole,
            summary: 'Architectural circuit-breaker engaged to prevent synthetic data cascade.',
            keyInsights: ['Fault isolation verified']
          },
          GIDEON_SYSTEMS: {
            role: 'GIDEON_SYSTEMS' as SpecialistRole,
            summary: 'Incident timestamped in chronological timeline for root-cause correlation.',
            keyInsights: ['Error event logged with server timestamp', 'Zero uncalibrated predictions made']
          }
        },
        rawSynthesis: isAborted
          ? `**[REQUEST_CANCELLED]**: Inference request was cancelled by the operator.`
          : `**[INFERENCE_FAILURE]**: Live Cloud inference could not be completed (${err.message}).\n\n*LORIN operates with truthful error reporting: no deceptive mock responses were substituted.*`,
        backendUsed: 'LIVE_GEMINI',
        latencyMs,
        modelAttribution: {
          requestedProvider: 'LIVE_GEMINI',
          requestedModel,
          actualProvider: 'NONE',
          actualModel: 'none',
          fallbackUsed: false,
          fallbackReason: err.message,
          latencyMs
        },
        workflowStages: [
          {
            id: 'stg_infer_fail',
            name: 'Live Cloud Gateway',
            specialist: 'LENA_GUARDIAN',
            status: isAborted ? 'BLOCKED' : 'FAILED',
            description: `Inference call ${isAborted ? 'cancelled' : `failed: ${err.message}`}`,
            durationMs: latencyMs,
            outputSummary: isAborted ? 'Cancelled' : 'Gateway Error',
            completedAt: Date.now()
          }
        ]
      };
    }
  }

  /**
   * Real-Time Progressive Token Streaming using SSE endpoint (/api/gemini/stream)
   */
  async inferStream(
    prompt: string,
    onChunk: (accumulatedText: string) => void,
    context?: string,
    snapshotImage?: string,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport> {
    const startTime = performance.now();
    const cleanPrompt = prompt.toLowerCase().trim();
    const isRoutine = ['hello', 'hi', 'hey', 'greetings', 'who are you', 'how are you', 'thanks', 'thank you'].includes(
      cleanPrompt.replace(/[!.,?]/g, '')
    );
    const requestedModel = options?.requestedModel || (isRoutine ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash');
    const requestId = options?.requestId || CommunicationManager.createRequestId();
    const allowCloudContext =
      options?.allowCloudContextTransmission !== undefined
        ? options.allowCloudContextTransmission
        : CloudPrivacyGate.isCloudContextPermitted();
    const effectiveContext = allowCloudContext ? context : undefined;

    CommunicationManager.transition('connecting', `Connecting to ${requestedModel}`, requestId);

    try {
      const streamUrl = typeof window !== 'undefined' ? '/api/gemini/stream' : 'http://localhost:3000/api/gemini/stream';
      const response = await fetch(streamUrl, {
        method: 'POST',
        headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
        signal: options?.signal,
        body: JSON.stringify({
          requestId,
          prompt,
          context: effectiveContext,
          snapshotImage,
          requestedModel,
          requestedProvider: options?.requestedProvider,
          taskCategory: options?.taskCategory,
          projectContext: options?.projectContext,
          activeSpecialists: options?.activeSpecialists,
          allowCloudContextTransmission: allowCloudContext,
          routineMode: isRoutine
        })
      });

      if (!response.ok) {
        let errBody: any = {};
        try {
          errBody = await response.json();
        } catch {}
        const httpErr: any = new Error(errBody.error || `Server responded with HTTP ${response.status}`);
        httpErr.status = response.status;
        httpErr.code = errBody.code || `HTTP_${response.status}`;
        // Do not retry non-streaming .infer() if auth failed (401/403), invalid input (400), rate limit (429), or unconfigured key (503)
        if ([400, 401, 403, 429, 503].includes(response.status)) {
          httpErr.noFallback = true;
        }
        throw httpErr;
      }

      CommunicationManager.recordBackendAck(requestId, options?.requestedProvider || 'LIVE_GEMINI', requestedModel);

      if (!response.body) {
        throw new Error('Streaming response body is unavailable.');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedText = '';
      let usedModel = requestedModel;
      let doneAttribution: any = null;
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.startsWith('data: ')) {
            const dataStr = trimmed.slice(6);
            let data: any = null;
            try {
              data = JSON.parse(dataStr);
            } catch (jsonErr: any) {
              if (jsonErr.message !== 'Unexpected end of JSON input') {
                console.warn('SSE line parse warning:', jsonErr);
              }
              continue;
            }

            if (data) {
              if (data.type === 'accepted' || data.type === 'connected') {
                if (data.modelUsed) usedModel = data.modelUsed;
                CommunicationManager.recordBackendAck(requestId, data.provider, data.modelUsed);
              } else if (data.type === 'started') {
                if (data.modelUsed) usedModel = data.modelUsed;
                CommunicationManager.recordFirstToken(requestId);
              } else if (data.type === 'error') {
                const streamErr: any = new Error(data.error || 'Stream error');
                streamErr.code = data.code || 'STREAM_ERROR';
                streamErr.noFallback = true;
                throw streamErr;
              } else if (data.type === 'chunk' && data.text) {
                accumulatedText += data.text;
                if (data.modelUsed) usedModel = data.modelUsed;
                CommunicationManager.recordStreamChunk(requestId);
                onChunk(accumulatedText);
              } else if (data.type === 'done') {
                if (data.modelUsed) usedModel = data.modelUsed;
                if (data.modelAttribution) doneAttribution = data.modelAttribution;
              }
            }
          }
        }
      }

      if (!accumulatedText.trim()) {
        throw new Error('Empty streaming response from model provider');
      }

      const latencyMs = Math.round(performance.now() - startTime);
      const privateLabel = formatPrivateModelLabel(usedModel);

      CommunicationManager.transition('rendering', 'Formatting response', requestId);
      CommunicationManager.completeRequestTrace(
        requestId,
        doneAttribution?.actualProvider === 'OLLAMA_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
        usedModel
      );

      return {
        objective: prompt.trim(),
        status: 'COMPLETED',
        autonomyLevel: 'LEVEL_1_RECOMMEND',
        completed: [`Streamed response tokens via ${privateLabel}`],
        verification: {
          tested: false,
          evidence: `Real-time token streaming completed via ${privateLabel}.`,
          acceptanceCriteriaMet: true
        },
        outstanding: [],
        risks: ['Real-time streaming output: verify consequential actions.'],
        nextStep: 'Review synthesized output or proceed to execution.',
        specialistBreakdown: {
          LENA_GUARDIAN: {
            role: 'LENA_GUARDIAN' as SpecialistRole,
            summary: `Trust boundary maintained during SSE stream (${privateLabel}).`,
            keyInsights: ['Zero client-side secrets exposed']
          },
          OWEN_COORDINATOR: {
            role: 'OWEN_COORDINATOR' as SpecialistRole,
            summary: 'Progressive token delivery coordinated.',
            keyInsights: ['Live progressive streaming completed']
          },
          RILEY_COMPANION: {
            role: 'RILEY_COMPANION' as SpecialistRole,
            summary: 'Tokens rendered progressively for immediate readability.',
            keyInsights: ['Low latency time-to-first-token']
          },
          IRIS_INVESTIGATOR: {
            role: 'IRIS_INVESTIGATOR' as SpecialistRole,
            summary: `Stream integrity confirmed from upstream model gateway.`,
            keyInsights: ['Valid SSE events received']
          },
          NOLAN_STRATEGIST: {
            role: 'NOLAN_STRATEGIST' as SpecialistRole,
            summary: 'Streaming pipeline architecture active.',
            keyInsights: ['Non-blocking chunk delivery']
          },
          GIDEON_SYSTEMS: {
            role: 'GIDEON_SYSTEMS' as SpecialistRole,
            summary: 'Streaming telemetry recorded in system event log.',
            keyInsights: ['Timeline streaming verified']
          }
        },
        rawSynthesis: accumulatedText,
        backendUsed: doneAttribution?.actualProvider === 'OLLAMA_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
        latencyMs,
        modelAttribution: doneAttribution || {
          requestedProvider: options?.requestedProvider || 'LIVE_GEMINI',
          requestedModel,
          actualProvider: 'LIVE_GEMINI',
          actualModel: usedModel,
          fallbackUsed: usedModel !== requestedModel,
          latencyMs
        }
      };
    } catch (err: any) {
      const isAborted =
        Boolean(options?.signal?.aborted) ||
        err?.name === 'AbortError' ||
        err?.message?.toLowerCase().includes('abort');

      if (isAborted || err?.noFallback) {
        const latencyMs = Math.round(performance.now() - startTime);
        if (isAborted) {
          CommunicationManager.cancelRequestTrace(requestId, 'Streaming cancelled by operator');
        } else {
          CommunicationManager.failRequestTrace({
            requestId,
            code: err?.code || 'STREAM_FAILURE',
            message: err?.message || 'Streaming inference failed.',
            retryable: err?.status !== 400
          });
        }
        return {
          objective: prompt.trim(),
          status: isAborted ? 'BLOCKED' : 'FAILED',
          autonomyLevel: 'LEVEL_0_OBSERVE',
          completed: [],
          verification: {
            tested: false,
            evidence: isAborted ? 'Request cancelled by operator.' : `Live streaming failed: ${err.message}`,
            acceptanceCriteriaMet: false
          },
          outstanding: [isAborted ? 'Cancelled by operator.' : `Resolve error: ${err.message}`],
          risks: [isAborted ? 'Stream stopped cleanly.' : 'Inference request was not fulfilled.'],
          nextStep: 'Click Retry or inspect Communication Diagnostics.',
          specialistBreakdown: {
            LENA_GUARDIAN: {
              role: 'LENA_GUARDIAN' as SpecialistRole,
              summary: `Security boundary maintained (${isAborted ? 'cancelled' : err.message}).`,
              keyInsights: ['Zero mock data substituted']
            },
            OWEN_COORDINATOR: {
              role: 'OWEN_COORDINATOR' as SpecialistRole,
              summary: isAborted ? 'Task cancelled by user.' : 'Task halted due to provider error.',
              keyInsights: ['No duplicate fallback request fired']
            },
            RILEY_COMPANION: {
              role: 'RILEY_COMPANION' as SpecialistRole,
              summary: 'Truthful status reported to operator.',
              keyInsights: ['Actionable recovery provided']
            },
            IRIS_INVESTIGATOR: {
              role: 'IRIS_INVESTIGATOR' as SpecialistRole,
              summary: `Recorded failure reason: ${err.message}`,
              keyInsights: ['Verified failure boundary']
            },
            NOLAN_STRATEGIST: {
              role: 'NOLAN_STRATEGIST' as SpecialistRole,
              summary: 'Circuit-breaker prevented redundant retry.',
              keyInsights: ['Bounded failure handling']
            },
            GIDEON_SYSTEMS: {
              role: 'GIDEON_SYSTEMS' as SpecialistRole,
              summary: 'Event logged in communication diagnostics.',
              keyInsights: ['Trace preserved']
            }
          },
          rawSynthesis: isAborted
            ? `**[REQUEST_CANCELLED]**: Inference request was cancelled by the operator.`
            : `**[INFERENCE_FAILURE]**: Live Cloud inference could not be completed (${err.message}).\n\n*LORIN operates with truthful error reporting: no deceptive mock responses were substituted.*`,
          backendUsed: 'LIVE_GEMINI',
          latencyMs,
          modelAttribution: {
            requestedProvider: options?.requestedProvider || 'LIVE_GEMINI',
            requestedModel,
            actualProvider: 'NONE',
            actualModel: 'none',
            fallbackUsed: false,
            fallbackReason: err.message,
            latencyMs
          }
        };
      }

      console.warn('SSE stream transport unavailable, falling back to standard inference:', err.message);
      return this.infer(prompt, context, snapshotImage, { ...options, requestId });
    }
  }
}

/**
 * Local-First Ollama Backend
 * Truthfully checks local Ollama daemon without mock fallbacks.
 */
export class OllamaLocalBackend implements ModelBackend {
  name = 'Ollama Local (localhost:11434)';
  type = 'OLLAMA_LOCAL' as const;

  async healthCheck(): Promise<ProviderHealthStatus> {
    const start = performance.now();
    const status = await OllamaService.checkLocalStatus();
    const latencyMs = Math.round(performance.now() - start);

    return {
      healthy: status.reachable && status.selectedModelInstalled,
      provider: 'OLLAMA_LOCAL',
      model: OllamaService.getSelectedModel(),
      latencyMs: status.latencyMs || latencyMs,
      message: status.message,
      checkedAt: Date.now(),
      liveAvailable: status.reachable && status.selectedModelInstalled,
      endpoint: OllamaService.getEndpoint(),
      error: status.reachable ? undefined : status.message
    };
  }

  async infer(
    prompt: string,
    context?: string,
    _snapshotImage?: string,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport> {
    const startTime = performance.now();
    const selectedModel = OllamaService.getSelectedModel() || 'llama3:latest';
    const specialistNames = options?.activeSpecialists?.length
      ? ` Collaborating with Extended Specialists: ${options.activeSpecialists.join(', ')}.`
      : '';
    const fullPrompt = `System: You are LORIN, a unified AI assistant with five core perspectives (Lena, Owen, Riley, Iris, Nolan).${specialistNames}
Prompt: ${prompt}
${context ? `Context: ${context}` : ''}`;

    const res = await OllamaService.infer(fullPrompt, selectedModel, options?.signal);
    const latencyMs = Math.round(performance.now() - startTime);

    if (!res.success || !res.text) {
      return {
        objective: prompt.trim(),
        status: 'FAILED',
        autonomyLevel: 'LEVEL_0_OBSERVE',
        completed: [],
        verification: {
          tested: false,
          evidence: `Local Ollama daemon unreachable or failed: ${res.error || 'Connection refused'}`,
          acceptanceCriteriaMet: false
        },
        outstanding: ['Start local Ollama daemon on localhost:11434 or pull requested model.'],
        risks: ['Local inference failed. No silent cloud fallback executed.'],
        nextStep: 'Ensure `ollama serve` is running and test connection in Settings, or switch to LORIN Cloud Gateway.',
        specialistBreakdown: {
          LENA_GUARDIAN: {
            role: 'LENA_GUARDIAN' as SpecialistRole,
            summary: 'Local Ollama connection failed. Safe fail-closed boundary maintained.',
            keyInsights: ['No silent fallback to cloud services']
          },
          OWEN_COORDINATOR: {
            role: 'OWEN_COORDINATOR' as SpecialistRole,
            summary: 'Orchestration paused due to local service unavailability.',
            keyInsights: ['Awaiting daemon start']
          },
          RILEY_COMPANION: {
            role: 'RILEY_COMPANION' as SpecialistRole,
            summary: 'Reported local daemon status accurately.',
            keyInsights: ['Truthful reporting']
          },
          IRIS_INVESTIGATOR: {
            role: 'IRIS_INVESTIGATOR' as SpecialistRole,
            summary: `Evidence indicates port 11434 connection failure: ${res.error}`,
            keyInsights: ['Verified socket failure']
          },
          NOLAN_STRATEGIST: {
            role: 'NOLAN_STRATEGIST' as SpecialistRole,
            summary: 'Local-first fallback pattern respected.',
            keyInsights: ['Air-gap invariant preserved']
          },
          GIDEON_SYSTEMS: {
            role: 'GIDEON_SYSTEMS' as SpecialistRole,
            summary: 'Diagnostic record logged for local daemon unreachable status.',
            keyInsights: ['Truthful connection failure state logged']
          }
        },
        rawSynthesis: `**[OLLAMA_CONNECTION_FAILURE]**: Local Ollama service is unreachable (${res.error || 'Connection refused'}).\n\n*Verify that Ollama is running locally on port 11434.*`,
        backendUsed: 'OLLAMA_LOCAL',
        latencyMs,
        modelAttribution: {
          requestedProvider: 'OLLAMA_LOCAL',
          requestedModel: selectedModel,
          actualProvider: 'NONE',
          actualModel: 'none (local daemon offline)',
          fallbackUsed: false,
          fallbackReason: res.error || 'Local Ollama daemon unreachable; strict local policy blocked cloud fallback',
          latencyMs
        }
      };
    }

    return {
      objective: prompt.trim(),
      status: 'COMPLETED',
      autonomyLevel: 'LEVEL_1_RECOMMEND',
      completed: ['Executed local-first inference via Ollama daemon'],
      verification: {
        tested: false,
        evidence: 'Local model response received from localhost:11434.',
        acceptanceCriteriaMet: true
      },
      outstanding: [],
      risks: ['Local model generation: verify consequential recommendations.'],
      nextStep: 'Review synthesized output.',
      specialistBreakdown: {
        LENA_GUARDIAN: {
          role: 'LENA_GUARDIAN' as SpecialistRole,
          summary: 'Local execution completed with air-gap privacy.',
          keyInsights: ['Zero external network calls']
        },
        OWEN_COORDINATOR: {
          role: 'OWEN_COORDINATOR' as SpecialistRole,
          summary: 'Local task sequence completed.',
          keyInsights: ['Local pipeline active']
        },
        RILEY_COMPANION: {
          role: 'RILEY_COMPANION' as SpecialistRole,
          summary: 'Delivered response from local model.',
          keyInsights: ['Natural phrasing']
        },
        IRIS_INVESTIGATOR: {
          role: 'IRIS_INVESTIGATOR' as SpecialistRole,
          summary: 'Local evidence checked.',
          keyInsights: ['Local inference verified']
        },
        NOLAN_STRATEGIST: {
          role: 'NOLAN_STRATEGIST' as SpecialistRole,
          summary: 'Local-first architecture operational.',
          keyInsights: ['Zero cloud dependency']
        },
        GIDEON_SYSTEMS: {
          role: 'GIDEON_SYSTEMS' as SpecialistRole,
          summary: 'Local inference event added to chronological timeline.',
          keyInsights: ['Air-gap event logged']
        }
      },
      rawSynthesis: res.text,
      backendUsed: 'OLLAMA_LOCAL',
      latencyMs,
      modelAttribution: {
        requestedProvider: 'OLLAMA_LOCAL',
        requestedModel: selectedModel,
        actualProvider: 'OLLAMA_LOCAL',
        actualModel: selectedModel,
        fallbackUsed: false,
        latencyMs
      }
    };
  }

  async inferStream(
    prompt: string,
    onChunk: (accumulatedText: string) => void,
    context?: string,
    _snapshotImage?: string,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport> {
    const startedAt = performance.now();
    const selectedModel = options?.requestedModel || OllamaService.getSelectedModel();
    const promptWithContext = `You are LORIN, a unified personal AI assistant.\nUser request: ${prompt}\n${context ? `Private local context: ${context}` : ''}`;
    const result = await OllamaService.inferStream(promptWithContext, onChunk, selectedModel, options?.signal);
    const latencyMs = Math.round(performance.now() - startedAt);
    if (!result.success || !result.text) {
      return createLorinInferenceFailureReport(
        prompt, result.error || 'Local Ollama streaming inference failed.', 'OLLAMA_LOCAL', selectedModel,
        options?.signal?.aborted === true
      );
    }
    return {
      objective: prompt.trim(), status: 'COMPLETED', autonomyLevel: 'LEVEL_1_RECOMMEND',
      completed: ['Received a streamed response from the local Ollama daemon.'],
      verification: { tested: false, evidence: 'Local model response stream completed; answer quality and factual accuracy were not independently verified.', acceptanceCriteriaMet: false },
      outstanding: [], risks: ['Local model output is probabilistic and requires review for consequential decisions.'],
      nextStep: 'Review the response and verify any consequential claims or proposed actions.',
      specialistBreakdown: {
        LENA_GUARDIAN: { role: 'LENA_GUARDIAN', summary: 'The request remained on the configured local loopback inference endpoint.', keyInsights: ['No cloud provider was used.'] },
        OWEN_COORDINATOR: { role: 'OWEN_COORDINATOR', summary: 'Local streaming request completed.', keyInsights: ['No external execution was triggered.'] },
        RILEY_COMPANION: { role: 'RILEY_COMPANION', summary: 'The streamed response was delivered to the conversation.', keyInsights: ['User-visible response received.'] },
        IRIS_INVESTIGATOR: { role: 'IRIS_INVESTIGATOR', summary: 'No independent factual verification was performed.', keyInsights: ['Model response remains unverified.'] },
        NOLAN_STRATEGIST: { role: 'NOLAN_STRATEGIST', summary: 'Local inference transport completed.', keyInsights: ['Streaming transport returned content.'] },
        GIDEON_SYSTEMS: { role: 'GIDEON_SYSTEMS', summary: 'Local inference outcome can be recorded in system history.', keyInsights: ['Outcome timestamp and provider attribution are available.'] }
      },
      rawSynthesis: result.text, backendUsed: 'OLLAMA_LOCAL', latencyMs,
      modelAttribution: { requestedProvider: 'OLLAMA_LOCAL', requestedModel: selectedModel, actualProvider: 'OLLAMA_LOCAL', actualModel: result.modelUsed || selectedModel, fallbackUsed: false, latencyMs }
    };
  }
}

/**
 * Deterministic Verification & Offline Engine
 * Clearly labeled deterministic synthesis for offline policy testing, specialist collaboration, and zero-key environments.
 */
export class DeterministicMockBackend implements ModelBackend {
  name = 'LORIN Deterministic Verification Engine';
  type = 'DETERMINISTIC_MOCK' as const;

  async healthCheck(): Promise<ProviderHealthStatus> {
    return {
      healthy: true,
      provider: 'DETERMINISTIC_MOCK',
      model: 'deterministic-v2',
      latencyMs: 2,
      message: 'Deterministic Verification Engine ready for offline specialist & policy testing.',
      checkedAt: Date.now(),
      liveAvailable: false
    };
  }

  async infer(
    prompt: string,
    context?: string,
    _snapshotImage?: string,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport> {
    const cleanPrompt = prompt.trim();
    const lowerPrompt = cleanPrompt.toLowerCase();
    const activeExtended = options?.activeSpecialists || [];

    const isHighRisk =
      lowerPrompt.includes('deploy') ||
      lowerPrompt.includes('delete') ||
      lowerPrompt.includes('purge') ||
      lowerPrompt.includes('drop') ||
      lowerPrompt.includes('permission') ||
      lowerPrompt.includes('production');

    const extendedNotes = activeExtended
      .map(name => {
        const spec = EXTENDED_SPECIALISTS[name];
        return spec ? `- **${spec.name} (${spec.codename} — ${spec.title})**: ${spec.guidingQuestion}` : null;
      })
      .filter(Boolean)
      .join('\n');

    const proposedActions = isHighRisk
      ? [
          {
            id: `act_det_${Date.now()}`,
            action: lowerPrompt.includes('delete') || lowerPrompt.includes('purge') ? 'purge_database_records' : 'deploy_production_release',
            resource: 'prod://cluster/main',
            description: `Execute requested high-impact operation: ${cleanPrompt.slice(0, 80)}`,
            riskLevel: 'HIGH' as const,
            requiredScope: 'admin:write',
            suggestedBy: 'LENA_GUARDIAN' as SpecialistRole
          }
        ]
      : undefined;

    return {
      objective: cleanPrompt,
      status: isHighRisk ? 'AWAITING_APPROVAL' : 'PREPARED',
      autonomyLevel: isHighRisk ? 'LEVEL_3_EXECUTE_WITH_APPROVAL' : 'LEVEL_2_PREPARE',
      completed: [
        'Evaluated request against LORIN PolicyEngine & 5 Core Perspectives',
        ...(activeExtended.length > 0 ? [`Integrated ${activeExtended.length} Extended Specialist(s): ${activeExtended.join(', ')}`] : []),
        ...(context ? ['Inspected private Knowledge Vault & Memory citations locally'] : [])
      ],
      verification: {
        tested: true,
        evidence: 'Executed via local Deterministic Verification Engine (no live cloud key consumed).',
        acceptanceCriteriaMet: true
      },
      outstanding: isHighRisk
        ? ['Awaiting explicit Owner cryptographic approval before executing high-impact action.']
        : ['Switch to LORIN Cloud Gateway or local Ollama daemon for live generative inference.'],
      risks: isHighRisk
        ? ['High-impact target detected: blocked from automatic execution until Owner approval digest is verified.']
        : ['Deterministic verification mode active: output is rule-based rather than live cloud generation.'],
      nextStep: isHighRisk
        ? 'Review and approve or deny the proposed action in the Security & Policy Gate.'
        : 'Proceed with implementation or switch to Live Cloud Gateway when GEMINI_API_KEY is configured.',
      specialistBreakdown: {
        LENA_GUARDIAN: {
          role: 'LENA_GUARDIAN',
          summary: isHighRisk
            ? 'Flagged high-impact operation requiring explicit Owner cryptographic approval.'
            : 'Verified local execution with zero external data transmission.',
          keyInsights: [
            'Zero secrets exposed to client',
            isHighRisk ? 'Action-bound SHA-256 approval gate triggered' : 'Least-privilege boundary preserved'
          ]
        },
        OWEN_COORDINATOR: {
          role: 'OWEN_COORDINATOR',
          summary: 'Sequenced task stages across active LORIN specialists.',
          keyInsights: [
            'Task state tracked accurately as ' + (isHighRisk ? 'AWAITING_APPROVAL' : 'PREPARED'),
            activeExtended.length > 0 ? `Coordinated with ${activeExtended.join(', ')}` : 'Core 5-specialist workflow aligned'
          ]
        },
        RILEY_COMPANION: {
          role: 'RILEY_COMPANION',
          summary: 'Structured synthesis for immediate engineering clarity.',
          keyInsights: ['Clear separation of verified facts and pending approvals']
        },
        IRIS_INVESTIGATOR: {
          role: 'IRIS_INVESTIGATOR',
          summary: 'Verified local context citations and deterministic policy assertions.',
          keyInsights: [
            context ? 'Local Vault citations verified' : 'No external unverified claims introduced',
            'Explicitly labeled as Deterministic Verification Engine'
          ]
        },
        NOLAN_STRATEGIST: {
          role: 'NOLAN_STRATEGIST',
          summary: 'Evaluated architectural resilience and provider isolation.',
          keyInsights: ['Decoupled provider routing verified', 'Zero silent fallback ambiguity']
        },
        GIDEON_SYSTEMS: {
          role: 'GIDEON_SYSTEMS',
          summary: 'Chronological timeline and dependency continuity projected.',
          keyInsights: [
            'Architectural decisions tracked with zero data drift',
            'Historical evidence correlated with current engineering state'
          ]
        }
      },
      proposedActions,
      rawSynthesis: `### LORIN Deterministic Engineering Synthesis\n\n**Objective:** ${cleanPrompt}\n\n**Core Specialist Evaluation:**\n- **Lena (Guardian):** ${isHighRisk ? 'High-impact operation gated for explicit Owner approval.' : 'Local privacy boundary verified.'}\n- **Owen (Coordinator):** Workflow staged with deterministic verification.\n- **Iris (Investigator):** ${context ? 'Local Knowledge Vault context integrated.' : 'Evaluated against baseline specification.'}\n- **Nolan (Strategist):** Architecture boundaries preserved.\n- **Riley (Companion):** Ready for next operator directive.${extendedNotes ? `\n\n**Extended Specialist Contributions:**\n${extendedNotes}` : ''}`,
      backendUsed: 'DETERMINISTIC_MOCK',
      latencyMs: 8,
      modelAttribution: {
        requestedProvider: 'DETERMINISTIC_MOCK',
        requestedModel: 'deterministic-v2',
        actualProvider: 'DETERMINISTIC_MOCK',
        actualModel: 'deterministic-v2',
        fallbackUsed: false,
        latencyMs: 8
      }
    };
  }
}

/**
 * Ollama Cloud Open-Weight Backend (https://ollama.com via server-side proxy)
 * Integrates seamlessly into LORIN's single conversation pipeline without requiring local GPU hardware.
 */
export class OllamaCloudBackend extends LiveGeminiBackend {
  override name = 'Ollama Cloud Open-Weight Gateway (https://ollama.com)';
  override type = 'OLLAMA_CLOUD' as any;

  override async healthCheck(): Promise<ProviderHealthStatus> {
    const startTime = performance.now();
    const endpoint = typeof window !== 'undefined' ? '/api/health' : 'http://localhost:3000/api/health';
    try {
      const response = await fetch(endpoint, { method: 'GET', headers: { Accept: 'application/json' } });
      const latencyMs = Math.round(performance.now() - startTime);
      if (!response.ok) {
        return {
          healthy: false,
          provider: 'OLLAMA_CLOUD',
          model: OllamaService.getSelectedModel() || 'deepseek-v4-flash',
          latencyMs,
          message: `Health probe failed: HTTP ${response.status}`,
          checkedAt: Date.now(),
          liveAvailable: false,
          endpoint
        };
      }
      const data = await response.json();
      const ready = Boolean(data.ollamaCloudConfigured);
      return {
        healthy: ready,
        provider: 'OLLAMA_CLOUD',
        model: OllamaService.getSelectedModel() || 'deepseek-v4-flash',
        latencyMs,
        message: ready
          ? `Ollama Cloud configured on server (${data.registeredModelsCount || 11} models in Central Registry, latency ${latencyMs}ms)`
          : 'Central Model Registry active; set OLLAMA_API_KEY in server environment for live Ollama Cloud inference.',
        checkedAt: Date.now(),
        liveAvailable: ready,
        endpoint
      };
    } catch (err: any) {
      return {
        healthy: false,
        provider: 'OLLAMA_CLOUD',
        model: OllamaService.getSelectedModel() || 'deepseek-v4-flash',
        latencyMs: Math.round(performance.now() - startTime),
        message: err?.message || 'Unreachable',
        checkedAt: Date.now(),
        liveAvailable: false,
        endpoint
      };
    }
  }

  override async infer(
    prompt: string,
    context?: string,
    snapshotImage?: string,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport> {
    return super.infer(prompt, context, snapshotImage, {
      ...options,
      requestedProvider: 'OLLAMA_CLOUD',
      requestedModel: options?.requestedModel || OllamaService.getSelectedModel() || 'deepseek-v4-flash'
    });
  }

  override async inferStream(
    prompt: string,
    onChunk: (accumulatedText: string) => void,
    context?: string,
    snapshotImage?: string,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport> {
    return super.inferStream(prompt, onChunk, context, snapshotImage, {
      ...options,
      requestedProvider: 'OLLAMA_CLOUD',
      requestedModel: options?.requestedModel || OllamaService.getSelectedModel() || 'deepseek-v4-flash'
    });
  }
}

/**
 * Intelligent Dual-Model & Open-Weight Cloud Router
 * Supports:
 * 1. CLOUD_INTELLIGENCE_ROUTER: Task-based routing across Ollama Cloud open-weight models & Google Gemini
 * 2. OLLAMA_CLOUD: Explicit Ollama Cloud open-weight execution (DeepSeek V4, Qwen 3.5, GLM-5.3-Flash, gpt-oss, Kimi K3, Gemma 4 31B)
 * 3. LIVE_GEMINI: Google Gemini cloud execution with streaming
 * 4. OLLAMA_LOCAL / LOCAL_FIRST_WITH_CLOUD_FALLBACK: Optional future local runtime with cloud fallback
 * 5. DETERMINISTIC_MOCK: Offline deterministic verification engine
 */
export type RoutingStrategy =
  | 'CLOUD_INTELLIGENCE_ROUTER'
  | 'OLLAMA_CLOUD'
  | 'LIVE_GEMINI'
  | 'OLLAMA_LOCAL'
  | 'LOCAL_FIRST_WITH_CLOUD_FALLBACK'
  | 'DUAL_TASK_COMPLEXITY'
  | 'DETERMINISTIC_MOCK'
  | 'OFFLINE_VAULT';

export class DualModelRouter {
  /**
   * Deterministic Task Complexity Classifier
   */
  static classifyComplexity(prompt: string): 'ROUTINE' | 'COMPLEX' {
    const text = prompt.toLowerCase().trim();
    const routinePhrases = [
      'hello',
      'hi',
      'hey',
      'greetings',
      'who are you',
      'how are you',
      'thanks',
      'thank you',
      'what is',
      'define',
      'help',
      'ping',
      'test'
    ];

    if (routinePhrases.some(p => text.startsWith(p) && text.length < 60)) {
      return 'ROUTINE';
    }

    const complexKeywords = [
      'architect',
      'security',
      'database',
      'migration',
      'crypto',
      'zero-trust',
      'audit',
      'rbac',
      'dsp',
      'filter',
      'pipeline',
      'concurrency',
      'schema',
      'diff',
      'refactor',
      'vulnerability',
      'authorization',
      'scale',
      'stream'
    ];

    if (complexKeywords.some(k => text.includes(k))) {
      return 'COMPLEX';
    }

    return text.length > 140 ? 'COMPLEX' : 'ROUTINE';
  }

  /**
   * Routes the prompt to the optimal model based on active strategy and provider health.
   * Provider failures remain failures. Offline Vault and deterministic modes are explicit selections, never implicit fallbacks.
   */
  private static async invokeSelected(
    backend: ModelBackend,
    prompt: string,
    context: string | undefined,
    snapshotImage: string | undefined,
    onChunk: ((text: string) => void) | undefined,
    options: InferenceOptions | undefined
  ): Promise<LorinCompletionReport> {
    if (options?.signal?.aborted) throw new DOMException('The inference request was cancelled.', 'AbortError');
    if (onChunk && backend.inferStream) {
      return backend.inferStream(prompt, onChunk, context, snapshotImage, options);
    }
    return backend.infer(prompt, context, snapshotImage, options);
  }

  private static failureReport(
    prompt: string,
    reason: string,
    requestedProvider: string,
    requestedModel: string,
    blocked = false
  ): LorinCompletionReport {
    return createLorinInferenceFailureReport(prompt, reason, requestedProvider, requestedModel, blocked);
  }

  private static async routeAutomatically(
    prompt: string,
    strategy: RoutingStrategy,
    context: string | undefined,
    snapshotImage: string | undefined,
    onChunk: ((text: string) => void) | undefined,
    options: InferenceOptions | undefined
  ): Promise<LorinCompletionReport> {
    const gemini = new LiveGeminiBackend();
    const ollamaCloud = new OllamaCloudBackend();
    const local = new OllamaLocalBackend();
    const [geminiHealth, cloudHealth, localHealth] = await Promise.all([
      gemini.healthCheck(), ollamaCloud.healthCheck(), local.healthCheck()
    ]);
    const queryKind = classifyQueryKind({ text: prompt, hasImage: Boolean(snapshotImage), sensitive: options?.sensitive });
    const requestedTokens = Math.ceil((prompt.length + (context?.length || 0)) / 4);

    const providers: ProviderCandidate[] = [
      {
        id: 'ollama-local', kind: 'OLLAMA_LOCAL', modelId: localHealth.model || OllamaService.getSelectedModel(),
        healthy: localHealth.healthy && localHealth.liveAvailable, enabled: true,
        capabilities: ['CHAT', 'RESEARCH', 'CODE', 'LONG_CONTEXT', 'SENSITIVE'],
        estimatedLatencyMs: Number.isFinite(localHealth.latencyMs) ? Math.max(1, localHealth.latencyMs) : undefined,
        supportsStreaming: true, supportsTools: false, lastVerifiedAt: localHealth.checkedAt
      },
      {
        id: 'gemini-cloud', kind: 'GEMINI_CLOUD', modelId: geminiHealth.model,
        healthy: geminiHealth.healthy && geminiHealth.liveAvailable, enabled: true,
        capabilities: ['CHAT', 'RESEARCH', 'CODE', 'VISION', 'AUDIO', 'LONG_CONTEXT'],
        estimatedLatencyMs: Number.isFinite(geminiHealth.latencyMs) ? Math.max(1, geminiHealth.latencyMs) : undefined,
        supportsStreaming: true, supportsTools: true, lastVerifiedAt: geminiHealth.checkedAt
      },
      {
        id: 'ollama-cloud', kind: 'OTHER_CLOUD', modelId: cloudHealth.model,
        healthy: cloudHealth.healthy && cloudHealth.liveAvailable, enabled: true,
        capabilities: ['CHAT', 'RESEARCH', 'CODE', 'LONG_CONTEXT'],
        estimatedLatencyMs: Number.isFinite(cloudHealth.latencyMs) ? Math.max(1, cloudHealth.latencyMs) : undefined,
        supportsStreaming: true, supportsTools: true, lastVerifiedAt: cloudHealth.checkedAt
      }
    ];

    let privacyMode: PrivacyMode = options?.privacyMode || 'BALANCED';
    let allowCloudFallback = options?.allowCloudFallback === true;
    if (queryKind === 'SENSITIVE') privacyMode = 'LOCAL_ONLY';
    if (strategy === 'LOCAL_FIRST_WITH_CLOUD_FALLBACK') {
      privacyMode = options?.privacyMode || 'LOCAL_PREFERRED';
      allowCloudFallback = options?.allowCloudFallback === true;
    } else if (strategy === 'DUAL_TASK_COMPLEXITY') {
      const complexity = this.classifyComplexity(prompt);
      privacyMode = options?.privacyMode || (complexity === 'COMPLEX' ? 'CLOUD_ALLOWED' : 'LOCAL_PREFERRED');
      allowCloudFallback = options?.allowCloudFallback === true;
    }

    const decision = routeModelRequest({
      kind: queryKind, privacyMode, estimatedInputTokens: requestedTokens,
      estimatedOutputTokens: 2048, requireStreaming: options?.requireStreaming ?? Boolean(onChunk),
      allowCloudFallback, minimumHealthAgeMs: 60_000
    }, providers);

    if (!decision.selected) {
      return this.failureReport(prompt, decision.reason, 'AUTO', options?.requestedModel || 'automatic', queryKind === 'SENSITIVE' || privacyMode === 'LOCAL_ONLY');
    }

    const selected = decision.selected;
    const backend = selected.id === 'ollama-local' ? local : selected.id === 'ollama-cloud' ? ollamaCloud : gemini;
    const actualOptions: InferenceOptions = {
      ...options,
      requestedModel: options?.requestedModel || selected.modelId,
      requestedProvider: selected.id === 'ollama-cloud' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
      allowCloudContextTransmission: selected.kind === 'OLLAMA_LOCAL' ? false : options?.allowCloudContextTransmission
    };

    // Streaming may already have exposed partial text to the UI. Track that boundary
    // and never switch providers after the first chunk (which would mix two answers).
    let emittedAnyChunk = false;
    const trackedChunk = onChunk
      ? (chunk: string) => { emittedAnyChunk = true; onChunk(chunk); }
      : undefined;

    const mayAttemptCloudFallback = (failure?: any): boolean =>
      strategy === 'LOCAL_FIRST_WITH_CLOUD_FALLBACK' &&
      options?.allowCloudFallback === true &&
      selected.kind === 'OLLAMA_LOCAL' &&
      queryKind !== 'SENSITIVE' &&
      privacyMode !== 'LOCAL_ONLY' &&
      !snapshotImage &&
      !emittedAnyChunk &&
      !options?.signal?.aborted &&
      failure?.name !== 'AbortError' &&
      failure?.noFallback !== true;

    const applyAttribution = (report: LorinCompletionReport, actualProvider: string, actualModel: string, fallbackUsed: boolean, fallbackReason?: string) => {
      if (report.modelAttribution) {
        report.modelAttribution.requestedProvider = strategy;
        report.modelAttribution.actualProvider = report.status === 'FAILED' || report.status === 'BLOCKED'
          ? 'NONE' : actualProvider;
        report.modelAttribution.actualModel = report.modelAttribution.actualProvider === 'NONE' ? 'none' : actualModel;
        report.modelAttribution.fallbackUsed = fallbackUsed;
        if (fallbackReason) report.modelAttribution.fallbackReason = fallbackReason;
      }
      if (actualProvider !== 'OLLAMA_LOCAL' && !CloudPrivacyGate.isCloudContextPermitted()) {
        report.outstanding = [...report.outstanding, 'Private Memory and Knowledge Vault context was withheld from cloud inference by the local privacy setting.'];
      }
      return report;
    };

    const performFallback = async (reason: string, failure?: any): Promise<LorinCompletionReport | null> => {
      if (!mayAttemptCloudFallback(failure)) return null;
      const cloudDecision = routeModelRequest({
        kind: queryKind,
        privacyMode: 'CLOUD_ALLOWED',
        estimatedInputTokens: requestedTokens,
        estimatedOutputTokens: 2048,
        requireStreaming: options?.requireStreaming ?? Boolean(onChunk),
        allowCloudFallback: true,
        minimumHealthAgeMs: 60_000
      }, providers.filter(provider => provider.kind !== 'OLLAMA_LOCAL'));
      if (!cloudDecision.selected) return null;
      const cloudSelected = cloudDecision.selected;
      const cloudBackend = cloudSelected.id === 'ollama-cloud' ? ollamaCloud : gemini;
      const cloudContextAllowed = options?.allowCloudContextTransmission === true && CloudPrivacyGate.isCloudContextPermitted();
      const cloudOptions: InferenceOptions = {
        ...options,
        requestedModel: options?.requestedModel || cloudSelected.modelId,
        requestedProvider: cloudSelected.id === 'ollama-cloud' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
        allowCloudContextTransmission: cloudContextAllowed
      };
      try {
        const fallbackReport = await this.invokeSelected(
          cloudBackend,
          prompt,
          cloudContextAllowed ? context : undefined,
          undefined,
          trackedChunk,
          cloudOptions
        );
        return applyAttribution(
          fallbackReport,
          cloudSelected.kind === 'OTHER_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
          cloudSelected.modelId,
          fallbackReport.status !== 'FAILED' && fallbackReport.status !== 'BLOCKED',
          `Explicit LOCAL_FIRST_WITH_CLOUD_FALLBACK permission was enabled; local inference failed (${reason}). Private context${cloudContextAllowed ? ' was explicitly permitted' : ' remained withheld'} and no image was forwarded.`
        );
      } catch (fallbackError: any) {
        return this.failureReport(
          prompt,
          `Local inference failed (${reason}); explicitly permitted cloud fallback also failed (${fallbackError?.message || 'provider error'}).`,
          cloudSelected.kind === 'OTHER_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
          cloudSelected.modelId,
          fallbackError?.name === 'AbortError' || options?.signal?.aborted === true
        );
      }
    };

    try {
      const report = await this.invokeSelected(backend, prompt, context, snapshotImage, trackedChunk, actualOptions);
      if (report.status === 'FAILED') {
        const fallback = await performFallback(report.rawSynthesis || 'Local provider returned a failure report.', report);
        if (fallback) return fallback;
      }
      return applyAttribution(
        report,
        selected.kind === 'OLLAMA_LOCAL' ? 'OLLAMA_LOCAL' : selected.kind === 'OTHER_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI',
        selected.modelId,
        strategy === 'LOCAL_FIRST_WITH_CLOUD_FALLBACK' && selected.kind !== 'OLLAMA_LOCAL',
        selected.kind !== 'OLLAMA_LOCAL' && strategy === 'LOCAL_FIRST_WITH_CLOUD_FALLBACK'
          ? 'No eligible healthy local provider was available; explicit cloud fallback permission allowed this cloud route.'
          : undefined
      );
    } catch (error: any) {
      const fallback = await performFallback(error?.message || 'Local provider request failed.', error);
      if (fallback) return fallback;
      return this.failureReport(prompt, error?.message || 'Selected provider failed before returning a response.', selected.kind === 'OLLAMA_LOCAL' ? 'OLLAMA_LOCAL' : selected.kind === 'OTHER_CLOUD' ? 'OLLAMA_CLOUD' : 'LIVE_GEMINI', selected.modelId, error?.name === 'AbortError' || options?.signal?.aborted);
    }
  }

  /**
   * Routes explicit provider choices directly and automatic strategies through
   * live health probes + deterministic privacy/capability-aware decisions.
   * Provider failure never becomes an offline mock answer.
   */
  static async route(
    prompt: string,
    strategy: RoutingStrategy = 'LIVE_GEMINI',
    context?: string,
    snapshotImage?: string,
    onChunk?: (text: string) => void,
    options?: InferenceOptions
  ): Promise<LorinCompletionReport> {
    const gemini = new LiveGeminiBackend();
    const ollamaCloud = new OllamaCloudBackend();
    const ollama = new OllamaLocalBackend();
    const mock = new DeterministicMockBackend();

    if (strategy === 'DETERMINISTIC_MOCK') return mock.infer(prompt, context, snapshotImage, options);
    if (strategy === 'OFFLINE_VAULT') {
      const offlineReport = OfflineIntelligenceService.generateResponse(prompt, context, options?.activeSpecialists);
      if (onChunk && offlineReport.rawSynthesis) onChunk(offlineReport.rawSynthesis);
      return offlineReport;
    }
    if (options?.signal?.aborted) return this.failureReport(prompt, 'Request cancelled before provider dispatch.', strategy, options?.requestedModel || 'automatic', true);

    if (strategy === 'CLOUD_INTELLIGENCE_ROUTER' || strategy === 'DUAL_TASK_COMPLEXITY' || strategy === 'LOCAL_FIRST_WITH_CLOUD_FALLBACK') {
      return this.routeAutomatically(prompt, strategy, context, snapshotImage, onChunk, options);
    }

    const backend: ModelBackend = strategy === 'OLLAMA_LOCAL' ? ollama
      : strategy === 'OLLAMA_CLOUD' ? ollamaCloud : gemini;
    const health = await backend.healthCheck();
    if (!health.healthy || !health.liveAvailable) {
      return this.failureReport(prompt, health.message || `${strategy} provider is unavailable.`, strategy, options?.requestedModel || health.model, false);
    }

    try {
      const directOptions: InferenceOptions = {
        ...options,
        requestedProvider: strategy === 'OLLAMA_CLOUD' ? 'OLLAMA_CLOUD' : strategy === 'OLLAMA_LOCAL' ? undefined : 'LIVE_GEMINI',
        allowCloudContextTransmission: strategy === 'OLLAMA_LOCAL' ? false : options?.allowCloudContextTransmission
      };
      const report = await this.invokeSelected(backend, prompt, context, snapshotImage, onChunk, directOptions);
      return report;
    } catch (error: any) {
      return this.failureReport(prompt, error?.message || `${strategy} provider request failed.`, strategy, options?.requestedModel || health.model, error?.name === 'AbortError' || options?.signal?.aborted);
    }
  }
}
