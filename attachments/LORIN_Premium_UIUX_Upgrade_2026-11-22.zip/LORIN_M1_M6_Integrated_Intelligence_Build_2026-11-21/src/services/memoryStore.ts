import { MemoryDomain, MemoryRecord, Principal } from '../types/lorin';
import { auth, deleteMemoryRecordRemote, loadMemoryRecordsRemote, persistMemoryRecordRemote } from './firebase';

const MEMORY_STORAGE_KEY = 'lorin_persistent_memory_v2';
const LEGACY_UNSCOPED_MEMORY_KEY = 'lorin_persistent_memory_v1';
const LEGACY_MEMORY_BACKUP_KEY = 'lorin_persistent_memory_v1_legacy_unscoped_backup';
const MEMORY_SYNC_QUEUE_KEY = 'lorin_memory_sync_queue_v1';
const GUEST_USER_ID = 'guest_unauthenticated';
const MEMORY_DOMAINS: MemoryDomain[] = [
  'USER_PREFERENCES',
  'PROJECT_REQUIREMENTS',
  'TASK_HISTORY',
  'KNOWLEDGE_BASE',
  'OPERATIONAL_LESSONS'
];

interface PendingMemoryOperation {
  id: string;
  type: 'UPSERT' | 'DELETE';
  memoryId: string;
  record?: MemoryRecord;
  queuedAt: number;
}

function isValidMemoryRecord(value: unknown): value is MemoryRecord {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = value as Partial<MemoryRecord>;
  return Boolean(
    typeof record.id === 'string' && /^[A-Za-z0-9_-]{1,128}$/.test(record.id) &&
    typeof record.domain === 'string' && MEMORY_DOMAINS.includes(record.domain as MemoryDomain) &&
    typeof record.key === 'string' && record.key.length > 0 && record.key.length <= 256 &&
    typeof record.title === 'string' && record.title.trim().length > 0 && record.title.length <= 300 &&
    typeof record.content === 'string' && record.content.length <= 20000 &&
    typeof record.provenance === 'string' && record.provenance.length <= 1000 &&
    (record.status === 'CONFIRMED' || record.status === 'PROPOSED') &&
    Array.isArray(record.tags) && record.tags.length <= 30 && record.tags.every((tag) => typeof tag === 'string' && tag.length <= 64) &&
    (record.projectId === undefined || (typeof record.projectId === 'string' && record.projectId.length <= 128)) &&
    Number.isFinite(record.createdAt) && Number.isFinite(record.updatedAt)
  );
}

function isValidMemoryInput(value: unknown): value is Omit<MemoryRecord, 'id' | 'createdAt' | 'updatedAt'> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const record = value as Partial<MemoryRecord>;
  return Boolean(
    typeof record.domain === 'string' && MEMORY_DOMAINS.includes(record.domain as MemoryDomain) &&
    typeof record.key === 'string' && record.key.length > 0 && record.key.length <= 256 &&
    typeof record.title === 'string' && record.title.trim().length > 0 && record.title.length <= 300 &&
    typeof record.content === 'string' && record.content.length <= 20000 &&
    typeof record.provenance === 'string' && record.provenance.length <= 1000 &&
    (record.status === 'CONFIRMED' || record.status === 'PROPOSED') &&
    Array.isArray(record.tags) && record.tags.length <= 30 && record.tags.every((tag) => typeof tag === 'string' && tag.length <= 64) &&
    (record.projectId === undefined || (typeof record.projectId === 'string' && record.projectId.length <= 128))
  );
}

export class MemoryStore {
  private static records: MemoryRecord[] = [];
  private static pendingOperations: PendingMemoryOperation[] = [];
  private static activeUserId = GUEST_USER_ID;

  private static getStorageKey(): string {
    return `${MEMORY_STORAGE_KEY}_${encodeURIComponent(this.activeUserId)}`;
  }

  private static getSyncQueueKey(): string {
    return `${MEMORY_SYNC_QUEUE_KEY}_${encodeURIComponent(this.activeUserId)}`;
  }

  private static isActivePrincipal(principal: Principal): boolean {
    return Boolean(
      principal.authenticated &&
      principal.id &&
      principal.id !== GUEST_USER_ID &&
      principal.id === this.activeUserId &&
      Boolean(principal.canonicalRole) &&
      principal.canonicalRole !== 'RESTRICTED'
    );
  }

  private static quarantineLegacyUnscopedMemory(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      const legacy = localStorage.getItem(LEGACY_UNSCOPED_MEMORY_KEY);
      if (legacy && !localStorage.getItem(LEGACY_MEMORY_BACKUP_KEY)) {
        // The old key had no owner UID, so it cannot safely be assigned to whichever
        // person signs in next. Preserve a private backup for deliberate owner review.
        localStorage.setItem(LEGACY_MEMORY_BACKUP_KEY, legacy);
      }
      if (legacy) localStorage.removeItem(LEGACY_UNSCOPED_MEMORY_KEY);
    } catch (error) {
      console.warn('Legacy unscoped memory could not be quarantined:', error);
    }
  }

  static setActiveUser(uid: string | undefined): void {
    const nextUserId = uid?.trim() || GUEST_USER_ID;
    if (nextUserId === this.activeUserId) return;
    this.activeUserId = nextUserId;
    this.records = [];
    this.pendingOperations = [];
    this.initialize();
  }

  static initialize(): void {
    if (this.activeUserId === GUEST_USER_ID) {
      this.quarantineLegacyUnscopedMemory();
      this.records = [];
      this.pendingOperations = [];
      return;
    }

    try {
      const queueRaw = typeof localStorage !== 'undefined' ? localStorage.getItem(this.getSyncQueueKey()) : null;
      const queueParsed = queueRaw ? JSON.parse(queueRaw) : [];
      this.pendingOperations = Array.isArray(queueParsed)
        ? queueParsed.filter((item: unknown): item is PendingMemoryOperation => {
            if (!item || typeof item !== 'object') return false;
            const op = item as PendingMemoryOperation;
            return (op.type === 'DELETE' && typeof op.memoryId === 'string') ||
              (op.type === 'UPSERT' && typeof op.memoryId === 'string' && isValidMemoryRecord(op.record));
          })
        : [];
      const stored = typeof localStorage !== 'undefined'
        ? localStorage.getItem(this.getStorageKey())
        : null;
      const parsed = stored ? JSON.parse(stored) : [];
      this.records = Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.warn('MemoryStore initialization failed; starting with empty user memory.', error);
      this.records = [];
    }
  }

  private static persist(): void {
    if (this.activeUserId === GUEST_USER_ID) return;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(this.getStorageKey(), JSON.stringify(this.records));
      }
    } catch (e) {
      console.warn('MemoryStore persist error', e);
    }
  }

  private static persistSyncQueue(): void {
    if (this.activeUserId === GUEST_USER_ID || typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(this.getSyncQueueKey(), JSON.stringify(this.pendingOperations));
    } catch (error) {
      console.warn('Memory sync queue could not be persisted locally:', error);
    }
  }

  private static queueUpsert(record: MemoryRecord): void {
    this.pendingOperations = this.pendingOperations.filter((item) => item.memoryId !== record.id);
    this.pendingOperations.push({
      id: `UPSERT:${record.id}`,
      type: 'UPSERT',
      memoryId: record.id,
      record,
      queuedAt: Date.now()
    });
    this.persistSyncQueue();
  }

  private static queueDelete(memoryId: string): void {
    this.pendingOperations = this.pendingOperations.filter((item) => item.memoryId !== memoryId);
    this.pendingOperations.push({
      id: `DELETE:${memoryId}`,
      type: 'DELETE',
      memoryId,
      queuedAt: Date.now()
    });
    this.persistSyncQueue();
  }

  private static async flushPendingOperations(userId: string): Promise<void> {
    if (this.activeUserId !== userId || auth.currentUser?.uid !== userId) return;
    for (const operation of [...this.pendingOperations]) {
      if (this.activeUserId !== userId || auth.currentUser?.uid !== userId) return;
      try {
        if (operation.type === 'UPSERT' && operation.record && isValidMemoryRecord(operation.record)) {
          await persistMemoryRecordRemote(userId, operation.record);
        } else if (operation.type === 'DELETE') {
          await deleteMemoryRecordRemote(userId, operation.memoryId);
        } else {
          if (this.activeUserId !== userId || auth.currentUser?.uid !== userId) return;
          this.pendingOperations = this.pendingOperations.filter((item) => item.id !== operation.id);
          this.persistSyncQueue();
          continue;
        }
        // Do not mutate the next account's in-memory queue if auth changes mid-flight.
        if (this.activeUserId !== userId || auth.currentUser?.uid !== userId) return;
        this.pendingOperations = this.pendingOperations.filter((item) => item.id !== operation.id);
        this.persistSyncQueue();
      } catch (error) {
        console.warn('Memory cloud sync paused; pending operations remain queued.', error);
        break;
      }
    }
  }

  static async syncFromBackend(): Promise<MemoryRecord[]> {
    const userId = this.activeUserId;
    if (typeof window === 'undefined' || userId === GUEST_USER_ID || auth.currentUser?.uid !== userId) {
      return this.records;
    }
    try {
      await this.flushPendingOperations(userId);
      const remoteRecords = (await loadMemoryRecordsRemote(userId)).filter(isValidMemoryRecord);
      if (auth.currentUser?.uid !== userId || this.activeUserId !== userId) return this.records;

      // Firestore wins for matching IDs unless this device has a newer local version.
      // Local-only/newer records are retained and queued so offline work is not discarded.
      const remoteById = new Map(remoteRecords.map((record) => [record.id, record]));
      const merged = new Map(remoteById);
      for (const localRecord of this.records) {
        const remoteRecord = remoteById.get(localRecord.id);
        if (!remoteRecord || localRecord.updatedAt > remoteRecord.updatedAt) {
          merged.set(localRecord.id, localRecord);
          this.queueUpsert(localRecord);
        }
      }
      this.records = Array.from(merged.values()).sort((a, b) => b.updatedAt - a.updatedAt);
      this.persist();
      await this.flushPendingOperations(userId);
      return this.records;
    } catch (error) {
      console.warn('Firestore memory sync deferred; account-scoped local cache and queue retained.', error);
      return this.records;
    }
  }

  static getRecordsByDomain(domain: MemoryDomain): MemoryRecord[] {
    return this.records.filter(r => r.domain === domain);
  }

  static getAllRecords(): MemoryRecord[] {
    return [...this.records];
  }

  static getRecordById(id: string): MemoryRecord | undefined {
    return this.records.find(r => r.id === id);
  }

  static searchRecords(query: string, domain?: MemoryDomain, status?: 'CONFIRMED' | 'PROPOSED'): MemoryRecord[] {
    const q = query.toLowerCase().trim();
    return this.records.filter(r => {
      if (domain && r.domain !== domain) return false;
      if (status && r.status !== status) return false;
      if (!q) return true;
      return (
        r.title.toLowerCase().includes(q) ||
        r.content.toLowerCase().includes(q) ||
        r.key.toLowerCase().includes(q) ||
        r.tags.some(t => t.toLowerCase().includes(q))
      );
    });
  }

  static createRecord(
    record: Omit<MemoryRecord, 'id' | 'createdAt' | 'updatedAt'>,
    principal: Principal
  ): { success: boolean; record?: MemoryRecord; message: string } {
    if (!this.isActivePrincipal(principal)) {
      return { success: false, message: 'Authentication for the active account is required to write memory.' };
    }
    if (principal.canonicalRole === 'RESTRICTED') {
      return { success: false, message: 'Guest principals cannot create persistent records.' };
    }
    if (!isValidMemoryInput(record)) {
      return { success: false, message: 'Memory record failed schema validation.' };
    }

    const newRecord: MemoryRecord = {
      id: `mem_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      ...record
    };

    this.records.unshift(newRecord);
    this.persist();
    this.queueUpsert(newRecord);
    this.flushPendingOperations(principal.id).catch(() => {});
    return { success: true, record: newRecord, message: 'Memory record stored locally; cloud synchronization is queued.' };
  }

  static updateRecord(
    id: string,
    updates: Partial<Omit<MemoryRecord, 'id' | 'createdAt' | 'updatedAt'>>,
    principal: Principal
  ): { success: boolean; message: string } {
    if (!this.isActivePrincipal(principal)) {
      return { success: false, message: 'Permission denied. The active authenticated account is required to modify memory.' };
    }

    const idx = this.records.findIndex(r => r.id === id);
    if (idx === -1) {
      return { success: false, message: 'Record not found.' };
    }

    const updatedRecord = {
      ...this.records[idx],
      ...updates,
      updatedAt: Date.now()
    };
    if (!isValidMemoryRecord(updatedRecord)) {
      return { success: false, message: 'Updated memory record failed schema validation.' };
    }
    this.records[idx] = updatedRecord;

    this.persist();
    this.queueUpsert(this.records[idx]);
    this.flushPendingOperations(principal.id).catch(() => {});
    return { success: true, message: 'Record updated locally; cloud synchronization is queued.' };
  }

  static confirmSuggestion(id: string, principal: Principal): { success: boolean; message: string } {
    return this.updateRecord(
      id,
      {
        status: 'CONFIRMED',
        provenance: `Confirmed by ${principal.name} (${principal.role}) on ${new Date().toLocaleDateString()}`
      },
      principal
    );
  }

  static rejectSuggestion(id: string, principal: Principal): { success: boolean; message: string } {
    if (!this.isActivePrincipal(principal)) {
      return { success: false, message: 'Permission denied.' };
    }
    const candidate = this.records.find((record) => record.id === id);
    if (!candidate || candidate.status !== 'PROPOSED') {
      return { success: false, message: 'Proposed memory suggestion not found.' };
    }
    this.records = this.records.filter(r => r.id !== id);
    this.persist();
    this.queueDelete(id);
    this.flushPendingOperations(principal.id).catch(() => {});
    return { success: true, message: 'Proposed memory suggestion removed locally; cloud deletion is queued.' };
  }

  static deleteRecord(id: string, principal: Principal): { success: boolean; message: string } {
    if (!this.isActivePrincipal(principal) || principal.canonicalRole !== 'SYSTEM_OWNER') {
      return { success: false, message: 'Permission denied. Only the verified System Owner can delete persistent memory records.' };
    }

    const initialLength = this.records.length;
    this.records = this.records.filter(r => r.id !== id);
    if (this.records.length === initialLength) {
      return { success: false, message: 'Record not found.' };
    }

    this.persist();
    this.queueDelete(id);
    this.flushPendingOperations(principal.id).catch(() => {});
    return { success: true, message: 'Record removed locally; cloud deletion is queued.' };
  }

  /**
   * Builds a concise context summary of CONFIRMED personal memories relevant to the current prompt and active project.
   * Strictly separates confirmed personal memory from conversation history and Vault documents (Part G Section 8.2).
   */
  static getConfirmedContextSummary(prompt: string, activeProjectId?: string): string {
    const confirmed = this.records.filter(
      r => r.status === 'CONFIRMED' && (!r.projectId || r.projectId === activeProjectId)
    );
    if (confirmed.length === 0) return '';

    const q = (prompt || '').toLowerCase();
    const scored = confirmed
      .map(rec => {
        let score = rec.domain === 'USER_PREFERENCES' || rec.domain === 'PROJECT_REQUIREMENTS' ? 2 : 1;
        if (q && (rec.title.toLowerCase().includes(q) || rec.tags.some(t => q.includes(t.toLowerCase())))) {
          score += 3;
        }
        return { rec, score };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    return (
      `[Confirmed Personal Memory Records (Approved by Owner — Distinct from Vault Documents)]:\n` +
      scored.map(({ rec }) => `- [${rec.domain}] ${rec.title}: ${rec.content} (Source: ${rec.provenance})`).join('\n')
    );
  }

  static exportJson(): string {
    return JSON.stringify(this.records, null, 2);
  }

  static importJson(jsonString: string, principal: Principal): { success: boolean; count: number; message: string } {
    if (!this.isActivePrincipal(principal) || principal.canonicalRole !== 'SYSTEM_OWNER') {
      return { success: false, count: 0, message: 'Only the verified System Owner can import memory records.' };
    }

    try {
      const parsed = JSON.parse(jsonString);
      if (!Array.isArray(parsed) || parsed.length > 1000 || !parsed.every(isValidMemoryRecord)) {
        return { success: false, count: 0, message: 'Invalid format: expected up to 1,000 schema-valid memory records.' };
      }
      const importedIds = new Set((parsed as MemoryRecord[]).map((record) => record.id));
      const removedIds = this.records.map((record) => record.id).filter((id) => !importedIds.has(id));
      this.records = parsed;
      this.persist();
      removedIds.forEach((id) => this.queueDelete(id));
      parsed.forEach((record: MemoryRecord) => this.queueUpsert(record));
      this.flushPendingOperations(principal.id).catch(() => {});
      return { success: true, count: parsed.length, message: `Imported ${parsed.length} records locally; cloud synchronization is queued.` };
    } catch (e: any) {
      return { success: false, count: 0, message: `Import failed: ${e.message}` };
    }
  }

  static resetToDefault(principal: Principal): boolean {
    if (!this.isActivePrincipal(principal) || principal.canonicalRole !== 'SYSTEM_OWNER') return false;
    const existingIds = this.records.map((record) => record.id);
    this.records = [];
    this.persist();
    existingIds.forEach((id) => this.queueDelete(id));
    this.flushPendingOperations(principal.id).catch((error) => {
      console.warn('Cloud memory deletion remains queued.', error);
    });
    return true;
  }
}

MemoryStore.initialize();

