import {
  DailyEngineeringGoal,
  DurableTaskRecord,
  DurableTaskState,
  DurableTaskStep,
  Principal,
  RiskLevel,
  SpecialistRole
} from '../types/lorin';
import { PolicyEngine } from './policyEngine';
import { authFetch } from './authHeaders';
import { GideonService } from './gideonService';

const normalizeTaskUid = (uid: string) => uid || 'guest';
const getTaskStorageKey = (uid: string) => `lorin_durable_tasks_v2_${normalizeTaskUid(uid)}`;
const getDailyGoalsStorageKey = (uid: string) => `lorin_daily_goals_v2_${normalizeTaskUid(uid)}`;

function matchesTaskProjectId(itemProjectId: string | undefined, filterProjectId: string | undefined): boolean {
  if (!filterProjectId || filterProjectId === 'ALL') return true;
  if (itemProjectId === filterProjectId) return true;
  if (
    (filterProjectId === 'proj_lorin_core' || filterProjectId === 'proj_lorin_v2') &&
    (itemProjectId === 'proj_lorin_core' || itemProjectId === 'proj_lorin_v2')
  ) {
    return true;
  }
  return false;
}

export const MAX_DAILY_GOALS = 5;

const LEGACY_SEEDED_TASK_IDS = new Set(['task_dur_01', 'task_dur_02', 'task_dur_03']);
const LEGACY_SEEDED_DAILY_GOAL_IDS = new Set(['dgoal_seed_01', 'dgoal_seed_02']);

export interface DurableTaskExecutionResult {
  success: boolean;
  verified?: boolean;
  output?: string;
  evidence?: string;
  error?: string;
}

export interface DurableTaskExecutionContext {
  task: Readonly<DurableTaskRecord>;
  step: Readonly<DurableTaskStep>;
  principal: Readonly<Principal>;
}

/**
 * A trusted, application-registered executor. This is deliberately not a
 * model-authored code hook. Production executors should call a server endpoint
 * that independently authenticates the user, re-checks policy and validates
 * the operation. A task can only run when its executorKey is registered by
 * trusted application code.
 */
export type DurableTaskStepExecutor = (
  context: DurableTaskExecutionContext
) => Promise<DurableTaskExecutionResult>;

function normalizeStoredTasks(value: unknown): DurableTaskRecord[] {
  if (!Array.isArray(value)) return [];

  return value
    .filter((task): task is DurableTaskRecord =>
      !!task &&
      typeof task === 'object' &&
      typeof (task as DurableTaskRecord).id === 'string' &&
      !LEGACY_SEEDED_TASK_IDS.has((task as DurableTaskRecord).id)
    )
    .map(task => {
      const syntheticCompletion =
        task.state === 'SUCCEEDED' &&
        (
          task.steps?.some(step => typeof step.output === 'string' && step.output.startsWith('Verified by ')) ||
          task.executionLog?.some(line => line.includes('[Iris] Verified completion of all ')) ||
          (typeof task.resultSummary === 'string' && task.resultSummary.includes('workflow steps completed and verified under'))
        );

      if (!syntheticCompletion) return task;

      // Older builds marked steps successful without invoking a real executor.
      // Keep the task, but require it to be re-executed and independently verified.
      return {
        ...task,
        state: 'BLOCKED',
        completedAt: undefined,
        resultSummary: undefined,
        errorDetails: 'Legacy completion was recorded without executor evidence. Re-run only after a trusted executor is configured.',
        steps: (task.steps || []).map(step => ({
          ...step,
          status: 'PENDING',
          output: undefined,
          completedAt: undefined
        })),
        executionLog: [
          ...(task.executionLog || []),
          '[Lena] Legacy synthetic completion downgraded during integrity migration; no execution success is assumed.'
        ]
      };
    });
}

function normalizeStoredDailyGoals(value: unknown): DailyEngineeringGoal[] {
  if (!Array.isArray(value)) return [];
  return value.filter((goal): goal is DailyEngineeringGoal =>
    !!goal &&
    typeof goal === 'object' &&
    typeof (goal as DailyEngineeringGoal).id === 'string' &&
    !LEGACY_SEEDED_DAILY_GOAL_IDS.has((goal as DailyEngineeringGoal).id)
  );
}

export class TaskQueueService {
  private static activeUserId = 'guest_unauthenticated';
  private static tasks: DurableTaskRecord[] = [];
  private static dailyGoals: DailyEngineeringGoal[] = [];
  private static listeners: Array<() => void> = [];
  private static executors = new Map<string, DurableTaskStepExecutor>();

  static subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private static notifyListeners(): void {
    for (const listener of this.listeners) {
      try {
        listener();
      } catch {}
    }
  }

  static getTodayDateKey(): string {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  static setActiveUser(uid: string): void {
    this.activeUserId = normalizeTaskUid(uid || 'guest_unauthenticated');
    this.load();
    this.loadDailyGoals();
  }

  private static persistToServer(): void {
    if (typeof window === 'undefined' || this.activeUserId === 'guest_unauthenticated') return;
    authFetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tasks: this.tasks,
        dailyGoals: this.dailyGoals
      })
    }).catch(() => {});
  }

  static async syncFromBackend(): Promise<void> {
    if (typeof window === 'undefined' || this.activeUserId === 'guest_unauthenticated') return;
    try {
      const res = await authFetch('/api/tasks', {
        headers: { Accept: 'application/json' }
      });
      if (!res.ok) return;
      const data = await res.json();
      let updated = false;
      let migratedLegacyRecords = false;
      if (Array.isArray(data?.tasks)) {
        this.tasks = normalizeStoredTasks(data.tasks);
        migratedLegacyRecords = this.tasks.length !== data.tasks.length;
        try {
          localStorage.setItem(getTaskStorageKey(this.activeUserId), JSON.stringify(this.tasks));
        } catch {}
        updated = true;
      }
      if (Array.isArray(data?.dailyGoals)) {
        this.dailyGoals = normalizeStoredDailyGoals(data.dailyGoals);
        migratedLegacyRecords = migratedLegacyRecords || this.dailyGoals.length !== data.dailyGoals.length;
        try {
          localStorage.setItem(getDailyGoalsStorageKey(this.activeUserId), JSON.stringify(this.dailyGoals));
        } catch {}
        updated = true;
      }
      if (!updated) {
        if (this.tasks.length === 0) this.load();
        if (this.dailyGoals.length === 0) this.loadDailyGoals();
        this.persistToServer();
      } else {
        this.reconcileDailyGoalsWithTasks(false);
        this.notifyListeners();
      }
      if (migratedLegacyRecords) this.persistToServer();
    } catch {}
  }

  private static load(): void {
    this.tasks = [];
    try {
      if (typeof localStorage === 'undefined') return;
      const raw = localStorage.getItem(getTaskStorageKey(this.activeUserId));
      if (!raw) return;

      const parsed: unknown = JSON.parse(raw);
      if (!Array.isArray(parsed)) return;

      const normalized = normalizeStoredTasks(parsed);
      this.tasks = normalized;
      if (normalized.length !== parsed.length || JSON.stringify(normalized) !== JSON.stringify(parsed)) {
        localStorage.setItem(getTaskStorageKey(this.activeUserId), JSON.stringify(normalized));
      }
    } catch {
      // Corrupt local data is not replaced with fabricated sample tasks.
      this.tasks = [];
    }
  }

  private static save(syncServer = true): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(getTaskStorageKey(this.activeUserId), JSON.stringify(this.tasks));
      }
    } catch {}
    if (syncServer) this.persistToServer();
    this.notifyListeners();
  }

  private static loadDailyGoals(): void {
    this.dailyGoals = [];
    try {
      if (typeof localStorage === 'undefined') return;
      const raw = localStorage.getItem(getDailyGoalsStorageKey(this.activeUserId));
      if (!raw) return;

      const parsed: unknown = JSON.parse(raw);
      if (!Array.isArray(parsed)) return;

      this.dailyGoals = normalizeStoredDailyGoals(parsed);
      if (this.dailyGoals.length !== parsed.length) {
        localStorage.setItem(getDailyGoalsStorageKey(this.activeUserId), JSON.stringify(this.dailyGoals));
      }
    } catch {
      // Do not create sample goals when local data is missing or unreadable.
      this.dailyGoals = [];
    }
  }

  private static saveDailyGoals(syncServer = true): void {
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(getDailyGoalsStorageKey(this.activeUserId), JSON.stringify(this.dailyGoals));
      }
    } catch {}
    if (syncServer) this.persistToServer();
    this.notifyListeners();
  }

  /**
   * Keeps DailyEngineeringGoal status synchronized with linked DurableTaskRecord states
   */
  private static reconcileDailyGoalsWithTasks(persistIfChanged = true): void {
    let changed = false;
    for (const goal of this.dailyGoals) {
      if (!goal.linkedTaskId) continue;
      const linkedTask = this.tasks.find(t => t.id === goal.linkedTaskId);
      if (!linkedTask) continue;

      if (linkedTask.state === 'SUCCEEDED' && goal.status !== 'completed') {
        goal.status = 'completed';
        goal.completedAt = linkedTask.completedAt || Date.now();
        changed = true;
      }
    }
    if (changed && persistIfChanged) {
      this.saveDailyGoals();
    }
  }

  static getDailyGoals(projectIdFilter?: string, dateKey?: string): DailyEngineeringGoal[] {
    if (this.tasks.length === 0) this.load();
    if (this.dailyGoals.length === 0) this.loadDailyGoals();
    this.reconcileDailyGoalsWithTasks(false);

    const targetDate = dateKey || this.getTodayDateKey();
    return this.dailyGoals
      .filter(g => g.dateKey === targetDate && matchesTaskProjectId(g.projectId, projectIdFilter))
      .sort((a, b) => a.createdAt - b.createdAt);
  }

  static addDailyGoal(
    title: string,
    projectId: string,
    principal: Principal
  ): { success: boolean; goal?: DailyEngineeringGoal; task?: DurableTaskRecord; message: string } {
    if (!principal.authenticated || principal.role === 'GUEST') {
      return { success: false, message: 'Authentication required to define daily engineering goals.' };
    }

    const cleanTitle = title.trim();
    if (!cleanTitle) {
      return { success: false, message: 'Goal title is required.' };
    }

    if (this.tasks.length === 0) this.load();
    if (this.dailyGoals.length === 0) this.loadDailyGoals();

    const today = this.getTodayDateKey();
    const todayGoals = this.dailyGoals.filter(g => g.dateKey === today);

    if (todayGoals.length >= MAX_DAILY_GOALS) {
      return {
        success: false,
        message: `Daily limit reached (${MAX_DAILY_GOALS}/${MAX_DAILY_GOALS}): You can define up to ${MAX_DAILY_GOALS} small development tasks for the day.`
      };
    }

    if (todayGoals.some(g => g.title.toLowerCase() === cleanTitle.toLowerCase())) {
      return {
        success: false,
        message: `Daily goal "${cleanTitle}" is already tracked for today.`
      };
    }

    const targetProject = projectId && projectId !== 'ALL' ? projectId : 'UNASSIGNED';

    const now = Date.now();
    const newGoal: DailyEngineeringGoal = {
      id: `dgoal_${now}_${Math.random().toString(36).substring(2, 6)}`,
      title: cleanTitle,
      projectId: targetProject,
      dateKey: today,
      status: 'pending',
      createdAt: now
    };

    // A personal daily goal is a tracker, not an executable task. Checking it
    // off must never trigger code, shell, provider, or device operations.
    this.dailyGoals.push(newGoal);
    this.saveDailyGoals();

    return {
      success: true,
      goal: newGoal,
      message: `Daily goal added (${todayGoals.length + 1}/${MAX_DAILY_GOALS}). It is tracked separately from executable tasks.`
    };
  }

  static async toggleDailyGoalCompleted(
    goalId: string,
    principal: Principal
  ): Promise<{ success: boolean; goal?: DailyEngineeringGoal; task?: DurableTaskRecord; message: string }> {
    if (!principal.authenticated || principal.role === 'GUEST') {
      return { success: false, message: 'Authentication required to update daily goals.' };
    }

    if (this.dailyGoals.length === 0) this.loadDailyGoals();

    const goal = this.dailyGoals.find(g => g.id === goalId);
    if (!goal) {
      return { success: false, message: 'Daily engineering goal not found.' };
    }

    goal.status = goal.status === 'pending' ? 'completed' : 'pending';
    goal.completedAt = goal.status === 'completed' ? Date.now() : undefined;
    this.saveDailyGoals();

    return {
      success: true,
      goal,
      message: goal.status === 'completed'
        ? `Goal "${goal.title}" marked complete by the user. No automated task was executed.`
        : `Goal "${goal.title}" reopened as pending.`
    };
  }

  static removeDailyGoal(
    goalId: string,
    principal: Principal
  ): { success: boolean; message: string } {
    if (!principal.authenticated || principal.role === 'GUEST') {
      return { success: false, message: 'Authentication required to remove daily goals.' };
    }
    const idx = this.dailyGoals.findIndex(g => g.id === goalId);
    if (idx === -1) {
      return { success: false, message: 'Daily engineering goal not found.' };
    }
    const [removed] = this.dailyGoals.splice(idx, 1);
    this.saveDailyGoals();
    return {
      success: true,
      message: `Removed daily goal "${removed.title}".`
    };
  }

  static getTasks(projectIdFilter?: string): DurableTaskRecord[] {
    if (this.tasks.length === 0) this.load();
    return this.tasks
      .filter(t => matchesTaskProjectId(t.projectId, projectIdFilter))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }

  static getTaskById(id: string): DurableTaskRecord | undefined {
    if (this.tasks.length === 0) this.load();
    return this.tasks.find(t => t.id === id);
  }

  /**
   * Register a trusted application-code executor for a known task key.
   * Models, project records and user input cannot register executable handlers.
   */
  static registerExecutor(key: string, executor: DurableTaskStepExecutor): () => void {
    const normalizedKey = key.trim();
    if (!normalizedKey) throw new Error('Executor key is required.');
    if (this.executors.has(normalizedKey)) {
      throw new Error(`A trusted executor is already registered for "${normalizedKey}".`);
    }

    this.executors.set(normalizedKey, executor);
    return () => {
      if (this.executors.get(normalizedKey) === executor) {
        this.executors.delete(normalizedKey);
      }
    };
  }

  static createTask(
    input: {
      title: string;
      description: string;
      projectId: string;
      priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
      riskLevel: RiskLevel;
      dependencies?: string[];
      steps?: { title: string; specialist: SpecialistRole }[];
      executorKey?: string;
    },
    principal: Principal
  ): { success: boolean; task?: DurableTaskRecord; message: string } {
    if (!principal.authenticated || principal.role === 'GUEST') {
      return { success: false, message: 'Authentication required to create durable tasks.' };
    }

    const cleanTitle = input.title.trim();
    if (!cleanTitle) {
      return { success: false, message: 'Task title is required.' };
    }

    // Duplicate prevention check for active tasks
    const duplicate = this.tasks.find(
      t =>
        t.title.toLowerCase() === cleanTitle.toLowerCase() &&
        t.projectId === input.projectId &&
        (t.state === 'QUEUED' || t.state === 'RUNNING' || t.state === 'AWAITING_APPROVAL')
    );
    if (duplicate) {
      return {
        success: false,
        message: `Duplicate active task prevented: "${cleanTitle}" is already ${duplicate.state}.`
      };
    }

    const now = Date.now();
    const requiresApproval = input.riskLevel === 'HIGH' || input.riskLevel === 'CRITICAL';
    const deps = input.dependencies || [];
    const hasUnmetDeps = deps.some(depId => {
      const depTask = this.tasks.find(t => t.id === depId);
      return !depTask || depTask.state !== 'SUCCEEDED';
    });

    const initialState: DurableTaskState = hasUnmetDeps
      ? 'BLOCKED'
      : requiresApproval
      ? 'AWAITING_APPROVAL'
      : 'QUEUED';

    const steps: DurableTaskStep[] = (
      input.steps && input.steps.length > 0
        ? input.steps
        : [
            { title: 'Inspect target context & preconditions', specialist: 'IRIS_INVESTIGATOR' as SpecialistRole },
            { title: 'Evaluate security & permission boundary', specialist: 'LENA_GUARDIAN' as SpecialistRole },
            { title: 'Execute & verify task objective', specialist: 'NOLAN_STRATEGIST' as SpecialistRole }
          ]
    ).map((s, idx) => ({
      id: `stp_${now}_${idx + 1}`,
      title: s.title,
      specialist: s.specialist,
      status: 'PENDING'
    }));

    const newTask: DurableTaskRecord = {
      id: `task_${now}_${Math.random().toString(36).substring(2, 6)}`,
      title: cleanTitle,
      description: input.description.trim() || cleanTitle,
      projectId: input.projectId || 'UNASSIGNED',
      executorKey: input.executorKey?.trim() || undefined,
      state: initialState,
      priority: input.priority,
      riskLevel: input.riskLevel,
      requiresOwnerApproval: requiresApproval,
      dependencies: deps,
      steps,
      retryCount: 0,
      maxRetries: 3,
      executionLog: [
        `[Owen] Created durable task "${cleanTitle}" with initial state ${initialState}.`,
        ...(requiresApproval
          ? ['[Lena] High-impact risk classification requires explicit Owner policy approval before execution.']
          : [])
      ],
      createdBy: principal.name || principal.email || 'Operator',
      createdAt: now,
      updatedAt: now
    };

    this.tasks.unshift(newTask);
    this.save();
    return { success: true, task: newTask, message: `Task created in ${initialState} state.` };
  }

  /**
   * Executes or advances a durable task through PolicyEngine verification and bounded steps
   */
  static async executeTask(
    taskId: string,
    principal: Principal
  ): Promise<{ success: boolean; task?: DurableTaskRecord; message: string }> {
    const idx = this.tasks.findIndex(t => t.id === taskId);
    if (idx === -1) return { success: false, message: 'Task not found.' };

    const task = this.tasks[idx];

    if (task.state === 'CANCELLED') {
      return { success: false, task, message: 'Cannot execute a cancelled task. Use Retry to requeue.' };
    }

    // Check dependencies
    const unmetDeps = task.dependencies.filter(depId => {
      const dep = this.tasks.find(d => d.id === depId);
      return !dep || dep.state !== 'SUCCEEDED';
    });
    if (unmetDeps.length > 0) {
      task.state = 'BLOCKED';
      task.updatedAt = Date.now();
      task.executionLog.push(`[Owen] Execution blocked: unmet dependency (${unmetDeps.join(', ')}).`);
      this.save();
      return { success: false, task, message: `Task is BLOCKED by unmet dependencies: ${unmetDeps.join(', ')}` };
    }

    const executorKey = task.executorKey?.trim();
    const executor = executorKey ? this.executors.get(executorKey) : undefined;
    if (!executor) {
      task.state = 'BLOCKED';
      task.completedAt = undefined;
      task.resultSummary = undefined;
      task.errorDetails = executorKey
        ? `No trusted executor is registered for "${executorKey}".`
        : 'No trusted executor is assigned to this task. Planning and policy approval do not execute work.';
      task.updatedAt = Date.now();
      task.executionLog.push(`[Owen] Execution was not attempted: ${task.errorDetails}`);
      this.save();
      return {
        success: false,
        task,
        message: `Task is BLOCKED. ${task.errorDetails}`
      };
    }

    // Evaluate policy via PolicyEngine
    const evalRes = await PolicyEngine.evaluateAction(principal, {
      id: `task_exec_${task.id}`,
      action: task.requiresOwnerApproval ? `deploy_production_${task.id}` : `execute_task_${task.id}`,
      resource: `project://${task.projectId}/tasks/${task.id}`,
      description: task.title,
      riskLevel: task.riskLevel,
      requiredScope: task.requiresOwnerApproval ? 'admin:write' : 'code:read'
    });

    if (evalRes.decision === 'DENY') {
      task.state = 'FAILED';
      task.errorDetails = evalRes.reason;
      task.updatedAt = Date.now();
      task.executionLog.push(`[Lena] Policy denied execution: ${evalRes.reason}`);
      this.save();
      return { success: false, task, message: `Execution denied: ${evalRes.reason}` };
    }

    if (evalRes.decision === 'REQUIRES_APPROVAL') {
      task.state = 'AWAITING_APPROVAL';
      task.approvalId = evalRes.approvalRecord?.id;
      task.updatedAt = Date.now();
      task.executionLog.push(
        `[Lena] Task requires cryptographic Owner approval (Approval ID: ${evalRes.approvalRecord?.id || 'pending'}).`
      );
      this.save();
      return {
        success: false,
        task,
        message: 'Task is AWAITING_APPROVAL. Approve the pending action in Security & Policy or Owner Control Plane.'
      };
    }

    // A policy decision permits an attempt; only an actual trusted executor
    // plus explicit verification evidence may produce SUCCEEDED.
    task.state = 'RUNNING';
    task.completedAt = undefined;
    task.resultSummary = undefined;
    task.errorDetails = undefined;
    task.executionLog.push(`[Owen] Policy authorized (${evalRes.reason}). Running registered executor "${executorKey}".`);
    this.save();

    for (const step of task.steps) {
      if (step.status === 'COMPLETED' && typeof step.output === 'string' && step.output.includes('Evidence:')) {
        continue;
      }

      step.status = 'RUNNING';
      this.save();

      let result: DurableTaskExecutionResult;
      try {
        const context: DurableTaskExecutionContext = {
          task: JSON.parse(JSON.stringify(task)) as DurableTaskRecord,
          step: JSON.parse(JSON.stringify(step)) as DurableTaskStep,
          principal: { ...principal }
        };
        result = await executor(context);
      } catch (error) {
        result = {
          success: false,
          error: error instanceof Error ? error.message : 'Executor failed with an unknown error.'
        };
      }

      const evidence = typeof result.evidence === 'string' ? result.evidence.trim() : '';
      if (!result.success || result.verified !== true || !evidence) {
        step.status = 'FAILED';
        step.output = result.error || 'Executor did not return a verified result with evidence.';
        task.state = 'FAILED';
        task.completedAt = undefined;
        task.resultSummary = undefined;
        task.errorDetails = step.output;
        task.updatedAt = Date.now();
        task.executionLog.push(`[Lena] Step "${step.title}" did not pass execution verification; task remains unsuccessful.`);
        this.save();
        return {
          success: false,
          task,
          message: `Task failed verification at step "${step.title}". ${task.errorDetails}`
        };
      }

      step.status = 'COMPLETED';
      step.output = `${(result.output || 'Executor completed the step').trim()}\nEvidence: ${evidence}`;
      step.completedAt = Date.now();
      task.updatedAt = Date.now();
      task.executionLog.push(`[${step.specialist}] Executor completed and supplied verification evidence for "${step.title}".`);
      this.save();
    }

    task.state = 'SUCCEEDED';
    task.updatedAt = Date.now();
    task.completedAt = Date.now();
    task.errorDetails = undefined;
    task.resultSummary = `All ${task.steps.length} workflow steps completed by registered executor "${executorKey}" with verification evidence.`;
    task.executionLog.push(`[Iris] Verified completion from registered executor evidence. Status -> SUCCEEDED.`);
    this.reconcileDailyGoalsWithTasks(true);
    this.save();

    GideonService.recordEvent({
      ownerUid: principal.id || 'unknown',
      projectId: task.projectId || 'UNASSIGNED',
      category: 'task',
      title: `Task Succeeded: ${task.title}`,
      summary: task.resultSummary,
      source: 'TaskQueueService',
      sourceReference: task.id,
      occurredAt: Date.now(),
      verificationStatus: 'verified',
      outcome: 'SUCCEEDED'
    }, principal).catch(() => {});

    return { success: true, task, message: `Task "${task.title}" executed and SUCCEEDED.` };
  }

  static async approveAndExecuteTask(
    taskId: string,
    principal: Principal
  ): Promise<{ success: boolean; task?: DurableTaskRecord; message: string }> {
    if (principal.role !== 'OWNER') {
      return { success: false, message: 'Only verified OWNER can approve high-impact tasks.' };
    }
    const task = this.tasks.find(t => t.id === taskId);
    if (!task) return { success: false, message: 'Task not found.' };
    if (!task.executorKey || !this.executors.has(task.executorKey)) {
      return {
        success: false,
        task,
        message: 'Approval was not requested or consumed because no trusted executor is registered for this task.'
      };
    }

    if (task.approvalId) {
      await PolicyEngine.approveAction(task.approvalId, principal);
      task.executionLog.push(`[Lena] Owner approved cryptographic digest (${task.approvalId}).`);
    } else {
      // Request and immediately approve
      const evalRes = await PolicyEngine.evaluateAction(principal, {
        id: `task_exec_${task.id}`,
        action: `deploy_production_${task.id}`,
        resource: `project://${task.projectId}/tasks/${task.id}`,
        description: task.title,
        riskLevel: task.riskLevel,
        requiredScope: 'admin:write'
      });
      if (evalRes.approvalRecord?.id) {
        task.approvalId = evalRes.approvalRecord.id;
        await PolicyEngine.approveAction(evalRes.approvalRecord.id, principal);
      }
    }

    task.requiresOwnerApproval = false;
    this.save();
    return this.executeTask(taskId, principal);
  }

  static cancelTask(taskId: string, principal: Principal): { success: boolean; message: string } {
    if (!principal.authenticated || principal.role === 'GUEST') {
      return { success: false, message: 'Permission denied.' };
    }
    const task = this.tasks.find(t => t.id === taskId);
    if (!task) return { success: false, message: 'Task not found.' };

    task.state = 'CANCELLED';
    task.updatedAt = Date.now();
    task.executionLog.push(`[Owen] Task cancelled by ${principal.name} (${principal.role}).`);
    this.reconcileDailyGoalsWithTasks(true);
    this.save();
    return { success: true, message: `Task "${task.title}" cancelled.` };
  }

  static retryTask(taskId: string, principal: Principal): Promise<{ success: boolean; task?: DurableTaskRecord; message: string }> {
    const task = this.tasks.find(t => t.id === taskId);
    if (!task) return Promise.resolve({ success: false, message: 'Task not found.' });

    if (task.retryCount >= task.maxRetries) {
      task.state = 'FAILED';
      task.errorDetails = `Bounded retry limit reached (${task.retryCount}/${task.maxRetries}).`;
      task.executionLog.push(`[Owen] Retry rejected: bounded retry limit (${task.maxRetries}) reached.`);
      this.save();
      return Promise.resolve({
        success: false,
        task,
        message: `Bounded retry limit (${task.maxRetries}) reached for this task.`
      });
    }

    task.retryCount += 1;
    task.state = 'QUEUED';
    task.updatedAt = Date.now();
    task.executionLog.push(`[Owen] Retry #${task.retryCount}/${task.maxRetries} initiated by ${principal.name}.`);
    this.save();
    return this.executeTask(taskId, principal);
  }

  static deleteTask(taskId: string, principal: Principal): { success: boolean; message: string } {
    if (principal.role !== 'OWNER') {
      return { success: false, message: 'Only OWNER can delete durable task audit records.' };
    }
    this.tasks = this.tasks.filter(t => t.id !== taskId);
    this.dailyGoals = this.dailyGoals.filter(g => g.linkedTaskId !== taskId);
    this.saveDailyGoals();
    this.save();
    return { success: true, message: 'Task record deleted.' };
  }
}

