/**
 * Ollama Cloud & Central Open-Weight Model Registry Service
 *
 * Implements Section 3 of the LORIN Master Specification:
 * - Cloud-first Ollama Cloud (`https://ollama.com`) via server-side proxy (`/api/ollama-cloud/*` & `/api/models/*`)
 * - Central Model Registry for the 8 preferred open-weight models + Qwen3-Embedding-8B + Google Gemini
 * - Catalogue synchronization (`POST /api/models/sync-catalogue`) & controlled verification (`POST /api/models/verify`)
 * - Optional future local Ollama runtime when dedicated local GPU hardware becomes available (never required for deployment)
 */

import {
  ModelRegistryRecord,
  TaskRoutingCategory,
  TaskRoutingPolicyEntry,
  VaultEmbeddingIndexMeta
} from '../types/lorin';
import { getAuthHeaders } from './authHeaders';
import { consumeOllamaNdjsonStream } from '../core/providers/ollamaNdjson';

export type OllamaConnectionStage =
  | 'INFERENCE_VERIFIED'
  | 'MODEL_INSTALLED'
  | 'SERVICE_AVAILABLE_MODEL_MISSING'
  | 'UNREACHABLE_LOCALHOST'
  | 'ERROR';

export interface LocalModelCandidate {
  tag: string;
  name: string;
  role: string;
  modality: 'text' | 'multimodal' | 'code' | 'embedding' | 'stt' | 'tts';
  minRamGb: number;
  contextWindow: string;
  license: string;
  licenseCategory: 'OPEN_SOURCE_PERMISSIVE' | 'OPEN_WEIGHT_CUSTOM_LICENSE' | 'OPEN_WEIGHT_USAGE_POLICY' | 'PROPRIETARY_CLOUD_HOSTED';
  officialLibraryUrl: string;
  provider: 'ollama-cloud' | 'google-gemini';
}

export const RECOMMENDED_LOCAL_MODEL_CANDIDATES: LocalModelCandidate[] = [
  {
    tag: 'deepseek-v4-flash',
    name: 'DeepSeek V4 Flash',
    role: 'Fast everyday assistant, general chat, coding help & structured outputs',
    modality: 'code',
    minRamGb: 0,
    contextWindow: '128K',
    license: 'MIT License (Permissive Open-Source)',
    licenseCategory: 'OPEN_SOURCE_PERMISSIVE',
    officialLibraryUrl: 'https://ollama.com/library/deepseek-v3.1',
    provider: 'ollama-cloud'
  },
  {
    tag: 'deepseek-v4-pro',
    name: 'DeepSeek V4 Pro',
    role: 'Deep reasoning, complex debugging, system architecture & hard technical analysis',
    modality: 'code',
    minRamGb: 0,
    contextWindow: '128K',
    license: 'MIT License (Permissive Open-Source)',
    licenseCategory: 'OPEN_SOURCE_PERMISSIVE',
    officialLibraryUrl: 'https://ollama.com/library/deepseek-r1',
    provider: 'ollama-cloud'
  },
  {
    tag: 'qwen3.5',
    name: 'Qwen 3.5',
    role: 'Balanced reasoning, coding, multimodal support & tool calling',
    modality: 'multimodal',
    minRamGb: 0,
    contextWindow: '128K',
    license: 'Apache-2.0 / Qwen Open-Source Release License',
    licenseCategory: 'OPEN_SOURCE_PERMISSIVE',
    officialLibraryUrl: 'https://ollama.com/library/qwen3.5',
    provider: 'ollama-cloud'
  },
  {
    tag: 'glm-5.3-flash',
    name: 'GLM-5.3-Flash',
    role: 'Lightweight fast reasoning, coding support & fallback generation',
    modality: 'code',
    minRamGb: 0,
    contextWindow: '128K',
    license: 'GLM Open-Weight License',
    licenseCategory: 'OPEN_WEIGHT_CUSTOM_LICENSE',
    officialLibraryUrl: 'https://ollama.com/library/glm4',
    provider: 'ollama-cloud'
  },
  {
    tag: 'gpt-oss:20b',
    name: 'gpt-oss-20b',
    role: 'Efficient open-weight reasoning, structured outputs & agent workflows',
    modality: 'code',
    minRamGb: 0,
    contextWindow: '128K',
    license: 'Apache-2.0 License + gpt-oss Usage Policy',
    licenseCategory: 'OPEN_WEIGHT_USAGE_POLICY',
    officialLibraryUrl: 'https://ollama.com/library/gpt-oss:20b',
    provider: 'ollama-cloud'
  },
  {
    tag: 'gpt-oss:120b',
    name: 'gpt-oss-120b',
    role: 'High-capacity open-weight reasoning, complex engineering & deep analysis',
    modality: 'code',
    minRamGb: 0,
    contextWindow: '128K',
    license: 'Apache-2.0 License + gpt-oss Usage Policy',
    licenseCategory: 'OPEN_WEIGHT_USAGE_POLICY',
    officialLibraryUrl: 'https://ollama.com/library/gpt-oss:120b',
    provider: 'ollama-cloud'
  },
  {
    tag: 'kimi-k3',
    name: 'Kimi K3',
    role: 'Long-context analysis, research synthesis, agentic coding & multi-step tool use',
    modality: 'code',
    minRamGb: 0,
    contextWindow: '256K',
    license: 'Kimi K3 Open-Weight License',
    licenseCategory: 'OPEN_WEIGHT_CUSTOM_LICENSE',
    officialLibraryUrl: 'https://ollama.com/library/kimi-k2',
    provider: 'ollama-cloud'
  },
  {
    tag: 'gemma4:31b',
    name: 'Gemma 4 31B',
    role: 'Multimodal image understanding, visual debugging, UI inspection & structured reasoning',
    modality: 'multimodal',
    minRamGb: 0,
    contextWindow: '128K',
    license: 'Google Gemma Terms of Use (Open-Weight)',
    licenseCategory: 'OPEN_WEIGHT_USAGE_POLICY',
    officialLibraryUrl: 'https://ollama.com/library/gemma3',
    provider: 'ollama-cloud'
  },
  {
    tag: 'qwen3-embedding:8b',
    name: 'Qwen3-Embedding-8B',
    role: 'Knowledge Vault semantic search, document chunk embeddings & retrieval ranking',
    modality: 'embedding',
    minRamGb: 0,
    contextWindow: '32K',
    license: 'Apache-2.0 License',
    licenseCategory: 'OPEN_SOURCE_PERMISSIVE',
    officialLibraryUrl: 'https://ollama.com/library/qwen3-embedding',
    provider: 'ollama-cloud'
  }
];

export interface OllamaStatus {
  reachable: boolean;
  stage: OllamaConnectionStage;
  endpoint: string;
  models: string[];
  selectedModel: string;
  selectedModelInstalled: boolean;
  latencyMs?: number;
  isHostedOrigin: boolean;
  ollamaCloudConfigured?: boolean;
  message: string;
}

export interface CentralRegistryResponse {
  models: ModelRegistryRecord[];
  taskRoutingTable: TaskRoutingPolicyEntry[];
  ollamaCloudConfigured: boolean;
  geminiConfigured: boolean;
  embeddingMeta: VaultEmbeddingIndexMeta;
  accountUsage: {
    requests: number;
    inputTokens: number;
    outputTokens: number;
    lastRequestAt: number;
  };
  timestamp: number;
}

const OLLAMA_ENDPOINT_KEY = 'lorin_ollama_endpoint_v2';
const OLLAMA_MODEL_KEY = 'lorin_ollama_selected_model_v2';

export class OllamaService {
  private static endpoint = (() => {
    try {
      return (typeof localStorage !== 'undefined' && localStorage.getItem(OLLAMA_ENDPOINT_KEY)) || 'https://ollama.com';
    } catch {
      return 'https://ollama.com';
    }
  })();

  private static selectedModel = (() => {
    try {
      return (typeof localStorage !== 'undefined' && localStorage.getItem(OLLAMA_MODEL_KEY)) || 'deepseek-v4-flash';
    } catch {
      return 'deepseek-v4-flash';
    }
  })();

  private static lastInferenceVerified = false;

  static getEndpoint(): string {
    return this.endpoint;
  }

  static setEndpoint(newEndpoint: string): void {
    const cleaned = (newEndpoint || 'https://ollama.com').trim().replace(/\/+$/, '');
    this.endpoint = cleaned;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(OLLAMA_ENDPOINT_KEY, cleaned);
      }
    } catch {}
  }

  static getSelectedModel(): string {
    return this.selectedModel;
  }

  static setSelectedModel(model: string): void {
    const cleaned = (model || 'deepseek-v4-flash').trim();
    this.selectedModel = cleaned;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(OLLAMA_MODEL_KEY, cleaned);
      }
    } catch {}
  }

  static getRecommendedCandidates(): LocalModelCandidate[] {
    return RECOMMENDED_LOCAL_MODEL_CANDIDATES;
  }

  static isRunningOnHostedOrigin(): boolean {
    if (typeof window === 'undefined') return false;
    const host = window.location.hostname;
    return host !== 'localhost' && host !== '127.0.0.1';
  }

  /**
   * Fetches the authoritative Central Model Registry and Task Routing Policy Table from the backend
   */
  static async fetchCentralModelRegistry(): Promise<CentralRegistryResponse | null> {
    try {
      const url = typeof window !== 'undefined' ? '/api/models/registry' : 'http://localhost:3000/api/models/registry';
      const res = await fetch(url, {
        method: 'GET',
        headers: await getAuthHeaders({ Accept: 'application/json' })
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  }

  /**
   * Synchronizes the connected Ollama Cloud account's model catalogue via GET https://ollama.com/api/tags on the server
   */
  static async syncOllamaCloudCatalogue(): Promise<{
    synced: boolean;
    discoveredTags: string[];
    matchedModelIds: string[];
    message: string;
    models?: ModelRegistryRecord[];
  }> {
    try {
      const url = typeof window !== 'undefined' ? '/api/models/sync-catalogue' : 'http://localhost:3000/api/models/sync-catalogue';
      const res = await fetch(url, {
        method: 'POST',
        headers: await getAuthHeaders({ 'Content-Type': 'application/json' })
      });
      const data = await res.json();
      if (!res.ok) {
        return {
          synced: false,
          discoveredTags: [],
          matchedModelIds: [],
          message: data?.error || `HTTP ${res.status}`
        };
      }
      return data;
    } catch (err: any) {
      return {
        synced: false,
        discoveredTags: [],
        matchedModelIds: [],
        message: err?.message || 'Failed to synchronize Ollama Cloud catalogue.'
      };
    }
  }

  /**
   * Runs a controlled verification test probe on the server before activating a model in the Central Registry
   */
  static async verifyModelInRegistry(modelId: string): Promise<{
    verified: boolean;
    modelId: string;
    resolvedTag: string;
    latencyMs: number;
    message: string;
    record?: ModelRegistryRecord;
  }> {
    try {
      const url = typeof window !== 'undefined' ? '/api/models/verify' : 'http://localhost:3000/api/models/verify';
      const res = await fetch(url, {
        method: 'POST',
        headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ modelId })
      });
      const data = await res.json();
      return data;
    } catch (err: any) {
      return {
        verified: false,
        modelId,
        resolvedTag: modelId,
        latencyMs: 0,
        message: err?.message || 'Verification request failed.'
      };
    }
  }

  /**
   * Updates administrative state (enabledByAdmin, resolvedTag, defaultRoleAssignment) for a model in the Central Registry
   */
  static async updateModelRegistryState(
    modelId: string,
    updates: {
      enabledByAdmin?: boolean;
      defaultRoleAssignment?: string;
      resolvedTag?: string;
    }
  ): Promise<{ model?: ModelRegistryRecord; models?: ModelRegistryRecord[]; error?: string }> {
    try {
      const url =
        typeof window !== 'undefined'
          ? `/api/models/${encodeURIComponent(modelId)}`
          : `http://localhost:3000/api/models/${encodeURIComponent(modelId)}`;
      const res = await fetch(url, {
        method: 'PUT',
        headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(updates)
      });
      return await res.json();
    } catch (err: any) {
      return { error: err?.message || 'Failed to update model registry state.' };
    }
  }

  /**
   * Bulk-activates and enables all 12 models in the Central Registry for live routing
   */
  static async activateAllModelsInRegistry(): Promise<{
    success: boolean;
    activatedCount: number;
    models?: ModelRegistryRecord[];
    message: string;
  }> {
    try {
      const url = typeof window !== 'undefined' ? '/api/models/activate-all' : 'http://localhost:3000/api/models/activate-all';
      const res = await fetch(url, {
        method: 'POST',
        headers: await getAuthHeaders({ 'Content-Type': 'application/json' })
      });
      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          activatedCount: 0,
          message: data?.error || `HTTP ${res.status}`
        };
      }
      return data;
    } catch (err: any) {
      return {
        success: false,
        activatedCount: 0,
        message: err?.message || 'Failed to activate all models.'
      };
    }
  }

  /**
   * Previews the Task-Based Intelligence Router decision for a given prompt and task category
   */
  static async previewTaskRouting(params: {
    prompt: string;
    taskCategory?: TaskRoutingCategory;
    requestedModelId?: string;
    hasImageAttachment?: boolean;
  }): Promise<any> {
    try {
      const url = typeof window !== 'undefined' ? '/api/models/route-preview' : 'http://localhost:3000/api/models/route-preview';
      const res = await fetch(url, {
        method: 'POST',
        headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify(params)
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  }

  /**
   * Probes only a loopback Ollama daemon. This is deliberately separate from
   * checkStatus(), which reports the cloud model registry and must never be
   * used as proof that localhost inference is available.
   */
  static async checkLocalStatus(): Promise<OllamaStatus> {
    const startedAt = performance.now();
    let parsed: URL;
    try {
      parsed = new URL(this.endpoint);
    } catch {
      return { reachable: false, stage: 'ERROR', endpoint: this.endpoint, models: [], selectedModel: this.selectedModel, selectedModelInstalled: false, isHostedOrigin: this.isRunningOnHostedOrigin(), message: 'The configured local Ollama endpoint is invalid.' };
    }
    const loopbackHosts = new Set(['localhost', '127.0.0.1', '[::1]', '::1']);
    if (parsed.protocol !== 'http:' || !loopbackHosts.has(parsed.hostname)) {
      return { reachable: false, stage: 'ERROR', endpoint: this.endpoint, models: [], selectedModel: this.selectedModel, selectedModelInstalled: false, isHostedOrigin: this.isRunningOnHostedOrigin(), message: 'Local Ollama is restricted to an HTTP loopback endpoint (localhost, 127.0.0.1 or ::1).' };
    }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);
    try {
      const response = await fetch(`${parsed.origin}/api/tags`, { headers: { Accept: 'application/json' }, signal: controller.signal });
      if (!response.ok) {
        return { reachable: false, stage: 'ERROR', endpoint: parsed.origin, models: [], selectedModel: this.selectedModel, selectedModelInstalled: false, latencyMs: Math.round(performance.now() - startedAt), isHostedOrigin: this.isRunningOnHostedOrigin(), message: `Local Ollama returned HTTP ${response.status}.` };
      }
      const body = await response.json();
      const models: string[] = Array.isArray(body?.models)
        ? body.models.map((item: any) => String(item?.name || item?.model || '')).filter(Boolean)
        : [];
      const selected = this.selectedModel.toLowerCase();
      const installed = models.some(model => model.toLowerCase() === selected || model.toLowerCase().startsWith(`${selected.split(':')[0]}:`));
      return {
        reachable: true, stage: installed ? 'MODEL_INSTALLED' : 'SERVICE_AVAILABLE_MODEL_MISSING',
        endpoint: parsed.origin, models, selectedModel: this.selectedModel, selectedModelInstalled: installed,
        latencyMs: Math.round(performance.now() - startedAt), isHostedOrigin: this.isRunningOnHostedOrigin(),
        message: installed ? `Local Ollama and selected model are available (${models.length} model(s)).` : `Local Ollama is reachable, but selected model ${this.selectedModel} is not installed.`
      };
    } catch (error: any) {
      return { reachable: false, stage: 'UNREACHABLE_LOCALHOST', endpoint: parsed.origin, models: [], selectedModel: this.selectedModel, selectedModelInstalled: false, latencyMs: Math.round(performance.now() - startedAt), isHostedOrigin: this.isRunningOnHostedOrigin(), message: error?.name === 'AbortError' ? 'Local Ollama health check timed out.' : `Local Ollama is unavailable: ${error?.message || 'connection failed'}` };
    } finally {
      clearTimeout(timeout);
    }
  }

  /**
   * Checks Ollama Cloud status via the server-side registry. This is not a local daemon probe.
   */
  static async checkStatus(): Promise<OllamaStatus> {
    const start = performance.now();
    const isHosted = this.isRunningOnHostedOrigin();

    // First check server-side Central Model Registry for cloud-first Ollama Cloud status
    const registry = await this.fetchCentralModelRegistry();
    if (registry) {
      const latencyMs = Math.round(performance.now() - start);
      const ollamaCloudModels = registry.models
        .filter(m => m.provider === 'ollama-cloud')
        .map(m => m.modelId);
      const selectedInstalled = ollamaCloudModels.includes(this.selectedModel);
      const stage: OllamaConnectionStage = registry.ollamaCloudConfigured
        ? 'INFERENCE_VERIFIED'
        : selectedInstalled
        ? 'MODEL_INSTALLED'
        : 'SERVICE_AVAILABLE_MODEL_MISSING';

      return {
        reachable: registry.ollamaCloudConfigured || registry.geminiConfigured,
        stage,
        endpoint: 'https://ollama.com (Server-Side Proxy)',
        models: ollamaCloudModels,
        selectedModel: this.selectedModel,
        selectedModelInstalled: selectedInstalled,
        latencyMs,
        isHostedOrigin: isHosted,
        ollamaCloudConfigured: registry.ollamaCloudConfigured,
        message: registry.ollamaCloudConfigured
          ? `Ollama Cloud configured on server (${ollamaCloudModels.length} open-weight models registered, latency ${latencyMs}ms). No local GPU required.`
          : `Central Model Registry active (${ollamaCloudModels.length} open-weight models registered). Set OLLAMA_API_KEY in server environment to enable live Ollama Cloud inference.`
      };
    }

    // Optional future local provider check only if endpoint is localhost
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);

      const res = await fetch(`${this.endpoint}/api/tags`, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        return {
          reachable: false,
          stage: 'ERROR',
          endpoint: this.endpoint,
          models: RECOMMENDED_LOCAL_MODEL_CANDIDATES.map(c => c.tag),
          selectedModel: this.selectedModel,
          selectedModelInstalled: false,
          isHostedOrigin: isHosted,
          message: `Ollama Cloud is not yet configured in server environment (OLLAMA_API_KEY). Local Ollama remains an optional future provider.`
        };
      }

      const data = await res.json();
      const models: string[] = Array.isArray(data.models)
        ? data.models.map((m: any) => m.name || m.model).filter(Boolean)
        : [];
      const latencyMs = Math.round(performance.now() - start);
      const exactOrPrefixMatch = models.some(
        m => m.toLowerCase() === this.selectedModel.toLowerCase() || m.toLowerCase().startsWith(this.selectedModel.split(':')[0].toLowerCase())
      );

      return {
        reachable: true,
        stage: this.lastInferenceVerified ? 'INFERENCE_VERIFIED' : exactOrPrefixMatch ? 'MODEL_INSTALLED' : 'SERVICE_AVAILABLE_MODEL_MISSING',
        endpoint: this.endpoint,
        models,
        selectedModel: this.selectedModel,
        selectedModelInstalled: exactOrPrefixMatch,
        latencyMs,
        isHostedOrigin: isHosted,
        message: `Ollama endpoint reachable (${latencyMs}ms).`
      };
    } catch {
      return {
        reachable: false,
        stage: 'UNREACHABLE_LOCALHOST',
        endpoint: 'https://ollama.com',
        models: RECOMMENDED_LOCAL_MODEL_CANDIDATES.map(c => c.tag),
        selectedModel: this.selectedModel,
        selectedModelInstalled: true,
        isHostedOrigin: isHosted,
        message:
          'Cloud-first deployment active: Configure OLLAMA_API_KEY in backend environment to run DeepSeek V4, Qwen 3.5, GLM-5.3-Flash, gpt-oss, Kimi K3, and Gemma 4 31B via Ollama Cloud without local GPU hardware.'
      };
    }
  }

  /**
   * Local Ollama streaming inference. The endpoint is deliberately restricted
   * to loopback so a browser preference cannot send private prompts to an
   * arbitrary network host under the label of a local model.
   */
  static async inferStream(
    prompt: string,
    onChunk: (accumulatedText: string) => void,
    modelOverride?: string,
    signal?: AbortSignal
  ): Promise<{ success: boolean; text?: string; modelUsed?: string; error?: string }> {
    const targetModel = modelOverride || this.selectedModel || 'deepseek-v4-flash';
    let parsed: URL;
    try { parsed = new URL(this.endpoint); }
    catch { return { success: false, modelUsed: targetModel, error: 'LOCAL_OLLAMA_ENDPOINT_INVALID' }; }
    if (parsed.protocol !== 'http:' || !new Set(['localhost', '127.0.0.1', '[::1]', '::1']).has(parsed.hostname)) {
      return { success: false, modelUsed: targetModel, error: 'LOCAL_OLLAMA_LOOPBACK_ONLY' };
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60_000);
    const forwardAbort = () => controller.abort();
    if (signal?.aborted) controller.abort();
    else signal?.addEventListener('abort', forwardAbort, { once: true });
    try {
      const response = await fetch(`${parsed.origin}/api/generate`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: targetModel, prompt, stream: true }),
        signal: controller.signal
      });
      if (!response.ok) {
        let detail = `${response.status} ${response.statusText}`;
        try { const body = await response.json(); if (body?.error) detail = String(body.error).slice(0, 500); } catch {}
        return { success: false, modelUsed: targetModel, error: `LOCAL_OLLAMA_HTTP_${response.status}: ${detail}` };
      }
      if (!response.body) return { success: false, modelUsed: targetModel, error: 'LOCAL_OLLAMA_STREAM_UNAVAILABLE' };
      const streamResult = await consumeOllamaNdjsonStream(response.body, targetModel, onChunk, { signal, maxOutputCharacters: 500_000 });
      if (streamResult.success) this.lastInferenceVerified = true;
      return streamResult;
    } catch (error: any) {
      return { success: false, modelUsed: targetModel, error: error?.name === 'AbortError' ? 'LOCAL_OLLAMA_REQUEST_ABORTED_OR_TIMED_OUT' : 'LOCAL_OLLAMA_CONNECTION_FAILED' };
    } finally {
      clearTimeout(timeoutId);
      signal?.removeEventListener('abort', forwardAbort);
    }
  }

  /**
   * Non-streaming local Ollama inference.
   */
  static async infer(
    prompt: string,
    modelOverride?: string,
    signal?: AbortSignal
  ): Promise<{ success: boolean; text?: string; modelUsed?: string; error?: string }> {
    const targetModel = modelOverride || this.selectedModel || 'deepseek-v4-flash';
    let parsedEndpoint: URL;
    try { parsedEndpoint = new URL(this.endpoint); }
    catch { return { success: false, modelUsed: targetModel, error: 'LOCAL_OLLAMA_ENDPOINT_INVALID' }; }
    if (parsedEndpoint.protocol !== 'http:' || !new Set(['localhost', '127.0.0.1', '[::1]', '::1']).has(parsedEndpoint.hostname)) {
      return { success: false, modelUsed: targetModel, error: 'LOCAL_OLLAMA_LOOPBACK_ONLY' };
    }
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 35000);
      if (signal) {
        signal.addEventListener('abort', () => controller.abort(), { once: true });
      }

      const res = await fetch(`${parsedEndpoint.origin}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: targetModel,
          prompt,
          stream: false
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        let errDetail = `${res.status} ${res.statusText}`;
        try {
          const errJson = await res.json();
          if (errJson?.error) errDetail = errJson.error;
        } catch {}
        return {
          success: false,
          modelUsed: targetModel,
          error: `Ollama HTTP ${errDetail}. Use Ollama Cloud (OLLAMA_API_KEY) for cloud-first inference without local GPU hardware.`
        };
      }

      const data = await res.json();
      this.lastInferenceVerified = true;
      return {
        success: true,
        text: data.response,
        modelUsed: data.model || targetModel
      };
    } catch (e: any) {
      return {
        success: false,
        modelUsed: targetModel,
        error: e.message || 'Local Ollama runtime is not running (optional future provider). Use Ollama Cloud or Gemini Cloud.'
      };
    }
  }
}
