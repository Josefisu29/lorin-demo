/**
 * MOSAIRA Dataset Laboratory & Consent Management Service (v6.0)
 * Handles unbundled user contribution choices and dataset curation pipeline.
 */
import { MosairaConsentRecord } from '../types/mosaira';

const CONSENT_STORAGE_KEY = 'mosaira_user_consent_v1';

export class DatasetLabService {
  private static userConsent: MosairaConsentRecord | null = null;

  static initialize(): MosairaConsentRecord {
    try {
      const stored = localStorage.getItem(CONSENT_STORAGE_KEY);
      if (stored) {
        this.userConsent = JSON.parse(stored);
      } else {
        this.userConsent = {
          id: `consent_${Date.now()}`,
          userId: 'anonymous_user',
          timestamp: Date.now(),
          useForRAGCommons: false,
          useForInternalEval: false,
          useForTrainingCandidate: false,
          allowPublicDisplay: false
        };
        this.persist();
      }
    } catch {
      this.userConsent = {
        id: `consent_${Date.now()}`,
        userId: 'anonymous_user',
        timestamp: Date.now(),
        useForRAGCommons: false,
        useForInternalEval: false,
        useForTrainingCandidate: false,
        allowPublicDisplay: false
      };
    }
    return this.userConsent!;
  }

  private static persist(): void {
    if (this.userConsent) {
      try {
        localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify(this.userConsent));
      } catch {}
    }
  }

  static getConsent(): MosairaConsentRecord {
    if (!this.userConsent) return this.initialize();
    return { ...this.userConsent };
  }

  static updateConsent(updates: Partial<Omit<MosairaConsentRecord, 'id' | 'userId' | 'timestamp'>>): MosairaConsentRecord {
    const current = this.getConsent();
    this.userConsent = {
      ...current,
      ...updates,
      timestamp: Date.now()
    };
    this.persist();
    return { ...this.userConsent };
  }

  static sanitizeSample(text: string): { cleanText: string; secretsFound: number; piiFound: number } {
    let cleanText = text;
    let secretsFound = 0;
    let piiFound = 0;

    // Detect secret keys
    const secretRegex = /(api[_-]?key|secret|token|password|bearer\s+[a-z0-9_-]+)/gi;
    if (secretRegex.test(cleanText)) {
      secretsFound += (cleanText.match(secretRegex) || []).length;
      cleanText = cleanText.replace(secretRegex, '[REDACTED_SECRET]');
    }

    // Detect email PII
    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    if (emailRegex.test(cleanText)) {
      piiFound += (cleanText.match(emailRegex) || []).length;
      cleanText = cleanText.replace(emailRegex, '[REDACTED_EMAIL]');
    }

    return { cleanText, secretsFound, piiFound };
  }
}

DatasetLabService.initialize();
