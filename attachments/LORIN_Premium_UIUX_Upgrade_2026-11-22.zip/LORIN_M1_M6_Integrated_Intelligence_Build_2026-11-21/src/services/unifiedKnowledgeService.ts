import { authFetch } from './authHeaders';

export type UnifiedKnowledgeDomain = 'CONVERSATION' | 'MEMORY' | 'VAULT' | 'PROJECT' | 'GIDEON';
export type KnowledgeVerification = 'VERIFIED' | 'UNVERIFIED' | 'INFERRED';

export interface UnifiedKnowledgeInput {
  domain: UnifiedKnowledgeDomain;
  sourceId: string;
  projectId?: string;
  title: string;
  content: string;
  sourceLabel?: string;
  verificationStatus?: KnowledgeVerification;
  occurredAt?: number;
  metadata?: Record<string, string | number | boolean | null>;
}

export interface UnifiedKnowledgeHit {
  recordId: string;
  domain: UnifiedKnowledgeDomain;
  sourceId: string;
  projectId?: string;
  title: string;
  snippet: string;
  verificationStatus: KnowledgeVerification;
  occurredAt: number;
  updatedAt: number;
  score: number;
  citation: { id: string; title: string; domain: UnifiedKnowledgeDomain; sourceId: string };
}

/**
 * Client adapter for the encrypted local SQLite knowledge index.
 * It is deliberately non-authoritative: the existing Memory/Vault/project stores
 * remain canonical until cloud-backed migration and conflict resolution are verified.
 */
export class UnifiedKnowledgeService {
  static async index(records: UnifiedKnowledgeInput[]): Promise<{ indexed: number; available: boolean }> {
    if (!Array.isArray(records) || records.length === 0) return { indexed: 0, available: true };
    try {
      const response = await authFetch('/api/core/knowledge/index', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ records: records.slice(0, 50) })
      });
      if (!response.ok) return { indexed: 0, available: false };
      const body = await response.json();
      return { indexed: Number(body?.indexed) || 0, available: true };
    } catch {
      return { indexed: 0, available: false };
    }
  }

  static async search(query: string, projectId?: string): Promise<UnifiedKnowledgeHit[]> {
    const cleanQuery = query.trim().slice(0, 500);
    if (!cleanQuery) return [];
    try {
      const params = new URLSearchParams({ q: cleanQuery });
      if (projectId) params.set('projectId', projectId);
      const response = await authFetch(`/api/core/knowledge/search?${params.toString()}`, {
        headers: { Accept: 'application/json' }
      });
      if (!response.ok) return [];
      const body = await response.json();
      return Array.isArray(body?.results) ? body.results : [];
    } catch {
      return [];
    }
  }

  static async delete(recordId: string): Promise<boolean> {
    if (!recordId) return false;
    try {
      const response = await authFetch(`/api/core/knowledge/${encodeURIComponent(recordId)}`, { method: 'DELETE' });
      return response.ok;
    } catch {
      return false;
    }
  }
}
