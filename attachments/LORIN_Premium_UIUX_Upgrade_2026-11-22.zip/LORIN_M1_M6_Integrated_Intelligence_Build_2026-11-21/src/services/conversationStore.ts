import { ChatMessage, ConversationSession } from '../types/lorin';
import { persistChatMessage, persistConversationMeta, deleteConversationRemote } from './firebase';
import { authFetch } from './authHeaders';

const getConversationsStorageKey = (uid: string) => `lorin_conversations_v2_${uid || 'guest'}`;
const getActiveConversationIdKey = (uid: string) => `lorin_active_conv_id_v2_${uid || 'guest'}`;
const getLegacyChatStorageKey = (uid: string) => `lorin_chat_messages_v2_${uid || 'guest'}`;

export class ConversationStore {
  private static activeUserId = 'guest_unauthenticated';
  private static activeSessionId = '';
  private static sessions: ConversationSession[] = [];

  static setActiveUser(uid: string): void {
    this.activeUserId = uid || 'guest_unauthenticated';
    this.activeSessionId = '';
    this.load();
  }

  private static load(): void {
    if (!this.activeUserId || this.activeUserId === 'guest_unauthenticated') {
      this.sessions = [];
      return;
    }

    try {
      if (typeof localStorage !== 'undefined') {
        const raw = localStorage.getItem(getConversationsStorageKey(this.activeUserId));
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed) && parsed.length > 0) {
            this.sessions = parsed;
            return;
          }
        }

      }

      // Migrate legacy single-thread messages if present
      const legacyRaw =
        typeof localStorage !== 'undefined'
          ? localStorage.getItem(getLegacyChatStorageKey(this.activeUserId))
          : null;
      const legacyMsgs: ChatMessage[] = legacyRaw ? JSON.parse(legacyRaw) : [];

      const initialSession: ConversationSession = {
        id: `conv_${Date.now()}_init`,
        userId: this.activeUserId,
        title: legacyMsgs.length > 0
          ? this.deriveTitleFromPrompt(legacyMsgs[0].content)
          : 'Primary Engineering Workspace',
        projectId: legacyMsgs[0]?.projectId || 'proj_lorin_core',
        messages: legacyMsgs,
        draftText: '',
        isArchived: false,
        createdAt: legacyMsgs[0]?.timestamp || Date.now(),
        updatedAt: legacyMsgs[legacyMsgs.length - 1]?.timestamp || Date.now()
      };

      this.sessions = [initialSession];
      this.activeSessionId = initialSession.id;
      this.save();
    } catch {
      this.sessions = [];
    }
  }

  private static save(): void {
    if (!this.activeUserId || this.activeUserId === 'guest_unauthenticated') return;
    if (typeof localStorage === 'undefined') return;
    try {
      // Bound messages per session in localStorage to prevent quota overflow
      const bounded = this.sessions.slice(0, 40).map(s => ({
        ...s,
        messages: s.messages.slice(-60)
      }));
      localStorage.setItem(getConversationsStorageKey(this.activeUserId), JSON.stringify(bounded));
    } catch (e) {
      console.warn('ConversationStore save warning:', e);
    }
  }

  private static async persistSessionToServer(session: ConversationSession): Promise<void> {
    if (!this.activeUserId || this.activeUserId === 'guest_unauthenticated') return;
    if (typeof window === 'undefined') return;
    try {
      await authFetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversation: session })
      });
    } catch {
      // Offline / local fallback remains in localStorage
    }
  }

  private static async deleteSessionOnServer(conversationId: string): Promise<void> {
    if (!this.activeUserId || this.activeUserId === 'guest_unauthenticated') return;
    if (typeof window === 'undefined') return;
    try {
      await authFetch(`/api/conversations/${encodeURIComponent(conversationId)}`, {
        method: 'DELETE'
      });
    } catch {
      // Offline / local fallback
    }
  }

  /**
   * Synchronizes local conversations with the authoritative backend store on startup/refresh.
   */
  static async syncFromBackend(): Promise<ConversationSession[]> {
    if (!this.activeUserId || this.activeUserId === 'guest_unauthenticated') {
      return [];
    }
    try {
      const endpoint = typeof window !== 'undefined' ? '/api/conversations' : 'http://localhost:3000/api/conversations';
      const res = await authFetch(endpoint, { method: 'GET' });
      if (!res.ok) return this.getSessions(true);
      const data = await res.json();
      const remoteSessions: ConversationSession[] = Array.isArray(data?.conversations) ? data.conversations : [];
      if (remoteSessions.length === 0) {
        // Push local non-empty sessions to backend so server stays in sync
        for (const local of this.sessions) {
          if (local.messages && local.messages.length > 0) {
            this.persistSessionToServer(local).catch(() => {});
          }
        }
        return this.getSessions(true);
      }

      const mergedById = new Map<string, ConversationSession>();
      for (const local of this.sessions) {
        mergedById.set(local.id, local);
      }
      for (const remote of remoteSessions) {
        const existing = mergedById.get(remote.id);
        if (
          !existing ||
          (remote.messages?.length || 0) > (existing.messages?.length || 0) ||
          remote.updatedAt > existing.updatedAt
        ) {
          mergedById.set(remote.id, { ...remote, userId: this.activeUserId });
        }
      }

      // Remove empty auto-generated initial session if real sessions exist with messages
      const allMerged = Array.from(mergedById.values());
      const hasRealSessions = allMerged.some(s => s.messages && s.messages.length > 0);
      this.sessions = hasRealSessions
        ? allMerged.filter(s => (s.messages && s.messages.length > 0) || !s.id.endsWith('_init'))
        : allMerged;

      this.sessions.sort((a, b) => b.updatedAt - a.updatedAt);
      this.save();
    } catch {
      // Offline mode: localStorage remains authoritative
    }
    return this.getSessions(true);
  }

  static deriveTitleFromPrompt(prompt: string): string {
    const clean = (prompt || '').replace(/\s+/g, ' ').trim();
    if (!clean) return 'Untitled Engineering Session';
    return clean.length > 46 ? `${clean.slice(0, 46)}...` : clean;
  }

  static getSessions(includeArchived = false, projectIdFilter?: string): ConversationSession[] {
    if (this.sessions.length === 0 && this.activeUserId !== 'guest_unauthenticated') {
      this.load();
    }
    return this.sessions
      .filter(s => (includeArchived ? true : !s.isArchived))
      .filter(s => (projectIdFilter ? s.projectId === projectIdFilter : true))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }

  static getAllSessions(): ConversationSession[] {
    if (this.sessions.length === 0 && this.activeUserId !== 'guest_unauthenticated') {
      this.load();
    }
    return [...this.sessions].sort((a, b) => b.updatedAt - a.updatedAt);
  }

  static getActiveSession(defaultProjectId = 'proj_lorin_core'): ConversationSession {
    if (this.sessions.length === 0 && this.activeUserId !== 'guest_unauthenticated') {
      this.load();
    }

    let storedActiveId: string | null = this.activeSessionId || null;
    try {
      if (!storedActiveId && typeof localStorage !== 'undefined') {
        storedActiveId = localStorage.getItem(getActiveConversationIdKey(this.activeUserId));
      }
    } catch {}

    if (storedActiveId) {
      const found = this.sessions.find(s => s.id === storedActiveId);
      if (found) return found;
    }

    const firstUnarchived = this.sessions.find(s => !s.isArchived);
    if (firstUnarchived) {
      this.setActiveSessionId(firstUnarchived.id);
      return firstUnarchived;
    }

    return this.createSession('Primary Engineering Workspace', defaultProjectId);
  }

  static setActiveSessionId(conversationId: string): ConversationSession | undefined {
    const found = this.sessions.find(s => s.id === conversationId);
    if (found) {
      this.activeSessionId = conversationId;
      if (this.activeUserId !== 'guest_unauthenticated' && typeof localStorage !== 'undefined') {
        try {
          localStorage.setItem(getActiveConversationIdKey(this.activeUserId), conversationId);
        } catch {}
      }
    }
    return found;
  }

  static createSession(title?: string, projectId = 'proj_lorin_core'): ConversationSession {
    const now = Date.now();
    const newSession: ConversationSession = {
      id: `conv_${now}_${Math.random().toString(36).substring(2, 6)}`,
      userId: this.activeUserId,
      title: title?.trim() || 'New Engineering Thread',
      projectId,
      messages: [],
      draftText: '',
      isArchived: false,
      createdAt: now,
      updatedAt: now
    };

    this.sessions.unshift(newSession);
    this.save();
    this.setActiveSessionId(newSession.id);

    if (this.activeUserId !== 'guest_unauthenticated') {
      this.persistSessionToServer(newSession).catch(() => {});
      persistConversationMeta(this.activeUserId, newSession).catch(() => {});
    }

    return newSession;
  }

  static updateMessages(conversationId: string, messages: ChatMessage[]): ConversationSession | undefined {
    const idx = this.sessions.findIndex(s => s.id === conversationId);
    if (idx === -1) return undefined;

    const current = this.sessions[idx];
    const autoTitle =
      (current.title === 'New Engineering Thread' || current.title === 'Primary Engineering Workspace') &&
      messages.length > 0 &&
      messages[0].role === 'user'
        ? this.deriveTitleFromPrompt(messages[0].content)
        : current.title;

    const updated: ConversationSession = {
      ...current,
      title: autoTitle,
      messages,
      updatedAt: Date.now()
    };

    this.sessions[idx] = updated;
    this.save();

    if (this.activeUserId !== 'guest_unauthenticated') {
      this.persistSessionToServer(updated).catch(() => {});
      const latestMsg = messages[messages.length - 1];
      if (latestMsg) {
        persistChatMessage(this.activeUserId, latestMsg, conversationId, updated.title).catch(() => {});
      }
    }

    return updated;
  }

  static saveDraft(conversationId: string, draftText: string): void {
    const idx = this.sessions.findIndex(s => s.id === conversationId);
    if (idx === -1) return;
    if (this.sessions[idx].draftText === draftText) return;
    this.sessions[idx] = {
      ...this.sessions[idx],
      draftText
    };
    this.save();
  }

  static renameSession(conversationId: string, newTitle: string): ConversationSession | undefined {
    const clean = newTitle.trim();
    if (!clean) return undefined;
    const idx = this.sessions.findIndex(s => s.id === conversationId);
    if (idx === -1) return undefined;

    this.sessions[idx] = {
      ...this.sessions[idx],
      title: clean,
      updatedAt: Date.now()
    };
    this.save();
    if (this.activeUserId !== 'guest_unauthenticated') {
      this.persistSessionToServer(this.sessions[idx]).catch(() => {});
      persistConversationMeta(this.activeUserId, this.sessions[idx]).catch(() => {});
    }
    return this.sessions[idx];
  }

  static toggleArchiveSession(conversationId: string): ConversationSession | undefined {
    const idx = this.sessions.findIndex(s => s.id === conversationId);
    if (idx === -1) return undefined;

    this.sessions[idx] = {
      ...this.sessions[idx],
      isArchived: !this.sessions[idx].isArchived,
      updatedAt: Date.now()
    };
    this.save();
    if (this.activeUserId !== 'guest_unauthenticated') {
      this.persistSessionToServer(this.sessions[idx]).catch(() => {});
      persistConversationMeta(this.activeUserId, this.sessions[idx]).catch(() => {});
    }
    return this.sessions[idx];
  }

  static deleteSession(conversationId: string): boolean {
    const before = this.sessions.length;
    this.sessions = this.sessions.filter(s => s.id !== conversationId);
    if (this.sessions.length === before) return false;
    this.save();
    if (this.activeUserId !== 'guest_unauthenticated') {
      this.deleteSessionOnServer(conversationId).catch(() => {});
      deleteConversationRemote(conversationId).catch(() => {});
    }
    return true;
  }

  static searchSessions(query: string): ConversationSession[] {
    const q = (query || '').toLowerCase().trim();
    if (!q) return this.getAllSessions();
    return this.sessions.filter(s => {
      if (s.title.toLowerCase().includes(q)) return true;
      return s.messages.some(m => m.content.toLowerCase().includes(q));
    });
  }
}
