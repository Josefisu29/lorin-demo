import { LorinCharacterState } from './lorinPresence';

/**
 * Section 3: Communication State Machine Model
 * Single centralized communication state model driving text, voice, status indicators, and the 3D Digital Human.
 */
export type CommunicationState =
  | 'idle'
  | 'permission_required'
  | 'requesting_permission'
  | 'initializing'
  | 'listening'
  | 'receiving_audio'
  | 'transcribing'
  | 'transcript_ready'
  | 'submitting'
  | 'connecting'
  | 'waiting_for_response'
  | 'streaming'
  | 'rendering'
  | 'speaking'
  | 'completed'
  | 'interrupted'
  | 'retrying'
  | 'error'
  | 'disconnected';

/**
 * Section 9.2: Human-Readable Communication Status Messages
 */
export const COMMUNICATION_STATE_MESSAGES: Record<CommunicationState, string> = {
  idle: 'Ready',
  permission_required: 'Microphone permission needed',
  requesting_permission: 'Requesting microphone access',
  initializing: 'Preparing audio system',
  listening: 'Listening to you',
  receiving_audio: 'Receiving your voice',
  transcribing: 'Converting speech to text',
  transcript_ready: 'Transcript ready',
  submitting: 'Sending your message',
  connecting: 'Connecting to LORIN',
  waiting_for_response: 'LORIN is thinking',
  streaming: 'LORIN is responding',
  rendering: 'Formatting response',
  speaking: 'LORIN is speaking',
  completed: 'Response complete',
  interrupted: 'Stopped',
  retrying: 'Retrying request',
  error: 'Action needed — see details',
  disconnected: 'Connection unavailable',
};

/**
 * Section 8: Map CommunicationState to 3D Digital Human Character State
 */
export function mapCommunicationToCharacterState(state: CommunicationState): LorinCharacterState {
  switch (state) {
    case 'listening':
    case 'receiving_audio':
      return 'LISTENING';
    case 'transcribing':
    case 'transcript_ready':
    case 'initializing':
    case 'requesting_permission':
      return 'PROCESSING';
    case 'submitting':
    case 'connecting':
    case 'waiting_for_response':
    case 'retrying':
      return 'THINKING';
    case 'streaming':
    case 'rendering':
      return 'RESPONDING';
    case 'speaking':
      return 'SPEAKING';
    case 'error':
    case 'permission_required':
      return 'ERROR';
    case 'disconnected':
      return 'DISCONNECTED';
    case 'idle':
    case 'completed':
    case 'interrupted':
    default:
      return 'IDLE';
  }
}

export type InputCommunicationMode = 'text' | 'voice' | 'dictation' | 'voice_dictation' | 'voice_conversation';

export type ResponseGenerationMode = 'stream' | 'complete';

export type ProviderSelectionMode = 'auto' | 'gemini' | 'ollama';

/**
 * Section 10.1: Request Contract
 */
export interface LorinMessageRequest {
  requestId: string;
  conversationId: string;
  messageId: string;
  inputMode: InputCommunicationMode;
  responseMode: ResponseGenerationMode;
  providerPreference?: ProviderSelectionMode;
  model?: string;
  userMessage: string;
  history?: Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp?: string;
  }>;
  voiceOutputRequested?: boolean;
  metadata?: {
    transcriptConfidence?: number;
    audioDurationMs?: number;
    clientTimestamp: string;
  };
}

/**
 * Section 10.2: Response Contract
 */
export interface LorinMessageResponse {
  requestId: string;
  conversationId: string;
  messageId: string;
  status: 'completed' | 'streaming' | 'failed' | 'cancelled';
  provider: 'gemini' | 'ollama' | 'local';
  model: string;
  content: string;
  createdAt: string;
  completedAt?: string;
  usage?: {
    inputTokens?: number;
    outputTokens?: number;
    totalTokens?: number;
  };
  error?: {
    code: string;
    message: string;
    retryable: boolean;
  };
}

export interface CommunicationStateTransition {
  state: CommunicationState;
  timestamp: number;
  detail?: string;
}

export interface CommunicationTraceRecord {
  requestId: string;
  messageId: string;
  conversationId: string;
  inputMode: InputCommunicationMode;
  provider: string;
  model: string;
  startedAt: number;
  submittedAt?: number;
  backendAckAt?: number;
  firstTokenAt?: number;
  completedAt?: number;
  inputToSubmitMs?: number;
  backendAckMs?: number;
  ttftMs?: number;
  totalDurationMs?: number;
  transcriptionDurationMs?: number;
  audioStartupDelayMs?: number;
  chunkCount: number;
  status: 'in_progress' | 'in_flight' | 'completed' | 'failed' | 'cancelled';
  errorCode?: string;
  errorMessage?: string;
  retryable?: boolean;
  transitions: CommunicationStateTransition[];
}

export type SpeechRecognitionBackendType =
  | 'WEB_SPEECH_API'
  | 'CLOUD_GEMINI_TRANSCRIBE'
  | 'HYBRID_WEB_AND_CLOUD'
  | 'UNAVAILABLE';

export type SpeechSynthesisBackendType =
  | 'GEMINI_NEURAL_TTS'
  | 'BROWSER_SPEECH_SYNTHESIS'
  | 'UNAVAILABLE';

export interface CommunicationDiagnosticsSnapshot {
  state: CommunicationState;
  currentState: CommunicationState;
  statusMessage: string;
  currentStatusMessage: string;
  currentDetail?: string;
  characterState: LorinCharacterState;
  isOnline: boolean;
  activeRequestId: string | null;
  lastError: {
    code: string;
    message: string;
    retryable: boolean;
    remediation: string;
    timestamp: string;
  } | null;
  microphonePermission: 'granted' | 'denied' | 'prompt' | 'unknown';
  microphoneAvailable: boolean;
  speechRecognitionSupport: SpeechRecognitionBackendType;
  speechSynthesisSupport: SpeechSynthesisBackendType;
  activeTtsEngine: SpeechSynthesisBackendType;
  lastTrace: CommunicationTraceRecord | null;
  recentTraces: CommunicationTraceRecord[];
}

export type CommunicationStateSnapshot = CommunicationDiagnosticsSnapshot;

type Listener = (snapshot: CommunicationDiagnosticsSnapshot) => void;

const MODE_KEYWORDS = new Set(['voice', 'text', 'dictation', 'voice_dictation', 'voice_conversation']);

class CommunicationManagerService {
  private currentState: CommunicationState = 'idle';
  private currentDetail: string | undefined = undefined;
  private isOnline: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;
  private activeRequestId: string | null = null;
  private inFlightFingerprints: Map<string, number> = new Map();
  private lastError: CommunicationDiagnosticsSnapshot['lastError'] = null;
  private microphonePermission: CommunicationDiagnosticsSnapshot['microphonePermission'] = 'unknown';
  private microphoneAvailable: boolean = true;
  private speechRecognitionSupport: SpeechRecognitionBackendType = 'HYBRID_WEB_AND_CLOUD';
  private speechSynthesisSupport: SpeechSynthesisBackendType = 'BROWSER_SPEECH_SYNTHESIS';
  private activeTtsEngine: SpeechSynthesisBackendType = 'BROWSER_SPEECH_SYNTHESIS';
  private traces: Map<string, CommunicationTraceRecord> = new Map();
  private traceOrder: string[] = [];
  private transitionHistory: CommunicationStateTransition[] = [];
  private pendingTranscriptionDurationMs: number | undefined = undefined;
  private pendingAudioStartupDelayMs: number | undefined = undefined;
  private listeners: Set<Listener> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        this.isOnline = true;
        if (this.currentState === 'disconnected') {
          this.transition('idle', 'Network connection restored');
        } else {
          this.notify();
        }
      });
      window.addEventListener('offline', () => {
        this.isOnline = false;
        this.transition('disconnected', 'Browser is offline');
      });
      this.detectBrowserCapabilities();
    }
  }

  public detectBrowserCapabilities(): void {
    if (typeof window === 'undefined') return;
    const hasWebSpeech = Boolean(
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown }).SpeechRecognition ||
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown }).webkitSpeechRecognition
    );
    const hasMediaRecorder = typeof MediaRecorder !== 'undefined';

    if (hasWebSpeech && hasMediaRecorder) {
      this.speechRecognitionSupport = 'HYBRID_WEB_AND_CLOUD';
    } else if (hasWebSpeech) {
      this.speechRecognitionSupport = 'WEB_SPEECH_API';
    } else if (hasMediaRecorder) {
      this.speechRecognitionSupport = 'CLOUD_GEMINI_TRANSCRIBE';
    } else {
      this.speechRecognitionSupport = 'UNAVAILABLE';
    }

    const hasSpeechSynth = 'speechSynthesis' in window;
    this.speechSynthesisSupport = hasSpeechSynth ? 'BROWSER_SPEECH_SYNTHESIS' : 'UNAVAILABLE';
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    listener(this.getSnapshot());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    const snap = this.getSnapshot();
    this.listeners.forEach((listener) => {
      try {
        listener(snap);
      } catch (err) {
        console.warn('[CommunicationManager] Listener error:', err);
      }
    });
  }

  public getSnapshot(): CommunicationDiagnosticsSnapshot {
    const recentTraces = this.traceOrder
      .slice(-15)
      .reverse()
      .map((id) => this.traces.get(id)!)
      .filter(Boolean);

    const statusMsg = this.currentDetail || COMMUNICATION_STATE_MESSAGES[this.currentState];

    return {
      state: this.currentState,
      currentState: this.currentState,
      statusMessage: statusMsg,
      currentStatusMessage: COMMUNICATION_STATE_MESSAGES[this.currentState],
      currentDetail: this.currentDetail,
      characterState: mapCommunicationToCharacterState(this.currentState),
      isOnline: this.isOnline,
      activeRequestId: this.activeRequestId,
      lastError: this.lastError,
      microphonePermission: this.microphonePermission,
      microphoneAvailable: this.microphoneAvailable,
      speechRecognitionSupport: this.speechRecognitionSupport,
      speechSynthesisSupport: this.speechSynthesisSupport,
      activeTtsEngine: this.activeTtsEngine,
      lastTrace: recentTraces[0] || null,
      recentTraces,
    };
  }

  public getState(): CommunicationState {
    return this.currentState;
  }

  public getTransitionHistory(): CommunicationStateTransition[] {
    return [...this.transitionHistory];
  }

  public getLastTrace(): CommunicationTraceRecord | null {
    if (this.traceOrder.length === 0) return null;
    const latestId = this.traceOrder[this.traceOrder.length - 1];
    return this.traces.get(latestId) || null;
  }

  /**
   * Transition to a new CommunicationState based on real system events.
   * Supports both transition(state, detail, requestId) and transition(state, mode, detail, errorPayload).
   */
  public transition(
    nextState: CommunicationState,
    detailOrMode?: string,
    thirdArg?: string,
    fourthArg?: { code?: string; message?: string; recoverable?: boolean }
  ): void {
    let resolvedDetail = detailOrMode;
    let resolvedRequestId = thirdArg;

    if (detailOrMode && MODE_KEYWORDS.has(detailOrMode)) {
      resolvedDetail = thirdArg || COMMUNICATION_STATE_MESSAGES[nextState];
      resolvedRequestId = undefined;
    }

    this.currentState = nextState;
    this.currentDetail = resolvedDetail;

    const entry: CommunicationStateTransition = {
      state: nextState,
      timestamp: Date.now(),
      detail: resolvedDetail,
    };
    this.transitionHistory.push(entry);
    if (this.transitionHistory.length > 100) {
      this.transitionHistory.shift();
    }

    const targetReqId = resolvedRequestId || this.activeRequestId;
    if (targetReqId && this.traces.has(targetReqId)) {
      const trace = this.traces.get(targetReqId)!;
      trace.transitions.push(entry);
    }

    if (fourthArg && (nextState === 'error' || nextState === 'permission_required')) {
      const code = fourthArg.code || 'COMMUNICATION_ERROR';
      const msg = fourthArg.message || resolvedDetail || COMMUNICATION_STATE_MESSAGES[nextState];
      this.lastError = {
        code,
        message: msg,
        retryable: Boolean(fourthArg.recoverable ?? true),
        remediation: this.deriveRemediation(code, msg),
        timestamp: new Date().toISOString(),
      };
    } else if (nextState === 'completed') {
      this.lastError = null;
    }

    this.notify();
  }

  /**
   * Section 11.4: Idempotency and Duplicate Prevention
   * Prevents accidental double-submit of identical prompt within a 2000ms window while in-flight.
   */
  public checkAndRegisterSubmission(
    conversationId: string,
    content: string
  ): { allowed: boolean; fingerprint: string; reason?: string } {
    const normalized = `${conversationId}::${(content || '').trim().toLowerCase()}`;
    const now = Date.now();
    const existing = this.inFlightFingerprints.get(normalized);
    if (existing && now - existing < 2000) {
      return {
        allowed: false,
        fingerprint: normalized,
        reason: 'Duplicate submission blocked within active deduplication window.',
      };
    }
    this.inFlightFingerprints.set(normalized, now);
    return { allowed: true, fingerprint: normalized };
  }

  public releaseSubmissionFingerprint(fingerprintOrConversationId: string, optionalContent?: string): void {
    if (typeof optionalContent === 'string') {
      const normalized = `${fingerprintOrConversationId}::${optionalContent.trim().toLowerCase()}`;
      this.inFlightFingerprints.delete(normalized);
    } else {
      this.inFlightFingerprints.delete(fingerprintOrConversationId);
    }
  }

  public createRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  }

  public createMessageId(): string {
    return `msg_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  }

  public startRequestTrace(params: {
    requestId: string;
    messageId: string;
    conversationId: string;
    inputMode?: InputCommunicationMode;
    mode?: InputCommunicationMode;
    provider: string;
    model: string;
    inputCreatedAt?: number;
  }): CommunicationTraceRecord {
    const now = Date.now();
    const resolvedMode: InputCommunicationMode = params.inputMode || params.mode || 'text';
    const record: CommunicationTraceRecord = {
      requestId: params.requestId,
      messageId: params.messageId,
      conversationId: params.conversationId,
      inputMode: resolvedMode,
      provider: params.provider,
      model: params.model,
      startedAt: params.inputCreatedAt || now,
      submittedAt: now,
      inputToSubmitMs: params.inputCreatedAt ? Math.max(0, now - params.inputCreatedAt) : 0,
      transcriptionDurationMs: this.pendingTranscriptionDurationMs,
      audioStartupDelayMs: this.pendingAudioStartupDelayMs,
      chunkCount: 0,
      status: 'in_flight',
      transitions: [
        {
          state: 'submitting',
          timestamp: now,
          detail: `Submitting ${resolvedMode} request to ${params.provider} (${params.model})`,
        },
      ],
    };

    this.pendingTranscriptionDurationMs = undefined;
    this.pendingAudioStartupDelayMs = undefined;

    this.activeRequestId = params.requestId;
    this.traces.set(params.requestId, record);
    this.traceOrder.push(params.requestId);
    if (this.traceOrder.length > 40) {
      const oldest = this.traceOrder.shift();
      if (oldest) this.traces.delete(oldest);
    }

    this.currentState = 'submitting';
    this.currentDetail = `Sending to ${params.model}`;
    this.lastError = null;
    this.notify();
    return record;
  }

  public markSubmitted(requestId?: string): void {
    const targetId = requestId || this.activeRequestId;
    if (!targetId) return;
    const trace = this.traces.get(targetId);
    if (trace) {
      const now = Date.now();
      trace.submittedAt = now;
      trace.inputToSubmitMs = Math.max(0, now - trace.startedAt);
    }
    this.transition('submitting', 'Sending your message', targetId);
  }

  public recordBackendAck(requestId: string, provider?: string, model?: string): void {
    const trace = this.traces.get(requestId);
    if (!trace) return;
    const now = Date.now();
    if (!trace.backendAckAt) {
      trace.backendAckAt = now;
      trace.backendAckMs = Math.max(0, now - (trace.submittedAt || trace.startedAt));
    }
    if (provider) trace.provider = provider;
    if (model) trace.model = model;
    this.transition('waiting_for_response', `Connected to ${trace.model}`, requestId);
  }

  public markBackendAck(requestId: string, provider?: string, model?: string): void {
    this.recordBackendAck(requestId, provider, model);
  }

  public recordFirstToken(requestId: string, explicitTtftMs?: number): void {
    const trace = this.traces.get(requestId);
    if (!trace) return;
    const now = Date.now();
    if (!trace.firstTokenAt) {
      trace.firstTokenAt = now;
      trace.ttftMs =
        typeof explicitTtftMs === 'number'
          ? explicitTtftMs
          : Math.max(0, now - (trace.submittedAt || trace.startedAt));
      this.transition('streaming', `Streaming response (${trace.ttftMs}ms TTFT)`, requestId);
    }
    trace.chunkCount += 1;
  }

  public markFirstToken(requestId: string, explicitTtftMs?: number): void {
    this.recordFirstToken(requestId, explicitTtftMs);
  }

  public recordStreamChunk(requestId: string): void {
    const trace = this.traces.get(requestId);
    if (!trace) return;
    if (!trace.firstTokenAt) {
      this.recordFirstToken(requestId);
      return;
    }
    trace.chunkCount += 1;
  }

  public recordTranscriptionMetric(durationMs: number, requestId?: string): void {
    const id = requestId || this.activeRequestId;
    if (id && this.traces.has(id)) {
      this.traces.get(id)!.transcriptionDurationMs = durationMs;
    } else {
      this.pendingTranscriptionDurationMs = durationMs;
    }
    this.notify();
  }

  public recordTranscriptionLatency(durationMs: number, requestId?: string): void {
    this.recordTranscriptionMetric(durationMs, requestId);
  }

  public recordAudioStartupMetric(
    delayMs: number,
    engine: SpeechSynthesisBackendType = 'BROWSER_SPEECH_SYNTHESIS',
    requestId?: string
  ): void {
    this.activeTtsEngine = engine;
    const id = requestId || this.activeRequestId;
    if (id && this.traces.has(id)) {
      this.traces.get(id)!.audioStartupDelayMs = delayMs;
    } else if (this.traceOrder.length > 0) {
      const latestId = this.traceOrder[this.traceOrder.length - 1];
      if (this.traces.has(latestId)) {
        this.traces.get(latestId)!.audioStartupDelayMs = delayMs;
      }
    } else {
      this.pendingAudioStartupDelayMs = delayMs;
    }
    this.notify();
  }

  public recordAudioStartupDelay(
    delayMs: number,
    engine: SpeechSynthesisBackendType = 'BROWSER_SPEECH_SYNTHESIS',
    requestId?: string
  ): void {
    this.recordAudioStartupMetric(delayMs, engine, requestId);
  }

  public completeRequestTrace(requestId: string, provider?: string, model?: string): void {
    const trace = this.traces.get(requestId);
    const now = Date.now();
    if (trace) {
      trace.completedAt = now;
      trace.totalDurationMs = Math.max(0, now - (trace.submittedAt || trace.startedAt));
      trace.status = 'completed';
      if (provider) trace.provider = provider;
      if (model) trace.model = model;
    }
    if (this.activeRequestId === requestId) {
      this.activeRequestId = null;
    }
    this.transition('completed', 'Response delivered', requestId);
  }

  public markCompleted(requestId: string, model?: string, provider?: string): void {
    this.completeRequestTrace(requestId, provider, model);
  }

  public cancelRequestTrace(requestId?: string, reason: string = 'Stopped by user'): void {
    const targetId = requestId || this.activeRequestId;
    const now = Date.now();
    if (targetId && this.traces.has(targetId)) {
      const trace = this.traces.get(targetId)!;
      trace.completedAt = now;
      trace.totalDurationMs = Math.max(0, now - (trace.submittedAt || trace.startedAt));
      trace.status = 'cancelled';
      trace.errorMessage = reason;
    }
    if (this.activeRequestId === targetId) {
      this.activeRequestId = null;
    }
    this.transition('interrupted', reason, targetId || undefined);
  }

  public failRequestTrace(params: {
    requestId?: string;
    code: string;
    message: string;
    retryable: boolean;
    remediation?: string;
  }): void {
    const targetId = params.requestId || this.activeRequestId;
    const now = Date.now();
    if (targetId && this.traces.has(targetId)) {
      const trace = this.traces.get(targetId)!;
      trace.completedAt = now;
      trace.totalDurationMs = Math.max(0, now - (trace.submittedAt || trace.startedAt));
      trace.status = 'failed';
      trace.errorCode = params.code;
      trace.errorMessage = params.message;
      trace.retryable = params.retryable;
    }
    if (this.activeRequestId === targetId) {
      this.activeRequestId = null;
    }

    this.lastError = {
      code: params.code,
      message: params.message,
      retryable: params.retryable,
      remediation:
        params.remediation ||
        this.deriveRemediation(params.code, params.message),
      timestamp: new Date().toISOString(),
    };

    this.transition('error', params.message, targetId || undefined);
  }

  public setMicrophoneStatus(
    permission: CommunicationDiagnosticsSnapshot['microphonePermission'],
    available: boolean
  ): void {
    this.microphonePermission = permission;
    this.microphoneAvailable = available;
    this.notify();
  }

  public clearError(): void {
    this.lastError = null;
    if (this.currentState === 'error' || this.currentState === 'permission_required') {
      this.transition('idle', 'Ready');
    } else {
      this.notify();
    }
  }

  public resetToIdle(): void {
    this.activeRequestId = null;
    this.inFlightFingerprints.clear();
    this.lastError = null;
    this.transition('idle', 'Ready');
  }

  public reset(_mode?: string): void {
    this.transitionHistory = [];
    this.resetToIdle();
  }

  private deriveRemediation(code: string, message: string): string {
    const upper = `${code} ${message}`.toUpperCase();
    if (upper.includes('401') || upper.includes('AUTH') || upper.includes('SESSION')) {
      return 'Your session token may have expired. Re-authenticate or refresh your session.';
    }
    if (upper.includes('429') || upper.includes('RATE_LIMIT') || upper.includes('QUOTA')) {
      return 'Provider rate limit reached. Wait a moment and click Retry, or switch models in the header.';
    }
    if (upper.includes('GEMINI_UNCONFIGURED') || upper.includes('API_KEY')) {
      return 'Configure GEMINI_API_KEY in server environment variables or switch to a configured model.';
    }
    if (upper.includes('OLLAMA_UNCONFIGURED') || upper.includes('OLLAMA')) {
      return 'Ollama Cloud API key is not configured. Switch to Gemini 3.8 Flash or configure OLLAMA_API_KEY.';
    }
    if (upper.includes('PERMISSION') || upper.includes('NOT-ALLOWED') || upper.includes('MICROPHONE')) {
      return 'Allow microphone access in your browser address bar settings, then click Retry Mic.';
    }
    if (upper.includes('NO-SPEECH') || upper.includes('EMPTY')) {
      return 'No speech was detected. Speak clearly into your microphone or use the Cloud Audio Clip recorder.';
    }
    return 'Click Retry to resend your request or inspect the Communication Diagnostics panel.';
  }
}

export const CommunicationManager = new CommunicationManagerService();
