/**
 * LORIN V2 — Multi-Project Engineering & Strategy Store
 * Maintains strict project isolation across LORIN Private System, MOSAIRA Public Platform,
 * and independent software projects (e.g., NexaSpace Connect, SeppinaLuxe).
 */

import { ProjectRecord, ProjectTask, ProjectDecision } from '../types/lorin';
import { authFetch } from './authHeaders';
import { GideonService } from './gideonService';

const PROJECTS_STORAGE_PREFIX = 'lorin_projects_v2';
const ACTIVE_PROJECT_KEY_PREFIX = 'lorin_active_project_v2';

function areProjectIdsEquivalent(a?: string, b?: string): boolean {
  if (!a || !b) return false;
  if (a === b) return true;
  if (
    (a === 'proj_lorin_v2' || a === 'proj_lorin_core') &&
    (b === 'proj_lorin_v2' || b === 'proj_lorin_core')
  ) {
    return true;
  }
  return false;
}

const LEGACY_PROJECT_SEEDS: Record<string, {
  repositoryOrPath: string;
  taskIds: string[];
  decisionIds: string[];
  techStack: string[];
}> = {
  proj_lorin_v2: {
    repositoryOrPath: '/workspace/lorin-core',
    taskIds: ['tsk_lorin_1', 'tsk_lorin_2', 'tsk_lorin_3'],
    decisionIds: ['dec_lorin_1', 'dec_lorin_2'],
    techStack: ['TypeScript', 'React 19', 'Express', 'Firebase Auth & Firestore', 'Web Crypto AES-GCM', 'Web Audio DSP']
  },
  proj_mosaira_pub: {
    repositoryOrPath: '/workspace/mosaira-platform',
    taskIds: ['tsk_msra_1', 'tsk_msra_2'],
    decisionIds: ['dec_msra_1'],
    techStack: ['TypeScript', 'React', '@google/genai', 'Express REST API', 'Rate-Limited API Keys']
  },
  proj_nexaspace: {
    repositoryOrPath: '/projects/nexaspace-connect',
    taskIds: ['tsk_nexa_1'],
    decisionIds: ['dec_nexa_1'],
    techStack: ['Next.js', 'PostgreSQL', 'WebRTC', 'Tailwind CSS']
  },
  proj_seppinaluxe: {
    repositoryOrPath: '/projects/seppinaluxe',
    taskIds: ['tsk_sepp_1'],
    decisionIds: ['dec_sepp_1'],
    techStack: ['TypeScript', 'React', 'Stripe API', 'Headless Commerce']
  }
};

function normalizeStoredProjects(value: unknown): ProjectRecord[] {
  if (!Array.isArray(value)) return [];

  return value
    .filter((project): project is ProjectRecord =>
      !!project &&
      typeof project === 'object' &&
      typeof (project as ProjectRecord).id === 'string'
    )
    .map(project => {
      const seed = LEGACY_PROJECT_SEEDS[project.id];
      if (!seed) return project;

      const hasLegacyMarkers =
        project.repositoryOrPath === seed.repositoryOrPath ||
        (project.tasks || []).some(task => seed.taskIds.includes(task.id)) ||
        (project.decisions || []).some(decision => seed.decisionIds.includes(decision.id));

      if (!hasLegacyMarkers) return project;

      const isSeedStack =
        JSON.stringify(project.techStack || []) === JSON.stringify(seed.techStack);

      const cleanTasks = (project.tasks || []).filter(task => !seed.taskIds.includes(task.id));
      const cleanDecisions = (project.decisions || []).filter(decision => !seed.decisionIds.includes(decision.id));
      const requirements = Array.isArray(project.requirements) ? [...project.requirements] : [];
      const migrationNotice = 'Legacy sample metadata detected. Confirm this project status, technology stack, repository path and previous completion claims before relying on them.';
      if (!requirements.includes(migrationNotice)) requirements.push(migrationNotice);

      return {
        ...project,
        description: project.description.includes('Legacy sample metadata detected.')
          ? project.description
          : `${project.description} Legacy sample metadata detected; confirm its current state before relying on it.`,
        techStack: isSeedStack ? [] : (project.techStack || []),
        repositoryOrPath: project.repositoryOrPath === seed.repositoryOrPath
          ? 'Not verified — add the actual repository or path'
          : project.repositoryOrPath,
        status: project.status === 'ACTIVE' ? 'PLANNING' : project.status,
        requirements,
        tasks: cleanTasks,
        decisions: cleanDecisions,
        updatedAt: Date.now()
      };
    });
}

export class ProjectStore {
  private static activeUserId = 'guest_unauthenticated';

  static setActiveUser(userId: string | undefined): void {
    const clean = userId && userId.trim() ? userId.trim() : 'guest_unauthenticated';
    this.activeUserId = clean;
  }

  private static getStorageKey(): string {
    return `${PROJECTS_STORAGE_PREFIX}_${this.activeUserId}`;
  }

  private static getActiveProjectKey(): string {
    return `${ACTIVE_PROJECT_KEY_PREFIX}_${this.activeUserId}`;
  }

  static getProjects(): ProjectRecord[] {
    try {
      const raw = localStorage.getItem(this.getStorageKey());
      if (!raw) return [];
      const parsed: unknown = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];

      const normalized = normalizeStoredProjects(parsed);
      if (JSON.stringify(normalized) !== JSON.stringify(parsed)) {
        localStorage.setItem(this.getStorageKey(), JSON.stringify(normalized));
      }
      return normalized;
    } catch {
      // Missing or unreadable project storage must not create fabricated projects.
      return [];
    }
  }

  static saveProjects(projects: ProjectRecord[], syncServer = true): void {
    const normalized = normalizeStoredProjects(projects);
    try {
      localStorage.setItem(this.getStorageKey(), JSON.stringify(normalized));
    } catch {}
    if (syncServer) {
      this.persistToServer(normalized);
    }
  }

  private static persistToServer(projects: ProjectRecord[]): void {
    if (typeof window === 'undefined') return;
    authFetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projects })
    }).catch(() => {});
  }

  static async syncFromBackend(): Promise<ProjectRecord[]> {
    if (typeof window === 'undefined') return this.getProjects();
    try {
      const res = await authFetch('/api/projects', {
        headers: { Accept: 'application/json' }
      });
      if (!res.ok) return this.getProjects();
      const data = await res.json();
      if (Array.isArray(data?.projects)) {
        const normalized = normalizeStoredProjects(data.projects);
        this.saveProjects(normalized, false);
        if (normalized.length !== data.projects.length) this.persistToServer(normalized);
        return normalized;
      }

      return this.getProjects();
    } catch {
      return this.getProjects();
    }
  }

  static getActiveProjectId(): string {
    const projects = this.getProjects();
    try {
      const stored = localStorage.getItem(this.getActiveProjectKey());
      if (stored && projects.some(project => project.id === stored)) return stored;
    } catch {}
    return projects[0]?.id || '';
  }

  static setActiveProjectId(projectId: string | null): void {
    try {
      if (!projectId || !this.getProjects().some(project => project.id === projectId)) {
        localStorage.removeItem(this.getActiveProjectKey());
      } else {
        localStorage.setItem(this.getActiveProjectKey(), projectId);
      }
    } catch {}
  }

  static getProject(projectId: string): ProjectRecord | undefined {
    return this.getProjects().find(p => areProjectIdsEquivalent(p.id, projectId));
  }

  static getActiveProject(): ProjectRecord | undefined {
    const id = this.getActiveProjectId();
    return this.getProject(id);
  }

  static createProject(partial: {
    name: string;
    classification: ProjectRecord['classification'];
    description: string;
    techStack: string[];
    repositoryOrPath?: string;
  }): ProjectRecord {
    const projects = this.getProjects();
    const slug = partial.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const newProj: ProjectRecord = {
      id: `proj_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      name: partial.name.trim(),
      slug,
      classification: partial.classification,
      description: partial.description.trim(),
      techStack: partial.techStack,
      repositoryOrPath: partial.repositoryOrPath || 'Not configured',
      status: 'ACTIVE',
      requirements: [],
      tasks: [],
      decisions: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    const updated = [newProj, ...projects];
    this.saveProjects(updated);
    return newProj;
  }

  static deleteProject(projectId: string): void {
    const filtered = this.getProjects().filter(p => p.id !== projectId);
    this.saveProjects(filtered);
    if (this.getActiveProjectId() === projectId) {
      this.setActiveProjectId(filtered[0]?.id || null);
    }
    if (typeof window !== 'undefined') {
      authFetch(`/api/projects/${encodeURIComponent(projectId)}`, { method: 'DELETE' }).catch(() => {});
    }
  }

  static addRequirement(projectId: string, requirement: string): ProjectRecord | undefined {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => areProjectIdsEquivalent(p.id, projectId));
    if (idx === -1) return undefined;
    projects[idx].requirements.push(requirement.trim());
    projects[idx].updatedAt = Date.now();
    this.saveProjects(projects);
    return projects[idx];
  }

  static addTask(projectId: string, task: Omit<ProjectTask, 'id' | 'createdAt'>): ProjectRecord | undefined {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => areProjectIdsEquivalent(p.id, projectId));
    if (idx === -1) return undefined;

    const newTask: ProjectTask = {
      id: `tsk_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      createdAt: Date.now(),
      ...task
    };
    projects[idx].tasks.unshift(newTask);
    projects[idx].updatedAt = Date.now();
    this.saveProjects(projects);
    return projects[idx];
  }

  static toggleTaskStatus(projectId: string, taskId: string): ProjectRecord | undefined {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => areProjectIdsEquivalent(p.id, projectId));
    if (idx === -1) return undefined;

    projects[idx].tasks = projects[idx].tasks.map(t => {
      if (t.id !== taskId) return t;
      const nextStatus: ProjectTask['status'] =
        t.status === 'TODO' ? 'IN_PROGRESS' : t.status === 'IN_PROGRESS' ? 'DONE' : 'TODO';
      return { ...t, status: nextStatus };
    });
    projects[idx].updatedAt = Date.now();
    this.saveProjects(projects);
    return projects[idx];
  }

  static addDecision(projectId: string, decision: Omit<ProjectDecision, 'id' | 'createdAt'>): ProjectRecord | undefined {
    const projects = this.getProjects();
    const idx = projects.findIndex(p => areProjectIdsEquivalent(p.id, projectId));
    if (idx === -1) return undefined;

    const newDec: ProjectDecision = {
      id: `dec_${Date.now()}`,
      createdAt: Date.now(),
      ...decision
    };
    projects[idx].decisions.unshift(newDec);
    projects[idx].updatedAt = Date.now();
    this.saveProjects(projects);

    // Emit live architectural decision into GIDEON timeline
    GideonService.recordDecision({
      projectId: projects[idx].id,
      title: newDec.title,
      decisionDescription: newDec.rationale,
      alternativesConsidered: [],
      reasoning: newDec.rationale,
      supportingEvidence: [`Recorded in Project ${projects[idx].name}`],
      decisionOwner: 'System Owner',
      status: newDec.status === 'ACCEPTED' ? 'APPROVED' : 'PROPOSED'
    }).catch(() => {});

    return projects[idx];
  }

  /**
   * Computes a 7-day series from recorded project tasks and decision records.
   * Chat volume is not counted as completed engineering work; no synthetic history is added.
   */
  static getDailyActivitySeries(
    projectId: string,
    _chatMessagesCountForToday: number = 0,
    _auditEventsCountForToday: number = 0
  ): {
    dateKey: string;
    dayLabel: string;
    tasksAndCommits: number;
    auditsAndReviews: number;
    totalEvents: number;
  }[] {
    const project = this.getProject(projectId);
    const now = new Date();
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const series: {
      dateKey: string;
      dayLabel: string;
      tasksAndCommits: number;
      auditsAndReviews: number;
      totalEvents: number;
    }[] = [];

    for (let offset = 6; offset >= 0; offset--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - offset);
      const dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      const dayLabel = offset === 0 ? 'Today' : dayNames[d.getDay()];
      const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
      const dayEnd = dayStart + 86400000;

      const tasksOnDay = (project?.tasks || []).filter(
        task => task.createdAt >= dayStart && task.createdAt < dayEnd
      ).length;
      const decisionsOnDay = (project?.decisions || []).filter(
        decision => decision.createdAt >= dayStart && decision.createdAt < dayEnd
      ).length;

      series.push({
        dateKey,
        dayLabel,
        tasksAndCommits: tasksOnDay,
        auditsAndReviews: decisionsOnDay,
        totalEvents: tasksOnDay + decisionsOnDay
      });
    }

    return series;
  }
}

