/**
 * MOSAIRA Model Registry & Persona Management Service (v6.0)
 * Manages 10 human-named public AI personas and model endpoint verification.
 */
import { MosairaModel, MosairaPersona, ModelHealthState } from '../types/mosaira';

export const PUBLIC_PERSONAS: MosairaPersona[] = [
  {
    id: 'NOVA',
    humanName: 'Maya',
    title: 'Creative Intelligence & Conceptual Design',
    voiceStyle: 'Creative, warm, imaginative, energetic',
    purpose: 'Brainstorming, storytelling, creative writing, campaign concepts, and design ideation',
    description: 'Maya specializes in generative ideation, expansive narrative synthesis, and creative problem solving across art and strategy.',
    underlyingModelId: 'gemini-3.8-flash',
    systemInstruction: 'You are Maya (NOVA), a creative AI persona on the MOSAIRA ecosystem. Respond with imaginative depth, warm engagement, and highly articulated conceptual clarity.',
    supportedTasks: ['Creative Writing', 'Brainstorming', 'Marketing Concepts', 'Storytelling'],
    avatarBg: 'from-amber-500/20 to-pink-500/20',
    accentColor: '#E9B76B'
  },
  {
    id: 'SAGE',
    humanName: 'Adrian',
    title: 'Structured Reasoning & Strategic Analysis',
    voiceStyle: 'Calm, analytical, balanced, clear, deliberate',
    purpose: 'Reasoning, decision analysis, trade-off evaluation, and structured explanations',
    description: 'Adrian breaks complex strategic and technical problems into disciplined multi-perspective frameworks.',
    underlyingModelId: 'gemini-3.8-flash',
    systemInstruction: 'You are Adrian (SAGE), a strategic reasoning AI persona on MOSAIRA. Structure your thoughts clearly with objective trade-offs and logical rigor.',
    supportedTasks: ['Strategic Analysis', 'Decision Trees', 'Trade-off Evaluation', 'Explanations'],
    avatarBg: 'from-indigo-500/20 to-blue-500/20',
    accentColor: '#8D83F6'
  },
  {
    id: 'ATLAS',
    humanName: 'Ethan',
    title: 'Software Architecture & Full-Stack Engineering',
    voiceStyle: 'Technical, methodical, practical, precise',
    purpose: 'Coding, debugging, architecture, API design, and technical problem solving',
    description: 'Ethan is an experienced full-stack engineering persona built for deep code synthesis, refactoring, and system design.',
    underlyingModelId: 'gemini-3.8-flash',
    systemInstruction: 'You are Ethan (ATLAS), a principal engineering persona on MOSAIRA. Provide production-grade, cleanly structured TypeScript/React code and architecture.',
    supportedTasks: ['Full-Stack Coding', 'Code Review', 'System Architecture', 'Debugging'],
    avatarBg: 'from-cyan-500/20 to-teal-500/20',
    accentColor: '#62D9CF'
  },
  {
    id: 'ORBIT',
    humanName: 'Nora',
    title: 'Evidence Verification & Deep Investigation',
    voiceStyle: 'Curious, evidence-led, cautious about unsupported claims',
    purpose: 'Research, source evaluation, document analysis, and factual citations',
    description: 'Nora rigorously evaluates claims, inspects source citations, and separates verified evidence from inference.',
    underlyingModelId: 'gemini-3.8-flash',
    systemInstruction: 'You are Nora (ORBIT), an evidence investigator persona on MOSAIRA. Emphasize verified sources, explicit citations, and honest uncertainty.',
    supportedTasks: ['Document Analysis', 'Fact Checking', 'Source Verification', 'Research Synthesis'],
    avatarBg: 'from-emerald-500/20 to-teal-500/20',
    accentColor: '#10B981'
  },
  {
    id: 'PIXEL',
    humanName: 'Leo',
    title: 'Visual Cognition & Spatial Design',
    voiceStyle: 'Visual, observant, design-minded, spatially aware',
    purpose: 'Image analysis, diagram critique, UI layout evaluation, and multimodal vision',
    description: 'Leo analyzes visual compositions, UI screenshots, spatial layouts, and visual asset quality.',
    underlyingModelId: 'gemini-3.1-flash-lite-image',
    systemInstruction: 'You are Leo (PIXEL), a visual cognition persona on MOSAIRA. Analyze imagery, spatial geometry, and UI typography with design precision.',
    supportedTasks: ['Image Analysis', 'UI/UX Critique', 'Diagram Understanding', 'Visual Inspection'],
    avatarBg: 'from-purple-500/20 to-pink-500/20',
    accentColor: '#A855F7'
  },
  {
    id: 'ECHO',
    humanName: 'Clara',
    title: 'Conversational Voice & Daily Assistant',
    voiceStyle: 'Natural, friendly, empathetic, accessible',
    purpose: 'Everyday conversation, guidance, accessibility, and voice interaction',
    description: 'Clara provides natural conversational dialogue optimized for tap-to-talk voice interactions and clear guidance.',
    underlyingModelId: 'gemini-3.8-flash',
    systemInstruction: 'You are Clara (ECHO), a conversational assistant persona on MOSAIRA. Speak naturally, concisely, and warmly.',
    supportedTasks: ['Voice Dialogue', 'Everyday Q&A', 'Accessibility Guidance', 'Quick Tasks'],
    avatarBg: 'from-rose-500/20 to-orange-500/20',
    accentColor: '#F43F5E'
  },
  {
    id: 'LINGO',
    humanName: 'Sofia',
    title: 'Multilingual Cognition & Cultural Localization',
    voiceStyle: 'Articulate, patient, multilingual, culturally aware',
    purpose: 'Translation, language learning, localization, and prose refinement',
    description: 'Sofia handles nuanced multi-language translation, dialect adaptation, and cultural idiom preservation.',
    underlyingModelId: 'gemini-3.8-flash',
    systemInstruction: 'You are Sofia (LINGO), a multilingual AI persona on MOSAIRA. Provide precise translation, grammatical insight, and cultural context.',
    supportedTasks: ['Translation', 'Prose Refinement', 'Localization', 'Language Learning'],
    avatarBg: 'from-violet-500/20 to-fuchsia-500/20',
    accentColor: '#D946EF'
  },
  {
    id: 'PULSE',
    humanName: 'Theo',
    title: 'High-Velocity Extraction & Rapid Summaries',
    voiceStyle: 'Fast, focused, direct, concise',
    purpose: 'Quick answers, key point extraction, classification, and short transformations',
    description: 'Theo is built for low-latency, ultra-concise summaries and high-speed information extraction.',
    underlyingModelId: 'gemini-3.1-flash-lite',
    systemInstruction: 'You are Theo (PULSE), a high-speed summary persona on MOSAIRA. Give direct, bulleted, zero-filler answers immediately.',
    supportedTasks: ['Rapid Summaries', 'Key Point Extraction', 'Text Classification', 'Quick Reframing'],
    avatarBg: 'from-amber-500/20 to-yellow-500/20',
    accentColor: '#F59E0B'
  },
  {
    id: 'FORGE',
    humanName: 'Marcus',
    title: 'Quantitative Data Analysis & Structured SQL',
    voiceStyle: 'Quantitative, systematic, structured, precise',
    purpose: 'Data analysis, math calculations, spreadsheet synthesis, and SQL query creation',
    description: 'Marcus delivers quantitative calculations, statistical insights, data schema transformation, and structured outputs.',
    underlyingModelId: 'gemini-3.8-flash',
    systemInstruction: 'You are Marcus (FORGE), a quantitative data persona on MOSAIRA. Provide exact calculations, tabular matrices, and clean SQL.',
    supportedTasks: ['SQL Generation', 'Data Analytics', 'Calculations', 'Spreadsheet Synthesis'],
    avatarBg: 'from-blue-500/20 to-cyan-500/20',
    accentColor: '#3B82F6'
  },
  {
    id: 'SENTINEL',
    humanName: 'Elena',
    title: 'Security Governance & Risk Discipline',
    voiceStyle: 'Careful, skeptical, fair, disciplined, risk-aware',
    purpose: 'Security code audit, vulnerability review, permission inspection, and safety checks',
    description: 'Elena evaluates threat boundaries, policy engine rules, secret exposure risks, and code security hygiene.',
    underlyingModelId: 'gemini-3.8-flash',
    systemInstruction: 'You are Elena (SENTINEL), a security auditor persona on MOSAIRA. Examine code and policy for vulnerabilities, data leaks, and authorization flaws.',
    supportedTasks: ['Security Audit', 'Vulnerability Review', 'ABAC Inspection', 'Risk Assessment'],
    avatarBg: 'from-red-500/20 to-slate-500/20',
    accentColor: '#EF4444'
  }
];

export const INITIAL_MODELS: MosairaModel[] = [
  {
    modelId: 'gemini-3.8-flash',
    displayName: 'MOSAIRA Primary Reasoning Engine',
    personaId: 'SAGE',
    publisher: 'Managed Cloud Intelligence',
    providerModelId: 'primary-reasoning-tier',
    openness: 'HOSTED_API',
    licenseName: 'Managed Cloud Terms of Service',
    officialCardUrl: 'https://ai.google.dev/',
    modalities: ['text', 'image', 'code'],
    contextLimit: 1048576,
    outputLimit: 8192,
    toolCalling: true,
    fineTuningSupport: true,
    commercialUseAllowed: true,
    healthStatus: 'ACTIVE',
    healthCheckedAt: Date.now(),
    latencyMs: 180,
    costPer1kInputTokens: 0.00015,
    costPer1kOutputTokens: 0.00060,
    enabled: true
  },
  {
    modelId: 'gemini-3.1-flash-lite',
    displayName: 'MOSAIRA High-Velocity Engine',
    personaId: 'PULSE',
    publisher: 'Managed Cloud Intelligence',
    providerModelId: 'fast-velocity-tier',
    openness: 'HOSTED_API',
    licenseName: 'Managed Cloud Terms of Service',
    officialCardUrl: 'https://ai.google.dev/',
    modalities: ['text', 'code'],
    contextLimit: 524288,
    outputLimit: 4096,
    toolCalling: true,
    fineTuningSupport: false,
    commercialUseAllowed: true,
    healthStatus: 'ACTIVE',
    healthCheckedAt: Date.now(),
    latencyMs: 95,
    costPer1kInputTokens: 0.000075,
    costPer1kOutputTokens: 0.00030,
    enabled: true
  },
  {
    modelId: 'gemini-3.1-flash-lite-image',
    displayName: 'MOSAIRA Multimodal Vision Engine',
    personaId: 'PIXEL',
    publisher: 'Managed Cloud Intelligence',
    providerModelId: 'multimodal-vision-tier',
    openness: 'HOSTED_API',
    licenseName: 'Managed Cloud Terms of Service',
    officialCardUrl: 'https://ai.google.dev/',
    modalities: ['text', 'image'],
    contextLimit: 131072,
    outputLimit: 2048,
    toolCalling: false,
    fineTuningSupport: false,
    commercialUseAllowed: true,
    healthStatus: 'ACTIVE',
    healthCheckedAt: Date.now(),
    latencyMs: 240,
    costPer1kInputTokens: 0.00020,
    costPer1kOutputTokens: 0.00080,
    enabled: true
  },
  {
    modelId: 'ollama-llama3-8b',
    displayName: 'Llama 3 8B Instruct (Meta Open Weight)',
    personaId: 'ATLAS',
    publisher: 'Meta AI / Local Ollama',
    providerModelId: 'llama3:latest',
    openness: 'OPEN_WEIGHT',
    licenseName: 'Meta Llama 3 Community License',
    officialCardUrl: 'https://llama.meta.com/llama3/',
    modalities: ['text', 'code'],
    contextLimit: 8192,
    outputLimit: 2048,
    toolCalling: true,
    fineTuningSupport: true,
    commercialUseAllowed: true,
    healthStatus: 'ACTIVE',
    healthCheckedAt: Date.now(),
    latencyMs: 320,
    costPer1kInputTokens: 0.00,
    costPer1kOutputTokens: 0.00,
    enabled: true
  },
  {
    modelId: 'huggingface-mistral-7b',
    displayName: 'Mistral 7B Instruct v0.3 (Mistral AI)',
    personaId: 'NOVA',
    publisher: 'Mistral AI / Hugging Face',
    providerModelId: 'mistralai/Mistral-7B-Instruct-v0.3',
    openness: 'OPEN_SOURCE',
    licenseName: 'Apache 2.0',
    officialCardUrl: 'https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3',
    modalities: ['text', 'code'],
    contextLimit: 32768,
    outputLimit: 4096,
    toolCalling: true,
    fineTuningSupport: true,
    commercialUseAllowed: true,
    healthStatus: 'ACTIVE',
    healthCheckedAt: Date.now(),
    latencyMs: 210,
    costPer1kInputTokens: 0.00010,
    costPer1kOutputTokens: 0.00040,
    enabled: true
  }
];

export class ModelRegistryService {
  private static personasMap = new Map<string, MosairaPersona>();
  private static modelsMap = new Map<string, MosairaModel>();

  static initialize(): void {
    PUBLIC_PERSONAS.forEach(p => this.personasMap.set(p.id, p));
    INITIAL_MODELS.forEach(m => this.modelsMap.set(m.modelId, m));
  }

  static getPersonas(): MosairaPersona[] {
    if (this.personasMap.size === 0) this.initialize();
    return Array.from(this.personasMap.values());
  }

  static getPersona(id: string): MosairaPersona | undefined {
    if (this.personasMap.size === 0) this.initialize();
    return this.personasMap.get(id);
  }

  static getModels(): MosairaModel[] {
    if (this.modelsMap.size === 0) this.initialize();
    return Array.from(this.modelsMap.values());
  }

  static getModel(modelId: string): MosairaModel | undefined {
    if (this.modelsMap.size === 0) this.initialize();
    return this.modelsMap.get(modelId);
  }

  static async verifyModelHealth(modelId: string): Promise<ModelHealthState> {
    const model = this.getModel(modelId);
    if (!model) return 'OFFLINE';

    try {
      if (model.modelId.startsWith('gemini')) {
        const res = await fetch('/api/health');
        if (res.ok) {
          model.healthStatus = 'ACTIVE';
          model.healthCheckedAt = Date.now();
          return 'ACTIVE';
        }
      } else if (model.modelId.startsWith('ollama')) {
        const res = await fetch('http://localhost:11434/api/tags').catch(() => null);
        if (res && res.ok) {
          model.healthStatus = 'ACTIVE';
          model.healthCheckedAt = Date.now();
          return 'ACTIVE';
        } else {
          model.healthStatus = 'DEGRADED';
          return 'DEGRADED';
        }
      }
    } catch {
      model.healthStatus = 'DEGRADED';
    }
    return model.healthStatus;
  }
}

ModelRegistryService.initialize();
