/**
 * LORIN Hybrid Primary Node, Private Network, Multi-Device Synchronization & Controlled Command Client Service
 * Implements Sections 2–15 of the LORIN Master Build Specification.
 */
import {
  ApprovedNodeCommandResult,
  ApprovedNodeCommandSpec,
  ChatMessage,
  ConversationSession,
  DeviceCapabilityScope,
  DeviceConnectionState,
  DevicePairingChallenge,
  EnrolledDeviceRecord,
  EnrolledDeviceType,
  HybridAvailabilityMode,
  PrimaryNodeTelemetry,
  PrivateNetworkProviderType,
  PrivateNetworkStatus,
  SyncEngineStatusSummary,
  SyncOutboxItem
} from '../types/lorin';
import {
  getAuthHeaders,
  getEnrolledClientDeviceId,
  setEnrolledClientDeviceId
} from './authHeaders';
import {
  persistConversationMeta,
  persistEnrolledDeviceRemote,
  removeEnrolledDeviceRemote
} from './firebase';
import { ConversationStore } from './conversationStore';
import { PolicyEngine } from './policyEngine';

const OUTBOX_STORAGE_KEY = 'lorin_sync_outbox_v2';
const TRUSTED_DEVICE_CACHE_POLICY_KEY = 'lorin_trusted_device_retain_cache_v2';
const NOTIFICATION_PREFS_KEY = 'lorin_notification_prefs_v2';

export interface NotificationCategoryPreferences {
  enabled: boolean;
  approvalRequests: boolean;
  longRunningTaskCompletion: boolean;
  primaryNodeDisconnected: boolean;
  securityAlerts: boolean;
  dailyGoalsReminders: boolean;
}

const DEFAULT_NOTIFICATION_PREFS: NotificationCategoryPreferences = {
  enabled: false,
  approvalRequests: true,
  longRunningTaskCompletion: true,
  primaryNodeDisconnected: true,
  securityAlerts: true,
  dailyGoalsReminders: false
};

export type CapabilityIdentifier =
  | 'CLOUD_AUTH_FIRESTORE'
  | 'MULTI_DEVICE_CONVERSATION_SYNC'
  | 'CLOUD_AI_INFERENCE'
  | 'VOICE_WEB_SPEECH_API'
  | 'VISION_CAMERA_SNAPSHOT'
  | 'LOCAL_OLLAMA_INFERENCE'
  | 'PRIMARY_NODE_SQLITE_VAULT'
  | 'PRIMARY_NODE_TELEMETRY'
  | 'CONTROLLED_NODE_COMMAND';

export interface CapabilityRouteDecision {
  capability: CapabilityIdentifier;
  executionTarget: 'CLOUD_PWA' | 'PRIMARY_NODE' | 'BROWSER_LOCAL' | 'UNAVAILABLE';
  available: boolean;
  reason: string;
  requiresPrimaryNode: boolean;
  requiresInternet: boolean;
}

export interface NodeStatusSnapshot {
  telemetry: PrimaryNodeTelemetry;
  network: PrivateNetworkStatus;
  devices: EnrolledDeviceRecord[];
  approvedCommands: ApprovedNodeCommandSpec[];
  commandHistory: ApprovedNodeCommandResult[];
  availabilityMode: HybridAvailabilityMode;
}

class DeviceCenterClientService {
  private lastTelemetry: PrimaryNodeTelemetry | null = null;
  private lastNetwork: PrivateNetworkStatus | null = null;
  private enrolledDevices: EnrolledDeviceRecord[] = [];
  private approvedCommands: ApprovedNodeCommandSpec[] = [];
  private commandHistory: ApprovedNodeCommandResult[] = [];
  private lastCompletedSyncAt: number | null = null;
  private lastSyncError: string | null = null;
  private isFlushingOutbox = false;

  getClientDeviceId(): string {
    return getEnrolledClientDeviceId();
  }

  setClientDeviceId(deviceId: string): void {
    setEnrolledClientDeviceId(deviceId);
  }

  isTrustedDeviceCacheRetained(): boolean {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.getItem(TRUSTED_DEVICE_CACHE_POLICY_KEY) === 'true';
      }
    } catch {
      // ignore
    }
    return false;
  }

  setTrustedDeviceCacheRetained(retain: boolean): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(TRUSTED_DEVICE_CACHE_POLICY_KEY, retain ? 'true' : 'false');
      }
    } catch {
      // ignore
    }
  }

  /**
   * Section 9 — Offline, Online, and Node-Offline Matrix
   * Truthfully computes the 4-state HybridAvailabilityMode based on real browser connectivity and Primary Node reachability.
   */
  computeHybridAvailabilityMode(
    telemetry: PrimaryNodeTelemetry | null = this.lastTelemetry,
    browserOnline: boolean = typeof navigator !== 'undefined' ? navigator.onLine !== false : true
  ): HybridAvailabilityMode {
    const nodeRunning = Boolean(
      telemetry &&
        telemetry.lifecycleState === 'RUNNING' &&
        Date.now() - telemetry.lastHeartbeatAt < 120_000
    );

    if (browserOnline && nodeRunning) {
      return 'CLOUD_AND_NODE_AVAILABLE';
    }
    if (browserOnline && !nodeRunning) {
      return 'CLOUD_ONLY_NODE_UNAVAILABLE';
    }
    if (!browserOnline && nodeRunning) {
      return 'NODE_ONLY_INTERNET_UNAVAILABLE';
    }
    return 'BOTH_UNAVAILABLE_CACHED_SHELL';
  }

  /**
   * Section 9 — Centralized Local vs. Cloud Capability Router
   * Determines whether each feature runs in Cloud/Browser vs. Primary Laptop Node and blocks unavailable features with truthful explanations.
   */
  routeCapability(
    capability: CapabilityIdentifier,
    mode: HybridAvailabilityMode = this.computeHybridAvailabilityMode(),
    telemetry: PrimaryNodeTelemetry | null = this.lastTelemetry
  ): CapabilityRouteDecision {
    const nodeAvailable =
      mode === 'CLOUD_AND_NODE_AVAILABLE' || mode === 'NODE_ONLY_INTERNET_UNAVAILABLE';
    const cloudAvailable =
      mode === 'CLOUD_AND_NODE_AVAILABLE' || mode === 'CLOUD_ONLY_NODE_UNAVAILABLE';

    switch (capability) {
      case 'LOCAL_OLLAMA_INFERENCE': {
        const ollamaHealthy = Boolean(telemetry?.ollamaStatus?.reachable);
        if (!nodeAvailable) {
          return {
            capability,
            executionTarget: 'UNAVAILABLE',
            available: false,
            reason:
              'Primary Laptop Node is offline or stopped. Local Ollama models require an active connection to the Primary Node.',
            requiresPrimaryNode: true,
            requiresInternet: false
          };
        }
        if (!ollamaHealthy) {
          return {
            capability,
            executionTarget: 'PRIMARY_NODE',
            available: false,
            reason:
              'Primary Laptop Node is online, but local Ollama service (127.0.0.1:11434) is not currently running on the laptop.',
            requiresPrimaryNode: true,
            requiresInternet: false
          };
        }
        return {
          capability,
          executionTarget: 'PRIMARY_NODE',
          available: true,
          reason: 'Routed to Primary Laptop Node local Ollama engine over private encrypted link.',
          requiresPrimaryNode: true,
          requiresInternet: false
        };
      }

      case 'PRIMARY_NODE_SQLITE_VAULT':
      case 'PRIMARY_NODE_TELEMETRY':
      case 'CONTROLLED_NODE_COMMAND': {
        if (!nodeAvailable) {
          return {
            capability,
            executionTarget: 'UNAVAILABLE',
            available: false,
            reason:
              'Primary Laptop Node is unreachable. Start the laptop service or connect via Tailscale Serve.',
            requiresPrimaryNode: true,
            requiresInternet: false
          };
        }
        return {
          capability,
          executionTarget: 'PRIMARY_NODE',
          available: true,
          reason: 'Executed directly on the authenticated Primary Laptop Node.',
          requiresPrimaryNode: true,
          requiresInternet: false
        };
      }

      case 'CLOUD_AI_INFERENCE':
      case 'CLOUD_AUTH_FIRESTORE': {
        if (!cloudAvailable) {
          return {
            capability,
            executionTarget: 'UNAVAILABLE',
            available: false,
            reason:
              'Cloud internet connection is currently offline. Use local Primary Node capabilities or cached workspace data.',
            requiresPrimaryNode: false,
            requiresInternet: true
          };
        }
        return {
          capability,
          executionTarget: 'CLOUD_PWA',
          available: true,
          reason: 'Routed via authenticated Cloud Server Proxy & Firebase.',
          requiresPrimaryNode: false,
          requiresInternet: true
        };
      }

      case 'MULTI_DEVICE_CONVERSATION_SYNC': {
        if (nodeAvailable || cloudAvailable) {
          return {
            capability,
            executionTarget: nodeAvailable ? 'PRIMARY_NODE' : 'CLOUD_PWA',
            available: true,
            reason: nodeAvailable
              ? 'Synchronized across Primary Node encrypted SQLite store and Firebase Cloud.'
              : 'Synchronized via Firebase Cloud; Primary Node will catch up automatically when online.',
            requiresPrimaryNode: false,
            requiresInternet: false
          };
        }
        return {
          capability,
          executionTarget: 'BROWSER_LOCAL',
          available: true,
          reason: 'Queued in local encrypted outbox; will flush automatically on reconnection.',
          requiresPrimaryNode: false,
          requiresInternet: false
        };
      }

      case 'VOICE_WEB_SPEECH_API':
      case 'VISION_CAMERA_SNAPSHOT':
      default:
        return {
          capability,
          executionTarget: 'BROWSER_LOCAL',
          available: true,
          reason: 'Handled directly by browser hardware media APIs with user permission.',
          requiresPrimaryNode: false,
          requiresInternet: false
        };
    }
  }

  /**
   * Fetch live Primary Node telemetry, Private Network status, Devices, and Approved Command Specs
   */
  async getNodeAndNetworkStatus(): Promise<NodeStatusSnapshot | null> {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/node/status', { headers });
      if (!res.ok) return null;
      const data = await res.json();
      this.lastTelemetry = data.telemetry;
      this.lastNetwork = data.network;
      if (Array.isArray(data.devices)) {
        this.enrolledDevices = data.devices;
      }
      if (Array.isArray(data.approvedCommands)) {
        this.approvedCommands = data.approvedCommands;
      }
      if (Array.isArray(data.commandHistory)) {
        this.commandHistory = data.commandHistory;
      }
      const availabilityMode = this.computeHybridAvailabilityMode(data.telemetry);
      return {
        telemetry: data.telemetry,
        network: data.network,
        devices: this.enrolledDevices,
        approvedCommands: this.approvedCommands,
        commandHistory: this.commandHistory,
        availabilityMode
      };
    } catch (err) {
      this.lastSyncError = err instanceof Error ? err.message : String(err);
      return null;
    }
  }

  /**
   * Control Primary Laptop Node Lifecycle (System Owner Only)
   */
  async controlNodeLifecycle(
    action: 'START' | 'STOP' | 'RESTART' | 'SLEEP' | 'WAKE' | 'SET_AUTO_START',
    autoStartOnBoot?: boolean
  ): Promise<{ success: boolean; message: string; telemetry?: PrimaryNodeTelemetry }> {
    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch('/api/node/lifecycle', {
        method: 'POST',
        headers,
        body: JSON.stringify({ action, autoStartOnBoot })
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || 'Failed to update Primary Node lifecycle.' };
      }
      if (data.telemetry) {
        this.lastTelemetry = data.telemetry;
      }
      return {
        success: Boolean(data.success),
        message:
          action === 'SET_AUTO_START'
            ? `Start-on-login updated to ${Boolean(autoStartOnBoot)}.`
            : `Primary Node transitioned to ${data.telemetry?.lifecycleState || action}.`,
        telemetry: data.telemetry
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'Primary Node lifecycle request failed.'
      };
    }
  }

  /**
   * Configure Tailscale Serve HTTPS Endpoint (Blocks Tailscale Funnel / plain HTTP)
   */
  async configureTailscaleEndpoint(
    endpoint: string
  ): Promise<{ success: boolean; message: string; network?: PrivateNetworkStatus }> {
    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch('/api/network/tailscale/endpoint', {
        method: 'POST',
        headers,
        body: JSON.stringify({ endpoint })
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || 'Failed to configure Tailscale endpoint.' };
      }
      if (data.network) {
        this.lastNetwork = data.network;
      }
      return {
        success: Boolean(data.success),
        message: `Configured Tailscale Serve HTTPS endpoint: ${data.endpoint || 'cleared'}.`,
        network: data.network
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'Network endpoint configuration failed.'
      };
    }
  }

  /**
   * Configure Optional HTTPS-Only Local LAN Fallback Endpoint
   */
  async configureSecureLanEndpoint(
    endpoint: string
  ): Promise<{ success: boolean; message: string; network?: PrivateNetworkStatus }> {
    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch('/api/network/lan/endpoint', {
        method: 'POST',
        headers,
        body: JSON.stringify({ endpoint })
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || 'Failed to configure Secure LAN endpoint.' };
      }
      if (data.network) {
        this.lastNetwork = data.network;
      }
      return {
        success: Boolean(data.success),
        message: `Verified HTTPS LAN endpoint configured (${endpoint}).`,
        network: data.network
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'LAN endpoint configuration failed.'
      };
    }
  }

  /**
   * List Enrolled Devices in LORIN Device Center
   */
  async listEnrolledDevices(): Promise<EnrolledDeviceRecord[]> {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/devices', { headers });
      if (!res.ok) return this.enrolledDevices;
      const data = await res.json();
      if (Array.isArray(data.devices)) {
        this.enrolledDevices = data.devices;
      }
      return this.enrolledDevices;
    } catch {
      return this.enrolledDevices;
    }
  }

  /**
   * Create a Single-Use, Short-Lived QR Pairing Challenge (System Owner Only)
   */
  async createPairingChallenge(params: {
    proposedDeviceName?: string;
    targetDeviceType?: EnrolledDeviceType;
    ttlMs?: number;
  }): Promise<{
    success: boolean;
    message?: string;
    challenge?: DevicePairingChallenge;
  }> {
    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch('/api/devices/pairing/create', {
        method: 'POST',
        headers,
        body: JSON.stringify(params)
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || 'Failed to create QR pairing challenge.' };
      }
      return {
        success: true,
        challenge: data.challenge
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'Pairing challenge creation failed.'
      };
    }
  }

  /**
   * Redeem a Single-Use QR Pairing Challenge from a Mobile / Companion Device
   */
  async redeemPairingChallenge(params: {
    challengeId: string;
    oneTimeCode: string;
    deviceId?: string;
    deviceName: string;
    deviceType: EnrolledDeviceType;
    platformSummary: string;
    connectionType?: PrivateNetworkProviderType;
    userId?: string;
  }): Promise<{
    success: boolean;
    message: string;
    device?: EnrolledDeviceRecord;
  }> {
    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch('/api/devices/pairing/redeem', {
        method: 'POST',
        headers,
        body: JSON.stringify(params)
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || data.message || 'Pairing redemption rejected.' };
      }
      if (data.device) {
        setEnrolledClientDeviceId(data.device.deviceId);
        if (params.userId) {
          persistEnrolledDeviceRemote(params.userId, data.device).catch(() => {});
        }
      }
      return {
        success: true,
        message: data.message || 'Device enrolled.',
        device: data.device
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'Pairing redemption failed.'
      };
    }
  }

  /**
   * Send Authenticated Device Heartbeat
   */
  async sendDeviceHeartbeat(params?: {
    deviceId?: string;
    state?: DeviceConnectionState;
    connectionType?: PrivateNetworkProviderType;
  }): Promise<{ success: boolean; device?: EnrolledDeviceRecord; message?: string }> {
    const targetDeviceId = params?.deviceId || this.getClientDeviceId();
    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch(`/api/devices/${encodeURIComponent(targetDeviceId)}/heartbeat`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          state: params?.state || 'online',
          connectionType: params?.connectionType
        })
      });
      const data = await res.json();
      return {
        success: res.ok && Boolean(data.success),
        device: data.device,
        message: data.message || data.error
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'Heartbeat failed'
      };
    }
  }

  /**
   * Manage Enrolled Device (Approve, Suspend, Revoke, Rename, Update Permissions)
   */
  async manageDevice(
    deviceId: string,
    action: 'APPROVE' | 'SUSPEND' | 'REVOKE' | 'RENAME' | 'UPDATE_PERMISSIONS',
    options?: {
      deviceName?: string;
      permissions?: DeviceCapabilityScope[];
      trustedCachePolicy?: 'PERSISTENT_TRUSTED' | 'CLEAR_ON_LOGOUT';
      userId?: string;
    }
  ): Promise<{ success: boolean; message: string; device?: EnrolledDeviceRecord }> {
    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch(`/api/devices/${encodeURIComponent(deviceId)}/action`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          action,
          deviceName: options?.deviceName,
          permissions: options?.permissions,
          trustedCachePolicy: options?.trustedCachePolicy
        })
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || data.message || 'Device management action failed.' };
      }
      if (data.device && options?.userId) {
        persistEnrolledDeviceRemote(options.userId, data.device).catch(() => {});
      }
      await this.listEnrolledDevices();
      return {
        success: Boolean(data.success),
        message: data.message || 'Device updated.',
        device: data.device
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'Device action failed.'
      };
    }
  }

  /**
   * Remove Enrolled Device (Cannot remove Primary Laptop Node)
   */
  async removeDevice(
    deviceId: string,
    userId?: string
  ): Promise<{ success: boolean; message: string }> {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(`/api/devices/${encodeURIComponent(deviceId)}`, {
        method: 'DELETE',
        headers
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || data.message || 'Device removal failed.' };
      }
      if (userId) {
        removeEnrolledDeviceRemote(userId, deviceId).catch(() => {});
      }
      await this.listEnrolledDevices();
      return {
        success: Boolean(data.success),
        message: data.message || 'Device removed.'
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'Device removal failed.'
      };
    }
  }

  /**
   * Outbox Queue Management for Offline / Reconnection Resilience (Section 8)
   */
  private memoryOutbox: SyncOutboxItem[] = [];

  getOutboxQueue(): SyncOutboxItem[] {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const raw = window.localStorage.getItem(OUTBOX_STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) {
            this.memoryOutbox = parsed;
            return parsed;
          }
        }
      }
    } catch {
      // ignore
    }
    return [...this.memoryOutbox];
  }

  private saveOutboxQueue(items: SyncOutboxItem[]): void {
    const trimmed = items.slice(-250);
    this.memoryOutbox = trimmed;
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(OUTBOX_STORAGE_KEY, JSON.stringify(trimmed));
      }
    } catch {
      // ignore
    }
  }

  enqueueOutboxItem(item: {
    userId?: string;
    deviceId?: string;
    entityType: SyncOutboxItem['entityType'];
    entityId: string;
    action: SyncOutboxItem['action'];
    payload: Record<string, unknown>;
  }): SyncOutboxItem {
    const queue = this.getOutboxQueue();
    const existingIdx = queue.findIndex(
      q => q.entityType === item.entityType && q.entityId === item.entityId
    );
    const entry: SyncOutboxItem = {
      operationId: `sync_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      userId: item.userId || 'owner',
      deviceId: item.deviceId || this.getClientDeviceId(),
      entityType: item.entityType,
      entityId: item.entityId,
      action: item.action,
      revision: existingIdx >= 0 ? queue[existingIdx].revision + 1 : 1,
      payload: item.payload,
      createdAt: Date.now(),
      retryCount: existingIdx >= 0 ? queue[existingIdx].retryCount : 0,
      status: 'PENDING'
    };
    if (existingIdx >= 0) {
      queue[existingIdx] = entry;
    } else {
      queue.push(entry);
    }
    this.saveOutboxQueue(queue);
    return entry;
  }

  /**
   * Append-Oriented Multi-Device Conversation Synchronization
   * Deduplicates messages by message ID and merges monotonically without overwriting concurrent mobile/laptop turns.
   */
  async syncConversationWithNode(
    session: ConversationSession,
    userId?: string
  ): Promise<{
    success: boolean;
    revision?: number;
    mergedMessages?: ChatMessage[];
    queuedOffline?: boolean;
  }> {
    const deviceId = this.getClientDeviceId();
    if (userId) {
      persistConversationMeta(userId, session).catch(() => {});
    }

    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch('/api/sync/conversations', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          conversationId: session.id,
          title: session.title,
          projectId: session.projectId,
          messages: session.messages,
          deviceId
        })
      });

      if (!res.ok) {
        throw new Error(`Sync HTTP ${res.status}`);
      }

      const data = await res.json();
      this.lastCompletedSyncAt = Date.now();
      this.lastSyncError = null;

      if (data.conversation && Array.isArray(data.conversation.messages)) {
        return {
          success: true,
          revision: data.revision,
          mergedMessages: data.conversation.messages
        };
      }
      return { success: true, revision: data.revision };
    } catch (err) {
      this.lastSyncError = err instanceof Error ? err.message : String(err);
      this.enqueueOutboxItem({
        userId,
        deviceId,
        entityType: 'conversation',
        entityId: session.id,
        action: 'APPEND_MESSAGE',
        payload: {
          conversationId: session.id,
          title: session.title,
          projectId: session.projectId,
          messages: session.messages,
          deviceId
        }
      });
      return {
        success: false,
        queuedOffline: true
      };
    }
  }

  /**
   * Pull all synchronized conversations from Primary Node and merge into local ConversationStore
   */
  async pullSynchronizedConversations(): Promise<{
    success: boolean;
    syncedCount: number;
    serverTimestamp?: number;
  }> {
    try {
      await this.flushOutboxQueue();
      const headers = await getAuthHeaders();
      const res = await fetch('/api/sync/conversations', { headers });
      if (!res.ok) {
        return { success: false, syncedCount: 0 };
      }
      const data = await res.json();
      const remoteEntries = Array.isArray(data.conversations) ? data.conversations : [];
      let mergedCount = 0;

      for (const entry of remoteEntries) {
        const remote: ConversationSession = entry?.conversation || entry;
        if (!remote || !remote.id || !Array.isArray(remote.messages)) continue;
        const localSessions = ConversationStore.getSessions(true);
        const existing = localSessions.find(s => s.id === remote.id);
        if (!existing) {
          const created = ConversationStore.createSession(
            remote.title || 'Synchronized Thread',
            remote.projectId || 'proj_lorin_core'
          );
          ConversationStore.updateMessages(created.id, remote.messages);
          mergedCount++;
        } else {
          const byId = new Map<string, ChatMessage>();
          for (const m of existing.messages) {
            if (m && m.id) byId.set(m.id, m);
          }
          let changed = false;
          for (const m of remote.messages) {
            if (m && m.id && !byId.has(m.id)) {
              byId.set(m.id, m);
              changed = true;
            }
          }
          if (changed) {
            const merged = Array.from(byId.values()).sort(
              (a, b) => (a.timestamp || 0) - (b.timestamp || 0)
            );
            ConversationStore.updateMessages(existing.id, merged);
            mergedCount++;
          }
        }
      }

      this.lastCompletedSyncAt = Date.now();
      this.lastSyncError = null;
      return {
        success: true,
        syncedCount: remoteEntries.length || mergedCount,
        serverTimestamp: data.timestamp
      };
    } catch (err) {
      this.lastSyncError = err instanceof Error ? err.message : String(err);
      return { success: false, syncedCount: 0 };
    }
  }

  /**
   * Flush Pending Outbox Queue Items upon Reconnection
   */
  async flushOutboxQueue(): Promise<{ flushedCount: number; remainingCount: number }> {
    if (this.isFlushingOutbox) {
      return { flushedCount: 0, remainingCount: this.getOutboxQueue().length };
    }
    const queue = this.getOutboxQueue();
    if (queue.length === 0) {
      return { flushedCount: 0, remainingCount: 0 };
    }

    this.isFlushingOutbox = true;
    const remaining: SyncOutboxItem[] = [];
    let flushedCount = 0;

    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      for (const item of queue) {
        try {
          if (item.entityType === 'conversation' || item.entityType === 'message') {
            const res = await fetch('/api/sync/conversations', {
              method: 'POST',
              headers,
              body: JSON.stringify(item.payload)
            });
            if (res.ok) {
              flushedCount++;
              continue;
            }
          }
          remaining.push({
            ...item,
            retryCount: item.retryCount + 1,
            status: 'FAILED',
            lastError: 'Server unreachable during outbox flush'
          });
        } catch (err) {
          remaining.push({
            ...item,
            retryCount: item.retryCount + 1,
            status: 'FAILED',
            lastError: err instanceof Error ? err.message : 'Flush error'
          });
        }
      }
      this.saveOutboxQueue(remaining);
      if (flushedCount > 0) {
        this.lastCompletedSyncAt = Date.now();
      }
    } finally {
      this.isFlushingOutbox = false;
    }

    return { flushedCount, remainingCount: remaining.length };
  }

  getSyncStatusSummary(): SyncEngineStatusSummary {
    const outbox = this.getOutboxQueue();
    const availabilityMode = this.computeHybridAvailabilityMode();
    return {
      state: outbox.length > 0 ? 'OFFLINE_QUEUED' : 'IDLE',
      availabilityMode,
      pendingOutboxCount: outbox.length,
      syncedOperationsCount: 0,
      conflictsCount: 0,
      lastSyncedAt: this.lastCompletedSyncAt,
      activeDeviceId: this.getClientDeviceId(),
      activeDeviceState: 'online',
      lastError: this.lastSyncError
    };
  }

  /**
   * Execute an Allowlisted Controlled Node Command (Section 10)
   * Arbitrary raw shell strings are impossible — only registered commandIds in APPROVED_NODE_COMMAND_SPECS are accepted.
   */
  async executeApprovedNodeCommand(
    commandId: string
  ): Promise<{
    success: boolean;
    result?: ApprovedNodeCommandResult;
    message?: string;
  }> {
    try {
      const headers = await getAuthHeaders({ 'Content-Type': 'application/json' });
      const res = await fetch('/api/node/commands/execute', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          commandId,
          deviceId: this.getClientDeviceId()
        })
      });
      const result: ApprovedNodeCommandResult = await res.json();
      if (result && result.executionId) {
        this.commandHistory = [result, ...this.commandHistory].slice(0, 30);
      }
      if (result?.status === 'AWAITING_APPROVAL' || result?.approvalId) {
        await PolicyEngine.syncFromBackend();
      }
      if (!res.ok || result.status !== 'COMPLETED') {
        return {
          success: false,
          result,
          message: result?.outputSummary || (result as any)?.error || 'Command execution denied.'
        };
      }
      return {
        success: true,
        result,
        message: result.outputSummary
      };
    } catch (err) {
      return {
        success: false,
        message: err instanceof Error ? err.message : 'Failed to execute node command.'
      };
    }
  }

  getCommandHistory(): ApprovedNodeCommandResult[] {
    return [...this.commandHistory];
  }

  /**
   * Section 15 — User-Controlled Browser & Mobile Notifications
   */
  getNotificationPreferences(): NotificationCategoryPreferences {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const raw = window.localStorage.getItem(NOTIFICATION_PREFS_KEY);
        if (raw) {
          return { ...DEFAULT_NOTIFICATION_PREFS, ...JSON.parse(raw) };
        }
      }
    } catch {
      // ignore
    }
    return { ...DEFAULT_NOTIFICATION_PREFS };
  }

  saveNotificationPreferences(
    prefs: Partial<NotificationCategoryPreferences>
  ): NotificationCategoryPreferences {
    const next = { ...this.getNotificationPreferences(), ...prefs };
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(NOTIFICATION_PREFS_KEY, JSON.stringify(next));
      }
    } catch {
      // ignore
    }
    return next;
  }

  getBrowserNotificationPermission(): 'granted' | 'denied' | 'default' | 'unsupported' {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return 'unsupported';
    }
    return Notification.permission;
  }

  async requestBrowserNotificationPermission(): Promise<'granted' | 'denied' | 'default' | 'unsupported'> {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return 'unsupported';
    }
    try {
      const perm = await Notification.requestPermission();
      if (perm === 'granted') {
        this.saveNotificationPreferences({ enabled: true });
      }
      return perm;
    } catch {
      return Notification.permission;
    }
  }

  /**
   * Centralized System Health Center — 18 Subsystem Inspection (Section 13)
   */
  async getSystemHealthMatrix(): Promise<SystemHealthMatrixResponse | null> {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/system/health-matrix', { headers });
      if (!res.ok) return null;
      return (await res.json()) as SystemHealthMatrixResponse;
    } catch {
      return null;
    }
  }

  /**
   * Section 4 & 16: Automatic Private Network Reconnection & Lifecycle Watcher
   * Listens to visibility changes, network online/offline events, sends periodic heartbeats,
   * flushes pending outbox messages, and synchronizes node status with bounded backoff.
   */
  startAutoReconnectWatcher(callbacks?: {
    onStatusChange?: (snapshot: NodeStatusSnapshot) => void;
    onOutboxFlushed?: (count: number) => void;
  }): () => void {
    if (typeof window === 'undefined') {
      return () => {};
    }

    let isDisposed = false;
    let heartbeatTimer: any = null;
    let reconnectDelayMs = 2000;
    const MAX_RECONNECT_DELAY_MS = 30000;

    const triggerReconnectionCheck = async () => {
      if (isDisposed) return;
      try {
        const snapshot = await this.getNodeAndNetworkStatus();
        if (snapshot) {
          reconnectDelayMs = 2000; // Reset backoff on success
          if (callbacks?.onStatusChange) {
            callbacks.onStatusChange(snapshot);
          }
        } else {
          reconnectDelayMs = Math.min(reconnectDelayMs * 1.5, MAX_RECONNECT_DELAY_MS);
        }

        // Send truthful heartbeat if client is online
        if (navigator.onLine) {
          await this.sendDeviceHeartbeat({ state: 'online' });
          const flushRes = await this.flushOutboxQueue();
          if (flushRes.flushedCount > 0 && callbacks?.onOutboxFlushed) {
            callbacks.onOutboxFlushed(flushRes.flushedCount);
          }
        }
      } catch {
        reconnectDelayMs = Math.min(reconnectDelayMs * 1.5, MAX_RECONNECT_DELAY_MS);
      }
    };

    // 1. Initial check
    triggerReconnectionCheck();

    // 2. Lifecycle event listeners
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        triggerReconnectionCheck();
      }
    };

    const handleOnline = () => {
      triggerReconnectionCheck();
    };

    const handleFocus = () => {
      triggerReconnectionCheck();
    };

    window.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('online', handleOnline);
    window.addEventListener('focus', handleFocus);

    // 3. Periodic heartbeat and sync timer (every 45s)
    heartbeatTimer = setInterval(() => {
      if (!isDisposed && document.visibilityState === 'visible') {
        triggerReconnectionCheck();
      }
    }, 45000);

    return () => {
      isDisposed = true;
      if (heartbeatTimer) clearInterval(heartbeatTimer);
      window.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('focus', handleFocus);
    };
  }
}

export interface SubsystemHealthItem {
  id: string;
  name: string;
  category: 'core' | 'ai' | 'network' | 'storage' | 'media';
  state: 'HEALTHY' | 'STARTING' | 'CONNECTING' | 'DEGRADED' | 'UNAVAILABLE' | 'FAILED' | 'NOT_CONFIGURED' | 'NOT_VERIFIED';
  diagnosticCode: string;
  summary: string;
  details?: Record<string, unknown>;
}

export interface SystemHealthMatrixResponse {
  timestamp: number;
  overallStatus: 'HEALTHY' | 'DEGRADED' | 'FAILED';
  summary: string;
  subsystems: SubsystemHealthItem[];
}

export const DeviceCenterService = new DeviceCenterClientService();

