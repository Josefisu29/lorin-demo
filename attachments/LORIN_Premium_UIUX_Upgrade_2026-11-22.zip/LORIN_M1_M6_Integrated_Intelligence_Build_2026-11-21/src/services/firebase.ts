import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  signOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  multiFactor,
  User
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  deleteDoc,
  collection,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  getDocs,
  Timestamp
} from 'firebase/firestore';
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL,
  deleteObject
} from 'firebase/storage';
import {
  initializeAppCheck,
  ReCaptchaEnterpriseProvider,
  ReCaptchaV3Provider,
  AppCheck
} from 'firebase/app-check';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  AccountStatus,
  ApprovalRecord,
  AuditEvent,
  CanonicalPermissionScope,
  CanonicalRole,
  ChatMessage,
  ConversationSession,
  DurableTaskRecord,
  EnrolledDeviceRecord,
  ManagedUserAccount,
  MemoryRecord,
  Principal,
  ProjectRecord,
  SystemControlConfig,
  VaultDocument,
  normalizeCanonicalRole
} from '../types/lorin';

const envMeta = (typeof import.meta !== 'undefined' && (import.meta as any).env) || {};

export const resolvedFirebaseConfig = {
  ...firebaseConfig,
  apiKey: envMeta.VITE_FIREBASE_API_KEY || firebaseConfig.apiKey,
  authDomain: envMeta.VITE_FIREBASE_AUTH_DOMAIN || firebaseConfig.authDomain,
  projectId: envMeta.VITE_FIREBASE_PROJECT_ID || firebaseConfig.projectId,
  storageBucket: envMeta.VITE_FIREBASE_STORAGE_BUCKET || firebaseConfig.storageBucket,
  appId: envMeta.VITE_FIREBASE_APP_ID || firebaseConfig.appId,
  messagingSenderId: envMeta.VITE_FIREBASE_MESSAGING_SENDER_ID || firebaseConfig.messagingSenderId,
  measurementId: envMeta.VITE_FIREBASE_MEASUREMENT_ID || firebaseConfig.measurementId,
  firestoreDatabaseId: envMeta.VITE_FIREBASE_FIRESTORE_DATABASE_ID || firebaseConfig.firestoreDatabaseId
};

// Initialize Firebase App
const app = !getApps().length ? initializeApp(resolvedFirebaseConfig) : getApp();

// CRITICAL: Specify firestoreDatabaseId for the provisioned Firestore database
export const db = getFirestore(app, resolvedFirebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const googleAuthProvider = new GoogleAuthProvider();

let appCheckInstance: AppCheck | null = null;
const appCheckSiteKey = (envMeta.VITE_FIREBASE_APPCHECK_SITE_KEY || '').trim();
const appCheckProviderType = (envMeta.VITE_FIREBASE_APPCHECK_PROVIDER || 'enterprise').trim().toLowerCase();

if (typeof window !== 'undefined' && appCheckSiteKey) {
  try {
    if (envMeta.DEV && envMeta.VITE_FIREBASE_APPCHECK_DEBUG_TOKEN) {
      (self as any).FIREBASE_APPCHECK_DEBUG_TOKEN = envMeta.VITE_FIREBASE_APPCHECK_DEBUG_TOKEN;
    }
    const provider =
      appCheckProviderType === 'v3'
        ? new ReCaptchaV3Provider(appCheckSiteKey)
        : new ReCaptchaEnterpriseProvider(appCheckSiteKey);
    appCheckInstance = initializeAppCheck(app, {
      provider,
      isTokenAutoRefreshEnabled: true
    });
  } catch (err) {
    console.warn('Firebase App Check initialization skipped:', err);
  }
}

export function getFirebaseAppCheckStatus(): {
  configured: boolean;
  active: boolean;
  provider: 'recaptcha-enterprise' | 'recaptcha-v3' | 'unconfigured';
} {
  return {
    configured: Boolean(appCheckSiteKey),
    active: Boolean(appCheckInstance),
    provider: !appCheckSiteKey
      ? 'unconfigured'
      : appCheckProviderType === 'v3'
      ? 'recaptcha-v3'
      : 'recaptcha-enterprise'
  };
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Validate Connection to Firestore on startup
 */
export async function testFirestoreConnection(): Promise<{ connected: boolean; error?: string }> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return { connected: true };
  } catch (error: any) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firestore offline:', error.message);
      return { connected: false, error: 'Offline - local cache active' };
    }
    // Permissions error on test/connection is normal if rule denies non-auth, connection is alive
    if (error?.code === 'permission-denied' || error?.message?.includes('permission')) {
      return { connected: true };
    }
    return { connected: false, error: error.message };
  }
}

/**
 * Real-time Firebase Authentication Helpers
 */
export async function signInWithGooglePopup(): Promise<User> {
  const result = await signInWithPopup(auth, googleAuthProvider);
  return result.user;
}

export async function signInWithEmailAccount(email: string, password: string): Promise<User> {
  const result = await signInWithEmailAndPassword(auth, email.trim(), password);
  return result.user;
}

export async function registerWithEmailAccount(email: string, password: string): Promise<User> {
  const result = await createUserWithEmailAndPassword(auth, email.trim(), password);
  return result.user;
}

export async function sendPasswordResetForEmail(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

export async function sendVerificationToCurrentUser(): Promise<boolean> {
  if (!auth.currentUser) return false;
  await sendEmailVerification(auth.currentUser);
  return true;
}

export async function refreshCurrentUserIdToken(forceRefresh = true): Promise<string | null> {
  if (!auth.currentUser) return null;
  try {
    return await auth.currentUser.getIdToken(forceRefresh);
  } catch {
    return null;
  }
}

export async function signOutFirebaseUser(): Promise<void> {
  await signOut(auth);
}

/**
 * Real-time Firestore Persistence for Authenticated User Profile (Without Self-Promotion)
 */
export async function syncUserProfileToFirestore(principal: Principal): Promise<void> {
  if (!auth.currentUser || !principal.authenticated || !principal.id) return;
  const uid = auth.currentUser.uid;
  try {
    const canonical = normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus);
    const safeSelfRole = canonical === 'SYSTEM_OWNER' || canonical === 'SUPER_ADMIN' || canonical === 'ADMINISTRATOR'
      ? undefined
      : canonical;
    const payload: Record<string, any> = {
      id: uid,
      email: principal.email,
      displayName: principal.name,
      lastActiveAt: new Date().toISOString()
    };
    if (safeSelfRole) {
      payload.role = safeSelfRole;
      payload.canonicalRole = safeSelfRole;
    }
    await setDoc(doc(db, 'users', uid), payload, { merge: true });
  } catch (error) {
    console.warn('Firestore user profile sync deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for Authoritative Role Assignments (Super Admin / System Owner)
 */
export async function persistUserRoleAssignmentRemote(
  account: ManagedUserAccount,
  actorUid: string
): Promise<void> {
  if (!auth.currentUser || !account.uid) return;
  try {
    await setDoc(
      doc(db, 'user_roles', account.uid),
      {
        uid: account.uid,
        email: account.email,
        canonicalRole: account.canonicalRole,
        accountStatus: account.accountStatus,
        delegatedPermissions: account.delegatedPermissions || [],
        projectScopes: account.projectScopes || [],
        updatedBy: actorUid,
        updatedAt: Date.now()
      },
      { merge: true }
    );
  } catch (error) {
    console.warn('Firestore user_roles sync deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for Conversation Thread Metadata
 */
export async function persistConversationMeta(
  userId: string,
  session: ConversationSession
): Promise<void> {
  if (!auth.currentUser) return;
  const effectiveUserId = auth.currentUser.uid || userId;
  try {
    await setDoc(doc(db, 'conversations', session.id), {
      id: session.id,
      userId: effectiveUserId,
      title: session.title,
      projectId: session.projectId,
      isArchived: Boolean(session.isArchived),
      messageCount: session.messages.length,
      updatedAt: new Date(session.updatedAt).toISOString(),
      createdAt: new Date(session.createdAt).toISOString()
    }, { merge: true });
  } catch (error) {
    console.warn('Firestore conversation meta sync deferred:', error);
  }
}

export async function deleteConversationRemote(conversationId: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await deleteDoc(doc(db, 'conversations', conversationId));
  } catch (error) {
    console.warn('Firestore conversation delete deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for LORIN Chat Messages
 */
export async function persistChatMessage(
  userId: string,
  message: ChatMessage,
  conversationId = 'default_workspace',
  conversationTitle = 'Active LORIN Workspace'
): Promise<void> {
  if (!auth.currentUser) return;
  const effectiveUserId = auth.currentUser.uid || userId;
  const path = `conversations/${conversationId}/messages`;
  try {
    await setDoc(doc(db, 'conversations', conversationId), {
      id: conversationId,
      userId: effectiveUserId,
      title: conversationTitle,
      projectId: message.projectId || 'proj_lorin_core',
      updatedAt: new Date().toISOString()
    }, { merge: true });

    await setDoc(doc(db, path, message.id), {
      id: message.id,
      userId: effectiveUserId,
      conversationId,
      sender: message.role,
      text: message.content,
      isPinned: !!message.isPinned,
      attachedFileName: message.attachedFile?.name || null,
      attachedFileSize: message.attachedFile?.size || null,
      reportSnippet: message.completionReport?.rawSynthesis?.slice(0, 500) || null,
      createdAt: new Date(message.timestamp).toISOString()
    });
  } catch (error) {
    console.warn('Firestore message persistence deferred (offline mode or auth pending):', error);
  }
}

/**
 * Real-time Firestore Persistence for Knowledge Vault Documents
 */
export async function persistVaultDocument(
  userId: string,
  docItem: VaultDocument
): Promise<void> {
  if (!auth.currentUser) return;
  const effectiveUserId = auth.currentUser.uid || userId;
  const path = 'vault_documents';
  try {
    await setDoc(doc(db, path, docItem.id), {
      id: docItem.id,
      userId: effectiveUserId,
      title: docItem.title,
      fileName: docItem.fileName,
      fileType: docItem.fileType,
      fileSize: docItem.fileSize,
      collection: docItem.collection || 'General',
      content: docItem.content.slice(0, 200000), // Firestore 1MB document boundary guard
      importedAt: docItem.importedAt
    });
  } catch (error) {
    console.warn('Firestore vault sync deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for Security Approvals & Audit Records
 */
export async function persistApprovalAudit(
  userId: string,
  record: ApprovalRecord
): Promise<void> {
  if (!auth.currentUser) return;
  const effectiveUserId = auth.currentUser.uid || userId;
  const path = 'approval_audits';
  try {
    await setDoc(doc(db, path, record.id), {
      id: record.id,
      userId: effectiveUserId,
      action: record.action,
      resource: record.resource,
      riskLevel: record.riskLevel,
      status: record.status,
      actionDigest: record.actionDigest,
      timestamp: record.createdAt
    });
  } catch (error) {
    console.warn('Firestore audit record deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for Security Events
 */
export async function persistSecurityEventRemote(event: AuditEvent): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'security_events', event.id), {
      id: event.id,
      principalId: event.principalId,
      role: event.role,
      action: event.action,
      resource: event.resource,
      decision: event.decision,
      reason: event.reason,
      timestamp: event.timestamp
    });
  } catch (error) {
    console.warn('Firestore security event sync deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for Persistent Personal Memory Records
 */
export async function loadMemoryRecordsRemote(userId: string): Promise<MemoryRecord[]> {
  if (!auth.currentUser || auth.currentUser.uid !== userId) return [];
  const memoryQuery = query(
    collection(db, 'memory_records'),
    where('userId', '==', userId)
  );
  const snapshot = await getDocs(memoryQuery);
  return snapshot.docs.map((item) => {
    const data = item.data() as Record<string, any>;
    const updatedAt = typeof data.updatedAt === 'number'
      ? data.updatedAt
      : Date.parse(String(data.updatedAtIso || data.updatedAt || '')) || Date.now();
    const createdAt = typeof data.createdAt === 'number'
      ? data.createdAt
      : Date.parse(String(data.createdAtIso || data.createdAt || '')) || updatedAt;
    return { ...data, id: item.id, createdAt, updatedAt } as MemoryRecord;
  });
}

export async function persistMemoryRecordRemote(
  userId: string,
  record: MemoryRecord
): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== userId) return;
  try {
    await setDoc(doc(db, 'memory_records', record.id), {
      ...record,
      userId,
      updatedAtIso: new Date(record.updatedAt).toISOString(),
      createdAtIso: new Date(record.createdAt).toISOString()
    }, { merge: true });
  } catch (error) {
    console.warn('Firestore memory sync deferred:', error);
    throw error;
  }
}

export async function deleteMemoryRecordRemote(userId: string, memoryId: string): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== userId) return;
  try {
    const ref = doc(db, 'memory_records', memoryId);
    const existing = await getDoc(ref);
    if (existing.exists() && existing.data().userId === userId) {
      await deleteDoc(ref);
    }
  } catch (error) {
    console.warn('Firestore memory deletion deferred:', error);
    throw error;
  }
}

export async function deleteAllMemoryRecordsRemote(userId: string): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== userId) return;
  const records = await loadMemoryRecordsRemote(userId);
  await Promise.all(records.map((record) => deleteMemoryRecordRemote(userId, record.id)));
}

/**
 * Real-time Firestore Persistence for Projects
 */
export async function persistProjectRemote(
  ownerId: string,
  project: ProjectRecord
): Promise<void> {
  if (!auth.currentUser) return;
  const effectiveOwnerId = auth.currentUser.uid || ownerId;
  try {
    await setDoc(doc(db, 'projects', project.id), {
      id: project.id,
      ownerId: effectiveOwnerId,
      name: project.name,
      slug: project.slug,
      classification: project.classification,
      description: project.description,
      status: project.status,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt
    }, { merge: true });
  } catch (error) {
    console.warn('Firestore project sync deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for Durable Tasks
 */
export async function persistTaskRemote(
  userId: string,
  task: DurableTaskRecord
): Promise<void> {
  if (!auth.currentUser) return;
  const effectiveUserId = auth.currentUser.uid || userId;
  try {
    await setDoc(doc(db, 'tasks', task.id), {
      id: task.id,
      userId: effectiveUserId,
      title: task.title,
      projectId: task.projectId,
      state: task.state,
      priority: task.priority,
      riskLevel: task.riskLevel,
      createdAt: task.createdAt,
      updatedAt: task.updatedAt
    }, { merge: true });
  } catch (error) {
    console.warn('Firestore task sync deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for System Settings
 */
export async function persistSystemSettingsRemote(
  config: SystemControlConfig
): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'system_settings', 'global_control_config'), {
      id: 'global_control_config',
      registrationPolicy: config.registrationPolicy,
      globalRateLimitRpm: config.globalRateLimitRpm,
      dailyTokenBudget: config.dailyTokenBudget,
      updatedBy: config.updatedBy,
      updatedAt: config.updatedAt
    }, { merge: true });
  } catch (error) {
    console.warn('Firestore system settings sync deferred:', error);
  }
}

/**
 * Real-time Firestore Persistence for Enrolled Devices in LORIN Device Center
 */
export async function persistEnrolledDeviceRemote(
  userId: string,
  device: EnrolledDeviceRecord
): Promise<void> {
  if (!auth.currentUser) return;
  const effectiveUserId = auth.currentUser.uid || userId;
  try {
    await setDoc(
      doc(db, 'users', effectiveUserId, 'devices', device.deviceId),
      {
        deviceId: device.deviceId,
        ownerId: effectiveUserId,
        ownerUid: device.ownerUid || effectiveUserId,
        deviceName: device.deviceName,
        deviceType: device.deviceType,
        platform: device.platformSummary,
        connectionState: device.connectionState,
        authorizationStatus: device.authorizationStatus,
        networkProvider: device.connectionType,
        tailscaleNodeName: device.tailscaleHostname || null,
        tailscaleIp: device.tailscaleIp || null,
        permissions: device.grantedPermissions,
        isPrimaryNode: Boolean(device.isPrimaryNode),
        isTrustedDevice: device.trustedCachePolicy === 'PERSISTENT_TRUSTED',
        lastHeartbeatAt: device.lastActiveAt,
        enrolledAt: device.enrolledAt
      },
      { merge: true }
    );
  } catch (error) {
    console.warn('Firestore enrolled device sync deferred:', error);
  }
}

export async function removeEnrolledDeviceRemote(
  userId: string,
  deviceId: string
): Promise<void> {
  if (!auth.currentUser) return;
  const effectiveUserId = auth.currentUser.uid || userId;
  try {
    await deleteDoc(doc(db, 'users', effectiveUserId, 'devices', deviceId));
  } catch (error) {
    console.warn('Firestore enrolled device delete deferred:', error);
  }
}

/**
 * Section 7 & 11: Session Persistence, Custom Claims Refresh & MFA Inspection
 */
export async function configureSessionPersistence(rememberSession: boolean): Promise<void> {
  try {
    await setPersistence(auth, rememberSession ? browserLocalPersistence : browserSessionPersistence);
  } catch (err) {
    console.warn('Session persistence configuration warning:', err);
  }
}

export function getMultiFactorStatus(user: User | null = auth.currentUser): {
  enrolled: boolean;
  enrolledFactorsCount: number;
  factorSummary: Array<{ uid: string; factorId: string; displayName?: string | null; enrollmentTime?: string }>;
} {
  if (!user) {
    return { enrolled: false, enrolledFactorsCount: 0, factorSummary: [] };
  }
  try {
    const mfUser = multiFactor(user);
    const factors = mfUser.enrolledFactors || [];
    return {
      enrolled: factors.length > 0,
      enrolledFactorsCount: factors.length,
      factorSummary: factors.map(f => ({
        uid: f.uid,
        factorId: f.factorId,
        displayName: f.displayName,
        enrollmentTime: f.enrollmentTime
      }))
    };
  } catch {
    return { enrolled: false, enrolledFactorsCount: 0, factorSummary: [] };
  }
}

export async function refreshCurrentUserTokenAndClaims(): Promise<{
  token: string | null;
  claims: Record<string, unknown>;
}> {
  if (!auth.currentUser) {
    return { token: null, claims: {} };
  }
  try {
    await auth.currentUser.reload();
    const result = await auth.currentUser.getIdTokenResult(true);
    return {
      token: result.token,
      claims: result.claims || {}
    };
  } catch {
    return { token: null, claims: {} };
  }
}

/**
 * Section 16: Firebase Storage — Ownership-Based Path Builder & Upload Validator
 * Supported canonical paths:
 * - users/{uid}/knowledge/{fileId}/original
 * - users/{uid}/attachments/{conversationId}/{fileId}
 * - users/{uid}/images/{fileId}
 */
export const MAX_STORAGE_FILE_SIZE_BYTES = 25 * 1024 * 1024; // 25 MB

export const ALLOWED_STORAGE_MIME_TYPES = new Set<string>([
  'text/plain',
  'text/markdown',
  'text/csv',
  'application/json',
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/webp',
  'image/gif',
  'audio/webm',
  'audio/wav',
  'audio/mpeg'
]);

const FORBIDDEN_EXTENSIONS = /\.(exe|bat|cmd|sh|ps1|vbs|dll|so|dylib|msi|jar|scr|com)$/i;

export type StorageAssetCategory = 'knowledge' | 'attachments' | 'images';

export interface StorageFileMetadataRecord {
  id: string;
  ownerId: string;
  category: StorageAssetCategory;
  storagePath: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  conversationId?: string;
  downloadUrl?: string;
  createdAt: number;
}

export function buildUserStoragePath(
  uid: string,
  category: StorageAssetCategory,
  fileId: string,
  options?: { conversationId?: string }
): string {
  const cleanUid = (uid || '').trim().replace(/[^a-zA-Z0-9_-]/g, '');
  const cleanFileId = (fileId || '').trim().replace(/[^a-zA-Z0-9_.-]/g, '');
  if (!cleanUid || !cleanFileId) {
    throw new Error('Invalid uid or fileId for storage path.');
  }
  if (category === 'knowledge') {
    return `users/${cleanUid}/knowledge/${cleanFileId}/original`;
  }
  if (category === 'attachments') {
    const cleanConvId = (options?.conversationId || 'default').trim().replace(/[^a-zA-Z0-9_-]/g, '');
    return `users/${cleanUid}/attachments/${cleanConvId}/${cleanFileId}`;
  }
  return `users/${cleanUid}/images/${cleanFileId}`;
}

export function validateStorageUpload(params: {
  uid: string;
  activeUid: string;
  isPrivileged?: boolean;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  storagePath: string;
}): { valid: boolean; reason?: string } {
  if (!params.activeUid || params.activeUid === 'guest_unverified') {
    return { valid: false, reason: 'Authentication required for file storage operations.' };
  }
  if (params.uid !== params.activeUid && !params.isPrivileged) {
    return { valid: false, reason: 'Cross-user file upload is forbidden.' };
  }
  if (params.storagePath.includes('..') || !params.storagePath.startsWith(`users/${params.uid}/`)) {
    return { valid: false, reason: 'Invalid or unauthorized storage path.' };
  }
  if (params.sizeBytes <= 0 || params.sizeBytes > MAX_STORAGE_FILE_SIZE_BYTES) {
    return {
      valid: false,
      reason: `File size must be between 1 byte and ${Math.round(MAX_STORAGE_FILE_SIZE_BYTES / (1024 * 1024))} MB.`
    };
  }
  if (FORBIDDEN_EXTENSIONS.test(params.fileName)) {
    return { valid: false, reason: 'Executable or binary script file extensions are forbidden.' };
  }
  if (!ALLOWED_STORAGE_MIME_TYPES.has(params.mimeType)) {
    return { valid: false, reason: `Unsupported MIME type '${params.mimeType}'.` };
  }
  return { valid: true };
}

export async function uploadUserFileToStorage(params: {
  uid: string;
  category: StorageAssetCategory;
  fileId: string;
  file: Blob | Uint8Array;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  conversationId?: string;
  isPrivileged?: boolean;
}): Promise<{ success: boolean; message: string; metadata?: StorageFileMetadataRecord }> {
  const activeUid = auth.currentUser?.uid || '';
  const storagePath = buildUserStoragePath(params.uid, params.category, params.fileId, {
    conversationId: params.conversationId
  });

  const validation = validateStorageUpload({
    uid: params.uid,
    activeUid,
    isPrivileged: params.isPrivileged,
    fileName: params.fileName,
    mimeType: params.mimeType,
    sizeBytes: params.sizeBytes,
    storagePath
  });

  if (!validation.valid) {
    return { success: false, message: validation.reason || 'Storage validation failed.' };
  }

  try {
    const fileRef = storageRef(storage, storagePath);
    await uploadBytes(fileRef, params.file, {
      contentType: params.mimeType,
      customMetadata: {
        ownerId: params.uid,
        originalFileName: params.fileName,
        category: params.category
      }
    });
    const downloadUrl = await getDownloadURL(fileRef);

    const metadata: StorageFileMetadataRecord = {
      id: params.fileId,
      ownerId: params.uid,
      category: params.category,
      storagePath,
      fileName: params.fileName,
      mimeType: params.mimeType,
      sizeBytes: params.sizeBytes,
      conversationId: params.conversationId,
      downloadUrl,
      createdAt: Date.now()
    };

    await setDoc(doc(db, 'users', params.uid, 'storage_files', params.fileId), metadata, { merge: true });
    return { success: true, message: 'File uploaded and metadata recorded.', metadata };
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    return { success: false, message: `Storage upload failed: ${msg}` };
  }
}

export async function deleteUserFileFromStorage(params: {
  uid: string;
  fileId: string;
  storagePath: string;
  isPrivileged?: boolean;
}): Promise<{ success: boolean; message: string }> {
  const activeUid = auth.currentUser?.uid || '';
  if (!activeUid) {
    return { success: false, message: 'Authentication required.' };
  }
  if (params.uid !== activeUid && !params.isPrivileged) {
    return { success: false, message: 'Cross-user file deletion is forbidden.' };
  }
  if (params.storagePath.includes('..') || !params.storagePath.startsWith(`users/${params.uid}/`)) {
    return { success: false, message: 'Invalid storage path.' };
  }

  try {
    const fileRef = storageRef(storage, params.storagePath);
    await deleteObject(fileRef);
    await deleteDoc(doc(db, 'users', params.uid, 'storage_files', params.fileId));
    return { success: true, message: 'Storage object and metadata deleted.' };
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    return { success: false, message: `Storage deletion failed: ${msg}` };
  }
}

export {
  onAuthStateChanged,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  deleteDoc,
  collection,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  getDocs,
  Timestamp
};
