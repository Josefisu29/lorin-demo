/**
 * Real Camera & Video Vision Service
 * Provides explicit user-controlled camera preview, frame snapshot analysis, and clean hardware teardown
 */

export class VideoService {
  private static mediaStream: MediaStream | null = null;
  private static facingMode: 'user' | 'environment' = 'user';

  static isCameraSupported(): boolean {
    return typeof navigator !== 'undefined' && !!navigator.mediaDevices && !!navigator.mediaDevices.getUserMedia;
  }

  /**
   * Starts camera capture after explicit user gesture
   */
  static async startCamera(videoElement: HTMLVideoElement, facingMode: 'user' | 'environment' = 'user'): Promise<{ success: boolean; error?: string }> {
    try {
      this.stopCamera(); // Clean any existing capture

      if (!this.isCameraSupported()) {
        return { success: false, error: 'Camera hardware or getUserMedia API is not supported in this browser.' };
      }

      this.facingMode = facingMode;
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: this.facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false // Kept separate; AudioService handles audio with permission
      });

      videoElement.srcObject = this.mediaStream;
      await videoElement.play();

      return { success: true };
    } catch (err: any) {
      this.stopCamera();
      return { success: false, error: err.message || 'Camera permission denied or device unavailable.' };
    }
  }

  /**
   * Captures a still snapshot frame from the active video stream for vision analysis
   */
  static captureSnapshot(videoElement: HTMLVideoElement): string | null {
    if (!this.mediaStream || !videoElement.videoWidth) {
      return null;
    }

    try {
      const canvas = document.createElement('canvas');
      canvas.width = videoElement.videoWidth;
      canvas.height = videoElement.videoHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;

      ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL('image/jpeg', 0.85);
    } catch (e) {
      console.error('Failed to capture video snapshot:', e);
      return null;
    }
  }

  /**
   * Toggles between front and rear cameras if supported
   */
  static async toggleFacingMode(videoElement: HTMLVideoElement): Promise<{ success: boolean; facingMode: 'user' | 'environment' }> {
    const nextMode = this.facingMode === 'user' ? 'environment' : 'user';
    const res = await this.startCamera(videoElement, nextMode);
    return { success: res.success, facingMode: this.facingMode };
  }

  /**
   * Immediately stops all camera tracks so the hardware camera light turns off
   */
  static stopCamera(): void {
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => {
        try {
          track.stop();
        } catch {
          // Already stopped
        }
      });
      this.mediaStream = null;
    }
  }
}
