/**
 * MOSAIRA Developer & BYOK Key Management Service (LORIN V2)
 * Synchronizes developer API keys with server-authoritative /api/mosaira/keys endpoints
 * while preserving synchronous read access for immediate UI rendering.
 */
import { MosairaApiKey } from '../types/mosaira';
import { getAuthHeaders } from './authHeaders';

const API_KEYS_STORAGE_KEY = 'mosaira_developer_keys_v1';

export class ApiKeyService {
  private static keys: MosairaApiKey[] = [];
  private static initialized = false;

  static initialize(): void {
    if (this.initialized) return;
    this.initialized = true;
    try {
      const stored = localStorage.getItem(API_KEYS_STORAGE_KEY);
      if (stored) {
        this.keys = JSON.parse(stored).filter((key: MosairaApiKey) => key.id !== 'key_dev_101');
      } else {
        this.keys = [];
      }
    } catch {
      this.keys = [];
    }

    if (typeof window !== 'undefined') {
      this.syncFromServer().catch(() => {});
    }
  }

  private static persist(): void {
    try {
      localStorage.setItem(API_KEYS_STORAGE_KEY, JSON.stringify(this.keys));
    } catch {}
  }

  static async syncFromServer(): Promise<MosairaApiKey[]> {
    if (typeof window === 'undefined') return this.getKeys();
    try {
      const res = await fetch('/api/mosaira/keys', { headers: await getAuthHeaders() });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.keys)) {
          this.keys = data.keys;
          this.persist();
        }
      } else {
        this.keys = [];
        this.persist();
      }
    } catch {
      this.keys = [];
      this.persist();
    }
    return this.getKeys();
  }

  static getKeys(): MosairaApiKey[] {
    if (this.keys.length === 0) this.initialize();
    return [...this.keys];
  }

  static async generateKeyOnServer(name: string, rateLimitRpm = 60): Promise<{ apiKey: MosairaApiKey; fullKey: string }> {
    const res = await fetch('/api/mosaira/keys', {
      method: 'POST',
      headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ name: name.trim() || 'Default Developer Key', rateLimitRpm })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Developer key creation was rejected.');
    await this.syncFromServer();
    return data;
  }

  static async revokeKey(id: string): Promise<boolean> {
    const res = await fetch(`/api/mosaira/keys/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: await getAuthHeaders()
    });
    if (!res.ok) return false;
    await this.syncFromServer();
    return true;
  }
}

ApiKeyService.initialize();
