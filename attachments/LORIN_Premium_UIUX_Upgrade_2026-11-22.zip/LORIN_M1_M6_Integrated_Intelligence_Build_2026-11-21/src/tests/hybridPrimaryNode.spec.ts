import { describe, it, expect, beforeEach } from 'vitest';
import {
  APPROVED_NODE_COMMAND_SPECS,
  OptionalSecureLANAdapter,
  PrimaryNodeRuntimeEngine,
  TailscaleNetworkAdapter,
  decryptLocalPayload,
  encryptLocalPayload
} from '../../serverPrimaryNode';
import { DeviceCenterService } from '../services/deviceCenterService';
import { ChatMessage, PrimaryNodeTelemetry } from '../types/lorin';

describe('LORIN Hybrid Personal AI Server, Private Network & Multi-Device Synchronization Suite (Tests 1–10)', () => {
  let nodeRuntime: PrimaryNodeRuntimeEngine;

  beforeEach(() => {
    nodeRuntime = new PrimaryNodeRuntimeEngine();
    nodeRuntime.setLifecycleState('RUNNING', 'owner_uid_1');
  });

  it('Test 1 — Laptop Node Startup, Real Telemetry & Encrypted SQLite Local Persistence', async () => {
    // Verify AES-256-GCM local payload encryption roundtrip
    const secretPayload = JSON.stringify({ vaultKey: 'lorin_private_record', rev: 4 });
    const ciphertext = encryptLocalPayload(secretPayload);
    expect(ciphertext.split(':')).toHaveLength(3);
    expect(ciphertext).not.toContain('lorin_private_record');
    expect(decryptLocalPayload(ciphertext)).toBe(secretPayload);

    // Verify Primary Node starts in RUNNING state and measures real OS metrics
    expect(nodeRuntime.getLifecycleState()).toBe('RUNNING');
    const telemetry = await nodeRuntime.getTelemetry();
    expect(telemetry.nodeId).toMatch(/^node_laptop_/);
    expect(telemetry.lifecycleState).toBe('RUNNING');
    expect(telemetry.cpuCount).toBeGreaterThan(0);
    expect(telemetry.memoryTotalMb).toBeGreaterThan(0);
    expect(telemetry.localDatabaseEngine).toBe('SQLITE_ENCRYPTED_LOCAL');

    // Verify lifecycle transitions (SLEEP -> RUNNING -> STOPPED -> RUNNING)
    expect(nodeRuntime.setLifecycleState('SLEEPING', 'owner_uid_1').currentState).toBe('SLEEPING');
    expect(nodeRuntime.setLifecycleState('RUNNING', 'owner_uid_1').currentState).toBe('RUNNING');
    expect(nodeRuntime.setLifecycleState('STOPPED', 'owner_uid_1').currentState).toBe('STOPPED');
    expect(nodeRuntime.setLifecycleState('RUNNING', 'owner_uid_1').currentState).toBe('RUNNING');

    expect(nodeRuntime.setAutoStartOnBoot(true)).toBe(true);
  });

  it('Test 2 — Private Network Connection (Tailscale Serve Validation & HTTPS-Only LAN Enforcement)', async () => {
    const tailscale = new TailscaleNetworkAdapter();
    const lan = new OptionalSecureLANAdapter();

    // Reject plain HTTP on Tailscale
    const httpTailscale = tailscale.setConfiguredEndpoint('http://lorin-laptop.tailnet.ts.net');
    expect(httpTailscale.valid).toBe(false);

    // Block Tailscale Funnel public exposure
    const funnelAttempt = tailscale.setConfiguredEndpoint('https://lorin-laptop.funnel.ts.net');
    expect(funnelAttempt.valid).toBe(false);
    expect(funnelAttempt.error).toContain('Funnel');

    // Accept valid private Tailscale Serve HTTPS URL
    const validTailscale = tailscale.setConfiguredEndpoint('https://lorin-laptop.tail99a.ts.net');
    expect(validTailscale.valid).toBe(true);

    const netStatus = await tailscale.probeRealTailscaleCli();
    expect(netStatus.funnelEnabled).toBe(false);
    expect(netStatus.serveHttpsEndpoint).toBe('https://lorin-laptop.tail99a.ts.net');

    // Reject plain HTTP on LAN fallback
    const insecureLan = lan.configureLanHttpsEndpoint('http://192.168.1.50:3000');
    expect(insecureLan.valid).toBe(false);
    expect(insecureLan.error).toContain('HTTPS');

    // Accept valid HTTPS LAN fallback
    const secureLan = lan.configureLanHttpsEndpoint('https://192.168.1.50:8443');
    expect(secureLan.valid).toBe(true);
    const lanProbe = await lan.probeStatus();
    expect(lanProbe.reachable).toBe(true);
    expect(lanProbe.endpoint).toBe('https://192.168.1.50:8443');
  });

  it('Test 3 — QR Code Pairing (Single-Use, Zero Embedded Secrets, Immediate Device Center Registration)', () => {
    const challenge = nodeRuntime.createPairingChallenge({
      ownerUid: 'owner_uid_1',
      proposedDeviceName: 'Joseph iPhone 16 Pro',
      targetDeviceType: 'mobile_phone',
      ttlMs: 300_000
    });

    expect(challenge.challengeId).toMatch(/^pair_/);
    expect(challenge.oneTimeCode).toHaveLength(8);
    expect(challenge.status).toBe('PENDING');

    // Ensure QR payload never contains permanent secrets or service account keys
    expect(challenge.qrPayloadString).not.toContain('PRIVATE_KEY');
    expect(challenge.qrPayloadString).not.toContain('GEMINI_API_KEY');
    expect(challenge.qrPayloadString).not.toContain('TAILSCALE_AUTHKEY');

    // Redeem challenge once
    const redeemRes = nodeRuntime.redeemPairingChallenge({
      challengeId: challenge.challengeId,
      oneTimeCode: challenge.oneTimeCode,
      actorUid: 'owner_uid_1',
      deviceId: 'dev_iphone_16_pro',
      deviceName: 'Joseph iPhone 16 Pro',
      deviceType: 'mobile_phone',
      platformSummary: 'iOS 18 PWA',
      connectionType: 'TAILSCALE',
      autoApproveForOwner: true
    });

    expect(redeemRes.success).toBe(true);
    expect(redeemRes.device).toBeDefined();
    expect(redeemRes.device?.authorizationStatus).toBe('APPROVED');
    expect(redeemRes.device?.connectionState).toBe('online');

    const allDevices = nodeRuntime.listDevicesForUser('owner_uid_1', true);
    expect(allDevices.some(d => d.deviceName === 'Joseph iPhone 16 Pro')).toBe(true);
  });

  it('Test 4 — Multi-Device Conversation Sync (Append-Only Deduplicated Merge Without Overwrites)', () => {
    // Ensure a paired mobile device is enrolled for owner_uid_1
    const challenge = nodeRuntime.createPairingChallenge({
      ownerUid: 'owner_uid_1',
      proposedDeviceName: 'Sync Mobile Phone',
      targetDeviceType: 'mobile_phone'
    });
    nodeRuntime.redeemPairingChallenge({
      challengeId: challenge.challengeId,
      oneTimeCode: challenge.oneTimeCode,
      actorUid: 'owner_uid_1',
      deviceId: 'dev_mobile_sync_phone',
      deviceName: 'Sync Mobile Phone',
      deviceType: 'mobile_phone',
      platformSummary: 'iOS PWA',
      autoApproveForOwner: true
    });

    const convId = `conv_sync_${Date.now()}`;
    const laptopMsg: ChatMessage = {
      id: 'msg_laptop_01',
      role: 'user',
      content: 'Start architecture review on laptop',
      timestamp: 1000,
      conversationId: convId
    };
    const mobileMsg: ChatMessage = {
      id: 'msg_mobile_02',
      role: 'user',
      content: 'Follow up question sent from mobile PWA over Tailscale',
      timestamp: 2000,
      conversationId: convId
    };

    // Laptop syncs first message
    const sync1 = nodeRuntime.syncConversationMessages({
      conversationId: convId,
      userId: 'owner_uid_1',
      title: 'Hybrid Architecture Thread',
      projectId: 'proj_lorin_core',
      messages: [laptopMsg],
      deviceId: 'dev_primary_laptop_node'
    });
    expect(sync1.success).toBe(true);
    expect(sync1.revision).toBeGreaterThanOrEqual(1);
    expect(sync1.conversation?.messages).toHaveLength(1);

    // Mobile syncs second message (append-only merge preserves laptop message)
    const sync2 = nodeRuntime.syncConversationMessages({
      conversationId: convId,
      userId: 'owner_uid_1',
      title: 'Hybrid Architecture Thread',
      projectId: 'proj_lorin_core',
      messages: [mobileMsg],
      deviceId: 'dev_mobile_sync_phone'
    });
    expect(sync2.success).toBe(true);
    expect(sync2.revision!).toBeGreaterThan(sync1.revision!);
    expect(sync2.conversation?.messages).toHaveLength(2);
    expect(sync2.conversation?.messages.map(m => m.id)).toEqual(['msg_laptop_01', 'msg_mobile_02']);

    // Re-syncing duplicate message IDs does not create duplicates
    const sync3 = nodeRuntime.syncConversationMessages({
      conversationId: convId,
      userId: 'owner_uid_1',
      title: 'Hybrid Architecture Thread',
      projectId: 'proj_lorin_core',
      messages: [laptopMsg, mobileMsg],
      deviceId: 'dev_primary_laptop_node'
    });
    expect(sync3.conversation?.messages).toHaveLength(2);
  });

  it('Test 5 & Test 6 — Voice/Vision Capability Routing & Node Offline Behavior Matrix', () => {
    const runningTelemetry: PrimaryNodeTelemetry = {
      nodeId: 'node_laptop_test',
      nodeName: 'lorin-laptop',
      hostPlatform: 'linux',
      hostArch: 'x64',
      nodeVersion: '2.4.0-primary-node',
      lifecycleState: 'RUNNING',
      bindAddress: '127.0.0.1',
      bindPort: 3000,
      startedAt: Date.now() - 120_000,
      uptimeSeconds: 120,
      lastHeartbeatAt: Date.now(),
      autoStartOnBootEnabled: true,
      cpuCount: 8,
      loadAvg1m: 0.4,
      memoryUsedMb: 8192,
      memoryTotalMb: 16384,
      memoryUsagePercent: 50,
      localDatabaseEngine: 'SQLITE_ENCRYPTED_LOCAL',
      localDatabasePath: '/tmp/test.sqlite',
      localDatabaseSizeBytes: 4096,
      services: {
        coreApi: 'RUNNING',
        aiOrchestrator: 'RUNNING',
        ollamaLocal: 'OFFLINE',
        knowledgeVaultIndex: 'READY',
        syncEngine: 'ACTIVE',
        deviceManager: 'ACTIVE'
      },
      ollamaStatus: {
        reachable: false,
        endpoint: 'http://127.0.0.1:11434',
        availableModels: [],
        lastCheckedAt: Date.now()
      },
      localKnowledgeStats: {
        indexedDocumentsCount: 5,
        indexedChunksCount: 20,
        localOnlyFilesCount: 2,
        lastIndexedAt: Date.now()
      }
    };

    // Mode 1: Both Cloud and Node available
    const mode1 = DeviceCenterService.computeHybridAvailabilityMode(runningTelemetry, true);
    expect(mode1).toBe('CLOUD_AND_NODE_AVAILABLE');
    expect(DeviceCenterService.routeCapability('VOICE_WEB_SPEECH_API', mode1, runningTelemetry).available).toBe(true);
    expect(DeviceCenterService.routeCapability('VISION_CAMERA_SNAPSHOT', mode1, runningTelemetry).available).toBe(true);
    expect(DeviceCenterService.routeCapability('PRIMARY_NODE_SQLITE_VAULT', mode1, runningTelemetry).available).toBe(true);

    // Mode 2: Primary Laptop Node stopped / offline while Cloud is online
    const stoppedTelemetry: PrimaryNodeTelemetry = {
      ...runningTelemetry,
      lifecycleState: 'STOPPED'
    };
    const mode2 = DeviceCenterService.computeHybridAvailabilityMode(stoppedTelemetry, true);
    expect(mode2).toBe('CLOUD_ONLY_NODE_UNAVAILABLE');

    const ollamaWhenNodeStopped = DeviceCenterService.routeCapability('LOCAL_OLLAMA_INFERENCE', mode2, stoppedTelemetry);
    expect(ollamaWhenNodeStopped.available).toBe(false);
    expect(ollamaWhenNodeStopped.reason).toContain('Primary Laptop Node is offline or stopped');

    const cloudWhenNodeStopped = DeviceCenterService.routeCapability('CLOUD_AI_INFERENCE', mode2, stoppedTelemetry);
    expect(cloudWhenNodeStopped.available).toBe(true);

    // Mode 3: Node available over LAN/Tailscale, Internet offline
    const mode3 = DeviceCenterService.computeHybridAvailabilityMode(runningTelemetry, false);
    expect(mode3).toBe('NODE_ONLY_INTERNET_UNAVAILABLE');
    expect(DeviceCenterService.routeCapability('PRIMARY_NODE_SQLITE_VAULT', mode3, runningTelemetry).available).toBe(true);
    expect(DeviceCenterService.routeCapability('CLOUD_AI_INFERENCE', mode3, runningTelemetry).available).toBe(false);

    // Mode 4: Both unavailable (cached shell)
    const mode4 = DeviceCenterService.computeHybridAvailabilityMode(stoppedTelemetry, false);
    expect(mode4).toBe('BOTH_UNAVAILABLE_CACHED_SHELL');
  });

  it('Test 7 — Node Outbox Queue & Deduplication on Offline Updates', () => {
    const item1 = DeviceCenterService.enqueueOutboxItem({
      entityType: 'conversation',
      entityId: 'conv_offline_test',
      action: 'APPEND_MESSAGE',
      payload: { conversationId: 'conv_offline_test', messages: [{ id: 'm1', content: 'first' }] }
    });
    expect(item1.entityId).toBe('conv_offline_test');

    // Enqueueing another update for the same entityId deduplicates in place
    DeviceCenterService.enqueueOutboxItem({
      entityType: 'conversation',
      entityId: 'conv_offline_test',
      action: 'APPEND_MESSAGE',
      payload: { conversationId: 'conv_offline_test', messages: [{ id: 'm1', content: 'first' }, { id: 'm2', content: 'second' }] }
    });

    const queue = DeviceCenterService.getOutboxQueue().filter(q => q.entityId === 'conv_offline_test');
    expect(queue).toHaveLength(1);
    expect((queue[0].payload.messages as any[]).length).toBe(2);
  });

  it('Test 8 — Device Revocation Immediately Blocks Node Access & Heartbeats', () => {
    const challenge = nodeRuntime.createPairingChallenge({
      ownerUid: 'owner_uid_1',
      proposedDeviceName: 'Temporary Tablet',
      targetDeviceType: 'tablet'
    });

    const enrolled = nodeRuntime.redeemPairingChallenge({
      challengeId: challenge.challengeId,
      oneTimeCode: challenge.oneTimeCode,
      actorUid: 'owner_uid_1',
      deviceId: 'dev_temp_tablet',
      deviceName: 'Temporary Tablet',
      deviceType: 'tablet',
      platformSummary: 'iPadOS',
      autoApproveForOwner: true
    });

    const devId = enrolled.device!.deviceId;
    expect(nodeRuntime.verifyDeviceAccess(devId, 'owner_uid_1').allowed).toBe(true);

    // System Owner revokes the device
    const revokeRes = nodeRuntime.updateDeviceStatusByOwner({
      deviceId: devId,
      action: 'REVOKE'
    });
    expect(revokeRes.success).toBe(true);
    expect(revokeRes.device?.authorizationStatus).toBe('REVOKED');
    expect(revokeRes.device?.connectionState).toBe('revoked');

    // Verify revoked device is blocked from node access and heartbeats
    const checkAfterRevoke = nodeRuntime.verifyDeviceAccess(devId, 'owner_uid_1');
    expect(checkAfterRevoke.allowed).toBe(false);
    expect(checkAfterRevoke.code).toBe('DEVICE_REVOKED');

    const heartbeatAfterRevoke = nodeRuntime.recordDeviceHeartbeat({
      deviceId: devId,
      actorUid: 'owner_uid_1'
    });
    expect(heartbeatAfterRevoke.success).toBe(false);
    expect(heartbeatAfterRevoke.message).toContain('revoked');
  });

  it('Test 9 — Unauthorized Access Protection (Replay, Wrong Code, Cross-User & Primary Node Deletion Protection)', () => {
    const challenge = nodeRuntime.createPairingChallenge({
      ownerUid: 'owner_uid_1',
      proposedDeviceName: 'Phone Test',
      targetDeviceType: 'mobile_phone'
    });

    // 1. Cross-user redemption attempt must fail
    const crossUserAttempt = nodeRuntime.redeemPairingChallenge({
      challengeId: challenge.challengeId,
      oneTimeCode: challenge.oneTimeCode,
      actorUid: 'intruder_uid_999',
      deviceId: 'dev_intruder',
      deviceName: 'Intruder Phone',
      deviceType: 'mobile_phone',
      platformSummary: 'Android'
    });
    expect(crossUserAttempt.success).toBe(false);
    expect(crossUserAttempt.code).toBe('CROSS_USER_PAIRING_FORBIDDEN');

    // 2. Wrong pairing code must fail
    const wrongCodeAttempt = nodeRuntime.redeemPairingChallenge({
      challengeId: challenge.challengeId,
      oneTimeCode: 'ZZZZ9999',
      actorUid: 'owner_uid_1',
      deviceId: 'dev_phone_test',
      deviceName: 'Phone Test',
      deviceType: 'mobile_phone',
      platformSummary: 'Android'
    });
    expect(wrongCodeAttempt.success).toBe(false);
    expect(wrongCodeAttempt.code).toBe('INVALID_ONE_TIME_CODE');

    // 3. Valid redemption succeeds
    const validAttempt = nodeRuntime.redeemPairingChallenge({
      challengeId: challenge.challengeId,
      oneTimeCode: challenge.oneTimeCode,
      actorUid: 'owner_uid_1',
      deviceId: 'dev_phone_test',
      deviceName: 'Phone Test',
      deviceType: 'mobile_phone',
      platformSummary: 'Android',
      autoApproveForOwner: true
    });
    expect(validAttempt.success).toBe(true);

    // 4. Replay of already-redeemed challenge must fail
    const replayAttempt = nodeRuntime.redeemPairingChallenge({
      challengeId: challenge.challengeId,
      oneTimeCode: challenge.oneTimeCode,
      actorUid: 'owner_uid_1',
      deviceId: 'dev_phone_clone',
      deviceName: 'Phone Clone',
      deviceType: 'mobile_phone',
      platformSummary: 'Android'
    });
    expect(replayAttempt.success).toBe(false);
    expect(replayAttempt.code).toBe('CHALLENGE_ALREADY_CONSUMED');

    // 5. Primary Laptop Node cannot be revoked or deleted
    expect(
      nodeRuntime.updateDeviceStatusByOwner({
        deviceId: 'dev_primary_laptop_node',
        action: 'REVOKE'
      }).success
    ).toBe(false);
    expect(nodeRuntime.removeDevice('dev_primary_laptop_node').success).toBe(false);
  });

  it('Test 10 — Controlled Command Registry Security (Rejects Arbitrary Shell Commands & Enforces Owner Approval)', async () => {
    expect(APPROVED_NODE_COMMAND_SPECS.length).toBe(5);

    // 1. Arbitrary shell command string is rejected
    const arbitraryAttempt = await nodeRuntime.executeApprovedCommand({
      commandId: 'rm -rf / && powershell -EncodedCommand xyz',
      principalId: 'owner_uid_1',
      deviceId: 'dev_primary_laptop_node',
      isSystemOwner: true,
      ownerApprovalVerified: false
    });
    expect(arbitraryAttempt.httpStatus).toBe(403);
    expect(arbitraryAttempt.result.status).toBe('DENIED');
    expect(arbitraryAttempt.result.outputSummary).toContain('not in the approved');

    // 2. High-impact allowlisted command ('project_workspace_verify') requires a server-verified approval
    const unapprovedVerify = await nodeRuntime.executeApprovedCommand({
      commandId: 'project_workspace_verify',
      principalId: 'owner_uid_1',
      deviceId: 'dev_primary_laptop_node',
      isSystemOwner: true,
      ownerApprovalVerified: false
    });
    expect(unapprovedVerify.httpStatus).toBe(202);
    expect(unapprovedVerify.result.status).toBe('AWAITING_APPROVAL');

    // 3. Approved allowlisted command executes cleanly and returns real output
    const approvedProbe = await nodeRuntime.executeApprovedCommand({
      commandId: 'system_memory_probe',
      principalId: 'owner_uid_1',
      deviceId: 'dev_primary_laptop_node',
      isSystemOwner: true,
      ownerApprovalVerified: false
    });
    expect(approvedProbe.httpStatus).toBe(200);
    expect(approvedProbe.result.status).toBe('COMPLETED');
    expect(approvedProbe.result.executionId).toMatch(/^cmd_exec_/);
    expect(approvedProbe.result.structuredData?.cpuCount).toBeGreaterThan(0);
  });

  it('Test 11 — 12-Stage Ordered Primary Node Startup Sequence (Section 3.2)', async () => {
    const { executeOrderedStartupSequence } = await import('../../lorin-node/src/core/node-runtime');
    const startupResult = await executeOrderedStartupSequence();

    expect(startupResult.steps).toHaveLength(12);
    expect(startupResult.steps[0].name).toBe('Host Environment Inspection');
    expect(startupResult.steps[1].name).toBe('Primary Node Lifecycle');
    expect(startupResult.steps[2].name).toBe('Load Configuration');
    expect(startupResult.steps[3].name).toBe('Initialize Local Database');
    expect(startupResult.steps[4].name).toBe('Initialize Security Subsystem');
    expect(startupResult.steps[5].name).toBe('Check Network Interfaces');
    expect(startupResult.steps[6].name).toBe('Check Private Network');
    expect(startupResult.steps[7].name).toBe('Check Firebase Connection');
    expect(startupResult.steps[8].name).toBe('Check Local Ollama Daemon');
    expect(startupResult.steps[9].name).toBe('Initialize AI Provider Router');
    expect(startupResult.steps[10].name).toBe('Initialize Knowledge Services');
    expect(startupResult.steps[11].name).toBe('Initialize Synchronization & Finalize');

    // No step should have failed fatally
    expect(startupResult.allPassed).toBe(true);
  });

  it('Test 12 — Centralized System Health Center & Auto-Reconnect Watcher Lifecycle (Sections 4 & 13)', () => {
    // 1. Verify Auto-Reconnect Watcher registers clean lifecycle handlers and unmounts cleanly
    let callbackInvoked = false;
    const cleanup = DeviceCenterService.startAutoReconnectWatcher({
      onOutboxFlushed: () => {
        callbackInvoked = true;
      }
    });

    expect(typeof cleanup).toBe('function');
    cleanup(); // Dispose safely without leaking timers or listeners
    expect(callbackInvoked).toBe(false);

    // 2. Verify System Health Matrix data structure
    expect(typeof DeviceCenterService.getSystemHealthMatrix).toBe('function');
  });
});

