/**
 * Phase 1 public/private isolation tests.
 * Unauthenticated callers must not reach Lauren private inference or policy surfaces.
 */
import { describe, it, expect } from 'vitest';

const BASE = process.env.TEST_BASE_URL || 'http://127.0.0.1:3000';

async function tryFetch(path: string, init?: RequestInit): Promise<{ status: number; body: any }> {
  try {
    const res = await fetch(`${BASE}${path}`, init);
    let body: any = null;
    try {
      body = await res.json();
    } catch {
      body = null;
    }
    return { status: res.status, body };
  } catch (err: any) {
    return { status: 0, body: { error: err.message, blocked: true } };
  }
}

describe('Public/private isolation (Lauren private API)', () => {
  it('rejects unauthenticated Gemini inference', async () => {
    const { status, body } = await tryFetch('/api/gemini/infer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: 'isolation probe' })
    });
    if (status === 0) {
      expect(body.blocked).toBe(true);
      return;
    }
    expect(status).toBe(401);
    expect(String(body?.error || '')).toMatch(/auth/i);
  });

  it('rejects forged OWNER principal on policy approve without token', async () => {
    const { status } = await tryFetch('/api/policy/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        approvalId: 'fake',
        principal: {
          id: 'attacker',
          email: 'owner@example.test',
          role: 'OWNER',
          authenticated: true
        }
      })
    });
    if (status === 0) return;
    expect(status).toBe(401);
  });

  it('rejects unauthenticated policy approvals listing', async () => {
    const { status } = await tryFetch('/api/policy/approvals');
    if (status === 0) return;
    expect(status).toBe(401);
  });

  it('rejects unauthenticated audit listing', async () => {
    const { status } = await tryFetch('/api/policy/audits');
    if (status === 0) return;
    expect(status).toBe(401);
  });

  it('health endpoint does not leak owner email', async () => {
    const { status, body } = await tryFetch('/api/health');
    if (status === 0) return;
    expect(status).toBe(200);
    expect(JSON.stringify(body)).not.toMatch(/@gmail\.com/i);
    expect(body.ownerAuthority).toBeUndefined();
  });
});
