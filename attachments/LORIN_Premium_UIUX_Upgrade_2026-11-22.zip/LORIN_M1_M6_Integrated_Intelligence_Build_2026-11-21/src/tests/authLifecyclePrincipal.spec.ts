import { describe, expect, it } from 'vitest';
import { createUnauthenticatedPrincipal } from '../services/authLifecycle';

describe('unauthenticated principal', () => {
  it('starts with no authentication or privileged scopes', () => {
    const principal = createUnauthenticatedPrincipal();
    expect(principal.authenticated).toBe(false);
    expect(principal.canonicalRole).toBe('RESTRICTED');
    expect(principal.role).toBe('GUEST');
    expect(principal.scopes).not.toContain('*');
    expect(principal.scopes).toEqual(['read:public']);
  });
});
