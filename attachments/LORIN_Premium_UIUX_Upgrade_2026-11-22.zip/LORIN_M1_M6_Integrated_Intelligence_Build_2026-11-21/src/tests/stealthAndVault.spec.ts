import { describe, it, expect, beforeEach } from 'vitest';

// Node environment mock for localStorage and document
if (typeof localStorage === 'undefined') {
  let store: Record<string, string> = {};
  (globalThis as any).localStorage = {
    getItem: (key: string) => (key in store ? store[key] : null),
    setItem: (key: string, val: string) => { store[key] = String(val); },
    removeItem: (key: string) => { delete store[key]; },
    clear: () => { store = {}; }
  };
}

if (typeof document === 'undefined') {
  (globalThis as any).document = {
    title: 'MOSAIRA Ecosystem',
    head: { appendChild: () => {} },
    querySelector: () => null,
    createElement: () => ({ rel: '', href: '' })
  };
}

import { StealthService } from '../services/stealthService';
import { LaurenVaultService } from '../services/laurenVaultService';
import { MosairaLabService } from '../services/mosairaLabService';

describe('StealthService Anti-Detection & Favicon Protection', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('correctly toggles stealth mode state and persists to localStorage', () => {
    expect(StealthService.isStealthEnabled()).toBe(false);

    StealthService.setStealthMode(true);
    expect(StealthService.isStealthEnabled()).toBe(true);
    expect(localStorage.getItem('lorin_stealth_mode_v1')).toBe('true');

    StealthService.setStealthMode(false);
    expect(StealthService.isStealthEnabled()).toBe(false);
    expect(localStorage.getItem('lorin_stealth_mode_v1')).toBe('false');
  });

  it('notifies subscribers on stealth mode state change', () => {
    let notifiedState: boolean | null = null;
    const unsub = StealthService.subscribe((enabled) => {
      notifiedState = enabled;
    });

    StealthService.setStealthMode(true);
    expect(notifiedState).toBe(true);

    StealthService.setStealthMode(false);
    expect(notifiedState).toBe(false);

    unsub();
  });
});

describe('Lauren Private Knowledge Vault & Citations', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('provides private documents with confidentiality levels', () => {
    const docs = LaurenVaultService.getDocuments();
    expect(docs.length).toBeGreaterThanOrEqual(2);
    expect(docs[0].confidentialLevel).toBe('PROJECT_SECRET');
  });

  it('performs private RAG and returns transparent citations with reasonUsed', () => {
    const res = LaurenVaultService.queryPrivateKnowledge('zero-trust policy engine directives');
    expect(res.citations.length).toBeGreaterThan(0);
    expect(res.citations[0].docTitle).toBe('Master Architecture & Security Directives');
    expect(res.citations[0].similarityScore).toBeGreaterThan(0.7);
    expect(res.citations[0].reasonUsed).toContain('Matched key query terms');
    expect(res.answer).toContain('Master Architecture & Security Directives');
  });

  it('exports encrypted backup with valid checksum', () => {
    const json = LaurenVaultService.exportEncryptedBackup();
    const parsed = JSON.parse(json);
    expect(parsed.vaultVersion).toBe('2.0.0');
    expect(parsed.checksum).toMatch(/^sha256-verified-[a-f0-9]{16}$/);
    expect(Array.isArray(parsed.documents)).toBe(true);
  });
});

describe('MOSAIRA AI Lab 7-Stage Pipeline & Model Registry', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('executes 7-stage dataset processing pipeline with PII sanitization and deduplication', async () => {
    const datasets = MosairaLabService.getDatasets();
    expect(datasets.length).toBeGreaterThan(0);

    const job = await MosairaLabService.runPipeline(datasets[0].id);
    expect(job.status).toBe('COMPLETED');
    expect(job.stages.length).toBe(7);
    expect(job.stages.every(s => s.status === 'COMPLETED')).toBe(true);
    expect(job.piiEntitiesRedacted).toBeGreaterThan(0);
    expect(job.totalChunks).toBeGreaterThan(0);
  });

  it('promotes and rolls back models in model registry', () => {
    const models = MosairaLabService.getRegisteredModels();
    expect(models.length).toBeGreaterThan(0);
    const target = models[0];

    const initialVersion = target.version;
    expect(target.rollbackVersion).toBeDefined();

    MosairaLabService.rollbackModel(target.id);
    const updatedModels = MosairaLabService.getRegisteredModels();
    const updated = updatedModels.find(m => m.id === target.id);
    expect(updated?.version).toBe(target.rollbackVersion);
  });
});
