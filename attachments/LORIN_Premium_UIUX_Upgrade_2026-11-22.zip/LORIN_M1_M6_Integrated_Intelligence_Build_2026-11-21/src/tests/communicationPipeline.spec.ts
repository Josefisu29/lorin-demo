import { describe, it, expect, beforeEach, vi } from 'vitest';

if (typeof localStorage === 'undefined') {
  let store: Record<string, string> = {};
  (globalThis as any).localStorage = {
    getItem: (key: string) => (key in store ? store[key] : null),
    setItem: (key: string, val: string) => { store[key] = String(val); },
    removeItem: (key: string) => { delete store[key]; },
    clear: () => { store = {}; }
  };
}

import {
  CommunicationManager,
  COMMUNICATION_STATE_MESSAGES,
  CommunicationState,
  mapCommunicationToCharacterState
} from '../services/communicationManager';
import { LiveGeminiBackend, CloudPrivacyGate } from '../services/modelBackend';
import { AudioService } from '../services/audioService';
import {
  ALLOWED_GEMINI_MODELS,
  ALLOWED_GEMINI_AUDIO_MODELS,
  ALLOWED_GEMINI_TEXT_MODELS,
  resolveConfiguredGeminiModel
} from '../../server.ts';

const ALL_NINETEEN_STATES: CommunicationState[] = [
  'idle',
  'permission_required',
  'requesting_permission',
  'initializing',
  'listening',
  'receiving_audio',
  'transcribing',
  'transcript_ready',
  'submitting',
  'connecting',
  'waiting_for_response',
  'streaming',
  'rendering',
  'speaking',
  'completed',
  'interrupted',
  'retrying',
  'error',
  'disconnected'
];

describe('LORIN Communication Pipeline, 19-State Machine & Audio Architecture Suite', () => {
  beforeEach(() => {
    localStorage.clear();
    CommunicationManager.reset('text');
    CloudPrivacyGate.setCloudContextPermitted(true);
  });

  it('1. Defines all 19 canonical CommunicationState values with human-readable status messages and 3D character mappings', () => {
    expect(ALL_NINETEEN_STATES.length).toBe(19);
    for (const state of ALL_NINETEEN_STATES) {
      expect(typeof COMMUNICATION_STATE_MESSAGES[state]).toBe('string');
      expect(COMMUNICATION_STATE_MESSAGES[state].length).toBeGreaterThan(3);
      const charState = mapCommunicationToCharacterState(state);
      expect([
        'IDLE',
        'LISTENING',
        'PROCESSING',
        'THINKING',
        'RESPONDING',
        'SPEAKING',
        'ERROR',
        'DISCONNECTED'
      ]).toContain(charState);
    }

    expect(mapCommunicationToCharacterState('listening')).toBe('LISTENING');
    expect(mapCommunicationToCharacterState('receiving_audio')).toBe('LISTENING');
    expect(mapCommunicationToCharacterState('waiting_for_response')).toBe('THINKING');
    expect(mapCommunicationToCharacterState('streaming')).toBe('RESPONDING');
    expect(mapCommunicationToCharacterState('speaking')).toBe('SPEAKING');
    expect(mapCommunicationToCharacterState('permission_required')).toBe('ERROR');
    expect(mapCommunicationToCharacterState('error')).toBe('ERROR');
    expect(mapCommunicationToCharacterState('disconnected')).toBe('DISCONNECTED');
  });

  it('2. Transitions cleanly through voice and text communication states and notifies subscribers', () => {
    const observedStates: CommunicationState[] = [];
    const unsubscribe = CommunicationManager.subscribe((snap) => {
      observedStates.push(snap.state);
    });

    CommunicationManager.transition('requesting_permission', 'voice');
    CommunicationManager.transition('listening', 'voice');
    CommunicationManager.transition('receiving_audio', 'voice');
    CommunicationManager.transition('transcribing', 'voice');
    CommunicationManager.transition('transcript_ready', 'voice');
    CommunicationManager.transition('submitting', 'voice');
    CommunicationManager.transition('connecting', 'voice');
    CommunicationManager.transition('waiting_for_response', 'voice');
    CommunicationManager.transition('streaming', 'voice');
    CommunicationManager.transition('speaking', 'voice');
    CommunicationManager.transition('completed', 'voice');

    unsubscribe();

    expect(observedStates).toEqual([
      'idle',
      'requesting_permission',
      'listening',
      'receiving_audio',
      'transcribing',
      'transcript_ready',
      'submitting',
      'connecting',
      'waiting_for_response',
      'streaming',
      'speaking',
      'completed'
    ]);

    const history = CommunicationManager.getTransitionHistory();
    expect(history.length).toBeGreaterThanOrEqual(11);
    expect(CommunicationManager.getSnapshot().state).toBe('completed');
  });

  it('3. Enforces idempotency guard against duplicate rapid message submissions', () => {
    const first = CommunicationManager.checkAndRegisterSubmission('conv_123', 'Analyze system latency');
    expect(first.allowed).toBe(true);

    const duplicate = CommunicationManager.checkAndRegisterSubmission('conv_123', '  analyze system latency  ');
    expect(duplicate.allowed).toBe(false);
    expect(duplicate.reason).toContain('Duplicate submission blocked');

    const otherConv = CommunicationManager.checkAndRegisterSubmission('conv_456', 'Analyze system latency');
    expect(otherConv.allowed).toBe(true);

    CommunicationManager.releaseSubmissionFingerprint('conv_123', 'Analyze system latency');
    const afterRelease = CommunicationManager.checkAndRegisterSubmission('conv_123', 'Analyze system latency');
    expect(afterRelease.allowed).toBe(true);
  });

  it('4. Tracks end-to-end request trace latency metrics (inputToSubmit, backendAck, TTFT, totalDuration, transcription, TTS)', () => {
    const trace = CommunicationManager.startRequestTrace({
      requestId: 'req_test_001',
      messageId: 'msg_test_001',
      conversationId: 'conv_test_001',
      mode: 'voice',
      model: 'gemini-3.8-flash',
      provider: 'Google Gemini'
    });
    expect(trace.status).toBe('in_flight');

    CommunicationManager.recordTranscriptionLatency(142);
    CommunicationManager.markSubmitted('req_test_001');
    CommunicationManager.markBackendAck('req_test_001');
    CommunicationManager.markFirstToken('req_test_001', 185);
    CommunicationManager.recordAudioStartupDelay(95);
    CommunicationManager.markCompleted('req_test_001', 'gemini-3.8-flash', 'Google Gemini');

    const lastTrace = CommunicationManager.getLastTrace();
    expect(lastTrace).not.toBeNull();
    expect(lastTrace?.requestId).toBe('req_test_001');
    expect(lastTrace?.status).toBe('completed');
    expect(lastTrace?.ttftMs).toBe(185);
    expect(lastTrace?.transcriptionDurationMs).toBe(142);
    expect(lastTrace?.audioStartupDelayMs).toBe(95);
    expect(typeof lastTrace?.totalDurationMs).toBe('number');
  });

  it('5. Exports gemini-3.5-transcribe and gemini-3.8-flash-lite-tts in ALLOWED_GEMINI_AUDIO_MODELS while keeping text default resolution strictly on ALLOWED_GEMINI_TEXT_MODELS', () => {
    expect(ALLOWED_GEMINI_AUDIO_MODELS).toContain('gemini-3.5-transcribe');
    expect(ALLOWED_GEMINI_AUDIO_MODELS).toContain('gemini-3.8-flash-lite-tts');
    expect(ALLOWED_GEMINI_MODELS).toEqual([
      'gemini-3.8-flash',
      'gemini-3.1-flash-lite',
      'gemini-3.1-flash-lite-image'
    ]);
    expect(ALLOWED_GEMINI_TEXT_MODELS).toContain('gemini-3.8-flash');

    expect(resolveConfiguredGeminiModel('gemini-3.5-transcribe')).toBe('gemini-3.8-flash');
    expect(resolveConfiguredGeminiModel('gemini-3.1-flash-lite')).toBe('gemini-3.1-flash-lite');
  });

  it('6. Prevents LiveGeminiBackend.inferStream from issuing a duplicate infer() call on 401/503 HTTP errors or user AbortError', async () => {
    const backend = new LiveGeminiBackend();
    const inferSpy = vi.spyOn(backend, 'infer');

    const originalFetch = globalThis.fetch;
    globalThis.fetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: async () => ({
        error: 'Authentication required before invoking private LORIN intelligence.',
        errorInfo: { code: 'AUTH_REQUIRED' }
      })
    } as any);

    try {
      const report = await backend.inferStream(
        'Test unauthorized stream',
        () => {},
        undefined,
        undefined,
        { requestId: 'req_unauth_test' }
      );

      expect(report.status).toBe('FAILED');
      expect(report.rawSynthesis).toContain('Authentication required');
      expect(inferSpy).not.toHaveBeenCalled();
      expect(CommunicationManager.getSnapshot().state).toBe('error');
    } finally {
      globalThis.fetch = originalFetch;
      inferSpy.mockRestore();
    }
  });

  it('7. Persists Neural TTS preference and DSP configuration in AudioService', () => {
    expect(AudioService.isNeuralTtsEnabled()).toBe(false);
    AudioService.setNeuralTtsEnabled(true);
    expect(AudioService.isNeuralTtsEnabled()).toBe(true);
    AudioService.setNeuralTtsEnabled(false);
    expect(AudioService.isNeuralTtsEnabled()).toBe(false);

    AudioService.updateDspConfig({ highpassFreq: 120, noiseGateThreshold: 18 });
    const dsp = AudioService.getDspConfig();
    expect(dsp.highpassFreq).toBe(120);
    expect(dsp.noiseGateThreshold).toBe(18);
  });
});
