import { VerificationRunner } from '../services/verificationRunner';

const results = await VerificationRunner.runAllTests();
const passed = results.filter(result => result.status === 'PASSED');
const failed = results.filter(result => result.status === 'FAILED');
const pending = results.filter(result => result.status === 'PENDING' || result.status === 'RUNNING');

console.log(`Verification suite: ${passed.length} passed, ${failed.length} failed, ${pending.length} pending, ${results.length} total.`);

if (failed.length > 0) {
  console.error('Failed checks:');
  for (const result of failed) {
    console.error(`- ${result.name}: ${result.details}`);
  }
  process.exitCode = 1;
}

if (pending.length > 0) {
  console.warn('Pending checks:');
  for (const result of pending) {
    console.warn(`- ${result.name}: ${result.details}`);
  }
}

process.exitCode = failed.length > 0 ? 1 : 0;
setTimeout(() => process.exit(process.exitCode ?? 0), 0);
