import { PolicyEngine } from '../services/policyEngine';
import { Principal, UserRole, ActionRequest } from '../types/lorin';

export interface AuthTestResult {
  name: string;
  passed: boolean;
  details: string;
  durationMs: number;
}

export class AuthLifecycleTestSuite {
  static async runAll(): Promise<AuthTestResult[]> {
    const results: AuthTestResult[] = [];

    results.push(await this.testUnauthenticatedUserRejected());
    results.push(await this.testClientBypassFlagRejected());
    results.push(await this.testPrivilegeEscalationPrevented());
    results.push(await this.testPrincipalResetsOnSignOut());
    results.push(await this.testOwnerOnlyApprovalAuthorization());
    results.push(await this.testSingleUseTokenReplayProtection());

    return results;
  }

  /**
   * Test 1: Unauthenticated callers are strictly rejected under fail-closed policy
   */
  static async testUnauthenticatedUserRejected(): Promise<AuthTestResult> {
    const start = performance.now();
    const unauthPrincipal: Principal = {
      id: 'guest_unauthenticated',
      name: 'Guest Operator',
      email: '',
      role: 'GUEST',
      authenticated: false,
      enrolledAt: 0,
      sessionExpiresAt: 0,
      scopes: ['read:public']
    };

    const actionReq: ActionRequest = {
      id: 'act_unauth_test',
      action: 'read_audit_logs',
      resource: 'audit://events',
      description: 'Attempt to inspect audit logs without authentication',
      riskLevel: 'LOW',
      requiredScope: 'audit:read'
    };

    const evalResult = await PolicyEngine.evaluateAction(unauthPrincipal, actionReq);
    const passed = evalResult.decision === 'DENY' && 
      (evalResult.reason.toLowerCase().includes('authentication required') || evalResult.reason.toLowerCase().includes('unauthenticated'));

    return {
      name: 'Unauthenticated Request Rejection (Fail-Closed)',
      passed,
      details: passed 
        ? `Policy correctly returned DENY for unauthenticated principal: "${evalResult.reason}"`
        : `Test failed: Policy permitted unauthenticated principal with decision ${evalResult.decision}`,
      durationMs: Math.round(performance.now() - start)
    };
  }

  /**
   * Test 2: Caller-supplied user_authorized bypass flags are rejected as security violations
   */
  static async testClientBypassFlagRejected(): Promise<AuthTestResult> {
    const start = performance.now();
    const engineerPrincipal: Principal = {
      id: 'eng_usr_01',
      name: 'Test Engineer',
      email: 'engineer@lorin.dev',
      role: 'ENGINEER',
      authenticated: true,
      enrolledAt: Date.now() - 3600000,
      sessionExpiresAt: Date.now() + 3600000,
      scopes: ['code:read', 'chat:write']
    };

    const actionReq: ActionRequest = {
      id: 'act_bypass_test',
      action: 'delete_production_database',
      resource: 'db://production/core',
      description: 'Attempted deletion using client-side user_authorized flag',
      riskLevel: 'CRITICAL',
      requiredScope: 'admin:db'
    };

    const evalResult = await PolicyEngine.evaluateAction(
      engineerPrincipal, 
      actionReq, 
      { user_authorized: true, bypass_policy: true }
    );

    const passed = evalResult.decision === 'DENY' && evalResult.reason.toLowerCase().includes('security violation');

    return {
      name: 'Caller-Supplied user_authorized Bypass Flag Rejection',
      passed,
      details: passed
        ? 'Client-side bypass flags were detected and rejected as untrusted security violations.'
        : `Test failed: Bypass flag was not rejected properly. Decision: ${evalResult.decision}`,
      durationMs: Math.round(performance.now() - start)
    };
  }

  /**
   * Test 3: Client-side role elevation to OWNER is rejected for non-owner identities
   */
  static async testPrivilegeEscalationPrevented(): Promise<AuthTestResult> {
    const start = performance.now();
    const VERIFIED_OWNER_EMAIL = 'owner@example.test';

    // Simulated role switcher validator matching App.tsx logic
    const validateRoleElevation = (candidateRole: UserRole, currentEmail: string, isAuthenticated: boolean): boolean => {
      if (candidateRole === 'OWNER') {
        return isAuthenticated && currentEmail === VERIFIED_OWNER_EMAIL;
      }
      return true;
    };

    const guestElevation = validateRoleElevation('OWNER', '', false);
    const nonOwnerElevation = validateRoleElevation('OWNER', 'attacker@example.com', true);
    const validOwnerElevation = validateRoleElevation('OWNER', VERIFIED_OWNER_EMAIL, true);

    const passed = !guestElevation && !nonOwnerElevation && validOwnerElevation;

    return {
      name: 'Client-Side Privilege Escalation Prevention',
      passed,
      details: passed
        ? 'Unverified users and arbitrary accounts are blocked from escalating to OWNER role. Only owner@example.test is permitted.'
        : 'Test failed: Unauthorized accounts were able to assume OWNER role.',
      durationMs: Math.round(performance.now() - start)
    };
  }

  /**
   * Test 4: Principal state properly resets to unauthenticated guest upon sign-out
   */
  static async testPrincipalResetsOnSignOut(): Promise<AuthTestResult> {
    const start = performance.now();

    const INITIAL_GUEST_PRINCIPAL: Principal = {
      id: 'guest_unauthenticated',
      name: 'Guest Operator',
      email: '',
      role: 'GUEST',
      authenticated: false,
      enrolledAt: 0,
      sessionExpiresAt: 0,
      scopes: ['read:public']
    };

    // Simulate an authenticated session transition -> Sign Out
    let currentPrincipal: Principal = {
      id: 'owner_session_active',
      name: 'Sample Test Owner',
      email: 'owner@example.test',
      role: 'OWNER',
      authenticated: true,
      enrolledAt: Date.now() - 500000,
      sessionExpiresAt: Date.now() + 86400000,
      scopes: ['*']
    };

    // Auth state transition callback on sign-out (Firebase user becomes null)
    const handleAuthTransition = (firebaseUser: { uid: string; email?: string | null } | null) => {
      if (!firebaseUser) {
        currentPrincipal = { ...INITIAL_GUEST_PRINCIPAL };
      }
    };

    // Execute sign-out
    handleAuthTransition(null);

    // Verify reset invariants
    const isUnauthenticated = currentPrincipal.authenticated === false;
    const isGuestRole = currentPrincipal.role === 'GUEST';
    const noWildcardScopes = !currentPrincipal.scopes.includes('*');
    const emailCleared = currentPrincipal.email === '';
    const passed = isUnauthenticated && isGuestRole && noWildcardScopes && emailCleared;

    return {
      name: 'Principal State Reset on Sign-Out',
      passed,
      details: passed
        ? 'Confirmed: Sign-out clears elevated identity, revokes wildcard scopes, and resets principal to unauthenticated GUEST.'
        : 'Test failed: Privileged state or wildcard scopes leaked across sign-out boundary.',
      durationMs: Math.round(performance.now() - start)
    };
  }

  /**
   * Test 5: Only verified owner can approve high-risk actions
   */
  static async testOwnerOnlyApprovalAuthorization(): Promise<AuthTestResult> {
    const start = performance.now();

    const engineerPrincipal: Principal = {
      id: 'eng_usr_02',
      name: 'Non-Owner Engineer',
      email: 'other@company.com',
      role: 'ENGINEER',
      authenticated: true,
      enrolledAt: Date.now(),
      sessionExpiresAt: Date.now() + 3600000,
      scopes: ['code:write']
    };

    const ownerPrincipal: Principal = {
      id: 'test_owner',
      name: 'Sample Test Owner',
      email: 'owner@example.test',
      role: 'OWNER',
      authenticated: true,
      enrolledAt: Date.now(),
      sessionExpiresAt: Date.now() + 3600000,
      scopes: ['*']
    };

    const actionReq: ActionRequest = {
      id: 'act_owner_test',
      action: 'deploy_production',
      resource: 'service://lorin-core',
      description: 'Production release',
      riskLevel: 'HIGH',
      requiredScope: 'deploy:write'
    };

    // 1. Initial evaluation creates approval record
    const evalRes = await PolicyEngine.evaluateAction(ownerPrincipal, actionReq);
    const approvalId = evalRes.approvalRecord?.id;

    if (!approvalId) {
      return {
        name: 'Owner-Only Approval Authorization',
        passed: false,
        details: 'Failed to generate approval record for high-risk action.',
        durationMs: Math.round(performance.now() - start)
      };
    }

    // 2. Engineer attempts to approve -> Must be rejected
    const engApprove = await PolicyEngine.approveAction(approvalId, engineerPrincipal);
    const engRejected = !engApprove.success;

    // 3. Owner approves -> Must succeed
    const ownerApprove = await PolicyEngine.approveAction(approvalId, ownerPrincipal);
    const ownerAccepted = ownerApprove.success;

    const passed = engRejected && ownerAccepted;

    return {
      name: 'Owner-Only Approval Authorization',
      passed,
      details: passed
        ? 'Non-owner approval attempt was rejected; verified owner approval succeeded.'
        : `Approval check failed. Engineer rejected: ${engRejected}, Owner accepted: ${ownerAccepted}`,
      durationMs: Math.round(performance.now() - start)
    };
  }

  /**
   * Test 6: Single-use execution token replay protection
   */
  static async testSingleUseTokenReplayProtection(): Promise<AuthTestResult> {
    const start = performance.now();
    const ownerPrincipal: Principal = {
      id: 'test_owner',
      name: 'Sample Test Owner',
      email: 'owner@example.test',
      role: 'OWNER',
      authenticated: true,
      enrolledAt: Date.now(),
      sessionExpiresAt: Date.now() + 3600000,
      scopes: ['*']
    };

    const actionReq: ActionRequest = {
      id: 'act_replay_test',
      action: 'purge_database',
      resource: 'db://staging_test',
      description: 'Single-use token test',
      riskLevel: 'HIGH',
      requiredScope: 'admin:db'
    };

    // Step 1: Create approval
    const step1 = await PolicyEngine.evaluateAction(ownerPrincipal, actionReq);
    const approvalId = step1.approvalRecord?.id;

    if (!approvalId) {
      return {
        name: 'Single-Use Token Replay Protection',
        passed: false,
        details: 'Failed to generate approval record.',
        durationMs: Math.round(performance.now() - start)
      };
    }

    // Step 2: Approve
    await PolicyEngine.approveAction(approvalId, ownerPrincipal);

    // Step 3: First execution consumes token -> ALLOW
    const step3 = await PolicyEngine.evaluateAction(ownerPrincipal, actionReq);
    const firstAllowed = step3.decision === 'ALLOW';

    // Step 4: Replay execution with consumed token -> Must NOT allow
    const step4 = await PolicyEngine.evaluateAction(ownerPrincipal, actionReq);
    const replayBlocked = step4.decision !== 'ALLOW';

    const passed = firstAllowed && replayBlocked;

    return {
      name: 'Single-Use Token Replay Protection',
      passed,
      details: passed
        ? 'Approval token was consumed on first execution. Immediate replay attempt was blocked.'
        : `Replay test failed. First allowed: ${firstAllowed}, Replay blocked: ${replayBlocked}`,
      durationMs: Math.round(performance.now() - start)
    };
  }
}

// Self-executable runner if executed directly via CLI
if (typeof process !== 'undefined' && process.argv && process.argv[1] && process.argv[1].includes('auth.test')) {
  AuthLifecycleTestSuite.runAll().then((results) => {
    console.log('\n========================================');
    console.log('LORIN Authentication Lifecycle Test Suite');
    console.log('========================================');
    let allPassed = true;
    for (const r of results) {
      const mark = r.passed ? '✓ PASSED' : '✗ FAILED';
      console.log(`[${mark}] ${r.name} (${r.durationMs}ms)`);
      console.log(`   Details: ${r.details}`);
      if (!r.passed) allPassed = false;
    }
    console.log('========================================');
    console.log(`Summary: ${results.filter(r => r.passed).length}/${results.length} tests passed.\n`);
    process.exit(allPassed ? 0 : 1);
  }).catch((err) => {
    console.error('Test execution error:', err);
    process.exit(1);
  });
}
