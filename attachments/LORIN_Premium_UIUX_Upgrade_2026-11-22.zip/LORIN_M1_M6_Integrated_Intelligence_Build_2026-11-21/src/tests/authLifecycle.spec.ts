import { describe, it, expect } from 'vitest';
import { AuthLifecycleTestSuite } from './authSuite';

describe('AuthLifecycleTestSuite (Vitest Integration)', () => {
  it('passes all authentication lifecycle tests', async () => {
    const results = await AuthLifecycleTestSuite.runAll();
    const failed = results.filter(r => !r.passed);

    if (failed.length > 0) {
      console.error('Failed Auth Lifecycle Tests:', failed);
    }

    expect(failed.length).toBe(0);
    expect(results.length).toBe(6);
  });
});
