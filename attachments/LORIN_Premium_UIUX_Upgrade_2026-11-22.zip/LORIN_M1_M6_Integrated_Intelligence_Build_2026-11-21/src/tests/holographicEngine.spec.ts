import { describe, it, expect, beforeEach } from 'vitest';
import {
  detectRenderingCapabilitiesSync,
  probeRenderingCapabilitiesAsync
} from '../holographic/core/RenderingCapabilities';
import {
  QualityManager,
  QUALITY_PROFILE_CONFIGS,
  HologramQualityProfile
} from '../holographic/core/QualityManager';
import { PixelStreamingAdapter } from '../holographic/streaming/PixelStreamingAdapter';
import {
  normalizeCharacterState,
  toLowerCharacterState,
  resolveExpressionForState,
  resolveLorinPresence,
  LorinCharacterState
} from '../services/lorinPresence';

describe('LORIN Holographic Digital-Human & Adaptive Experience Engine (Sections 2–20)', () => {
  beforeEach(() => {
    QualityManager.setQualityProfile('AUTO');
    PixelStreamingAdapter.updateConfig({ signallingUrl: '' });
  });

  describe('1. Rendering Capabilities & Pipeline Detection (Section 2)', () => {
    it('detects capabilities synchronously and returns a valid preferredNativeBackend', () => {
      const caps = detectRenderingCapabilitiesSync();
      expect(['WebGPU', 'WebGL2', 'WebGL1', 'SVG_Fallback', 'UnrealPixelStream']).toContain(
        caps.preferredNativeBackend
      );
      expect(typeof caps.devicePixelRatio).toBe('number');
      expect(caps.devicePixelRatio).toBeGreaterThanOrEqual(1);
      expect(typeof caps.prefersReducedMotion).toBe('boolean');
    });

    it('detects capabilities asynchronously without throwing in headless/Node test environments', async () => {
      const caps = await probeRenderingCapabilitiesAsync();
      expect(['WebGPU', 'WebGL2', 'WebGL1', 'SVG_Fallback', 'UnrealPixelStream']).toContain(
        caps.preferredNativeBackend
      );
      expect(caps.hardwareConcurrency).toBeGreaterThanOrEqual(1);
    });
  });

  describe('2. Adaptive Quality Manager & 5 Quality Profiles (Section 9)', () => {
    it('defines all 5 required quality profiles: ULTRA, HIGH, BALANCED, LOW, MOBILE', () => {
      const levels: HologramQualityProfile[] = ['ULTRA', 'HIGH', 'BALANCED', 'LOW', 'MOBILE'];
      for (const level of levels) {
        const spec = QUALITY_PROFILE_CONFIGS[level];
        expect(spec).toBeDefined();
        expect(spec.profile).toBe(level);
        expect(spec.hardwareScalingLevel).toBeGreaterThan(0);
        expect(spec.targetFps).toBeGreaterThanOrEqual(30);
      }
      expect(QUALITY_PROFILE_CONFIGS.ULTRA.enableSubsurfaceScattering).toBe(true);
      expect(QUALITY_PROFILE_CONFIGS.ULTRA.enableClearCoatEyes).toBe(true);
      expect(QUALITY_PROFILE_CONFIGS.LOW.enableShadows).toBe(false);
    });

    it('supports manual quality override and reset to automatic hardware selection', () => {
      QualityManager.setQualityProfile('ULTRA');
      expect(QualityManager.isManualOverrideActive()).toBe(true);
      expect(QualityManager.getActiveProfile().profile).toBe('ULTRA');

      QualityManager.setQualityProfile('MOBILE');
      expect(QualityManager.getActiveProfile().profile).toBe('MOBILE');

      QualityManager.setQualityProfile('AUTO');
      expect(QualityManager.isManualOverrideActive()).toBe(false);
      const autoProfile = QualityManager.getActiveProfile();
      expect(['ULTRA', 'HIGH', 'BALANCED', 'LOW', 'MOBILE']).toContain(autoProfile.profile);
    });

    it('records and clamps live FPS telemetry', () => {
      QualityManager.reportMeasuredFps(60);
      expect(QualityManager.getMeasuredFps()).toBe(60);
    });
  });

  describe('3. Unreal Engine 5.8 + MetaHuman Pixel Streaming Adapter (Section 2.2)', () => {
    it('reports truthful UNCONFIGURED status by default and never fabricates a stream URL', () => {
      const status = PixelStreamingAdapter.getStatus();
      expect(status.state).toBe('UNCONFIGURED');
      expect(status.signallingUrl).toBe('');
      expect(status.configured).toBe(false);
    });

    it('rejects non-WebSocket signalling URLs and accepts valid ws:// or wss:// URLs', async () => {
      const invalidRes = PixelStreamingAdapter.updateConfig({
        signallingUrl: 'http://invalid-url.local'
      });
      expect(invalidRes.state).toBe('ERROR');
      expect(invalidRes.lastError).toContain('ws:// or wss://');

      const validRes = PixelStreamingAdapter.updateConfig({
        signallingUrl: 'wss://metahuman.lorin.internal:8888',
        metaHumanAssetId: 'MH_LORIN_HYBRID_V58'
      });
      expect(validRes.configured).toBe(true);
      expect(validRes.state).toBe('READY_TO_CONNECT');

      PixelStreamingAdapter.updateConfig({ signallingUrl: '' });
      expect(PixelStreamingAdapter.getStatus().state).toBe('UNCONFIGURED');
    });
  });

  describe('4. Character States, Facial Expressions & Adaptive Environments (Sections 5, 7 & 8)', () => {
    it('supports all 13 canonical LorinCharacterState values in both uppercase and lowercase', () => {
      const allStates: LorinCharacterState[] = [
        'IDLE',
        'LISTENING',
        'PROCESSING',
        'THINKING',
        'SPEAKING',
        'RESPONDING',
        'RESEARCHING',
        'CODING',
        'ANALYZING',
        'VISION_ACTIVE',
        'NOTIFICATION',
        'ERROR',
        'DISCONNECTED'
      ];

      for (const st of allStates) {
        const lower = toLowerCharacterState(st);
        expect(normalizeCharacterState(lower)).toBe(st);
        expect(normalizeCharacterState(st)).toBe(st);

        const expression = resolveExpressionForState(lower);
        expect([
          'neutral',
          'attentive',
          'listening',
          'thinking',
          'speaking',
          'confident',
          'friendly',
          'serious',
          'acknowledgement',
          'concern'
        ]).toContain(expression);
      }
    });

    it('resolves all 7 adaptive environments including immersive mode and all 6 presentations', () => {
      const chatPresence = resolveLorinPresence({
        currentView: 'chat',
        isLoading: false,
        isMicActive: false,
        isCameraActive: false,
        voiceState: 'IDLE',
        videoState: 'IDLE',
        gideonActivity: 'IDLE',
        pendingApprovals: 0
      });
      expect(chatPresence.environment).toBe('conversation');
      expect(chatPresence.presentation).toBe('compact');

      const voicePresence = resolveLorinPresence({
        currentView: 'voice',
        isLoading: false,
        isMicActive: true,
        isCameraActive: false,
        voiceState: 'SPEAKING',
        videoState: 'IDLE',
        gideonActivity: 'IDLE',
        pendingApprovals: 0
      });
      expect(voicePresence.environment).toBe('voice');
      expect(voicePresence.presentation).toBe('expanded');
      expect(voicePresence.state).toBe('SPEAKING');
      expect(voicePresence.expression).toBe('speaking');

      const immersivePresence = resolveLorinPresence({
        currentView: 'chat',
        isLoading: true,
        isMicActive: false,
        isCameraActive: false,
        voiceState: 'IDLE',
        videoState: 'IDLE',
        gideonActivity: 'IDLE',
        pendingApprovals: 0,
        isImmersiveOpen: true
      });
      expect(immersivePresence.environment).toBe('immersive');
      expect(immersivePresence.presentation).toBe('full');
      expect(immersivePresence.state).toBe('THINKING');
    });
  });
});
