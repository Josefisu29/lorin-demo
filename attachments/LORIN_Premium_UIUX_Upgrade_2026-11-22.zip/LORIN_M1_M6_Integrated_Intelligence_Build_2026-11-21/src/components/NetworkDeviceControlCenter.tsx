import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity,
  Bell,
  Cloud,
  Copy,
  Cpu,
  Database,
  Laptop,
  Lock,
  Monitor,
  Network,
  Play,
  Power,
  QrCode,
  RefreshCw,
  RotateCcw,
  Server,
  Shield,
  ShieldCheck,
  Smartphone,
  Square,
  Tablet,
  Terminal,
  Trash2,
  Wifi
} from 'lucide-react';
import {
  ApprovedNodeCommandResult,
  ApprovedNodeCommandSpec,
  DeviceCapabilityScope,
  DevicePairingChallenge,
  EnrolledDeviceRecord,
  EnrolledDeviceType,
  HybridAvailabilityMode,
  PrimaryNodeTelemetry,
  Principal,
  PrivateNetworkStatus,
  isSuperAdminOrOwnerPrincipal,
  isSystemOwnerPrincipal
} from '../types/lorin';
import {
  CapabilityIdentifier,
  DeviceCenterService,
  NotificationCategoryPreferences,
  SubsystemHealthItem,
  SystemHealthMatrixResponse
} from '../services/deviceCenterService';

interface NetworkDeviceControlCenterProps {
  principal: Principal;
  onSyncConversations?: () => void;
}

type ControlCenterTab =
  | 'overview'
  | 'devices'
  | 'network'
  | 'sync'
  | 'operations'
  | 'systemHealth';

const CAPABILITY_ROUTER_LIST: { id: CapabilityIdentifier; label: string }[] = [
  { id: 'CLOUD_AUTH_FIRESTORE', label: 'Firebase Auth & Cloud Firestore' },
  { id: 'MULTI_DEVICE_CONVERSATION_SYNC', label: 'Multi-Device Conversation Sync' },
  { id: 'CLOUD_AI_INFERENCE', label: 'Cloud AI Proxy Inference' },
  { id: 'LOCAL_OLLAMA_INFERENCE', label: 'Primary Laptop Local Ollama Inference' },
  { id: 'PRIMARY_NODE_SQLITE_VAULT', label: 'Primary Node Encrypted SQLite Vault' },
  { id: 'PRIMARY_NODE_TELEMETRY', label: 'Primary Laptop Hardware Telemetry' },
  { id: 'CONTROLLED_NODE_COMMAND', label: 'Controlled Node Command Execution' },
  { id: 'VOICE_WEB_SPEECH_API', label: 'Browser Tap-to-Talk Voice Stage' },
  { id: 'VISION_CAMERA_SNAPSHOT', label: 'Browser Camera Snapshot Analysis' }
];

/**
 * Deterministic 21x21 QR-style SVG Matrix Renderer for Single-Use Pairing Payload
 */
const DeterministicQrSvg: React.FC<{ payload: string }> = ({ payload }) => {
  const grid = useMemo(() => {
    const size = 21;
    const matrix: boolean[][] = Array.from({ length: size }, () => Array(size).fill(false));

    const drawFinder = (r0: number, c0: number) => {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 7; c++) {
          const isBorder = r === 0 || r === 6 || c === 0 || c === 6;
          const isCenter = r >= 2 && r <= 4 && c >= 2 && c <= 4;
          matrix[r0 + r][c0 + c] = isBorder || isCenter;
        }
      }
    };

    drawFinder(0, 0);
    drawFinder(0, size - 7);
    drawFinder(size - 7, 0);

    for (let i = 8; i < size - 8; i++) {
      matrix[6][i] = i % 2 === 0;
      matrix[i][6] = i % 2 === 0;
    }

    let hash = 2166136261;
    for (let i = 0; i < payload.length; i++) {
      hash ^= payload.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }

    let idx = 0;
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const inFinder =
          (r < 8 && c < 8) ||
          (r < 8 && c >= size - 8) ||
          (r >= size - 8 && c < 8) ||
          r === 6 ||
          c === 6;
        if (inFinder) continue;
        const ch = payload.charCodeAt(idx % payload.length) || 1;
        const bit = ((hash ^ (ch * (r + 1) * (c + 3) + idx)) & 1) === 1;
        matrix[r][c] = bit;
        idx++;
      }
    }

    return matrix;
  }, [payload]);

  return (
    <svg
      viewBox="0 0 25 25"
      className="w-44 h-44 bg-white p-2 rounded-lg border border-slate-300 shadow-inner shrink-0"
      role="img"
      aria-label="Single-use LORIN Device Pairing QR Code"
    >
      {grid.map((row, r) =>
        row.map((cell, c) =>
          cell ? (
            <rect
              key={`${r}-${c}`}
              x={c + 2}
              y={r + 2}
              width={1}
              height={1}
              fill="#0B0F14"
            />
          ) : null
        )
      )}
    </svg>
  );
};

export const NetworkDeviceControlCenter: React.FC<NetworkDeviceControlCenterProps> = ({
  principal,
  onSyncConversations
}) => {
  const [activeTab, setActiveTab] = useState<ControlCenterTab>('overview');
  const [telemetry, setTelemetry] = useState<PrimaryNodeTelemetry | null>(null);
  const [network, setNetwork] = useState<PrivateNetworkStatus | null>(null);
  const [devices, setDevices] = useState<EnrolledDeviceRecord[]>([]);
  const [approvedCommands, setApprovedCommands] = useState<ApprovedNodeCommandSpec[]>([]);
  const [commandHistory, setCommandHistory] = useState<ApprovedNodeCommandResult[]>([]);
  const [availabilityMode, setAvailabilityMode] = useState<HybridAvailabilityMode | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [bannerMessage, setBannerMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Tailscale & LAN endpoint inputs
  const [tailscaleEndpointInput, setTailscaleEndpointInput] = useState('');
  const [lanEndpointInput, setLanEndpointInput] = useState('');

  // QR Pairing Challenge state
  const [activeChallenge, setActiveChallenge] = useState<DevicePairingChallenge | null>(null);
  const [pairingDeviceName, setPairingDeviceName] = useState('Owner Mobile PWA');
  const [pairingDeviceType, setPairingDeviceType] = useState<EnrolledDeviceType>('mobile_phone');
  const [pairingTtlSeconds, setPairingTtlSeconds] = useState(300);

  // Redeem Pairing Form
  const [redeemChallengeId, setRedeemChallengeId] = useState('');
  const [redeemCode, setRedeemCode] = useState('');
  const [redeemDeviceName, setRedeemDeviceName] = useState('Mobile Companion');
  const [redeemDeviceType, setRedeemDeviceType] = useState<EnrolledDeviceType>('mobile_phone');

  // Device Rename State
  const [renamingDeviceId, setRenamingDeviceId] = useState<string | null>(null);
  const [renameInput, setRenameInput] = useState('');

  // Controlled Node Command Approval state
  const [executingCommandId, setExecutingCommandId] = useState<string | null>(null);

  // Trusted Device Cache & Notification preferences
  const [retainTrustedCache, setRetainTrustedCache] = useState<boolean>(() =>
    DeviceCenterService.isTrustedDeviceCacheRetained()
  );
  const [notifPrefs, setNotifPrefs] = useState<NotificationCategoryPreferences>(() =>
    DeviceCenterService.getNotificationPreferences()
  );
  const [browserNotifPerm, setBrowserNotifPerm] = useState<string>(() =>
    DeviceCenterService.getBrowserNotificationPermission()
  );

  // Section 13: Centralized System Health Center State
  const [healthMatrix, setHealthMatrix] = useState<SystemHealthMatrixResponse | null>(null);
  const [healthCategoryFilter, setHealthCategoryFilter] = useState<'all' | 'core' | 'ai' | 'storage' | 'network' | 'media'>('all');
  const [isAuditingHealth, setIsAuditingHealth] = useState<boolean>(false);

  const isOwner = isSystemOwnerPrincipal(principal);
  const isPrivileged = isSuperAdminOrOwnerPrincipal(principal);
  const currentClientDeviceId = DeviceCenterService.getClientDeviceId();

  const refreshAll = useCallback(async () => {
    setIsLoading(true);
    try {
      const [statusSnap, healthSnap] = await Promise.all([
        DeviceCenterService.getNodeAndNetworkStatus(),
        DeviceCenterService.getSystemHealthMatrix()
      ]);
      if (healthSnap) {
        setHealthMatrix(healthSnap);
      }
      if (statusSnap) {
        setTelemetry(statusSnap.telemetry);
        setNetwork(statusSnap.network);
        setDevices(statusSnap.devices);
        setApprovedCommands(statusSnap.approvedCommands);
        setCommandHistory(statusSnap.commandHistory);
        setAvailabilityMode(statusSnap.availabilityMode);
        if (!tailscaleEndpointInput && statusSnap.network.tailscale.serveHttpsEndpoint) {
          setTailscaleEndpointInput(statusSnap.network.tailscale.serveHttpsEndpoint);
        }
      } else {
        const list = await DeviceCenterService.listEnrolledDevices();
        setDevices(list);
      }
    } finally {
      setIsLoading(false);
    }
  }, [tailscaleEndpointInput]);

  useEffect(() => {
    refreshAll();
    DeviceCenterService.sendDeviceHeartbeat({ state: 'online' }).catch(() => {});
    const timer = setInterval(() => {
      DeviceCenterService.sendDeviceHeartbeat({ state: 'online' }).catch(() => {});
      refreshAll();
    }, 25000);
    return () => clearInterval(timer);
  }, [refreshAll]);

  const handleLifecycleControl = async (
    action: 'START' | 'STOP' | 'RESTART' | 'SLEEP' | 'WAKE' | 'SET_AUTO_START',
    autoStartOnBoot?: boolean
  ) => {
    const res = await DeviceCenterService.controlNodeLifecycle(action, autoStartOnBoot);
    setBannerMessage({
      type: res.success ? 'success' : 'error',
      text: res.message
    });
    if (res.telemetry) {
      setTelemetry(res.telemetry);
      setAvailabilityMode(DeviceCenterService.computeHybridAvailabilityMode(res.telemetry));
    }
    await refreshAll();
  };

  const handleSaveTailscaleEndpoint = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await DeviceCenterService.configureTailscaleEndpoint(tailscaleEndpointInput);
    setBannerMessage({
      type: res.success ? 'success' : 'error',
      text: res.message
    });
    if (res.network) setNetwork(res.network);
  };

  const handleSaveLanEndpoint = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await DeviceCenterService.configureSecureLanEndpoint(lanEndpointInput);
    setBannerMessage({
      type: res.success ? 'success' : 'error',
      text: res.message
    });
    if (res.network) setNetwork(res.network);
  };

  const handleGenerateQrChallenge = async () => {
    const res = await DeviceCenterService.createPairingChallenge({
      proposedDeviceName: pairingDeviceName,
      targetDeviceType: pairingDeviceType,
      ttlMs: pairingTtlSeconds * 1000
    });
    if (res.success && res.challenge) {
      setActiveChallenge(res.challenge);
      setRedeemChallengeId(res.challenge.challengeId);
      setRedeemCode(res.challenge.oneTimeCode);
      setRedeemDeviceName(pairingDeviceName);
      setRedeemDeviceType(pairingDeviceType);
      setBannerMessage({
        type: 'info',
        text: `Generated single-use QR pairing challenge (${res.challenge.oneTimeCode}) valid for ${pairingTtlSeconds}s.`
      });
    } else {
      setBannerMessage({
        type: 'error',
        text: res.message || 'Failed to generate QR pairing challenge.'
      });
    }
  };

  const handleRedeemPairing = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await DeviceCenterService.redeemPairingChallenge({
      challengeId: redeemChallengeId.trim(),
      oneTimeCode: redeemCode.trim(),
      deviceName: redeemDeviceName.trim() || 'Companion Device',
      deviceType: redeemDeviceType,
      platformSummary: typeof navigator !== 'undefined' ? navigator.platform || 'Web PWA' : 'Web PWA',
      connectionType: network?.tailscale.backendState === 'Running' ? 'TAILSCALE' : 'CLOUD_HOSTED',
      userId: principal.id
    });
    setBannerMessage({
      type: res.success ? 'success' : 'error',
      text: res.message
    });
    if (res.success) {
      setActiveChallenge(null);
      await refreshAll();
    }
  };

  const handleDeviceAction = async (
    deviceId: string,
    action: 'APPROVE' | 'SUSPEND' | 'REVOKE' | 'RENAME' | 'UPDATE_PERMISSIONS',
    options?: {
      deviceName?: string;
      permissions?: DeviceCapabilityScope[];
      trustedCachePolicy?: 'PERSISTENT_TRUSTED' | 'CLEAR_ON_LOGOUT';
    }
  ) => {
    const res = await DeviceCenterService.manageDevice(deviceId, action, {
      ...options,
      userId: principal.id
    });
    setBannerMessage({
      type: res.success ? 'success' : 'error',
      text: res.message
    });
    setRenamingDeviceId(null);
    await refreshAll();
  };

  const handleRemoveDevice = async (deviceId: string) => {
    const res = await DeviceCenterService.removeDevice(deviceId, principal.id);
    setBannerMessage({
      type: res.success ? 'success' : 'error',
      text: res.message
    });
    await refreshAll();
  };

  const handleManualSyncNow = async () => {
    setIsLoading(true);
    try {
      const pullRes = await DeviceCenterService.pullSynchronizedConversations();
      if (onSyncConversations) onSyncConversations();
      setBannerMessage({
        type: pullRes.success ? 'success' : 'error',
        text: pullRes.success
          ? `Multi-device sync completed (${pullRes.syncedCount} conversation thread(s) verified).`
          : 'Primary Node unreachable; pending updates remain safely queued in local outbox.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExecuteCommand = async (cmd: ApprovedNodeCommandSpec) => {
    setExecutingCommandId(cmd.commandId);
    try {
      const res = await DeviceCenterService.executeApprovedNodeCommand(cmd.commandId);
      setCommandHistory(DeviceCenterService.getCommandHistory());
      setBannerMessage({
        type: res.result?.status === 'AWAITING_APPROVAL' ? 'info' : res.success ? 'success' : 'error',
        text: res.message || (res.success ? 'Command executed.' : 'Command execution failed.')
      });
      await refreshAll();
    } finally {
      setExecutingCommandId(null);
    }
  };

  const handleCopyText = (text: string, label: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
      setBannerMessage({ type: 'info', text: `Copied ${label} to clipboard.` });
    }
  };

  const syncSummary = DeviceCenterService.getSyncStatusSummary();

  const availabilityBadge = useMemo(() => {
    if (availabilityMode === null) {
      return {
        label: 'AVAILABILITY NOT VERIFIED',
        desc: 'No successful node/network status response has been received in this session yet.',
        cls: 'bg-[#17212C] border-[#283544] text-[#A2AFBF]'
      };
    }
    switch (availabilityMode) {
      case 'CLOUD_AND_NODE_AVAILABLE':
        return {
          label: 'MODE 1 · CLOUD + PRIMARY NODE ONLINE',
          desc: 'Full hybrid capability active: Firebase Cloud, Private Tailscale/Node link, and Local Ollama / Encrypted SQLite Vault.',
          cls: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
        };
      case 'CLOUD_ONLY_NODE_UNAVAILABLE':
        return {
          label: 'MODE 2 · CLOUD AVAILABLE · PRIMARY NODE OFFLINE',
          desc: 'Cloud PWA, Firebase Auth, and Cloud AI Inference are active. Local laptop Ollama and laptop-only commands are paused until the Primary Node wakes.',
          cls: 'bg-amber-500/10 border-amber-500/30 text-amber-300'
        };
      case 'NODE_ONLY_INTERNET_UNAVAILABLE':
        return {
          label: 'MODE 3 · PRIMARY NODE AVAILABLE · INTERNET OFFLINE',
          desc: 'Private LAN/Tailscale link to Primary Laptop Node is active. Local Ollama and Encrypted SQLite Vault work; cloud sync queues in outbox.',
          cls: 'bg-sky-500/10 border-sky-500/30 text-sky-300'
        };
      case 'BOTH_UNAVAILABLE_CACHED_SHELL':
      default:
        return {
          label: 'MODE 4 · OFFLINE CACHED PWA SHELL',
          desc: 'Both internet and Primary Laptop Node are unreachable. Cached conversations and drafts are accessible and queued in the local outbox.',
          cls: 'bg-rose-500/10 border-rose-500/30 text-rose-300'
        };
    }
  }, [availabilityMode]);

  const getDeviceIcon = (type: EnrolledDeviceType) => {
    switch (type) {
      case 'primary_laptop':
      case 'secondary_laptop':
        return Laptop;
      case 'mobile_phone':
        return Smartphone;
      case 'tablet':
        return Tablet;
      case 'desktop_workstation':
      default:
        return Monitor;
    }
  };

  return (
    <div className="lorin-module-page lorin-device-center flex-1 flex flex-col h-full overflow-y-auto bg-[#0B0F14] text-slate-100 p-4 sm:p-6 space-y-5">
      {/* Top Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-4 border-b border-[#283544]">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#131C26] border border-[#3A4B5F] flex items-center justify-center">
              <Network className="w-5 h-5 text-[#66E3CB]" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                LORIN NETWORK &amp; DEVICE CONTROL
              </h1>
              <p className="text-xs text-[#8796A8]">
                Hybrid Personal AI Primary Node · Private Tailscale Mesh · Multi-Device Synchronization · Controlled Node Operations
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className={`px-2.5 py-1 rounded-md border text-[11px] font-mono font-semibold ${availabilityBadge.cls}`}>
            {availabilityBadge.label}
          </span>
          <button
            type="button"
            onClick={refreshAll}
            disabled={isLoading}
            className="px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#1E2B3A] border border-[#283544] text-xs font-mono text-slate-200 flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#66E3CB] ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh Telemetry</span>
          </button>
        </div>
      </div>

      {/* Status Banner */}
      {bannerMessage && (
        <div
          className={`px-4 py-2.5 rounded-lg border text-xs font-mono flex items-center justify-between gap-3 ${
            bannerMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : bannerMessage.type === 'error'
              ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
              : 'bg-teal-500/10 border-teal-500/30 text-[#66E3CB]'
          }`}
        >
          <span>{bannerMessage.text}</span>
          <button
            type="button"
            onClick={() => setBannerMessage(null)}
            className="text-xs underline opacity-80 hover:opacity-100 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 border-b border-[#283544] pb-2">
        {[
          { id: 'overview', label: '1. Primary Node & Telemetry', icon: Server },
          { id: 'devices', label: `2. LORIN Device Center (${devices.length})`, icon: Smartphone },
          { id: 'network', label: '3. Private Network (Tailscale & HTTPS LAN)', icon: Shield },
          { id: 'sync', label: '4. Multi-Device Sync & Availability Matrix', icon: Cloud },
          { id: 'operations', label: '5. Controlled Node Operations & Alerts', icon: Terminal },
          { id: 'systemHealth', label: `6. System Health Center${healthMatrix ? ` (${healthMatrix.subsystems.length} subsystems)` : ''}`, icon: Activity }
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as ControlCenterTab)}
              className={`px-3 py-2 rounded-lg text-xs font-mono font-medium flex items-center gap-2 transition-colors cursor-pointer ${
                active
                  ? 'bg-[#17212C] text-[#66E3CB] border border-[#3A4B5F]'
                  : 'text-[#A2AFBF] hover:bg-[#131C26] hover:text-white border border-transparent'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: PRIMARY NODE & TELEMETRY */}
      {activeTab === 'overview' && (
        <div className="space-y-5">
          {/* Primary Node Status & Lifecycle Bar */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono uppercase tracking-wider text-[#8796A8]">
                  PRIMARY PERSONAL AI NODE
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                    telemetry?.lifecycleState === 'RUNNING'
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : telemetry?.lifecycleState === 'SLEEPING'
                      ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                      : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                  }`}
                >
                  {telemetry?.lifecycleState || 'UNKNOWN'}
                </span>
                <span className="text-xs font-mono text-[#66E3CB]">
                  {telemetry?.nodeName || 'primary-laptop-node'} ({telemetry?.hostPlatform || 'node'} / {telemetry?.hostArch || 'x64'})
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {availabilityBadge.desc}
              </p>
            </div>

            {isOwner && (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleLifecycleControl('START')}
                  disabled={telemetry?.lifecycleState === 'RUNNING'}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 disabled:opacity-40 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center gap-1.5 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Start Node</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    handleLifecycleControl(telemetry?.lifecycleState === 'SLEEPING' ? 'WAKE' : 'SLEEP')
                  }
                  className="px-3 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-mono flex items-center gap-1.5 cursor-pointer"
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>{telemetry?.lifecycleState === 'SLEEPING' ? 'Wake Node' : 'Sleep Mode'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleLifecycleControl('RESTART')}
                  className="px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#1E2B3A] border border-[#3A4B5F] text-slate-200 text-xs font-mono flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-[#66E3CB]" />
                  <span>Restart</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleLifecycleControl('STOP')}
                  disabled={telemetry?.lifecycleState === 'STOPPED'}
                  className="px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 disabled:opacity-40 border border-rose-500/30 text-rose-300 text-xs font-mono flex items-center gap-1.5 cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5" />
                  <span>Stop Node</span>
                </button>
                <label className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-[11px] font-mono text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(telemetry?.autoStartOnBootEnabled)}
                    onChange={(e) => handleLifecycleControl('SET_AUTO_START', e.target.checked)}
                    className="accent-[#66E3CB]"
                  />
                  <span>Auto-Start on Login</span>
                </label>
              </div>
            )}
          </div>

          {/* 4-Column Real Hardware & Storage Telemetry Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#8796A8]">
                <span>CPU LOAD &amp; CORES</span>
                <Cpu className="w-4 h-4 text-[#66E3CB]" />
              </div>
              <div className="text-2xl font-bold font-mono tabular-nums text-white">
                {telemetry ? `${telemetry.loadAvg1m} (1m avg)` : '—'}
              </div>
              <div className="text-[11px] font-mono text-slate-400 truncate">
                {telemetry ? `${telemetry.cpuCount} Physical/Logical Cores` : 'Measuring host CPU...'}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#8796A8]">
                <span>SYSTEM MEMORY (RAM)</span>
                <Activity className="w-4 h-4 text-[#66E3CB]" />
              </div>
              <div className="text-2xl font-bold font-mono tabular-nums text-white">
                {telemetry ? `${telemetry.memoryUsagePercent}%` : '—'}
              </div>
              <div className="text-[11px] font-mono text-slate-400 tabular-nums">
                {telemetry
                  ? `${telemetry.memoryUsedMb.toLocaleString()} MB / ${telemetry.memoryTotalMb.toLocaleString()} MB`
                  : 'Measuring host RAM...'}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#8796A8]">
                <span>LOCAL OLLAMA ENGINE</span>
                <Server className="w-4 h-4 text-[#66E3CB]" />
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-lg font-bold font-mono ${
                    telemetry?.ollamaStatus.reachable ? 'text-emerald-400' : 'text-amber-300'
                  }`}
                >
                  {telemetry?.ollamaStatus.reachable ? 'ONLINE (127.0.0.1)' : 'NOT RUNNING'}
                </span>
              </div>
              <div className="text-[11px] font-mono text-slate-400 truncate">
                {telemetry?.ollamaStatus.reachable
                  ? `${telemetry.ollamaStatus.availableModels.length} local model(s): ${telemetry.ollamaStatus.availableModels.join(', ') || 'ready'}`
                  : 'Bound to localhost only · Never exposed publicly'}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#8796A8]">
                <span>ENCRYPTED NODE STORE</span>
                <Database className="w-4 h-4 text-[#66E3CB]" />
              </div>
              <div className="text-lg font-bold font-mono text-white">
                {telemetry?.localDatabaseEngine || 'SQLITE_ENCRYPTED_LOCAL'}
              </div>
              <div className="text-[11px] font-mono text-slate-400 tabular-nums">
                {telemetry
                  ? `${(telemetry.localDatabaseSizeBytes / 1024).toFixed(1)} KB · Vault Docs: ${telemetry.localKnowledgeStats.indexedDocumentsCount} · Uptime: ${telemetry.uptimeSeconds}s`
                  : 'AES-256-GCM Encrypted'}
              </div>
            </div>
          </div>

          {/* Standalone Laptop Node Scripts Reference */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-mono uppercase tracking-wider text-[#66E3CB]">
                LAPTOP PRIMARY NODE SERVICE SCRIPTS (WINDOWS POWERSHELL &amp; LINUX/MACOS)
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                Directory: <code className="text-white">lorin-node/</code>
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] flex items-center justify-between gap-2">
                <div>
                  <div className="text-[#8796A8] text-[10px]">START LAPTOP PRIMARY NODE (NPM)</div>
                  <code className="text-emerald-300">npm run node:start</code>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyText('npm run node:start', 'node:start command')}
                  className="p-1.5 rounded bg-[#17212C] hover:bg-[#1E2B3A] text-slate-300 cursor-pointer"
                  title="Copy command"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] flex items-center justify-between gap-2">
                <div>
                  <div className="text-[#8796A8] text-[10px]">WINDOWS TASK SCHEDULER (LOGIN AUTO-START)</div>
                  <code className="text-teal-300">powershell -ExecutionPolicy Bypass -File .\lorin-node\scripts\install.ps1 -RegisterStartupShortcut</code>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    handleCopyText(
                      'powershell -ExecutionPolicy Bypass -File .\\lorin-node\\scripts\\install.ps1 -RegisterStartupShortcut',
                      'PowerShell install command'
                    )
                  }
                  className="p-1.5 rounded bg-[#17212C] hover:bg-[#1E2B3A] text-slate-300 cursor-pointer"
                  title="Copy command"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] flex items-center justify-between gap-2">
                <div>
                  <div className="text-[#8796A8] text-[10px]">MACOS LAUNCHD AGENT (AUTO-START ON LOGIN)</div>
                  <code className="text-sky-300">bash ./lorin-node/scripts/install.sh</code>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyText('bash ./lorin-node/scripts/install.sh', 'macOS install command')}
                  className="p-1.5 rounded bg-[#17212C] hover:bg-[#1E2B3A] text-slate-300 cursor-pointer"
                  title="Copy command"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] flex items-center justify-between gap-2">
                <div>
                  <div className="text-[#8796A8] text-[10px]">LINUX SYSTEMD USER SERVICE (AUTO-START ON BOOT)</div>
                  <code className="text-indigo-300">systemctl --user enable --now lorin-node.service</code>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyText('systemctl --user enable --now lorin-node.service', 'systemd command')}
                  className="p-1.5 rounded bg-[#17212C] hover:bg-[#1E2B3A] text-slate-300 cursor-pointer"
                  title="Copy command"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] flex items-center justify-between gap-2">
                <div>
                  <div className="text-[#8796A8] text-[10px]">ORDERED 12-STAGE STARTUP SEQUENCE INSPECTOR</div>
                  <code className="text-amber-300">npm run node:start -- --startup-sequence</code>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyText('npm run node:start -- --startup-sequence', 'Startup sequence inspector')}
                  className="p-1.5 rounded bg-[#17212C] hover:bg-[#1E2B3A] text-slate-300 cursor-pointer"
                  title="Copy command"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: LORIN DEVICE CENTER & QR PAIRING */}
      {activeTab === 'devices' && (
        <div className="space-y-5">
          {/* Enrolled Devices Table */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <h2 className="text-sm font-bold text-white font-mono">
                  ENROLLED DEVICES REGISTRY ({devices.length})
                </h2>
                <p className="text-xs text-[#8796A8]">
                  Current active client device ID: <code className="text-[#66E3CB] font-mono">{currentClientDeviceId}</code>
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#283544] text-[10px] font-mono uppercase text-[#8796A8]">
                    <th className="py-2.5 pr-3">Device</th>
                    <th className="py-2.5 px-3">State</th>
                    <th className="py-2.5 px-3">Authorization</th>
                    <th className="py-2.5 px-3">Network Path</th>
                    <th className="py-2.5 px-3">Capabilities</th>
                    <th className="py-2.5 px-3">Last Seen</th>
                    <th className="py-2.5 pl-3 text-right">Owner Controls</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1D2836]">
                  {devices.map((dev) => {
                    const DevIcon = getDeviceIcon(dev.deviceType);
                    const isCurrent = dev.deviceId === currentClientDeviceId;
                    return (
                      <tr key={dev.deviceId} className="hover:bg-[#151F2B]/60">
                        <td className="py-3 pr-3">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-[#17212C] border border-[#283544] flex items-center justify-center shrink-0">
                              <DevIcon className="w-4 h-4 text-[#66E3CB]" />
                            </div>
                            <div>
                              {renamingDeviceId === dev.deviceId ? (
                                <div className="flex items-center gap-1">
                                  <input
                                    type="text"
                                    value={renameInput}
                                    onChange={(e) => setRenameInput(e.target.value)}
                                    className="px-2 py-0.5 rounded bg-[#0B0F14] border border-[#66E3CB] text-xs text-white"
                                  />
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleDeviceAction(dev.deviceId, 'RENAME', { deviceName: renameInput })
                                    }
                                    className="px-2 py-0.5 rounded bg-[#66E3CB] text-slate-950 font-bold text-[10px] cursor-pointer"
                                  >
                                    Save
                                  </button>
                                </div>
                              ) : (
                                <div className="font-semibold text-white flex items-center gap-1.5">
                                  <span>{dev.deviceName}</span>
                                  {dev.isPrimaryNode && (
                                    <span className="px-1.5 py-0.2 rounded bg-teal-500/15 text-[#66E3CB] border border-teal-500/30 text-[9px] font-mono">
                                      PRIMARY NODE
                                    </span>
                                  )}
                                  {isCurrent && (
                                    <span className="px-1.5 py-0.2 rounded bg-sky-500/15 text-sky-300 border border-sky-500/30 text-[9px] font-mono">
                                      THIS DEVICE
                                    </span>
                                  )}
                                </div>
                              )}
                              <div className="text-[10px] font-mono text-[#8796A8]">
                                {dev.deviceId} · {dev.platformSummary}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-3 font-mono">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] border ${
                              dev.connectionState === 'online'
                                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                                : dev.connectionState === 'sleeping'
                                ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                                : dev.connectionState === 'revoked' || dev.connectionState === 'unauthorized'
                                ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                                : 'bg-slate-800 text-slate-400 border-slate-700'
                            }`}
                          >
                            {dev.connectionState.toUpperCase()}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-mono">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] border ${
                              dev.authorizationStatus === 'APPROVED'
                                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                                : dev.authorizationStatus === 'PENDING_APPROVAL'
                                ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                                : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                            }`}
                          >
                            {dev.authorizationStatus}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-mono text-[11px] text-slate-300">
                          <div>{dev.connectionType}</div>
                          {(dev.tailscaleIp || dev.tailscaleHostname) && (
                            <div className="text-[10px] text-[#8796A8]">
                              {dev.tailscaleIp || dev.tailscaleHostname}
                            </div>
                          )}
                        </td>

                        <td className="py-3 px-3">
                          <div className="flex flex-wrap gap-1 max-w-xs">
                            {dev.grantedPermissions.slice(0, 4).map((p) => (
                              <span
                                key={p}
                                className="px-1.5 py-0.2 rounded bg-[#17212C] border border-[#283544] text-[10px] font-mono text-slate-300"
                              >
                                {p}
                              </span>
                            ))}
                            {dev.grantedPermissions.length > 4 && (
                              <span className="text-[10px] font-mono text-[#8796A8]">
                                +{dev.grantedPermissions.length - 4} more
                              </span>
                            )}
                          </div>
                        </td>

                        <td className="py-3 px-3 font-mono text-[11px] text-[#8796A8] tabular-nums">
                          {new Date(dev.lastActiveAt).toLocaleTimeString()}
                        </td>

                        <td className="py-3 pl-3 text-right">
                          {isPrivileged && (
                            <div className="flex items-center justify-end gap-1">
                              {dev.authorizationStatus !== 'APPROVED' && (
                                <button
                                  type="button"
                                  onClick={() => handleDeviceAction(dev.deviceId, 'APPROVE')}
                                  className="px-2 py-1 rounded bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-[10px] font-mono cursor-pointer"
                                >
                                  Approve
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => {
                                  setRenamingDeviceId(dev.deviceId);
                                  setRenameInput(dev.deviceName);
                                }}
                                className="px-2 py-1 rounded bg-[#17212C] hover:bg-[#1E2B3A] border border-[#283544] text-slate-300 text-[10px] font-mono cursor-pointer"
                              >
                                Rename
                              </button>
                              {!dev.isPrimaryNode && dev.authorizationStatus === 'APPROVED' && (
                                <button
                                  type="button"
                                  onClick={() => handleDeviceAction(dev.deviceId, 'SUSPEND')}
                                  className="px-2 py-1 rounded bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-[10px] font-mono cursor-pointer"
                                >
                                  Suspend
                                </button>
                              )}
                              {!dev.isPrimaryNode && dev.authorizationStatus !== 'REVOKED' && (
                                <button
                                  type="button"
                                  onClick={() => handleDeviceAction(dev.deviceId, 'REVOKE')}
                                  className="px-2 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-[10px] font-mono cursor-pointer"
                                >
                                  Revoke
                                </button>
                              )}
                              {!dev.isPrimaryNode && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveDevice(dev.deviceId)}
                                  className="p-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 cursor-pointer"
                                  title="Remove device"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Single-Use QR Pairing Generator & Companion Redemption Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Generate Single-Use QR Pairing Challenge */}
            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-[#66E3CB]" />
                  <h3 className="text-sm font-bold font-mono text-white">
                    GENERATE SINGLE-USE QR PAIRING CHALLENGE
                  </h3>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-teal-500/10 text-[#66E3CB] border border-teal-500/30">
                  ZERO SECRETS IN QR
                </span>
              </div>

              <p className="text-xs text-[#8796A8]">
                Generates a short-lived, single-use pairing challenge bound to your owner account. Never embeds Firebase Admin keys, permanent API keys, or Tailscale auth keys.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-[10px] font-mono text-[#8796A8] mb-1">
                    DEVICE LABEL
                  </label>
                  <input
                    type="text"
                    value={pairingDeviceName}
                    onChange={(e) => setPairingDeviceName(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-[#8796A8] mb-1">
                    DEVICE TYPE
                  </label>
                  <select
                    value={pairingDeviceType}
                    onChange={(e) => setPairingDeviceType(e.target.value as EnrolledDeviceType)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-white text-xs"
                  >
                    <option value="mobile_phone">Mobile Phone</option>
                    <option value="tablet">Tablet</option>
                    <option value="secondary_laptop">Secondary Laptop</option>
                    <option value="desktop_workstation">Desktop Workstation</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-[#8796A8] mb-1">
                    EXPIRATION (SECONDS)
                  </label>
                  <input
                    type="number"
                    min={60}
                    max={900}
                    value={pairingTtlSeconds}
                    onChange={(e) => setPairingTtlSeconds(Number(e.target.value) || 300)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-white text-xs font-mono"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={handleGenerateQrChallenge}
                disabled={!isPrivileged}
                className="w-full py-2 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] disabled:opacity-40 text-slate-950 font-bold text-xs font-mono flex items-center justify-center gap-2 cursor-pointer"
              >
                <QrCode className="w-4 h-4" />
                <span>Generate Single-Use Pairing QR Code</span>
              </button>

              {activeChallenge && (
                <div className="p-4 rounded-xl bg-[#0B0F14] border border-[#3A4B5F] flex flex-col sm:flex-row items-center gap-4">
                  <DeterministicQrSvg payload={activeChallenge.qrPayloadString} />
                  <div className="flex-1 space-y-2 text-xs font-mono">
                    <div>
                      <span className="text-[#8796A8]">CHALLENGE ID: </span>
                      <span className="text-white">{activeChallenge.challengeId}</span>
                    </div>
                    <div>
                      <span className="text-[#8796A8]">ONE-TIME CODE: </span>
                      <span className="text-lg font-bold text-[#66E3CB] tracking-wider">
                        {activeChallenge.oneTimeCode}
                      </span>
                    </div>
                    <div>
                      <span className="text-[#8796A8]">EXPIRES AT: </span>
                      <span className="text-amber-300">
                        {new Date(activeChallenge.expiresAt).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Scan from your authenticated mobile LORIN PWA or enter the Challenge ID and One-Time Code on the right to enroll.
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Redeem Pairing Challenge Form */}
            <form
              onSubmit={handleRedeemPairing}
              className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-4"
            >
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#66E3CB]" />
                <h3 className="text-sm font-bold font-mono text-white">
                  ENROLL THIS DEVICE / REDEEM PAIRING CODE
                </h3>
              </div>

              <p className="text-xs text-[#8796A8]">
                Redeem an active single-use challenge to bind this device to your LORIN Device Center. Replayed or expired codes are rejected automatically.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[10px] font-mono text-[#8796A8] mb-1">
                    CHALLENGE ID
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="pair_..."
                    value={redeemChallengeId}
                    onChange={(e) => setRedeemChallengeId(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-white text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-[#8796A8] mb-1">
                    ONE-TIME PAIRING CODE
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="8-CHAR HEX CODE"
                    value={redeemCode}
                    onChange={(e) => setRedeemCode(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-white text-xs font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-[#8796A8] mb-1">
                    DEVICE NAME
                  </label>
                  <input
                    type="text"
                    required
                    value={redeemDeviceName}
                    onChange={(e) => setRedeemDeviceName(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-[#8796A8] mb-1">
                    DEVICE FORM FACTOR
                  </label>
                  <select
                    value={redeemDeviceType}
                    onChange={(e) => setRedeemDeviceType(e.target.value as EnrolledDeviceType)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-white text-xs"
                  >
                    <option value="mobile_phone">Mobile Phone</option>
                    <option value="tablet">Tablet</option>
                    <option value="secondary_laptop">Secondary Laptop</option>
                    <option value="desktop_workstation">Desktop Workstation</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 rounded-lg bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/40 text-[#66E3CB] font-bold text-xs font-mono cursor-pointer"
              >
                Redeem Pairing Code &amp; Enroll Device
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 3: PRIVATE NETWORK (TAILSCALE SERVE & HTTPS LAN) */}
      {activeTab === 'network' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#8796A8]">
                <span>TAILSCALE MESH STATUS</span>
                <ShieldCheck className="w-4 h-4 text-[#66E3CB]" />
              </div>
              <div className="text-lg font-bold font-mono text-white">
                {network?.tailscale.backendState === 'Running'
                  ? 'CONNECTED (PRIVATE TAILNET)'
                  : network?.tailscale.installed
                  ? `INSTALLED (${network.tailscale.backendState})`
                  : network?.tailscale.serveConfigured
                  ? 'CONFIGURED VIA HTTPS ENDPOINT'
                  : 'STANDBY'}
              </div>
              <div className="text-xs font-mono text-slate-400">
                {network?.tailscale.statusDetail || 'Tailscale Serve HTTPS private mode recommended'}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#8796A8]">
                <span>PUBLIC FUNNEL PROTECTION</span>
                <Lock className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-lg font-bold font-mono text-emerald-400">
                FUNNEL DISABLED (PRIVATE ONLY)
              </div>
              <div className="text-xs font-mono text-slate-400">
                Public unauthenticated internet exposure and raw port forwarding are strictly blocked.
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#8796A8]">
                <span>HTTPS TRANSPORT ENFORCEMENT</span>
                <Wifi className="w-4 h-4 text-[#66E3CB]" />
              </div>
              <div className="text-lg font-bold font-mono text-white">
                {network?.secureTransportVerified ? 'HTTPS VERIFIED' : 'LOCALHOST / DEV'}
              </div>
              <div className="text-xs font-mono text-slate-400 truncate">
                {network?.tailscale.serveHttpsEndpoint || 'https://<laptop>.<tailnet>.ts.net'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Configure Tailscale Serve Endpoint */}
            <form
              onSubmit={handleSaveTailscaleEndpoint}
              className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-3"
            >
              <div className="text-sm font-bold font-mono text-white">
                TAILSCALE SERVE PRIVATE HTTPS ENDPOINT (PRIMARY)
              </div>
              <p className="text-xs text-[#8796A8]">
                Enter your laptop&apos;s MagicDNS / Tailscale Serve HTTPS URL (must start with <code className="text-white">https://</code> and never use public Funnel).
              </p>
              <div className="flex gap-2">
                <input
                  type="url"
                  placeholder="https://lorin-laptop.tailnet-name.ts.net"
                  value={tailscaleEndpointInput}
                  onChange={(e) => setTailscaleEndpointInput(e.target.value)}
                  className="flex-1 px-3 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-xs font-mono text-white"
                />
                <button
                  type="submit"
                  disabled={!isOwner}
                  className="px-4 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] disabled:opacity-40 text-slate-950 font-bold text-xs font-mono cursor-pointer"
                >
                  Save Tailscale URL
                </button>
              </div>
            </form>

            {/* Configure HTTPS-Only LAN Fallback */}
            <form
              onSubmit={handleSaveLanEndpoint}
              className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-3"
            >
              <div className="text-sm font-bold font-mono text-white">
                OPTIONAL SECURE LAN HTTPS ENDPOINT (FALLBACK)
              </div>
              <p className="text-xs text-[#8796A8]">
                Plain <code className="text-rose-300">http://</code> LAN URLs are rejected because mobile browsers block microphone, camera, and service workers on insecure origins.
              </p>
              <div className="flex gap-2">
                <input
                  type="url"
                  placeholder="https://192.168.1.50:8443"
                  value={lanEndpointInput}
                  onChange={(e) => setLanEndpointInput(e.target.value)}
                  className="flex-1 px-3 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-xs font-mono text-white"
                />
                <button
                  type="submit"
                  disabled={!isOwner}
                  className="px-4 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#1E2B3A] border border-[#3A4B5F] disabled:opacity-40 text-[#66E3CB] font-bold text-xs font-mono cursor-pointer"
                >
                  Validate HTTPS LAN
                </button>
              </div>
            </form>
          </div>

          {/* Step-by-Step Tailscale Serve Commands */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-[#66E3CB]">
              STEP-BY-STEP PRIVATE TAILSCALE SERVE SETUP (LAPTOP + PHONE)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] space-y-1">
                <div className="text-[10px] text-[#8796A8]">STEP 1 · AUTHENTICATE TAILSCALE ON LAPTOP</div>
                <code className="text-emerald-300 block">tailscale up</code>
                <div className="text-[11px] text-slate-400 font-sans">
                  Joins your laptop to your private encrypted tailnet.
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] space-y-1">
                <div className="text-[10px] text-[#8796A8]">STEP 2 · EXPOSE LORIN VIA PRIVATE HTTPS SERVE</div>
                <code className="text-emerald-300 block">tailscale serve --bg http://127.0.0.1:3000</code>
                <div className="text-[11px] text-slate-400 font-sans">
                  Provisions automatic TLS certs for your tailnet only. Do NOT run <code className="text-rose-300">tailscale funnel</code>.
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] space-y-1">
                <div className="text-[10px] text-[#8796A8]">STEP 3 · VERIFY STATUS &amp; OPEN ON MOBILE</div>
                <code className="text-emerald-300 block">tailscale serve status</code>
                <div className="text-[11px] text-slate-400 font-sans">
                  Install Tailscale on your phone, sign in, and open the <code className="text-white">https://&lt;laptop&gt;.&lt;tailnet&gt;.ts.net</code> URL.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: MULTI-DEVICE SYNCHRONIZATION & AVAILABILITY MATRIX */}
      {activeTab === 'sync' && (
        <div className="space-y-5">
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-1">
              <div className="text-sm font-bold font-mono text-white">
                APPEND-ORIENTED MULTI-DEVICE SYNCHRONIZATION ENGINE
              </div>
              <div className="text-xs text-[#8796A8] font-mono">
                Outbox Queue: <span className="text-white font-bold">{syncSummary.pendingOutboxCount}</span> pending item(s) ·{' '}
                Last Sync:{' '}
                <span className="text-[#66E3CB]">
                  {syncSummary.lastSyncedAt
                    ? new Date(syncSummary.lastSyncedAt).toLocaleTimeString()
                    : 'Ready'}
                </span>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleManualSyncNow}
                disabled={isLoading}
                className="px-3.5 py-2 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs font-mono flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Sync Now Across Devices</span>
              </button>

              <label className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#0B0F14] border border-[#283544] text-xs font-mono text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={retainTrustedCache}
                  onChange={(e) => {
                    setRetainTrustedCache(e.target.checked);
                    DeviceCenterService.setTrustedDeviceCacheRetained(e.target.checked);
                  }}
                  className="accent-[#66E3CB]"
                />
                <span>Trusted Device: Retain Encrypted Offline Cache</span>
              </label>
            </div>
          </div>

          {/* Centralized Local vs. Cloud Capability Routing Matrix */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-wider text-[#66E3CB]">
              CENTRALIZED LOCAL VS. CLOUD CAPABILITY ROUTER (LIVE EVALUATION)
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#283544] text-[10px] font-mono uppercase text-[#8796A8]">
                    <th className="py-2 pr-3">Capability</th>
                    <th className="py-2 px-3">Execution Target</th>
                    <th className="py-2 px-3">Status</th>
                    <th className="py-2 pl-3">Truthful Routing Explanation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1D2836]">
                  {CAPABILITY_ROUTER_LIST.map((item) => {
                    const route = DeviceCenterService.routeCapability(item.id, availabilityMode, telemetry);
                    return (
                      <tr key={item.id}>
                        <td className="py-2.5 pr-3 font-medium text-white">{item.label}</td>
                        <td className="py-2.5 px-3 font-mono text-[11px] text-[#66E3CB]">
                          {route.executionTarget}
                        </td>
                        <td className="py-2.5 px-3 font-mono">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] border ${
                              route.available
                                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                                : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                            }`}
                          >
                            {route.available ? 'AVAILABLE' : 'PAUSED / BLOCKED'}
                          </span>
                        </td>
                        <td className="py-2.5 pl-3 text-slate-300">{route.reason}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: CONTROLLED NODE OPERATIONS & ALERTS */}
      {activeTab === 'operations' && (
        <div className="space-y-5">
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <h2 className="text-sm font-bold font-mono text-white">
                  RESTRICTED ALLOWLISTED NODE COMMAND REGISTRY
                </h2>
                <p className="text-xs text-[#8796A8]">
                  Arbitrary shell execution is prohibited. Only predefined, audited node operations below can be triggered by authorized devices.
                </p>
              </div>
              {isOwner && (
                <div className="px-3 py-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono max-w-xl">
                  High-impact commands require a server-issued, action-bound approval. Request the command here, approve its exact request in Security &amp; Approvals, then retry it. A browser checkbox cannot authorize execution.
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {approvedCommands.map((cmd) => (
                <div
                  key={cmd.commandId}
                  className="p-3.5 rounded-xl bg-[#0B0F14] border border-[#283544] flex flex-col justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-xs font-mono text-white">{cmd.title}</span>
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-mono border ${
                          cmd.riskLevel === 'HIGH'
                            ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                            : 'bg-teal-500/15 text-[#66E3CB] border-teal-500/30'
                        }`}
                      >
                        {cmd.riskLevel} RISK
                      </span>
                    </div>
                    <p className="text-xs text-[#8796A8]">{cmd.description}</p>
                    <div className="text-[10px] font-mono text-slate-400">
                      ID: <code>{cmd.commandId}</code> · Scope: <code>{cmd.requiredScope}</code>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleExecuteCommand(cmd)}
                    disabled={executingCommandId === cmd.commandId}
                    className="w-full py-1.5 rounded-lg bg-[#17212C] hover:bg-[#1E2B3A] border border-[#3A4B5F] text-xs font-mono text-[#66E3CB] font-semibold cursor-pointer"
                  >
                    {executingCommandId === cmd.commandId ? 'Executing on Primary Node...' : `Run ${cmd.title}`}
                  </button>
                </div>
              ))}
            </div>

            {commandHistory.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-[#283544]">
                <div className="text-xs font-mono uppercase text-[#8796A8]">
                  RECENT NODE COMMAND AUDIT LOG
                </div>
                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {commandHistory.map((item) => (
                    <div
                      key={`${item.executionId}-${item.startedAt}`}
                      className="p-2.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-xs font-mono flex items-center justify-between gap-3"
                    >
                      <div>
                        <span className={item.status === 'COMPLETED' ? 'text-emerald-400' : 'text-rose-400'}>
                          [{item.status}]
                        </span>{' '}
                        <span className="text-white">{item.commandId}</span> —{' '}
                        <span className="text-slate-300">{item.outputSummary}</span>
                      </div>
                      <span className="text-[10px] text-[#8796A8] shrink-0">
                        {new Date(item.completedAt).toLocaleTimeString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Section 15: User-Controlled Notification Categories */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#66E3CB]" />
                <h3 className="text-sm font-bold font-mono text-white">
                  BROWSER &amp; MOBILE PWA NOTIFICATION CONTROLS
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono text-[#8796A8]">
                  Browser Permission: <strong className="text-white">{browserNotifPerm.toUpperCase()}</strong>
                </span>
                {browserNotifPerm !== 'granted' && browserNotifPerm !== 'unsupported' && (
                  <button
                    type="button"
                    onClick={async () => {
                      const perm = await DeviceCenterService.requestBrowserNotificationPermission();
                      setBrowserNotifPerm(perm);
                      setNotifPrefs(DeviceCenterService.getNotificationPreferences());
                    }}
                    className="px-2.5 py-1 rounded bg-[#66E3CB] text-slate-950 font-bold text-xs font-mono cursor-pointer"
                  >
                    Enable Browser Alerts
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs font-mono">
              {[
                { key: 'approvalRequests', label: 'High-Impact Approval Requests' },
                { key: 'longRunningTaskCompletion', label: 'Long-Running Task Completion' },
                { key: 'primaryNodeDisconnected', label: 'Primary Laptop Node Disconnected' },
                { key: 'securityAlerts', label: 'Security & Revocation Alerts' },
                { key: 'dailyGoalsReminders', label: 'Daily Engineering Goal Reminders' }
              ].map((item) => {
                const k = item.key as keyof Omit<NotificationCategoryPreferences, 'enabled'>;
                return (
                  <label
                    key={item.key}
                    className="p-2.5 rounded-lg bg-[#0B0F14] border border-[#283544] flex items-center gap-2 text-slate-200 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={Boolean(notifPrefs[k])}
                      onChange={(e) => {
                        const updated = DeviceCenterService.saveNotificationPreferences({
                          [k]: e.target.checked
                        });
                        setNotifPrefs(updated);
                      }}
                      className="accent-[#66E3CB]"
                    />
                    <span>{item.label}</span>
                  </label>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: CENTRALIZED SYSTEM HEALTH CENTER (Section 13) */}
      {activeTab === 'systemHealth' && (
        <div className="space-y-5">
          {/* Top Health Header & Summary */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#66E3CB]" />
                <h2 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                  CENTRALIZED SYSTEM HEALTH CENTER
                </h2>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                    healthMatrix?.overallStatus === 'HEALTHY'
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  }`}
                >
                  {healthMatrix?.overallStatus || 'AUDITING'}
                </span>
              </div>
              <p className="text-xs text-slate-300 font-mono">
                {healthMatrix?.summary || 'Auditing all 18 subsystems across Frontend, Backend, Primary Node, Firebase, Models & Network...'}
              </p>
              <div className="text-[11px] font-mono text-[#8796A8]">
                Last Verified: {healthMatrix ? new Date(healthMatrix.timestamp).toLocaleString() : 'Just now'} · Zero synthetic or fabricated metrics
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={async () => {
                  setIsAuditingHealth(true);
                  try {
                    const res = await DeviceCenterService.getSystemHealthMatrix();
                    if (res) setHealthMatrix(res);
                  } finally {
                    setIsAuditingHealth(false);
                  }
                }}
                disabled={isAuditingHealth}
                className="px-3.5 py-2 rounded-lg bg-[#66E3CB] hover:bg-[#52cbb4] text-slate-950 font-mono font-bold text-xs flex items-center gap-2 cursor-pointer transition-colors"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isAuditingHealth ? 'animate-spin' : ''}`} />
                <span>Run Full System Audit Now</span>
              </button>
            </div>
          </div>

          {/* Subsystem Category Filters */}
          <div className="flex flex-wrap items-center gap-1.5 border-b border-[#283544] pb-2">
            {[
              { id: 'all', label: `All Subsystems${healthMatrix ? ` (${healthMatrix.subsystems.length})` : ''}` },
              { id: 'core', label: `Core Runtime${healthMatrix ? ` (${healthMatrix.subsystems.filter(s => s.category === 'core').length})` : ''}` },
              { id: 'ai', label: `AI & Models${healthMatrix ? ` (${healthMatrix.subsystems.filter(s => s.category === 'ai').length})` : ''}` },
              { id: 'storage', label: `Storage & Knowledge${healthMatrix ? ` (${healthMatrix.subsystems.filter(s => s.category === 'storage').length})` : ''}` },
              { id: 'network', label: `Network & Mesh${healthMatrix ? ` (${healthMatrix.subsystems.filter(s => s.category === 'network').length})` : ''}` },
              { id: 'media', label: `Media & Holographic${healthMatrix ? ` (${healthMatrix.subsystems.filter(s => s.category === 'media').length})` : ''}` }
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setHealthCategoryFilter(cat.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors cursor-pointer ${
                  healthCategoryFilter === cat.id
                    ? 'bg-[#17212C] text-[#66E3CB] border border-[#3A4B5F]'
                    : 'text-[#8796A8] hover:bg-[#131C26] hover:text-white border border-transparent'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Verified subsystem status grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {(healthMatrix?.subsystems || []).filter(
              (sub) => healthCategoryFilter === 'all' || sub.category === healthCategoryFilter
            ).map((sub) => {
              const stateCls =
                sub.state === 'HEALTHY'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : sub.state === 'DEGRADED'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                  : sub.state === 'NOT_CONFIGURED' || sub.state === 'NOT_VERIFIED'
                  ? 'bg-slate-700/30 border-slate-600/40 text-slate-300'
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-300';

              return (
                <div
                  key={sub.id}
                  className="p-4 rounded-xl bg-[#111821] border border-[#283544] flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-0.5">
                        <span className="text-[10px] font-mono uppercase tracking-wider text-[#8796A8]">
                          {sub.category.toUpperCase()}
                        </span>
                        <h3 className="text-xs font-bold text-white font-mono leading-tight">
                          {sub.name}
                        </h3>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border shrink-0 ${stateCls}`}>
                        {sub.state}
                      </span>
                    </div>

                    <div className="text-[11px] font-mono text-[#66E3CB] bg-[#0B0F14] px-2 py-1 rounded border border-[#283544]">
                      <code>{sub.diagnosticCode}</code>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {sub.summary}
                    </p>
                  </div>

                  {sub.details && Object.keys(sub.details).length > 0 && (
                    <div className="pt-2 border-t border-[#283544]/60 space-y-1">
                      <div className="text-[10px] font-mono text-[#8796A8] uppercase tracking-wider">
                        Technical Inspection Details
                      </div>
                      <div className="space-y-0.5 text-[11px] font-mono text-slate-400">
                        {Object.entries(sub.details).map(([k, v]) => (
                          <div key={k} className="flex items-center justify-between gap-2 truncate">
                            <span className="text-slate-400">{k}:</span>
                            <span className="text-slate-200 font-semibold truncate">
                              {typeof v === 'boolean'
                                ? v ? 'true' : 'false'
                                : Array.isArray(v)
                                ? v.join(', ') || 'none'
                                : String(v)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
