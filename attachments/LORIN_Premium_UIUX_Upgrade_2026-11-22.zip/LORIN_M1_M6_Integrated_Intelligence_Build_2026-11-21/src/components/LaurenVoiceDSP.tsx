import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, Sparkles, Activity, ShieldCheck } from 'lucide-react';
import { getAuthHeaders } from '../services/authHeaders';

interface Props {
  onSendMessage: (text: string) => void;
  isProcessing?: boolean;
}

export const LaurenVoiceDSP: React.FC<Props> = ({ onSendMessage, isProcessing }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [audioLevel, setAudioLevel] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check SpeechRecognition support
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let currentText = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentText += event.results[i][0].transcript;
        }
        setTranscript(currentText);
      };

      recognition.onend = () => {
        setIsListening(false);
        stopAudioDSP();
      };

      recognitionRef.current = recognition;
    }

    return () => {
      stopAudioDSP();
    };
  }, []);

  const startAudioDSP = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioCtxRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 64;
      analyserRef.current = analyser;
      source.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const updateLevel = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        setAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
        animFrameRef.current = requestAnimationFrame(updateLevel);
      };

      updateLevel();
    } catch (e) {
      console.warn('Microphone access for DSP visualization deferred:', e);
    }
  };

  const stopAudioDSP = () => {
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (audioCtxRef.current) {
      audioCtxRef.current.close().catch(() => {});
      audioCtxRef.current = null;
    }
    setAudioLevel(0);
  };

  const handleToggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      stopAudioDSP();
      if (transcript.trim()) {
        onSendMessage(transcript.trim());
        setTranscript('');
      }
    } else {
      setTranscript('');
      setIsListening(true);
      startAudioDSP();
      try {
        recognitionRef.current?.start();
      } catch {}
    }
  };

  return (
    <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-6 text-center max-w-xl mx-auto shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-slate-100">
          <Sparkles className="w-4 h-4 text-teal-500" />
          <span>Lauren Private Voice Stage</span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-teal-500" />
          <span>Zero-Trust Mic Access</span>
        </div>
      </div>

      {/* Main Microphone DSP Button with Dynamic Visualizer Rings */}
      <div className="relative py-6 flex items-center justify-center">
        {isListening && (
          <div
            className="absolute rounded-full bg-teal-500/20 transition-all duration-75 animate-ping"
            style={{ width: `${100 + audioLevel * 1.5}px`, height: `${100 + audioLevel * 1.5}px` }}
          />
        )}

        <button
          onClick={handleToggleListening}
          className={`relative z-10 w-24 h-24 rounded-full flex items-center justify-center transition-all shadow-xl ${
            isListening
              ? 'bg-teal-500 text-white shadow-teal-500/40 scale-105'
              : 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:scale-105'
          }`}
        >
          {isListening ? <Mic className="w-10 h-10 animate-pulse" /> : <MicOff className="w-10 h-10" />}
        </button>
      </div>

      {/* Real-Time Audio Level Meter */}
      <div className="space-y-1 max-w-xs mx-auto">
        <div className="flex justify-between text-[11px] font-mono text-slate-500">
          <span>DSP Meter</span>
          <span className="tabular-nums">{audioLevel}%</span>
        </div>
        <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-teal-500 transition-all duration-75"
            style={{ width: `${audioLevel}%` }}
          />
        </div>
      </div>

      {/* Transcript Box */}
      <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 min-h-[60px] flex items-center justify-center italic">
        {transcript ? (
          <span>"{transcript}"</span>
        ) : isListening ? (
          <span className="text-teal-600 dark:text-teal-400 font-medium not-italic animate-pulse">Listening... speak now</span>
        ) : (
          <span className="text-slate-400 not-italic">Tap microphone to begin high-fidelity voice conversation.</span>
        )}
      </div>
    </div>
  );
};
