import React, { useState, useEffect, useRef } from 'react';
import { 
  Video, 
  VideoOff, 
  Camera, 
  RefreshCw, 
  Radio, 
  Sparkles, 
  PhoneOff, 
  AlertCircle, 
  Check, 
  Send,
  Eye,
  Maximize2
} from 'lucide-react';
import { VideoService } from '../services/videoService';
import { LorinCompletionReport, VideoState } from '../types/lorin';
import { LorinCharacterState } from '../services/lorinPresence';
import { LorinCharacter } from './LorinCharacter';

interface VideoVisionViewProps {
  onAnalyzeSnapshot: (prompt: string, imageBase64: string) => Promise<LorinCompletionReport>;
  onSwitchToChat: () => void;
  isCameraActive: boolean;
  setIsCameraActive: (active: boolean) => void;
  onPresenceChange?: (state: LorinCharacterState) => void;
}

export const VideoVisionView: React.FC<VideoVisionViewProps> = ({
  onAnalyzeSnapshot,
  onSwitchToChat,
  isCameraActive,
  setIsCameraActive,
  onPresenceChange
}) => {
  const [videoState, setVideoState] = useState<VideoState>('IDLE');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [capturedSnapshot, setCapturedSnapshot] = useState<string | null>(null);
  const [analysisPrompt, setAnalysisPrompt] = useState('Analyze this visual frame and evaluate any engineering, code, or architectural artifacts.');
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const characterState: LorinCharacterState = videoState === 'ERROR'
      ? 'ERROR'
      : videoState === 'ANALYZING_FRAME'
        ? 'ANALYZING'
        : videoState === 'PREVIEW_ACTIVE' && isCameraActive
          ? 'VISION_ACTIVE'
          : videoState === 'STARTING'
            ? 'PROCESSING'
            : 'IDLE';
    onPresenceChange?.(characterState);
  }, [videoState, isCameraActive, onPresenceChange]);

  const startCameraSession = async () => {
    if (!videoRef.current) return;
    setErrorMessage(null);
    setVideoState('STARTING');

    const res = await VideoService.startCamera(videoRef.current, facingMode);
    if (!res.success) {
      setVideoState('ERROR');
      setErrorMessage(res.error || 'Failed to access camera.');
      setIsCameraActive(false);
      return;
    }

    setIsCameraActive(true);
    setVideoState('PREVIEW_ACTIVE');
  };

  const endCameraSession = () => {
    VideoService.stopCamera();
    setIsCameraActive(false);
    setVideoState('IDLE');
    setCapturedSnapshot(null);
  };

  const handleFlipCamera = async () => {
    if (!videoRef.current) return;
    const res = await VideoService.toggleFacingMode(videoRef.current);
    if (res.success) {
      setFacingMode(res.facingMode);
    }
  };

  const handleCaptureSnapshot = () => {
    if (!videoRef.current) return;
    const dataUrl = VideoService.captureSnapshot(videoRef.current);
    if (dataUrl) {
      setCapturedSnapshot(dataUrl);
      setAnalysisResult(null);
    }
  };

  const handleSendSnapshotForAnalysis = async () => {
    if (!capturedSnapshot) return;
    setIsProcessing(true);
    setVideoState('ANALYZING_FRAME');

    try {
      const report = await onAnalyzeSnapshot(analysisPrompt, capturedSnapshot);
      setAnalysisResult(report.rawSynthesis);
    } catch (e: any) {
      setErrorMessage(e.message || 'Vision analysis failed');
    } finally {
      setIsProcessing(false);
      setVideoState('PREVIEW_ACTIVE');
    }
  };

  // Teardown camera tracks when leaving view
  useEffect(() => {
    return () => {
      VideoService.stopCamera();
      setIsCameraActive(false);
    };
  }, [setIsCameraActive]);

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] overflow-y-auto">
      {/* Top Header */}
      <div className="p-4 border-b border-[#283544] bg-[#111821] flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center">
            <Eye className="w-4 h-4 text-[#66E3CB]" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight">Video & Vision Stage</h2>
            <div className="text-[11px] font-mono text-[#A2AFBF] flex items-center gap-2">
              <span>Mode: <strong className="text-[#66E3CB]">{isCameraActive ? 'Local Camera Preview' : 'Camera Off'}</strong></span>
              <span>·</span>
              <span>Facing: {facingMode}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {isCameraActive && (
            <button
              onClick={handleFlipCamera}
              className="px-3 py-1.5 rounded-lg bg-[#17212C] border border-[#283544] hover:bg-[#151E28] text-xs text-[#A2AFBF] hover:text-white flex items-center gap-1.5 font-mono"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Flip Camera</span>
            </button>
          )}

          <button
            onClick={onSwitchToChat}
            className="px-3 py-1.5 rounded-lg bg-[#17212C] border border-[#283544] hover:bg-[#151E28] text-xs text-[#A2AFBF] hover:text-white transition-colors"
          >
            Chat View
          </button>
        </div>
      </div>

      {/* Main Vision Stage Layout */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Error Notice */}
          {errorMessage && (
            <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-3">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Video Preview and LORIN Presence Split */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left: Camera Viewfinder */}
            <div className="relative rounded-2xl bg-[#111821] border border-[#283544] overflow-hidden aspect-video flex items-center justify-center shadow-xl">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover transition-opacity duration-300 ${isCameraActive ? 'opacity-100' : 'opacity-0'}`}
              />

              {!isCameraActive && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center space-y-3 bg-[#111821]">
                  <div className="w-14 h-14 rounded-2xl bg-[#17212C] border border-[#283544] flex items-center justify-center text-[#738297]">
                    <VideoOff className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">Camera Preview Inactive</h3>
                    <p className="text-xs text-[#A2AFBF] max-w-xs mt-1">
                      Start camera to preview local video or capture snapshots for vision analysis.
                    </p>
                  </div>
                  <button
                    onClick={startCameraSession}
                    className="px-5 py-2.5 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs flex items-center gap-2 transition-transform active:scale-95 shadow-md"
                  >
                    <Video className="w-4 h-4" />
                    <span>Enable Camera</span>
                  </button>
                </div>
              )}

              {/* Viewfinder Overlays when Active */}
              {isCameraActive && (
                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-xs border border-white/10 text-[11px] font-mono text-emerald-400 flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>LOCAL PREVIEW</span>
                </div>
              )}

              {isCameraActive && (
                <div className="absolute bottom-3 inset-x-3 flex items-center justify-between pointer-events-auto">
                  <button
                    onClick={handleCaptureSnapshot}
                    className="px-4 py-2 rounded-xl bg-white text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg hover:bg-slate-100 transition-transform active:scale-95"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Capture Snapshot</span>
                  </button>

                  <button
                    onClick={endCameraSession}
                    className="p-2.5 rounded-xl bg-rose-600/90 hover:bg-rose-500 text-white shadow-md"
                    title="End Camera Session"
                  >
                    <PhoneOff className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            {/* Right: Captured Snapshot & Analysis Console */}
            <div className="rounded-2xl bg-[#111821] border border-[#283544] p-5 flex flex-col justify-between space-y-4 shadow-xl">
              <div>
                <div className="flex items-center justify-between border-b border-[#283544] pb-3 mb-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider font-mono">
                    <LorinCharacter
                      state={videoState === 'ANALYZING_FRAME' ? 'ANALYZING' : isCameraActive ? 'VISION_ACTIVE' : 'IDLE'}
                      presentation="compact"
                      environment="vision"
                      showStatus={false}
                      className="shrink-0"
                    />
                    <span>Multimodal Vision Console</span>
                  </div>
                  <span className="text-[11px] font-mono text-[#738297]">
                    {capturedSnapshot ? 'Frame Captured' : 'Awaiting Frame'}
                  </span>
                </div>

                {capturedSnapshot ? (
                  <div className="space-y-3">
                    <div className="relative rounded-lg overflow-hidden border border-[#3A4B5F] aspect-video bg-black">
                      <img src={capturedSnapshot} alt="Captured frame" className="w-full h-full object-contain" />
                      <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/70 text-[10px] font-mono text-[#66E3CB]">
                        Ready for Inference
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono text-[#A2AFBF] mb-1">Visual Query</label>
                      <input
                        type="text"
                        value={analysisPrompt}
                        onChange={(e) => setAnalysisPrompt(e.target.value)}
                        className="w-full bg-[#17212C] border border-[#283544] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#66E3CB]"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="p-4 text-center text-xs text-[#738297] space-y-3 border border-dashed border-[#283544] rounded-xl flex flex-col items-center">
                    <LorinCharacter
                      state={videoState === 'ANALYZING_FRAME' ? 'ANALYZING' : isCameraActive ? 'VISION_ACTIVE' : 'IDLE'}
                      presentation="standard"
                      environment="vision"
                      showControls={true}
                    />
                    <div>Click "Capture Snapshot" on the camera preview to grab a frame for visual analysis.</div>
                    <div className="text-[10px] text-[#A2AFBF]">Frames are only sent when you explicitly trigger analysis.</div>
                  </div>
                )}
              </div>

              {capturedSnapshot && (
                <div className="pt-2 border-t border-[#283544]">
                  <button
                    onClick={handleSendSnapshotForAnalysis}
                    disabled={isProcessing}
                    className="w-full py-2.5 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] disabled:opacity-40 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                  >
                    {isProcessing ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Analyzing with LORIN Vision...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Run Visual Analysis</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Analysis Result Output */}
          {analysisResult && (
            <div className="p-5 rounded-2xl bg-[#17212C] border border-[#3A4B5F] space-y-3">
              <div className="flex items-center justify-between border-b border-[#283544] pb-2">
                <span className="text-xs font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#A9B8FF]" />
                  <span>LORIN Vision Analysis Report</span>
                </span>
                <span className="text-[11px] font-mono text-[#66E3CB]">Evaluated</span>
              </div>
              <div className="text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
                {analysisResult}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
