import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  ShieldCheck, 
  ShieldAlert, 
  Key, 
  Check, 
  X, 
  AlertOctagon, 
  Download, 
  RefreshCw, 
  Sliders, 
  Lock,
  Trash2,
  Terminal,
  Plus,
  Mail,
  UserCheck
} from 'lucide-react';
import { ActionRequest, ApprovalRecord, AuditEvent, PolicyDecision, Principal, isSuperAdminOrOwnerPrincipal, isSystemOwnerPrincipal, normalizeCanonicalRole } from '../types/lorin';
import { PolicyEngine } from '../services/policyEngine';
import { auth } from '../services/firebase';

interface SecurityDashboardProps {
  principal: Principal;
  auditEvents: AuditEvent[];
  pendingApprovals: ApprovalRecord[];
  allApprovals: ApprovalRecord[];
  onRefreshData: () => void;
}

export const SecurityDashboard: React.FC<SecurityDashboardProps> = ({
  principal,
  auditEvents,
  pendingApprovals,
  allApprovals,
  onRefreshData,
}) => {
  // Simulator State
  const [testAction, setTestAction] = useState('deploy_production');
  const [testResource, setTestResource] = useState('services://lorin-core/production');
  const [testRiskLevel, setTestRiskLevel] = useState<'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'>('HIGH');
  const [testParamString, setTestParamString] = useState('{"version": "1.2.0", "targetCluster": "prod-eu"}');
  const [simulateBypassFlag, setSimulateBypassFlag] = useState(false);
  const [simResult, setSimResult] = useState<{
    decision: PolicyDecision;
    reason: string;
    digest: string;
    approvalRecord?: ApprovalRecord;
  } | null>(null);

  // Filter state for audit logs
  const [auditFilter, setAuditFilter] = useState<'ALL' | PolicyDecision>('ALL');

  // Multiple Owner Email Management State
  const [ownerEmails, setOwnerEmails] = useState<string[]>([]);
  const [primaryOwner, setPrimaryOwner] = useState('');
  const [newOwnerEmail, setNewOwnerEmail] = useState('');
  const [emailStatus, setEmailStatus] = useState<string | null>(null);

  const fetchOwnerEmails = async () => {
    try {
      const user = auth.currentUser;
      if (!user) return;
      const token = await user.getIdToken();
      const res = await fetch('/api/owner/emails', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setOwnerEmails(data.emails || []);
        setPrimaryOwner(data.primaryOwner || '');
      }
    } catch {
      // Ignore
    }
  };

  useEffect(() => {
    if (isSystemOwnerPrincipal(principal)) {
      fetchOwnerEmails();
    }
  }, [principal.role, principal.canonicalRole]);

  const handleAddOwnerEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOwnerEmail || !newOwnerEmail.includes('@')) return;
    setEmailStatus(null);
    try {
      const user = auth.currentUser;
      if (!user) return;
      const token = await user.getIdToken();
      const res = await fetch('/api/owner/emails', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ email: newOwnerEmail.trim().toLowerCase() })
      });
      const data = await res.json();
      if (res.ok) {
        setOwnerEmails(data.emails || []);
        setNewOwnerEmail('');
        setEmailStatus(`Successfully added ${newOwnerEmail}`);
      } else {
        setEmailStatus(`Error: ${data.message || 'Failed to add owner email.'}`);
      }
    } catch (err: any) {
      setEmailStatus(`Error: ${err.message}`);
    }
  };

  const handleRemoveOwnerEmail = async (email: string) => {
    if (!confirm(`Remove ${email} from authorized owner emails?`)) return;
    setEmailStatus(null);
    try {
      const user = auth.currentUser;
      if (!user) return;
      const token = await user.getIdToken();
      const res = await fetch('/api/owner/emails', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (res.ok) {
        setOwnerEmails(data.emails || []);
        setEmailStatus(`Removed ${email}`);
      } else {
        setEmailStatus(`Error: ${data.message || 'Failed'}`);
      }
    } catch (err: any) {
      setEmailStatus(`Error: ${err.message}`);
    }
  };

  const handleRunPolicySimulation = async () => {
    let parsedParams = {};
    try {
      parsedParams = JSON.parse(testParamString);
    } catch {
      parsedParams = { raw: testParamString };
    }

    const request: ActionRequest = {
      id: `sim_act_${Date.now()}`,
      action: testAction,
      resource: testResource,
      description: 'Simulated action from Security Console',
      riskLevel: testRiskLevel,
      requiredScope: testRiskLevel === 'CRITICAL' ? 'admin:critical' : 'deploy:write',
      parameters: parsedParams
    };

    const flags = simulateBypassFlag ? { user_authorized: true, bypass_policy: true } : undefined;
    const result = await PolicyEngine.evaluateAction(principal, request, flags);
    setSimResult(result);
    onRefreshData();
  };

  const isOwnerAccount = isSystemOwnerPrincipal(principal);
  const isSuperAdminOrOwner = isSuperAdminOrOwnerPrincipal(principal);

  const handleApprove = async (approvalId: string) => {
    const res = await PolicyEngine.approveAction(approvalId, principal);
    if (!res.success) {
      setEmailStatus(`Approval rejected: ${res.message}`);
    }
    onRefreshData();
  };

  const handleDeny = async (approvalId: string) => {
    await PolicyEngine.denyAction(approvalId, principal);
    onRefreshData();
  };

  const handleExportAuditJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(auditEvents, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `lorin_audit_stream_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleClearAuditLogs = () => {
    if (confirm('Clear audit event log? (Owner authenticated action)')) {
      PolicyEngine.clearAuditLogs(principal);
      onRefreshData();
    }
  };

  const filteredAuditEvents = auditEvents.filter(e => {
    if (auditFilter === 'ALL') return true;
    return e.decision === auditFilter;
  });

  return (
    <div className="lorin-module-page flex-1 overflow-y-auto bg-[#090d16] p-4 sm:p-6 space-y-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header Summary */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-400" />
              <h1 className="text-lg font-bold text-white tracking-tight">Phase 2 Security & Policy Engine</h1>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Deterministic server-enforced policy boundary, cryptographic action digests, and tamper-evident audit logging.
            </p>
          </div>
          <button
            onClick={onRefreshData}
            className="px-3 py-1.5 rounded bg-slate-900 border border-slate-800 hover:bg-slate-800 text-xs text-slate-300 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh State</span>
          </button>
        </div>

        {/* Top Grid: Authenticated Principal Context + Policy Invariants */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Principal Context Card */}
          <div className="p-4 rounded-lg bg-[#0e1626] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                Authenticated Principal
              </span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                principal.authenticated
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                  : 'bg-amber-500/10 text-amber-300 border-amber-500/20'
              }`}>
                {principal.authenticated ? 'VERIFIED' : 'GUEST / UNAUTH'}
              </span>
            </div>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Principal ID:</span>
                <span className="font-mono text-slate-200">{principal.id}</span>
              </div>
              <div className="flex justify-between text-slate-400 items-center">
                <span>Active Role:</span>
                <span className="font-mono text-sky-400" aria-label="Role assigned by the server">
                  {normalizeCanonicalRole(principal.canonicalRole || principal.role)}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Canonical Role:</span>
                <span className="text-teal-400 font-mono font-bold">{normalizeCanonicalRole(principal.canonicalRole || principal.role)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Account Status:</span>
                <span className="text-emerald-400 font-mono">{principal.accountStatus || 'ACTIVE'} (TLS 1.3)</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Assigned Scopes:</span>
                <span className="font-mono text-slate-300 truncate max-w-[170px]">{principal.scopes.join(', ')}</span>
              </div>
            </div>
          </div>

          {/* Policy Invariants & Boundary Status */}
          <div className="p-4 rounded-lg bg-[#0e1626] border border-slate-800 space-y-3">
            <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
              Policy Invariants
            </div>
            <ul className="space-y-1.5 text-xs text-slate-300">
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Deny-by-default access control</span>
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Client <code className="text-amber-300">user_authorized</code> bypass rejected</span>
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Action-bound SHA-256 digest validation</span>
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Single-use execution token consumption</span>
              </li>
            </ul>
          </div>

          {/* Action Approval Status Summary */}
          <div className="p-4 rounded-lg bg-[#0e1626] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                Approvals Queue
              </span>
              <span className="text-xs font-mono text-amber-400 font-bold tabular-nums">
                {pendingApprovals.length} Pending
              </span>
            </div>
            <p className="text-xs text-slate-400">
              High-impact operations require owner authorization before tool invocation. Single-use tokens expire after 15 minutes.
            </p>
            <div className="pt-1 flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>Total Recorded: {allApprovals.length}</span>
              <span>Audit Entries: {auditEvents.length}</span>
            </div>
          </div>
        </div>

        {/* Section: Authorized Owner Email Registry */}
        {isSystemOwnerPrincipal(principal) && (
          <div className="p-5 rounded-lg bg-[#0e1626] border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-teal-400" />
                <h2 className="text-sm font-semibold text-white">Authorized Owner Email Registry</h2>
              </div>
              <span className="text-xs font-mono text-slate-400 font-bold">{ownerEmails.length} Configured Emails</span>
            </div>

            <p className="text-xs text-slate-400">
              Configure additional verified email addresses authorized for LORIN Owner access. All added accounts receive full verified Owner permissions.
            </p>

            {emailStatus && (
              <div className={`p-2.5 rounded text-xs font-mono border ${
                emailStatus.startsWith('Error')
                  ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                  : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              }`}>
                {emailStatus}
              </div>
            )}

            <form onSubmit={handleAddOwnerEmail} className="flex gap-2 max-w-lg">
              <input
                type="email"
                value={newOwnerEmail}
                onChange={(e) => setNewOwnerEmail(e.target.value)}
                placeholder="Add new owner email address..."
                className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-slate-200 placeholder-slate-500 font-mono focus:outline-none focus:border-teal-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Owner</span>
              </button>
            </form>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1">
              {ownerEmails.map((email) => {
                const isPrimary = Boolean(primaryOwner) && email.toLowerCase() === primaryOwner.toLowerCase();
                return (
                  <div key={email} className="p-2.5 rounded bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-2 truncate">
                      <UserCheck className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <span className="text-slate-200 truncate">{email}</span>
                      {isPrimary && (
                        <span className="px-1.5 py-0.2 text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded shrink-0">
                          PRIMARY
                        </span>
                      )}
                    </div>
                    {!isPrimary && (
                      <button
                        onClick={() => handleRemoveOwnerEmail(email)}
                        className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                        title="Remove owner"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Section: Interactive Policy Evaluation Simulator */}
        <div className="p-5 rounded-lg bg-[#0e1626] border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-sky-400" />
              <h2 className="text-sm font-semibold text-white">Interactive Policy Evaluation Simulator</h2>
            </div>
            <span className="text-xs font-mono text-slate-500">Test deterministic boundaries</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            {/* Action Select */}
            <div>
              <label className="block text-slate-400 mb-1 font-mono">Action Name</label>
              <select
                value={testAction}
                onChange={(e) => setTestAction(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 px-3 py-2 rounded font-mono text-xs focus:border-sky-500 focus:outline-none"
              >
                <option value="deploy_production">deploy_production (High)</option>
                <option value="purge_database">purge_database (Critical)</option>
                <option value="modify_permissions">modify_permissions (High)</option>
                <option value="read_audit_logs">read_audit_logs (Low)</option>
                <option value="write_code">write_code (Medium)</option>
                <option value="execute_shell">execute_shell (Critical)</option>
              </select>
            </div>

            {/* Target Resource */}
            <div>
              <label className="block text-slate-400 mb-1 font-mono">Target Resource</label>
              <input
                type="text"
                value={testResource}
                onChange={(e) => setTestResource(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 px-3 py-2 rounded font-mono text-xs focus:border-sky-500 focus:outline-none"
              />
            </div>

            {/* Risk Level */}
            <div>
              <label className="block text-slate-400 mb-1 font-mono">Risk Level</label>
              <select
                value={testRiskLevel}
                onChange={(e) => setTestRiskLevel(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 px-3 py-2 rounded font-mono text-xs focus:border-sky-500 focus:outline-none"
              >
                <option value="LOW">LOW</option>
                <option value="MEDIUM">MEDIUM</option>
                <option value="HIGH">HIGH (Requires Approval)</option>
                <option value="CRITICAL">CRITICAL (Requires Approval)</option>
              </select>
            </div>

            {/* Action Parameters */}
            <div>
              <label className="block text-slate-400 mb-1 font-mono">JSON Parameters</label>
              <input
                type="text"
                value={testParamString}
                onChange={(e) => setTestParamString(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 px-3 py-2 rounded font-mono text-xs focus:border-sky-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Adversarial Testing Toggle */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={simulateBypassFlag}
                onChange={(e) => setSimulateBypassFlag(e.target.checked)}
                className="rounded border-slate-700 bg-slate-900 text-sky-500 focus:ring-0"
              />
              <span className="text-slate-400">Simulate Adversarial Bypass: Inject caller-supplied </span>
              <code className="text-amber-300 bg-slate-900 px-1 py-0.5 rounded border border-slate-800">
                user_authorized = true
              </code>
            </label>

            <button
              onClick={handleRunPolicySimulation}
              className="px-4 py-2 rounded bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold text-xs transition-colors"
            >
              Evaluate Policy Decision
            </button>
          </div>

          {/* Simulation Output Card */}
          {simResult && (
            <div className={`p-4 rounded-lg border text-xs space-y-2 mt-3 font-mono ${
              simResult.decision === 'ALLOW' ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200' :
              simResult.decision === 'REQUIRES_APPROVAL' ? 'bg-amber-950/30 border-amber-500/40 text-amber-200' :
              'bg-rose-950/30 border-rose-500/40 text-rose-200'
            }`}>
              <div className="flex items-center justify-between font-bold text-sm">
                <div className="flex items-center gap-2">
                  {simResult.decision === 'ALLOW' && <Check className="w-4 h-4 text-emerald-400" />}
                  {simResult.decision === 'REQUIRES_APPROVAL' && <Lock className="w-4 h-4 text-amber-400" />}
                  {simResult.decision === 'DENY' && <AlertOctagon className="w-4 h-4 text-rose-400" />}
                  <span>DECISION: {simResult.decision}</span>
                </div>
                <span className="text-[11px] font-normal text-slate-400">
                  Evaluated at {new Date().toLocaleTimeString()}
                </span>
              </div>
              <p className="text-xs text-slate-200">{simResult.reason}</p>
              <div className="pt-1 text-[11px] text-slate-400 break-all">
                <span>Cryptographic Digest: </span>
                <span className="text-sky-300">{simResult.digest}</span>
              </div>
            </div>
          )}
        </div>

        {/* Section: Action Approvals Queue */}
        <div className="p-5 rounded-lg bg-[#0e1626] border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Key className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-semibold text-white">Action-Bound Approvals Queue ({allApprovals.length})</h2>
            </div>
            <span className="text-xs font-mono text-slate-500">Single-use Cryptographic Tokens</span>
          </div>

          {allApprovals.length === 0 ? (
            <div className="text-center py-6 text-xs text-slate-500 font-mono">
              No action approval records currently registered. Trigger high-risk actions to generate tokens.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                    <th className="py-2 px-3">Status</th>
                    <th className="py-2 px-3">Action</th>
                    <th className="py-2 px-3">Target Resource</th>
                    <th className="py-2 px-3">Digest (SHA-256)</th>
                    <th className="py-2 px-3">Expiry</th>
                    <th className="py-2 px-3 text-right">Owner Control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {allApprovals.map((app) => (
                    <tr key={app.id} className="hover:bg-slate-900/40">
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          app.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                          app.status === 'PENDING' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                          app.status === 'DENIED' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                          'bg-slate-800 text-slate-400'
                        }`}>
                          {app.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-white">{app.action}</td>
                      <td className="py-2.5 px-3 text-slate-400 max-w-[200px] truncate" title={app.resource}>{app.resource}</td>
                      <td className="py-2.5 px-3 text-sky-400 text-[11px] max-w-[140px] truncate" title={app.actionDigest}>
                        {app.actionDigest.slice(0, 12)}...
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] tabular-nums">
                        {app.expiresAt > Date.now() ? `${Math.round((app.expiresAt - Date.now()) / 1000 / 60)}m left` : 'Expired'}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {app.status === 'PENDING' && app.expiresAt > Date.now() ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleDeny(app.id)}
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px]"
                            >
                              Deny
                            </button>
                            <button
                              onClick={() => handleApprove(app.id)}
                              disabled={principal.role !== 'OWNER'}
                              className="px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-bold text-[11px]"
                            >
                              Sign
                            </button>
                          </div>
                        ) : (
                          <span className="text-slate-600 text-[11px]">Closed</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Section: Tamper-Evident Audit Stream */}
        <div className="p-5 rounded-lg bg-[#0e1626] border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <h2 className="text-sm font-semibold text-white">Tamper-Evident Audit Event Stream</h2>
            </div>

            <div className="flex items-center gap-2 text-xs">
              {/* Filter */}
              <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 font-mono text-[11px]">
                {(['ALL', 'ALLOW', 'DENY', 'REQUIRES_APPROVAL'] as const).map(mode => (
                  <button
                    key={mode}
                    onClick={() => setAuditFilter(mode)}
                    className={`px-2 py-0.5 rounded transition-colors ${
                      auditFilter === mode ? 'bg-slate-800 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>

              {/* Actions */}
              <button
                onClick={handleExportAuditJson}
                className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center gap-1 font-mono text-[11px]"
              >
                <Download className="w-3 h-3" />
                <span>Export JSON</span>
              </button>

              {principal.role === 'OWNER' && (
                <button
                  onClick={handleClearAuditLogs}
                  className="px-2.5 py-1 rounded bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 text-rose-300 flex items-center gap-1 font-mono text-[11px]"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Clear</span>
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto max-h-80 overflow-y-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="sticky top-0 bg-[#0e1626] border-b border-slate-800 text-slate-400 text-[11px]">
                <tr>
                  <th className="py-2 px-3">Timestamp</th>
                  <th className="py-2 px-3">Role</th>
                  <th className="py-2 px-3">Decision</th>
                  <th className="py-2 px-3">Action</th>
                  <th className="py-2 px-3">Target Resource</th>
                  <th className="py-2 px-3">Reason / Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-slate-300">
                {filteredAuditEvents.map((evt) => (
                  <tr key={evt.id} className="hover:bg-slate-900/40 text-[11px]">
                    <td className="py-2 px-3 text-slate-400 tabular-nums">
                      {new Date(evt.timestamp).toLocaleTimeString()}
                    </td>
                    <td className="py-2 px-3">
                      <span className="text-slate-400 font-semibold">{evt.role}</span>
                    </td>
                    <td className="py-2 px-3">
                      <span className={`px-1.5 py-0.2 rounded font-semibold ${
                        evt.decision === 'ALLOW' ? 'text-emerald-400 bg-emerald-500/10' :
                        evt.decision === 'REQUIRES_APPROVAL' ? 'text-amber-400 bg-amber-500/10' :
                        'text-rose-400 bg-rose-500/10'
                      }`}>
                        {evt.decision}
                      </span>
                    </td>
                    <td className="py-2 px-3 font-semibold text-white">{evt.action}</td>
                    <td className="py-2 px-3 text-slate-400 max-w-[180px] truncate" title={evt.resource}>
                      {evt.resource}
                    </td>
                    <td className="py-2 px-3 text-slate-400 max-w-[260px] truncate" title={evt.reason}>
                      {evt.reason}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
