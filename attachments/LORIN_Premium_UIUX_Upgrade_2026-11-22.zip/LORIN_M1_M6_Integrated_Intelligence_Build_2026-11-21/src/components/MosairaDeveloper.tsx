import React, { useEffect, useState } from 'react';
import { ApiKeyService } from '../services/apiKeyService';
import { MosairaApiKey } from '../types/mosaira';
import { Key, Plus, Trash2, ShieldAlert, Code, Check, Copy } from 'lucide-react';

export const MosairaDeveloper: React.FC = () => {
  const [keys, setKeys] = useState<MosairaApiKey[]>(ApiKeyService.getKeys());
  const [newKeyName, setNewKeyName] = useState('');
  const [createdFullKey, setCreatedFullKey] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    ApiKeyService.syncFromServer().then(setKeys);
  }, []);

  const handleCreateKey = async () => {
    if (!newKeyName.trim() || isSaving) return;
    setIsSaving(true);
    setErrorMessage(null);
    try {
      const { fullKey } = await ApiKeyService.generateKeyOnServer(newKeyName.trim());
      setKeys(ApiKeyService.getKeys());
      setCreatedFullKey(fullKey);
      setNewKeyName('');
    } catch (error: any) {
      setErrorMessage(error.message || 'The server could not create a developer key.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRevokeKey = async (id: string) => {
    setErrorMessage(null);
    try {
      if (!await ApiKeyService.revokeKey(id)) throw new Error('The server rejected key revocation.');
      setKeys(ApiKeyService.getKeys());
    } catch (error: any) {
      setErrorMessage(error.message || 'The server could not revoke this key.');
    }
  };

  const handleCopyKey = (keyStr: string) => {
    navigator.clipboard.writeText(keyStr);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Key className="w-6 h-6 text-indigo-500" />
          Developer Portal & BYOK Key Management
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Manage developer API keys for programmatic access and Bring-Your-Own-Key (BYOK) inference.
        </p>
      </div>

      {/* Security Warning Notice */}
      <div className="p-3.5 bg-indigo-50/50 dark:bg-indigo-950/20 rounded-xl border border-indigo-100 dark:border-indigo-900/40 flex items-start gap-3 text-xs">
        <ShieldAlert className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold text-slate-900 dark:text-slate-100">Zero-Trust Credential Security Policy</span>
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
            API secret keys are displayed once upon generation. The server stores a one-way hash for verification; key creation and revocation require an authenticated system owner.
          </p>
        </div>
      </div>

      {/* Key Generation Section */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
        <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">Generate New Developer Key</h2>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            placeholder="Key Description (e.g. Production Microservice, Research Script)..."
            value={newKeyName}
            onChange={e => setNewKeyName(e.target.value)}
            className="flex-1 px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={handleCreateKey}
            disabled={!newKeyName.trim() || isSaving}
            className="py-2 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 shrink-0"
          >
            <Plus className="w-4 h-4" />
            {isSaving ? 'Saving…' : 'Generate Secret Key'}
          </button>
        </div>
        {errorMessage && <p role="alert" className="text-xs text-rose-500">{errorMessage}</p>}

        {createdFullKey && (
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 rounded-lg space-y-1.5 text-xs">
            <span className="font-bold text-emerald-800 dark:text-emerald-300">Key Created Successfully!</span>
            <p className="text-emerald-700 dark:text-emerald-400 text-[11px]">
              Copy this secret key immediately. You will not be able to view it again.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <code className="flex-1 p-2 bg-white dark:bg-slate-950 border border-emerald-300 dark:border-emerald-800 rounded text-emerald-900 dark:text-emerald-200 font-mono text-[11px]">
                {createdFullKey}
              </code>
              <button
                onClick={() => handleCopyKey(createdFullKey)}
                className="p-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded flex items-center gap-1 shrink-0"
              >
                {copiedKey ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Existing Keys Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">Active Developer Credentials</h2>
          <span className="text-xs text-slate-500 font-mono tabular-nums">{keys.filter(k => k.status === 'ACTIVE').length} Active</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 font-semibold text-slate-900 dark:text-slate-100">
              <tr>
                <th className="p-3">Key Prefix</th>
                <th className="p-3">Description</th>
                <th className="p-3">Rate Limit</th>
                <th className="p-3">Status</th>
                <th className="p-3">Created</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {keys.map(k => (
                <tr key={k.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                  <td className="p-3 font-mono font-medium text-slate-900 dark:text-slate-100">{k.keyPrefix}</td>
                  <td className="p-3 font-medium">{k.name}</td>
                  <td className="p-3 font-mono tabular-nums">{k.rateLimitRpm} RPM</td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                      k.status === 'ACTIVE'
                        ? 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400'
                        : 'bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-400'
                    }`}>
                      {k.status}
                    </span>
                  </td>
                  <td className="p-3 font-mono tabular-nums text-slate-500">{new Date(k.createdAt).toLocaleDateString()}</td>
                  <td className="p-3 text-right">
                    {k.status === 'ACTIVE' && (
                      <button
                        onClick={() => handleRevokeKey(k.id)}
                        className="p-1.5 text-rose-600 hover:text-rose-700 dark:text-rose-400 dark:hover:text-rose-300 rounded hover:bg-rose-50 dark:hover:bg-rose-950/30"
                        title="Revoke Key"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Code Snippet Example */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
        <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
          <Code className="w-4 h-4 text-indigo-500" />
          API Integration Snippet
        </h2>
        <pre className="p-3 bg-slate-950 text-slate-200 rounded-lg text-[11px] font-mono overflow-x-auto whitespace-pre">
{`// Example API Request to MOSAIRA Public Inference Endpoint
const response = await fetch('https://mosaira.ai/api/v1/inference', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer msra_your_api_key_here'
  },
  body: JSON.stringify({
    personaId: 'SAGE',
    prompt: 'Provide a structured comparison of Rust vs Go for backend microservices.'
  })
});

const data = await response.json();
console.log(data.rawResponse);`}
        </pre>
      </div>
    </div>
  );
};
