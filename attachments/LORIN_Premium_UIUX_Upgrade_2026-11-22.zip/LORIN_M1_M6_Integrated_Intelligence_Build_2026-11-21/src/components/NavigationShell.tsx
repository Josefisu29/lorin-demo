import React, { useState, useEffect } from 'react';
import { PWAInstallButton } from './PWAInstallButton';
import { Sparkles, Lock, ShieldCheck, Layers } from 'lucide-react';
import { Principal, isSuperAdminOrOwnerPrincipal, normalizeCanonicalRole } from '../types/lorin';
import { StealthService } from '../services/stealthService';
import { LorinCharacter } from './LorinCharacter';
import { CharacterPresentation, LorinCharacterState } from '../services/lorinPresence';

export type PublicTab = 'discovery' | 'playground' | 'comparison' | 'commons' | 'datasetLab' | 'developer' | 'laurenPrivate';

interface Props {
  activeTab: PublicTab;
  onTabChange: (tab: PublicTab) => void;
  principal: Principal;
  characterState: LorinCharacterState;
  characterPresentation: CharacterPresentation;
  onOpenSecretLorinPortal: () => void;
  onOpenImmersiveHologram?: () => void;
}

export const NavigationShell: React.FC<Props> = ({
  activeTab,
  onTabChange,
  principal,
  characterState,
  characterPresentation,
  onOpenSecretLorinPortal,
  onOpenImmersiveHologram
}) => {
  const isPrivateActive = activeTab === 'laurenPrivate';
  const canonicalRole = normalizeCanonicalRole(principal.canonicalRole || principal.role);
  const isOwner = principal.authenticated && principal.accountStatus !== 'DISABLED' && principal.accountStatus !== 'REVOKED' && (
    isSuperAdminOrOwnerPrincipal(principal) || canonicalRole !== 'RESTRICTED'
  );
  const [isStealth, setIsStealth] = useState(StealthService.isStealthEnabled());

  useEffect(() => {
    return StealthService.subscribe((enabled) => {
      setIsStealth(enabled);
    });
  }, []);

  // Stealth multi-click trigger on brand logo
  const [clickCount, setClickCount] = useState(0);
  const handleBrandClick = (e: React.MouseEvent) => {
    e.preventDefault();
    const newCount = clickCount + 1;
    setClickCount(newCount);

    if (newCount >= 3) {
      setClickCount(0);
      onOpenSecretLorinPortal();
    } else {
      onTabChange('discovery');
      setTimeout(() => setClickCount(0), 1500);
    }
  };

  return (
    <header className="lorin-global-header sticky top-0 z-40 bg-[var(--lorin-surface-1)] border-b border-[var(--lorin-border)] transition-colors">
      {isPrivateActive ? (
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 flex items-center justify-between gap-6 h-14">
          {/* Zone 1: Single Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <LorinCharacter
              state={characterState}
              presentation="compact"
              showStatus={false}
              className="shrink-0"
            />
            <span className="font-bold text-sm tracking-tight text-white whitespace-nowrap">
              {isStealth ? 'Operations Console' : 'LORIN'}
            </span>
            <span className="text-sm text-[var(--lorin-text-muted)] hidden sm:inline">
              {characterPresentation === 'expanded' ? 'Voice workspace' : characterPresentation === 'workspace' ? 'Focused workspace' : 'Personal intelligence'}
            </span>
          </div>

          {/* Zone 2: Action & App Switcher */}
          <div className="flex items-center gap-2.5 shrink-0">
            {onOpenImmersiveHologram && (
              <button
                type="button"
                onClick={onOpenImmersiveHologram}
                className="px-3 py-1.5 text-xs font-mono font-semibold rounded-lg bg-[#17212C] hover:bg-[#1E2C3A] text-[#66E3CB] border border-[#3A4B5F] transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                title="Open LORIN’s dedicated immersive character experience"
              >
                <Layers className="w-3.5 h-3.5 text-[#66E3CB]" />
                <span>Immersive Stage</span>
              </button>
            )}
            <PWAInstallButton />
            <button
              onClick={() => onTabChange('discovery')}
              className="px-3 py-2 text-sm font-medium rounded-lg bg-[var(--lorin-surface-2)] hover:bg-[var(--lorin-surface-3)] text-[var(--lorin-text-muted)] hover:text-[var(--lorin-text)] border border-[var(--lorin-border)] transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap"
              title="Open the separate MOSAIRA platform. LORIN private data and owner permissions are not shared."
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">MOSAIRA Platform</span>
            </button>
          </div>
        </div>
      ) : (
        /* MOSAIRA PUBLIC PLATFORM HEADER */
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Brand Wordmark (Multi-click stealth trigger) */}
          <a
            href="/"
            onClick={handleBrandClick}
            className="text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap shrink-0 flex items-center gap-2 select-none"
            title="MOSAIRA Ecosystem"
          >
            <Sparkles className="w-5 h-5 text-indigo-500" />
            <span>MOSAIRA</span>
          </a>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-600 dark:text-slate-300">
            <button
              onClick={() => onTabChange('discovery')}
              className={`whitespace-nowrap shrink-0 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${
                activeTab === 'discovery' ? 'text-indigo-600 dark:text-indigo-400 font-bold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Discover Personas
            </button>
            <button
              onClick={() => onTabChange('playground')}
              className={`whitespace-nowrap shrink-0 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${
                activeTab === 'playground' ? 'text-indigo-600 dark:text-indigo-400 font-bold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Playground
            </button>
            <button
              onClick={() => onTabChange('comparison')}
              className={`whitespace-nowrap shrink-0 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${
                activeTab === 'comparison' ? 'text-indigo-600 dark:text-indigo-400 font-bold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Compare Models
            </button>
            <button
              onClick={() => onTabChange('commons')}
              className={`whitespace-nowrap shrink-0 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${
                activeTab === 'commons' ? 'text-indigo-600 dark:text-indigo-400 font-bold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Knowledge Commons
            </button>
            <button
              onClick={() => onTabChange('datasetLab')}
              className={`whitespace-nowrap shrink-0 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${
                activeTab === 'datasetLab' ? 'text-indigo-600 dark:text-indigo-400 font-bold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Dataset Lab
            </button>
            <button
              onClick={() => onTabChange('developer')}
              className={`whitespace-nowrap shrink-0 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer ${
                activeTab === 'developer' ? 'text-indigo-600 dark:text-indigo-400 font-bold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Developer API
            </button>
          </nav>

          {/* Zone 3: Primary Action & LORIN Live Workbench Switcher */}
          <div className="flex items-center gap-3 shrink-0">
            <PWAInstallButton />

            {!isOwner ? (
              <button
                onClick={onOpenSecretLorinPortal}
                aria-label="Activate LORIN Workbench"
                className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-teal-600 hover:bg-teal-700 text-white transition-all flex items-center gap-1.5 shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
                title="Activate LORIN Private Workbench"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-teal-200" />
                <span>Activate LORIN Live</span>
              </button>
            ) : (
              <button
                onClick={() => onTabChange('laurenPrivate')}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-teal-600 hover:bg-teal-700 text-white transition-all flex items-center gap-1.5 shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-teal-200" />
                <span>Enter LORIN Workbench</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
