import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  Lock, 
  FileText, 
  FolderPlus, 
  Search, 
  Cpu, 
  Download, 
  Upload, 
  Sparkles, 
  Key, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  ArrowLeft,
  ChevronRight,
  Info,
  ExternalLink,
  Sliders,
  Send,
  Eye
} from 'lucide-react';
import { Principal } from '../../types/lorin';
import { 
  LaurenDocument, 
  KnowledgeCollection, 
  LaurenSourceCitation, 
  LocalOllamaModel 
} from '../../types/laurenVault';
import { LaurenVaultService } from '../../services/laurenVaultService';
import { VaultStore } from '../../services/vaultStore';
import { GoogleDriveService, GoogleDriveFile } from '../../services/googleDriveService';

interface Props {
  principal: Principal;
  onSwitchToMosairaLab?: () => void;
}

export type VaultTab = 'documents' | 'collections' | 'askLauren' | 'localModels';

export const LaurenVaultHub: React.FC<Props> = ({ principal, onSwitchToMosairaLab }) => {
  const [activeTab, setActiveTab] = useState<VaultTab>('askLauren');
  const [documents, setDocuments] = useState<LaurenDocument[]>([]);
  const [collections, setCollections] = useState<KnowledgeCollection[]>([]);

  // Ask Lauren RAG State
  const [queryInput, setQueryInput] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{
    query: string;
    answer: string;
    citations: LaurenSourceCitation[];
    timestamp: number;
    latencyMs: number;
  }>>([
    {
      query: 'What are the core directives of the zero-trust policy engine?',
      answer: 'Based on your private documents in the vault, I located relevant verified references in "Master Architecture & Security Directives".\n\nEnforce server-side authorization on all consequential state transitions. No client-supplied role or hidden URL can bypass authorization.\n\nAll state mutations are checked with replay protection before execution.',
      citations: [
        {
          docId: 'doc_priv_001',
          docTitle: 'Master Architecture & Security Directives',
          chunkId: 'chk_001_2',
          snippet: 'Enforce server-side authorization on all consequential state transitions. No client-supplied role or hidden URL can bypass authorization.',
          similarityScore: 0.96,
          reasonUsed: "Matched 4 key architectural query terms: ['zero-trust', 'policy-engine', 'authorization', 'server-side'] with 96% semantic relevance."
        }
      ],
      timestamp: Date.now() - 3600000,
      latencyMs: 38
    }
  ]);
  const [isQuerying, setIsQuerying] = useState(false);
  const [activeCitationDrawer, setActiveCitationDrawer] = useState<LaurenSourceCitation | null>(null);

  // Local Ollama State
  const [ollamaModels, setOllamaModels] = useState<LocalOllamaModel[]>([]);
  const [ollamaReachable, setOllamaReachable] = useState(false);
  const [isProbingOllama, setIsProbingOllama] = useState(false);
  const [ollamaLatency, setOllamaLatency] = useState(0);

  // New Document Modal
  const [isNewDocModalOpen, setIsNewDocModalOpen] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocContent, setNewDocContent] = useState('');
  const [newDocLevel, setNewDocLevel] = useState<'CONFIDENTIAL' | 'PROJECT_SECRET' | 'PERSONAL'>('CONFIDENTIAL');

  // Google Drive Modal
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [driveFiles, setDriveFiles] = useState<GoogleDriveFile[]>([]);
  const [driveConnected, setDriveConnected] = useState(false);
  const [isScanningDrive, setIsScanningDrive] = useState(false);

  // AES-256-GCM Encrypted Backup Modal
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [backupPassphrase, setBackupPassphrase] = useState('');
  const [isEncryptingBackup, setIsEncryptingBackup] = useState(false);
  const [backupStatusMsg, setBackupStatusMsg] = useState<string | null>(null);

  const loadData = () => {
    setDocuments(LaurenVaultService.getDocuments());
    setCollections(LaurenVaultService.getCollections());
  };

  useEffect(() => {
    LaurenVaultService.syncFromVaultStore(VaultStore.getDocuments());
    loadData();
    VaultStore.syncFromBackend().then(() => {
      LaurenVaultService.syncFromVaultStore(VaultStore.getDocuments());
      loadData();
    });
    probeOllama();
  }, []);

  const probeOllama = async () => {
    setIsProbingOllama(true);
    const res = await LaurenVaultService.probeLocalOllama();
    setOllamaReachable(res.reachable);
    setOllamaModels(res.models);
    setOllamaLatency(res.latencyMs);
    setIsProbingOllama(false);
  };

  const handleSendQuery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!queryInput.trim() || isQuerying) return;

    setIsQuerying(true);
    const res = LaurenVaultService.queryPrivateKnowledge(queryInput.trim());

    setChatHistory(prev => [
      ...prev,
      {
        query: queryInput.trim(),
        answer: res.answer,
        citations: res.citations,
        timestamp: Date.now(),
        latencyMs: res.latencyMs
      }
    ]);

    setQueryInput('');
    setIsQuerying(false);
  };

  const handleCreateDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim() || !newDocContent.trim()) return;

    const words = newDocContent.trim().split(/\s+/);
    const chunkSize = 50;
    const chunks = [];
    for (let i = 0; i < words.length; i += chunkSize) {
      chunks.push({
        id: `chk_${Date.now()}_${i}`,
        chunkIndex: Math.floor(i / chunkSize),
        text: words.slice(i, i + chunkSize).join(' '),
        tokenCount: Math.min(words.length - i, chunkSize)
      });
    }

    const doc: LaurenDocument = {
      id: `doc_priv_${Date.now()}`,
      title: newDocTitle.trim(),
      fileName: `${newDocTitle.trim().toLowerCase().replace(/\s+/g, '_')}.md`,
      fileType: 'text/markdown',
      sizeBytes: newDocContent.length,
      source: 'MANUAL_NOTE',
      importedAt: Date.now(),
      content: newDocContent,
      chunks,
      tags: ['private', 'owner'],
      confidentialLevel: newDocLevel
    };

    LaurenVaultService.addDocument(doc);
    loadData();
    setIsNewDocModalOpen(false);
    setNewDocTitle('');
    setNewDocContent('');
  };

  const handleOpenDriveImport = async () => {
    setIsDriveModalOpen(true);
    setIsScanningDrive(true);
    const status = await GoogleDriveService.scanDesignatedFolderWithStatus(undefined, true);
    setDriveConnected(status.connected);
    setDriveFiles(status.files);
    setIsScanningDrive(false);
  };

  const handleImportDriveFile = async (file: GoogleDriveFile) => {
    const doc: LaurenDocument = {
      id: `doc_gdrive_${Date.now()}`,
      title: file.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '),
      fileName: file.name,
      fileType: file.mimeType,
      sizeBytes: file.sizeBytes,
      source: 'GOOGLE_DRIVE',
      importedAt: Date.now(),
      content: file.contentSnippet || 'Private document content imported from Google Drive.',
      chunks: [
        {
          id: `chk_${Date.now()}_1`,
          chunkIndex: 0,
          text: file.contentSnippet || 'Private content snippet.',
          tokenCount: 42
        }
      ],
      tags: ['google_drive', 'personal'],
      confidentialLevel: 'CONFIDENTIAL',
      googleDriveFileId: file.id
    };

    LaurenVaultService.addDocument(doc);
    loadData();
    setIsDriveModalOpen(false);
  };

  const handleExportBackup = () => {
    setBackupStatusMsg(null);
    setIsBackupModalOpen(true);
  };

  const handleConfirmAesExport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!backupPassphrase || backupPassphrase.length < 8) {
      setBackupStatusMsg('Passphrase must be at least 8 characters for PBKDF2 / AES-256-GCM key derivation.');
      return;
    }
    setIsEncryptingBackup(true);
    try {
      const encryptedObj = await LaurenVaultService.exportAesGcmEncryptedBackup(backupPassphrase);
      const blob = new Blob([JSON.stringify(encryptedObj, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `lauren_vault_aes256gcm_${Date.now()}.enc.json`;
      a.click();
      URL.revokeObjectURL(url);
      setIsBackupModalOpen(false);
      setBackupPassphrase('');
    } catch (err: any) {
      setBackupStatusMsg(err?.message || 'Encryption failed');
    } finally {
      setIsEncryptingBackup(false);
    }
  };

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] text-[#F1F5F9] font-sans overflow-hidden">
      {/* Top Private Header */}
      <header className="px-6 py-4 bg-[#111821] border-b border-[#283544] flex flex-wrap items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-[#A9B8FF]">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-white tracking-tight">Lauren Private Knowledge Vault</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-[#A9B8FF] border border-indigo-500/30 font-semibold">
                CONFIDENTIAL & AIR-GAPPED
              </span>
            </div>
            <p className="text-xs text-[#A2AFBF] mt-0.5">
              Personal knowledge base, private RAG, local models & source-trace citations
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportBackup}
            className="px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] text-xs font-semibold text-[#A2AFBF] hover:text-white border border-[#3A4B5F] flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Download air-gapped encrypted backup"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Air-Gapped Backup</span>
          </button>

          {onSwitchToMosairaLab && (
            <button
              onClick={onSwitchToMosairaLab}
              className="px-3.5 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] text-xs font-semibold text-[#66E3CB] border border-[#3A4B5F] flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>MOSAIRA AI Lab</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </header>

      {/* Sub-Navigation */}
      <div className="px-6 bg-[#111821]/80 border-b border-[#283544] flex items-center gap-2 overflow-x-auto text-xs shrink-0 py-2">
        <button
          onClick={() => setActiveTab('askLauren')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'askLauren' ? 'bg-[#17212C] text-[#A9B8FF] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Ask Lauren (Private RAG)
        </button>
        <button
          onClick={() => setActiveTab('documents')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'documents' ? 'bg-[#17212C] text-[#A9B8FF] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          My Documents & Drive ({documents.length})
        </button>
        <button
          onClick={() => setActiveTab('collections')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'collections' ? 'bg-[#17212C] text-[#A9B8FF] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Knowledge Collections ({collections.length})
        </button>
        <button
          onClick={() => setActiveTab('localModels')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'localModels' ? 'bg-[#17212C] text-[#A9B8FF] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Local Models (Ollama)
        </button>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-6 relative">
        {/* TAB 1: ASK LAUREN (PRIVATE RAG WITH CITATIONS) */}
        {activeTab === 'askLauren' && (
          <div className="space-y-4 max-w-4xl mx-auto h-full flex flex-col">
            <div className="p-3.5 rounded-xl bg-[#17212C] border border-[#283544] flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span className="text-[#A2AFBF]">Private Context Scope:</span>
                <span className="text-white font-semibold font-mono">{documents.length} Personal Records Indexed</span>
              </div>
              <span className="text-[11px] font-mono text-[#A9B8FF]">Zero Public Data Leakage</span>
            </div>

            {/* Chat Stream */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1">
              {chatHistory.map((item, i) => (
                <div key={i} className="space-y-3">
                  {/* User Query */}
                  <div className="flex justify-end">
                    <div className="max-w-xl bg-[#17212C] border border-[#283544] rounded-2xl px-4 py-2.5 text-xs text-white shadow-xs">
                      {item.query}
                    </div>
                  </div>

                  {/* Assistant Answer with Citations */}
                  <div className="flex justify-start">
                    <div className="max-w-2xl bg-[#111821] border border-[#283544] rounded-2xl p-4 text-xs space-y-3 shadow-md">
                      <div className="flex items-center justify-between text-[11px] text-[#A2AFBF] border-b border-[#283544] pb-2 font-mono">
                        <span className="text-[#A9B8FF] font-bold">Lauren Assistant</span>
                        <span>{item.latencyMs}ms · Semantic Match</span>
                      </div>

                      <div className="text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                        {item.answer}
                      </div>

                      {/* "Why did Lauren use this source?" Citations Bar */}
                      {item.citations.length > 0 && (
                        <div className="pt-2 border-t border-[#283544] space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono uppercase tracking-wider text-[#A2AFBF] flex items-center gap-1">
                              <Info className="w-3 h-3 text-[#66E3CB]" />
                              <span>Why did Lauren use this source?</span>
                            </span>
                            <span className="text-[10px] text-[#738297]">Click citation to inspect</span>
                          </div>

                          <div className="flex items-center gap-2 flex-wrap">
                            {item.citations.map((c, ci) => (
                              <button
                                key={ci}
                                onClick={() => setActiveCitationDrawer(c)}
                                className="px-2.5 py-1 rounded bg-[#17212C] border border-[#3A4B5F] hover:border-[#66E3CB] text-left text-[11px] flex items-center gap-2 transition-colors cursor-pointer"
                              >
                                <span className="font-semibold text-white truncate max-w-[160px]">{c.docTitle}</span>
                                <span className="font-mono text-[#66E3CB] text-[10px]">{(c.similarityScore * 100).toFixed(0)}% match</span>
                                <Eye className="w-3 h-3 text-[#A2AFBF]" />
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Input Bar */}
            <form onSubmit={handleSendQuery} className="pt-2 flex items-center gap-2">
              <input
                type="text"
                value={queryInput}
                onChange={(e) => setQueryInput(e.target.value)}
                placeholder="Ask Lauren questions verified against your private vault documents..."
                className="flex-1 px-4 py-3 bg-[#111821] border border-[#283544] rounded-xl text-xs text-white placeholder-[#738297] focus:outline-none focus:border-[#A9B8FF]"
              />
              <button
                type="submit"
                disabled={isQuerying || !queryInput.trim()}
                className="px-5 py-3 bg-[#A9B8FF] hover:bg-[#92a4ff] disabled:opacity-50 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
              >
                {isQuerying ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span>Ask</span>
              </button>
            </form>
          </div>
        )}

        {/* TAB 2: MY DOCUMENTS & GOOGLE DRIVE */}
        {activeTab === 'documents' && (
          <div className="space-y-4 max-w-5xl mx-auto">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white">Private Document Vault</h2>
                <p className="text-xs text-[#A2AFBF]">Confidential project references, credentials, and notes</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleOpenDriveImport}
                  className="px-3.5 py-1.5 bg-[#17212C] border border-[#3A4B5F] hover:bg-[#283544] text-[#66E3CB] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Google Drive Sync</span>
                </button>
                <button
                  onClick={() => setIsNewDocModalOpen(true)}
                  className="px-3.5 py-1.5 bg-[#A9B8FF] text-slate-950 hover:bg-[#92a4ff] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>New Note</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {documents.map((doc) => (
                <div key={doc.id} className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-white text-xs truncate max-w-[240px]">{doc.title}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                      doc.confidentialLevel === 'PROJECT_SECRET'
                        ? 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                        : 'bg-indigo-500/10 text-[#A9B8FF] border-indigo-500/30'
                    }`}>
                      {doc.confidentialLevel}
                    </span>
                  </div>

                  <p className="text-xs text-[#A2AFBF] line-clamp-2 leading-relaxed">
                    {doc.content}
                  </p>

                  <div className="flex items-center justify-between text-[11px] font-mono text-[#738297] pt-2 border-t border-[#283544]">
                    <span>{doc.chunks.length} Chunks Indexed</span>
                    <span>{(doc.sizeBytes / 1024).toFixed(1)} KB</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: KNOWLEDGE COLLECTIONS */}
        {activeTab === 'collections' && (
          <div className="space-y-4 max-w-5xl mx-auto">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white">Private Knowledge Collections</h2>
                <p className="text-xs text-[#A2AFBF]">Structured domains separating personal strategy and code blueprints</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {collections.map((col) => (
                <div key={col.id} className="p-5 rounded-xl bg-[#17212C] border border-[#283544] space-y-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: col.color }} />
                  <h3 className="font-bold text-white text-xs">{col.name}</h3>
                  <p className="text-xs text-[#A2AFBF]">{col.description}</p>
                  <div className="text-[11px] font-mono text-[#738297] pt-2">
                    {col.docCount} Documents Linked
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: LOCAL MODELS (OLLAMA / WEBGPU) */}
        {activeTab === 'localModels' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            <div className="p-5 rounded-xl bg-[#17212C] border border-[#283544] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Local Ollama Inference Daemon</h3>
                  <p className="text-xs text-[#A2AFBF]">Private execution directly on local machine (Port 11434)</p>
                </div>
                <button
                  onClick={probeOllama}
                  disabled={isProbingOllama}
                  className="px-3 py-1.5 rounded-lg bg-[#283544] hover:bg-[#3A4B5F] text-xs font-mono text-[#66E3CB] flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isProbingOllama ? 'animate-spin' : ''}`} />
                  <span>Re-Probe Daemon</span>
                </button>
              </div>

              <div className={`p-3 rounded-lg border text-xs font-mono space-y-1 ${
                ollamaReachable
                  ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-amber-950/20 border-amber-500/40 text-amber-200'
              }`}>
                <div className="flex items-center justify-between font-bold">
                  <span>{ollamaReachable ? 'Ollama Daemon Responding (Verified Live)' : 'Local Ollama Daemon Unreachable'}</span>
                  <span>{ollamaLatency}ms latency</span>
                </div>
                <p className="text-[11px] font-sans text-[#A2AFBF]">
                  {ollamaReachable 
                    ? 'Connected to local runtime. Queries processed locally without external API transmission.'
                    : 'No local Ollama daemon detected on port 11434. Strict local mode will block cloud egress rather than leaking private prompts.'}
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-mono text-[#A2AFBF] uppercase tracking-wider">
                    {ollamaReachable ? 'Installed Local Models' : 'Local Models (Daemon Offline)'}
                  </div>
                  {!ollamaReachable && ollamaModels.length === 0 && (
                    <button
                      onClick={() => setOllamaModels(LaurenVaultService.getSampleOllamaModels())}
                      className="text-[11px] font-mono text-[#66E3CB] hover:underline cursor-pointer"
                    >
                      Preview Recommended Local Model Specs
                    </button>
                  )}
                </div>
                {ollamaModels.length === 0 ? (
                  <div className="p-4 rounded-lg bg-[#111821] border border-[#283544] text-xs text-[#738297] font-mono">
                    0 models reported because the local Ollama daemon is offline. Start `ollama serve` locally and click Re-Probe Daemon.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {ollamaModels.map((m) => (
                      <div
                        key={m.name}
                        className="p-3 rounded-lg bg-[#111821] border border-[#283544] flex items-center justify-between text-xs font-mono"
                      >
                        <div className="flex items-center gap-2">
                          <Cpu className="w-4 h-4 text-[#A9B8FF]" />
                          <span className="text-white font-bold">{m.name}</span>
                        </div>
                        <div className="flex items-center gap-4 text-[#A2AFBF]">
                          <span>{(m.sizeBytes / 1000000000).toFixed(1)} GB</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] ${
                            ollamaReachable
                              ? 'bg-emerald-500/10 text-emerald-400'
                              : 'bg-amber-500/10 text-amber-300'
                          }`}>
                            {ollamaReachable ? 'LIVE READY' : 'SPEC PREVIEW'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Citation Inspector Drawer Modal */}
      {activeCitationDrawer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-[#66E3CB]" />
                <h3 className="text-sm font-bold text-white">Why did Lauren use this source?</h3>
              </div>
              <button onClick={() => setActiveCitationDrawer(null)} className="text-[#A2AFBF] hover:text-white cursor-pointer">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <div className="text-[11px] font-mono text-[#A2AFBF]">Referenced Document:</div>
                <div className="text-sm font-bold text-white">{activeCitationDrawer.docTitle}</div>
              </div>

              <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544] space-y-1">
                <div className="text-[10px] font-mono text-[#66E3CB] uppercase tracking-wider">Semantic Match Reasoning</div>
                <p className="text-slate-200 leading-relaxed font-sans">{activeCitationDrawer.reasonUsed}</p>
              </div>

              <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544] space-y-1">
                <div className="text-[10px] font-mono text-[#A9B8FF] uppercase tracking-wider">Cited Chunk Text</div>
                <p className="text-slate-300 font-mono text-[11px] leading-relaxed">{activeCitationDrawer.snippet}</p>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-[#283544]">
              <button
                onClick={() => setActiveCitationDrawer(null)}
                className="px-4 py-1.5 rounded-lg bg-[#283544] text-white text-xs cursor-pointer"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Document Modal */}
      {isNewDocModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <h3 className="text-sm font-bold text-white">Create Private Vault Document</h3>
              <button onClick={() => setIsNewDocModalOpen(false)} className="text-[#A2AFBF] hover:text-white cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleCreateDocument} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="text-[#A2AFBF] font-mono">Title</label>
                <input
                  type="text"
                  value={newDocTitle}
                  onChange={(e) => setNewDocTitle(e.target.value)}
                  placeholder="e.g. Project Architecture Directives"
                  className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[#A2AFBF] font-mono">Confidentiality Level</label>
                <select
                  value={newDocLevel}
                  onChange={(e: any) => setNewDocLevel(e.target.value)}
                  className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white font-mono"
                >
                  <option value="CONFIDENTIAL">CONFIDENTIAL</option>
                  <option value="PROJECT_SECRET">PROJECT_SECRET</option>
                  <option value="PERSONAL">PERSONAL</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[#A2AFBF] font-mono">Document Content (Markdown)</label>
                <textarea
                  rows={6}
                  value={newDocContent}
                  onChange={(e) => setNewDocContent(e.target.value)}
                  placeholder="Paste or write confidential notes here..."
                  className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white font-mono text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-[#283544]">
                <button
                  type="button"
                  onClick={() => setIsNewDocModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#283544] text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#A9B8FF] text-slate-950 font-bold hover:bg-[#92a4ff] cursor-pointer"
                >
                  Save & Index
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Google Drive Selector Modal */}
      {isDriveModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-xl bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <h3 className="text-sm font-bold text-white">Select File from Google Drive</h3>
              <button onClick={() => setIsDriveModalOpen(false)} className="text-[#A2AFBF] hover:text-white cursor-pointer">✕</button>
            </div>

            <div className={`p-2.5 rounded-lg border text-xs font-mono ${
              driveConnected
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
            }`}>
              {driveConnected
                ? 'Connected: Displaying live files from your authenticated Google Drive.'
                : 'OAuth Token Not Active: Displaying clearly labeled demonstration templates for local testing.'}
            </div>

            {isScanningDrive ? (
              <div className="py-8 flex flex-col items-center justify-center text-xs text-[#A2AFBF] gap-2">
                <RefreshCw className="w-5 h-5 animate-spin text-[#66E3CB]" />
                <span>Scanning Google Drive...</span>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {driveFiles.map((file) => (
                  <div
                    key={file.id}
                    className="p-3 rounded-lg bg-[#17212C] border border-[#283544] flex items-center justify-between text-xs hover:border-[#A9B8FF] transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-white flex items-center gap-2">
                        <span>{file.name}</span>
                        {file.isDemoSample && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            DEMO SAMPLE
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-[#A2AFBF]">
                        {(file.sizeBytes / 1024).toFixed(0)} KB · {file.mimeType}
                      </div>
                    </div>
                    <button
                      onClick={() => handleImportDriveFile(file)}
                      className="px-3 py-1 bg-[#A9B8FF] hover:bg-[#92a4ff] text-slate-950 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      Import to Vault
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-end pt-2 border-t border-[#283544]">
              <button
                onClick={() => setIsDriveModalOpen(false)}
                className="px-4 py-1.5 rounded-lg bg-[#283544] text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AES-256-GCM Encrypted Backup Modal */}
      {isBackupModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-[#66E3CB]" />
                <h3 className="text-sm font-bold text-white">AES-256-GCM Encrypted Vault Backup</h3>
              </div>
              <button onClick={() => setIsBackupModalOpen(false)} className="text-[#A2AFBF] hover:text-white cursor-pointer">✕</button>
            </div>

            <p className="text-xs text-[#A2AFBF] leading-relaxed">
              Derives a 256-bit key using Web Crypto <code>PBKDF2-SHA256</code> (100,000 iterations), computes a <code>SHA-256</code> plaintext integrity digest, and encrypts your entire private vault with <code>AES-256-GCM</code>.
            </p>

            <form onSubmit={handleConfirmAesExport} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#A2AFBF] font-mono mb-1">Encryption Passphrase (min 8 chars)</label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={backupPassphrase}
                  onChange={e => setBackupPassphrase(e.target.value)}
                  placeholder="Enter strong encryption passphrase..."
                  className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              {backupStatusMsg && (
                <div className="text-rose-400 text-[11px] font-mono">{backupStatusMsg}</div>
              )}

              <div className="flex justify-end gap-2 pt-2 border-t border-[#283544]">
                <button
                  type="button"
                  onClick={() => setIsBackupModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#283544] text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isEncryptingBackup}
                  className="px-4 py-2 rounded-lg bg-[#66E3CB] text-slate-950 font-bold hover:bg-[#52d6be] cursor-pointer disabled:opacity-50"
                >
                  {isEncryptingBackup ? 'Encrypting...' : 'Encrypt & Download'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
