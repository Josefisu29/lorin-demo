import React, { useState } from 'react';
import { ModelRegistryService } from '../services/modelRegistry';
import { formatPrivateModelLabel } from '../data/specialists';
import { MosairaComparisonResult } from '../types/mosaira';
import { Columns, Play } from 'lucide-react';

export const MosairaComparison: React.FC = () => {
  const personas = ModelRegistryService.getPersonas();

  const [selectedPersonaIds, setSelectedPersonaIds] = useState<string[]>(['NOVA', 'SAGE', 'ATLAS']);
  const [comparisonPrompt, setComparisonPrompt] = useState('Compare procedural programming with object-oriented programming in 3 key bullet points.');
  const [isComparing, setIsComparing] = useState(false);
  const [results, setResults] = useState<Record<string, MosairaComparisonResult>>({});

  const handleTogglePersona = (id: string) => {
    if (selectedPersonaIds.includes(id)) {
      if (selectedPersonaIds.length > 2) {
        setSelectedPersonaIds(selectedPersonaIds.filter(p => p !== id));
      }
    } else {
      if (selectedPersonaIds.length < 4) {
        setSelectedPersonaIds([...selectedPersonaIds, id]);
      }
    }
  };

  const handleRunComparison = async () => {
    if (!comparisonPrompt.trim() || isComparing) return;
    setIsComparing(true);

    const newResults: Record<string, MosairaComparisonResult> = {};

    await Promise.all(
      selectedPersonaIds.map(async personaId => {
        const persona = ModelRegistryService.getPersona(personaId);
        if (!persona) return;

        const t0 = performance.now();

        try {
          const res = await fetch('/api/mosaira/infer', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              personaId: persona.id,
              humanName: persona.humanName,
              systemInstruction: persona.systemInstruction,
              modelId: persona.underlyingModelId,
              prompt: comparisonPrompt.trim(),
              stream: false
            })
          });

          const latencyMs = Math.round(performance.now() - t0);
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || `Inference service returned status ${res.status}`);
          if (typeof data.rawResponse !== 'string' || typeof data.modelUsed !== 'string') {
            throw new Error('Inference response did not include a model response and actual model attribution.');
          }
          const inputTokens = Number.isFinite(data.inputTokenCount) ? data.inputTokenCount : undefined;
          const outputTokens = Number.isFinite(data.outputTokenCount) ? data.outputTokenCount : undefined;

          newResults[personaId] = {
            personaId: persona.id,
            modelId: data.modelUsed,
            displayName: `${persona.humanName} (${persona.id})`,
            responseText: data.rawResponse,
            latencyMs,
            inputTokens,
            outputTokens,
            status: 'SUCCESS'
          };
        } catch (err: any) {
          newResults[personaId] = {
            personaId: persona.id,
            modelId: persona.underlyingModelId,
            displayName: `${persona.humanName} (${persona.id})`,
            responseText: `Comparison failed: ${err.message || 'Service offline'}`,
            latencyMs: 0,
            status: 'ERROR',
            errorDetails: err.message
          };
        }
      })
    );

    setResults(newResults);
    setIsComparing(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Columns className="w-6 h-6 text-indigo-500" />
          Comparison Laboratory
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Evaluate 2 to 4 AI personas side-by-side on identical prompts. Measure real response time, token throughput, and output quality.
        </p>
      </div>

      {/* Model Selector Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
          Select Personas to Compare (2–4):
        </span>
        <div className="flex flex-wrap gap-2">
          {personas.map(p => {
            const isSelected = selectedPersonaIds.includes(p.id);
            return (
              <button
                key={p.id}
                onClick={() => handleTogglePersona(p.id)}
                className={`py-1.5 px-3 text-xs font-semibold rounded-lg border transition-all ${
                  isSelected
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-400'
                }`}
              >
                {p.humanName} ({p.id})
              </button>
            );
          })}
        </div>

        {/* Prompt Input */}
        <div className="pt-2 flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={comparisonPrompt}
            onChange={e => setComparisonPrompt(e.target.value)}
            placeholder="Enter a prompt to compare across models..."
            className="flex-1 px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={handleRunComparison}
            disabled={isComparing || !comparisonPrompt.trim()}
            className="py-2 px-5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm shrink-0"
          >
            {isComparing ? (
              <span className="animate-pulse">Evaluating...</span>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-white" />
                Run Comparison
              </>
            )}
          </button>
        </div>
      </div>

      {/* Comparison Grid */}
      <div className={`grid grid-cols-1 md:grid-cols-${selectedPersonaIds.length} gap-4`}>
        {selectedPersonaIds.map(id => {
          const persona = ModelRegistryService.getPersona(id);
          const res = results[id];

          if (!persona) return null;

          return (
            <div
              key={id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${persona.avatarBg} flex items-center justify-center font-bold text-slate-900 dark:text-slate-100 text-xs`}>
                    {persona.humanName[0]}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                      {persona.humanName} ({persona.id})
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {formatPrivateModelLabel(persona.underlyingModelId)}
                    </p>
                  </div>
                </div>

                <div className="pt-3">
                  {res ? (
                    <div className="text-xs text-slate-700 dark:text-slate-300 space-y-3">
                      <p className="whitespace-pre-wrap leading-relaxed min-h-[160px]">
                        {res.responseText}
                      </p>

                      <div className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-800 space-y-1 text-[11px] font-mono tabular-nums">
                        <div className="flex justify-between text-slate-600 dark:text-slate-400">
                          <span>Total Latency:</span>
                          <span className="font-semibold text-slate-900 dark:text-slate-100">{res.latencyMs} ms</span>
                        </div>
                        <div className="flex justify-between text-slate-600 dark:text-slate-400">
                          <span>Est. TTFT:</span>
                          <span>{res.ttftMs === undefined ? 'Not reported' : `${res.ttftMs} ms`}</span>
                        </div>
                        <div className="flex justify-between text-slate-600 dark:text-slate-400">
                          <span>Tokens (In/Out):</span>
                          <span>{res.inputTokens === undefined || res.outputTokens === undefined ? 'Not reported' : `${res.inputTokens} / ${res.outputTokens}`}</span>
                        </div>
                        <div className="flex justify-between text-slate-600 dark:text-slate-400">
                          <span>Est. Cost:</span>
                          <span>{res.estimatedCost === undefined ? 'Not reported' : `$${res.estimatedCost.toFixed(6)}`}</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="h-48 flex items-center justify-center text-center text-xs text-slate-400">
                      Click "Run Comparison" to generate side-by-side outputs.
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
