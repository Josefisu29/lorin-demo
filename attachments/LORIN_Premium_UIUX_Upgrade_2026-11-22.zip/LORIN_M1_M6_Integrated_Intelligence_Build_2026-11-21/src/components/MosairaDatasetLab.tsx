import React, { useState } from 'react';
import { DatasetLabService } from '../services/datasetLab';
import { Database, ShieldCheck, Filter, FileCode, CheckCircle2, Lock } from 'lucide-react';

export const MosairaDatasetLab: React.FC = () => {
  const [consent, setConsent] = useState(DatasetLabService.getConsent());
  const [testInput, setTestInput] = useState('My name is Alex (alex@example.com) and my secret key is api_key_1234567890.');
  const [sanitizedResult, setSanitizedResult] = useState<{ cleanText: string; secretsFound: number; piiFound: number } | null>(null);

  const handleUpdateConsent = (key: keyof typeof consent, value: boolean) => {
    const updated = DatasetLabService.updateConsent({ [key]: value });
    setConsent(updated);
  };

  const handleSanitizeTest = () => {
    const result = DatasetLabService.sanitizeSample(testInput);
    setSanitizedResult(result);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Database className="w-6 h-6 text-indigo-500" />
          Governed Dataset Laboratory (System B)
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Curate, sanitize, and manage model fine-tuning candidate datasets with explicit unbundled user consent.
        </p>
      </div>

      {/* Unbundled Consent Control Panel */}
      <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-500" />
            <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">Unbundled User Contribution Consent Toggles</h2>
          </div>
          <span className="text-[11px] font-mono text-slate-500">Updated: {new Date(consent.timestamp).toLocaleTimeString()}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3">
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">System A: Knowledge Commons (RAG)</span>
              <p className="text-slate-500 text-[11px] mt-0.5">Allow contributed items to be indexed into the public searchable knowledge commons.</p>
            </div>
            <input
              type="checkbox"
              checked={consent.useForRAGCommons}
              onChange={e => handleUpdateConsent('useForRAGCommons', e.target.checked)}
              className="accent-indigo-600 rounded w-4 h-4 mt-1"
            />
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3">
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">Internal Model Evaluation</span>
              <p className="text-slate-500 text-[11px] mt-0.5">Allow prompt/response pairs to be used for offline benchmark & quality evaluation.</p>
            </div>
            <input
              type="checkbox"
              checked={consent.useForInternalEval}
              onChange={e => handleUpdateConsent('useForInternalEval', e.target.checked)}
              className="accent-indigo-600 rounded w-4 h-4 mt-1"
            />
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3">
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">System B: Fine-Tuning Candidate</span>
              <p className="text-slate-500 text-[11px] mt-0.5">Allow anonymized samples as candidates for open-weight model fine-tuning datasets.</p>
            </div>
            <input
              type="checkbox"
              checked={consent.useForTrainingCandidate}
              onChange={e => handleUpdateConsent('useForTrainingCandidate', e.target.checked)}
              className="accent-indigo-600 rounded w-4 h-4 mt-1"
            />
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 flex items-start justify-between gap-3">
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">Public Display Rights</span>
              <p className="text-slate-500 text-[11px] mt-0.5">Allow anonymized contributions to be displayed in community example galleries.</p>
            </div>
            <input
              type="checkbox"
              checked={consent.allowPublicDisplay}
              onChange={e => handleUpdateConsent('allowPublicDisplay', e.target.checked)}
              className="accent-indigo-600 rounded w-4 h-4 mt-1"
            />
          </div>
        </div>
      </div>

      {/* Dataset Sanitization & Secret Scrubbing Playground */}
      <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
        <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Filter className="w-4 h-4 text-indigo-500" />
          Dataset Sanitization & PII Scrubbing Engine
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Test the automated dataset scrubbing pipeline that detects and redacts secret keys, credentials, and email PII.
        </p>

        <div className="space-y-2">
          <textarea
            rows={3}
            value={testInput}
            onChange={e => setTestInput(e.target.value)}
            className="w-full p-3 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg font-mono text-slate-900 dark:text-slate-100"
          />
          <button
            onClick={handleSanitizeTest}
            className="py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg"
          >
            Run Scrubbing Pipeline
          </button>
        </div>

        {sanitizedResult && (
          <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-2">
            <div className="flex items-center gap-4 text-slate-700 dark:text-slate-300 font-mono tabular-nums">
              <span>Secrets Redacted: <strong className="text-rose-600">{sanitizedResult.secretsFound}</strong></span>
              <span>PII Redacted: <strong className="text-amber-600">{sanitizedResult.piiFound}</strong></span>
            </div>
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block mb-1">Sanitized Dataset Output</span>
              <code className="block p-2 bg-slate-900 text-emerald-400 rounded font-mono text-[11px] whitespace-pre-wrap">
                {sanitizedResult.cleanText}
              </code>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
