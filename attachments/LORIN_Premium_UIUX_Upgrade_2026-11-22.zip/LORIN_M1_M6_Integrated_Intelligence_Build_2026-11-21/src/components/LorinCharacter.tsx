import React, { useEffect, useId, useRef, useState } from 'react';
import {
  CharacterPresentation,
  LorinCharacterState,
  LorinCharacterStateInput,
  LorinEnvironment,
  normalizeCharacterState
} from '../services/lorinPresence';
import { CameraFramingPreset, HologramRuntime } from '../holographic/core/HologramRuntime';
import { ActiveRendererBackend } from '../holographic/core/RenderingCapabilities';
import { QualityManager, QualityProfileSettings } from '../holographic/core/QualityManager';
import { PixelStreamingAdapter } from '../holographic/streaming/PixelStreamingAdapter';

export interface LorinCharacterProps {
  state: LorinCharacterStateInput;
  presentation?: CharacterPresentation;
  environment?: LorinEnvironment;
  audioLevel?: number;
  isSpeaking?: boolean;
  showStatus?: boolean;
  showControls?: boolean;
  force3D?: boolean;
  cameraPreset?: CameraFramingPreset;
  onCameraPresetChange?: (preset: CameraFramingPreset) => void;
  onOpenImmersiveMode?: () => void;
  className?: string;
}

export const STATE_LABELS: Record<LorinCharacterState, string> = {
  IDLE: 'Ready',
  LISTENING: 'Listening',
  PROCESSING: 'Working',
  THINKING: 'Thinking',
  SPEAKING: 'Speaking',
  RESPONDING: 'Responding',
  RESEARCHING: 'Researching',
  CODING: 'Coding',
  ANALYZING: 'Analyzing image',
  VISION_ACTIVE: 'Camera preview active',
  NOTIFICATION: 'Approval needs attention',
  ERROR: 'Something needs attention',
  DISCONNECTED: 'Service unavailable'
};

/**
 * LORIN Hybrid Digital-Human Holographic Character (Sections 2, 3, 4, 5 & 6)
 * - Uses Babylon.js WebGPU (with automatic WebGL 2 fallback) for dimensional 3D presentations
 *   ('standard', 'expanded', 'full', 'workspace', or when force3D is true).
 * - Synchronizes with Unreal Engine 5.8 + MetaHuman Pixel Streaming when connected.
 * - Gracefully falls back to the high-precision 2.5D hybrid silhouette for compact badges or headless environments.
 */
export const LorinCharacter: React.FC<LorinCharacterProps> = ({
  state: stateInput,
  presentation = 'standard',
  environment = 'conversation',
  audioLevel = 0,
  isSpeaking = false,
  showStatus = true,
  showControls = false,
  force3D = false,
  cameraPreset,
  onCameraPresetChange,
  onOpenImmersiveMode,
  className = ''
}) => {
  const id = useId().replace(/:/g, '');
  const state = normalizeCharacterState(stateInput);
  const level = Math.max(0, Math.min(100, audioLevel));

  const shouldAttempt3D =
    force3D ||
    presentation === 'standard' ||
    presentation === 'expanded' ||
    presentation === 'full' ||
    presentation === 'workspace';

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const runtimeRef = useRef<HologramRuntime | null>(null);
  const [activeBackend, setActiveBackend] = useState<ActiveRendererBackend>('SVG_Fallback');
  const [qualityProfile, setQualityProfile] = useState<QualityProfileSettings>(() =>
    QualityManager.getActiveProfile()
  );
  const [measuredFps, setMeasuredFps] = useState<number>(() => QualityManager.getMeasuredFps());

  // Initialize Babylon.js WebGPU / WebGL 2 3D runtime when 3D presentation is active
  useEffect(() => {
    if (!shouldAttempt3D || typeof window === 'undefined') {
      setActiveBackend('SVG_Fallback');
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;

    let cancelled = false;
    const runtime = new HologramRuntime();
    runtimeRef.current = runtime;

    runtime
      .initialize(canvas, presentation)
      .then(res => {
        if (!cancelled) {
          setActiveBackend(res.backend);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setActiveBackend('SVG_Fallback');
        }
      });

    const unsubQuality = QualityManager.subscribe((prof, fps) => {
      if (!cancelled) {
        setQualityProfile(prof);
        setMeasuredFps(fps);
        runtime.applyQualityProfile(prof);
      }
    });

    const fpsTimer = window.setInterval(() => {
      if (!cancelled) {
        setMeasuredFps(QualityManager.getMeasuredFps());
      }
    }, 1000);

    return () => {
      cancelled = true;
      window.clearInterval(fpsTimer);
      unsubQuality();
      runtime.dispose();
      runtimeRef.current = null;
    };
  }, [shouldAttempt3D, presentation]);

  // Synchronize live assistant state, audio level, and speaking status with 3D rig & Pixel Streaming
  useEffect(() => {
    const speakingActive = isSpeaking || state === 'SPEAKING';
    if (runtimeRef.current) {
      runtimeRef.current.syncState({
        state,
        environment,
        presentation,
        audioLevel: level,
        isSpeaking: speakingActive
      });
    }
    PixelStreamingAdapter.sendCharacterDirective({
      state,
      environment,
      presentation,
      audioLevel: level,
      isSpeaking: speakingActive
    });
  }, [state, environment, presentation, level, isSpeaking]);

  // Synchronize external camera framing preset
  useEffect(() => {
    if (cameraPreset && runtimeRef.current) {
      runtimeRef.current.setCameraFramingPreset(cameraPreset);
    }
  }, [cameraPreset]);

  const handlePointerMove = (e: React.PointerEvent<HTMLElement>) => {
    if (!runtimeRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const ny = ((e.clientY - rect.top) / rect.height) * 2 - 1;
    runtimeRef.current.setPointerGaze(nx, ny);
  };

  const handlePointerLeave = () => {
    runtimeRef.current?.setPointerGaze(0, 0);
  };

  const is3DRenderingActive =
    shouldAttempt3D && (activeBackend === 'WebGPU' || activeBackend === 'WebGL2' || activeBackend === 'WebGL1');

  return (
    <figure
      className={`lorin-character lorin-character--${presentation} relative select-none ${className}`}
      data-state={state.toLowerCase()}
      data-renderer={activeBackend}
      role="img"
      aria-label={`LORIN digital presence, ${STATE_LABELS[state]}`}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
    >
      <span
        className="lorin-character__aura"
        aria-hidden="true"
        style={{ transform: `scale(${1 + level / 600})`, opacity: 0.14 + level / 300 }}
      />

      {/* 3D WebGPU / WebGL2 Digital-Human Canvas */}
      {shouldAttempt3D && (
        <canvas
          ref={canvasRef}
          className={`w-full h-full block transition-opacity duration-300 ${
            is3DRenderingActive ? 'opacity-100' : 'opacity-0 pointer-events-none absolute inset-0'
          }`}
          aria-hidden="true"
        />
      )}

      {/* High-Precision 2.5D Hybrid SVG Presence (Active for compact badges or when WebGL is unavailable) */}
      {!is3DRenderingActive && (
        <svg className="lorin-character__art" viewBox="0 0 240 280" aria-hidden="true" focusable="false">
          <defs>
            <linearGradient id={`${id}-skin`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#D7FFF8" stopOpacity=".88" />
              <stop offset=".43" stopColor="#72DCCF" stopOpacity=".68" />
              <stop offset="1" stopColor="#7F91D9" stopOpacity=".74" />
            </linearGradient>
            <linearGradient id={`${id}-hair`} x1=".1" y1="0" x2=".9" y2="1">
              <stop offset="0" stopColor="#DAFFF8" stopOpacity=".92" />
              <stop offset=".55" stopColor="#79CFCB" stopOpacity=".74" />
              <stop offset="1" stopColor="#7F91D9" stopOpacity=".78" />
            </linearGradient>
            <linearGradient id={`${id}-coat`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#66E3CB" stopOpacity=".42" />
              <stop offset=".52" stopColor="#263F52" stopOpacity=".94" />
              <stop offset="1" stopColor="#A9B8FF" stopOpacity=".4" />
            </linearGradient>
            <radialGradient id={`${id}-light`} cx="50%" cy="38%" r="60%">
              <stop offset="0" stopColor="#B8FFF2" stopOpacity=".29" />
              <stop offset="1" stopColor="#66E3CB" stopOpacity="0" />
            </radialGradient>
            <filter id={`${id}-glow`} x="-80%" y="-80%" width="260%" height="260%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <clipPath id={`${id}-silhouette`}>
              <path d="M30 278c4-36 16-59 41-72l21-11 3-20c-12-9-20-23-22-40-9-1-14-9-13-18 1-6 5-10 11-10-2-33 15-58 49-61 36-3 58 22 56 60 7 1 10 6 10 12 0 9-5 15-13 17-2 17-10 31-22 40l3 20 24 12c23 12 36 35 40 71H30Z" />
            </clipPath>
          </defs>

          <ellipse cx="120" cy="128" rx="95" ry="128" fill={`url(#${id}-light)`} />
          <path
            d="M32 278c4-34 16-57 40-70l23-12 5-23h40l5 23 24 12c24 13 36 36 40 70H32Z"
            fill={`url(#${id}-coat)`}
            stroke="#9DF5E7"
            strokeOpacity=".72"
            strokeWidth="1.4"
          />
          <path
            d="m91 195 29 31 29-31-6-23h-46l-6 23Z"
            fill="#101E2A"
            fillOpacity=".88"
            stroke="#9DF5E7"
            strokeOpacity=".65"
          />
          <path
            d="M120 225v52m-44-67 15 17m73-17-15 17"
            fill="none"
            stroke="#8DEADB"
            strokeOpacity=".57"
            strokeWidth="1.2"
          />
          <path
            d="M77 111c-2-35 16-59 47-62 34-3 56 21 53 61l-4 29c-3 22-17 40-37 48-10 4-22 4-33 0-20-8-34-26-37-48l-4-28Z"
            fill={`url(#${id}-skin)`}
            fillOpacity=".78"
            stroke="#C7FFF6"
            strokeOpacity=".82"
            strokeWidth="1.5"
          />
          <path
            d="M72 113c-1-16-1-31 4-43 8-24 27-38 53-39 32-1 53 17 58 48 2 11 1 23-1 35-5-8-8-18-9-29-13-2-25-8-35-17-12 16-30 26-56 29-2 6-6 11-14 16Z"
            fill={`url(#${id}-hair)`}
            fillOpacity=".82"
            stroke="#C7FFF6"
            strokeOpacity=".86"
            strokeWidth="1.6"
          />
          <path
            d="M76 112c-6-1-10 2-10 8 0 7 4 12 12 13m86-21c7-2 12 1 12 8 0 7-4 12-12 14"
            fill="none"
            stroke="#B8FFF2"
            strokeOpacity=".88"
            strokeWidth="2"
          />
          <path
            d="M86 125c7-6 15-6 22-1m25 0c7-5 15-5 22 1"
            fill="none"
            stroke="#D8FFF9"
            strokeOpacity=".74"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <path
            d="M91 134c5 3 11 3 16 0m27 0c5 3 11 3 16 0"
            fill="none"
            stroke="#D1FFF7"
            strokeOpacity=".9"
            strokeWidth="2.1"
            strokeLinecap="round"
            filter={`url(#${id}-glow)`}
          />
          <path
            d="M120 135v22l-5 4 5 3"
            fill="none"
            stroke="#C8FFF5"
            strokeOpacity=".52"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
          <path
            d="M109 171c7 4 15 4 22 0"
            fill="none"
            stroke="#E4FFFB"
            strokeOpacity=".73"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <path
            d="M80 119c-3 22 5 47 22 58m58-58c3 22-5 47-22 58"
            fill="none"
            stroke="#E0FFFA"
            strokeOpacity=".25"
            strokeWidth="1"
          />
          <path d="M72 97h10m76 0h10M70 106h7m86 0h7" stroke="#8DEADB" strokeOpacity=".8" strokeWidth="1.3" />
          <circle cx="71" cy="114" r="2" fill="#C9FFF6" />
          <circle cx="169" cy="114" r="2" fill="#C9FFF6" />
          <g clipPath={`url(#${id}-silhouette)`} fill="none" stroke="#8DEADB" strokeOpacity=".55" strokeWidth="1">
            <path d="M42 254h25l9-9h20m77 0h18l9 9h20M59 266h28m66 0h28M81 235l8-8h15m52 0h-15l-8 8" />
            <path d="M64 205v17l9 9m103-26v17l-9 9" />
            <circle cx="69" cy="254" r="2" fill="#A9F7EB" />
            <circle cx="171" cy="245" r="2" fill="#A9F7EB" />
          </g>
          <path d="M43 83h154M38 89h164M46 194h148" stroke="#D9FFF9" strokeOpacity=".12" strokeWidth="1" />
          <path d="M120 31v14m-12-10h24" stroke="#D9FFF9" strokeOpacity=".75" strokeWidth="1.2" strokeLinecap="round" />
        </svg>
      )}

      {/* Optional Interactive Spatial Telemetry & Camera Controls Overlay */}
      {showControls && (
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between gap-2 pointer-events-auto z-10">
          <div className="px-2 py-0.5 rounded-md bg-[#0B0F14]/80 border border-[#283544] backdrop-blur-md text-[10px] font-mono text-[#66E3CB] flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#66E3CB]" />
            <span>{activeBackend}</span>
            <span className="text-[#A2AFBF]">·</span>
            <span className="text-[#A2AFBF]">{qualityProfile.profile}</span>
            {is3DRenderingActive && (
              <>
                <span className="text-[#A2AFBF]">·</span>
                <span className="text-[#F1F5F9]">{measuredFps} FPS</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-1">
            {onCameraPresetChange && (
              <select
                aria-label="Camera framing preset"
                value={cameraPreset || 'upper_body'}
                onChange={e => onCameraPresetChange(e.target.value as CameraFramingPreset)}
                className="px-2 py-0.5 rounded-md bg-[#0B0F14]/85 border border-[#283544] text-[10px] font-mono text-[#F1F5F9] focus:outline-none focus:border-[#66E3CB] cursor-pointer"
              >
                <option value="portrait">Portrait</option>
                <option value="upper_body">Upper Body</option>
                <option value="full_stage">Full Stage</option>
                <option value="cinematic">Cinematic Orbit</option>
              </select>
            )}
            {onOpenImmersiveMode && (
              <button
                type="button"
                onClick={onOpenImmersiveMode}
                className="px-2 py-0.5 rounded-md bg-[#17212C]/90 hover:bg-[#1F2D3C] border border-[#3A4B5F] text-[10px] font-mono text-[#66E3CB] transition-colors cursor-pointer"
                title="Open Dedicated Full Immersive Holographic Mode"
              >
                Immersive
              </button>
            )}
          </div>
        </div>
      )}

      {showStatus && <figcaption className="lorin-character__caption">{STATE_LABELS[state]}</figcaption>}
    </figure>
  );
};
