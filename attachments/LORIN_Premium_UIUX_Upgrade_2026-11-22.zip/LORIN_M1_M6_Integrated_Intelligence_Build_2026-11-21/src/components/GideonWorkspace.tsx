import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  Activity,
  TrendingUp,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Search,
  Filter,
  Plus,
  RefreshCw,
  Send,
  Calendar,
  Layers,
  ShieldCheck,
  Server,
  Database,
  Cpu,
  ArrowRight,
  GitBranch,
  Info,
  Sparkles
} from 'lucide-react';
import {
  GideonCorrelation,
  GideonDecision,
  GideonDiagnosticsSummary,
  GideonEvent,
  GideonEventCategory,
  GideonObservation,
  GideonPrediction,
  GideonScenario,
  GideonStatus,
  Principal
} from '../types/lorin';
import { GideonService, TimelineFilterOptions } from '../services/gideonService';
import { ProjectStore } from '../services/projectStore';

interface GideonWorkspaceProps {
  principal: Principal;
  activeProjectId?: string;
  onNavigateToProject?: (projectId: string) => void;
  onNavigateToChat?: () => void;
  onPresenceChange?: (state: 'IDLE' | 'PROCESSING' | 'RESEARCHING') => void;
}

type GideonTab =
  | 'overview'
  | 'timeline'
  | 'decisions'
  | 'predictions'
  | 'diagnostics'
  | 'scenarios'
  | 'ask';

export const GideonWorkspace: React.FC<GideonWorkspaceProps> = ({
  principal,
  activeProjectId = 'proj_lorin_core',
  onNavigateToProject,
  onNavigateToChat,
  onPresenceChange
}) => {
  const [activeTab, setActiveTab] = useState<GideonTab>('overview');
  const [status, setStatus] = useState<GideonStatus | null>(null);
  const [events, setEvents] = useState<GideonEvent[]>([]);
  const [decisions, setDecisions] = useState<GideonDecision[]>([]);
  const [predictions, setPredictions] = useState<GideonPrediction[]>([]);
  const [scenarios, setScenarios] = useState<GideonScenario[]>([]);
  const [diagnostics, setDiagnostics] = useState<GideonDiagnosticsSummary | null>(null);
  const [correlations, setCorrelations] = useState<GideonCorrelation[]>([]);

  // Filtering & Pagination
  const [categoryFilter, setCategoryFilter] = useState<GideonEventCategory | 'ALL'>('ALL');
  const [projectFilter, setProjectFilter] = useState<string>(activeProjectId);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEvent, setSelectedEvent] = useState<GideonEvent | null>(null);

  // Loading States
  const [loading, setLoading] = useState(false);
  const [diagnosing, setDiagnosing] = useState(false);
  const [serviceNotice, setServiceNotice] = useState<string | null>(null);

  // Modals & Creation
  const [showEventModal, setShowEventModal] = useState(false);
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventCategory, setNewEventCategory] = useState<GideonEventCategory>('task');
  const [newEventSummary, setNewEventSummary] = useState('');

  const [showDecisionModal, setShowDecisionModal] = useState(false);
  const [newDecisionTitle, setNewDecisionTitle] = useState('');
  const [newDecisionDesc, setNewDecisionDesc] = useState('');
  const [newDecisionReason, setNewDecisionReason] = useState('');

  // Ask GIDEON conversational state
  const [askQuery, setAskQuery] = useState('');
  const [asking, setAsking] = useState(false);
  const [askResult, setAskResult] = useState<{
    answer: string;
    evidenceEvents: GideonEvent[];
    confidence: string;
    recommendedNextStep: string;
  } | null>(null);

  const projects = useMemo(() => ProjectStore.getProjects(), []);

  useEffect(() => {
    onPresenceChange?.(asking ? 'RESEARCHING' : diagnosing || loading ? 'PROCESSING' : 'IDLE');
  }, [asking, diagnosing, loading, onPresenceChange]);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [statusRes, timelineRes, decRes, predRes] = await Promise.all([
        GideonService.getStatus(),
        GideonService.getTimeline({
          projectId: projectFilter !== 'ALL' ? projectFilter : undefined,
          category: categoryFilter !== 'ALL' ? categoryFilter : undefined,
          search: searchQuery || undefined,
          limit: 100
        }),
        GideonService.getProjectDecisions(projectFilter),
        GideonService.getActivePredictions(projectFilter)
      ]);

      setStatus(statusRes);
      setEvents(timelineRes.events);
      setDecisions(decRes);
      setPredictions(predRes);
      setScenarios(GideonService.getScenarios());

      // Auto-correlate first 2 events if available
      if (timelineRes.events.length >= 2) {
        const corrs = await GideonService.correlateEvents([
          timelineRes.events[0].eventId,
          timelineRes.events[1].eventId
        ]);
        setCorrelations(corrs);
      }
    } catch {
      // Fallback handled inside GideonService
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, [categoryFilter, projectFilter, searchQuery]);

  const handleRunDiagnostics = async () => {
    setDiagnosing(true);
    try {
      const summary = await GideonService.runDiagnostics();
      setDiagnostics(summary);
      // Reload timeline to display new diagnostic event
      const tl = await GideonService.getTimeline({ projectId: projectFilter, limit: 50 });
      setEvents(tl.events);
    } finally {
      setDiagnosing(false);
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle.trim()) return;

    await GideonService.recordEvent({
      ownerUid: principal.id,
      projectId: projectFilter !== 'ALL' ? projectFilter : activeProjectId,
      category: newEventCategory,
      title: newEventTitle.trim(),
      summary: newEventSummary.trim() || 'Manual event logged via GIDEON Workspace.',
      source: `Operator (${principal.role})`,
      occurredAt: Date.now(),
      verificationStatus: 'unverified'
    }, principal);

    setShowEventModal(false);
    setNewEventTitle('');
    setNewEventSummary('');
    loadAllData();
  };

  const handleCreateDecision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDecisionTitle.trim() || !newDecisionDesc.trim()) return;

    await GideonService.recordDecision({
      projectId: projectFilter !== 'ALL' ? projectFilter : activeProjectId,
      title: newDecisionTitle.trim(),
      decisionDescription: newDecisionDesc.trim(),
      alternativesConsidered: ['Default system configuration', 'Postponed review'],
      reasoning: newDecisionReason.trim() || 'Optimized for security and maintainability.',
      supportingEvidence: ['GIDEON Timeline Intelligence record'],
      decisionOwner: `${principal.role} (${principal.email || principal.id})`,
      status: 'APPROVED'
    }, principal);

    setShowDecisionModal(false);
    setNewDecisionTitle('');
    setNewDecisionDesc('');
    setNewDecisionReason('');
    loadAllData();
  };

  const handleAskGideon = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!askQuery.trim() || asking) return;

    setAsking(true);
    try {
      const res = await GideonService.queryGideon(askQuery.trim(), projectFilter);
      setAskResult(res);
    } finally {
      setAsking(false);
    }
  };

  return (
    <div className="lorin-module-page flex min-h-0 flex-1 flex-col h-full overflow-hidden bg-[#0B0F14] text-white">
      {serviceNotice && (
        <div role="status" className="mx-4 mt-3 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
          {serviceNotice}
          <button type="button" className="ml-3 underline" onClick={() => setServiceNotice(null)}>Dismiss</button>
        </div>
      )}
      {/* Top GIDEON Specialist Header */}
      <div className="px-6 py-4 border-b border-[#283544] bg-[#111821] flex flex-wrap items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#E5A93C]/15 border border-[#E5A93C]/40 flex items-center justify-center text-[#E5A93C] shadow-lg shadow-[#E5A93C]/10">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-white tracking-wide">
                GIDEON
              </h1>
              <span className="px-2 py-0.5 rounded-md bg-[#E5A93C]/20 border border-[#E5A93C]/40 text-[#E5A93C] text-[10px] font-mono font-bold uppercase tracking-wider">
                Systems Intelligence
              </span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-mono font-bold">
                CORE 6TH SPECIALIST
              </span>
            </div>
            <p className="text-xs text-[#A2AFBF] mt-0.5">
              Timeline intelligence, architectural continuity, event correlation & predictive analysis.
            </p>
          </div>
        </div>

        {/* Global Controls & Diagnostics Action */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleRunDiagnostics}
            disabled={diagnosing}
            className="px-3 py-1.5 rounded-xl bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[#66E3CB] text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Activity className={`w-3.5 h-3.5 ${diagnosing ? 'animate-spin' : ''}`} />
            <span>{diagnosing ? 'Diagnosing...' : 'Run Diagnostics'}</span>
          </button>
          <button
            type="button"
            onClick={() => setShowEventModal(true)}
            className="px-3 py-1.5 rounded-xl bg-[#E5A93C] hover:bg-[#d89b30] text-slate-950 text-xs font-bold font-mono flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Record Event</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="px-6 py-2 border-b border-[#283544] bg-[#0E151E] flex items-center gap-2 overflow-x-auto shrink-0 text-xs font-mono">
        {[
          { id: 'overview', label: 'Overview', icon: Layers },
          { id: 'timeline', label: `Timeline (${events.length})`, icon: Clock },
          { id: 'decisions', label: `Decisions (${decisions.length})`, icon: FileText },
          { id: 'predictions', label: `Predictions (${predictions.length})`, icon: TrendingUp },
          { id: 'diagnostics', label: 'Diagnostics', icon: Activity },
          { id: 'scenarios', label: `Scenarios (${scenarios.length})`, icon: GitBranch },
          { id: 'ask', label: 'Ask GIDEON', icon: Sparkles }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as GideonTab)}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
                isActive
                  ? 'bg-[#E5A93C]/15 text-[#E5A93C] border border-[#E5A93C]/40 font-bold'
                  : 'text-[#A2AFBF] hover:text-white border border-transparent hover:bg-[#17212C]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Workspace Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* ================================================================ */}
        {/* TAB 1: OVERVIEW */}
        {/* ================================================================ */}
        {activeTab === 'overview' && (
          <div className="max-w-6xl mx-auto space-y-6">
            {/* Top Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-[#111821] border border-[#283544]">
                <div className="flex items-center justify-between text-[#A2AFBF] text-xs font-mono">
                  <span>TIMELINE EVENTS</span>
                  <Clock className="w-4 h-4 text-[#E5A93C]" />
                </div>
                <div className="text-2xl font-bold text-white mt-2 font-mono">
                  {events.length}
                </div>
                <p className="text-[11px] text-[#738297] mt-1">
                  Chronological records persisted with verifiable server timestamps.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#111821] border border-[#283544]">
                <div className="flex items-center justify-between text-[#A2AFBF] text-xs font-mono">
                  <span>RECORDED DECISIONS</span>
                  <FileText className="w-4 h-4 text-[#66E3CB]" />
                </div>
                <div className="text-2xl font-bold text-white mt-2 font-mono">
                  {decisions.length}
                </div>
                <p className="text-[11px] text-[#738297] mt-1">
                  Architectural Decision Records (ADRs) preserving intent & trade-offs.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#111821] border border-[#283544]">
                <div className="flex items-center justify-between text-[#A2AFBF] text-xs font-mono">
                  <span>ACTIVE FORECASTS</span>
                  <TrendingUp className="w-4 h-4 text-[#A9B8FF]" />
                </div>
                <div className="text-2xl font-bold text-white mt-2 font-mono">
                  {predictions.length}
                </div>
                <p className="text-[11px] text-[#738297] mt-1">
                  Forecasting is unavailable until verified data sources are connected.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#111821] border border-[#283544]">
                <div className="flex items-center justify-between text-[#A2AFBF] text-xs font-mono">
                  <span>SYSTEM HEALTH</span>
                  <Activity className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-bold text-emerald-400 mt-2 font-mono">
                  {diagnostics?.overallStatus || 'NOT CHECKED'}
                </div>
                <p className="text-[11px] text-[#738297] mt-1">
                  Shows only the systems checked by the latest diagnostics run.
                </p>
              </div>
            </div>

            {/* Quick Natural Language Bar */}
            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#E5A93C]" />
                  <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                    Query Historical & Predictive Continuity
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-[#738297]">
                  Timeline Grounded • Zero Fabrication
                </span>
              </div>
              <form onSubmit={handleAskGideon} className="flex items-center gap-2">
                <input
                  type="text"
                  value={askQuery}
                  onChange={(e) => setAskQuery(e.target.value)}
                  placeholder="Ask GIDEON: e.g. What changed since the last deployment? What is blocking progress?"
                  className="flex-1 px-4 py-2.5 rounded-xl bg-[#17212C] border border-[#3A4B5F] focus:border-[#E5A93C] focus:outline-none text-xs text-white placeholder-[#738297]"
                />
                <button
                  type="submit"
                  disabled={!askQuery.trim() || asking}
                  className="px-4 py-2.5 rounded-xl bg-[#E5A93C] hover:bg-[#d89b30] text-slate-950 text-xs font-bold font-mono flex items-center gap-1.5 cursor-pointer disabled:opacity-40"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{asking ? 'Analyzing...' : 'Ask'}</span>
                </button>
              </form>

              {askResult && (
                <div className="p-4 rounded-xl bg-[#17212C] border border-[#E5A93C]/40 space-y-2 mt-3 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono font-bold text-[#E5A93C] flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      GIDEON Synthesis Response ({askResult.confidence} Confidence)
                    </span>
                    <button
                      onClick={() => setAskResult(null)}
                      className="text-[10px] font-mono text-[#738297] hover:text-white"
                    >
                      Clear
                    </button>
                  </div>
                  <p className="text-xs text-[#E2E8F0] whitespace-pre-wrap leading-relaxed font-sans">
                    {askResult.answer}
                  </p>
                  {askResult.evidenceEvents.length > 0 && (
                    <div className="pt-2 border-t border-[#283544]/60 text-[11px] font-mono text-[#738297] space-y-1">
                      <span className="font-bold text-[#A2AFBF]">Supporting Timeline Evidence:</span>
                      {askResult.evidenceEvents.map(ev => (
                        <div key={ev.eventId} className="flex items-center gap-2 text-[#66E3CB]">
                          <ArrowRight className="w-3 h-3 shrink-0" />
                          <span>[{new Date(ev.occurredAt).toLocaleTimeString()}] {ev.title} ({ev.category})</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Split View: Recent Events vs Active Decisions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Timeline Stream */}
              <div className="p-5 rounded-xl bg-[#111821] border border-[#283544] space-y-3">
                <div className="flex items-center justify-between border-b border-[#283544] pb-3">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#E5A93C]" />
                    <h3 className="text-xs font-mono font-bold text-white uppercase">Recent Timeline Activity</h3>
                  </div>
                  <button
                    onClick={() => setActiveTab('timeline')}
                    className="text-[11px] font-mono text-[#E5A93C] hover:underline"
                  >
                    View All ({events.length}) →
                  </button>
                </div>
                <div className="space-y-2.5">
                  {events.slice(0, 5).map((ev) => (
                    <div
                      key={ev.eventId}
                      onClick={() => setSelectedEvent(ev)}
                      className="p-3 rounded-lg bg-[#17212C] border border-[#283544] hover:border-[#E5A93C]/40 transition-colors cursor-pointer space-y-1"
                    >
                      <div className="flex items-center justify-between text-[11px] font-mono">
                        <span className="font-bold text-white truncate mr-2">{ev.title}</span>
                        <span className="text-[#738297] shrink-0">{new Date(ev.occurredAt).toLocaleTimeString()}</span>
                      </div>
                      <p className="text-xs text-[#A2AFBF] line-clamp-2">{ev.summary}</p>
                      <div className="flex items-center gap-2 pt-1 text-[10px] font-mono text-[#738297]">
                        <span className="px-1.5 py-0.5 rounded bg-[#0B0F14] text-[#E5A93C] border border-[#283544]">
                          {ev.category}
                        </span>
                        <span>Source: {ev.source}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Architectural Decision Records */}
              <div className="p-5 rounded-xl bg-[#111821] border border-[#283544] space-y-3">
                <div className="flex items-center justify-between border-b border-[#283544] pb-3">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#66E3CB]" />
                    <h3 className="text-xs font-mono font-bold text-white uppercase">Architectural Decisions (ADRs)</h3>
                  </div>
                  <button
                    onClick={() => setActiveTab('decisions')}
                    className="text-[11px] font-mono text-[#66E3CB] hover:underline"
                  >
                    Manage ({decisions.length}) →
                  </button>
                </div>
                <div className="space-y-2.5">
                  {decisions.slice(0, 4).map((dec) => (
                    <div
                      key={dec.decisionId}
                      className="p-3 rounded-lg bg-[#17212C] border border-[#283544] space-y-1"
                    >
                      <div className="flex items-center justify-between text-[11px] font-mono">
                        <span className="font-bold text-white">{dec.title}</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {dec.status}
                        </span>
                      </div>
                      <p className="text-xs text-[#A2AFBF] line-clamp-2">{dec.decisionDescription}</p>
                      <p className="text-[10px] font-mono text-[#738297]">
                        Reasoning: {dec.reasoning}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 2: TIMELINE WORKSPACE */}
        {/* ================================================================ */}
        {activeTab === 'timeline' && (
          <div className="max-w-6xl mx-auto space-y-4">
            {/* Filter Bar */}
            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-[#738297] absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search events, commits, tests..."
                    className="pl-8 pr-3 py-1.5 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-white focus:outline-none focus:border-[#E5A93C] w-64"
                  />
                </div>

                {/* Project Filter */}
                <select
                  value={projectFilter}
                  onChange={(e) => setProjectFilter(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-[#A2AFBF] focus:outline-none"
                >
                  <option value="ALL">All Projects</option>
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>

                {/* Category Filter */}
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value as any)}
                  className="px-2.5 py-1.5 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-[#A2AFBF] focus:outline-none"
                >
                  <option value="ALL">All Categories</option>
                  <option value="deployment">Deployments</option>
                  <option value="test">Tests & Builds</option>
                  <option value="configuration">Configuration</option>
                  <option value="security">Security & RBAC</option>
                  <option value="decision">Decisions</option>
                  <option value="diagnostic">Diagnostics</option>
                  <option value="task">Tasks</option>
                  <option value="incident">Incidents</option>
                </select>
              </div>

              <div className="text-[11px] text-[#738297]">
                Showing {events.length} chronological records
              </div>
            </div>

            {/* Event List */}
            <div className="space-y-3">
              {events.map((ev, idx) => (
                <div
                  key={ev.eventId}
                  onClick={() => setSelectedEvent(ev)}
                  className="p-4 rounded-xl bg-[#111821] border border-[#283544] hover:border-[#E5A93C]/50 transition-all cursor-pointer space-y-2 relative"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#E5A93C]" />
                      <h4 className="text-sm font-bold text-white">{ev.title}</h4>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#17212C] text-[#E5A93C] border border-[#283544]">
                        {ev.category}
                      </span>
                      {ev.verificationStatus === 'verified' && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          <span>VERIFIED</span>
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-mono text-[#738297]">
                      {new Date(ev.occurredAt).toLocaleString()}
                    </div>
                  </div>

                  <p className="text-xs text-[#A2AFBF] leading-relaxed">
                    {ev.summary}
                  </p>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#283544]/60 text-[10px] font-mono text-[#738297]">
                    <div className="flex items-center gap-3">
                      <span>Source: <strong className="text-slate-300">{ev.source}</strong></span>
                      {ev.sourceReference && (
                        <span>Ref: <code className="text-[#66E3CB]">{ev.sourceReference}</code></span>
                      )}
                      <span>Project: <strong className="text-slate-300">{ev.projectId || 'Global'}</strong></span>
                    </div>
                    {ev.outcome && (
                      <span className="px-2 py-0.5 rounded bg-[#17212C] text-[#66E3CB] border border-[#283544]">
                        Outcome: {ev.outcome}
                      </span>
                    )}
                  </div>
                </div>
              ))}

              {events.length === 0 && !loading && (
                <div className="p-12 text-center rounded-xl bg-[#111821] border border-[#283544] text-[#738297] font-mono text-xs">
                  No timeline events found matching current criteria. Click "Record Event" to log a new milestone.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 3: ARCHITECTURAL DECISIONS */}
        {/* ================================================================ */}
        {activeTab === 'decisions' && (
          <div className="max-w-6xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white font-mono">
                  Architecture Decision Records (ADRs)
                </h2>
                <p className="text-xs text-[#A2AFBF]">
                  Permanent records preserving architectural choices, alternatives considered, and evidence.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowDecisionModal(true)}
                className="px-3 py-1.5 rounded-xl bg-[#66E3CB] text-slate-950 font-mono font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Decision Record</span>
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {decisions.map((dec) => (
                <div
                  key={dec.decisionId}
                  className="p-5 rounded-xl bg-[#111821] border border-[#283544] space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#E5A93C]/20 text-[#E5A93C] border border-[#E5A93C]/30">
                        {dec.decisionId}
                      </span>
                      <h3 className="text-sm font-bold text-white">{dec.title}</h3>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {dec.status}
                    </span>
                  </div>

                  <p className="text-xs text-[#E2E8F0] leading-relaxed">
                    {dec.decisionDescription}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 text-xs font-mono">
                    <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544]">
                      <span className="text-[10px] text-[#738297] block uppercase font-bold">Reasoning</span>
                      <p className="text-xs text-[#A2AFBF] mt-1">{dec.reasoning}</p>
                    </div>

                    <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544]">
                      <span className="text-[10px] text-[#738297] block uppercase font-bold">Alternatives Considered</span>
                      <ul className="text-xs text-[#A2AFBF] mt-1 list-disc list-inside space-y-0.5">
                        {dec.alternativesConsidered.map((alt, i) => (
                          <li key={i}>{alt}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-[#283544]/60 text-[10px] font-mono text-[#738297]">
                    <span>Owner: {dec.decisionOwner}</span>
                    <span>Created: {new Date(dec.creationTimestamp).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 4: PREDICTIVE ANALYSIS */}
        {/* ================================================================ */}
        {activeTab === 'predictions' && (
          <div className="max-w-6xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white font-mono">
                  Evidence-Based Predictive Intelligence
                </h2>
                <p className="text-xs text-[#A2AFBF]">
                  Calibrated forecasts tracking potential risks, dependencies, and delivery outcomes.
                </p>
              </div>
              <button
                type="button"
                onClick={async () => {
                  setServiceNotice(null);
                  try {
                    await GideonService.generatePrediction('Sprint Delivery & Release Readiness', projectFilter);
                    loadAllData();
                  } catch (error: any) {
                    setServiceNotice(error.message || 'Forecasting is unavailable until verified data sources are connected.');
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-[#A9B8FF] text-slate-950 font-mono font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Generate Forecast</span>
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {predictions.map((pred) => (
                <div
                  key={pred.predictionId}
                  className="p-5 rounded-xl bg-[#111821] border border-[#283544] space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#A9B8FF]/20 text-[#A9B8FF] border border-[#A9B8FF]/30">
                        FORECAST
                      </span>
                      <h3 className="text-sm font-bold text-white">{pred.subject}</h3>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {pred.confidenceAssessment} CONFIDENCE
                    </span>
                  </div>

                  <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544] text-xs text-[#E2E8F0]">
                    <span className="text-[10px] font-mono text-[#E5A93C] uppercase font-bold block mb-1">
                      Projected Outcome ({pred.forecastHorizon})
                    </span>
                    {pred.potentialOutcome}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544]">
                      <span className="text-[10px] text-[#738297] uppercase font-bold block">Supporting Evidence</span>
                      <ul className="text-xs text-[#A2AFBF] mt-1 space-y-1">
                        {pred.supportingEvidence.map((ev, i) => (
                          <li key={i} className="flex items-center gap-1.5">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                            <span>{ev}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544]">
                      <span className="text-[10px] text-[#738297] uppercase font-bold block">Recommended Actions</span>
                      <ul className="text-xs text-[#A2AFBF] mt-1 space-y-1">
                        {pred.recommendedActions.map((rec, i) => (
                          <li key={i} className="flex items-center gap-1.5">
                            <ArrowRight className="w-3 h-3 text-[#66E3CB] shrink-0" />
                            <span>{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 5: SYSTEM DIAGNOSTICS */}
        {/* ================================================================ */}
        {activeTab === 'diagnostics' && (
          <div className="max-w-6xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white font-mono">
                  System Diagnostics & Observation Log
                </h2>
                <p className="text-xs text-[#A2AFBF]">
                  Truthful measurements of backend availability, APIs, model router, and security gates.
                </p>
              </div>
              <button
                type="button"
                onClick={handleRunDiagnostics}
                disabled={diagnosing}
                className="px-3 py-1.5 rounded-xl bg-[#66E3CB] text-slate-950 font-mono font-bold text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${diagnosing ? 'animate-spin' : ''}`} />
                <span>Run Diagnostic Sweep</span>
              </button>
            </div>

            {diagnostics && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {diagnostics.observations.map((obs) => (
                  <div
                    key={obs.observationId}
                    className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white font-mono">{obs.sourceIntegration}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          obs.observedValueOrStatus === 'HEALTHY'
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : obs.observedValueOrStatus === 'DEGRADED'
                            ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                            : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {obs.observedValueOrStatus}
                      </span>
                    </div>

                    <p className="text-xs text-[#A2AFBF] font-sans">
                      {obs.details}
                    </p>

                    <div className="flex items-center justify-between pt-2 border-t border-[#283544]/60 text-[10px] font-mono text-[#738297]">
                      <span>Ref: {obs.serviceReference}</span>
                      {obs.latencyMs !== undefined && (
                        <span>Latency: {obs.latencyMs}ms</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 6: SCENARIOS */}
        {/* ================================================================ */}
        {activeTab === 'scenarios' && (
          <div className="max-w-6xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white font-mono">
                  Scenario Simulator (Zero-Execution Trade-Off Modeling)
                </h2>
                <p className="text-xs text-[#A2AFBF]">
                  Models alternative migrations, schema evolutions, and provider shifts before committing changes.
                </p>
              </div>
              <button
                type="button"
                onClick={async () => {
                  await GideonService.simulateScenario(
                    'Multi-Cloud Model Router Failover',
                    ['Enable automatic fallback between Google Gemini and Ollama Cloud Proxy', 'Buffer client messages during transient upstream retries']
                  );
                  loadAllData();
                }}
                className="px-3 py-1.5 rounded-xl bg-[#E5A93C] text-slate-950 font-mono font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Simulate Scenario</span>
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {scenarios.map((scen) => (
                <div
                  key={scen.scenarioId}
                  className="p-5 rounded-xl bg-[#111821] border border-[#283544] space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white font-mono">{scen.scenarioName}</h3>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/20 text-[#A9B8FF] border border-indigo-500/30">
                      {scen.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544]">
                      <span className="text-[10px] text-emerald-400 uppercase font-bold block">Expected Benefits</span>
                      <ul className="text-xs text-[#A2AFBF] mt-1 space-y-0.5 list-disc list-inside">
                        {scen.expectedBenefits.map((b, i) => (
                          <li key={i}>{b}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544]">
                      <span className="text-[10px] text-rose-400 uppercase font-bold block">Potential Risks</span>
                      <ul className="text-xs text-[#A2AFBF] mt-1 space-y-0.5 list-disc list-inside">
                        {scen.potentialRisks.map((r, i) => (
                          <li key={i}>{r}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] text-xs font-mono text-[#E5A93C]">
                    <strong>Recommended Next Step:</strong> {scen.recommendedNextAction}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 7: ASK GIDEON */}
        {/* ================================================================ */}
        {activeTab === 'ask' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="p-6 rounded-2xl bg-[#111821] border border-[#283544] space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#E5A93C]/15 border border-[#E5A93C]/40 flex items-center justify-center text-[#E5A93C]">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white font-mono">
                    Consult GIDEON Systems Intelligence
                  </h2>
                  <p className="text-xs text-[#A2AFBF]">
                    Ask complex questions regarding project history, deployment timeline, recurring errors, or future risks.
                  </p>
                </div>
              </div>

              {/* Sample Quick Questions */}
              <div className="flex flex-wrap items-center gap-2 pt-2 text-[11px] font-mono">
                <span className="text-[#738297]">Quick Directives:</span>
                {[
                  "Show me what changed since the last deployment",
                  "What caused the last recorded build error?",
                  "What architectural decisions govern our database?",
                  "What are the highest risks for this sprint?"
                ].map((sample, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setAskQuery(sample);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-[#17212C] hover:bg-[#1E2B38] border border-[#283544] text-[#A2AFBF] hover:text-white transition-colors cursor-pointer"
                  >
                    {sample}
                  </button>
                ))}
              </div>

              <form onSubmit={handleAskGideon} className="space-y-3 pt-2">
                <textarea
                  rows={3}
                  value={askQuery}
                  onChange={(e) => setAskQuery(e.target.value)}
                  placeholder="Enter your system continuity or predictive question for GIDEON..."
                  className="w-full px-4 py-3 rounded-xl bg-[#17212C] border border-[#3A4B5F] focus:border-[#E5A93C] focus:outline-none text-xs text-white placeholder-[#738297] font-sans"
                />
                <button
                  type="submit"
                  disabled={!askQuery.trim() || asking}
                  className="px-5 py-2.5 rounded-xl bg-[#E5A93C] hover:bg-[#d89b30] text-slate-950 text-xs font-bold font-mono flex items-center gap-2 cursor-pointer disabled:opacity-40"
                >
                  <Send className="w-4 h-4" />
                  <span>{asking ? 'Evaluating Timeline & Telemetry...' : 'Submit Inquiry to GIDEON'}</span>
                </button>
              </form>

              {askResult && (
                <div className="p-5 rounded-xl bg-[#17212C] border border-[#E5A93C]/50 space-y-3 mt-4 animate-fade-in">
                  <div className="flex items-center justify-between border-b border-[#283544] pb-2">
                    <span className="text-xs font-mono font-bold text-[#E5A93C]">
                      GIDEON Evaluation Report ({askResult.confidence} Confidence)
                    </span>
                    <span className="text-[10px] font-mono text-[#738297]">
                      {new Date().toLocaleTimeString()}
                    </span>
                  </div>

                  <p className="text-xs text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                    {askResult.answer}
                  </p>

                  <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] text-xs font-mono text-[#66E3CB]">
                    <strong>Recommended Next Step:</strong> {askResult.recommendedNextStep}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ==================================================================== */}
      {/* MODAL 1: RECORD EVENT */}
      {/* ==================================================================== */}
      {showEventModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#111821] border border-[#283544] p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#E5A93C]" />
                Record Timeline Event
              </h3>
              <button
                onClick={() => setShowEventModal(false)}
                className="text-[#738297] hover:text-white text-xs font-mono"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="space-y-3">
              <div>
                <label className="text-[10px] font-mono uppercase text-[#738297] block mb-1">
                  Event Title
                </label>
                <input
                  type="text"
                  required
                  value={newEventTitle}
                  onChange={(e) => setNewEventTitle(e.target.value)}
                  placeholder="e.g. Phase 2 Security Gateway Gated"
                  className="w-full px-3 py-2 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-white focus:outline-none focus:border-[#E5A93C]"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-[#738297] block mb-1">
                  Category
                </label>
                <select
                  value={newEventCategory}
                  onChange={(e) => setNewEventCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-white focus:outline-none"
                >
                  <option value="deployment">Deployment</option>
                  <option value="code_change">Code Change</option>
                  <option value="test">Test & Build</option>
                  <option value="configuration">Configuration</option>
                  <option value="security">Security & Permissions</option>
                  <option value="decision">Decision</option>
                  <option value="diagnostic">Diagnostic</option>
                  <option value="task">Task Completion</option>
                  <option value="incident">Incident / Bug</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-[#738297] block mb-1">
                  Summary & Context
                </label>
                <textarea
                  rows={3}
                  value={newEventSummary}
                  onChange={(e) => setNewEventSummary(e.target.value)}
                  placeholder="Details of the event, verification status, and impact..."
                  className="w-full px-3 py-2 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-white focus:outline-none focus:border-[#E5A93C]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEventModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-[#283544] text-xs text-[#A2AFBF] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#E5A93C] text-slate-950 font-mono font-bold text-xs"
                >
                  Save Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* MODAL 2: RECORD DECISION */}
      {/* ==================================================================== */}
      {showDecisionModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-[#111821] border border-[#283544] p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#66E3CB]" />
                New Architecture Decision Record (ADR)
              </h3>
              <button
                onClick={() => setShowDecisionModal(false)}
                className="text-[#738297] hover:text-white text-xs font-mono"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateDecision} className="space-y-3">
              <div>
                <label className="text-[10px] font-mono uppercase text-[#738297] block mb-1">
                  Decision Title
                </label>
                <input
                  type="text"
                  required
                  value={newDecisionTitle}
                  onChange={(e) => setNewDecisionTitle(e.target.value)}
                  placeholder="e.g. Adopt Local-First Vector Indexing with Qwen3-Embedding"
                  className="w-full px-3 py-2 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-white focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-[#738297] block mb-1">
                  Decision Description
                </label>
                <textarea
                  rows={2}
                  required
                  value={newDecisionDesc}
                  onChange={(e) => setNewDecisionDesc(e.target.value)}
                  placeholder="What is the architecture choice being made?"
                  className="w-full px-3 py-2 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-white focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-[#738297] block mb-1">
                  Reasoning & Trade-Offs
                </label>
                <textarea
                  rows={2}
                  value={newDecisionReason}
                  onChange={(e) => setNewDecisionReason(e.target.value)}
                  placeholder="Why was this option chosen over alternatives?"
                  className="w-full px-3 py-2 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-xs text-white focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowDecisionModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-[#283544] text-xs text-[#A2AFBF] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#66E3CB] text-slate-950 font-mono font-bold text-xs"
                >
                  Record Decision
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
