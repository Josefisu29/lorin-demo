import React, { useState } from 'react';
import { KnowledgeCommonsService } from '../services/knowledgeCommons';
import { MosairaKnowledgeSource } from '../types/mosaira';
import { BookOpen, Search, Plus, ExternalLink, ShieldCheck, FileText } from 'lucide-react';

export const MosairaCommons: React.FC = () => {
  const [sources, setSources] = useState<MosairaKnowledgeSource[]>(KnowledgeCommonsService.getSources());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSource, setSelectedSource] = useState<MosairaKnowledgeSource | null>(null);

  // New source form state
  const [showAddForm, setShowAddForm] = useState(false);
  const [title, setTitle] = useState('');
  const [publisher, setPublisher] = useState('');
  const [url, setUrl] = useState('');
  const [license, setLicense] = useState('CC-BY-4.0');
  const [category, setCategory] = useState('Documentation');
  const [content, setContent] = useState('');

  const filteredSources = sources.filter(s =>
    s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.publisher.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddSource = () => {
    if (!title.trim() || !content.trim()) return;

    const chunks = content.split('\n\n').filter(c => c.trim().length > 0);
    const newDoc = KnowledgeCommonsService.addSource({
      title: title.trim(),
      publisher: publisher.trim() || 'Community Contributor',
      url: url.trim() || undefined,
      license,
      category,
      content: content.trim(),
      chunks
    });

    setSources(KnowledgeCommonsService.getSources());
    setShowAddForm(false);
    setTitle('');
    setPublisher('');
    setUrl('');
    setContent('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <BookOpen className="w-6 h-6 text-indigo-500" />
              Public Knowledge Commons (System A)
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Open, searchable, and rights-verified knowledge index used for RAG grounding and source citations.
            </p>
          </div>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 shrink-0 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Contribute Public Source
          </button>
        </div>

        {/* Search */}
        <div className="mt-4 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search public Knowledge Commons documents, papers, and licenses..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Add Source Form Modal */}
      {showAddForm && (
        <div className="p-4 bg-white dark:bg-slate-900 border border-indigo-200 dark:border-indigo-900/50 rounded-xl space-y-3 shadow-lg text-xs">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <h2 className="font-bold text-slate-900 dark:text-slate-100 text-sm">Contribute Document to Knowledge Commons</h2>
            <button onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600">✕</button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold block mb-1">Document Title *</label>
              <input
                type="text"
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Title..."
                className="w-full p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">Publisher / Author</label>
              <input
                type="text"
                value={publisher}
                onChange={e => setPublisher(e.target.value)}
                placeholder="Organization or Author..."
                className="w-full p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">Source URL</label>
              <input
                type="text"
                value={url}
                onChange={e => setUrl(e.target.value)}
                placeholder="https://..."
                className="w-full p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg"
              />
            </div>

            <div>
              <label className="font-semibold block mb-1">License</label>
              <select
                value={license}
                onChange={e => setLicense(e.target.value)}
                className="w-full p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg"
              >
                <option value="CC-BY-4.0">CC-BY-4.0</option>
                <option value="Apache 2.0">Apache 2.0</option>
                <option value="MIT">MIT</option>
                <option value="ODC-By 1.0">ODC-By 1.0</option>
                <option value="Public Domain">Public Domain</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-semibold block mb-1">Document Content *</label>
            <textarea
              rows={4}
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="Paste public document text here..."
              className="w-full p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg font-mono text-[11px]"
            />
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button onClick={() => setShowAddForm(false)} className="px-3 py-1.5 text-slate-600">Cancel</button>
            <button
              onClick={handleAddSource}
              disabled={!title.trim() || !content.trim()}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg disabled:opacity-40"
            >
              Submit Source
            </button>
          </div>
        </div>
      )}

      {/* Sources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredSources.map(s => (
          <div
            key={s.id}
            className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 flex flex-col justify-between hover:border-indigo-500/50 transition-all"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm leading-snug">
                  {s.title}
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800/50 rounded shrink-0">
                  {s.category}
                </span>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed mb-3">
                {s.content}
              </p>

              {/* Unboxed Metadata */}
              <div className="flex items-center gap-2 text-xs text-slate-500 border-t border-slate-100 dark:border-slate-800/80 pt-2.5">
                <span>{s.publisher}</span>
                <span aria-hidden="true">·</span>
                <span>{s.license}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">{s.citationCount} Citations</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setSelectedSource(s)}
                className="py-1.5 px-3 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
              >
                Preview Content
              </button>
              {s.url && (
                <a
                  href={s.url}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  Official Source
                </a>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Source Details Modal */}
      {selectedSource && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                {selectedSource.title}
              </h3>
              <button onClick={() => setSelectedSource(null)} className="text-slate-400">✕</button>
            </div>

            <div className="text-xs space-y-3">
              <div className="flex items-center gap-3 text-slate-500 border-b border-slate-100 dark:border-slate-800 pb-2">
                <span>Publisher: <strong>{selectedSource.publisher}</strong></span>
                <span>License: <strong>{selectedSource.license}</strong></span>
              </div>

              <div>
                <span className="font-bold block mb-1 text-slate-900 dark:text-slate-100">Full Document Content</span>
                <p className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg leading-relaxed whitespace-pre-wrap">
                  {selectedSource.content}
                </p>
              </div>

              <div>
                <span className="font-bold block mb-1 text-slate-900 dark:text-slate-100">RAG Ingest Chunks ({selectedSource.chunks.length})</span>
                <div className="space-y-1.5">
                  {selectedSource.chunks.map((c, i) => (
                    <div key={i} className="p-2 bg-slate-100 dark:bg-slate-800/50 rounded font-mono text-[11px] border border-slate-200 dark:border-slate-700">
                      Chunk {i + 1}: {c}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button onClick={() => setSelectedSource(null)} className="px-4 py-2 text-xs font-semibold bg-indigo-600 text-white rounded-lg">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
