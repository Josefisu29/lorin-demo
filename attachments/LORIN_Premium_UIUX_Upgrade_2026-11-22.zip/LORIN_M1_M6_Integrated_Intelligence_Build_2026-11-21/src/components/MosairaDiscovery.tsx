import React, { useState } from 'react';
import { ModelRegistryService } from '../services/modelRegistry';
import { MosairaPersona, MosairaModel } from '../types/mosaira';
import { Search, Sparkles, Activity, Shield, Cpu, ExternalLink, CheckCircle, AlertCircle } from 'lucide-react';

interface Props {
  onSelectPersonaForPlayground: (personaId: string) => void;
}

export const MosairaDiscovery: React.FC<Props> = ({ onSelectPersonaForPlayground }) => {
  const personas = ModelRegistryService.getPersonas();
  const models = ModelRegistryService.getModels();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTaskFilter, setSelectedTaskFilter] = useState<string>('ALL');
  const [selectedPersonaDetail, setSelectedPersonaDetail] = useState<MosairaPersona | null>(null);

  const filteredPersonas = personas.filter(p => {
    const matchesSearch = p.humanName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.purpose.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTask = selectedTaskFilter === 'ALL' || p.supportedTasks.includes(selectedTaskFilter);
    return matchesSearch && matchesTask;
  });

  const ALL_TASKS = ['ALL', 'Creative Writing', 'Strategic Analysis', 'Full-Stack Coding', 'Document Analysis', 'Image Analysis', 'Voice Dialogue', 'Translation', 'Rapid Summaries', 'SQL Generation', 'Security Audit'];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100 font-sans">
              Model Discovery & Public Personas
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Discover 10 specialized human-named AI personas backed by verified open-weight and cloud model endpoints.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/60 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 shrink-0">
            <Activity className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>10 Personas Active</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">5 Model Endpoints</span>
          </div>
        </div>

        {/* Search & Task Filters */}
        <div className="mt-5 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search personas by name, title, or task capability..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
            {ALL_TASKS.slice(0, 5).map(task => (
              <button
                key={task}
                onClick={() => setSelectedTaskFilter(task)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                  selectedTaskFilter === task
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {task === 'ALL' ? 'All Capabilities' : task}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 10 Persona Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPersonas.map(p => {
          const model = models.find(m => m.modelId === p.underlyingModelId) || models[0];

          return (
            <div
              key={p.id}
              className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-500/50 dark:hover:border-indigo-500/50 transition-all flex flex-col justify-between"
            >
              <div>
                {/* Persona Card Header */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-11 h-11 rounded-lg bg-gradient-to-br ${p.avatarBg} border border-slate-200 dark:border-slate-700 flex items-center justify-center font-bold text-lg text-slate-900 dark:text-slate-100 shrink-0`}
                    >
                      {p.humanName[0]}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-slate-900 dark:text-slate-100 text-base">
                          {p.humanName}
                        </h3>
                        <span className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">
                          ({p.id})
                        </span>
                      </div>
                      <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium">
                        {p.title}
                      </p>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 mb-4 line-clamp-2 leading-relaxed">
                  {p.purpose}
                </p>

                {/* Metadata Line - Unboxed text with separators */}
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800/60 pt-3 mb-4">
                  <span className="font-medium text-slate-700 dark:text-slate-300">{model.displayName}</span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize">{model.openness.toLowerCase().replace('_', ' ')}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{(model.contextLimit / 1024).toFixed(0)}k context</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() => onSelectPersonaForPlayground(p.id)}
                  className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Launch Persona
                </button>
                <button
                  onClick={() => setSelectedPersonaDetail(p)}
                  className="py-2 px-3 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                  Details
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Persona Detail Modal */}
      {selectedPersonaDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${selectedPersonaDetail.avatarBg} flex items-center justify-center font-bold text-slate-900 dark:text-slate-100`}>
                  {selectedPersonaDetail.humanName[0]}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg">
                    {selectedPersonaDetail.humanName} ({selectedPersonaDetail.id})
                  </h3>
                  <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium">
                    {selectedPersonaDetail.title}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPersonaDetail(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
              <div>
                <span className="font-semibold text-slate-900 dark:text-slate-100 block mb-1">Voice & Personality Style</span>
                <p className="bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                  {selectedPersonaDetail.voiceStyle}
                </p>
              </div>

              <div>
                <span className="font-semibold text-slate-900 dark:text-slate-100 block mb-1">Detailed Description</span>
                <p className="leading-relaxed">{selectedPersonaDetail.description}</p>
              </div>

              <div>
                <span className="font-semibold text-slate-900 dark:text-slate-100 block mb-1">Supported Capabilities</span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {selectedPersonaDetail.supportedTasks.map(t => (
                    <span key={t} className="px-2 py-0.5 rounded text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="font-semibold text-slate-900 dark:text-slate-100 block mb-1">System Instructions Snippet</span>
                <pre className="text-[11px] font-mono bg-slate-950 text-slate-200 p-2.5 rounded-lg overflow-x-auto whitespace-pre-wrap">
                  {selectedPersonaDetail.systemInstruction}
                </pre>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setSelectedPersonaDetail(null)}
                className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
              >
                Close
              </button>
              <button
                onClick={() => {
                  const id = selectedPersonaDetail.id;
                  setSelectedPersonaDetail(null);
                  onSelectPersonaForPlayground(id);
                }}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white"
              >
                Launch in Playground
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
