import React, { useState } from 'react';
import {
  Send,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  CornerDownRight,
  Lock,
  Layers,
  FileCheck,
  Search,
  Sparkles,
  RefreshCw,
  Users
} from 'lucide-react';
import {
  EXTENDED_SPECIALIST_LIST,
  EXTENDED_SPECIALISTS,
  SPECIALISTS,
  formatPrivateModelLabel
} from '../data/specialists';
import {
  ApprovalRecord,
  ExtendedSpecialistName,
  LorinCompletionReport,
  Principal,
  SpecialistRole
} from '../types/lorin';
import { PolicyEngine } from '../services/policyEngine';

interface SpecialistConsoleProps {
  principal: Principal;
  onRunInference: (prompt: string, overrideSpecialists?: ExtendedSpecialistName[]) => Promise<LorinCompletionReport>;
  currentReport: LorinCompletionReport | null;
  isLoading: boolean;
  onRefreshApprovals: () => void;
  pendingApprovals: ApprovalRecord[];
  activeExtendedSpecialists?: ExtendedSpecialistName[];
  onToggleExtendedSpecialist?: (name: ExtendedSpecialistName) => void;
  onActivateAllSpecialists?: () => void;
}

const SAMPLE_PROMPTS = [
  {
    label: 'Microservice Auth Policy (Marcus + Lena)',
    prompt: 'Design a zero-trust authentication boundary for a distributed Go microservice with JWT token rotation and scoped RBAC.'
  },
  {
    label: 'High-Impact DB Purge (Approval Test)',
    prompt: 'Purge obsolete staging database records and drop temporary test tables from the production cluster.'
  },
  {
    label: 'Distributed Schema & RAG (Adrian + Elena)',
    prompt: 'Architect a high-throughput RAG indexing and relational schema pipeline with strict public/private tenant isolation.'
  },
  {
    label: 'Full-Stack Code & UX Audit (Ethan + Leo)',
    prompt: 'Evaluate TypeScript API error normalization and WCAG 2.2 AA keyboard navigation across the workspace.'
  }
];

export const SpecialistConsole: React.FC<SpecialistConsoleProps> = ({
  principal,
  onRunInference,
  currentReport,
  isLoading,
  onRefreshApprovals,
  pendingApprovals,
  activeExtendedSpecialists = ['Maya', 'Adrian', 'Ethan', 'Nora', 'Leo', 'Clara', 'Sofia', 'Theo', 'Marcus', 'Elena'],
  onToggleExtendedSpecialist,
  onActivateAllSpecialists
}) => {
  const [prompt, setPrompt] = useState('');
  const [activeSpecialistLens, setActiveSpecialistLens] = useState<'ALL' | SpecialistRole>('ALL');
  const [focusedExtended, setFocusedExtended] = useState<ExtendedSpecialistName | null>(null);
  const [approvalMessage, setApprovalMessage] = useState<string | null>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim() || isLoading) return;
    onRunInference(prompt, activeExtendedSpecialists);
  };

  const handleSelectSample = (samplePrompt: string) => {
    setPrompt(samplePrompt);
    onRunInference(samplePrompt, activeExtendedSpecialists);
  };

  const handleConsultExtendedSpecialist = (name: ExtendedSpecialistName) => {
    const spec = EXTENDED_SPECIALISTS[name];
    if (!spec) return;
    setFocusedExtended(name);
    if (onToggleExtendedSpecialist && !activeExtendedSpecialists.includes(name)) {
      onToggleExtendedSpecialist(name);
    }
    const nextSpecs = activeExtendedSpecialists.includes(name)
      ? activeExtendedSpecialists
      : [...activeExtendedSpecialists, name];
    setPrompt(spec.defaultPrompt);
    onRunInference(spec.defaultPrompt, nextSpecs);
  };

  const handleApprove = async (approvalId: string) => {
    const res = await PolicyEngine.approveAction(approvalId, principal);
    setApprovalMessage(res.message);
    onRefreshApprovals();
    setTimeout(() => setApprovalMessage(null), 4000);
  };

  const handleDeny = async (approvalId: string) => {
    const res = await PolicyEngine.denyAction(approvalId, principal);
    setApprovalMessage(res.message);
    onRefreshApprovals();
    setTimeout(() => setApprovalMessage(null), 4000);
  };

  return (
    <div className="lorin-module-page flex min-h-0 flex-1 flex-col h-full overflow-hidden bg-[#0B0F14]">
      {/* Top Context & Prompt Bar */}
      <div className="p-5 border-b border-[#283544] bg-[#111821]">
        <div className="max-w-6xl mx-auto space-y-3">
          {/* Quick Prompt Suggestions */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <span className="text-[#738297] font-mono text-[11px] whitespace-nowrap">Presets:</span>
            {SAMPLE_PROMPTS.map((sp, idx) => (
              <button
                key={idx}
                onClick={() => handleSelectSample(sp.prompt)}
                disabled={isLoading}
                className="px-2.5 py-1 rounded-lg bg-[#17212C] hover:bg-[#1E2B38] border border-[#283544] hover:border-[#66E3CB]/40 text-slate-200 text-[11px] whitespace-nowrap transition-colors cursor-pointer"
              >
                {sp.label}
              </button>
            ))}
          </div>

          {/* Main Input Form */}
          <form onSubmit={handleSubmit} className="relative flex items-center">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Enter engineering objective, architectural question, or specialist directive for LORIN..."
              disabled={isLoading}
              className="w-full px-4 py-3 pl-11 pr-32 rounded-xl bg-[#17212C] border border-[#3A4B5F] focus:border-[#66E3CB] focus:outline-none text-xs text-white placeholder-[#738297] transition-all font-sans"
            />
            <Search className="w-4 h-4 text-[#738297] absolute left-4" />
            <button
              type="submit"
              disabled={!prompt.trim() || isLoading}
              className="absolute right-2 px-4 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] disabled:opacity-40 text-xs font-bold text-slate-950 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Synthesizing...</span>
                </>
              ) : (
                <>
                  <span>Evaluate</span>
                  <Send className="w-3 h-3" />
                </>
              )}
            </button>
          </form>

          {/* 6 Core Perspectives Lens Filter */}
          <div className="flex items-center gap-2 overflow-x-auto text-xs pt-1">
            <span className="text-[#738297] font-mono text-[11px] mr-1 shrink-0">Core Perspectives (6):</span>
            <button
              onClick={() => setActiveSpecialistLens('ALL')}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                activeSpecialistLens === 'ALL'
                  ? 'bg-[#66E3CB]/15 text-[#66E3CB] border border-[#66E3CB]/40'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              Unified LORIN Report
            </button>
            {(Object.keys(SPECIALISTS) as SpecialistRole[]).map((role) => {
              const spec = SPECIALISTS[role];
              const isSelected = activeSpecialistLens === role;
              return (
                <button
                  key={role}
                  onClick={() => setActiveSpecialistLens(role)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors border cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? 'border-[#66E3CB]/50 bg-[#17212C] text-white'
                      : 'border-[#283544] text-slate-400 hover:text-slate-200 hover:bg-[#17212C]/50'
                  }`}
                >
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: spec.accentColor }}
                  />
                  <span>{spec.name} ({spec.title})</span>
                </button>
              );
            })}
          </div>

          {/* 10 Extended Specialists Roster Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-xs pt-1 border-t border-[#283544]/60">
            <span className="text-[#738297] font-mono text-[11px] mr-1 shrink-0 flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-[#A9B8FF]" />
              <span>Extended Specialists ({activeExtendedSpecialists.length}/10 Active):</span>
            </span>
            {onActivateAllSpecialists && activeExtendedSpecialists.length < 10 && (
              <button
                type="button"
                onClick={onActivateAllSpecialists}
                className="px-2.5 py-1 rounded-lg bg-[#66E3CB]/20 hover:bg-[#66E3CB]/30 border border-[#66E3CB]/50 text-[#66E3CB] text-[10px] font-mono font-bold cursor-pointer whitespace-nowrap"
              >
                Activate All 10
              </button>
            )}
            {EXTENDED_SPECIALIST_LIST.map((ext) => {
              const isActive = activeExtendedSpecialists.includes(ext.name);
              return (
                <button
                  key={ext.name}
                  type="button"
                  onClick={() => onToggleExtendedSpecialist && onToggleExtendedSpecialist(ext.name)}
                  onDoubleClick={() => handleConsultExtendedSpecialist(ext.name)}
                  title={`${ext.name} (${ext.codename} — ${ext.title}). Click to toggle in LORIN synthesis; double-click to run dedicated consultation.`}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-mono flex items-center gap-1.5 transition-all border cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-[#17212C] text-white border-[#66E3CB]/50 shadow-xs'
                      : 'bg-[#0B0F14]/60 text-[#738297] border-[#283544] hover:text-slate-200'
                  }`}
                >
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: isActive ? ext.accentColor : '#475569' }}
                  />
                  <span>{ext.name}</span>
                  <span className="text-[9px] text-[#738297]">({ext.codename})</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Viewport Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Approval Feedback Toast */}
          {approvalMessage && (
            <div className="p-3.5 rounded-xl border border-[#66E3CB]/30 bg-[#66E3CB]/10 text-[#66E3CB] text-xs flex items-center justify-between">
              <span>{approvalMessage}</span>
              <span className="text-slate-400 text-[11px] font-mono">Audit trace recorded</span>
            </div>
          )}

          {/* Pending Action Approval Banners */}
          {pendingApprovals.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs tracking-wider uppercase">
                  <ShieldAlert className="w-4 h-4" />
                  <span>Action-Bound Cryptographic Approvals Required ({pendingApprovals.length})</span>
                </div>
                <span className="text-slate-500 text-[11px] font-mono">Bound to Verified Principal</span>
              </div>

              {pendingApprovals.map((app) => (
                <div
                  key={app.id}
                  className="p-4 rounded-xl bg-[#111821] border border-amber-500/40 text-xs space-y-3 shadow-md"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 font-mono text-amber-300 font-semibold">
                        <Lock className="w-3.5 h-3.5" />
                        <span>Action: {app.action}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 border border-amber-500/30">
                          {app.riskLevel} RISK
                        </span>
                      </div>
                      <div className="text-slate-400 mt-1 font-mono text-[11px]">
                        Target: <span className="text-slate-200">{app.resource}</span>
                      </div>
                    </div>
                    <div className="text-right text-[11px] font-mono text-slate-400">
                      <div>
                        Expires in:{' '}
                        <span className="text-amber-400">
                          {Math.max(0, Math.round((app.expiresAt - Date.now()) / 1000 / 60))}m
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500">ID: {app.id}</div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-[#0B0F14] border border-[#283544] font-mono text-[11px] text-slate-300 break-all">
                    <div className="text-slate-500 text-[10px] mb-1">
                      Cryptographic Digest (SHA-256 bound to action, target & parameters):
                    </div>
                    <div className="text-[#66E3CB]">{app.actionDigest}</div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-[#283544]">
                    <div className="text-[11px] text-slate-500">
                      {principal.role === 'OWNER' ? (
                        <span className="text-emerald-400 font-medium">
                          ✓ Authenticated as OWNER. You can sign or deny.
                        </span>
                      ) : (
                        <span className="text-amber-400 font-medium">
                          ⚠ Verified OWNER clearance required to sign this action.
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleDeny(app.id)}
                        className="px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] text-slate-300 text-xs font-medium transition-colors cursor-pointer"
                      >
                        Deny Action
                      </button>
                      <button
                        onClick={() => handleApprove(app.id)}
                        disabled={principal.role !== 'OWNER'}
                        className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Sign & Authorize (Owner)</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Current Evaluation Report */}
          {currentReport && (
            <div className="space-y-6">
              {/* Report Header Metadata */}
              <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] flex items-center justify-between flex-wrap gap-4">
                <div>
                  <div className="text-xs text-[#738297] uppercase tracking-wider font-mono">Evaluated Objective</div>
                  <div className="text-sm font-semibold text-white mt-0.5">{currentReport.objective}</div>
                </div>
                <div className="flex items-center gap-4 text-xs font-mono">
                  <div>
                    <span className="text-[#738297]">Status: </span>
                    <span
                      className={`font-semibold ${
                        currentReport.status === 'VERIFIED'
                          ? 'text-emerald-400'
                          : currentReport.status === 'COMPLETED'
                          ? 'text-[#66E3CB]'
                          : currentReport.status === 'AWAITING_APPROVAL'
                          ? 'text-amber-400'
                          : 'text-slate-300'
                      }`}
                    >
                      {currentReport.status}
                    </span>
                  </div>
                  <div className="border-l border-[#283544] pl-4">
                    <span className="text-[#738297]">Engine: </span>
                    <span className="text-[#A9B8FF]">
                      {formatPrivateModelLabel(currentReport.modelAttribution?.actualModel || currentReport.backendUsed)}
                    </span>
                  </div>
                  <div className="border-l border-[#283544] pl-4">
                    <span className="text-[#738297]">Latency: </span>
                    <span className="text-slate-300 tabular-nums">{currentReport.latencyMs}ms</span>
                  </div>
                </div>
              </div>

              {activeSpecialistLens === 'ALL' ? (
                <div className="space-y-6">
                  {/* Executive Synthesis Card */}
                  <div className="p-5 rounded-xl bg-[#111821] border border-[#283544] space-y-4">
                    <div className="flex items-center justify-between border-b border-[#283544] pb-3">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-[#66E3CB]" />
                        <h3 className="text-sm font-semibold text-white">Unified Specialist Synthesis</h3>
                      </div>
                      <span className="text-[#738297] text-xs font-mono">
                        5 Core Perspectives + {activeExtendedSpecialists.length} Extended Specialists Active
                      </span>
                    </div>

                    <div className="text-xs text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                      {currentReport.rawSynthesis}
                    </div>
                  </div>

                  {/* Structured LORIN Report Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
                      <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs tracking-wider">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Completed Actions</span>
                      </div>
                      <ul className="space-y-1.5 text-xs text-slate-300">
                        {currentReport.completed.map((item, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-emerald-500 mt-0.5">·</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
                      <div className="flex items-center gap-2 text-[#66E3CB] font-semibold text-xs tracking-wider">
                        <FileCheck className="w-4 h-4" />
                        <span>Verification & Evidence (Iris + Nora)</span>
                      </div>
                      <div className="text-xs text-slate-300">
                        <p>{currentReport.verification.evidence}</p>
                        <div className="mt-2 text-[11px] font-mono text-slate-400 flex items-center gap-2">
                          <span>
                            Tested: <strong className="text-emerald-400">{currentReport.verification.tested ? 'Yes' : 'Runtime'}</strong>
                          </span>
                          <span>·</span>
                          <span>
                            Criteria Met:{' '}
                            <strong className="text-emerald-400">
                              {currentReport.verification.acceptanceCriteriaMet ? 'True' : 'Pending'}
                            </strong>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
                      <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs tracking-wider">
                        <AlertTriangle className="w-4 h-4" />
                        <span>Residual Risks & Boundaries (Lena + Marcus)</span>
                      </div>
                      <ul className="space-y-1 text-xs text-slate-300">
                        {currentReport.risks.map((item, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-amber-500 mt-0.5">·</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-2">
                      <div className="flex items-center gap-2 text-[#A9B8FF] font-semibold text-xs tracking-wider">
                        <ArrowRight className="w-4 h-4" />
                        <span>Immediate Next Step (Owen + Theo)</span>
                      </div>
                      <div className="text-xs text-slate-300">
                        <p className="font-medium text-slate-100">{currentReport.nextStep}</p>
                        {currentReport.outstanding.length > 0 && (
                          <div className="mt-2 text-[11px] text-slate-400">
                            <span>Outstanding: </span>
                            {currentReport.outstanding.join(', ')}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {(() => {
                    const spec = SPECIALISTS[activeSpecialistLens];
                    const output = currentReport.specialistBreakdown[activeSpecialistLens];
                    if (!output) return null;

                    return (
                      <div className="p-5 rounded-xl bg-[#111821] border border-[#283544] space-y-4">
                        <div className="flex items-center justify-between border-b border-[#283544] pb-3">
                          <div className="flex items-center gap-3">
                            <div
                              className="w-3.5 h-3.5 rounded-full"
                              style={{ backgroundColor: spec.accentColor }}
                            />
                            <div>
                              <h3 className="text-base font-bold text-white">
                                {spec.name} — {spec.title}
                              </h3>
                              <p className="text-xs text-slate-400">{spec.domain}</p>
                            </div>
                          </div>
                          <span className="text-xs font-mono text-slate-500 italic">"{spec.guidingQuestion}"</span>
                        </div>

                        <div className="text-sm text-slate-200 leading-relaxed">{output.summary}</div>

                        <div>
                          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 font-mono">
                            Specialist Key Insights
                          </div>
                          <ul className="space-y-2">
                            {output.keyInsights.map((insight, idx) => (
                              <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                                <CornerDownRight className="w-3.5 h-3.5 text-[#66E3CB] shrink-0 mt-0.5" />
                                <span>{insight}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          )}

          {/* Complete 15-Specialist Architecture Roster (5 Core Perspectives + 10 Extended Domain Specialists) */}
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#66E3CB]" />
                  <span>LORIN Complete Specialist Intelligence Roster (5 Core + 10 Extended)</span>
                </h2>
                <p className="text-xs text-[#738297] mt-0.5">
                  Toggle specialists to include their domain synthesis in LORIN, or click "Consult with LORIN" to launch a targeted domain evaluation.
                </p>
              </div>
              <span className="text-xs font-mono text-[#66E3CB]">
                {activeExtendedSpecialists.length} / 10 Extended Active
              </span>
            </div>

            {/* 5 Core Perspectives Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
              {(Object.keys(SPECIALISTS) as SpecialistRole[]).map((r) => {
                const s = SPECIALISTS[r];
                return (
                  <div
                    key={r}
                    className="p-3.5 rounded-xl bg-[#111821] border border-[#283544] text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 font-bold text-white">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.accentColor }} />
                        <span>{s.name}</span>
                      </div>
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#17212C] text-[#66E3CB] border border-[#283544]">
                        CORE
                      </span>
                    </div>
                    <div className="text-[11px] font-semibold text-[#A9B8FF]">{s.title}</div>
                    <p className="text-[11px] text-[#738297] line-clamp-2 leading-relaxed">{s.domain}</p>
                  </div>
                );
              })}
            </div>

            {/* 10 Extended Specialists Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
              {EXTENDED_SPECIALIST_LIST.map((ext) => {
                const isActive = activeExtendedSpecialists.includes(ext.name);
                const isFocused = focusedExtended === ext.name;
                return (
                  <div
                    key={ext.name}
                    className={`p-3.5 rounded-xl border text-xs flex flex-col justify-between gap-3 transition-all ${
                      isActive
                        ? 'bg-[#111821] border-[#66E3CB]/50 shadow-sm'
                        : 'bg-[#111821]/60 border-[#283544] hover:border-[#3A4B5F]'
                    } ${isFocused ? 'ring-1 ring-[#66E3CB]' : ''}`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 font-bold text-white">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: ext.accentColor }} />
                          <span>{ext.name}</span>
                          <span className="text-[10px] font-mono text-[#738297]">({ext.codename})</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => onToggleExtendedSpecialist && onToggleExtendedSpecialist(ext.name)}
                          className={`text-[9px] font-mono px-1.5 py-0.5 rounded border cursor-pointer ${
                            isActive
                              ? 'bg-[#66E3CB]/15 text-[#66E3CB] border-[#66E3CB]/40'
                              : 'bg-[#17212C] text-[#738297] border-[#283544]'
                          }`}
                        >
                          {isActive ? 'ACTIVE' : 'STANDBY'}
                        </button>
                      </div>
                      <div className="text-[11px] font-medium text-[#A9B8FF]">{ext.title}</div>
                      <p className="text-[11px] text-[#A2AFBF] leading-relaxed line-clamp-3">
                        {ext.description}
                      </p>
                    </div>

                    <button
                      type="button"
                      disabled={isLoading}
                      onClick={() => handleConsultExtendedSpecialist(ext.name)}
                      className="w-full py-1.5 px-2.5 rounded-lg bg-[#17212C] hover:bg-[#283544] border border-[#283544] text-[11px] font-mono text-[#66E3CB] flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-40"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>Consult {ext.name}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
