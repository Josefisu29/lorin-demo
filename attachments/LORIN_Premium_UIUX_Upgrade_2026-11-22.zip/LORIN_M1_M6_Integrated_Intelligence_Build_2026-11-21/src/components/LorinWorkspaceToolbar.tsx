import React from 'react';
import {
  Bell,
  ChevronDown,
  FolderKanban,
  LockKeyhole,
  Mic,
  Search,
  Settings2,
  ShieldCheck,
  Video,
} from 'lucide-react';
import { LorinProfileConfig, Principal, WorkspaceView } from '../types/lorin';
import { ProjectStore } from '../services/projectStore';

interface Props {
  currentView: WorkspaceView;
  principal: Principal;
  activeProjectId: string;
  onSelectProject: (id: string) => void;
  pendingApprovalsCount: number;
  isMicActive: boolean;
  isCameraActive: boolean;
  profileConfig: LorinProfileConfig;
  onOpenSearch: () => void;
  onOpenApprovals: () => void;
  onOpenModeAndAccess: () => void;
  onOpenSettings: () => void;
}

const VIEW_META: Partial<Record<WorkspaceView, { title: string; eyebrow: string; description: string }>> = {
  chat: { eyebrow: 'WORKSPACE / CONVERSATION', title: 'Conversation', description: 'Think, explore, research and build with LORIN.' },
  projects: { eyebrow: 'WORKSPACE / PROJECTS', title: 'Projects', description: 'Your workspaces, decisions and engineering activity.' },
  specialists: { eyebrow: 'INTELLIGENCE / CAPABILITIES', title: 'Capabilities', description: 'Focused perspectives coordinated through one LORIN identity.' },
  voice: { eyebrow: 'INTERACTION / VOICE', title: 'Voice conversation', description: 'Speak with LORIN when you choose to activate the microphone.' },
  video: { eyebrow: 'INTERACTION / VISION', title: 'Visual intelligence', description: 'Review images and explicitly enabled camera input.' },
  vault: { eyebrow: 'KNOWLEDGE / VAULT', title: 'Knowledge Vault', description: 'Private documents, sources and retrieval.' },
  laurenVault: { eyebrow: 'KNOWLEDGE / PRIVATE VAULT', title: 'Private Vault', description: 'Manage protected knowledge and approved records.' },
  memory: { eyebrow: 'KNOWLEDGE / MEMORY', title: 'Memory', description: 'Review and govern what LORIN is allowed to remember.' },
  tasks: { eyebrow: 'EXECUTION / TASKS', title: 'Tasks & automation', description: 'Review jobs, approvals and verified outcomes.' },
  security: { eyebrow: 'CONTROL / SECURITY', title: 'Security & approvals', description: 'Permissions, authorization and audit history.' },
  connections: { eyebrow: 'CONTROL / INTEGRATIONS', title: 'Connections', description: 'Manage connected services and access.' },
  terminal: { eyebrow: 'ENGINEERING / WORKBENCH', title: 'Engineering workbench', description: 'Inspect, test and work with approved development tools.' },
  tests: { eyebrow: 'ENGINEERING / VERIFICATION', title: 'Verification', description: 'Review system checks and acceptance evidence.' },
  settings: { eyebrow: 'PREFERENCES / SETTINGS', title: 'Settings', description: 'Configure your LORIN experience and runtime preferences.' },
  mosairaLab: { eyebrow: 'SEPARATE PLATFORM / MOSAIRA', title: 'MOSAIRA AI Lab', description: 'A separate platform with its own access and data boundaries.' },
  ownerGateway: { eyebrow: 'CONTROL / OWNER', title: 'Owner control', description: 'Manage privileged operations and system configuration.' },
  gideon: { eyebrow: 'INTELLIGENCE / CONTINUITY', title: 'GIDEON', description: 'Verified chronology, continuity and diagnostics.' },
  deviceCenter: { eyebrow: 'CONTROL / DEVICES', title: 'Devices & local companion', description: 'Manage paired devices and local runtime connections.' },
};

export const LorinWorkspaceToolbar: React.FC<Props> = ({
  currentView,
  principal,
  activeProjectId,
  onSelectProject,
  pendingApprovalsCount,
  isMicActive,
  isCameraActive,
  profileConfig,
  onOpenSearch,
  onOpenApprovals,
  onOpenModeAndAccess,
  onOpenSettings,
}) => {
  const meta = VIEW_META[currentView] || { eyebrow: 'LORIN / WORKSPACE', title: 'Workspace', description: 'Your private personal intelligence workspace.' };
  const projects = ProjectStore.getProjects();
  const selectedProjectId = projects.some((project) => project.id === activeProjectId)
    ? activeProjectId
    : (projects[0]?.id || '');
  const runtimePreference = profileConfig.runtimeActivation === 'ONLINE_ACTIVE'
    ? 'Cloud-enabled preference'
    : 'Local-first preference';

  return (
    <header className="lorin-commandbar shrink-0" aria-label="Workspace controls">
      <div className="lorin-commandbar__identity min-w-0">
        <div className="lorin-commandbar__eyebrow">{meta.eyebrow}</div>
        <div className="flex items-baseline gap-3 min-w-0">
          <h1 className="lorin-commandbar__title truncate">{meta.title}</h1>
          <p className="lorin-commandbar__description hidden xl:block truncate">{meta.description}</p>
        </div>
      </div>

      <div className="lorin-commandbar__context">
        <label className="lorin-context-select" title="Choose the active project context">
          <FolderKanban aria-hidden="true" size={15} />
          <span className="sr-only">Active project</span>
          <select
            aria-label="Active project context"
            value={selectedProjectId}
            onChange={(event) => onSelectProject(event.target.value)}
            disabled={projects.length === 0}
          >
            {projects.length === 0 ? <option value="">No projects</option> : projects.map((project) => (
              <option key={project.id} value={project.id}>{project.name}</option>
            ))}
          </select>
          <ChevronDown aria-hidden="true" size={13} />
        </label>
      </div>

      <div className="lorin-commandbar__actions">
        <span className="lorin-privacy-chip" title="This is the authenticated private workspace. This label does not imply that every integration is connected.">
          <LockKeyhole size={13} aria-hidden="true" />
          <span className="hidden 2xl:inline">Private workspace</span>
        </span>

        <span className="lorin-runtime-chip" title={`Configured runtime preference: ${runtimePreference}. Provider health is shown separately when measured.`}>
          <span className="lorin-runtime-chip__dot" aria-hidden="true" />
          <span className="hidden xl:inline">{runtimePreference}</span>
          <span className="xl:hidden">{profileConfig.runtimeActivation === 'ONLINE_ACTIVE' ? 'Cloud pref.' : 'Local pref.'}</span>
        </span>

        {isMicActive && <span className="lorin-hardware-chip lorin-hardware-chip--active" title="Microphone capture is active"><Mic size={13} /> <span className="hidden sm:inline">Mic active</span></span>}
        {isCameraActive && <span className="lorin-hardware-chip lorin-hardware-chip--active" title="Camera preview is active"><Video size={13} /> <span className="hidden sm:inline">Camera active</span></span>}

        <button type="button" className="lorin-toolbar-icon" onClick={onOpenSearch} aria-label="Search workspace" title="Search workspace · Ctrl/⌘ K">
          <Search size={17} />
          <kbd className="hidden 2xl:inline">⌘ K</kbd>
        </button>

        <button
          type="button"
          className={`lorin-toolbar-icon relative ${pendingApprovalsCount > 0 ? 'lorin-toolbar-icon--attention' : ''}`}
          onClick={onOpenApprovals}
          aria-label={pendingApprovalsCount > 0 ? `${pendingApprovalsCount} pending approvals` : 'Approvals and security'}
          title="Review security approvals"
        >
          <Bell size={17} />
          {pendingApprovalsCount > 0 && <span className="lorin-notification-count">{pendingApprovalsCount > 99 ? '99+' : pendingApprovalsCount}</span>}
        </button>

        <button type="button" className="lorin-toolbar-action hidden sm:inline-flex" onClick={onOpenModeAndAccess} title="Operating mode and autonomy settings">
          <Settings2 size={15} />
          <span className="hidden xl:inline">Mode</span>
        </button>

        <button type="button" className="lorin-toolbar-icon" onClick={onOpenSettings} aria-label="Open settings" title="Settings">
          <ShieldCheck size={17} />
        </button>

        <div className="lorin-user-chip" title={`${principal.name || 'User'} · authenticated session`}>
          <span className="lorin-user-chip__avatar">{(principal.name || 'U').trim().charAt(0).toUpperCase()}</span>
          <span className="hidden 2xl:block max-w-24 truncate">{principal.name || 'User'}</span>
        </div>
      </div>
    </header>
  );
};
