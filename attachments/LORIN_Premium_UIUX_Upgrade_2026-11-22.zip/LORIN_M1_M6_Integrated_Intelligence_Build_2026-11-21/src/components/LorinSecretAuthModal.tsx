import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Lock, Key, Plus, Trash2, CheckCircle2, AlertTriangle, X, Sparkles, UserCheck, Mail, RefreshCw, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import {
  auth,
  signInWithEmailAccount,
  registerWithEmailAccount,
  sendPasswordResetForEmail,
  sendVerificationToCurrentUser,
  refreshCurrentUserIdToken,
  refreshCurrentUserTokenAndClaims,
  configureSessionPersistence,
  getMultiFactorStatus
} from '../services/firebase';
import { Principal, isSuperAdminOrOwnerPrincipal, isSystemOwnerPrincipal, normalizeCanonicalRole } from '../types/lorin';

interface LorinSecretAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  principal: Principal;
  onOpenPrivateGateway: () => void;
  onInstantActivateOwner?: () => void;
  onExplicitSignOut?: () => void;
}

export const LorinSecretAuthModal: React.FC<LorinSecretAuthModalProps> = ({
  isOpen,
  onClose,
  principal,
  onOpenPrivateGateway,
  onInstantActivateOwner,
  onExplicitSignOut
}) => {
  const [ownerEmails, setOwnerEmails] = useState<string[]>([]);
  const [primaryOwner, setPrimaryOwner] = useState<string>('');
  const [newEmail, setNewEmail] = useState('');
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Email/Password Auth State
  const [authMode, setAuthMode] = useState<'signin' | 'register' | 'reset'>('signin');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authDisplayName, setAuthDisplayName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberSession, setRememberSession] = useState(true);
  const [registrationPolicy, setRegistrationPolicy] = useState<'INVITE_ONLY' | 'DOMAIN_RESTRICTED' | 'OPEN_STANDARD'>('INVITE_ONLY');

  const canonicalRole = normalizeCanonicalRole(principal.canonicalRole || principal.role);
  const isSystemOwner = isSystemOwnerPrincipal(principal);
  const isPrivileged = isSuperAdminOrOwnerPrincipal(principal);
  const mfaStatus = getMultiFactorStatus(auth.currentUser);
  const isAuthorizedActiveUser = principal.authenticated &&
    principal.accountStatus !== 'DISABLED' &&
    principal.accountStatus !== 'REVOKED' &&
    (isSuperAdminOrOwnerPrincipal(principal) || canonicalRole !== 'RESTRICTED' || isSystemOwner);

  const fetchOwnerEmails = async () => {
    try {
      const user = auth.currentUser;
      if (!user) return;
      const idToken = await user.getIdToken();
      const res = await fetch('/api/owner/emails', {
        headers: { Authorization: `Bearer ${idToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setOwnerEmails(data.emails || []);
        if (data.primaryOwner) setPrimaryOwner(data.primaryOwner);
      }
    } catch {
      // Ignore
    }
  };

  useEffect(() => {
    if (isOpen) {
      if (principal.authorizedOwnerEmails && principal.authorizedOwnerEmails.length > 0) {
        setOwnerEmails(principal.authorizedOwnerEmails);
      }
      fetchOwnerEmails();
      fetch('/api/rbac/registration-status')
        .then(r => (r.ok ? r.json() : null))
        .then(data => {
          if (data?.registrationPolicy) {
            setRegistrationPolicy(data.registrationPolicy);
          }
        })
        .catch(() => {});
    }
  }, [isOpen, principal.authorizedOwnerEmails]);

  const handleGoogleSignIn = async () => {
    setIsSubmitting(true);
    setStatusMsg(null);
    try {
      await configureSessionPersistence(rememberSession);
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      setStatusMsg({ type: 'success', text: 'Authentication successful. Resolving centralized RBAC clearance...' });
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'Failed to authenticate via Google.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEmailAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = authEmail.trim().toLowerCase();
    if (!cleanEmail.includes('@')) {
      setStatusMsg({ type: 'error', text: 'Please enter a valid email address.' });
      return;
    }

    setIsSubmitting(true);
    setStatusMsg(null);
    try {
      await configureSessionPersistence(rememberSession);
      if (authMode === 'reset') {
        await sendPasswordResetForEmail(cleanEmail);
        setStatusMsg({ type: 'success', text: `Password reset email sent to ${cleanEmail}.` });
      } else if (authMode === 'register') {
        if (authPassword.length < 6) {
          setStatusMsg({ type: 'error', text: 'Password must be at least 6 characters.' });
          setIsSubmitting(false);
          return;
        }
        // Verify registration policy (INVITE_ONLY blocks uninvited public accounts)
        try {
          const checkRes = await fetch(`/api/rbac/registration-status?email=${encodeURIComponent(cleanEmail)}`);
          if (checkRes.ok) {
            const checkData = await checkRes.json();
            if (checkData.registrationPolicy === 'INVITE_ONLY' && !checkData.eligibleForRegistration) {
              setStatusMsg({
                type: 'error',
                text: 'Registration blocked: Invite-only policy is active. Only pre-invited accounts or the designated System Owner can register.'
              });
              setIsSubmitting(false);
              return;
            }
          }
        } catch {
          // Proceed if offline check unavailable
        }
        await registerWithEmailAccount(cleanEmail, authPassword);
        setStatusMsg({ type: 'success', text: 'Account registered and signed in. Resolving role policy...' });
      } else {
        await signInWithEmailAccount(cleanEmail, authPassword);
        setStatusMsg({ type: 'success', text: 'Signed in with email/password. Resolving role policy...' });
      }
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'Authentication failed.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRefreshToken = async () => {
    setIsSubmitting(true);
    try {
      const { token } = await refreshCurrentUserTokenAndClaims();
      const fallbackToken = token || (await refreshCurrentUserIdToken());
      if (fallbackToken) {
        setStatusMsg({ type: 'success', text: 'Firebase ID token, email verification, and custom role claims refreshed.' });
      } else {
        setStatusMsg({ type: 'error', text: 'No active Firebase session to refresh.' });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSendVerification = async () => {
    setIsSubmitting(true);
    try {
      const sent = await sendVerificationToCurrentUser();
      setStatusMsg({
        type: sent ? 'success' : 'error',
        text: sent ? 'Verification email sent to your address.' : 'Unable to send verification email.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch {
      // Ignore
    }
    if (onExplicitSignOut) {
      onExplicitSignOut();
    }
    setStatusMsg({ type: 'info', text: 'Signed out and cleared session state.' });
  };

  const handleAddEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail || !newEmail.includes('@')) {
      setStatusMsg({ type: 'error', text: 'Please enter a valid email address.' });
      return;
    }

    setIsSubmitting(true);
    setStatusMsg(null);

    try {
      const user = auth.currentUser;
      if (!user) throw new Error('Authentication required.');
      const idToken = await user.getIdToken();

      const res = await fetch('/api/owner/emails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`
        },
        body: JSON.stringify({ email: newEmail.trim().toLowerCase() })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || 'Failed to add owner email.');
      }

      setOwnerEmails(data.emails || []);
      setNewEmail('');
      setStatusMsg({ type: 'success', text: data.message || `Added ${newEmail} to authorized owners.` });
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'Failed to add owner email.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRemoveEmail = async (emailToRemove: string) => {
    if (emailToRemove === primaryOwner) {
      setStatusMsg({ type: 'error', text: 'Cannot remove primary owner email.' });
      return;
    }

    setIsSubmitting(true);
    setStatusMsg(null);

    try {
      const user = auth.currentUser;
      if (!user) throw new Error('Authentication required.');
      const idToken = await user.getIdToken();

      const res = await fetch('/api/owner/emails', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`
        },
        body: JSON.stringify({ email: emailToRemove })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || 'Failed to remove owner email.');
      }

      setOwnerEmails(data.emails || []);
      setStatusMsg({ type: 'success', text: data.message || `Removed ${emailToRemove}.` });
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'Failed to remove owner email.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="w-full max-w-lg bg-[#0e1626] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-100 font-sans"
        >
          {/* Header */}
          <div className="px-6 py-5 bg-[#121c30] border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-400">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span>LORIN Centralized Identity & RBAC Gateway</span>
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 rounded">
                    FIREBASE AUTH
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  System Owner, Super Admin & Role-Scoped Identity Verification
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
            {/* Status Message */}
            {statusMsg && (
              <div
                className={`p-3.5 rounded-xl border text-xs flex items-center gap-2.5 ${
                  statusMsg.type === 'success'
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                    : statusMsg.type === 'error'
                    ? 'bg-rose-950/40 border-rose-500/40 text-rose-200'
                    : 'bg-sky-950/40 border-sky-500/40 text-sky-200'
                }`}
              >
                {statusMsg.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                {statusMsg.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />}
                {statusMsg.type === 'info' && <Shield className="w-4 h-4 text-sky-400 shrink-0" />}
                <span>{statusMsg.text}</span>
              </div>
            )}

            {/* Current Access State */}
            {isAuthorizedActiveUser ? (
              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-bold text-emerald-300">Verified Identity Session Active</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={handleRefreshToken}
                      className="text-[11px] font-mono text-teal-400 hover:underline flex items-center gap-1 cursor-pointer"
                      title="Force refresh Firebase ID token"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Refresh Token</span>
                    </button>
                    <button
                      onClick={handleSignOut}
                      className="text-[11px] font-mono text-slate-400 hover:text-rose-300 underline cursor-pointer"
                    >
                      Sign Out
                    </button>
                  </div>
                </div>
                <div className="text-xs text-slate-300 space-y-1">
                  <p>
                    <span className="text-slate-400">Authenticated Email:</span>{' '}
                    <span className="font-mono text-white font-semibold">{principal.email}</span>
                  </p>
                  <p>
                    <span className="text-slate-400">Canonical Role:</span>{' '}
                    <span className="font-mono text-teal-400 font-bold">{canonicalRole}</span>
                  </p>
                  <p>
                    <span className="text-slate-400">Account Status:</span>{' '}
                    <span className="font-mono text-emerald-400 font-semibold">{principal.accountStatus || 'ACTIVE'}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="text-slate-400">Email Verification:</span>{' '}
                    <span className={`font-mono font-semibold ${principal.emailVerified !== false ? 'text-emerald-400' : 'text-amber-300'}`}>
                      {principal.emailVerified !== false ? 'VERIFIED' : 'PENDING VERIFICATION'}
                    </span>
                  </p>
                  {isPrivileged && (
                    <p className="flex items-center gap-2">
                      <span className="text-slate-400">Privileged MFA Status:</span>{' '}
                      <span className="inline-flex items-center gap-1 font-mono text-[11px] text-teal-300">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        {mfaStatus.enrolled ? `ENROLLED (${mfaStatus.enrolledFactorsCount} factor)` : 'READY FOR ENROLLMENT'}
                      </span>
                    </p>
                  )}
                </div>

                {auth.currentUser && !auth.currentUser.emailVerified && (
                  <div className="pt-1 flex items-center gap-4">
                    <button
                      type="button"
                      onClick={handleSendVerification}
                      className="text-[11px] font-mono text-amber-300 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Mail className="w-3 h-3" />
                      <span>Send Verification Link</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleRefreshToken}
                      className="text-[11px] font-mono text-teal-300 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Refresh Verification Status</span>
                    </button>
                  </div>
                )}

                <div className="pt-2">
                  <button
                    onClick={() => {
                      onOpenPrivateGateway();
                      onClose();
                    }}
                    className="w-full py-2.5 px-4 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Launch LORIN Private Assistant Gateway</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
                <div className="text-xs text-slate-300 space-y-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-white">Identity Verification Required</h4>
                    <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-teal-300">
                      POLICY: {registrationPolicy}
                    </span>
                  </div>
                  <p className="text-slate-400 text-[11px]">
                    Authenticate via Google OAuth or Email/Password. Your canonical role (`SYSTEM_OWNER`, `SUPER_ADMIN`, `ADMINISTRATOR`, `SPECIALIST`, `STANDARD_USER`) is resolved by the backend RBAC engine.
                  </p>
                </div>

                {onInstantActivateOwner && (
                  <button
                    type="button"
                    onClick={onInstantActivateOwner}
                    className="w-full py-2.5 px-4 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Instant Activate LORIN Live Workbench (System Owner)</span>
                  </button>
                )}

                <button
                  onClick={handleGoogleSignIn}
                  disabled={isSubmitting}
                  className="w-full py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Sign In with Google Account</span>
                </button>

                {/* Email/Password Auth Tabs */}
                <div className="pt-3 border-t border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-[11px] font-mono">
                    <button
                      type="button"
                      onClick={() => setAuthMode('signin')}
                      className={`px-2.5 py-1 rounded cursor-pointer ${
                        authMode === 'signin' ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30 font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Email Sign-In
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthMode('register')}
                      className={`px-2.5 py-1 rounded cursor-pointer ${
                        authMode === 'register' ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30 font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Register {registrationPolicy === 'INVITE_ONLY' ? '(Invite-Only)' : ''}
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthMode('reset')}
                      className={`px-2.5 py-1 rounded cursor-pointer ${
                        authMode === 'reset' ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30 font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Password Reset
                    </button>
                  </div>

                  <form onSubmit={handleEmailAuthSubmit} className="space-y-2.5">
                    {authMode === 'register' && (
                      <input
                        type="text"
                        value={authDisplayName}
                        onChange={(e) => setAuthDisplayName(e.target.value)}
                        placeholder="Display Name"
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-teal-500"
                      />
                    )}
                    <input
                      type="email"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      placeholder="Email address..."
                      required
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-teal-500"
                    />
                    {authMode !== 'reset' && (
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          value={authPassword}
                          onChange={(e) => setAuthPassword(e.target.value)}
                          placeholder="Password..."
                          required
                          className="w-full pl-3 pr-9 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-teal-500"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(prev => !prev)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                          aria-label={showPassword ? 'Hide password' : 'Show password'}
                        >
                          {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    )}
                    {authMode !== 'reset' && (
                      <label className="flex items-center gap-2 text-[11px] text-slate-400 cursor-pointer select-none pt-0.5">
                        <input
                          type="checkbox"
                          checked={rememberSession}
                          onChange={(e) => setRememberSession(e.target.checked)}
                          className="rounded border-slate-700 bg-slate-950 text-teal-500 focus:ring-0"
                        />
                        <span>Remember session on this trusted device</span>
                      </label>
                    )}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      {authMode === 'signin'
                        ? 'Sign In with Email'
                        : authMode === 'register'
                        ? 'Create Account'
                        : 'Send Password Reset Email'}
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* Multiple Owner Email Management Section (Strictly System Owner Only) */}
            {isSystemOwner && (
              <div className="space-y-4 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Key className="w-4 h-4 text-teal-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                      Authorized System Owner Registry
                    </h4>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">{ownerEmails.length} Configured</span>
                </div>

                <p className="text-xs text-slate-400">
                  Manage verified System Owner email addresses. Super Admin, Administrator, Specialist, and Standard User roles can be governed inside the Owner Control Plane.
                </p>

                {/* Add New Email Form */}
                <form onSubmit={handleAddEmail} className="flex gap-2">
                  <input
                    type="email"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    placeholder="Add owner email address..."
                    className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 font-mono"
                  />
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-3.5 py-2 bg-teal-500 hover:bg-teal-400 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add</span>
                  </button>
                </form>

                {/* Owner Emails List */}
                <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                  {ownerEmails.map((email) => {
                    const isPrimary = email.toLowerCase() === primaryOwner.toLowerCase();
                    return (
                      <div
                        key={email}
                        className="px-3 py-2 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="font-mono text-slate-200 truncate">{email}</span>
                          {isPrimary && (
                            <span className="px-2 py-0.5 text-[10px] font-mono bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded shrink-0">
                              PRIMARY OWNER
                            </span>
                          )}
                        </div>

                        {!isPrimary && (
                          <button
                            type="button"
                            onClick={() => handleRemoveEmail(email)}
                            className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
                            title="Remove owner email"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-6 py-4 bg-[#121c30] border-t border-slate-800 text-[11px] font-mono text-slate-400 flex justify-between items-center">
            <span>LORIN Identity & RBAC v2.0</span>
            <span className="text-slate-500">Shortcut: Ctrl+Shift+L / Cmd+Shift+L</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
