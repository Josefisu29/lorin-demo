import React, { useEffect, useRef, useState } from 'react';
import { 
  MessageSquare, 
  Mic, 
  Video, 
  ShieldCheck, 
  Terminal, 
  Clock,
  Settings, 
  ChevronLeft, 
  ChevronRight,
  Cpu,
  Database,
  BookOpen,
  Search,
  Archive,
  X,
  Layers,
  LayoutGrid,
  Lock,
  FolderKanban,
  Plug,
  Wifi,
  WifiOff,
  Sliders,
  ListTodo,
  Sun,
  Moon,
  Trash2,
  Edit3,
  Plus,
  Smartphone
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ConversationSession,
  LorinProfileConfig,
  Principal,
  WorkspaceView,
  normalizeCanonicalRole
} from '../types/lorin';
import { PolicyEngine } from '../services/policyEngine';
import { RoutingStrategy } from '../services/modelBackend';
import {
  LORIN_AUTONOMY_LEVELS,
  LORIN_OPERATING_MODES,
  LORIN_VOICE_PROFILES
} from '../services/lorinProfileService';
import { PWAInstallButton } from './PWAInstallButton';

interface SidebarNavigationProps {
  currentView: WorkspaceView;
  setCurrentView: (view: WorkspaceView) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
  isMobileDrawerOpen?: boolean;
  onCloseMobileDrawer?: () => void;
  principal: Principal;
  backendMode: RoutingStrategy;
  pendingApprovalsCount: number;
  isMicActive: boolean;
  isCameraActive: boolean;
  onOpenSearch?: () => void;
  onOpenArchivedModal?: () => void;
  archivedReportsCount?: number;
  profileConfig?: LorinProfileConfig;
  onOpenModeAndAccessModal?: (tab?: 'persona' | 'levels' | 'access_runtime') => void;
  onToggleOnlineOffline?: () => void;
  onToggleThemeMode?: () => void;
  conversations?: ConversationSession[];
  activeConversationId?: string;
  onSelectConversation?: (conversationId: string) => void;
  onNewConversation?: () => void;
  onRenameConversation?: (conversationId: string, newTitle: string) => void;
  onDeleteConversation?: (conversationId: string) => void;
}

interface NavItemConfig {
  id: WorkspaceView;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string | null;
  badgeColor?: string;
  ownerOnly?: boolean;
}

export const SidebarNavigation: React.FC<SidebarNavigationProps> = ({
  currentView,
  setCurrentView,
  isCollapsed,
  setIsCollapsed,
  isMobileDrawerOpen = false,
  onCloseMobileDrawer,
  principal,
  backendMode,
  pendingApprovalsCount,
  isMicActive,
  isCameraActive,
  onOpenSearch,
  onOpenArchivedModal,
  archivedReportsCount = 0,
  profileConfig,
  onOpenModeAndAccessModal,
  onToggleOnlineOffline,
  onToggleThemeMode,
  conversations = [],
  activeConversationId,
  onSelectConversation,
  onNewConversation,
  onRenameConversation,
  onDeleteConversation
}) => {
  const [renamingConvId, setRenamingConvId] = useState<string | null>(null);
  const [renameText, setRenameText] = useState('');
  const mobileDrawerRef = useRef<HTMLDivElement>(null);
  const closeDrawerRef = useRef(onCloseMobileDrawer);
  closeDrawerRef.current = onCloseMobileDrawer;

  useEffect(() => {
    if (!isMobileDrawerOpen) return;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const drawer = mobileDrawerRef.current;
    const focusable = () => drawer?.querySelectorAll<HTMLElement>('button:not(:disabled), a[href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])') || [];
    focusable()[0]?.focus();

    const handleDrawerKeys = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        closeDrawerRef.current?.();
        return;
      }
      if (event.key !== 'Tab') return;
      const items = Array.from(focusable());
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener('keydown', handleDrawerKeys);
    return () => {
      document.removeEventListener('keydown', handleDrawerKeys);
      previousFocus?.focus();
    };
  }, [isMobileDrawerOpen]);

  const navGroups: { title: string; items: NavItemConfig[] }[] = [
    {
      title: 'YOUR WORKSPACE',
      items: [
        {
          id: 'chat',
          label: 'Conversation',
          icon: MessageSquare,
          badge: null
        },
        {
          id: 'projects',
          label: 'Projects',
          icon: FolderKanban,
          badge: null
        },
        {
          id: 'tasks',
          label: 'Tasks & automation',
          icon: ListTodo,
          badge: null
        },
        {
          id: 'vault',
          label: 'Knowledge Vault',
          icon: BookOpen,
          badge: null
        },
        {
          id: 'laurenVault',
          label: 'Private Vault',
          icon: Lock,
          badge: null
        }
      ]
    },
    {
      title: 'INTELLIGENCE',
      items: [
        {
          id: 'specialists',
          label: 'Capabilities',
          icon: Layers,
          badge: null
        },
        {
          id: 'gideon',
          label: 'GIDEON continuity',
          icon: Clock,
          badge: null
        },
        {
          id: 'voice',
          label: 'Voice',
          icon: Mic,
          badge: isMicActive ? 'LIVE' : null,
          badgeColor: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
        },
        {
          id: 'video',
          label: 'Vision',
          icon: Video,
          badge: isCameraActive ? 'CAM' : null,
          badgeColor: 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
        },
        {
          id: 'terminal',
          label: 'Engineering workbench',
          icon: Terminal,
          badge: null
        }
      ]
    },
    {
      title: 'SYSTEM & PRIVACY',
      items: [
        {
          id: 'deviceCenter',
          label: 'Devices & companion',
          icon: Smartphone,
          badge: 'Node',
          badgeColor: 'bg-teal-500/15 text-[#66E3CB] border border-teal-500/30'
        },
        {
          id: 'connections',
          label: 'Connections',
          icon: Plug,
          badge: null
        },
        {
          id: 'memory',
          label: 'Memory',
          icon: Database,
          badge: null
        },
        {
          id: 'security',
          label: 'Security & approvals',
          icon: ShieldCheck,
          badge: pendingApprovalsCount > 0 ? `${pendingApprovalsCount}` : null,
          badgeColor: 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
        },
        {
          id: 'ownerGateway',
          label: 'Owner control',
          icon: LayoutGrid,
          badge: 'Owner',
          badgeColor: 'bg-teal-500/15 text-[#66E3CB] border border-teal-500/30',
          ownerOnly: true
        },
        {
          id: 'settings',
          label: 'Settings',
          icon: Settings,
          badge: null
        }
      ]
    }
  ];

  const handleNavClick = (view: WorkspaceView) => {
    setCurrentView(view);
    if (onCloseMobileDrawer) {
      onCloseMobileDrawer();
    }
  };

  const isOnlineRuntime = profileConfig ? profileConfig.runtimeActivation === 'ONLINE_ACTIVE' : backendMode !== 'DETERMINISTIC_MOCK';
  const isLightTheme = profileConfig?.themeMode === 'light';

  const navContent = (collapsed: boolean, isMobile = false) => (
    <div className="lorin-sidebar-content flex flex-col h-full justify-between overflow-hidden">
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Brand & Workspace Header */}
        <div className="lorin-sidebar-brand flex items-center justify-between p-3.5 border-b border-[#283544] shrink-0">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-lg bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center shrink-0">
              <Cpu className="w-4 h-4 text-[#66E3CB]" />
            </div>
            {(!collapsed || isMobile) && (
              <div className="overflow-hidden">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold tracking-tight text-white text-sm">LORIN</span>
                </div>
                <div className="text-[11px] text-[#8796A8] truncate">Personal intelligence</div>
              </div>
            )}
          </div>

          {!isMobile ? (
            <button
              onClick={() => setIsCollapsed(!isCollapsed)}
              aria-expanded={!isCollapsed}
              className="p-1 rounded hover:bg-[#17212C] text-[#A2AFBF] hover:text-white transition-colors cursor-pointer"
              title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          ) : (
            <button
              onClick={onCloseMobileDrawer}
              className="p-1.5 rounded-lg bg-[#17212C] border border-[#283544] text-[#A2AFBF] hover:text-white cursor-pointer"
              aria-label="Close drawer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* New Chat + Quick Search + Modes/Runtime/Theme Trigger */}
        <div className="p-2.5 pb-1 space-y-1.5 shrink-0">
          <div className="flex items-center gap-1.5">
            {onNewConversation && (
              <button
                type="button"
                onClick={() => {
                  onNewConversation();
                  handleNavClick('chat');
                }}
                className={`lorin-new-chat flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs transition-all cursor-pointer ${
                  collapsed && !isMobile ? 'px-2' : ''
                }`}
                title="Start a new conversation"
              >
                <Plus className="w-3.5 h-3.5 shrink-0" />
                {(!collapsed || isMobile) && <span>New Chat</span>}
              </button>
            )}

            {onOpenSearch && (
              <button
                onClick={() => {
                  onOpenSearch();
                  if (isMobile && onCloseMobileDrawer) onCloseMobileDrawer();
                }}
                className="px-2.5 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#1C2836] border border-[#283544] hover:border-[#66E3CB]/40 text-xs text-[#A2AFBF] hover:text-white flex items-center gap-1.5 transition-all cursor-pointer"
                title="Global Search across workspace (⌘K)"
              >
                <Search className="w-3.5 h-3.5 text-[#66E3CB] shrink-0" />
                {(!collapsed || isMobile) && (
                  <kbd className="text-[10px] font-mono text-[#738297]">⌘K</kbd>
                )}
              </button>
            )}
          </div>

          {/* Quick LORIN Modes, Voices, Levels, Online/Offline & Theme Switcher Bar */}
          {(!collapsed || isMobile) ? (
            <div className="flex items-center gap-1">
              {onOpenModeAndAccessModal && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenModeAndAccessModal('persona');
                    if (isMobile && onCloseMobileDrawer) onCloseMobileDrawer();
                  }}
                  className="flex-1 px-2 py-1.5 rounded-lg bg-[#0B0F14] hover:bg-[#17212C] border border-[#283544] hover:border-[#66E3CB]/40 text-[11px] font-mono text-left flex items-center justify-between transition-colors cursor-pointer overflow-hidden"
                  title="Configure LORIN Operating Modes, Personalities, Voices & Autonomy Levels"
                >
                  <span className="flex items-center gap-1.5 truncate text-white">
                    <Sliders className="w-3 h-3 text-[#66E3CB] shrink-0" />
                    <span className="truncate">
                      {profileConfig ? LORIN_OPERATING_MODES[profileConfig.operatingMode].shortLabel : 'Architect'}
                    </span>
                  </span>
                  <span className="text-[9px] px-1 rounded bg-[#17212C] text-[#A9B8FF] border border-[#283544] shrink-0 tabular-nums">
                    {profileConfig ? LORIN_AUTONOMY_LEVELS[profileConfig.autonomyLevel].shortLabel.split(':')[0] : 'L3'}
                  </span>
                </button>
              )}

              {onToggleOnlineOffline && (
                <button
                  type="button"
                  onClick={onToggleOnlineOffline}
                  className={`px-2 py-1.5 rounded-lg border text-[10px] font-mono font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer ${
                    isOnlineRuntime
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/20'
                      : 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                  }`}
                  title={
                    isOnlineRuntime
                      ? 'Cloud processing is permitted by your privacy setting. This does not indicate provider connectivity.'
                      : 'Cloud processing is blocked by local-only privacy mode.'
                  }
                >
                  {isOnlineRuntime ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                  <span>{isOnlineRuntime ? 'CLOUD' : 'LOCAL'}</span>
                </button>
              )}

              {onToggleThemeMode && (
                <button
                  type="button"
                  onClick={onToggleThemeMode}
                  className="p-1.5 rounded-lg bg-[#0B0F14] hover:bg-[#17212C] border border-[#283544] text-[#A2AFBF] hover:text-white shrink-0 transition-colors cursor-pointer"
                  title={isLightTheme ? 'Switch to LORIN Dark Theme' : 'Switch to LORIN Light Theme'}
                  aria-label="Toggle Dark or Light Theme"
                >
                  {isLightTheme ? <Moon className="w-3.5 h-3.5 text-[#66E3CB]" /> : <Sun className="w-3.5 h-3.5 text-amber-300" />}
                </button>
              )}
            </div>
          ) : (
            onOpenModeAndAccessModal && (
              <button
                type="button"
                onClick={() => onOpenModeAndAccessModal('persona')}
                className="w-full flex items-center justify-center py-1.5 rounded-lg bg-[#0B0F14] hover:bg-[#17212C] border border-[#283544] text-[#66E3CB] cursor-pointer"
                title="LORIN Modes, Personalities, Voices & Runtime"
              >
                <Sliders className="w-3.5 h-3.5" />
              </button>
            )
          )}
        </div>

        {/* Categorized Navigation Links + Conversation History */}
        <nav aria-label="Primary workspace" className="lorin-sidebar-nav flex-1 overflow-y-auto px-2.5 py-3 space-y-4">
          {/* Conversation History Threads (Part C Section 4 & Part R Section 19.4) */}
          {(!collapsed || isMobile) && conversations.length > 0 && (
            <div className="space-y-1">
              <div className="px-3 flex items-center justify-between text-[10px] font-mono uppercase tracking-wider text-[#738297]">
                <span>CONVERSATION HISTORY</span>
                <span>{conversations.length}</span>
              </div>
              <div className="space-y-0.5 max-h-32 overflow-y-auto pr-0.5">
                {conversations.slice(0, 8).map((conv) => {
                  const isSelected = conv.id === activeConversationId && currentView === 'chat';
                  return (
                    <div
                      key={conv.id}
                      className={`group flex items-center justify-between gap-1 px-2.5 py-1 rounded-lg text-xs transition-all ${
                        isSelected
                          ? 'lorin-nav-item--active bg-[#17212C] text-[#66E3CB] border border-[#3A4B5F]'
                          : 'text-[#A2AFBF] hover:bg-[#151E28] hover:text-white border border-transparent'
                      }`}
                    >
                      {renamingConvId === conv.id ? (
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            if (onRenameConversation && renameText.trim()) {
                              onRenameConversation(conv.id, renameText.trim());
                            }
                            setRenamingConvId(null);
                          }}
                          className="flex-1 flex items-center gap-1"
                        >
                          <input
                            type="text"
                            autoFocus
                            value={renameText}
                            onChange={(e) => setRenameText(e.target.value)}
                            onBlur={() => setRenamingConvId(null)}
                            className="w-full bg-[#0B0F14] border border-[#66E3CB] rounded px-1.5 py-0.5 text-[11px] text-white focus:outline-none"
                          />
                        </form>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              if (onSelectConversation) onSelectConversation(conv.id);
                              handleNavClick('chat');
                            }}
                            className="flex-1 text-left truncate text-[11px] cursor-pointer"
                            title={`${conv.title} (${conv.messages.length} messages)`}
                          >
                            {conv.title}
                          </button>
                          <div className="opacity-0 group-hover:opacity-100 flex items-center gap-0.5 shrink-0 transition-opacity">
                            {onRenameConversation && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setRenamingConvId(conv.id);
                                  setRenameText(conv.title);
                                }}
                                className="p-0.5 text-[#738297] hover:text-white cursor-pointer"
                                title="Rename conversation"
                              >
                                <Edit3 className="w-3 h-3" />
                              </button>
                            )}
                            {onDeleteConversation && conversations.length > 1 && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onDeleteConversation(conv.id);
                                }}
                                className="p-0.5 text-[#738297] hover:text-rose-400 cursor-pointer"
                                title="Delete conversation"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {onOpenArchivedModal && archivedReportsCount > 0 && (
            <button
              onClick={() => {
                onOpenArchivedModal();
                if (isMobile && onCloseMobileDrawer) onCloseMobileDrawer();
              }}
              className="w-full flex items-center gap-3 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors text-[#A2AFBF] hover:bg-[#151E28] hover:text-white border border-transparent cursor-pointer"
              title={collapsed && !isMobile ? `Archived Reports (${archivedReportsCount})` : undefined}
            >
              <Archive className="w-4 h-4 shrink-0 text-amber-400/80" />
              {(!collapsed || isMobile) && (
                <div className="flex-1 flex items-center justify-between">
                  <span>Archived Reports</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 tabular-nums">
                    {archivedReportsCount}
                  </span>
                </div>
              )}
            </button>
          )}

          {navGroups.map((group) => {
            const visibleItems = group.items.filter(
              item => PolicyEngine.canAccessModule(principal, item.id)
            );
            if (visibleItems.length === 0) return null;

            return (
              <div key={group.title} className="space-y-0.5">
                {(!collapsed || isMobile) && (
                  <div className="px-3 pb-1 text-[10px] font-mono uppercase tracking-wider text-[#738297]">
                    {group.title}
                  </div>
                )}
                {visibleItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentView === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNavClick(item.id)}
                      aria-current={isActive ? 'page' : undefined}
                      className={`lorin-nav-item w-full min-h-10 flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                        isActive
                          ? 'lorin-nav-item--active bg-[#17212C] text-[#66E3CB] border border-[#3A4B5F]'
                          : 'text-[#A2AFBF] hover:bg-[#151E28] hover:text-white border border-transparent'
                      }`}
                      title={collapsed && !isMobile ? item.label : undefined}
                    >
                      <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? 'text-[#66E3CB]' : 'text-[#738297]'}`} />
                      {(!collapsed || isMobile) && (
                        <div className="flex-1 flex items-center justify-between overflow-hidden">
                          <span className="truncate">{item.label}</span>
                          {item.badge && (
                            <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded tabular-nums ${item.badgeColor || 'bg-[#151E28] text-[#738297] border border-[#283544]'}`}>
                              {item.badge}
                            </span>
                          )}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            );
          })}
        </nav>
      </div>

      <div className="shrink-0">
        {/* PWA Standalone / Offline Ready Action */}
        <div className="px-2.5 py-2 border-t border-[#283544]">
          <PWAInstallButton variant={collapsed && !isMobile ? 'compact' : 'full'} className="w-full justify-center" />
        </div>

        {/* Footer User Profile & Settings */}
        <div className="p-3 border-t border-[#283544] bg-[#0B0F14]/90">
          {!collapsed || isMobile ? (
            <div className="flex items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="w-7 h-7 rounded-full bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center font-bold text-white text-xs shrink-0 font-mono">
                  {principal.name ? principal.name.charAt(0).toUpperCase() : 'U'}
                </div>
                <div className="overflow-hidden">
                  <div className="font-semibold text-white truncate text-xs">{principal.name || 'User'}</div>
                  <div className="text-[10px] text-[#A2AFBF] font-mono truncate">{normalizeCanonicalRole(principal.canonicalRole || principal.role)}</div>
                </div>
              </div>

              <button
                onClick={() => handleNavClick('settings')}
                className="p-1.5 rounded-lg hover:bg-[#17212C] text-[#A2AFBF] hover:text-white transition-colors cursor-pointer shrink-0"
                title="Settings"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex justify-center">
              <button
                onClick={() => handleNavClick('settings')}
                className="p-1.5 rounded-lg hover:bg-[#17212C] text-[#A2AFBF] hover:text-white transition-colors cursor-pointer"
                title={`Settings (${principal.name || 'User'})`}
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* 1. Desktop Persistent Sidebar */}
      <aside
        className={`lorin-sidebar hidden md:flex relative z-30 shrink-0 border-r border-[#283544] bg-[#0D141C] flex-col justify-between transition-[width] duration-200 select-none ${
          isCollapsed ? 'w-[68px]' : 'w-[264px]'
        }`}
      >
        {navContent(isCollapsed, false)}
      </aside>

      {/* 2. Mobile Responsive Slide-Over Drawer with AnimatePresence */}
      <AnimatePresence>
        {isMobileDrawerOpen && (
          <div className="fixed inset-0 z-50 md:hidden">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={onCloseMobileDrawer}
              className="absolute inset-0 bg-black/70 backdrop-blur-xs"
            />

            <motion.div
              ref={mobileDrawerRef}
              role="dialog"
              aria-modal="true"
              aria-label="LORIN navigation"
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              drag="x"
              dragConstraints={{ left: -300, right: 0 }}
              dragElastic={{ left: 0.15, right: 0 }}
              onDragEnd={(_e, info) => {
                if (info.offset.x < -60 || info.velocity.x < -250) {
                  if (onCloseMobileDrawer) onCloseMobileDrawer();
                }
              }}
              className="lorin-sidebar lorin-sidebar--mobile relative w-80 max-w-[88vw] h-full bg-[#0D141C] border-r border-[#283544] shadow-2xl flex flex-col justify-between select-none touch-pan-y"
            >
              <div className="absolute right-1 top-1/2 -translate-y-1/2 w-1 h-12 rounded-full bg-[#283544] opacity-50 pointer-events-none" aria-hidden="true" />
              {navContent(false, true)}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
