import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  ShieldCheck,
  Volume2,
  Cpu,
  Wifi,
  WifiOff,
  Lock,
  Sliders,
  CheckCircle2,
  RefreshCw,
  Terminal,
  Key,
  Layers,
  EyeOff,
  Radio,
  Gauge
} from 'lucide-react';
import {
  AutonomyLevel,
  LorinOperatingMode,
  LorinPersonality,
  LorinProfileConfig,
  LorinRuntimeActivation,
  LorinVoiceProfile,
  Principal
} from '../types/lorin';
import {
  LORIN_AUTONOMY_LEVELS,
  LORIN_OPERATING_MODES,
  LORIN_PERSONALITIES,
  LORIN_SECURE_ACCESS_VECTORS,
  LORIN_VOICE_PROFILES
} from '../services/lorinProfileService';
import { AudioService } from '../services/audioService';
import {
  CloudPrivacyGate,
  DeterministicMockBackend,
  LiveGeminiBackend,
  OllamaLocalBackend,
  ProviderHealthStatus,
  RoutingStrategy
} from '../services/modelBackend';
import { StealthService } from '../services/stealthService';

interface LorinModeAndAccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  principal: Principal;
  profileConfig: LorinProfileConfig;
  onUpdateProfileConfig: (partial: Partial<LorinProfileConfig>) => void;
  backendMode: RoutingStrategy;
  onSelectBackendMode: (mode: RoutingStrategy) => void;
  initialTab?: 'persona' | 'levels' | 'access_runtime';
}

export const LorinModeAndAccessModal: React.FC<LorinModeAndAccessModalProps> = ({
  isOpen,
  onClose,
  principal,
  profileConfig,
  onUpdateProfileConfig,
  backendMode,
  onSelectBackendMode,
  initialTab = 'persona'
}) => {
  const [activeTab, setActiveTab] = useState<'persona' | 'levels' | 'access_runtime'>(initialTab);
  const [speakingVoiceId, setSpeakingVoiceId] = useState<LorinVoiceProfile | null>(null);
  const [healthStatus, setHealthStatus] = useState<ProviderHealthStatus | null>(null);
  const [isProbing, setIsProbing] = useState(false);
  const [browserOnline, setBrowserOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [stealthActive, setStealthActive] = useState<boolean>(StealthService.isStealthEnabled());
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      runRuntimeProbe(profileConfig.runtimeActivation, backendMode);
    }
  }, [isOpen, initialTab]);

  useEffect(() => {
    const onOnline = () => setBrowserOnline(true);
    const onOffline = () => setBrowserOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  const runRuntimeProbe = async (activation: LorinRuntimeActivation, mode: RoutingStrategy) => {
    setIsProbing(true);
    try {
      if (activation === 'OFFLINE_AIRGAPPED') {
        const ollama = new OllamaLocalBackend();
        const ollamaRes = await ollama.healthCheck();
        if (ollamaRes.healthy) {
          setHealthStatus(ollamaRes);
        } else {
          const det = new DeterministicMockBackend();
          setHealthStatus(await det.healthCheck());
        }
      } else {
        const backend =
          mode === 'OLLAMA_LOCAL'
            ? new OllamaLocalBackend()
            : mode === 'DETERMINISTIC_MOCK'
            ? new DeterministicMockBackend()
            : new LiveGeminiBackend();
        setHealthStatus(await backend.healthCheck());
      }
    } finally {
      setIsProbing(false);
    }
  };

  const handleActivateOnline = async () => {
    CloudPrivacyGate.setCloudContextPermitted(true);
    onUpdateProfileConfig({ runtimeActivation: 'ONLINE_ACTIVE' });
    const nextBackend: RoutingStrategy =
      backendMode === 'DETERMINISTIC_MOCK' || backendMode === 'OLLAMA_LOCAL'
        ? 'LIVE_GEMINI'
        : backendMode;
    onSelectBackendMode(nextBackend);
    setStatusNotice('LORIN Online Runtime Activated: Cloud Gateway SSE + Firestore Sync + Local Vault Hybrid enabled.');
    await runRuntimeProbe('ONLINE_ACTIVE', nextBackend);
    setTimeout(() => setStatusNotice(null), 4000);
  };

  const handleActivateOffline = async () => {
    CloudPrivacyGate.setCloudContextPermitted(false);
    onUpdateProfileConfig({ runtimeActivation: 'OFFLINE_AIRGAPPED' });

    setIsProbing(true);
    const ollamaHealth = await new OllamaLocalBackend().healthCheck();
    const nextBackend: RoutingStrategy = ollamaHealth.healthy ? 'OLLAMA_LOCAL' : 'DETERMINISTIC_MOCK';
    onSelectBackendMode(nextBackend);
    const finalHealth = ollamaHealth.healthy
      ? ollamaHealth
      : await new DeterministicMockBackend().healthCheck();
    setHealthStatus(finalHealth);
    setIsProbing(false);

    setStatusNotice(
      ollamaHealth.healthy
        ? 'LORIN Offline Air-Gapped Runtime Activated: Connected to local Ollama daemon (localhost:11434). Cloud transmission blocked.'
        : 'LORIN Offline Air-Gapped Runtime Activated: Local Deterministic Engine & Encrypted Vault ready. Zero cloud calls.'
    );
    setTimeout(() => setStatusNotice(null), 4500);
  };

  const handlePreviewVoice = (voiceId: LorinVoiceProfile) => {
    const def = LORIN_VOICE_PROFILES[voiceId];
    onUpdateProfileConfig({ voiceProfile: voiceId });
    setSpeakingVoiceId(voiceId);
    AudioService.speak(
      def.samplePhrase,
      () => setSpeakingVoiceId(null),
      {
        pitch: def.pitch,
        rate: def.rate,
        preferredVoiceKeywords: def.preferredVoiceKeywords
      }
    );
  };

  const handleToggleStealth = () => {
    const next = !stealthActive;
    setStealthActive(next);
    StealthService.setStealthMode(next);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-3 sm:p-6"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-4xl bg-[#111821] border border-[#283544] rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-xs"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="px-6 py-4 bg-[#0B0F14] border-b border-[#283544] flex flex-wrap items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center text-[#66E3CB]">
                  <Sliders className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-sm font-bold text-white tracking-tight">
                      LORIN Intelligence Modes, Personalities, Voices & Secure Runtime
                    </h2>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                        profileConfig.runtimeActivation === 'ONLINE_ACTIVE'
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                          : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                      }`}
                    >
                      {profileConfig.runtimeActivation === 'ONLINE_ACTIVE'
                        ? 'ACTIVE ONLINE'
                        : 'ACTIVE OFFLINE (AIR-GAPPED)'}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#A2AFBF] mt-0.5">
                    Configure operating modes, conversational personality, speech synthesis voice, autonomy level, and Online/Offline execution boundaries.
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="px-2.5 py-1 rounded-lg bg-[#17212C] border border-[#283544] text-[#A2AFBF] hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Navigation Tabs */}
            <div className="px-6 pt-3 bg-[#111821] border-b border-[#283544] flex items-center gap-2 overflow-x-auto shrink-0">
              <button
                onClick={() => setActiveTab('persona')}
                className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                  activeTab === 'persona'
                    ? 'border-[#66E3CB] text-[#66E3CB]'
                    : 'border-transparent text-[#A2AFBF] hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Modes, Personalities & Voices</span>
              </button>

              <button
                onClick={() => setActiveTab('levels')}
                className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                  activeTab === 'levels'
                    ? 'border-[#66E3CB] text-[#66E3CB]'
                    : 'border-transparent text-[#A2AFBF] hover:text-white'
                }`}
              >
                <Gauge className="w-3.5 h-3.5" />
                <span>Autonomy & Capability Levels (L0–L4)</span>
              </button>

              <button
                onClick={() => setActiveTab('access_runtime')}
                className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                  activeTab === 'access_runtime'
                    ? 'border-[#66E3CB] text-[#66E3CB]'
                    : 'border-transparent text-[#A2AFBF] hover:text-white'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Secure Access & Online / Offline Activation</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {statusNotice && (
                <div className="p-3 rounded-xl bg-[#15232A] border border-[#66E3CB]/40 text-[#66E3CB] text-xs font-mono flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{statusNotice}</span>
                </div>
              )}

              {/* TAB 1: MODES, PERSONALITIES & VOICES */}
              {activeTab === 'persona' && (
                <div className="space-y-6">
                  {/* 1. Operating Modes */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                          1. LORIN Operating Modes
                        </h3>
                        <p className="text-[11px] text-[#A2AFBF]">
                          Determines which specialist discipline leads reasoning and how LORIN structures engineering output.
                        </p>
                      </div>
                      <span className="text-[11px] font-mono text-[#66E3CB]">
                        Active: {LORIN_OPERATING_MODES[profileConfig.operatingMode].shortLabel}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {(Object.keys(LORIN_OPERATING_MODES) as LorinOperatingMode[]).map((modeKey) => {
                        const mode = LORIN_OPERATING_MODES[modeKey];
                        const isSelected = profileConfig.operatingMode === modeKey;
                        return (
                          <button
                            key={modeKey}
                            onClick={() => onUpdateProfileConfig({ operatingMode: modeKey })}
                            className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between gap-2.5 cursor-pointer ${
                              isSelected
                                ? 'bg-[#17212C] border-[#66E3CB] ring-1 ring-[#66E3CB]/30'
                                : 'bg-[#0B0F14] border-[#283544] hover:border-[#3A4B5F]'
                            }`}
                          >
                            <div className="space-y-1.5">
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-bold text-white text-xs">{mode.shortLabel}</span>
                                <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono border ${mode.badgeColor}`}>
                                  {mode.leadSpecialist.split('_')[0]} Lead
                                </span>
                              </div>
                              <div className="text-[11px] font-semibold text-slate-200">{mode.label}</div>
                              <p className="text-[11px] text-[#A2AFBF] leading-relaxed">{mode.description}</p>
                            </div>
                            <div className="pt-2 border-t border-[#283544]/60 flex items-center justify-between text-[10px] font-mono">
                              <span className={isSelected ? 'text-[#66E3CB] font-bold' : 'text-[#738297]'}>
                                {isSelected ? 'ACTIVE MODE' : 'Click to activate'}
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 2. Personalities */}
                  <div className="space-y-3 pt-2 border-t border-[#283544]">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                          2. Conversational Personalities
                        </h3>
                        <p className="text-[11px] text-[#A2AFBF]">
                          Tunes LORIN's communication style, directness, and Socratic questioning depth without sacrificing technical rigor.
                        </p>
                      </div>
                      <span className="text-[11px] font-mono text-[#A9B8FF]">
                        Active: {LORIN_PERSONALITIES[profileConfig.personality].shortLabel}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
                      {(Object.keys(LORIN_PERSONALITIES) as LorinPersonality[]).map((pKey) => {
                        const p = LORIN_PERSONALITIES[pKey];
                        const isSelected = profileConfig.personality === pKey;
                        return (
                          <button
                            key={pKey}
                            onClick={() => onUpdateProfileConfig({ personality: pKey })}
                            className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                              isSelected
                                ? 'bg-[#17212C] border-[#A9B8FF] text-white'
                                : 'bg-[#0B0F14] border-[#283544] text-[#A2AFBF] hover:text-white'
                            }`}
                          >
                            <div className="space-y-1">
                              <div className="font-bold text-xs text-white flex items-center justify-between">
                                <span>{p.shortLabel}</span>
                                {isSelected && <span className="w-2 h-2 rounded-full bg-[#A9B8FF]" />}
                              </div>
                              <p className="text-[10px] text-[#A2AFBF] leading-relaxed">{p.toneSummary}</p>
                            </div>
                            <span className="text-[9px] font-mono text-[#738297] uppercase">
                              {isSelected ? 'Selected' : 'Select'}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 3. Voice Synthesis Profiles */}
                  <div className="space-y-3 pt-2 border-t border-[#283544]">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                          3. LORIN Voice Synthesis Profiles (Web Speech DSP)
                        </h3>
                        <p className="text-[11px] text-[#A2AFBF]">
                          Selects voice cadence, pitch, and speaking rate for the Voice Conversation Stage. Click "Test Voice" to preview immediately.
                        </p>
                      </div>
                      <span className="text-[11px] font-mono text-[#66E3CB]">
                        Active: {LORIN_VOICE_PROFILES[profileConfig.voiceProfile].shortLabel}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {(Object.keys(LORIN_VOICE_PROFILES) as LorinVoiceProfile[]).map((vKey) => {
                        const v = LORIN_VOICE_PROFILES[vKey];
                        const isSelected = profileConfig.voiceProfile === vKey;
                        const isPreviewing = speakingVoiceId === vKey;
                        return (
                          <div
                            key={vKey}
                            onClick={() => onUpdateProfileConfig({ voiceProfile: vKey })}
                            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                              isSelected
                                ? 'bg-[#17212C] border-[#66E3CB]'
                                : 'bg-[#0B0F14] border-[#283544] hover:border-[#3A4B5F]'
                            }`}
                          >
                            <div className="space-y-1 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-white text-xs">{v.label}</span>
                                <span className="px-1.5 py-0.5 rounded bg-[#111821] border border-[#283544] text-[10px] font-mono text-[#66E3CB] tabular-nums">
                                  Pitch {v.pitch.toFixed(2)} · Rate {v.rate.toFixed(2)}x
                                </span>
                              </div>
                              <p className="text-[11px] text-[#A2AFBF] leading-relaxed">{v.description}</p>
                            </div>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handlePreviewVoice(vKey);
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-[#111821] hover:bg-[#283544] border border-[#3A4B5F] text-[11px] font-mono text-[#66E3CB] flex items-center gap-1.5 shrink-0 cursor-pointer"
                            >
                              <Volume2 className={`w-3.5 h-3.5 ${isPreviewing ? 'animate-bounce' : ''}`} />
                              <span>{isPreviewing ? 'Speaking...' : 'Test Voice'}</span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: AUTONOMY & CAPABILITY LEVELS */}
              {activeTab === 'levels' && (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-[#0B0F14] border border-[#283544] flex flex-wrap items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="text-xs font-bold text-white flex items-center gap-2">
                        <Gauge className="w-4 h-4 text-[#66E3CB]" />
                        <span>Human-Directed Autonomy & Execution Governance</span>
                      </div>
                      <p className="text-[11px] text-[#A2AFBF]">
                        LORIN never self-escalates privileges. High-impact operations remain bound by Lena Guardian's cryptographic SHA-256 approval gate.
                      </p>
                    </div>
                    <span className="px-2.5 py-1 rounded bg-[#17212C] border border-[#66E3CB]/40 text-[#66E3CB] font-mono text-xs font-bold tabular-nums">
                      {LORIN_AUTONOMY_LEVELS[profileConfig.autonomyLevel].shortLabel}
                    </span>
                  </div>

                  <div className="space-y-3">
                    {(Object.keys(LORIN_AUTONOMY_LEVELS) as AutonomyLevel[]).map((lvlKey) => {
                      const lvl = LORIN_AUTONOMY_LEVELS[lvlKey];
                      const isSelected = profileConfig.autonomyLevel === lvlKey;
                      return (
                        <div
                          key={lvlKey}
                          onClick={() => onUpdateProfileConfig({ autonomyLevel: lvlKey })}
                          className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                            isSelected
                              ? 'bg-[#17212C] border-[#66E3CB]'
                              : 'bg-[#0B0F14] border-[#283544] hover:border-[#3A4B5F]'
                          }`}
                        >
                          <div className="space-y-1.5 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="px-2 py-0.5 rounded bg-[#111821] border border-[#283544] text-[#66E3CB] font-mono text-[11px] font-bold tabular-nums">
                                LEVEL {lvl.levelNumber}
                              </span>
                              <span className="font-bold text-white text-xs">{lvl.label}</span>
                              <span className="px-2 py-0.5 rounded bg-[#111821] border border-[#283544] text-[10px] font-mono text-[#A9B8FF]">
                                Gate: {lvl.approvalRequirement}
                              </span>
                            </div>
                            <p className="text-[11px] text-[#A2AFBF] leading-relaxed">{lvl.description}</p>
                            <div className="flex flex-wrap items-center gap-1.5 pt-1">
                              {lvl.allowedOperations.map((op, idx) => (
                                <span
                                  key={idx}
                                  className="px-2 py-0.5 rounded bg-[#111821] border border-[#283544] text-[10px] font-mono text-slate-300"
                                >
                                  ✓ {op}
                                </span>
                              ))}
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onUpdateProfileConfig({ autonomyLevel: lvlKey });
                            }}
                            className={`px-3 py-1.5 rounded-lg font-mono text-[11px] font-bold border shrink-0 cursor-pointer ${
                              isSelected
                                ? 'bg-[#66E3CB] text-slate-950 border-[#66E3CB]'
                                : 'bg-[#111821] text-[#A2AFBF] border-[#283544] hover:text-white'
                            }`}
                          >
                            {isSelected ? 'ACTIVE LEVEL' : `Set Level ${lvl.levelNumber}`}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 3: SECURE ACCESS & ONLINE / OFFLINE ACTIVATION */}
              {activeTab === 'access_runtime' && (
                <div className="space-y-6">
                  {/* Part A: Activate LORIN Online vs Offline */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                          Activate LORIN Online or Offline Runtime
                        </h3>
                        <p className="text-[11px] text-[#A2AFBF]">
                          Switch LORIN between Online Cloud-Hybrid intelligence and strict Air-Gapped Offline local execution in one click.
                        </p>
                      </div>
                      <span className="text-[11px] font-mono text-[#A2AFBF] tabular-nums">
                        Browser Network: <strong className={browserOnline ? 'text-emerald-400' : 'text-amber-400'}>{browserOnline ? 'ONLINE' : 'OFFLINE'}</strong>
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Online Activation Card */}
                      <div
                        className={`p-4 rounded-xl border space-y-3 flex flex-col justify-between ${
                          profileConfig.runtimeActivation === 'ONLINE_ACTIVE'
                            ? 'bg-[#17212C] border-emerald-500/60'
                            : 'bg-[#0B0F14] border-[#283544]'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white text-xs flex items-center gap-2">
                              <Wifi className="w-4 h-4 text-emerald-400" />
                              <span>LORIN Active Online (Cloud + Local Hybrid)</span>
                            </span>
                            {profileConfig.runtimeActivation === 'ONLINE_ACTIVE' && (
                              <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-bold">
                                ACTIVE
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-[#A2AFBF] leading-relaxed">
                            Routes complex engineering reasoning through the authenticated server-side Cloud Gateway (`/api/gemini/stream`), syncs conversations and approvals with Firestore, and blends sanitized local Vault citations.
                          </p>
                          <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[10px]">
                            <div className="p-2 rounded bg-[#111821] border border-[#283544]">
                              <div className="text-[#738297]">Primary Engine:</div>
                              <div className="text-emerald-400 font-semibold">Cloud Gateway Proxy</div>
                            </div>
                            <div className="p-2 rounded bg-[#111821] border border-[#283544]">
                              <div className="text-[#738297]">Cloud Privacy Gate:</div>
                              <div className="text-white font-semibold">Sanitized Citations Allowed</div>
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleActivateOnline}
                          className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                            profileConfig.runtimeActivation === 'ONLINE_ACTIVE'
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-[#17212C] hover:bg-[#283544] text-white border border-[#3A4B5F]'
                          }`}
                        >
                          <Wifi className="w-3.5 h-3.5" />
                          <span>
                            {profileConfig.runtimeActivation === 'ONLINE_ACTIVE'
                              ? 'Online Runtime Active (Re-Verify)'
                              : 'Activate LORIN Online'}
                          </span>
                        </button>
                      </div>

                      {/* Offline Activation Card */}
                      <div
                        className={`p-4 rounded-xl border space-y-3 flex flex-col justify-between ${
                          profileConfig.runtimeActivation === 'OFFLINE_AIRGAPPED'
                            ? 'bg-[#17212C] border-amber-400/60'
                            : 'bg-[#0B0F14] border-[#283544]'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white text-xs flex items-center gap-2">
                              <WifiOff className="w-4 h-4 text-amber-400" />
                              <span>LORIN Active Offline (Air-Gapped Local Vault)</span>
                            </span>
                            {profileConfig.runtimeActivation === 'OFFLINE_AIRGAPPED' && (
                              <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold">
                                ACTIVE
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-[#A2AFBF] leading-relaxed">
                            Enforces strict zero-cloud data transmission (`CloudPrivacyGate = LOCAL_ONLY`). Routes prompts to your local Ollama daemon (`localhost:11434`) or the local Deterministic Verification Engine with full offline Vault RAG.
                          </p>
                          <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[10px]">
                            <div className="p-2 rounded bg-[#111821] border border-[#283544]">
                              <div className="text-[#738297]">Local Engine:</div>
                              <div className="text-amber-300 font-semibold">Ollama 11434 / Local Engine</div>
                            </div>
                            <div className="p-2 rounded bg-[#111821] border border-[#283544]">
                              <div className="text-[#738297]">Cloud Privacy Gate:</div>
                              <div className="text-amber-300 font-semibold">Strictly Air-Gapped</div>
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleActivateOffline}
                          className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                            profileConfig.runtimeActivation === 'OFFLINE_AIRGAPPED'
                              ? 'bg-amber-400 text-slate-950'
                              : 'bg-[#17212C] hover:bg-[#283544] text-white border border-[#3A4B5F]'
                          }`}
                        >
                          <WifiOff className="w-3.5 h-3.5" />
                          <span>
                            {profileConfig.runtimeActivation === 'OFFLINE_AIRGAPPED'
                              ? 'Offline Runtime Active (Re-Verify)'
                              : 'Activate LORIN Offline'}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Live Probe Readout */}
                    {healthStatus && (
                      <div className="p-3 rounded-xl bg-[#0B0F14] border border-[#283544] flex flex-wrap items-center justify-between gap-2 font-mono text-[11px]">
                        <div className="flex items-center gap-2">
                          <Radio className={`w-3.5 h-3.5 ${isProbing ? 'animate-spin text-[#66E3CB]' : 'text-emerald-400'}`} />
                          <span className="text-white font-semibold">Active Provider Diagnostic:</span>
                          <span className="text-[#A2AFBF]">{healthStatus.message}</span>
                        </div>
                        <span className="text-[#66E3CB] tabular-nums font-bold">
                          {healthStatus.provider} · {healthStatus.latencyMs}ms
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Part B: How LORIN Can Be Accessed Securely */}
                  <div className="space-y-3 pt-2 border-t border-[#283544]">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                          How LORIN Is Accessed Securely (5 Defense-in-Depth Vectors)
                        </h3>
                        <p className="text-[11px] text-[#A2AFBF]">
                          Authentic security mechanisms separating the private LORIN system from the public MOSAIRA platform.
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={handleToggleStealth}
                        className={`px-3 py-1 rounded-lg border font-mono text-[11px] font-bold flex items-center gap-1.5 cursor-pointer ${
                          stealthActive
                            ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                            : 'bg-[#17212C] text-[#A2AFBF] border-[#283544] hover:text-white'
                        }`}
                      >
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>{stealthActive ? 'Stealth Masking: ON' : 'Stealth Masking: OFF'}</span>
                      </button>
                    </div>

                    <div className="space-y-2.5">
                      {LORIN_SECURE_ACCESS_VECTORS.map((vec) => (
                        <div
                          key={vec.id}
                          className="p-3.5 rounded-xl bg-[#0B0F14] border border-[#283544] space-y-1.5"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="font-bold text-white text-xs flex items-center gap-2">
                              <Lock className="w-3.5 h-3.5 text-[#66E3CB]" />
                              <span>{vec.title}</span>
                            </span>
                            <div className="flex items-center gap-2 font-mono text-[10px]">
                              <span className="px-2 py-0.5 rounded bg-[#17212C] border border-[#3A4B5F] text-[#66E3CB]">
                                {vec.shortcutOrEndpoint}
                              </span>
                              <span className="px-2 py-0.5 rounded bg-[#111821] border border-[#283544] text-[#A9B8FF]">
                                {vec.availability.replace(/_/g, ' ')}
                              </span>
                            </div>
                          </div>
                          <p className="text-[11px] text-[#A2AFBF] leading-relaxed">{vec.description}</p>
                          <div className="text-[10px] font-mono text-[#738297] flex items-center justify-between pt-1">
                            <span>Mechanism: <strong className="text-slate-300">{vec.mechanism}</strong></span>
                            <span>Standard: <strong className="text-emerald-400">{vec.verificationStandard}</strong></span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-[#0B0F14] border-t border-[#283544] flex flex-wrap items-center justify-between gap-3 shrink-0 font-mono text-[11px]">
              <div className="flex items-center gap-2 text-[#A2AFBF]">
                <span>Principal: <strong className="text-white">{principal.name}</strong> ({principal.role})</span>
                <span>·</span>
                <span>Mode: <strong className="text-[#66E3CB]">{LORIN_OPERATING_MODES[profileConfig.operatingMode].shortLabel}</strong></span>
                <span>·</span>
                <span>Level: <strong className="text-[#A9B8FF]">{LORIN_AUTONOMY_LEVELS[profileConfig.autonomyLevel].shortLabel}</strong></span>
              </div>

              <button
                onClick={onClose}
                className="px-5 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs cursor-pointer"
              >
                Apply & Close
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
