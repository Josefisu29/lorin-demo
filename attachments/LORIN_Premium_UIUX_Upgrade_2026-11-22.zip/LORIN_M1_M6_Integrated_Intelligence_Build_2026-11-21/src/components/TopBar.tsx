import React from 'react';
import { Cpu, ShieldCheck, User } from 'lucide-react';
import { Principal, UserRole } from '../types/lorin';

export type ActiveTab = 'chat' | 'security' | 'memory' | 'terminal' | 'tests';

interface TopBarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  backendMode: 'LIVE_GEMINI' | 'DETERMINISTIC_MOCK';
  setBackendMode: (mode: 'LIVE_GEMINI' | 'DETERMINISTIC_MOCK') => void;
  principal: Principal;
  setPrincipalRole: (role: UserRole) => void;
  pendingApprovalsCount: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  backendMode,
  setBackendMode,
  principal,
  setPrincipalRole,
  pendingApprovalsCount,
}) => {
  return (
    <header className="flex items-center justify-between gap-6 px-6 py-3.5 border-b border-slate-800/80 bg-[#0c121e] sticky top-0 z-40 select-none">
      {/* Zone 1: Single text element wordmark in display face */}
      <div className="flex items-center gap-3 shrink-0">
        <a 
          href="#dashboard" 
          onClick={(e) => { e.preventDefault(); setActiveTab('chat'); }}
          className="text-lg font-bold tracking-tight text-white whitespace-nowrap flex items-center gap-2 group"
        >
          <div className="w-7 h-7 rounded bg-sky-500/10 border border-sky-400/30 flex items-center justify-center text-sky-400 group-hover:border-sky-400/60 transition-colors">
            <Cpu className="w-4 h-4 text-sky-400" />
          </div>
          <span>LORIN</span>
        </a>
        <span className="text-[11px] font-mono text-slate-500 tracking-wider">v1.1</span>
      </div>

      {/* Zone 2: Navigation Links (1-2 word labels, single-line text links) */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('chat')}
          className={`transition-colors whitespace-nowrap pb-0.5 border-b ${
            activeTab === 'chat'
              ? 'text-sky-400 border-sky-400 font-semibold'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          Specialist Console
        </button>
        <button
          onClick={() => setActiveTab('security')}
          className={`transition-colors whitespace-nowrap pb-0.5 border-b relative ${
            activeTab === 'security'
              ? 'text-sky-400 border-sky-400 font-semibold'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          <span>Security & Policy</span>
          {pendingApprovalsCount > 0 && (
            <span className="ml-1.5 px-1.5 py-0.2 text-[10px] font-mono rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
              {pendingApprovalsCount}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('memory')}
          className={`transition-colors whitespace-nowrap pb-0.5 border-b ${
            activeTab === 'memory'
              ? 'text-sky-400 border-sky-400 font-semibold'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          Persistent Memory
        </button>
        <button
          onClick={() => setActiveTab('terminal')}
          className={`transition-colors whitespace-nowrap pb-0.5 border-b ${
            activeTab === 'terminal'
              ? 'text-sky-400 border-sky-400 font-semibold'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          Workbench & Telemetry
        </button>
        <button
          onClick={() => setActiveTab('tests')}
          className={`transition-colors whitespace-nowrap pb-0.5 border-b ${
            activeTab === 'tests'
              ? 'text-sky-400 border-sky-400 font-semibold'
              : 'border-transparent hover:text-slate-200'
          }`}
        >
          Verification Suite
        </button>
      </nav>

      {/* Zone 3: Primary Actions (Model Backend Switch & Principal Role Switcher) */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Model Backend Mode Toggle */}
        <div className="flex items-center bg-slate-900/90 border border-slate-800 rounded p-0.5 text-xs">
          <button
            onClick={() => setBackendMode('LIVE_GEMINI')}
            title="Use live Google Gemini 3.8 Flash model"
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors whitespace-nowrap ${
              backendMode === 'LIVE_GEMINI'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Live Gemini
          </button>
          <button
            onClick={() => setBackendMode('DETERMINISTIC_MOCK')}
            title="Use local deterministic offline engine"
            className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors whitespace-nowrap ${
              backendMode === 'DETERMINISTIC_MOCK'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Mock Engine
          </button>
        </div>

        {/* Principal Role Selector (Owner / Engineer / Guest) */}
        <div className="flex items-center gap-1.5 pl-2 border-l border-slate-800">
          <div className="flex items-center gap-1 px-2 py-1 rounded bg-slate-900 border border-slate-800 text-xs">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <select
              aria-label="User Principal Role"
              value={principal.role}
              onChange={(e) => setPrincipalRole(e.target.value as UserRole)}
              className="bg-transparent text-slate-300 text-xs font-mono focus:outline-none cursor-pointer"
            >
              <option value="OWNER" className="bg-slate-900 text-slate-200">Owner (Admin)</option>
              <option value="ENGINEER" className="bg-slate-900 text-slate-200">Engineer</option>
              <option value="GUEST" className="bg-slate-900 text-slate-200">Guest (Observe)</option>
            </select>
          </div>
          {principal.role === 'OWNER' && (
            <span title="Owner privileges verified" className="text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
            </span>
          )}
        </div>
      </div>
    </header>
  );
};
