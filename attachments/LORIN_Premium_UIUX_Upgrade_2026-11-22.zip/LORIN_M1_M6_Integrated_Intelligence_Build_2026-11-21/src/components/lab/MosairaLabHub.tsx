import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, 
  Layers, 
  Cpu, 
  BarChart3, 
  GitBranch, 
  ShieldAlert, 
  Upload, 
  Play, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Sliders, 
  FileText, 
  ArrowRight,
  ExternalLink,
  Plus,
  Trash2,
  FolderGit2,
  HardDrive
} from 'lucide-react';
import { Principal } from '../../types/lorin';
import { 
  LabDataset, 
  PipelineJob, 
  PipelineStage,
  KnowledgeIndex, 
  TrainingJob, 
  RegisteredModel, 
  LabAuditRecord,
  EvaluationSuite
} from '../../types/mosairaLab';
import { MosairaLabService } from '../../services/mosairaLabService';
import { GoogleDriveService, GoogleDriveFile } from '../../services/googleDriveService';

interface Props {
  principal: Principal;
  onSwitchToLaurenVault?: () => void;
}

export type LabTab = 'overview' | 'datasets' | 'pipeline' | 'indexes' | 'training' | 'evaluation' | 'registry' | 'audit';

export const MosairaLabHub: React.FC<Props> = ({ principal, onSwitchToLaurenVault }) => {
  const [activeTab, setActiveTab] = useState<LabTab>('overview');
  const [datasets, setDatasets] = useState<LabDataset[]>([]);
  const [trainingJobs, setTrainingJobs] = useState<TrainingJob[]>([]);
  const [models, setModels] = useState<RegisteredModel[]>([]);
  const [auditLogs, setAuditLogs] = useState<LabAuditRecord[]>([]);
  
  // Pipeline state
  const [selectedDatasetForPipeline, setSelectedDatasetForPipeline] = useState<string>('');
  const [activePipelineJob, setActivePipelineJob] = useState<PipelineJob | null>(null);
  const [isPipelineRunning, setIsPipelineRunning] = useState(false);

  // Google Drive Modal
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [driveFiles, setDriveFiles] = useState<GoogleDriveFile[]>([]);
  const [isScanningDrive, setIsScanningDrive] = useState(false);

  // Training Modal
  const [isNewTrainingModalOpen, setIsNewTrainingModalOpen] = useState(false);
  const [newTrainName, setNewTrainName] = useState('MOSAIRA Nova Advanced Reasoning Adapter');
  const [newTrainPersona, setNewTrainPersona] = useState('NOVA');
  const [newTrainModel, setNewTrainModel] = useState('gemini-3.8-flash');
  const [newTrainDataset, setNewTrainDataset] = useState('');
  const [newTrainLr, setNewTrainLr] = useState(0.0002);
  const [newTrainRank, setNewTrainRank] = useState(16);
  const [newTrainEpochs, setNewTrainEpochs] = useState(4);

  // Evaluation state
  const [evalSuite, setEvalSuite] = useState<EvaluationSuite | null>(null);

  const loadData = () => {
    const ds = MosairaLabService.getDatasets();
    setDatasets(ds);
    if (ds.length > 0 && !selectedDatasetForPipeline) {
      setSelectedDatasetForPipeline(ds[0].id);
    }
    setTrainingJobs(MosairaLabService.getTrainingJobs());
    const regModels = MosairaLabService.getRegisteredModels();
    setModels(regModels);
    setAuditLogs(MosairaLabService.getAuditLogs());
    if (regModels.length > 0) {
      setEvalSuite(MosairaLabService.getEvaluationSuite(regModels[0].id));
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Scan Google Drive folder
  const handleOpenDriveImport = async () => {
    setIsDriveModalOpen(true);
    setIsScanningDrive(true);
    const files = await GoogleDriveService.scanDesignatedFolder();
    setDriveFiles(files);
    setIsScanningDrive(false);
  };

  const handleImportDriveFile = async (file: GoogleDriveFile) => {
    const newDataset: LabDataset = {
      id: `ds_gdrive_${Date.now()}`,
      name: file.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '),
      description: `Imported from Google Drive (${file.name})`,
      source: 'GOOGLE_DRIVE',
      format: file.name.endsWith('.jsonl') ? 'JSONL' : file.name.endsWith('.csv') ? 'CSV' : 'MARKDOWN',
      sizeBytes: file.sizeBytes,
      rowCount: Math.floor(file.sizeBytes / 240) + 10,
      piiStatus: 'REQUIRES_SCAN',
      license: 'Proprietary / Approved for MOSAIRA',
      tags: ['google_drive', 'ingested'],
      status: 'READY',
      createdAt: Date.now(),
      googleDriveFileId: file.id
    };

    MosairaLabService.addDataset(newDataset, principal.email || 'unknown');
    loadData();
    setIsDriveModalOpen(false);
  };

  // Run 7-stage pipeline
  const handleRunPipeline = async () => {
    if (!selectedDatasetForPipeline) return;
    setIsPipelineRunning(true);
    try {
      const job = await MosairaLabService.runPipeline(selectedDatasetForPipeline, principal.email);
      setActivePipelineJob(job);
      loadData();
    } catch (err: any) {
      console.warn(err);
    } finally {
      setIsPipelineRunning(false);
    }
  };

  // Step training job
  const handleStepTraining = async (jobId: string) => {
    await MosairaLabService.stepTrainingJob(jobId);
    loadData();
  };

  // Submit training job
  const handleCreateTrainingJob = (e: React.FormEvent) => {
    e.preventDefault();
    const targetDs = newTrainDataset || datasets[0]?.id;
    if (!targetDs) return;

    MosairaLabService.createTrainingJob(
      newTrainName,
      newTrainModel,
      newTrainPersona,
      targetDs,
      {
        learningRate: newTrainLr,
        loraRank: newTrainRank,
        loraAlpha: newTrainRank * 2,
        epochs: newTrainEpochs,
        batchSize: 8,
        warmupRatio: 0.05
      },
      principal.email
    );

    setIsNewTrainingModalOpen(false);
    loadData();
    setActiveTab('training');
  };

  const handlePromote = (modelId: string, stage: 'STAGING' | 'PRODUCTION') => {
    MosairaLabService.promoteModel(modelId, stage, principal.email);
    loadData();
  };

  const handleRollback = (modelId: string) => {
    MosairaLabService.rollbackModel(modelId, principal.email);
    loadData();
  };

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] text-[#F1F5F9] font-sans overflow-hidden">
      {/* Top Engineering Workspace Header */}
      <header className="px-6 py-4 bg-[#111821] border-b border-[#283544] flex flex-wrap items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-teal-500/10 border border-teal-500/20 text-[#66E3CB]">
            <FolderGit2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold text-white tracking-tight">MOSAIRA AI Lab</h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-teal-500/10 text-[#66E3CB] border border-teal-500/30 font-semibold">
                OWNER CONTROL PLANE
              </span>
            </div>
            <p className="text-xs text-[#A2AFBF] mt-0.5">
              Production dataset governance, 7-stage processing, LoRA training & model registry
            </p>
          </div>
        </div>

        {/* Quick Workspace Switcher */}
        {onSwitchToLaurenVault && (
          <div className="flex items-center gap-3">
            <button
              onClick={onSwitchToLaurenVault}
              className="px-3.5 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] text-xs font-semibold text-[#A9B8FF] border border-[#3A4B5F] flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>Switch to Lauren Vault</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </header>

      {/* Secondary Horizontal Sub-Nav */}
      <div className="px-6 bg-[#111821]/80 border-b border-[#283544] flex items-center gap-2 overflow-x-auto text-xs shrink-0 py-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'overview' ? 'bg-[#17212C] text-[#66E3CB] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Workspace Overview
        </button>
        <button
          onClick={() => setActiveTab('datasets')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'datasets' ? 'bg-[#17212C] text-[#66E3CB] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Datasets & Google Drive ({datasets.length})
        </button>
        <button
          onClick={() => setActiveTab('pipeline')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'pipeline' ? 'bg-[#17212C] text-[#66E3CB] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Processing Pipeline
        </button>
        <button
          onClick={() => setActiveTab('training')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'training' ? 'bg-[#17212C] text-[#66E3CB] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Training Studio ({trainingJobs.length})
        </button>
        <button
          onClick={() => setActiveTab('evaluation')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'evaluation' ? 'bg-[#17212C] text-[#66E3CB] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Evaluation Centre
        </button>
        <button
          onClick={() => setActiveTab('registry')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'registry' ? 'bg-[#17212C] text-[#66E3CB] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Model Registry ({models.length})
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'audit' ? 'bg-[#17212C] text-[#66E3CB] font-bold shadow-xs' : 'text-[#A2AFBF] hover:text-white'
          }`}
        >
          Audit Log ({auditLogs.length})
        </button>
      </div>

      {/* Main Tab Content Viewport */}
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6 max-w-6xl">
            {/* KPI Summary Matrix */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-1">
                <div className="flex items-center justify-between text-[#A2AFBF] text-xs">
                  <span>Datasets Governed</span>
                  <Database className="w-4 h-4 text-[#66E3CB]" />
                </div>
                <div className="text-2xl font-bold font-mono text-white tabular-nums">{datasets.length}</div>
                <div className="text-[11px] text-[#A2AFBF]">Google Drive & Local Ingestion</div>
              </div>

              <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-1">
                <div className="flex items-center justify-between text-[#A2AFBF] text-xs">
                  <span>Active LoRA Checkpoints</span>
                  <Cpu className="w-4 h-4 text-[#A9B8FF]" />
                </div>
                <div className="text-2xl font-bold font-mono text-white tabular-nums">{trainingJobs.length}</div>
                <div className="text-[11px] text-[#A2AFBF]">PEFT Adapters Trained</div>
              </div>

              <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-1">
                <div className="flex items-center justify-between text-[#A2AFBF] text-xs">
                  <span>Production Models</span>
                  <GitBranch className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-bold font-mono text-white tabular-nums">
                  {models.filter(m => m.stage === 'PRODUCTION').length}
                </div>
                <div className="text-[11px] text-[#A2AFBF]">Validated & Deployed</div>
              </div>

              <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-1">
                <div className="flex items-center justify-between text-[#A2AFBF] text-xs">
                  <span>Security & Audits</span>
                  <ShieldAlert className="w-4 h-4 text-[#E8BE78]" />
                </div>
                <div className="text-2xl font-bold font-mono text-white tabular-nums">{auditLogs.length}</div>
                <div className="text-[11px] text-[#A2AFBF]">Tamper-Evident Entries</div>
              </div>
            </div>

            {/* Quick Action Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-5 rounded-xl bg-[#17212C] border border-[#283544] space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-white text-sm">Google Drive Dataset Sync</h3>
                  <HardDrive className="w-4 h-4 text-[#66E3CB]" />
                </div>
                <p className="text-xs text-[#A2AFBF] leading-relaxed">
                  Connect your Google Drive <span className="font-mono text-white">AI_DATA_VAULT/</span> directory or launch Google Picker to import instruction corpora, evaluation benchmarks, and persona datasets.
                </p>
                <button
                  onClick={handleOpenDriveImport}
                  className="px-4 py-2 bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs rounded-lg flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Import from Google Drive</span>
                </button>
              </div>

              <div className="p-5 rounded-xl bg-[#17212C] border border-[#283544] space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-white text-sm">LoRA Fine-Tuning Studio</h3>
                  <Sliders className="w-4 h-4 text-[#A9B8FF]" />
                </div>
                <p className="text-xs text-[#A2AFBF] leading-relaxed">
                  Configure lightweight PEFT adapters ($r=16, \alpha=32$) for conversational personas without heavyweight cloud GPU expenses. Track loss and save checkpoints.
                </p>
                <button
                  onClick={() => setIsNewTrainingModalOpen(true)}
                  className="px-4 py-2 bg-[#A9B8FF] hover:bg-[#92a4ff] text-slate-950 font-bold text-xs rounded-lg flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Configure Training Job</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: DATASETS & GOOGLE DRIVE */}
        {activeTab === 'datasets' && (
          <div className="space-y-4 max-w-6xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white">Dataset Library & Ingestion</h2>
                <p className="text-xs text-[#A2AFBF]">Approved instruction tuning, evaluation, and public commons corpora</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleOpenDriveImport}
                  className="px-3.5 py-1.5 bg-[#66E3CB] text-slate-950 hover:bg-[#52d6be] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Google Drive Ingestion</span>
                </button>
              </div>
            </div>

            {/* Datasets Table */}
            <div className="rounded-xl border border-[#283544] bg-[#17212C] overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#111821] text-[#A2AFBF] font-mono border-b border-[#283544]">
                  <tr>
                    <th className="py-3 px-4">Dataset Name</th>
                    <th className="py-3 px-4">Source</th>
                    <th className="py-3 px-4">Format</th>
                    <th className="py-3 px-4 text-right">Rows</th>
                    <th className="py-3 px-4">PII Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#283544]">
                  {datasets.map((ds) => (
                    <tr key={ds.id} className="hover:bg-[#111821]/50 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{ds.name}</div>
                        <div className="text-[11px] text-[#A2AFBF] truncate max-w-sm">{ds.description}</div>
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-[#A9B8FF]">{ds.source}</td>
                      <td className="py-3 px-4 font-mono text-[11px]">{ds.format}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-white">{ds.rowCount.toLocaleString()}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                          ds.piiStatus === 'CLEAN' || ds.piiStatus === 'ANONYMIZED'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                        }`}>
                          {ds.piiStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => {
                            setSelectedDatasetForPipeline(ds.id);
                            setActiveTab('pipeline');
                          }}
                          className="px-2.5 py-1 rounded bg-[#283544] hover:bg-[#3A4B5F] text-white text-[11px] font-mono transition-colors cursor-pointer"
                        >
                          Run Pipeline
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: PROCESSING PIPELINE */}
        {activeTab === 'pipeline' && (
          <div className="space-y-6 max-w-5xl">
            <div className="p-5 rounded-xl bg-[#17212C] border border-[#283544] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">7-Stage Semantic Ingestion Pipeline</h3>
                  <p className="text-xs text-[#A2AFBF]">Encoding check, PII sanitization, deduplication, chunking and vector indexing</p>
                </div>
                <button
                  onClick={handleRunPipeline}
                  disabled={isPipelineRunning}
                  className="px-4 py-2 bg-[#66E3CB] text-slate-950 hover:bg-[#52d6be] disabled:opacity-50 font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {isPipelineRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPipelineRunning ? 'Executing Stages...' : 'Execute 7-Stage Pipeline'}</span>
                </button>
              </div>

              {/* Dataset Selector */}
              <div className="flex items-center gap-3">
                <span className="text-xs text-[#A2AFBF] font-mono">Target Dataset:</span>
                <select
                  value={selectedDatasetForPipeline}
                  onChange={(e) => setSelectedDatasetForPipeline(e.target.value)}
                  className="px-3 py-1.5 rounded-lg bg-[#111821] border border-[#283544] text-xs text-white focus:outline-none focus:border-[#66E3CB] font-mono"
                >
                  {datasets.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.rowCount} rows)</option>
                  ))}
                </select>
              </div>

              {/* Pipeline Stages Stepper */}
              <div className="space-y-2 pt-2">
                {(activePipelineJob ? activePipelineJob.stages : ([
                  { id: 'IMPORT', name: 'File Import & Encoding Validation', status: 'PENDING', durationMs: 0, itemsProcessed: 0, details: '' },
                  { id: 'SCHEMA_VALIDATION', name: 'Structural & Schema Integrity Check', status: 'PENDING', durationMs: 0, itemsProcessed: 0, details: '' },
                  { id: 'PII_ANONYMIZATION', name: 'PII Detection & Anonymization Scan', status: 'PENDING', durationMs: 0, itemsProcessed: 0, details: '' },
                  { id: 'TEXT_EXTRACTION', name: 'Normalized Text Extraction', status: 'PENDING', durationMs: 0, itemsProcessed: 0, details: '' },
                  { id: 'DEDUPLICATION', name: 'Semantic Hash Deduplication', status: 'PENDING', durationMs: 0, itemsProcessed: 0, details: '' },
                  { id: 'CHUNKING', name: 'Contextual Semantic Chunking (512 tokens)', status: 'PENDING', durationMs: 0, itemsProcessed: 0, details: '' },
                  { id: 'EMBEDDING', name: 'Vector Embedding Generation', status: 'PENDING', durationMs: 0, itemsProcessed: 0, details: '' }
                ] as PipelineStage[])).map((stage, idx) => (
                  <div
                    key={stage.id}
                    className="p-3 rounded-lg bg-[#111821] border border-[#283544] flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-[#17212C] border border-[#283544] flex items-center justify-center font-mono text-[11px] text-[#A2AFBF]">
                        {idx + 1}
                      </span>
                      <div>
                        <div className="font-semibold text-white">{stage.name}</div>
                        {stage.details && <div className="text-[11px] text-[#66E3CB] font-mono">{stage.details}</div>}
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      {stage.durationMs > 0 && (
                        <span className="font-mono text-[#A2AFBF] text-[11px] tabular-nums">{stage.durationMs}ms</span>
                      )}
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                        stage.status === 'COMPLETED'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : stage.status === 'RUNNING'
                          ? 'bg-teal-500/10 text-[#66E3CB] border-teal-500/30'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}>
                        {stage.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: TRAINING STUDIO (LoRA / PEFT) */}
        {activeTab === 'training' && (
          <div className="space-y-4 max-w-6xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white">LoRA Fine-Tuning Studio</h2>
                <p className="text-xs text-[#A2AFBF]">Parameter-efficient fine-tuning adapters for conversational personas</p>
              </div>
              <button
                onClick={() => setIsNewTrainingModalOpen(true)}
                className="px-3.5 py-1.5 bg-[#A9B8FF] text-slate-950 hover:bg-[#92a4ff] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Fine-Tuning Job</span>
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {trainingJobs.map((job) => (
                <div key={job.id} className="p-5 rounded-xl bg-[#17212C] border border-[#283544] space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-white text-sm">{job.name}</h3>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-500/10 text-[#A9B8FF] border border-indigo-500/30 font-bold">
                          Persona: {job.targetPersona}
                        </span>
                      </div>
                      <p className="text-xs text-[#A2AFBF] mt-0.5">
                        Base: {job.baseModel} · Dataset: {job.datasetName}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className={`px-2.5 py-1 rounded text-xs font-mono font-bold border ${
                        job.status === 'COMPLETED'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : job.status === 'TRAINING'
                          ? 'bg-teal-500/10 text-[#66E3CB] border-teal-500/30'
                          : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                      }`}>
                        {job.status}
                      </span>

                      {job.status !== 'COMPLETED' && (
                        <button
                          onClick={() => handleStepTraining(job.id)}
                          className="px-3 py-1 bg-[#66E3CB] text-slate-950 font-bold text-xs rounded-lg hover:bg-[#52d6be] transition-colors cursor-pointer"
                        >
                          Step Epoch ({job.currentEpoch}/{job.totalEpochs})
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Hyperparameter Summary */}
                  <div className="grid grid-cols-4 gap-2 text-xs font-mono bg-[#111821] p-3 rounded-lg border border-[#283544]">
                    <div>
                      <div className="text-[#A2AFBF] text-[10px]">Learning Rate:</div>
                      <div className="text-white font-bold">{job.hyperparameters.learningRate}</div>
                    </div>
                    <div>
                      <div className="text-[#A2AFBF] text-[10px]">LoRA Rank (r):</div>
                      <div className="text-white font-bold">{job.hyperparameters.loraRank}</div>
                    </div>
                    <div>
                      <div className="text-[#A2AFBF] text-[10px]">LoRA Alpha:</div>
                      <div className="text-white font-bold">{job.hyperparameters.loraAlpha}</div>
                    </div>
                    <div>
                      <div className="text-[#A2AFBF] text-[10px]">Batch Size:</div>
                      <div className="text-white font-bold">{job.hyperparameters.batchSize}</div>
                    </div>
                  </div>

                  {/* Loss Curve Readout */}
                  {job.lossHistory.length > 0 && (
                    <div className="space-y-1.5 font-mono text-xs">
                      <div className="text-[11px] text-[#A2AFBF]">Deterministic Loss Progression:</div>
                      <div className="flex items-center gap-3 flex-wrap">
                        {job.lossHistory.map((pt) => (
                          <div key={pt.epoch} className="px-2.5 py-1 rounded bg-[#111821] border border-[#283544] text-[11px]">
                            <span className="text-[#A2AFBF]">Ep {pt.epoch}:</span>{' '}
                            <span className="text-emerald-400 font-bold">{pt.loss}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: EVALUATION CENTRE */}
        {activeTab === 'evaluation' && evalSuite && (
          <div className="space-y-6 max-w-5xl">
            <div className="p-5 rounded-xl bg-[#17212C] border border-[#283544] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Evaluation Benchmark Matrix</h3>
                  <p className="text-xs text-[#A2AFBF]">Systematic validation before production promotion</p>
                </div>
                <div className="text-right font-mono">
                  <div className="text-xs text-[#A2AFBF]">Overall Composite:</div>
                  <div className="text-xl font-bold text-emerald-400">{evalSuite.overallScore}%</div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {evalSuite.benchmarks.map((bm) => (
                  <div key={bm.name} className="p-3.5 rounded-lg bg-[#111821] border border-[#283544] space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-white">{bm.name}</span>
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        {bm.status}
                      </span>
                    </div>
                    <div className="flex items-center justify-between font-mono text-xs text-[#A2AFBF]">
                      <span>Achieved: {bm.score}%</span>
                      <span>Target: &gt;={bm.targetScore}%</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Side-by-side prompt diff */}
              <div className="space-y-2 pt-2 border-t border-[#283544]">
                <h4 className="text-xs font-bold text-white uppercase font-mono">Side-by-Side Prompt Verification</h4>
                {evalSuite.sampleOutputs.map((so, i) => (
                  <div key={i} className="p-3.5 rounded-lg bg-[#111821] border border-[#283544] space-y-2 text-xs">
                    <div className="font-semibold text-[#A9B8FF]">{so.prompt}</div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] leading-relaxed">
                      <div className="p-2.5 rounded bg-[#17212C] border border-[#283544]">
                        <div className="text-[#A2AFBF] font-mono text-[10px] mb-1">Standard Base Output:</div>
                        <p className="text-[#738297]">{so.baseOutput}</p>
                      </div>
                      <div className="p-2.5 rounded bg-[#17212C] border border-[#66E3CB]/40">
                        <div className="text-[#66E3CB] font-mono text-[10px] mb-1">Fine-Tuned Adapter Output:</div>
                        <p className="text-white">{so.fineTunedOutput}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: MODEL REGISTRY */}
        {activeTab === 'registry' && (
          <div className="space-y-4 max-w-6xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-white">Versioned Model Registry</h2>
                <p className="text-xs text-[#A2AFBF]">Promote models to Staging or Production, or execute instant rollback</p>
              </div>
            </div>

            <div className="rounded-xl border border-[#283544] bg-[#17212C] overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#111821] text-[#A2AFBF] font-mono border-b border-[#283544]">
                  <tr>
                    <th className="py-3 px-4">Model & Version</th>
                    <th className="py-3 px-4">Base Architecture</th>
                    <th className="py-3 px-4">Persona</th>
                    <th className="py-3 px-4">Deployment Stage</th>
                    <th className="py-3 px-4 text-right">Eval Score</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#283544]">
                  {models.map((mod) => (
                    <tr key={mod.id} className="hover:bg-[#111821]/50 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{mod.name}</div>
                        <div className="font-mono text-[11px] text-[#A2AFBF]">{mod.version}</div>
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-300">{mod.baseModel}</td>
                      <td className="py-3 px-4 font-mono text-[11px] text-[#66E3CB]">{mod.targetPersona}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                          mod.stage === 'PRODUCTION'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                            : mod.stage === 'STAGING'
                            ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30'
                            : 'bg-slate-800 text-slate-400 border-slate-700'
                        }`}>
                          {mod.stage}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-white font-bold">{mod.evalScore}%</td>
                      <td className="py-3 px-4 text-right space-x-2">
                        {mod.stage !== 'PRODUCTION' && (
                          <button
                            onClick={() => handlePromote(mod.id, 'PRODUCTION')}
                            className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-[10px] transition-colors cursor-pointer"
                          >
                            Promote to Prod
                          </button>
                        )}
                        {mod.rollbackVersion && (
                          <button
                            onClick={() => handleRollback(mod.id)}
                            className="px-2 py-1 rounded bg-[#283544] hover:bg-[#3A4B5F] text-[#E8BE78] font-mono text-[10px] transition-colors cursor-pointer"
                            title="Rollback to previous version"
                          >
                            Rollback
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 7: AUDIT LOG */}
        {activeTab === 'audit' && (
          <div className="space-y-4 max-w-5xl">
            <div>
              <h2 className="text-sm font-bold text-white">Security & Operational Audit Log</h2>
              <p className="text-xs text-[#A2AFBF]">Server-authoritative, tamper-evident log of datasets and model updates</p>
            </div>

            <div className="space-y-2">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-lg bg-[#17212C] border border-[#283544] flex items-center justify-between text-xs font-mono"
                >
                  <div className="space-y-0.5 truncate max-w-xl">
                    <div className="flex items-center gap-2">
                      <span className="text-[#66E3CB] font-bold">{log.action}</span>
                      <span className="text-[#A2AFBF]">·</span>
                      <span className="text-white truncate">{log.target}</span>
                    </div>
                    <div className="text-[11px] text-[#A2AFBF] font-sans truncate">{log.details}</div>
                  </div>

                  <div className="text-right text-[11px] text-[#738297] shrink-0">
                    <div>{new Date(log.timestamp).toLocaleTimeString()}</div>
                    <div className="text-white truncate max-w-[140px]">{log.actor}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Google Drive Ingestion Modal */}
      {isDriveModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-xl bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-[#66E3CB]" />
                <h3 className="text-sm font-bold text-white">Google Drive Dataset Selector</h3>
              </div>
              <button onClick={() => setIsDriveModalOpen(false)} className="text-[#A2AFBF] hover:text-white cursor-pointer">✕</button>
            </div>

            <p className="text-xs text-[#A2AFBF]">
              Files scanned from your designated <span className="font-mono text-white">AI_DATA_VAULT/</span> directory. Select a dataset to import into MOSAIRA AI Lab.
            </p>

            {isScanningDrive ? (
              <div className="py-8 flex flex-col items-center justify-center text-xs text-[#A2AFBF] gap-2">
                <RefreshCw className="w-5 h-5 animate-spin text-[#66E3CB]" />
                <span>Scanning Google Drive...</span>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {driveFiles.map((file) => (
                  <div
                    key={file.id}
                    className="p-3 rounded-lg bg-[#17212C] border border-[#283544] flex items-center justify-between text-xs hover:border-[#66E3CB] transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-white">{file.name}</div>
                      <div className="text-[11px] font-mono text-[#A2AFBF]">
                        {(file.sizeBytes / 1024).toFixed(0)} KB · {file.mimeType}
                      </div>
                    </div>
                    <button
                      onClick={() => handleImportDriveFile(file)}
                      className="px-3 py-1 bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      Import
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-end pt-2 border-t border-[#283544]">
              <button
                onClick={() => setIsDriveModalOpen(false)}
                className="px-4 py-1.5 rounded-lg bg-[#283544] text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Training Job Modal */}
      {isNewTrainingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#A9B8FF]" />
                <h3 className="text-sm font-bold text-white">Configure LoRA Fine-Tuning Job</h3>
              </div>
              <button onClick={() => setIsNewTrainingModalOpen(false)} className="text-[#A2AFBF] hover:text-white cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleCreateTrainingJob} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[#A2AFBF] font-mono">Job Name</label>
                <input
                  type="text"
                  value={newTrainName}
                  onChange={(e) => setNewTrainName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[#A2AFBF] font-mono">Target Persona</label>
                  <select
                    value={newTrainPersona}
                    onChange={(e) => setNewTrainPersona(e.target.value)}
                    className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white font-mono"
                  >
                    <option value="NOVA">NOVA (Analytical Lead)</option>
                    <option value="ORION">ORION (Deep Reasoning)</option>
                    <option value="SOLIS">SOLIS (Creative Synthesizer)</option>
                    <option value="KAIROS">KAIROS (Real-time Flow)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[#A2AFBF] font-mono">Base Model (PEFT Target)</label>
                  <select
                    value={newTrainModel}
                    onChange={(e) => setNewTrainModel(e.target.value)}
                    className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white font-mono"
                  >
                    <option value="gemini-3.8-flash">Gemini 3.8 Flash</option>
                    <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite</option>
                    <option value="llama-3-8b">Llama 3 8B (Local GGUF)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 font-mono">
                <div className="space-y-1">
                  <label className="text-[#A2AFBF]">Learning Rate</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={newTrainLr}
                    onChange={(e) => setNewTrainLr(parseFloat(e.target.value))}
                    className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#A2AFBF]">LoRA Rank (r)</label>
                  <input
                    type="number"
                    value={newTrainRank}
                    onChange={(e) => setNewTrainRank(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[#A2AFBF]">Epochs</label>
                  <input
                    type="number"
                    value={newTrainEpochs}
                    onChange={(e) => setNewTrainEpochs(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 bg-[#17212C] border border-[#283544] rounded-lg text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#283544]">
                <button
                  type="button"
                  onClick={() => setIsNewTrainingModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#283544] text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#66E3CB] text-slate-950 font-bold hover:bg-[#52d6be] cursor-pointer"
                >
                  Launch Job
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
