import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  Upload, 
  Download, 
  FileText, 
  Trash2, 
  RotateCcw, 
  Plus, 
  ExternalLink, 
  Tag, 
  Database,
  CheckCircle,
  AlertCircle,
  FileCode,
  Folder
} from 'lucide-react';
import { VaultDocument } from '../types/lorin';
import { VaultStore } from '../services/vaultStore';

export const KnowledgeVaultView: React.FC = () => {
  const [documents, setDocuments] = useState<VaultDocument[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCollection, setSelectedCollection] = useState<string>('ALL');
  const [searchResults, setSearchResults] = useState<{
    document: VaultDocument;
    snippet: string;
    score: number;
    chunkIndex: number;
  }[]>([]);

  const [activeDocViewer, setActiveDocViewer] = useState<VaultDocument | null>(null);
  const [noticeMessage, setNoticeMessage] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);

  // Manual Document Addition Modal
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadCollection, setUploadCollection] = useState('Core Architecture');
  const [uploadContent, setUploadContent] = useState('');
  const [uploadTags, setUploadTags] = useState('offline, spec');
  const [embeddingMeta, setEmbeddingMeta] = useState(() => VaultStore.getEmbeddingMeta());

  const refreshVault = () => {
    setDocuments(VaultStore.getDocuments());
    setEmbeddingMeta(VaultStore.getEmbeddingMeta());
  };

  useEffect(() => {
    refreshVault();
    VaultStore.syncFromBackend().then(refreshVault);
  }, []);

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    if (!q.trim()) {
      setSearchResults([]);
      return;
    }
    const results = VaultStore.search(q, selectedCollection);
    setSearchResults(results);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      VaultStore.addDocument(
        file.name.replace(/\.[^/.]+$/, ""),
        file.name,
        file.type || 'text/plain',
        content,
        selectedCollection !== 'ALL' ? selectedCollection : 'General'
      );
      refreshVault();
      setNoticeMessage(`Imported "${file.name}" into Knowledge Vault (${new Blob([content]).size} bytes).`);
      setTimeout(() => setNoticeMessage(null), 3500);
    };
    reader.readAsText(file);
  };

  const handleManualAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadTitle.trim() || !uploadContent.trim()) return;

    const tagsArr = uploadTags.split(',').map(t => t.trim()).filter(Boolean);
    VaultStore.addDocument(
      uploadTitle,
      `${uploadTitle.toLowerCase().replace(/\s+/g, '_')}.md`,
      'text/markdown',
      uploadContent,
      uploadCollection,
      tagsArr
    );

    refreshVault();
    setIsUploadModalOpen(false);
    setUploadTitle('');
    setUploadContent('');
    setNoticeMessage(`Created reference document "${uploadTitle}".`);
    setTimeout(() => setNoticeMessage(null), 3000);
  };

  const handleDelete = (id: string, title: string) => {
    VaultStore.deleteDocument(id);
    setPendingDeleteId(null);
    refreshVault();
    if (activeDocViewer?.id === id) setActiveDocViewer(null);
    setNoticeMessage(`Document "${title}" removed from Knowledge Vault.`);
    setTimeout(() => setNoticeMessage(null), 3000);
  };

  const handleReindex = (id: string) => {
    VaultStore.reindexDocument(id);
    refreshVault();
    setNoticeMessage('Document re-indexed with updated chunks.');
    setTimeout(() => setNoticeMessage(null), 2500);
  };

  const handleExportJson = () => {
    const jsonStr = VaultStore.exportJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lorin_knowledge_vault_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const collections = ['ALL', ...VaultStore.getCollections()];
  const filteredDocs = documents.filter(d => {
    if (selectedCollection !== 'ALL' && d.collection !== selectedCollection) return false;
    return true;
  });

  const totalVaultBytes = VaultStore.getTotalBytes();

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] overflow-hidden">
      {/* Top Header */}
      <div className="p-4 border-b border-[#283544] bg-[#111821] flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center">
            <BookOpen className="w-4 h-4 text-[#66E3CB]" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight">Offline Knowledge Vault</h2>
            <div className="text-[11px] font-mono text-[#A2AFBF] flex items-center gap-2">
              <span>Local-First Knowledge Library</span>
              <span>·</span>
              <span>{documents.length} Documents</span>
              <span>·</span>
              <span>{Math.round(totalVaultBytes / 1024)} KB Indexed</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <label className="px-3 py-1.5 rounded-lg bg-[#17212C] border border-[#3A4B5F] hover:bg-[#151E28] text-xs font-mono text-[#66E3CB] flex items-center gap-1.5 cursor-pointer transition-colors">
            <Upload className="w-3.5 h-3.5" />
            <span>Import File</span>
            <input
              type="file"
              accept=".txt,.md,.json,.csv,.js,.ts,.html"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>

          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="px-3 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Document</span>
          </button>

          <button
            onClick={handleExportJson}
            className="px-3 py-1.5 rounded-lg bg-[#17212C] border border-[#283544] hover:bg-[#151E28] text-xs font-mono text-[#A2AFBF] hover:text-white flex items-center gap-1.5"
            title="Export Vault JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Main Vault Workspace */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Notification banner */}
          {noticeMessage && (
            <div className="p-3.5 rounded-xl bg-[#17212C] border border-[#66E3CB]/40 text-[#66E3CB] text-xs flex items-center justify-between">
              <span>{noticeMessage}</span>
              <span className="text-[10px] text-[#A2AFBF] font-mono">Offline storage updated</span>
            </div>
          )}

          {/* Separate Knowledge Vault Embedding Pipeline Status (Section 3.7) */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
            <div className="flex items-center gap-3">
              <Database className="w-4 h-4 text-[#66E3CB] shrink-0" />
              <div>
                <div className="font-bold text-white flex items-center gap-2">
                  <span>Separate Embedding Pipeline:</span>
                  <span className="text-[#66E3CB]">{embeddingMeta.embeddingModelId}</span>
                  <span className="px-1.5 py-0.5 rounded bg-[#17212C] border border-[#3A4B5F] text-[10px] text-[#A9B8FF]">
                    {embeddingMeta.vectorDimension}-D Vectors · Index v{embeddingMeta.indexVersion}
                  </span>
                </div>
                <div className="text-[11px] text-[#A2AFBF] mt-0.5">
                  Provider: {embeddingMeta.provider} · {embeddingMeta.totalIndexedChunks} Homogeneous Chunks Indexed · Hybrid Search (BM25 + Cosine Similarity)
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <select
                aria-label="Knowledge Vault Embedding Model"
                value={embeddingMeta.embeddingModelId}
                onChange={(e) => {
                  const nextModel = e.target.value;
                  const updated = VaultStore.reindexWithEmbeddingModel(nextModel, embeddingMeta.vectorDimension);
                  refreshVault();
                  setNoticeMessage(
                    `Reindexed all ${updated.totalIndexedChunks} chunks with ${updated.embeddingModelId} (${updated.vectorDimension}-D, Index v${updated.indexVersion}). Zero dimension mixing.`
                  );
                  setTimeout(() => setNoticeMessage(null), 4000);
                }}
                className="px-2.5 py-1.5 rounded-lg bg-[#17212C] border border-[#3A4B5F] text-[11px] text-white cursor-pointer"
              >
                <option value="qwen3-embedding:8b">Qwen3-Embedding-8B (Ollama Cloud · Apache-2.0)</option>
                <option value="gemini-embedding-2-preview">Gemini Embedding 2 (Google Cloud Fallback)</option>
              </select>

              <button
                type="button"
                onClick={() => {
                  const updated = VaultStore.reindexWithEmbeddingModel(
                    embeddingMeta.embeddingModelId || embeddingMeta.activeEmbeddingModelId || 'qwen3-embedding:8b',
                    embeddingMeta.vectorDimension
                  );
                  refreshVault();
                  setNoticeMessage(
                    `Controlled vector reindex completed (${updated.totalIndexedChunks ?? updated.chunksIndexed} chunks, Index v${updated.indexVersion}).`
                  );
                  setTimeout(() => setNoticeMessage(null), 3500);
                }}
                className="px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[11px] text-[#66E3CB] flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reindex Vectors</span>
              </button>
            </div>
          </div>

          {/* Search & Collection Filter Bar */}
          <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] space-y-3 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#738297] absolute left-3 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  placeholder="Hybrid search (BM25 + Semantic Vector Similarity) across documents..."
                  className="w-full bg-[#17212C] border border-[#283544] rounded-lg px-3.5 py-2.5 pl-9 text-xs text-white placeholder-[#738297] focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              {searchQuery && (
                <button
                  onClick={() => handleSearch('')}
                  className="px-3 py-2 rounded-lg bg-[#17212C] text-xs text-[#A2AFBF] hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Collection filters */}
            <div className="flex items-center gap-2 overflow-x-auto text-xs pt-1">
              <span className="text-[11px] font-mono text-[#738297] shrink-0">Collection:</span>
              {collections.map((col) => (
                <button
                  key={col}
                  onClick={() => setSelectedCollection(col)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-mono transition-colors whitespace-nowrap ${
                    selectedCollection === col
                      ? 'bg-[#17212C] text-[#66E3CB] border border-[#3A4B5F]'
                      : 'text-[#A2AFBF] hover:text-white border border-transparent'
                  }`}
                >
                  {col}
                </button>
              ))}
            </div>
          </div>

          {/* Search Results Display (if active query) */}
          {searchQuery.trim() && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono text-[#A2AFBF]">
                <span>Hybrid Search Matches ({searchResults.length} excerpts found)</span>
                <span>Ranked by Hybrid BM25 + Vector Cosine Score ({embeddingMeta.embeddingModelId})</span>
              </div>

              {searchResults.length === 0 ? (
                <div className="p-8 rounded-xl bg-[#111821] border border-[#283544] text-center text-xs text-[#738297]">
                  No exact or semantic matches found in offline library for "{searchQuery}".
                </div>
              ) : (
                <div className="space-y-2">
                  {searchResults.map((res, i) => (
                    <div
                      key={i}
                      className="p-4 rounded-xl bg-[#111821] border border-[#283544] hover:border-[#3A4B5F] text-xs space-y-2 transition-colors cursor-pointer"
                      onClick={() => setActiveDocViewer(res.document)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-[#66E3CB]" />
                          <span className="font-semibold text-white">{res.document.title}</span>
                          <span className="text-[10px] font-mono text-[#738297]">Chunk #{res.chunkIndex + 1}</span>
                        </div>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#17212C] text-[#66E3CB]">
                          Score: {res.score.toFixed(1)}
                        </span>
                      </div>
                      <p className="text-[#A2AFBF] leading-relaxed font-sans">{res.snippet}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Document Library Table */}
          <div className="rounded-xl bg-[#111821] border border-[#283544] overflow-hidden shadow-lg">
            <div className="p-4 border-b border-[#283544] flex items-center justify-between">
              <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Indexed Library Documents ({filteredDocs.length})
              </span>
              <span className="text-[11px] font-mono text-[#738297]">
                Local IndexedDB / Storage Available Offline
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#283544] text-[#738297] text-[11px] bg-[#0B0F14]/40">
                    <th className="py-2.5 px-4">Document Title</th>
                    <th className="py-2.5 px-4">Collection</th>
                    <th className="py-2.5 px-4">Type</th>
                    <th className="py-2.5 px-4">Size</th>
                    <th className="py-2.5 px-4">Chunks</th>
                    <th className="py-2.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#283544]/60 text-[#F1F5F9]">
                  {filteredDocs.map((doc) => (
                    <tr key={doc.id} className="hover:bg-[#17212C]/50 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveDocViewer(doc)}>
                          <FileText className="w-4 h-4 text-[#66E3CB] shrink-0" />
                          <span className="font-semibold text-white hover:text-[#66E3CB] transition-colors">{doc.title}</span>
                        </div>
                        <div className="text-[10px] text-[#738297] mt-0.5">{doc.fileName}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded bg-[#17212C] text-[#A2AFBF] text-[10px] border border-[#283544]">
                          {doc.collection}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[#A2AFBF] text-[11px]">{doc.fileType.split('/')[1] || 'text'}</td>
                      <td className="py-3 px-4 text-[#A2AFBF] text-[11px] tabular-nums">
                        {Math.round(doc.fileSize / 1024)} KB
                      </td>
                      <td className="py-3 px-4 text-[#66E3CB] font-bold tabular-nums">
                        {doc.chunks.length} chunks
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setActiveDocViewer(doc)}
                            className="p-1 rounded hover:bg-[#17212C] text-[#A2AFBF] hover:text-white"
                            title="Inspect document"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleReindex(doc.id)}
                            className="p-1 rounded hover:bg-[#17212C] text-[#A2AFBF] hover:text-[#66E3CB]"
                            title="Re-index document"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                          {pendingDeleteId === doc.id ? (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleDelete(doc.id, doc.title)}
                                className="px-2 py-0.5 rounded bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-[10px] font-bold whitespace-nowrap cursor-pointer"
                              >
                                Confirm
                              </button>
                              <button
                                onClick={() => setPendingDeleteId(null)}
                                className="px-2 py-0.5 rounded bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[#A2AFBF] text-[10px] whitespace-nowrap cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setPendingDeleteId(doc.id)}
                              className="p-1 rounded hover:bg-rose-950/40 text-[#738297] hover:text-rose-400 cursor-pointer"
                              title="Delete from vault"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Document Reader Modal */}
      {activeDocViewer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="w-full max-w-2xl bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-4 text-xs shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <div>
                <h3 className="text-base font-bold text-white">{activeDocViewer.title}</h3>
                <div className="text-[11px] font-mono text-[#A2AFBF] mt-0.5">
                  File: {activeDocViewer.fileName} · {activeDocViewer.chunks.length} indexed chunks
                </div>
              </div>
              <button
                onClick={() => setActiveDocViewer(null)}
                className="text-[#738297] hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 rounded-xl bg-[#0B0F14] border border-[#283544] font-mono text-[11px] text-[#A2AFBF] leading-relaxed whitespace-pre-wrap select-text">
              {activeDocViewer.content}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[#283544] text-[11px] font-mono text-[#738297]">
              <span>Collection: {activeDocViewer.collection}</span>
              <button
                onClick={() => setActiveDocViewer(null)}
                className="px-4 py-2 rounded-lg bg-[#17212C] hover:bg-[#283544] text-white"
              >
                Close Viewer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Document Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <form
            onSubmit={handleManualAddSubmit}
            className="w-full max-w-xl bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-4 text-xs shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <h3 className="text-sm font-bold text-white">Create Vault Knowledge Document</h3>
              <button
                type="button"
                onClick={() => setIsUploadModalOpen(false)}
                className="text-[#738297] hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 font-mono">
              <div>
                <label className="block text-[#A2AFBF] mb-1 font-sans">Document Title</label>
                <input
                  type="text"
                  required
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder="e.g. Microservices Rate Limiting Specification"
                  className="w-full bg-[#17212C] border border-[#283544] rounded-lg px-3 py-2 text-white font-sans focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#A2AFBF] mb-1 font-sans">Collection</label>
                  <input
                    type="text"
                    value={uploadCollection}
                    onChange={(e) => setUploadCollection(e.target.value)}
                    className="w-full bg-[#17212C] border border-[#283544] rounded-lg px-3 py-2 text-white font-sans focus:outline-none focus:border-[#66E3CB]"
                  />
                </div>
                <div>
                  <label className="block text-[#A2AFBF] mb-1 font-sans">Tags (comma-separated)</label>
                  <input
                    type="text"
                    value={uploadTags}
                    onChange={(e) => setUploadTags(e.target.value)}
                    className="w-full bg-[#17212C] border border-[#283544] rounded-lg px-3 py-2 text-white font-sans focus:outline-none focus:border-[#66E3CB]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#A2AFBF] mb-1 font-sans">Content (Markdown or Plain Text)</label>
                <textarea
                  required
                  rows={6}
                  value={uploadContent}
                  onChange={(e) => setUploadContent(e.target.value)}
                  placeholder="Paste architectural guidelines, API contracts, domain models, or reference knowledge..."
                  className="w-full bg-[#17212C] border border-[#283544] rounded-lg px-3 py-2 text-white font-sans focus:outline-none focus:border-[#66E3CB]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#283544]">
              <button
                type="button"
                onClick={() => setIsUploadModalOpen(false)}
                className="px-4 py-2 rounded-lg bg-[#17212C] text-[#A2AFBF] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold"
              >
                Save & Index
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
