import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Mic,
  RefreshCw,
  ShieldCheck,
  Volume2,
  Wifi,
  X,
  Zap,
  Clock
} from 'lucide-react';
import {
  CommunicationDiagnosticsSnapshot,
  CommunicationManager
} from '../services/communicationManager';
import { AudioService } from '../services/audioService';
import { getAuthHeaders } from '../services/authHeaders';

interface CommunicationDiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedModel?: string;
  backendMode?: string;
  onRetryLastRequest?: () => void;
}

interface ServerCommStatus {
  authenticated: boolean;
  principal?: { id: string; email: string; role: string };
  providers?: {
    geminiConfigured: boolean;
    ollamaCloudConfigured: boolean;
    activePrimaryProvider: string;
    defaultTextModel: string;
  };
  voiceCapabilities?: {
    cloudTranscriptionReady: boolean;
    cloudTranscriptionModel: string;
    cloudNeuralTtsReady: boolean;
    cloudNeuralTtsModel: string;
    browserSpeechFallbackSupported: boolean;
  };
  timestamp?: number;
}

export const CommunicationDiagnosticsModal: React.FC<CommunicationDiagnosticsModalProps> = ({
  isOpen,
  onClose,
  selectedModel,
  backendMode,
  onRetryLastRequest
}) => {
  const [snapshot, setSnapshot] = useState<CommunicationDiagnosticsSnapshot>(() =>
    CommunicationManager.getSnapshot()
  );
  const [serverStatus, setServerStatus] = useState<ServerCommStatus | null>(null);
  const [isProbing, setIsProbing] = useState(false);
  const [probeError, setProbeError] = useState<string | null>(null);
  const [useNeuralTts, setUseNeuralTts] = useState<boolean>(() =>
    AudioService.getPreferCloudNeuralTts()
  );

  useEffect(() => {
    const unsubscribe = CommunicationManager.subscribe(setSnapshot);
    return unsubscribe;
  }, []);

  const fetchServerDiagnostics = async () => {
    setIsProbing(true);
    setProbeError(null);
    try {
      const res = await fetch('/api/communication/status', {
        method: 'GET',
        headers: await getAuthHeaders({ Accept: 'application/json' })
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setProbeError(errData?.error || `Server status check returned HTTP ${res.status}`);
        setServerStatus(null);
      } else {
        const data = await res.json();
        setServerStatus(data);
      }
    } catch (err: any) {
      setProbeError(err?.message || 'Unable to reach /api/communication/status');
    } finally {
      setIsProbing(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      CommunicationManager.detectBrowserCapabilities();
      fetchServerDiagnostics();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleToggleNeuralTts = () => {
    const next = !useNeuralTts;
    setUseNeuralTts(next);
    AudioService.setPreferCloudNeuralTts(next);
  };

  const handleTestVoiceOutput = () => {
    AudioService.speakWithNeuralOption(
      'LORIN communication diagnostics check passed. Voice output is operational.',
      undefined,
      { useCloudNeuralTts: useNeuralTts }
    );
  };

  const handleProbeMicrophone = async () => {
    const perm = await AudioService.requestMicrophonePermission();
    CommunicationManager.setMicrophoneStatus(
      perm.granted ? 'granted' : perm.state === 'denied' ? 'denied' : 'prompt',
      true
    );
  };

  const isPrivileged =
    serverStatus?.principal?.role === 'SYSTEM_OWNER' ||
    serverStatus?.principal?.role === 'SUPER_ADMIN';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Communication Diagnostics Panel"
    >
      <div className="w-full max-w-3xl max-h-[88vh] flex flex-col rounded-2xl bg-[#0B0F17] border border-white/10 shadow-2xl overflow-hidden text-zinc-100">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#0F1522]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-300">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">
                Communication Diagnostics & State Inspector
              </h2>
              <p className="text-xs text-zinc-400">
                Real-time text, voice, provider routing, and audio pipeline health
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={fetchServerDiagnostics}
              disabled={isProbing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 hover:bg-white/10 text-zinc-200 border border-white/10 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isProbing ? 'animate-spin text-teal-400' : ''}`} />
              Refresh Status
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close diagnostics"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Active Communication State Banner */}
          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span
                className={`w-3 h-3 rounded-full ${
                  snapshot.currentState === 'error' || snapshot.currentState === 'disconnected'
                    ? 'bg-red-400 animate-pulse'
                    : snapshot.currentState === 'idle' || snapshot.currentState === 'completed'
                    ? 'bg-emerald-400'
                    : 'bg-teal-400 animate-pulse'
                }`}
              />
              <div>
                <div className="text-xs uppercase tracking-wider text-zinc-400">
                  Current State Machine Status
                </div>
                <div className="text-sm font-semibold text-white flex items-center gap-2 mt-0.5">
                  <span>{snapshot.currentStatusMessage}</span>
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-white/5 text-teal-300 border border-white/10">
                    {snapshot.currentState}
                  </span>
                </div>
                {snapshot.currentDetail && (
                  <p className="text-xs text-zinc-400 mt-0.5">{snapshot.currentDetail}</p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-zinc-300">
                Avatar State: <strong className="text-teal-300">{snapshot.characterState}</strong>
              </span>
              {snapshot.lastError && onRetryLastRequest && (
                <button
                  type="button"
                  onClick={() => {
                    CommunicationManager.clearError();
                    onRetryLastRequest();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/40 text-teal-200 font-medium transition-colors"
                >
                  Retry Last Request
                </button>
              )}
            </div>
          </div>

          {/* Last Error Remediation Box */}
          {(snapshot.lastError || probeError) && (
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-semibold text-xs uppercase tracking-wider text-red-300">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{snapshot.lastError?.code || 'DIAGNOSTIC_NOTICE'}</span>
                </div>
                <button
                  type="button"
                  onClick={() => CommunicationManager.clearError()}
                  className="text-[11px] underline text-red-300 hover:text-white"
                >
                  Dismiss
                </button>
              </div>
              <p className="text-xs text-red-100">
                {snapshot.lastError?.message || probeError}
              </p>
              {snapshot.lastError?.remediation && (
                <p className="text-xs text-amber-200/90 pt-1 border-t border-red-500/20">
                  <strong>Recommended Fix:</strong> {snapshot.lastError.remediation}
                </p>
              )}
            </div>
          )}

          {/* 4-Card Status Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* 1. Connectivity & Authentication */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-zinc-400 flex items-center gap-1.5">
                  <Wifi className="w-3.5 h-3.5 text-teal-400" />
                  Network & Auth Boundary
                </span>
                <span
                  className={`text-[11px] px-2 py-0.5 rounded font-medium ${
                    snapshot.isOnline && serverStatus?.authenticated
                      ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {snapshot.isOnline
                    ? serverStatus?.authenticated
                      ? 'Authenticated'
                      : 'Checking Auth'
                    : 'Offline'}
                </span>
              </div>
              <div className="text-xs text-zinc-300 space-y-1">
                <div>
                  Browser Connectivity:{' '}
                  <strong className="text-white">{snapshot.isOnline ? 'Online' : 'Offline'}</strong>
                </div>
                <div>
                  Principal Role:{' '}
                  <strong className="text-teal-300">
                    {serverStatus?.principal?.role || 'Active Session'}
                  </strong>
                </div>
              </div>
            </div>

            {/* 2. AI Provider & Model Availability */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-zinc-400 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                  AI Provider & Routing
                </span>
                <span
                  className={`text-[11px] px-2 py-0.5 rounded font-medium ${
                    serverStatus?.providers?.geminiConfigured ||
                    serverStatus?.providers?.ollamaCloudConfigured
                      ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {serverStatus?.providers?.activePrimaryProvider || backendMode || 'LIVE_GEMINI'}
                </span>
              </div>
              <div className="text-xs text-zinc-300 space-y-1">
                <div>
                  Selected Model:{' '}
                  <strong className="text-white">
                    {selectedModel || serverStatus?.providers?.defaultTextModel || 'gemini-3.8-flash'}
                  </strong>
                </div>
                <div className="flex items-center gap-3 text-[11px] text-zinc-400">
                  <span>
                    Gemini Proxy:{' '}
                    <strong
                      className={
                        serverStatus?.providers?.geminiConfigured
                          ? 'text-emerald-300'
                          : 'text-amber-300'
                      }
                    >
                      {serverStatus?.providers?.geminiConfigured ? 'Ready' : 'Unconfigured'}
                    </strong>
                  </span>
                  <span>
                    Ollama Cloud:{' '}
                    <strong
                      className={
                        serverStatus?.providers?.ollamaCloudConfigured
                          ? 'text-emerald-300'
                          : 'text-zinc-400'
                      }
                    >
                      {serverStatus?.providers?.ollamaCloudConfigured ? 'Ready' : 'Optional'}
                    </strong>
                  </span>
                </div>
              </div>
            </div>

            {/* 3. Microphone & Speech-to-Text */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-zinc-400 flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5 text-teal-400" />
                  Microphone & Speech-to-Text
                </span>
                <button
                  type="button"
                  onClick={handleProbeMicrophone}
                  className="text-[11px] px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-teal-300 border border-white/10"
                >
                  Verify Mic
                </button>
              </div>
              <div className="text-xs text-zinc-300 space-y-1">
                <div>
                  Mic Permission:{' '}
                  <strong className="text-white capitalize">{snapshot.microphonePermission}</strong>
                </div>
                <div>
                  Recognition Engine:{' '}
                  <strong className="text-teal-300">
                    {snapshot.speechRecognitionSupport === 'HYBRID_WEB_AND_CLOUD'
                      ? 'Web Speech + Cloud Gemini 3.5 Transcribe'
                      : snapshot.speechRecognitionSupport === 'CLOUD_GEMINI_TRANSCRIBE'
                      ? 'Cloud Gemini 3.5 Transcribe (MediaRecorder)'
                      : snapshot.speechRecognitionSupport}
                  </strong>
                </div>
              </div>
            </div>

            {/* 4. Text-to-Speech (TTS) Output */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-zinc-400 flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                  Voice Output (TTS)
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleToggleNeuralTts}
                    className={`text-[11px] px-2 py-0.5 rounded border transition-colors ${
                      useNeuralTts
                        ? 'bg-teal-500/20 border-teal-500/40 text-teal-200'
                        : 'bg-white/5 border-white/10 text-zinc-300'
                    }`}
                  >
                    {useNeuralTts ? 'Neural TTS: ON' : 'Browser TTS'}
                  </button>
                  <button
                    type="button"
                    onClick={handleTestVoiceOutput}
                    className="text-[11px] px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-zinc-200 border border-white/10"
                  >
                    Test Audio
                  </button>
                </div>
              </div>
              <div className="text-xs text-zinc-300 space-y-1">
                <div>
                  Active TTS Engine:{' '}
                  <strong className="text-white">
                    {useNeuralTts
                      ? 'Gemini 3.8 Flash-Lite Neural TTS (with Browser Fallback)'
                      : 'Browser SpeechSynthesis'}
                  </strong>
                </div>
                <div>
                  Cloud Neural TTS Ready:{' '}
                  <strong
                    className={
                      serverStatus?.voiceCapabilities?.cloudNeuralTtsReady
                        ? 'text-emerald-300'
                        : 'text-zinc-400'
                    }
                  >
                    {serverStatus?.voiceCapabilities?.cloudNeuralTtsReady ? 'Yes (24kHz WAV)' : 'Browser Fallback Active'}
                  </strong>
                </div>
              </div>
            </div>
          </div>

          {/* Last Request Latency & Telemetry Summary */}
          {snapshot.lastTrace && (
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold text-zinc-200">
                  <Clock className="w-3.5 h-3.5 text-teal-400" />
                  <span>Last Communication Request Trace</span>
                  <span className="font-mono text-[11px] text-zinc-400">
                    ({snapshot.lastTrace.requestId})
                  </span>
                </div>
                <span
                  className={`text-[11px] px-2 py-0.5 rounded font-medium uppercase ${
                    snapshot.lastTrace.status === 'completed'
                      ? 'bg-emerald-500/15 text-emerald-300'
                      : snapshot.lastTrace.status === 'failed'
                      ? 'bg-red-500/15 text-red-300'
                      : 'bg-teal-500/15 text-teal-300'
                  }`}
                >
                  {snapshot.lastTrace.status}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                <div className="p-2.5 rounded-lg bg-black/30 border border-white/5">
                  <div className="text-[10px] text-zinc-400">Input Mode</div>
                  <div className="font-mono font-semibold text-white mt-0.5">
                    {snapshot.lastTrace.inputMode}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-black/30 border border-white/5">
                  <div className="text-[10px] text-zinc-400">Backend Ack</div>
                  <div className="font-mono font-semibold text-teal-300 mt-0.5">
                    {snapshot.lastTrace.backendAckMs !== undefined
                      ? `${snapshot.lastTrace.backendAckMs}ms`
                      : '—'}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-black/30 border border-white/5">
                  <div className="text-[10px] text-zinc-400">First Token (TTFT)</div>
                  <div className="font-mono font-semibold text-indigo-300 mt-0.5">
                    {snapshot.lastTrace.ttftMs !== undefined
                      ? `${snapshot.lastTrace.ttftMs}ms`
                      : '—'}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-black/30 border border-white/5">
                  <div className="text-[10px] text-zinc-400">Total Duration</div>
                  <div className="font-mono font-semibold text-white mt-0.5">
                    {snapshot.lastTrace.totalDurationMs !== undefined
                      ? `${snapshot.lastTrace.totalDurationMs}ms`
                      : 'In flight'}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-black/30 border border-white/5">
                  <div className="text-[10px] text-zinc-400">Model Executed</div>
                  <div className="font-mono font-semibold text-emerald-300 truncate mt-0.5">
                    {snapshot.lastTrace.model}
                  </div>
                </div>
              </div>

              {isPrivileged && snapshot.lastTrace.transitions.length > 0 && (
                <div className="pt-2 border-t border-white/5">
                  <div className="text-[11px] text-zinc-400 mb-1.5">
                    State Machine Transition Sequence (Owner/Admin Diagnostic View):
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {snapshot.lastTrace.transitions.map((tr, i) => (
                      <span
                        key={`${tr.state}-${i}`}
                        className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-zinc-300 border border-white/5"
                      >
                        {i + 1}. {tr.state}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Troubleshooting Guide */}
          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-zinc-200">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>Quick Troubleshooting & Recovery Guide</span>
            </div>
            <ul className="text-xs text-zinc-400 space-y-1.5 list-disc list-inside">
              <li>
                <strong className="text-zinc-200">Voice Dictation / Speech Recognition:</strong> You can dictate directly in the Chat composer using the Mic button, or use the <strong>Record Cloud Voice Clip</strong> button in Voice Mode which works across all browsers via Gemini 3.5 Transcribe.
              </li>
              <li>
                <strong className="text-zinc-200">Provider Fallback:</strong> If an Ollama Cloud model is selected while <code className="text-zinc-300">OLLAMA_API_KEY</code> is unconfigured, LORIN automatically falls back to Google Gemini (<code className="text-zinc-300">gemini-3.8-flash</code>) and labels the attribution truthfully.
              </li>
              <li>
                <strong className="text-zinc-200">Failed Messages:</strong> Any failed message in Chat preserves your prompt and displays an inline <strong>Retry</strong> action.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-white/10 bg-[#0F1522] flex items-center justify-between text-xs text-zinc-400">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Zero client-side secrets exposed • Server-enforced RBAC active</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
