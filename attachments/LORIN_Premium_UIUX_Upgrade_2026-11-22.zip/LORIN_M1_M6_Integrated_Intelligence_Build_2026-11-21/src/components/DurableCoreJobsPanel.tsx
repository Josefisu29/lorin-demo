import React, { useCallback, useEffect, useState } from 'react';
import { authFetch } from '../services/authHeaders';
import type { Principal } from '../types/lorin';

type CoreJobState = 'AWAITING_APPROVAL' | 'QUEUED' | 'RUNNING' | 'BLOCKED' | 'FAILED' | 'CANCELLED' | 'COMPLETED' | 'VERIFIED';
interface CoreJob {
  id: string; capabilityId: string; resource: string; state: CoreJobState;
  attempts: number; updatedAt: number; errorCode?: string; approvalId?: string; receipt?: unknown;
}
interface WorkerStatus { enabled: boolean; running: boolean; processedCount: number; lastErrorCode?: string; lastPollAt?: number; }

const stateClass: Record<CoreJobState, string> = {
  AWAITING_APPROVAL: 'text-amber-300 border-amber-400/30', QUEUED: 'text-sky-300 border-sky-400/30',
  RUNNING: 'text-teal-300 border-teal-400/30', BLOCKED: 'text-violet-300 border-violet-400/30',
  FAILED: 'text-rose-300 border-rose-400/30', CANCELLED: 'text-slate-400 border-slate-500/30',
  COMPLETED: 'text-blue-300 border-blue-400/30', VERIFIED: 'text-emerald-300 border-emerald-400/30'
};

export const DurableCoreJobsPanel: React.FC<{ principal: Principal }> = ({ principal }) => {
  const [jobs, setJobs] = useState<CoreJob[]>([]);
  const [worker, setWorker] = useState<WorkerStatus>({ enabled: false, running: false, processedCount: 0 });
  const [message, setMessage] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const isPrivileged = principal.canonicalRole === 'SYSTEM_OWNER' || principal.canonicalRole === 'SUPER_ADMIN' || principal.role === 'OWNER';

  const refresh = useCallback(async () => {
    try {
      const [jobResponse, workerResponse] = await Promise.all([
        authFetch('/api/core/jobs', { headers: { Accept: 'application/json' } }),
        isPrivileged ? authFetch('/api/core/worker/status', { headers: { Accept: 'application/json' } }) : Promise.resolve(null)
      ]);
      if (jobResponse.ok) {
        const body = await jobResponse.json();
        setJobs(Array.isArray(body?.jobs) ? body.jobs : []);
      }
      if (workerResponse?.ok) {
        const body = await workerResponse.json();
        if (body?.worker) setWorker(body.worker);
      }
    } catch {
      setMessage('The local durable job API is unavailable. Existing browser task records remain separate.');
    }
  }, [isPrivileged]);

  useEffect(() => {
    void refresh();
    const interval = window.setInterval(() => void refresh(), 5_000);
    return () => window.clearInterval(interval);
  }, [refresh]);

  const act = async (key: string, path: string, body?: unknown) => {
    setBusyId(key);
    setMessage('');
    try {
      const response = await authFetch(path, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        ...(body === undefined ? {} : { body: JSON.stringify(body) })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result?.error || `Request failed: HTTP ${response.status}`);
      setMessage('Request accepted. Job state will refresh from the server.');
      await refresh();
    } catch (error: any) {
      setMessage(error?.message || 'The requested action failed.');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <section className="rounded-xl bg-[#111821] border border-[#283544] p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-bold text-white">Server-backed capability jobs</h2>
          <p className="text-[11px] text-[#A2AFBF] mt-1">Separate from browser task plans. Jobs are executed only by registered local capabilities.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={`px-2 py-1 rounded border text-[10px] font-mono ${worker.running ? 'text-emerald-300 border-emerald-400/30' : 'text-slate-400 border-slate-500/30'}`}>
            Worker {worker.running ? 'RUNNING' : worker.enabled ? 'STOPPED' : 'DISABLED'}
          </span>
          {isPrivileged && worker.enabled && (
            worker.running
              ? <button disabled={Boolean(busyId)} onClick={() => void act('worker-stop', '/api/core/worker/stop')} className="px-2.5 py-1 rounded bg-[#17212C] border border-[#3A4B5F] text-xs text-white disabled:opacity-40">Stop worker</button>
              : <button disabled={Boolean(busyId)} onClick={() => void act('worker-start', '/api/core/worker/start')} className="px-2.5 py-1 rounded bg-[#66E3CB] text-slate-950 text-xs font-bold disabled:opacity-40">Start worker</button>
          )}
          <button onClick={() => void refresh()} className="px-2.5 py-1 rounded bg-[#17212C] border border-[#3A4B5F] text-xs text-white">Refresh</button>
        </div>
      </div>
      {message && <p role="status" className="text-xs text-[#A9B8FF]">{message}</p>}
      {jobs.length === 0 ? <p className="text-xs text-[#738297] py-3">No server-backed jobs have been submitted.</p> : (
        <div className="space-y-2">
          {jobs.slice(0, 20).map(job => (
            <div key={job.id} className="rounded-lg border border-[#283544] bg-[#0B0F14] p-3 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs text-white font-semibold break-all">{job.capabilityId}</p>
                  <p className="text-[10px] text-[#738297] break-all">{job.resource} · Attempts {job.attempts}</p>
                </div>
                <span className={`rounded border px-2 py-0.5 text-[10px] font-mono ${stateClass[job.state]}`}>{job.state}</span>
              </div>
              {job.errorCode && <p className="text-[10px] text-rose-300">{job.errorCode}</p>}
              <div className="flex flex-wrap gap-2">
                {job.state === 'AWAITING_APPROVAL' && job.approvalId && isPrivileged && <button disabled={Boolean(busyId)} onClick={() => void act(job.id, `/api/core/jobs/${encodeURIComponent(job.id)}/approve`, { approvalId: job.approvalId })} className="text-[10px] px-2 py-1 rounded bg-amber-400 text-slate-950 font-bold disabled:opacity-40">Approve</button>}
                {['QUEUED', 'AWAITING_APPROVAL', 'FAILED', 'BLOCKED'].includes(job.state) && <button disabled={Boolean(busyId)} onClick={() => void act(job.id, `/api/core/jobs/${encodeURIComponent(job.id)}/cancel`)} className="text-[10px] px-2 py-1 rounded border border-rose-400/30 text-rose-300 disabled:opacity-40">Cancel</button>}
                {['FAILED', 'BLOCKED'].includes(job.state) && <button disabled={Boolean(busyId)} onClick={() => void act(job.id, `/api/core/jobs/${encodeURIComponent(job.id)}/retry`)} className="text-[10px] px-2 py-1 rounded border border-sky-400/30 text-sky-300 disabled:opacity-40">Retry</button>}
                {job.state === 'COMPLETED' && <button disabled={Boolean(busyId)} onClick={() => void act(job.id, `/api/core/jobs/${encodeURIComponent(job.id)}/verify`)} className="text-[10px] px-2 py-1 rounded border border-emerald-400/30 text-emerald-300 disabled:opacity-40">Verify result</button>}
              </div>
              <p className="text-[10px] text-[#526174]">Updated {new Date(job.updatedAt).toLocaleString()}</p>
            </div>
          ))}
        </div>
      )}
      <p className="text-[10px] text-[#738297]">Worker starts only when the trusted local host has LORIN_ENABLE_CORE_WORKER=true. Stop prevents new claims; an in-flight action completes or times out under its registered capability limit.</p>
    </section>
  );
};
