import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  X, 
  MessageSquare, 
  Pin, 
  BookOpen, 
  Archive, 
  ArrowRight, 
  Copy, 
  Check, 
  ExternalLink, 
  Sparkles, 
  CornerDownRight, 
  Tag, 
  Clock, 
  FileText 
} from 'lucide-react';
import { ChatMessage, VaultDocument, WorkspaceView } from '../types/lorin';
import { VaultStore } from '../services/vaultStore';

export type SearchCategory = 'ALL' | 'CHAT' | 'PINNED' | 'VAULT' | 'ARCHIVED';

export interface GlobalSearchResult {
  id: string;
  category: 'CHAT' | 'PINNED' | 'VAULT' | 'ARCHIVED';
  title: string;
  snippet: string;
  timestamp?: number;
  metadata?: {
    role?: 'user' | 'assistant';
    docType?: string;
    collection?: string;
    status?: string;
    score?: number;
  };
  originalItem: ChatMessage | VaultDocument;
}

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  pinnedMessages: ChatMessage[];
  onNavigateToView: (view: WorkspaceView) => void;
  onJumpToMessage?: (messageId: string) => void;
  onOpenArchivedModal?: () => void;
}

const QUICK_SUGGESTIONS = [
  "Zero-trust RBAC and action digests",
  "Web Audio DSP noise cancellation",
  "Offline knowledge vault spec",
  "Phase 2 Security Gate",
  "Ollama local inference",
  "Relational zero-downtime schema evolution"
];

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  messages,
  pinnedMessages,
  onNavigateToView,
  onJumpToMessage,
  onOpenArchivedModal,
}) => {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<SearchCategory>('ALL');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);
  const resultsContainerRef = useRef<HTMLDivElement>(null);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  // Aggregate results across Chat History, Pinned Messages, Knowledge Vault, and Archived Reports
  const results: GlobalSearchResult[] = useMemo(() => {
    if (!query.trim()) return [];

    const lower = query.toLowerCase();
    const items: GlobalSearchResult[] = [];

    // 1. Pinned Messages Search
    pinnedMessages.forEach((pm) => {
      if (pm.content.toLowerCase().includes(lower)) {
        items.push({
          id: `pinned_${pm.id}`,
          category: 'PINNED',
          title: pm.role === 'user' ? 'Pinned User Directive' : 'Pinned Synthesis Context',
          snippet: pm.content,
          timestamp: pm.timestamp,
          metadata: {
            role: pm.role,
            status: 'PINNED'
          },
          originalItem: pm
        });
      }
    });

    // 2. Chat History Search (active messages, non-archived or regular messages)
    messages.forEach((msg) => {
      const isArchived = msg.isArchived || msg.completionReport?.isArchived;
      const contentMatches = msg.content.toLowerCase().includes(lower);
      const objectiveMatches = msg.completionReport?.objective.toLowerCase().includes(lower);
      const evidenceMatches = msg.completionReport?.verification.evidence.toLowerCase().includes(lower);

      if (isArchived) {
        if (contentMatches || objectiveMatches || evidenceMatches) {
          items.push({
            id: `archived_${msg.id}`,
            category: 'ARCHIVED',
            title: msg.completionReport?.objective || 'Archived Completion Report',
            snippet: msg.completionReport?.verification.evidence || msg.content,
            timestamp: msg.archivedAt || msg.timestamp,
            metadata: {
              role: msg.role,
              status: msg.completionReport?.status || 'ARCHIVED'
            },
            originalItem: msg
          });
        }
      } else if (contentMatches || objectiveMatches || evidenceMatches) {
        items.push({
          id: `chat_${msg.id}`,
          category: 'CHAT',
          title: msg.completionReport 
            ? `Report: ${msg.completionReport.objective}` 
            : msg.role === 'user' ? 'User Message' : 'LORIN Synthesis',
          snippet: msg.content,
          timestamp: msg.timestamp,
          metadata: {
            role: msg.role,
            status: msg.completionReport?.status
          },
          originalItem: msg
        });
      }
    });

    // 3. Knowledge Vault Search (via VaultStore query)
    const vaultHits = VaultStore.search(query);
    vaultHits.forEach((hit) => {
      items.push({
        id: `vault_${hit.document.id}_${hit.chunkIndex}`,
        category: 'VAULT',
        title: hit.document.title,
        snippet: hit.snippet,
        timestamp: hit.document.importedAt,
        metadata: {
          docType: hit.document.fileType,
          collection: hit.document.collection,
          score: hit.score
        },
        originalItem: hit.document
      });
    });

    return items;
  }, [query, messages, pinnedMessages]);

  // Filtered by selected category tab
  const filteredResults = useMemo(() => {
    if (activeCategory === 'ALL') return results;
    return results.filter((r) => r.category === activeCategory);
  }, [results, activeCategory]);

  // Category counts
  const counts = useMemo(() => {
    const c = {
      ALL: results.length,
      CHAT: 0,
      PINNED: 0,
      VAULT: 0,
      ARCHIVED: 0
    };
    results.forEach((r) => {
      c[r.category] = (c[r.category] || 0) + 1;
    });
    return c;
  }, [results]);

  // Keyboard navigation inside list
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev < filteredResults.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const current = filteredResults[selectedIndex];
      if (current) {
        handleSelectItem(current);
      }
    }
  };

  const handleSelectItem = (item: GlobalSearchResult) => {
    if (item.category === 'VAULT') {
      onNavigateToView('vault');
      onClose();
    } else if (item.category === 'ARCHIVED') {
      if (onOpenArchivedModal) {
        onClose();
        onOpenArchivedModal();
      } else {
        onNavigateToView('chat');
        onClose();
      }
    } else {
      // CHAT or PINNED
      onNavigateToView('chat');
      if (onJumpToMessage && 'id' in item.originalItem) {
        onJumpToMessage(item.originalItem.id);
      }
      onClose();
    }
  };

  const handleCopySnippet = (snippet: string, id: string) => {
    navigator.clipboard.writeText(snippet);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Highlight matched terms in text snippet
  const highlightMatches = (text: string, searchTerm: string) => {
    if (!searchTerm.trim()) return text;
    const parts = text.split(new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === searchTerm.toLowerCase() ? (
        <mark key={i} className="bg-[#66E3CB]/25 text-[#66E3CB] font-bold rounded-xs px-0.5">
          {part}
        </mark>
      ) : (
        part
      )
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-20 p-4 bg-black/80 backdrop-blur-xs select-none"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-2xl max-h-[80vh] rounded-2xl bg-[#111821] border border-[#283544] shadow-2xl flex flex-col overflow-hidden text-[#F1F5F9]"
            onClick={(e) => e.stopPropagation()}
            onKeyDown={handleKeyDown}
          >
        {/* Search Input Box */}
        <div className="p-3.5 sm:p-4 border-b border-[#283544] flex items-center gap-3 bg-[#17212C]">
          <Search className="w-5 h-5 text-[#66E3CB] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Search across Chat History, Pinned Context, Knowledge Vault & Archive..."
            className="w-full bg-transparent text-sm text-white placeholder-[#738297] focus:outline-none font-sans"
          />
          {query ? (
            <button
              onClick={() => {
                setQuery('');
                setSelectedIndex(0);
              }}
              className="p-1 rounded text-[#738297] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0B0F14] text-[#738297] border border-[#283544] shrink-0">
              ESC to exit
            </span>
          )}
        </div>

        {/* Category Tabs */}
        {query && (
          <div className="px-4 py-2 bg-[#0B0F14]/70 border-b border-[#283544] flex items-center gap-2 overflow-x-auto text-xs font-mono">
            <button
              onClick={() => setActiveCategory('ALL')}
              className={`px-2.5 py-1 rounded-lg border transition-colors whitespace-nowrap ${
                activeCategory === 'ALL'
                  ? 'bg-[#17212C] text-[#66E3CB] border-[#66E3CB]/40'
                  : 'text-[#738297] hover:text-white border-transparent'
              }`}
            >
              All ({counts.ALL})
            </button>
            <button
              onClick={() => setActiveCategory('CHAT')}
              className={`px-2.5 py-1 rounded-lg border transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeCategory === 'CHAT'
                  ? 'bg-[#17212C] text-[#66E3CB] border-[#66E3CB]/40'
                  : 'text-[#738297] hover:text-white border-transparent'
              }`}
            >
              <MessageSquare className="w-3 h-3" />
              <span>Chat ({counts.CHAT})</span>
            </button>
            <button
              onClick={() => setActiveCategory('PINNED')}
              className={`px-2.5 py-1 rounded-lg border transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeCategory === 'PINNED'
                  ? 'bg-[#17212C] text-[#66E3CB] border-[#66E3CB]/40'
                  : 'text-[#738297] hover:text-white border-transparent'
              }`}
            >
              <Pin className="w-3 h-3" />
              <span>Pinned ({counts.PINNED})</span>
            </button>
            <button
              onClick={() => setActiveCategory('VAULT')}
              className={`px-2.5 py-1 rounded-lg border transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeCategory === 'VAULT'
                  ? 'bg-[#17212C] text-[#66E3CB] border-[#66E3CB]/40'
                  : 'text-[#738297] hover:text-white border-transparent'
              }`}
            >
              <BookOpen className="w-3 h-3" />
              <span>Vault ({counts.VAULT})</span>
            </button>
            <button
              onClick={() => setActiveCategory('ARCHIVED')}
              className={`px-2.5 py-1 rounded-lg border transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeCategory === 'ARCHIVED'
                  ? 'bg-[#17212C] text-[#66E3CB] border-[#66E3CB]/40'
                  : 'text-[#738297] hover:text-white border-transparent'
              }`}
            >
              <Archive className="w-3 h-3" />
              <span>Archived ({counts.ARCHIVED})</span>
            </button>
          </div>
        )}

        {/* Results List */}
        <div ref={resultsContainerRef} className="flex-1 overflow-y-auto p-3 space-y-2">
          {!query.trim() ? (
            /* Suggested Queries State */
            <div className="py-6 px-3 space-y-4">
              <div className="text-[11px] font-mono text-[#738297] uppercase tracking-wider">
                Quick Search Suggestions
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {QUICK_SUGGESTIONS.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setQuery(s);
                      setSelectedIndex(0);
                    }}
                    className="p-2.5 rounded-xl bg-[#17212C] border border-[#283544] hover:border-[#3A4B5F] text-left text-xs text-[#F1F5F9] hover:bg-[#1f2b38] transition-all flex items-center justify-between group"
                  >
                    <span className="truncate">{s}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#66E3CB] opacity-0 group-hover:opacity-100 transition-opacity shrink-0 ml-1" />
                  </button>
                ))}
              </div>

              <div className="pt-3 border-t border-[#283544] flex items-center justify-between text-[11px] font-mono text-[#738297]">
                <span>Navigation shortcut</span>
                <span className="text-[#A2AFBF]">Press ⌘K or Ctrl+K anywhere</span>
              </div>
            </div>
          ) : filteredResults.length === 0 ? (
            /* No Results Found */
            <div className="py-12 text-center space-y-2">
              <div className="w-10 h-10 rounded-xl bg-[#17212C] border border-[#283544] flex items-center justify-center text-[#738297] mx-auto">
                <Search className="w-5 h-5" />
              </div>
              <div className="text-sm font-semibold text-white">No results found</div>
              <p className="text-xs text-[#A2AFBF] max-w-sm mx-auto">
                No matching messages, pinned context, vault documents, or archived tasks for "{query}".
              </p>
            </div>
          ) : (
            /* Search Result Cards */
            filteredResults.map((item, idx) => {
              const isSelected = selectedIndex === idx;
              const isCopied = copiedId === item.id;

              return (
                <div
                  key={item.id}
                  onClick={() => handleSelectItem(item)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer space-y-1.5 ${
                    isSelected
                      ? 'bg-[#17212C] border-[#66E3CB]/60 shadow-md'
                      : 'bg-[#111821] hover:bg-[#151E28] border-[#283544]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 overflow-hidden">
                      {item.category === 'PINNED' && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 flex items-center gap-1 shrink-0">
                          <Pin className="w-3 h-3 fill-current" />
                          <span>PINNED</span>
                        </span>
                      )}

                      {item.category === 'VAULT' && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#66E3CB]/10 text-[#66E3CB] border border-[#66E3CB]/30 flex items-center gap-1 shrink-0">
                          <BookOpen className="w-3 h-3" />
                          <span>VAULT</span>
                        </span>
                      )}

                      {item.category === 'CHAT' && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#A9B8FF]/10 text-[#A9B8FF] border border-[#A9B8FF]/30 flex items-center gap-1 shrink-0">
                          <MessageSquare className="w-3 h-3" />
                          <span>CHAT</span>
                        </span>
                      )}

                      {item.category === 'ARCHIVED' && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#738297]/20 text-[#A2AFBF] border border-[#738297]/30 flex items-center gap-1 shrink-0">
                          <Archive className="w-3 h-3" />
                          <span>ARCHIVE</span>
                        </span>
                      )}

                      <h4 className="text-xs font-bold text-white truncate">
                        {item.title}
                      </h4>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => handleCopySnippet(item.snippet, item.id)}
                        className="p-1 rounded hover:bg-[#283544] text-[#738297] hover:text-white transition-colors"
                        title="Copy excerpt"
                      >
                        {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                      <button
                        onClick={() => handleSelectItem(item)}
                        className="p-1 rounded hover:bg-[#283544] text-[#738297] hover:text-[#66E3CB] transition-colors"
                        title="Navigate to item"
                      >
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-[#A2AFBF] font-sans leading-relaxed line-clamp-2 select-text">
                    {highlightMatches(item.snippet.slice(0, 240), query)}
                  </p>

                  <div className="flex items-center justify-between text-[10px] font-mono text-[#738297] pt-1 border-t border-[#283544]/50">
                    <div className="flex items-center gap-2">
                      {item.metadata?.collection && (
                        <span>Collection: {item.metadata.collection}</span>
                      )}
                      {item.metadata?.status && (
                        <span className="text-[#66E3CB]">{item.metadata.status}</span>
                      )}
                    </div>
                    {item.timestamp && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" />
                        <span>{new Date(item.timestamp).toLocaleDateString()}</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Shortcut Bar */}
        <div className="p-2.5 px-4 bg-[#17212C] border-t border-[#283544] flex items-center justify-between text-[11px] font-mono text-[#738297]">
          <div className="flex items-center gap-3">
            <span><strong className="text-[#A2AFBF]">↑↓</strong> to navigate</span>
            <span><strong className="text-[#A2AFBF]">↵</strong> to select</span>
            <span><strong className="text-[#A2AFBF]">ESC</strong> to close</span>
          </div>
          <span>{filteredResults.length} matches</span>
        </div>
      </motion.div>
    </motion.div>
  )}
</AnimatePresence>
  );
};
