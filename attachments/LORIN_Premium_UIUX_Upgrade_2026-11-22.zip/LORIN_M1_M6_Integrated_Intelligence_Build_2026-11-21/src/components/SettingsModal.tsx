import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Settings, 
  Cpu, 
  Radio, 
  ShieldCheck, 
  Mic, 
  Video, 
  Volume2, 
  RefreshCw, 
  AlertCircle, 
  CheckCircle,
  ExternalLink,
  Database,
  LogIn,
  LogOut,
  Server,
  EyeOff,
  Eye,
  Key,
  Plus,
  Trash2,
  Lock,
  Sun,
  Moon
} from 'lucide-react';
import { LorinProfileConfig, Principal } from '../types/lorin';
import { StealthService } from '../services/stealthService';
import { OllamaService, OllamaStatus, RECOMMENDED_LOCAL_MODEL_CANDIDATES } from '../services/ollamaService';
import { AudioService } from '../services/audioService';
import { VideoService } from '../services/videoService';
import { 
  auth, 
  signInWithGooglePopup, 
  signOutFirebaseUser, 
  testFirestoreConnection,
  resolvedFirebaseConfig as activeFirebaseConfig
} from '../services/firebase';
import {
  CloudPrivacyGate,
  DeterministicMockBackend,
  LiveGeminiBackend,
  OllamaLocalBackend,
  ProviderHealthStatus,
  RoutingStrategy
} from '../services/modelBackend';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  principal: Principal;
  backendMode: RoutingStrategy;
  setBackendMode: (mode: RoutingStrategy) => void;
  profileConfig?: LorinProfileConfig;
  onUpdateProfileConfig?: (partial: Partial<LorinProfileConfig>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  principal,
  backendMode,
  setBackendMode,
  profileConfig,
  onUpdateProfileConfig,
}) => {
  const [ollamaEndpoint, setOllamaEndpoint] = useState(OllamaService.getEndpoint());
  const [selectedOllamaModel, setSelectedOllamaModel] = useState(OllamaService.getSelectedModel());
  const [ollamaStatus, setOllamaStatus] = useState<OllamaStatus | null>(null);
  const [isProbingOllama, setIsProbingOllama] = useState(false);
  const [dbStatus, setDbStatus] = useState<{ connected: boolean; checking: boolean }>({
    connected: true,
    checking: false
  });
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [providerHealth, setProviderHealth] = useState<ProviderHealthStatus | null>(null);
  const [isHealthChecking, setIsHealthChecking] = useState(false);
  const [isStealth, setIsStealth] = useState(StealthService.isStealthEnabled());
  const [cloudContextPermitted, setCloudContextPermitted] = useState(CloudPrivacyGate.isCloudContextPermitted());
  const [ownerEmails, setOwnerEmails] = useState<string[]>([]);
  const [primaryOwner, setPrimaryOwner] = useState('');
  const [newOwnerEmail, setNewOwnerEmail] = useState('');
  const [emailStatus, setEmailStatus] = useState<string | null>(null);

  const toggleStealth = () => {
    const next = !isStealth;
    setIsStealth(next);
    StealthService.setStealthMode(next);
  };

  const toggleCloudContextPermission = () => {
    const next = !cloudContextPermitted;
    setCloudContextPermitted(next);
    CloudPrivacyGate.setCloudContextPermitted(next);
  };

  const fetchOwnerEmails = async () => {
    try {
      const user = auth.currentUser;
      if (!user) return;
      const idToken = await user.getIdToken();
      const res = await fetch('/api/owner/emails', {
        headers: { Authorization: `Bearer ${idToken}` }
      });
      if (res.ok) {
        const data = await res.json();
        setOwnerEmails(data.emails || []);
        setPrimaryOwner(data.primaryOwner || '');
      }
    } catch {}
  };

  useEffect(() => {
    if (isOpen && principal.role === 'OWNER') {
      fetchOwnerEmails();
    }
  }, [isOpen, principal.role]);

  const handleAddEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOwnerEmail.includes('@')) return;
    try {
      const user = auth.currentUser;
      if (!user) return;
      const idToken = await user.getIdToken();
      const res = await fetch('/api/owner/emails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`
        },
        body: JSON.stringify({ email: newOwnerEmail.trim().toLowerCase() })
      });
      if (res.ok) {
        const data = await res.json();
        setOwnerEmails(data.emails || []);
        setNewOwnerEmail('');
        setEmailStatus('Owner email authorized successfully.');
        setTimeout(() => setEmailStatus(null), 3000);
      }
    } catch {}
  };

  const handleRemoveEmail = async (email: string) => {
    try {
      const user = auth.currentUser;
      if (!user) return;
      const idToken = await user.getIdToken();
      const res = await fetch('/api/owner/emails', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`
        },
        body: JSON.stringify({ email })
      });
      if (res.ok) {
        const data = await res.json();
        setOwnerEmails(data.emails || []);
      }
    } catch {}
  };

  const checkProviderHealth = async () => {
    setIsHealthChecking(true);
    const backend =
      backendMode === 'OLLAMA_LOCAL'
        ? new OllamaLocalBackend()
        : backendMode === 'DETERMINISTIC_MOCK'
        ? new DeterministicMockBackend()
        : new LiveGeminiBackend();
    const status = await backend.healthCheck();
    setProviderHealth(status);
    setIsHealthChecking(false);
  };

  useEffect(() => {
    if (isOpen) {
      checkDb();
      checkProviderHealth();
    }
  }, [isOpen]);

  const checkDb = async () => {
    setDbStatus({ connected: false, checking: true });
    const res = await testFirestoreConnection();
    setDbStatus({ connected: res.connected, checking: false });
  };

  const handleSignInGoogle = async () => {
    setIsAuthLoading(true);
    try {
      await signInWithGooglePopup();
    } catch (e: any) {
      console.warn('Google sign in error:', e);
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    setIsAuthLoading(true);
    try {
      await signOutFirebaseUser();
    } catch (e: any) {
      console.warn('Google sign out error:', e);
    } finally {
      setIsAuthLoading(false);
    }
  };

  if (!isOpen) return null;

  const handleProbeOllama = async () => {
    setIsProbingOllama(true);
    OllamaService.setEndpoint(ollamaEndpoint);
    const status = await OllamaService.checkStatus();
    setOllamaStatus(status);
    setIsProbingOllama(false);
  };

  const sttSupported = AudioService.isSpeechRecognitionSupported();
  const ttsSupported = AudioService.isSpeechSynthesisSupported();
  const camSupported = VideoService.isCameraSupported();

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-xl bg-[#111821] border border-[#3A4B5F] rounded-2xl p-6 space-y-5 text-xs shadow-2xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <div className="flex items-center gap-2">
                <Settings className="w-4 h-4 text-[#66E3CB]" />
                <h2 className="text-sm font-bold text-white tracking-tight">System Configuration & Live Connections</h2>
              </div>
              <button onClick={onClose} className="text-[#738297] hover:text-white text-sm cursor-pointer">✕</button>
            </div>

        {/* Section 1: Live Cloud Database Connection (Firebase Firestore) */}
        <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-3 font-mono">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-[#66E3CB]" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Live Cloud Database (Firestore)
              </span>
            </div>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
              dbStatus.connected 
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
            }`}>
              {dbStatus.checking ? 'PROBING...' : activeFirebaseConfig.projectId?.startsWith('SET_') || activeFirebaseConfig.apiKey?.startsWith('SET_') ? 'NOT CONFIGURED' : dbStatus.connected ? 'CONNECTED' : 'DISCONNECTED'}
            </span>
          </div>

          <div className="bg-[#111821] p-3 rounded-lg border border-[#283544] space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between text-[#A2AFBF]">
              <span>Project ID:</span>
              <span className="text-white font-bold">{activeFirebaseConfig.projectId?.startsWith('SET_') ? 'NOT CONFIGURED' : activeFirebaseConfig.projectId}</span>
            </div>
            <div className="flex items-center justify-between text-[#A2AFBF]">
              <span>Firestore Database:</span>
              <span className="text-[#66E3CB] font-semibold truncate max-w-[260px]">
                {activeFirebaseConfig.firestoreDatabaseId}
              </span>
            </div>
            <div className="flex items-center justify-between text-[#738297]">
              <span>Persistence Scope:</span>
              <span>Messages • Vault Documents • Security Audits</span>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={checkDb}
              disabled={dbStatus.checking || Boolean(activeFirebaseConfig.projectId?.startsWith('SET_') || activeFirebaseConfig.apiKey?.startsWith('SET_'))}
              className="px-3 py-1.5 rounded-lg bg-[#283544] hover:bg-[#3A4B5F] text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${dbStatus.checking ? 'animate-spin' : ''}`} />
              <span>{activeFirebaseConfig.projectId?.startsWith('SET_') || activeFirebaseConfig.apiKey?.startsWith('SET_') ? 'Configure Firebase First' : 'Verify DB Ping'}</span>
            </button>

            {auth.currentUser ? (
              <button
                onClick={handleSignOut}
                disabled={isAuthLoading}
                className="px-3 py-1.5 rounded-lg bg-rose-950/40 border border-rose-500/40 text-rose-300 hover:bg-rose-900/50 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out ({auth.currentUser.displayName || auth.currentUser.email})</span>
              </button>
            ) : (
              <button
                onClick={handleSignInGoogle}
                disabled={isAuthLoading}
                className="px-3 py-1.5 rounded-lg bg-[#66E3CB] text-slate-950 font-bold hover:bg-[#52d6be] flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In via Google Firebase</span>
              </button>
            )}
          </div>
        </div>

        {/* Section 2: Active Model Inference Backend with Explicit HEALTH_CHECK */}
        <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-3 font-mono">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Model Inference Provider
            </span>
            <button
              onClick={checkProviderHealth}
              disabled={isHealthChecking}
              className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#111821] text-[#66E3CB] border border-[#66E3CB]/30 hover:border-[#66E3CB] flex items-center gap-1 transition-colors cursor-pointer"
              title="Actively probe model provider connectivity"
            >
              <RefreshCw className={`w-3 h-3 ${isHealthChecking ? 'animate-spin' : ''}`} />
              <span>{isHealthChecking ? 'PROBING...' : 'HEALTH_CHECK'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              onClick={() => {
                setBackendMode('LIVE_GEMINI');
                new LiveGeminiBackend().healthCheck().then(setProviderHealth);
              }}
              className={`p-3 rounded-lg border text-left font-mono transition-colors cursor-pointer ${
                backendMode === 'LIVE_GEMINI'
                  ? 'bg-[#111821] border-[#66E3CB] text-[#66E3CB]'
                  : 'bg-[#151E28] border-[#283544] text-[#A2AFBF]'
              }`}
            >
              <div className="font-bold text-xs text-white">LORIN Cloud Gateway</div>
              <div className="text-[10px] text-[#738297] mt-1">Server Proxy • Primary Reasoning Tier</div>
            </button>

            <button
              onClick={() => {
                setBackendMode('LOCAL_FIRST_WITH_CLOUD_FALLBACK');
                new OllamaLocalBackend().healthCheck().then(setProviderHealth);
              }}
              className={`p-3 rounded-lg border text-left font-mono transition-colors cursor-pointer ${
                backendMode === 'LOCAL_FIRST_WITH_CLOUD_FALLBACK'
                  ? 'bg-[#111821] border-[#66E3CB] text-[#66E3CB]'
                  : 'bg-[#151E28] border-[#283544] text-[#A2AFBF]'
              }`}
            >
              <div className="font-bold text-xs text-white">Local-First with Cloud Fallback</div>
              <div className="text-[10px] text-[#738297] mt-1">Ollama local primary • Cloud fallback</div>
            </button>

            <button
              onClick={() => {
                setBackendMode('DUAL_TASK_COMPLEXITY');
                new LiveGeminiBackend().healthCheck().then(setProviderHealth);
              }}
              className={`p-3 rounded-lg border text-left font-mono transition-colors cursor-pointer ${
                backendMode === 'DUAL_TASK_COMPLEXITY'
                  ? 'bg-[#111821] border-[#66E3CB] text-[#66E3CB]'
                  : 'bg-[#151E28] border-[#283544] text-[#A2AFBF]'
              }`}
            >
              <div className="font-bold text-xs text-white">Dual Complexity Router</div>
              <div className="text-[10px] text-[#738297] mt-1">Auto-routes routine vs complex tasks</div>
            </button>

            <button
              onClick={() => {
                setBackendMode('OLLAMA_LOCAL');
                new OllamaLocalBackend().healthCheck().then(setProviderHealth);
              }}
              className={`p-3 rounded-lg border text-left font-mono transition-colors cursor-pointer ${
                backendMode === 'OLLAMA_LOCAL'
                  ? 'bg-[#111821] border-[#E8BE78] text-[#E8BE78]'
                  : 'bg-[#151E28] border-[#283544] text-[#A2AFBF]'
              }`}
            >
              <div className="font-bold text-xs text-white">Ollama Local (Strict)</div>
              <div className="text-[10px] text-[#738297] mt-1">Air-Gapped Daemon • Port 11434</div>
            </button>

            <button
              onClick={() => {
                setBackendMode('DETERMINISTIC_MOCK');
                new DeterministicMockBackend().healthCheck().then(setProviderHealth);
              }}
              className={`p-3 rounded-lg border text-left font-mono transition-colors cursor-pointer sm:col-span-2 ${
                backendMode === 'DETERMINISTIC_MOCK'
                  ? 'bg-[#111821] border-[#A9B8FF] text-[#A9B8FF]'
                  : 'bg-[#151E28] border-[#283544] text-[#A2AFBF]'
              }`}
            >
              <div className="font-bold text-xs text-white">Deterministic Verification Engine</div>
              <div className="text-[10px] text-[#738297] mt-1">Offline Rule-Based Synthesis • Zero Cloud Calls</div>
            </button>
          </div>

          {/* Cloud Context Privacy Boundary Control (Part 8) */}
          <div className="p-3 rounded-lg bg-[#111821] border border-[#283544] flex items-center justify-between gap-3">
            <div>
              <div className="text-white font-bold text-[11px] flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-[#66E3CB]" />
                <span>Private Vault & Memory Cloud Transmission</span>
              </div>
              <p className="text-[10px] text-[#A2AFBF] font-sans mt-0.5">
                {cloudContextPermitted
                  ? 'Authorized: Sanitized Knowledge Vault & Memory snippets may be sent to the server-side Cloud Gateway.'
                  : 'Air-Gapped: Private Vault & Memory snippets are strictly blocked from cloud transmission.'}
              </p>
            </div>
            <button
              type="button"
              onClick={toggleCloudContextPermission}
              className={`px-3 py-1 rounded text-[10px] font-bold border shrink-0 cursor-pointer transition-colors ${
                cloudContextPermitted
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
              }`}
            >
              {cloudContextPermitted ? 'CLOUD PERMITTED' : 'LOCAL ONLY'}
            </button>
          </div>

          {/* Real-time Health Check Status Readout */}
          {providerHealth && (
            <div className={`p-3 rounded-lg border text-[11px] space-y-1 ${
              providerHealth.healthy
                ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                : 'bg-amber-950/20 border-amber-500/40 text-amber-200'
            }`}>
              <div className="flex items-center justify-between font-bold">
                <span className="flex items-center gap-1.5">
                  {providerHealth.healthy ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <AlertCircle className="w-3.5 h-3.5 text-amber-400" />}
                  <span>{providerHealth.provider} Connection Status</span>
                </span>
                <span>{providerHealth.latencyMs}ms</span>
              </div>
              <p className="text-[11px] text-[#A2AFBF] font-sans">{providerHealth.message}</p>
            </div>
          )}
        </div>

        {/* Section 3: Ollama Local-First Diagnostic Prober & Candidate Model Strategy */}
        <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-3 font-mono">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Local Ollama Endpoint & Model Candidates
            </span>
            <span className="text-[10px] text-[#66E3CB]">Port 11434 • Local-First</span>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={ollamaEndpoint}
              onChange={(e) => setOllamaEndpoint(e.target.value)}
              className="flex-1 bg-[#111821] border border-[#283544] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#66E3CB]"
            />
            <button
              onClick={handleProbeOllama}
              disabled={isProbingOllama}
              className="px-3 py-2 rounded-lg bg-[#283544] hover:bg-[#3A4B5F] text-xs text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isProbingOllama ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Radio className="w-3.5 h-3.5" />}
              <span>Test Ping</span>
            </button>
          </div>

          {/* Local Model Candidate Selector */}
          <div className="space-y-1.5">
            <label className="block text-[10px] uppercase tracking-wider text-[#A2AFBF]">
              Target Local Ollama Model Candidate
            </label>
            <select
              value={selectedOllamaModel}
              onChange={(e) => {
                setSelectedOllamaModel(e.target.value);
                OllamaService.setSelectedModel(e.target.value);
              }}
              className="w-full bg-[#111821] border border-[#283544] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#66E3CB]"
            >
              {RECOMMENDED_LOCAL_MODEL_CANDIDATES.map((cand) => (
                <option key={cand.tag} value={cand.tag} className="bg-[#111821] text-white">
                  {cand.name} — {cand.role} ({cand.minRamGb}GB+ RAM)
                </option>
              ))}
              {ollamaStatus?.models
                ?.filter((m) => !RECOMMENDED_LOCAL_MODEL_CANDIDATES.some((c) => c.tag === m))
                .map((m) => (
                  <option key={m} value={m} className="bg-[#111821] text-[#66E3CB]">
                    {m} (Discovered Local Tag)
                  </option>
                ))}
            </select>
          </div>

          {ollamaStatus && (
            <div className={`p-3 rounded-lg border text-[11px] space-y-1.5 ${
              ollamaStatus.reachable
                ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                : 'bg-amber-950/20 border-amber-500/40 text-amber-200'
            }`}>
              <div className="flex items-center justify-between gap-2 font-bold">
                <span className="flex items-center gap-1.5">
                  {ollamaStatus.reachable ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-amber-400" />}
                  <span>{ollamaStatus.reachable ? 'Ollama Daemon Responding' : 'Local Connection Notice'}</span>
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#111821] border border-[#283544] text-[#66E3CB]">
                  Stage: {ollamaStatus.stage}
                </span>
              </div>
              <p className="text-[11px] leading-relaxed text-[#A2AFBF] font-sans">{ollamaStatus.message}</p>
            </div>
          )}
        </div>

        {/* Section 3B: Workspace Appearance Theme (Dark / Light Mode) */}
        {profileConfig && onUpdateProfileConfig && (
          <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] flex items-center justify-between gap-3 font-mono">
            <div>
              <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                {profileConfig.themeMode === 'light' ? (
                  <Sun className="w-4 h-4 text-amber-400" />
                ) : (
                  <Moon className="w-4 h-4 text-[#66E3CB]" />
                )}
                <span>Workspace Appearance Theme</span>
              </div>
              <p className="text-[11px] text-[#A2AFBF] font-sans mt-0.5">
                Switch between High-Contrast Slate Dark Mode (#0B0F14) and Daylight Engineering Mode.
              </p>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => onUpdateProfileConfig({ themeMode: 'dark' })}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-bold border cursor-pointer transition-colors ${
                  profileConfig.themeMode !== 'light'
                    ? 'bg-[#66E3CB] text-slate-950 border-[#66E3CB]'
                    : 'bg-[#111821] text-[#A2AFBF] border-[#283544]'
                }`}
              >
                Dark
              </button>
              <button
                type="button"
                onClick={() => onUpdateProfileConfig({ themeMode: 'light' })}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-bold border cursor-pointer transition-colors ${
                  profileConfig.themeMode === 'light'
                    ? 'bg-[#66E3CB] text-slate-950 border-[#66E3CB]'
                    : 'bg-[#111821] text-[#A2AFBF] border-[#283544]'
                }`}
              >
                Light
              </button>
            </div>
          </div>
        )}

        {/* Section 4: Browser Hardware & Media Capabilities */}
        <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-2">
          <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
            Browser Hardware & Media API Status
          </span>
          <div className="grid grid-cols-3 gap-2 text-xs font-mono">
            <div className="p-2.5 rounded bg-[#111821] border border-[#283544] flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[#A2AFBF]">
                <Mic className="w-3.5 h-3.5" />
                <span>Speech Rec:</span>
              </span>
              <span className={sttSupported ? 'text-emerald-400' : 'text-amber-400'}>
                {sttSupported ? 'Available' : 'Fallback'}
              </span>
            </div>

            <div className="p-2.5 rounded bg-[#111821] border border-[#283544] flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[#A2AFBF]">
                <Volume2 className="w-3.5 h-3.5" />
                <span>Audio TTS:</span>
              </span>
              <span className={ttsSupported ? 'text-emerald-400' : 'text-rose-400'}>
                {ttsSupported ? 'Active' : 'Missing'}
              </span>
            </div>

            <div className="p-2.5 rounded bg-[#111821] border border-[#283544] flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[#A2AFBF]">
                <Video className="w-3.5 h-3.5" />
                <span>Webcam:</span>
              </span>
              <span className={camSupported ? 'text-emerald-400' : 'text-rose-400'}>
                {camSupported ? 'Ready' : 'Missing'}
              </span>
            </div>
          </div>
        </div>

        {/* Section 5: Stealth Mode & Anti-Detection Control */}
        <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-3 font-mono">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <EyeOff className="w-4 h-4 text-[#66E3CB]" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Stealth Mode & Anti-Detection
              </span>
            </div>
            <button
              onClick={toggleStealth}
              className={`px-3 py-1 rounded text-[11px] font-bold border transition-colors cursor-pointer ${
                isStealth
                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
              }`}
            >
              {isStealth ? 'STEALTH ACTIVE' : 'STEALTH OFF'}
            </button>
          </div>

          <div className="bg-[#111821] p-3 rounded-lg border border-[#283544] space-y-2 text-[11px]">
            <p className="text-[#A2AFBF] font-sans">
              {isStealth 
                ? 'Favicon neutralized to a minimal dark dot/square. Page title masked. Explicit LORIN / Assistant branding is completely hidden from public observers, crawlers, and automated bots.'
                : 'Standard public branding is active. Favicon displays standard icon.'}
            </p>
            <div className="flex items-center gap-2 text-[#738297]">
              <span>Active Favicon:</span>
              <span className="text-[#66E3CB] font-semibold">
                {isStealth ? 'Discreet Neutral SVG Node' : 'Default MOSAIRA Icon'}
              </span>
            </div>
          </div>
        </div>

        {/* Section 6: Authorized Owner Email Registry */}
        {principal.role === 'OWNER' && (
          <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] space-y-3 font-mono">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-[#66E3CB]" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Authorized Owner Emails
                </span>
              </div>
              <span className="text-[10px] text-[#A2AFBF]">{ownerEmails.length} Configured</span>
            </div>

            <p className="text-[11px] text-[#A2AFBF] font-sans">
              Multiple emails granted server-enforced Owner clearance to access MOSAIRA AI Lab & Lauren Private Vault.
            </p>

            <form onSubmit={handleAddEmail} className="flex gap-2">
              <input
                type="email"
                value={newOwnerEmail}
                onChange={(e) => setNewOwnerEmail(e.target.value)}
                placeholder="Add owner email address..."
                className="flex-1 px-3 py-1.5 bg-[#111821] border border-[#283544] rounded-lg text-xs text-white placeholder-[#738297] focus:outline-none focus:border-[#66E3CB] font-mono"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </form>

            {emailStatus && (
              <div className="text-[10px] text-emerald-400 font-sans">{emailStatus}</div>
            )}

            <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
              {ownerEmails.map((email) => {
                const isPrimary = Boolean(primaryOwner) && email.toLowerCase() === primaryOwner.toLowerCase();
                return (
                  <div
                    key={email}
                    className="px-2.5 py-1.5 rounded-lg bg-[#111821] border border-[#283544] flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-white truncate">{email}</span>
                      {isPrimary && (
                        <span className="px-1.5 py-0.5 text-[9px] bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded shrink-0">
                          PRIMARY
                        </span>
                      )}
                    </div>
                    {!isPrimary && (
                      <button
                        type="button"
                        onClick={() => handleRemoveEmail(email)}
                        className="text-[#738297] hover:text-rose-400 transition-colors p-1"
                        title="Remove owner email"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Section 7: Authenticated Owner Identity */}
        <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] flex items-center justify-between text-xs font-mono">
          <div>
            <div className="text-[#738297]">Verified Principal</div>
            <div className="text-white font-bold">{principal.name} ({principal.email})</div>
          </div>
          <div className="px-2.5 py-1 rounded bg-[#111821] border border-[#283544] text-[#66E3CB]">
            Role: {principal.role}
          </div>
        </div>

        <div className="flex justify-end pt-2 border-t border-[#283544]">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold cursor-pointer"
          >
            Done
          </button>
        </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
