import React from 'react';
import { AlertTriangle, CheckCircle2, Circle, LoaderCircle, XCircle } from 'lucide-react';
import { LorinCompletionReport } from '../types/lorin';

interface WorkflowStatusIndicatorProps {
  isLoading: boolean;
  currentReport: LorinCompletionReport | null;
  pendingApprovalsCount: number;
}

type StatusView = {
  label: string;
  detail: string;
  className: string;
  icon: React.ComponentType<{ className?: string }>;
};

export const WorkflowStatusIndicator: React.FC<WorkflowStatusIndicatorProps> = ({
  isLoading,
  currentReport,
  pendingApprovalsCount
}) => {
  let status: StatusView = {
    label: 'Ready',
    detail: 'Start a conversation whenever you are ready.',
    className: 'text-[var(--lorin-text-muted)]',
    icon: Circle
  };

  if (isLoading) {
    status = {
      label: 'Responding',
      detail: 'LORIN is preparing a response.',
      className: 'text-[var(--lorin-accent)]',
      icon: LoaderCircle
    };
  } else if (pendingApprovalsCount > 0 || currentReport?.status === 'AWAITING_APPROVAL') {
    status = {
      label: 'Approval needed',
      detail: 'A requested action is waiting for your approval.',
      className: 'text-[var(--lorin-warning)]',
      icon: AlertTriangle
    };
  } else if (currentReport?.status === 'BLOCKED') {
    status = {
      label: 'Blocked',
      detail: 'The last request could not proceed. Review its report for the stated reason.',
      className: 'text-[var(--lorin-warning)]',
      icon: AlertTriangle
    };
  } else if (currentReport?.status === 'FAILED') {
    status = {
      label: 'Response failed',
      detail: 'The last request did not complete. Your prompt remains available to retry.',
      className: 'text-[var(--lorin-danger)]',
      icon: XCircle
    };
  } else if (currentReport?.status === 'VERIFIED') {
    status = {
      label: 'Verified',
      detail: 'The last report includes verification evidence.',
      className: 'text-[var(--lorin-success)]',
      icon: CheckCircle2
    };
  } else if (currentReport?.status === 'COMPLETED') {
    status = {
      label: 'Completed',
      detail: 'The last response completed. No verification result was reported.',
      className: 'text-[var(--lorin-text-muted)]',
      icon: CheckCircle2
    };
  } else if (currentReport?.status === 'PROPOSED' || currentReport?.status === 'PREPARED' || currentReport?.status === 'ATTEMPTED') {
    status = {
      label: currentReport.status === 'PROPOSED' ? 'Proposed' : currentReport.status === 'PREPARED' ? 'Prepared' : 'Attempted',
      detail: 'The last report does not claim that the requested work was verified.',
      className: 'text-[var(--lorin-text-muted)]',
      icon: Circle
    };
  }

  const StatusIcon = status.icon;

  return (
    <div className="flex min-h-11 items-center justify-between gap-3 border-b border-[var(--lorin-border)] bg-[var(--lorin-surface-1)] px-4 sm:px-6">
      <div className="flex min-w-0 items-center gap-2.5" role="status" aria-live="polite">
        <StatusIcon className={`h-4 w-4 shrink-0 ${status.className} ${isLoading ? 'animate-spin' : ''}`} />
        <span className={`text-sm font-medium ${status.className}`}>{status.label}</span>
        <span className="hidden truncate text-sm text-[var(--lorin-text-muted)] sm:inline">{status.detail}</span>
      </div>
      {currentReport?.modelAttribution && (
        <span className="max-w-[45%] truncate text-xs text-[var(--lorin-text-subtle)]" title={`${currentReport.modelAttribution.actualProvider}: ${currentReport.modelAttribution.actualModel}`}>
          {currentReport.modelAttribution.actualProvider} · {currentReport.modelAttribution.actualModel}
        </span>
      )}
    </div>
  );
};
