import React from 'react';
import { Download, CheckCircle2, Share, PlusSquare, X, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'compact' | 'full';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'full', className = '' }) => {
  const { isInstallable, isInstalled, isIOS, showIOSPrompt, setShowIOSPrompt, installApp } = usePWAInstall();

  if (isInstalled) {
    return (
      <div
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#15232A] border border-[#66E3CB]/30 text-[#66E3CB] text-[11px] font-mono ${className}`}
        title="LORIN is installed as a standalone app. Network-dependent features still need a connection."
      >
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
        {variant === 'full' && <span>PWA Active</span>}
      </div>
    );
  }

  return (
    <>
      <button
        onClick={() => installApp()}
        className={`flex items-center gap-1.5 rounded-lg border transition-all cursor-pointer ${
          isInstallable
            ? 'bg-[#15232A] border-[#66E3CB]/50 text-[#66E3CB] hover:bg-[#1a2e37] shadow-sm'
            : 'bg-[#17212C] border-[#283544] text-[#A2AFBF] hover:text-white hover:border-[#3A4B5F]'
        } ${variant === 'compact' ? 'px-2 py-1 text-xs' : 'px-3 py-1.5 text-xs font-mono font-medium'} ${className}`}
        title="Install LORIN as a standalone app"
      >
        <Download className="w-3.5 h-3.5 text-[#66E3CB] shrink-0" />
        <span>{variant === 'compact' ? 'Install' : 'Install PWA'}</span>
      </button>

      {/* iOS Safari Guided Install Sheet */}
      {showIOSPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in-50">
          <div className="bg-[#111821] border border-[#283544] rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl relative">
            <button
              onClick={() => setShowIOSPrompt(false)}
              className="absolute top-4 right-4 p-1 rounded-lg text-[#738297] hover:text-white hover:bg-[#17212C]"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#17212C] border border-[#66E3CB]/30 flex items-center justify-center text-[#66E3CB]">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Install LORIN on iOS</h3>
                <p className="text-[11px] text-[#A2AFBF]">Add LORIN to your Home Screen. Features that use online services still need a connection.</p>
              </div>
            </div>

            <div className="space-y-2.5 text-xs text-[#F1F5F9] bg-[#17212C] p-3.5 rounded-xl border border-[#283544]">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-[#283544] text-[10px] font-mono flex items-center justify-center shrink-0 text-[#66E3CB] font-bold">1</span>
                <p>Tap the <strong>Share</strong> icon <Share className="w-3.5 h-3.5 inline mx-0.5 text-[#66E3CB]" /> in the Safari browser navigation bar.</p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-[#283544] text-[10px] font-mono flex items-center justify-center shrink-0 text-[#66E3CB] font-bold">2</span>
                <p>Scroll down the share sheet and tap <strong>Add to Home Screen</strong> <PlusSquare className="w-3.5 h-3.5 inline mx-0.5 text-[#66E3CB]" />.</p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-[#283544] text-[10px] font-mono flex items-center justify-center shrink-0 text-[#66E3CB] font-bold">3</span>
                <p>Tap <strong>Add</strong> in the top right to launch LORIN standalone without browser chrome.</p>
              </div>
            </div>

            <button
              onClick={() => setShowIOSPrompt(false)}
              className="w-full py-2.5 rounded-xl bg-[#66E3CB] text-slate-950 font-bold text-xs hover:bg-[#52d6be] transition-colors"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
