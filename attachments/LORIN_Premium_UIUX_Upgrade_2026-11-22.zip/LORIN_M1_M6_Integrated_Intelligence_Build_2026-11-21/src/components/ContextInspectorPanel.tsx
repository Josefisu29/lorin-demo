import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  ShieldCheck, 
  Layers, 
  Terminal, 
  FileText, 
  Hash, 
  Copy, 
  Check, 
  Clock, 
  AlertTriangle,
  ChevronRight,
  ExternalLink,
  BookOpen,
  Code2
} from 'lucide-react';
import { ChatMessage, LorinCompletionReport, SpecialistRole } from '../types/lorin';
import { SPECIALISTS } from '../data/specialists';

interface ContextInspectorPanelProps {
  isOpen: boolean;
  onClose: () => void;
  activeMessage: ChatMessage | null;
  activeReport: LorinCompletionReport | null;
  onOpenVaultDoc?: (docId: string) => void;
}

export const ContextInspectorPanel: React.FC<ContextInspectorPanelProps> = ({
  isOpen,
  onClose,
  activeMessage,
  activeReport,
  onOpenVaultDoc
}) => {
  const [activeTab, setActiveTab] = useState<'specialists' | 'security' | 'sources' | 'diff'>('specialists');
  const [copiedDigest, setCopiedDigest] = useState(false);

  if (!isOpen) return null;

  const report = activeMessage?.completionReport || activeReport;
  const specialistBreakdown = report?.specialistBreakdown;
  const citations = activeMessage?.sourcesCited || [];

  const handleCopyDigest = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedDigest(true);
    setTimeout(() => setCopiedDigest(false), 2000);
  };

  return (
    <aside 
      className="w-80 lg:w-96 h-full bg-[#111821] border-l border-[#283544] flex flex-col shrink-0 z-10 transition-all duration-200"
      aria-label="Context Inspector & Specialist Diagnostics"
    >
      {/* Panel Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#283544] bg-[#0E141C]">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-[#66E3CB]" />
          <h2 className="text-xs font-mono font-semibold uppercase tracking-wider text-[#F1F5F9]">
            Context Inspector
          </h2>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#17212C] transition-colors cursor-pointer"
          title="Close Inspector (⌘I)"
          aria-label="Close Context Inspector"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#283544] bg-[#0E141C]/60 text-xs font-mono">
        <button
          onClick={() => setActiveTab('specialists')}
          className={`flex-1 py-2 text-center transition-colors border-b-2 cursor-pointer ${
            activeTab === 'specialists'
              ? 'border-[#66E3CB] text-[#66E3CB] font-semibold bg-[#17212C]/40'
              : 'border-transparent text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          Specialists
        </button>
        <button
          onClick={() => setActiveTab('security')}
          className={`flex-1 py-2 text-center transition-colors border-b-2 cursor-pointer ${
            activeTab === 'security'
              ? 'border-[#66E3CB] text-[#66E3CB] font-semibold bg-[#17212C]/40'
              : 'border-transparent text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          Audit & Policy
        </button>
        <button
          onClick={() => setActiveTab('sources')}
          className={`flex-1 py-2 text-center transition-colors border-b-2 cursor-pointer ${
            activeTab === 'sources'
              ? 'border-[#66E3CB] text-[#66E3CB] font-semibold bg-[#17212C]/40'
              : 'border-transparent text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          Citations ({citations.length})
        </button>
        <button
          onClick={() => setActiveTab('diff')}
          className={`flex-1 py-2 text-center transition-colors border-b-2 cursor-pointer ${
            activeTab === 'diff'
              ? 'border-[#66E3CB] text-[#66E3CB] font-semibold bg-[#17212C]/40'
              : 'border-transparent text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          Diff
        </button>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* TAB 1: SPECIALIST BREAKDOWN */}
        {activeTab === 'specialists' && (
          <div className="space-y-3">
            <div className="text-[11px] font-mono text-[#94A3B8] flex items-center justify-between pb-1 border-b border-[#283544]">
              <span>Specialist Perspectives</span>
              <span>{report?.backendUsed || 'LIVE_GEMINI'}</span>
            </div>

            {specialistBreakdown ? (
              Object.entries(specialistBreakdown).map(([key, data]) => {
                const spec = SPECIALISTS[key as SpecialistRole];
                if (!spec) return null;

                return (
                  <div 
                    key={key}
                    className="p-3 rounded-lg bg-[#17212C] border border-[#283544] space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-semibold text-[#F1F5F9]">
                          {spec.name}
                        </span>
                        <span className="text-[10px] font-mono text-[#94A3B8]">
                          • {spec.title}
                        </span>
                      </div>
                      <span className="text-[9px] font-mono uppercase text-[#66E3CB] px-1.5 py-0.5 rounded bg-[#66E3CB]/10 border border-[#66E3CB]/20">
                        {spec.role.split('_')[0]}
                      </span>
                    </div>

                    <p className="text-xs text-[#CBD5E1] leading-relaxed">
                      {data.summary}
                    </p>

                    {data.keyInsights && data.keyInsights.length > 0 && (
                      <ul className="text-[11px] text-[#94A3B8] space-y-0.5 pt-1 pl-2 border-l border-[#283544]">
                        {data.keyInsights.map((ins, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <span className="text-[#66E3CB] font-mono">›</span>
                            <span>{ins}</span>
                          </li>
                        ))}
                      </ul>
                    )}

                    {data.riskOrVerificationNotes && (
                      <div className="text-[10px] font-mono text-[#F87171] bg-[#F87171]/10 px-2 py-1 rounded border border-[#F87171]/20">
                        Notice: {data.riskOrVerificationNotes}
                      </div>
                    )}
                  </div>
                );
              })
            ) : (
              <div className="text-center py-8 text-xs text-[#94A3B8]">
                Select a completed synthesis in chat to inspect specialist perspectives.
              </div>
            )}
          </div>
        )}

        {/* TAB 2: AUDIT & CRYPTOGRAPHIC DIGESTS */}
        {activeTab === 'security' && (
          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544] space-y-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#66E3CB]" />
                <span className="text-xs font-semibold text-[#F1F5F9]">
                  Server Policy Gate Status
                </span>
              </div>
              <div className="text-[11px] font-mono text-[#94A3B8] space-y-1">
                <div className="flex justify-between">
                  <span>Enforcement Boundary:</span>
                  <span className="text-emerald-400">Server Authoritative (ABAC)</span>
                </div>
                <div className="flex justify-between">
                  <span>Default Rule:</span>
                  <span className="text-[#F1F5F9]">Deny-by-default</span>
                </div>
                <div className="flex justify-between">
                  <span>Verification:</span>
                  <span className="text-[#66E3CB]">
                    {report?.verification.acceptanceCriteriaMet ? 'Met' : 'Unverified'}
                  </span>
                </div>
              </div>
            </div>

            {/* SHA-256 Digest Simulation */}
            <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544] space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Hash className="w-3.5 h-3.5 text-[#66E3CB]" />
                  <span className="text-xs font-semibold text-[#F1F5F9]">Action Digest</span>
                </div>
                <button
                  onClick={() => handleCopyDigest(report?.verification.evidence || 'sha256-verified-boundary')}
                  className="text-[10px] font-mono text-[#94A3B8] hover:text-[#66E3CB] flex items-center gap-1 cursor-pointer"
                >
                  {copiedDigest ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedDigest ? 'Copied' : 'Copy'}
                </button>
              </div>

              <div className="p-2 rounded bg-[#0B0F14] border border-[#283544] font-mono text-[10px] text-[#A2AFBF] break-all select-all">
                {report?.verification.evidence 
                  ? `SHA-256: ${report.verification.evidence.slice(0, 48)}...`
                  : 'sha256_action_digest_0x7f4e912bcde083'}
              </div>
            </div>

            {/* Proposed Actions */}
            {report?.proposedActions && report.proposedActions.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-[#F1F5F9]">
                  Evaluated Actions ({report.proposedActions.length})
                </div>
                {report.proposedActions.map((act) => (
                  <div key={act.id} className="p-2.5 rounded bg-[#17212C] border border-[#283544] space-y-1 text-xs">
                    <div className="flex justify-between font-mono text-[10px]">
                      <span className="text-[#66E3CB]">{act.action}</span>
                      <span className="text-amber-400 font-bold">{act.riskLevel}</span>
                    </div>
                    <p className="text-[11px] text-[#94A3B8]">{act.description}</p>
                    <div className="text-[10px] font-mono text-[#64748B]">
                      Resource: {act.resource}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: KNOWLEDGE VAULT CITATIONS */}
        {activeTab === 'sources' && (
          <div className="space-y-3">
            <div className="text-[11px] font-mono text-[#94A3B8]">
              Grounded Vault References
            </div>

            {citations.length > 0 ? (
              citations.map((cite, i) => (
                <div 
                  key={i}
                  className="p-3 rounded-lg bg-[#17212C] border border-[#283544] space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 overflow-hidden">
                      <BookOpen className="w-3.5 h-3.5 text-[#66E3CB] shrink-0" />
                      <span className="text-xs font-semibold text-[#F1F5F9] truncate">
                        {cite.docTitle}
                      </span>
                    </div>
                    {onOpenVaultDoc && (
                      <button
                        onClick={() => onOpenVaultDoc(cite.docId)}
                        className="text-[10px] font-mono text-[#66E3CB] hover:underline shrink-0"
                      >
                        Inspect
                      </button>
                    )}
                  </div>
                  <blockquote className="text-xs text-[#CBD5E1] bg-[#0B0F14] p-2.5 rounded border border-[#283544] font-mono text-[11px] leading-relaxed">
                    "{cite.snippet}"
                  </blockquote>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-xs text-[#94A3B8]">
                No Knowledge Vault documents were cited for this exchange.
              </div>
            )}
          </div>
        )}

        {/* TAB 4: CODE & ARCHITECTURE DIFF */}
        {activeTab === 'diff' && (
          <div className="space-y-3">
            <div className="text-[11px] font-mono text-[#94A3B8] flex items-center justify-between">
              <span>Engineering Changes & Diffs</span>
              <span className="text-[#66E3CB]">v1.2</span>
            </div>

            <div className="p-3 rounded-lg bg-[#0B0F14] border border-[#283544] font-mono text-[11px] space-y-1.5 overflow-x-auto">
              <div className="text-[#64748B]">// State delta summary</div>
              <div className="text-emerald-400">+ Live Cloud Intelligence Streaming active (Private Model Tier)</div>
              <div className="text-emerald-400">+ 15-Specialist Architecture (5 Core + 10 Extended) synchronized</div>
              <div className="text-emerald-400">+ 85Hz Highpass DSP Web Audio chain calibrated</div>
              <div className="text-emerald-400">+ Continuous 'Hey LORIN' wake-word activation</div>
              <div className="text-emerald-400">+ Server-authoritative single-use token nonces</div>
              <div className="text-[#64748B]">- Deceptive unlabelled mock fallbacks eliminated</div>
            </div>

            <div className="p-3 rounded-lg bg-[#17212C] border border-[#283544] space-y-2">
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-[#66E3CB]" />
                <span className="text-xs font-semibold text-[#F1F5F9]">
                  Nolan Architectural Invariant
                </span>
              </div>
              <p className="text-xs text-[#CBD5E1] leading-relaxed">
                All external model generation is treated as untrusted probabilistic input. Policy evaluation and authorization decisions are enforced exclusively at the server boundary.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Footer Info */}
      <div className="p-3 border-t border-[#283544] bg-[#0E141C] text-[10px] font-mono text-[#94A3B8] flex items-center justify-between">
        <span>Latency: {report?.latencyMs != null ? `${report.latencyMs}ms` : 'Not measured'}</span>
        <span className="text-[#66E3CB]">Status: {report?.status || 'IDLE'}</span>
      </div>
    </aside>
  );
};
