import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  PhoneOff, 
  AlertCircle, 
  MessageSquare,
  Radio,
  Sliders,
  ShieldCheck,
  Activity,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Wand2,
  Filter,
  Layers,
  Gauge,
  Pause,
  Play,
  Square,
  Cloud,
  Loader2,
  Stethoscope
} from 'lucide-react';
import { AudioService, AudioVisualizerData, AudioDspConfig } from '../services/audioService';
import { LorinCompletionReport, LorinVoiceProfile, VoiceState } from '../types/lorin';
import { LorinCharacter } from './LorinCharacter';
import { LorinCharacterState } from '../services/lorinPresence';
import { LORIN_VOICE_PROFILES } from '../services/lorinProfileService';
import { CommunicationManager, CommunicationStateSnapshot } from '../services/communicationManager';
import { CommunicationDiagnosticsModal } from './CommunicationDiagnosticsModal';

interface VoiceChatViewProps {
  onSendMessage: (text: string) => Promise<LorinCompletionReport>;
  onSwitchToChat: () => void;
  isMicActive: boolean;
  setIsMicActive: (active: boolean) => void;
  activeVoiceProfile?: LorinVoiceProfile;
  onSelectVoiceProfile?: (voiceProfile: LorinVoiceProfile) => void;
  onPresenceChange?: (state: LorinCharacterState) => void;
}

const toCharacterState = (state: VoiceState): LorinCharacterState => {
  if (state === 'MUTED' || state === 'READY' || state === 'IDLE') return 'IDLE';
  if (state === 'REQUESTING_PERMISSION') return 'PROCESSING';
  return state;
};

export type VoiceInteractionMode = 'MODE_B_CONVERSATION' | 'MODE_A_DICTATION';

export const VoiceChatView: React.FC<VoiceChatViewProps> = ({
  onSendMessage,
  onSwitchToChat,
  isMicActive,
  setIsMicActive,
  activeVoiceProfile = 'LAUREN_NATURAL',
  onSelectVoiceProfile,
  onPresenceChange
}) => {
  const [voiceState, setVoiceState] = useState<VoiceState>('IDLE');
  const [interactionMode, setInteractionMode] = useState<VoiceInteractionMode>('MODE_B_CONVERSATION');
  const [commSnapshot, setCommSnapshot] = useState<CommunicationStateSnapshot>(() =>
    CommunicationManager.getSnapshot()
  );
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState<boolean>(false);
  const [isWakeWordArmed, setIsWakeWordArmed] = useState<boolean>(false);
  const [isVoiceActivityActive, setIsVoiceActivityActive] = useState<boolean>(false);

  const [audioVolume, setAudioVolume] = useState<number>(0);
  const [isGateSuppressed, setIsGateSuppressed] = useState<boolean>(false);
  const [rmsDbfs, setRmsDbfs] = useState<number>(-90);
  const [thresholdDbfs, setThresholdDbfs] = useState<number>(-55);
  const [currentGain, setCurrentGain] = useState<number>(1.0);
  const [transcript, setTranscript] = useState<string>('');
  const [interimText, setInterimText] = useState<string>('');
  const [lorinResponse, setLorinResponse] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isTTSMuted, setIsTTSMuted] = useState<boolean>(false);
  const [isTTSPaused, setIsTTSPaused] = useState<boolean>(false);
  const [showDspPanel, setShowDspPanel] = useState<boolean>(true);
  const [dspConfig, setDspConfig] = useState<AudioDspConfig>(AudioService.getDspConfig());

  // Cloud MediaRecorder clip recording state (works across all browsers, uses gemini-3.5-transcribe)
  const [isRecordingClip, setIsRecordingClip] = useState<boolean>(false);
  const [isTranscribingClip, setIsTranscribingClip] = useState<boolean>(false);

  // Ambient calibration state
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);
  const [calibrationProgress, setCalibrationProgress] = useState<number>(0);
  const [calibrationToast, setCalibrationToast] = useState<string | null>(null);

  // Editable prompt / Mode A review input inside voice view
  const [fallbackInput, setFallbackInput] = useState<string>('');

  // Ref-based visual meter elements (high-performance, zero re-render lag)
  const meterCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const levelBarRef = useRef<HTMLDivElement | null>(null);
  const gateMarkerRef = useRef<HTMLDivElement | null>(null);
  const gainBarRef = useRef<HTMLDivElement | null>(null);
  const animationFrameIdRef = useRef<number | null>(null);
  const interactionModeRef = useRef<VoiceInteractionMode>(interactionMode);

  useEffect(() => {
    interactionModeRef.current = interactionMode;
  }, [interactionMode]);

  // VAD observes the microphone frames only during an explicitly active mic session.
  // It emits speech boundaries; it does not store or transmit audio segments.
  useEffect(() => {
    if (!isMicActive) {
      AudioService.setVoiceActivityListener(null);
      setIsVoiceActivityActive(false);
      return;
    }
    AudioService.setVoiceActivityListener((event) => setIsVoiceActivityActive(event.active));
    return () => {
      AudioService.setVoiceActivityListener(null);
      setIsVoiceActivityActive(false);
    };
  }, [isMicActive]);

  useEffect(() => {
    return CommunicationManager.subscribe((snap) => {
      setCommSnapshot(snap);
    });
  }, []);

  useEffect(() => {
    const derivedState =
      commSnapshot.state !== 'idle' && commSnapshot.state !== 'completed'
        ? commSnapshot.characterState
        : toCharacterState(voiceState);
    onPresenceChange?.(derivedState);
  }, [voiceState, commSnapshot.state, commSnapshot.characterState, onPresenceChange]);

  // Meter width helper: map -90dBFS (0%) to 0dBFS (100%)
  const dbfsToPercent = useCallback((db: number) => {
    return Math.max(0, Math.min(100, Math.round(((db + 90) / 90) * 100)));
  }, []);

  // Real-time canvas animation loop tied directly to the Web Audio AnalyserNode
  const runCanvasVisualizerLoop = useCallback(() => {
    const canvas = meterCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const analyser = AudioService.getAnalyserNode();
    if (!analyser) return;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    const timeDomainArray = new Uint8Array(bufferLength);

    const draw = () => {
      animationFrameIdRef.current = requestAnimationFrame(draw);

      analyser.getByteFrequencyData(dataArray);
      analyser.getByteTimeDomainData(timeDomainArray);

      const width = canvas.width;
      const height = canvas.height;

      ctx.fillStyle = '#0E1520';
      ctx.fillRect(0, 0, width, height);

      // 1. Draw subtle grid lines
      ctx.strokeStyle = 'rgba(40, 53, 68, 0.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, height * 0.25);
      ctx.lineTo(width, height * 0.25);
      ctx.moveTo(0, height * 0.5);
      ctx.lineTo(width, height * 0.5);
      ctx.moveTo(0, height * 0.75);
      ctx.lineTo(width, height * 0.75);
      ctx.stroke();

      // 2. Draw Frequency Spectrum Bars
      const barWidth = (width / bufferLength) * 2.2;
      let barX = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * (height * 0.85);
        const freqHz = (i * 22050) / bufferLength;
        const isBelowHighpass = dspConfig.enableHighpass && freqHz < dspConfig.highpassFreq;

        if (isBelowHighpass) {
          ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
        } else if (isGateSuppressed) {
          ctx.fillStyle = 'rgba(245, 158, 11, 0.6)';
        } else {
          const grad = ctx.createLinearGradient(0, height, 0, height - barHeight);
          grad.addColorStop(0, 'rgba(102, 227, 203, 0.2)');
          grad.addColorStop(1, 'rgba(102, 227, 203, 0.85)');
          ctx.fillStyle = grad;
        }

        ctx.fillRect(barX, height - barHeight, barWidth - 1, barHeight);
        barX += barWidth;
      }

      // 3. Draw Oscilloscope Time-Domain Waveform Overlay
      ctx.lineWidth = 2;
      ctx.strokeStyle = isGateSuppressed ? '#F59E0B' : '#A9B8FF';
      ctx.beginPath();

      const sliceWidth = width / bufferLength;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const v = timeDomainArray[i] / 128.0;
        const y = (v * height) / 2;

        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
        x += sliceWidth;
      }
      ctx.lineTo(width, height / 2);
      ctx.stroke();

      // 4. Draw High-Pass Cutoff Vertical Marker
      if (dspConfig.enableHighpass) {
        const cutoffX = (dspConfig.highpassFreq / 22050) * bufferLength * (barWidth / 2.2);
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.8)';
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(cutoffX, 0);
        ctx.lineTo(cutoffX, height);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = '#EF4444';
        ctx.font = '9px JetBrains Mono, monospace';
        ctx.fillText(`HPF ${dspConfig.highpassFreq}Hz`, cutoffX + 4, 12);
      }
    };

    draw();
  }, [dspConfig, isGateSuppressed]);

  const handleProcessVoicePrompt = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setErrorMessage(null);
    setVoiceState('PROCESSING');
    AudioService.stopSpeaking();
    setIsTTSPaused(false);
    CommunicationManager.transition('submitting', 'voice', 'Submitting spoken prompt to LORIN...');

    try {
      const report = await onSendMessage(trimmed);
      if (report.status === 'FAILED' || report.status === 'BLOCKED') {
        setErrorMessage(report.rawSynthesis || 'LORIN could not complete this request.');
        setLorinResponse('');
        setVoiceState(isMicActive ? 'LISTENING' : 'IDLE');
        return;
      }
      const cleanSummary = report.rawSynthesis
        ? report.rawSynthesis.replace(/[*#`_>-]/g, '').slice(0, 420)
        : 'Analysis complete.';

      setLorinResponse(cleanSummary);
      const canSpeak = !isTTSMuted && (AudioService.isNeuralTtsEnabled() || AudioService.isSpeechSynthesisSupported());
      setVoiceState(canSpeak ? 'SPEAKING' : isMicActive ? 'LISTENING' : 'IDLE');

      if (canSpeak) {
        const def = LORIN_VOICE_PROFILES[activeVoiceProfile];
        await AudioService.speakWithNeuralOption(
          cleanSummary,
          () => {
            setIsTTSPaused(false);
            setVoiceState(isMicActive ? 'LISTENING' : 'IDLE');
            if (isMicActive) {
              CommunicationManager.transition('listening', 'voice', 'Listening... Speak now.');
            } else {
              CommunicationManager.transition('completed', 'voice', 'Voice response complete.');
            }
          },
          {
            pitch: def?.pitch,
            rate: def?.rate,
            preferredVoiceKeywords: def?.preferredVoiceKeywords
          }
        );
      } else if (isMicActive) {
        CommunicationManager.transition('listening', 'voice', 'Listening... Speak now.');
      }
    } catch (e: any) {
      const reason = typeof e?.message === 'string' ? e.message : 'Voice request could not be completed.';
      setLorinResponse('');
      setErrorMessage(reason);
      setVoiceState(isMicActive ? 'LISTENING' : 'ERROR');
      CommunicationManager.failRequestTrace({
        code: e?.name === 'AbortError' ? 'VOICE_REQUEST_CANCELLED' : 'VOICE_INFERENCE_FAILED',
        message: reason,
        retryable: e?.name !== 'AbortError'
      });
    }
  };

  // Start voice session ONLY after explicit user gesture (e.g. click event)
  const handleStartSessionClick = async () => {
    setErrorMessage(null);
    setVoiceState('REQUESTING_PERMISSION');
    CommunicationManager.transition('requesting_permission', 'voice', 'Requesting microphone permission...');

    const micRes = await AudioService.startMicrophone((data: AudioVisualizerData) => {
      setAudioVolume(data.volume);
      setIsGateSuppressed(data.isGateSuppressed);
      setRmsDbfs(data.rmsDbfs);
      setThresholdDbfs(data.thresholdDbfs);
      setCurrentGain(data.currentGain);

      if (levelBarRef.current) {
        const pct = Math.max(0, Math.min(100, Math.round(((data.rmsDbfs + 90) / 90) * 100)));
        levelBarRef.current.style.width = `${pct}%`;
        levelBarRef.current.style.backgroundColor = data.isGateSuppressed ? '#F59E0B' : '#66E3CB';
      }

      if (gateMarkerRef.current) {
        const markerPct = Math.max(0, Math.min(100, Math.round(((data.thresholdDbfs + 90) / 90) * 100)));
        gateMarkerRef.current.style.left = `${markerPct}%`;
      }

      if (gainBarRef.current) {
        gainBarRef.current.style.width = `${Math.round(data.currentGain * 100)}%`;
      }
    });

    if (!micRes.success) {
      const errMsg = micRes.error || 'Microphone access denied or unavailable.';
      setVoiceState('ERROR');
      setErrorMessage(errMsg);
      setIsMicActive(false);
      CommunicationManager.transition('permission_required', 'voice', errMsg, {
        code: 'MIC_PERMISSION_DENIED',
        message: errMsg,
        recoverable: true
      });
      return;
    }

    setIsMicActive(true);
    setVoiceState('LISTENING');
    setDspConfig(AudioService.getDspConfig());
    runCanvasVisualizerLoop();

    // Start browser Speech Recognition if supported; otherwise notify user to use Cloud Clip button
    if (!AudioService.isSpeechRecognitionSupported()) {
      setErrorMessage(
        'Browser continuous SpeechRecognition is unavailable in this browser. Use "Record Cloud Voice Clip" below for Gemini 3.5 server-side transcription, or type below.'
      );
      CommunicationManager.transition(
        'listening',
        'voice',
        'Microphone active. Use "Record Cloud Voice Clip" for server-side speech transcription.'
      );
      return;
    }

    AudioService.startSpeechRecognition(
      (text: string, isFinal: boolean) => {
        // Conversational Interruption: speaking cuts off ongoing TTS playback
        if (AudioService.isSpeaking()) {
          AudioService.interrupt();
          setIsTTSPaused(false);
          setVoiceState('LISTENING');
        }
        if (isFinal) {
          setTranscript(text);
          setInterimText('');
          if (interactionModeRef.current === 'MODE_A_DICTATION') {
            setFallbackInput((prev) => (prev ? `${prev.trim()} ${text}`.trim() : text));
            CommunicationManager.transition(
              'transcript_ready',
              'dictation',
              'Transcript placed in review box below. Edit or press Send.'
            );
          } else {
            handleProcessVoicePrompt(text);
          }
        } else {
          setInterimText(text);
        }
      },
      (errText: string) => {
        setErrorMessage(
          `${errText} — You can also click "Record Cloud Voice Clip" to transcribe via Gemini 3.5 on the server.`
        );
      }
    );
  };

  // Cloud MediaRecorder Clip Capture -> /api/audio/transcribe (gemini-3.5-transcribe)
  const handleToggleCloudClipRecording = async () => {
    setErrorMessage(null);
    if (isTranscribingClip) return;

    if (!isRecordingClip) {
      if (AudioService.isSpeaking()) {
        AudioService.interrupt();
        setIsTTSPaused(false);
      }
      const startRes = await AudioService.startClipRecording();
      if (!startRes.success) {
        setErrorMessage(startRes.error || 'Could not start voice clip recorder.');
        return;
      }
      setIsRecordingClip(true);
      setVoiceState('LISTENING');
    } else {
      setIsRecordingClip(false);
      setIsTranscribingClip(true);
      setVoiceState('PROCESSING');
      try {
        const res = await AudioService.stopClipAndTranscribe();
        if (!res.success) {
          setErrorMessage(res.error || 'Cloud voice clip transcription returned no speech.');
          setVoiceState(isMicActive ? 'LISTENING' : 'IDLE');
          return;
        }
        setTranscript(res.transcript);
        setInterimText('');
        if (interactionMode === 'MODE_A_DICTATION') {
          setFallbackInput((prev) => (prev ? `${prev.trim()} ${res.transcript}`.trim() : res.transcript));
          setVoiceState(isMicActive ? 'LISTENING' : 'IDLE');
        } else {
          await handleProcessVoicePrompt(res.transcript);
        }
      } finally {
        setIsTranscribingClip(false);
      }
    }
  };

  const handleEndSession = () => {
    AudioService.stopWakeWordDetection();
    setIsWakeWordArmed(false);
    if (animationFrameIdRef.current) {
      cancelAnimationFrame(animationFrameIdRef.current);
      animationFrameIdRef.current = null;
    }
    AudioService.stopMicrophone();
    setIsMicActive(false);
    setIsRecordingClip(false);
    setIsTTSPaused(false);
    setVoiceState('IDLE');
    setAudioVolume(0);
    setIsGateSuppressed(false);
    setRmsDbfs(-90);
    setCurrentGain(1.0);
    setInterimText('');
    CommunicationManager.reset('voice');
  };

  const handleToggleWakeWord = () => {
    if (isWakeWordArmed) {
      AudioService.stopWakeWordDetection();
      setIsWakeWordArmed(false);
      return;
    }
    if (!AudioService.isSpeechRecognitionSupported()) {
      setErrorMessage('Foreground wake phrase is unavailable in this browser. Start the microphone manually instead.');
      return;
    }
    const started = AudioService.startWakeWordDetection(
      () => {
        AudioService.stopWakeWordDetection();
        setIsWakeWordArmed(false);
        setErrorMessage(null);
        // The wake phrase is armed only by an explicit click. After detection,
        // normal microphone capture still requests permission through the usual flow.
        void handleStartSessionClick();
      },
      (message) => {
        setIsWakeWordArmed(false);
        setErrorMessage(message);
      }
    );
    if (started) setIsWakeWordArmed(true);
  };

  const toggleMicMute = () => {
    if (voiceState === 'MUTED') {
      AudioService.setMicrophoneMuted(false);
      setVoiceState('LISTENING');
      CommunicationManager.transition('listening', 'voice', 'Microphone unmuted. Listening...');
    } else {
      AudioService.setMicrophoneMuted(true);
      AudioService.stopSpeaking();
      setIsTTSPaused(false);
      setVoiceState('MUTED');
      setAudioVolume(0);
      CommunicationManager.transition('idle', 'voice', 'Microphone muted.');
    }
  };

  const handlePauseOrResumeTTS = () => {
    if (isTTSPaused) {
      AudioService.resumeSpeaking();
      setIsTTSPaused(false);
    } else {
      AudioService.pauseSpeaking();
      setIsTTSPaused(true);
    }
  };

  const handleStopTTS = () => {
    AudioService.stopSpeaking();
    setIsTTSPaused(false);
    setVoiceState(isMicActive ? 'LISTENING' : 'IDLE');
  };

  // Real-time parameter updates
  const handleSetNoiseGate = (threshold: number) => {
    AudioService.updateDspConfig({ noiseGateThreshold: threshold });
    setDspConfig(AudioService.getDspConfig());
  };

  const handleSetHighpassFreq = (freq: number) => {
    AudioService.updateDspConfig({ highpassFreq: freq });
    setDspConfig(AudioService.getDspConfig());
  };

  const handleToggleHighpass = () => {
    const nextVal = !dspConfig.enableHighpass;
    AudioService.updateDspConfig({ enableHighpass: nextVal });
    setDspConfig(AudioService.getDspConfig());
  };

  const handleCalibrateNoiseFloor = async () => {
    if (!isMicActive) {
      setErrorMessage('Please start the voice session first to measure room ambient noise.');
      return;
    }

    setIsCalibrating(true);
    setCalibrationProgress(0);

    try {
      const result = await AudioService.calibrateNoiseFloor(1500, (p) => setCalibrationProgress(p));
      setDspConfig(AudioService.getDspConfig());
      setCalibrationToast(`Calibrated room noise floor: ${result.ambientDbfs} dBFS. Gate threshold set to ${result.recommendedThreshold}%.`);
      setTimeout(() => setCalibrationToast(null), 4000);
    } catch (e: any) {
      setErrorMessage(e.message || 'Calibration failed');
    } finally {
      setIsCalibrating(false);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
      AudioService.stopMicrophone();
      AudioService.stopWakeWordDetection();
      AudioService.setVoiceActivityListener(null);
      setIsMicActive(false);
    };
  }, [setIsMicActive]);

  const handleFallbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fallbackInput.trim()) return;
    const textToSend = fallbackInput.trim();
    setTranscript(textToSend);
    setFallbackInput('');
    handleProcessVoicePrompt(textToSend);
  };

  const activeCharacterState: LorinCharacterState =
    commSnapshot.state !== 'idle' && commSnapshot.state !== 'completed'
      ? commSnapshot.characterState
      : toCharacterState(voiceState);

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] overflow-y-auto">
      {/* Voice Stage Header */}
      <div className="p-4 border-b border-[#283544] bg-[#111821] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center">
            <Radio className="w-4 h-4 text-[#66E3CB]" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight">Voice Conversation Stage & Web Audio DSP</h2>
            <div className="text-[11px] font-mono text-[#A2AFBF] flex flex-wrap items-center gap-2">
              <span>
                Pipeline: <strong className="text-[#66E3CB] uppercase">{commSnapshot.state}</strong>
              </span>
              <span>·</span>
              <span className="text-slate-300">{commSnapshot.statusMessage}</span>
              <span aria-live="polite" className={isVoiceActivityActive ? 'text-[#66E3CB]' : 'text-slate-500'}>
                · VAD {isVoiceActivityActive ? 'speech detected' : isMicActive ? 'monitoring' : 'off'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Voice Mode Selector: Mode A (Dictation Review) vs Mode B (Hands-Free Turn) */}
          <div
            className="flex items-center bg-[#17212C] border border-[#283544] rounded-lg p-0.5 text-[11px] font-mono"
            role="group"
            aria-label="Voice Interaction Mode"
          >
            <button
              type="button"
              onClick={() => setInteractionMode('MODE_B_CONVERSATION')}
              className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                interactionMode === 'MODE_B_CONVERSATION'
                  ? 'bg-[#66E3CB] text-slate-950 font-bold'
                  : 'text-[#A2AFBF] hover:text-white'
              }`}
              title="Mode B — Hands-free voice turn: automatically sends finalized speech and speaks LORIN's reply"
            >
              Mode B: Auto-Send
            </button>
            <button
              type="button"
              onClick={() => setInteractionMode('MODE_A_DICTATION')}
              className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                interactionMode === 'MODE_A_DICTATION'
                  ? 'bg-[#66E3CB] text-slate-950 font-bold'
                  : 'text-[#A2AFBF] hover:text-white'
              }`}
              title="Mode A — Voice Dictation: transcribes speech into the prompt input box so you can review or edit before sending"
            >
              Mode A: Review First
            </button>
          </div>

          <button
            type="button"
            onClick={handleToggleWakeWord}
            disabled={isMicActive}
            aria-pressed={isWakeWordArmed}
            title="Optional foreground phrase detection through the browser speech service. It starts only after you click and is not an offline native wake-word engine."
            className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-mono transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${isWakeWordArmed ? 'border-[#66E3CB] bg-[#66E3CB]/10 text-[#66E3CB]' : 'border-[#283544] bg-[#17212C] text-[#A2AFBF] hover:text-white'}`}
          >
            {isWakeWordArmed ? 'Hey LORIN: Armed' : 'Enable Hey LORIN'}
          </button>

          {/* Voice Profile Selector */}
          {onSelectVoiceProfile && (
            <div className="flex items-center gap-1.5 bg-[#17212C] border border-[#283544] rounded-lg px-2.5 py-1.5 font-mono text-xs">
              <Volume2 className="w-3.5 h-3.5 text-[#66E3CB] shrink-0" />
              <select
                aria-label="LORIN Voice Synthesis Profile"
                value={activeVoiceProfile}
                onChange={(e) => {
                  const nextVoice = e.target.value as LorinVoiceProfile;
                  onSelectVoiceProfile(nextVoice);
                  const def = LORIN_VOICE_PROFILES[nextVoice];
                  AudioService.speakWithNeuralOption(def.samplePhrase, undefined, {
                    pitch: def.pitch,
                    rate: def.rate,
                    preferredVoiceKeywords: def.preferredVoiceKeywords
                  });
                }}
                className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
              >
                {(Object.keys(LORIN_VOICE_PROFILES) as LorinVoiceProfile[]).map((vKey) => (
                  <option key={vKey} value={vKey} className="bg-[#111821] text-white">
                    Voice: {LORIN_VOICE_PROFILES[vKey].shortLabel} ({LORIN_VOICE_PROFILES[vKey].rate}x)
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* DSP Settings Drawer Toggle */}
          <button
            onClick={() => setShowDspPanel(!showDspPanel)}
            className={`px-2.5 py-1.5 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer ${
              dspConfig.enableHighpass && dspConfig.noiseGateThreshold > 0
                ? 'bg-[#15232A] border-[#66E3CB]/40 text-[#66E3CB]'
                : 'bg-[#17212C] border-[#283544] text-[#A2AFBF] hover:text-white'
            }`}
            title="Configure real-time Web Audio API High-Pass filter, noise gate threshold, and room calibration"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Web Audio ANC:</span>
            <span className="font-bold tabular-nums">
              {dspConfig.noiseGateThreshold > 0 ? `${dspConfig.noiseGateThreshold}%` : 'OFF'}
            </span>
            {showDspPanel ? <ChevronUp className="w-3 h-3 ml-0.5" /> : <ChevronDown className="w-3 h-3 ml-0.5" />}
          </button>

          {/* Communication Diagnostics Modal Trigger */}
          <button
            type="button"
            onClick={() => setIsDiagnosticsOpen(true)}
            className="px-2.5 py-1.5 rounded-lg bg-[#17212C] border border-[#283544] hover:border-[#66E3CB]/50 text-xs font-mono text-[#A2AFBF] hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Open Communication Pipeline & Audio Diagnostics"
          >
            <Stethoscope className="w-3.5 h-3.5 text-[#66E3CB]" />
            <span className="hidden md:inline">Diagnostics</span>
          </button>

          <button
            onClick={() => {
              const nextMuted = !isTTSMuted;
              setIsTTSMuted(nextMuted);
              if (nextMuted && AudioService.isSpeaking()) {
                AudioService.stopSpeaking();
                setIsTTSPaused(false);
              }
            }}
            className={`p-2 rounded-lg border text-xs transition-colors cursor-pointer ${
              isTTSMuted ? 'bg-[#151E28] border-amber-500/30 text-amber-300' : 'bg-[#17212C] border-[#283544] text-[#A2AFBF] hover:text-white'
            }`}
            title={isTTSMuted ? 'Unmute LORIN voice output' : 'Mute LORIN voice output'}
          >
            {isTTSMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={onSwitchToChat}
            className="px-3 py-1.5 rounded-lg bg-[#17212C] border border-[#283544] hover:bg-[#151E28] text-xs text-[#A2AFBF] hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Switch to Text</span>
          </button>
        </div>
      </div>

      {/* DSP Noise Cancellation & Live Meter Settings Drawer */}
      {showDspPanel && (
        <div className="bg-[#111821] border-b border-[#283544] px-6 py-4 transition-all animate-in slide-in-from-top-2">
          <div className="max-w-5xl mx-auto space-y-4">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#66E3CB]" />
                  <span className="text-xs font-mono font-bold text-white tracking-wide uppercase">
                    Web Audio API Stream Processor (High-Pass + Dynamic Noise Gate)
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#17212C] text-[#66E3CB] border border-[#66E3CB]/30">
                    Butterworth Biquad
                  </span>
                </div>
                <p className="text-[11px] text-[#A2AFBF] font-sans">
                  Initialized strictly upon explicit user interaction to comply with browser audio policies. Real-time ref-based visual meter renders FFT spectral energy and noise gate threshold attenuation.
                </p>
              </div>

              {/* Room Noise Calibration Action */}
              <button
                onClick={handleCalibrateNoiseFloor}
                disabled={!isMicActive || isCalibrating}
                className="px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#1f2d3d] border border-[#66E3CB]/40 hover:border-[#66E3CB] text-xs font-mono text-[#66E3CB] flex items-center gap-2 disabled:opacity-40 transition-colors cursor-pointer shrink-0"
                title="Measure 1.5s of silent room background noise to auto-tune noise gate threshold"
              >
                <Wand2 className="w-3.5 h-3.5" />
                <span>{isCalibrating ? `Calibrating (${calibrationProgress}%)...` : 'Auto-Tune Noise Floor'}</span>
              </button>
            </div>

            {/* Interactive DSP Controls & Visual Meter Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              {/* 1. High-Pass Filter Card */}
              <div className="p-3 rounded-xl bg-[#17212C] border border-[#283544] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-white font-semibold flex items-center gap-1.5">
                    <Filter className="w-3.5 h-3.5 text-[#66E3CB]" />
                    <span>High-Pass Filter:</span>
                  </span>
                  <button
                    onClick={handleToggleHighpass}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border transition-colors cursor-pointer ${
                      dspConfig.enableHighpass
                        ? 'bg-[#15232A] border-[#66E3CB] text-[#66E3CB]'
                        : 'bg-[#111821] border-[#283544] text-[#738297]'
                    }`}
                  >
                    {dspConfig.enableHighpass ? 'ACTIVE' : 'BYPASS'}
                  </button>
                </div>
                <div className="flex items-center justify-between text-[11px] font-mono text-[#A2AFBF]">
                  <span>Cutoff Frequency:</span>
                  <strong className="text-white">{dspConfig.highpassFreq} Hz</strong>
                </div>
                <div className="flex items-center gap-1">
                  {[40, 60, 85, 120, 180].map((f) => (
                    <button
                      key={f}
                      onClick={() => handleSetHighpassFreq(f)}
                      className={`flex-1 py-1 text-[10px] font-mono rounded border transition-colors cursor-pointer ${
                        dspConfig.highpassFreq === f
                          ? 'bg-[#66E3CB] text-slate-950 font-bold border-[#66E3CB]'
                          : 'bg-[#111821] border-[#283544] text-[#A2AFBF] hover:text-white'
                      }`}
                    >
                      {f}Hz
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Noise Gate Threshold Card */}
              <div className="p-3 rounded-xl bg-[#17212C] border border-[#283544] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-white font-semibold flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-[#66E3CB]" />
                    <span>Noise Gate Threshold:</span>
                  </span>
                  <strong className="text-[#66E3CB]">{dspConfig.noiseGateThreshold}% ({thresholdDbfs} dBFS)</strong>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50"
                  step="1"
                  value={dspConfig.noiseGateThreshold}
                  onChange={(e) => handleSetNoiseGate(parseInt(e.target.value, 10))}
                  className="w-full accent-[#66E3CB] cursor-pointer"
                />
                <div className="flex items-center justify-between text-[10px] font-mono text-[#738297]">
                  <span>0% (Open)</span>
                  <span>12% (Studio)</span>
                  <span>25% (Office)</span>
                  <span>50% (Max)</span>
                </div>
              </div>

              {/* 3. Ref-based Real-Time Visual Signal & Gate Meter */}
              <div className="p-3 rounded-xl bg-[#17212C] border border-[#283544] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-white font-semibold flex items-center gap-1.5">
                    <Gauge className="w-3.5 h-3.5 text-[#66E3CB]" />
                    <span>Real-Time Level Meter:</span>
                  </span>
                  <span className={isGateSuppressed ? 'text-amber-300 font-mono' : 'text-emerald-400 font-mono font-bold'}>
                    {isMicActive ? `${rmsDbfs} dBFS` : 'Offline'}
                  </span>
                </div>
                <div className="relative w-full h-3 bg-[#111821] rounded-full overflow-hidden border border-[#283544]">
                  <div
                    ref={levelBarRef}
                    className="h-full transition-all duration-75 bg-[#66E3CB]"
                    style={{ width: `${dbfsToPercent(rmsDbfs)}%` }}
                  />
                  <div
                    ref={gateMarkerRef}
                    className="absolute top-0 bottom-0 w-0.5 bg-rose-400 z-10"
                    style={{ left: `${dbfsToPercent(thresholdDbfs)}%` }}
                    title={`Gate Cutoff: ${thresholdDbfs} dBFS`}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] font-mono text-[#A2AFBF]">
                  <span>Gate State:</span>
                  <strong className={isGateSuppressed ? 'text-amber-400' : 'text-emerald-400'}>
                    {isGateSuppressed ? 'CLOSED (Gated -46dB)' : `OPEN (Gain: ${currentGain})`}
                  </strong>
                </div>
              </div>
            </div>

            {/* Live FFT Canvas & Oscilloscope Spectrum */}
            {isMicActive && (
              <div className="rounded-xl overflow-hidden border border-[#283544] bg-[#0E1520] p-2 space-y-1.5">
                <div className="flex items-center justify-between px-1 text-[10px] font-mono text-[#A2AFBF]">
                  <span className="flex items-center gap-1.5 text-white">
                    <Layers className="w-3 h-3 text-[#66E3CB]" />
                    <span>Live Analyser FFT & Waveform Meter</span>
                  </span>
                  <span>20Hz — 20kHz Spectrum</span>
                </div>
                <canvas
                  ref={meterCanvasRef}
                  width={640}
                  height={72}
                  className="w-full h-18 rounded bg-[#0E1520] block"
                />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main Stage Canvas */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-6 max-w-3xl mx-auto w-full overflow-y-auto">
        {/* Error Notice */}
        {errorMessage && (
          <div className="w-full p-4 rounded-xl bg-rose-950/30 border border-rose-500/40 text-rose-200 text-xs flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
              <div className="space-y-1">
                <div className="font-semibold">Voice / Audio Pipeline Notice</div>
                <div>{errorMessage}</div>
                <div className="text-[11px] text-[#A2AFBF]">
                  You can record a Cloud Voice Clip (Gemini 3.5 Transcribe) or use the text prompt below at any time.
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setErrorMessage(null)}
              className="text-[11px] font-mono text-rose-300 hover:text-white px-2 py-1 rounded border border-rose-500/30 cursor-pointer shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Calibration Toast */}
        {calibrationToast && (
          <div className="w-full p-3 rounded-xl bg-[#15232A] border border-[#66E3CB]/40 text-[#66E3CB] text-xs font-mono flex items-center gap-2 shadow-xl animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-[#66E3CB] shrink-0" />
            <span>{calibrationToast}</span>
          </div>
        )}

        {/* Live Audio & Noise Suppression Status Badge */}
        {isMicActive && (
          <div className="flex items-center gap-2 text-xs font-mono">
            {isGateSuppressed ? (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-950/30 border border-amber-500/40 text-amber-300">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span>Ambient Noise Gated ({rmsDbfs} dBFS &lt; {thresholdDbfs} dBFS)</span>
              </span>
            ) : audioVolume > 0 ? (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/30 border border-emerald-500/40 text-emerald-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>Speech Active ({rmsDbfs} dBFS • Gain {currentGain})</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#17212C] border border-[#283544] text-[#738297]">
                <Activity className="w-3.5 h-3.5 text-[#66E3CB]" />
                <span>Web Audio High-Pass ({dspConfig.highpassFreq}Hz) & Gate Armed</span>
              </span>
            )}
          </div>
        )}

        {/* Character presence synchronized with CommunicationManager and voice audio levels */}
        <div className="relative flex items-center justify-center">
          <LorinCharacter
            state={activeCharacterState}
            presentation="expanded"
            environment="voice"
            audioLevel={isMicActive && activeCharacterState === 'LISTENING' ? audioVolume : 0}
            isSpeaking={activeCharacterState === 'SPEAKING' || voiceState === 'SPEAKING'}
            showControls={true}
          />
        </div>

        {/* Real-time Transcription & LORIN Speech Feedback */}
        <div className="w-full space-y-4">
          {(transcript || interimText) && (
            <div className="p-4 rounded-xl bg-[#111821] border border-[#283544] text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono text-[#738297]">Spoken Transcript:</span>
                <span className="text-[10px] font-mono text-[#66E3CB]">
                  {interactionMode === 'MODE_A_DICTATION' ? 'Mode A (Review in box below)' : 'Mode B (Auto-Sent)'}
                </span>
              </div>
              <p className="text-[#F1F5F9] font-medium leading-relaxed">
                {transcript} <span className="text-[#66E3CB] italic">{interimText}</span>
              </p>
            </div>
          )}

          {lorinResponse && (
            <div className="p-4 rounded-xl bg-[#17212C] border border-[#3A4B5F] text-xs space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-[11px] font-mono text-[#A9B8FF] font-semibold">LORIN Voice Output:</span>
                <div className="flex items-center gap-2">
                  {(voiceState === 'SPEAKING' || commSnapshot.state === 'speaking') && (
                    <>
                      <button
                        type="button"
                        onClick={handlePauseOrResumeTTS}
                        className="px-2 py-1 rounded bg-[#111821] border border-[#283544] text-[10px] font-mono text-[#66E3CB] hover:text-white flex items-center gap-1 cursor-pointer"
                      >
                        {isTTSPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
                        <span>{isTTSPaused ? 'Resume' : 'Pause'}</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleStopTTS}
                        className="px-2 py-1 rounded bg-rose-950/40 border border-rose-500/40 text-[10px] font-mono text-rose-300 hover:text-white flex items-center gap-1 cursor-pointer"
                      >
                        <Square className="w-3 h-3" />
                        <span>Stop Speaking</span>
                      </button>
                    </>
                  )}
                </div>
              </div>
              <p className="text-slate-200 leading-relaxed font-sans">{lorinResponse}</p>
            </div>
          )}
        </div>

        {/* Primary Interaction Controls: Live Session + Universal Cloud Voice Clip Recorder */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          {!isMicActive ? (
            <button
              type="button"
              onClick={handleStartSessionClick}
              className="px-6 py-3 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-sm flex items-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
            >
              <Mic className="w-4 h-4" />
              <span>Start Live Voice Session</span>
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={toggleMicMute}
                className={`p-3.5 rounded-xl border text-sm transition-all cursor-pointer ${
                  voiceState === 'MUTED'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-[#17212C] border-[#283544] text-white hover:bg-[#151E28]'
                }`}
                title={voiceState === 'MUTED' ? 'Unmute microphone' : 'Mute microphone'}
              >
                {voiceState === 'MUTED' ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 text-[#66E3CB]" />}
              </button>

              <button
                type="button"
                onClick={handleEndSession}
                className="px-5 py-3 rounded-xl bg-rose-600/90 hover:bg-rose-500 text-white font-semibold text-xs flex items-center gap-2 shadow-md transition-colors cursor-pointer"
              >
                <PhoneOff className="w-4 h-4" />
                <span>End Voice Session</span>
              </button>
            </div>
          )}

          {/* Universal Cloud Voice Clip Recorder (MediaRecorder -> /api/audio/transcribe with gemini-3.5-transcribe) */}
          <button
            type="button"
            onClick={handleToggleCloudClipRecording}
            disabled={isTranscribingClip}
            className={`px-4 py-3 rounded-xl border font-mono text-xs flex items-center gap-2 transition-all cursor-pointer ${
              isRecordingClip
                ? 'bg-rose-600 text-white border-rose-400 animate-pulse font-bold'
                : isTranscribingClip
                ? 'bg-[#17212C] border-[#3A4B5F] text-[#66E3CB] opacity-80'
                : 'bg-[#17212C] hover:bg-[#1f2d3d] border-[#3A4B5F] text-[#F1F5F9]'
            }`}
            title="Record an audio clip using MediaRecorder and transcribe on the server via Gemini 3.5 Transcribe"
          >
            {isTranscribingClip ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-[#66E3CB]" />
                <span>Transcribing Cloud Clip...</span>
              </>
            ) : isRecordingClip ? (
              <>
                <Square className="w-4 h-4 fill-current" />
                <span>Stop & Transcribe Clip</span>
              </>
            ) : (
              <>
                <Cloud className="w-4 h-4 text-[#66E3CB]" />
                <span>Record Cloud Voice Clip</span>
              </>
            )}
          </button>
        </div>

        {/* Editable Voice Prompt / Mode A Review & Text Fallback Form */}
        <form onSubmit={handleFallbackSubmit} className="w-full relative mt-2">
          <input
            type="text"
            value={fallbackInput}
            onChange={(e) => setFallbackInput(e.target.value)}
            placeholder={
              interactionMode === 'MODE_A_DICTATION'
                ? 'Mode A Review Box: Spoken transcript appears here for review/editing before pressing Send...'
                : 'Or type/edit a voice prompt directly and press Send...'
            }
            className="w-full bg-[#111821] border border-[#283544] rounded-xl px-4 py-3 pr-24 text-xs text-white placeholder-[#738297] focus:outline-none focus:border-[#66E3CB]"
          />
          <button
            type="submit"
            disabled={!fallbackInput.trim()}
            className="absolute right-2 top-2 px-3 py-1.5 rounded-lg bg-[#17212C] border border-[#3A4B5F] hover:bg-[#283544] disabled:opacity-40 text-xs text-[#66E3CB] font-mono transition-colors cursor-pointer"
          >
            Send
          </button>
        </form>
      </div>

      {/* Communication Diagnostics Modal */}
      <CommunicationDiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
      />
    </div>
  );
};
