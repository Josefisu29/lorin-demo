import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  AlertTriangle, 
  ShieldCheck, 
  ChevronDown, 
  ChevronUp, 
  Cpu, 
  Sparkles,
  Layers,
  FileCheck,
  Search
} from 'lucide-react';
import { LorinCompletionReport, WorkflowStage } from '../types/lorin';

interface WorkflowProgressIndicatorProps {
  isLoading: boolean;
  currentReport: LorinCompletionReport | null;
  pendingApprovalsCount: number;
}

export const WorkflowProgressIndicator: React.FC<WorkflowProgressIndicatorProps> = ({
  isLoading,
  currentReport,
  pendingApprovalsCount,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Compute active stage based on LORIN state
  let currentStage: WorkflowStage = 'IDLE';
  let stageDescription = 'Awaiting new objective or query';

  if (isLoading) {
    currentStage = 'SPECIALIST_SYNTHESIS';
    stageDescription = 'Coordinating specialists: Lena (Security), Owen (Task), Nolan (Architecture), Iris (Evidence)';
  } else if (pendingApprovalsCount > 0 || currentReport?.status === 'AWAITING_APPROVAL') {
    currentStage = 'APPROVAL_GATE';
    stageDescription = 'Action halted at Phase 2 Security Gate: Cryptographic owner approval required';
  } else if (currentReport?.status === 'VERIFIED') {
    currentStage = 'VERIFIED';
    stageDescription = 'Acceptance criteria met and formally verified by Iris';
  } else if (currentReport?.status === 'COMPLETED') {
    currentStage = 'VERIFIED';
    stageDescription = 'Task synthesized and verified across all specialist perspectives';
  }

  const STAGES: { id: WorkflowStage; label: string; icon: any; shortDesc: string }[] = [
    { id: 'DISCOVER', label: 'Discover', icon: Search, shortDesc: 'Context & Invariant Ingestion' },
    { id: 'INSPECT', label: 'Inspect', icon: Layers, shortDesc: 'Knowledge Vault & Memory Retrieval' },
    { id: 'SECURITY_EVAL', label: 'Security Eval', icon: ShieldCheck, shortDesc: 'Lena Trust Boundary & RBAC' },
    { id: 'SPECIALIST_SYNTHESIS', label: 'Synthesis', icon: Sparkles, shortDesc: 'Owen & Nolan Architecture' },
    { id: 'APPROVAL_GATE', label: 'Approval Gate', icon: AlertTriangle, shortDesc: 'Action-Bound SHA-256 Digest' },
    { id: 'VERIFIED', label: 'Verified', icon: FileCheck, shortDesc: 'Iris Evidence & Delivery' },
  ];

  // Calculate stage progress status
  const getStageStatus = (stageId: WorkflowStage) => {
    if (isLoading) {
      if (stageId === 'DISCOVER' || stageId === 'INSPECT' || stageId === 'SECURITY_EVAL') return 'completed';
      if (stageId === 'SPECIALIST_SYNTHESIS') return 'active';
      return 'pending';
    }

    if (currentStage === 'APPROVAL_GATE') {
      if (stageId === 'APPROVAL_GATE') return 'warning';
      if (stageId === 'VERIFIED') return 'pending';
      return 'completed';
    }

    if (currentStage === 'VERIFIED') {
      return 'completed';
    }

    return 'idle';
  };

  return (
    <div className="border-b border-[#283544] bg-[#0E1520]/95 backdrop-blur-xs select-none">
      <div className="max-w-4xl mx-auto px-6 py-2.5">
        <div className="flex items-center justify-between gap-4">
          {/* Left: Active Workflow Stage summary */}
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className={`w-2 h-2 rounded-full shrink-0 ${
              isLoading ? 'bg-[#66E3CB] animate-ping' :
              currentStage === 'APPROVAL_GATE' ? 'bg-amber-400' :
              currentStage === 'VERIFIED' ? 'bg-emerald-400' :
              'bg-[#738297]'
            }`} />

            <div className="flex items-center gap-2 text-xs font-mono truncate">
              <span className="text-[#738297] text-[11px]">Workflow:</span>
              <span className={`font-bold tracking-tight ${
                isLoading ? 'text-[#66E3CB]' :
                currentStage === 'APPROVAL_GATE' ? 'text-amber-400' :
                currentStage === 'VERIFIED' ? 'text-emerald-400' :
                'text-[#A2AFBF]'
              }`}>
                {isLoading ? 'STAGE 4/6: SPECIALIST SYNTHESIS' :
                 currentStage === 'APPROVAL_GATE' ? 'GATE HALTED: ACTION APPROVAL REQUIRED' :
                 currentStage === 'VERIFIED' ? 'STAGE 6/6: DELIVERED & VERIFIED' :
                 'READY / STANDBY'}
              </span>

              <span className="text-[#3A4B5F] hidden sm:inline">|</span>
              <span className="text-[11px] text-[#A2AFBF] truncate hidden sm:inline">
                {stageDescription}
              </span>
            </div>
          </div>

          {/* Right: Expand details toggle button */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-[#17212C] hover:bg-[#283544] text-[11px] font-mono text-[#A2AFBF] hover:text-white transition-colors shrink-0"
            title="Inspect workflow pipeline"
          >
            <span>{isExpanded ? 'Hide Pipeline' : 'Inspect Pipeline'}</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Linear Stepper Bar */}
        <div className="grid grid-cols-6 gap-1.5 mt-2">
          {STAGES.map((s) => {
            const status = getStageStatus(s.id);
            return (
              <div key={s.id} className="group relative">
                <div
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    status === 'active' ? 'bg-[#66E3CB] animate-pulse shadow-sm shadow-[#66E3CB]/40' :
                    status === 'warning' ? 'bg-amber-400 shadow-sm shadow-amber-400/40' :
                    status === 'completed' ? 'bg-emerald-500' :
                    'bg-[#1C2735]'
                  }`}
                />
              </div>
            );
          })}
        </div>

        {/* Detailed Pipeline Breakdown Drawer */}
        {isExpanded && (
          <div className="mt-3 pt-3 border-t border-[#283544]/60 grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs font-mono">
            {STAGES.map((s, index) => {
              const status = getStageStatus(s.id);
              const Icon = s.icon;
              return (
                <div
                  key={s.id}
                  className={`p-2 rounded-lg border transition-all ${
                    status === 'active' ? 'bg-[#17212C] border-[#66E3CB]/50 text-white' :
                    status === 'warning' ? 'bg-amber-950/20 border-amber-500/40 text-amber-300' :
                    status === 'completed' ? 'bg-[#111821] border-emerald-500/30 text-slate-200' :
                    'bg-[#111821]/60 border-[#283544] text-[#738297]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-[#738297]">0{index + 1}</span>
                    <Icon className={`w-3.5 h-3.5 ${
                      status === 'active' ? 'text-[#66E3CB]' :
                      status === 'warning' ? 'text-amber-400' :
                      status === 'completed' ? 'text-emerald-400' :
                      'text-[#3A4B5F]'
                    }`} />
                  </div>
                  <div className="font-bold text-[11px] truncate">{s.label}</div>
                  <div className="text-[9px] text-[#A2AFBF] line-clamp-2 mt-0.5 font-sans leading-tight">
                    {s.shortDesc}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
