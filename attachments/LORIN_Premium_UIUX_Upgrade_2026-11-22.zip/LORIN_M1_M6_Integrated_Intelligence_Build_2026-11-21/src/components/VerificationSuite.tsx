import React, { useState, useEffect } from 'react';
import { CheckCircle2, XCircle, Play, RefreshCw, Shield, Layers, Database } from 'lucide-react';
import { TestResult } from '../types/lorin';
import { VerificationRunner } from '../services/verificationRunner';

export const VerificationSuite: React.FC = () => {
  const [tests, setTests] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'Phase 1 Core' | 'Phase 2 Security' | 'Phase 3 Memory' | 'Phase 4 Live Services' | 'Phase 4 Multimodal' | 'Phase 4 Knowledge'>('ALL');
  const [lastRunTime, setLastRunTime] = useState<string | null>(null);

  const runSuite = async () => {
    setIsRunning(true);
    try {
      const results = await VerificationRunner.runAllTests();
      setTests(results);
      setLastRunTime(new Date().toLocaleTimeString());
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    // Run tests once on mount for immediate evidence
    runSuite();
  }, []);

  const filteredTests = tests.filter(t => {
    if (activeFilter === 'ALL') return true;
    return t.phase === activeFilter;
  });

  const passedCount = tests.filter(t => t.status === 'PASSED').length;
  const failedCount = tests.filter(t => t.status === 'FAILED').length;

  return (
    <div className="lorin-module-page flex-1 overflow-y-auto bg-[#090d16] p-4 sm:p-6 space-y-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header Summary */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <h1 className="text-lg font-bold text-white tracking-tight">Phase 1–4 Automated Verification Suite</h1>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              19 programmatic assertions enforcing Iris evidence criteria, Phase 2 security boundaries, Phase 3 memory isolation, Phase 4 Live Services, Web Audio API processor, PWA compliance, and Tri-Domain Search.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {lastRunTime && (
              <span className="text-xs font-mono text-slate-500">
                Last Run: <span className="text-slate-300">{lastRunTime}</span>
              </span>
            )}
            <button
              onClick={runSuite}
              disabled={isRunning}
              className="px-4 py-2 rounded bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-bold text-xs flex items-center gap-2 transition-colors"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Running Assertions...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Run Verification Suite</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Aggregate Test Scoreboard */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-lg bg-[#0e1626] border border-slate-800 space-y-1">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Total Tests</span>
            <div className="text-2xl font-bold font-mono text-white tabular-nums">{tests.length}</div>
            <div className="text-[11px] text-slate-500">19 programmatic assertions</div>
          </div>

          <div className="p-4 rounded-lg bg-[#0e1626] border border-slate-800 space-y-1">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Passed Criteria</span>
            <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">{passedCount}</div>
            <div className="text-[11px] text-emerald-500">All invariants verified</div>
          </div>

          <div className="p-4 rounded-lg bg-[#0e1626] border border-slate-800 space-y-1">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Failures Detected</span>
            <div className="text-2xl font-bold font-mono text-rose-400 tabular-nums">{failedCount}</div>
            <div className="text-[11px] text-slate-500">{failedCount === 0 ? 'Zero regression defects' : 'Review failed assertions'}</div>
          </div>

          <div className="p-4 rounded-lg bg-[#0e1626] border border-slate-800 space-y-1">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Execution Time</span>
            <div className="text-2xl font-bold font-mono text-sky-400 tabular-nums">
              {tests.reduce((acc, t) => acc + (t.durationMs || 0), 0)}ms
            </div>
            <div className="text-[11px] text-slate-500">Fast deterministic check</div>
          </div>
        </div>

        {/* Phase Filter Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs flex-wrap">
          <span className="text-slate-500 font-mono text-[11px] mr-2">Filter Phase:</span>
          {(['ALL', 'Phase 1 Core', 'Phase 2 Security', 'Phase 3 Memory', 'Phase 4 Live Services', 'Phase 4 Multimodal', 'Phase 4 Knowledge'] as const).map(ph => (
            <button
              key={ph}
              onClick={() => setActiveFilter(ph)}
              className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                activeFilter === ph
                  ? 'bg-slate-800 text-white font-bold border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              {ph}
            </button>
          ))}
        </div>

        {/* Test List Matrix */}
        <div className="space-y-3">
          {filteredTests.map((test) => (
            <div
              key={test.id}
              className={`p-4 rounded-lg border text-xs space-y-3 transition-colors ${
                test.status === 'PASSED'
                  ? 'bg-[#0e1626] border-slate-800 hover:border-slate-700'
                  : 'bg-rose-950/20 border-rose-500/40'
              }`}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    {test.status === 'PASSED' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span className="font-bold text-sm text-white">{test.name}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                      {test.phase}
                    </span>
                  </div>
                  <p className="text-slate-400 text-xs">{test.description}</p>
                </div>

                <div className="text-right shrink-0">
                  <span className={`px-2.5 py-1 rounded font-mono font-bold text-xs ${
                    test.status === 'PASSED'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                  }`}>
                    {test.status}
                  </span>
                  <div className="text-[10px] font-mono text-slate-500 mt-1 tabular-nums">
                    {test.durationMs}ms
                  </div>
                </div>
              </div>

              {/* Code assertion block */}
              <div className="p-2.5 rounded bg-slate-950 border border-slate-800/80 font-mono text-[11px] text-sky-300">
                <span className="text-slate-500">Assertion: </span>
                <code>{test.assertion}</code>
              </div>

              {/* Details & Rationale */}
              <div className="text-[11px] text-slate-400 font-sans flex items-center justify-between">
                <span>{test.details}</span>
                <span className="text-slate-600 font-mono text-[10px]">ID: {test.id}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
