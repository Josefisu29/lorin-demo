import React, { useState, useRef, useEffect } from 'react';
import { ModelRegistryService } from '../services/modelRegistry';
import { DatasetLabService } from '../services/datasetLab';
import { MosairaPersona } from '../types/mosaira';
import { Send, Sparkles, RefreshCw, Copy, Check, Sliders, Shield, Info, CornerDownLeft } from 'lucide-react';
import { getAuthHeaders } from '../services/authHeaders';

interface Props {
  initialPersonaId?: string;
}

interface ChatTurn {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  personaId?: string;
  modelUsed?: string;
  latencyMs?: number;
  inputTokens?: number;
  outputTokens?: number;
}

export const MosairaPlayground: React.FC<Props> = ({ initialPersonaId = 'NOVA' }) => {
  const personas = ModelRegistryService.getPersonas();
  const [selectedPersonaId, setSelectedPersonaId] = useState<string>(initialPersonaId);
  const selectedPersona = ModelRegistryService.getPersona(selectedPersonaId) || personas[0];

  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState<ChatTurn[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Model parameters
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(2048);
  const [showSettings, setShowSettings] = useState(false);
  const [showConsentModal, setShowConsentModal] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isStreaming]);

  const handleSend = async () => {
    if (!prompt.trim() || isStreaming) return;

    const userTurn: ChatTurn = {
      id: `turn_${Date.now()}_usr`,
      role: 'user',
      content: prompt.trim(),
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userTurn]);
    const currentPrompt = prompt.trim();
    setPrompt('');
    setIsStreaming(true);

    const assistantTurnId = `turn_${Date.now()}_ast`;
    const initialAssistantTurn: ChatTurn = {
      id: assistantTurnId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      personaId: selectedPersona.id,
      modelUsed: selectedPersona.underlyingModelId
    };

    setMessages(prev => [...prev, initialAssistantTurn]);

    const t0 = performance.now();

    try {
      const res = await fetch('/api/mosaira/infer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          personaId: selectedPersona.id,
          personaName: selectedPersona.humanName,
          systemInstruction: selectedPersona.systemInstruction,
          model: selectedPersona.underlyingModelId,
          prompt: currentPrompt,
          stream: true
        })
      });

      if (!res.ok) {
        throw new Error(`Inference service returned status ${res.status}`);
      }

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = '';
      let buffer = '';
      let actualModel: string | undefined;
      let actualLatencyMs: number | undefined;
      let inputTokenCount: number | undefined;
      let outputTokenCount: number | undefined;

      const consumeEvents = (chunk: string) => {
        for (const eventBlock of chunk.split(/\r?\n\r?\n/)) {
          for (const line of eventBlock.split(/\r?\n/)) {
            if (!line.startsWith('data: ')) continue;
            const data = JSON.parse(line.slice(6));
            if (data.type === 'chunk' && typeof data.text === 'string') {
              fullText += data.text;
              setMessages(prev => prev.map(m => (m.id === assistantTurnId ? { ...m, content: fullText } : m)));
            } else if (data.type === 'done') {
              actualModel = typeof data.modelUsed === 'string' ? data.modelUsed : undefined;
              actualLatencyMs = Number.isFinite(data.latencyMs) ? data.latencyMs : undefined;
              inputTokenCount = Number.isFinite(data.inputTokenCount) ? data.inputTokenCount : undefined;
              outputTokenCount = Number.isFinite(data.outputTokenCount) ? data.outputTokenCount : undefined;
            } else if (data.type === 'error') {
              throw new Error(data.error || 'Provider inference failed.');
            }
          }
        }
      };

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          buffer += decoder.decode(value || new Uint8Array(), { stream: !done });
          const eventEnd = /\r?\n\r?\n/g;
          let match: RegExpExecArray | null;
          while ((match = eventEnd.exec(buffer))) {
            const eventBlock = buffer.slice(0, match.index);
            buffer = buffer.slice(match.index + match[0].length);
            eventEnd.lastIndex = 0;
            consumeEvents(eventBlock);
          }
          if (done) break;
        }
      }

      if (buffer.trim()) consumeEvents(buffer);
      if (!actualModel) throw new Error('Inference finished without actual provider/model attribution.');

      setMessages(prev =>
        prev.map(m =>
          m.id === assistantTurnId
            ? {
                ...m,
                modelUsed: actualModel,
                latencyMs: actualLatencyMs ?? Math.round(performance.now() - t0),
                ...(inputTokenCount === undefined ? {} : { inputTokens: inputTokenCount }),
                ...(outputTokenCount === undefined ? {} : { outputTokens: outputTokenCount })
              }
            : m
        )
      );
    } catch (err: any) {
      setMessages(prev =>
        prev.map(m =>
          m.id === assistantTurnId
            ? { ...m, content: `Error executing inference with ${selectedPersona.humanName}: ${err.message || 'Service unavailable'}` }
            : m
        )
      );
    } finally {
      setIsStreaming(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleResetSession = () => {
    setMessages([]);
  };

  return (
    <div className="space-y-4">
      {/* Playground Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-500" />
            MOSAIRA AI Playground
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Test and converse with 10 human-named AI personas using real model streaming inference.
          </p>
        </div>

        {/* Persona Selector & Parameter Toggle */}
        <div className="flex items-center gap-2">
          <select
            value={selectedPersonaId}
            onChange={e => setSelectedPersonaId(e.target.value)}
            className="py-1.5 px-3 text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            {personas.map(p => (
              <option key={p.id} value={p.id}>
                {p.humanName} ({p.id}) — {p.title.split('&')[0]}
              </option>
            ))}
          </select>

          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
            title="Model Parameters"
          >
            <Sliders className="w-4 h-4" />
          </button>

          <button
            onClick={handleResetSession}
            className="p-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
            title="Reset Session"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Slide-out Parameter Controls */}
      {showSettings && (
        <div className="p-4 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div>
            <div className="flex justify-between font-medium text-slate-700 dark:text-slate-300 mb-1">
              <span>Temperature</span>
              <span className="font-mono tabular-nums">{temperature}</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={temperature}
              onChange={e => setTemperature(parseFloat(e.target.value))}
              className="w-full accent-indigo-600"
            />
          </div>

          <div>
            <div className="flex justify-between font-medium text-slate-700 dark:text-slate-300 mb-1">
              <span>Max Output Tokens</span>
              <span className="font-mono tabular-nums">{maxTokens}</span>
            </div>
            <input
              type="range"
              min="256"
              max="4096"
              step="256"
              value={maxTokens}
              onChange={e => setMaxTokens(parseInt(e.target.value))}
              className="w-full accent-indigo-600"
            />
          </div>
        </div>
      )}

      {/* Active Persona Banner */}
      <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/20 rounded-xl border border-indigo-100 dark:border-indigo-900/40 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${selectedPersona.avatarBg} flex items-center justify-center font-bold text-slate-900 dark:text-slate-100 text-sm`}>
            {selectedPersona.humanName[0]}
          </div>
          <div>
            <span className="font-bold text-slate-900 dark:text-slate-100">
              {selectedPersona.humanName} ({selectedPersona.id})
            </span>
            <p className="text-slate-500 dark:text-slate-400 text-[11px]">
              {selectedPersona.purpose}
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowConsentModal(true)}
          className="flex items-center gap-1 text-[11px] font-medium text-indigo-600 dark:text-indigo-400 hover:underline shrink-0"
        >
          <Shield className="w-3.5 h-3.5" />
          Data Consent
        </button>
      </div>

      {/* Conversation Area */}
      <div className="min-h-[380px] max-h-[500px] overflow-y-auto p-4 bg-slate-50/50 dark:bg-slate-950/40 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
        {messages.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 space-y-2 text-slate-400">
            <Sparkles className="w-8 h-8 text-indigo-400/50" />
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              Start a conversation with {selectedPersona.humanName}
            </p>
            <p className="text-xs max-w-md">
              Ask questions, request code, or brainstorm ideas. Responses use real live model inference with measured performance.
            </p>
          </div>
        ) : (
          messages.map(m => (
            <div
              key={m.id}
              className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-xl p-3.5 text-xs leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                }`}
              >
                <p className="whitespace-pre-wrap">{m.content || (isStreaming ? 'Thinking...' : '')}</p>

                {m.role === 'assistant' && m.latencyMs !== undefined && (
                  <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <div className="flex items-center gap-2">
                      <span className="font-mono tabular-nums">{m.latencyMs}ms</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{m.inputTokens}/{m.outputTokens} tokens</span>
                    </div>
                    <button
                      onClick={() => handleCopy(m.id, m.content)}
                      className="hover:text-slate-600 dark:hover:text-slate-200 flex items-center gap-1"
                    >
                      {copiedId === m.id ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Prompt Composer */}
      <div className="relative">
        <textarea
          rows={3}
          placeholder={`Message ${selectedPersona.humanName} (${selectedPersona.id})...`}
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
          className="w-full p-3 pr-12 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
        />

        <button
          onClick={handleSend}
          disabled={!prompt.trim() || isStreaming}
          className="absolute right-3 bottom-3 p-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-lg transition-colors"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Consent Modal */}
      {showConsentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm flex items-center gap-2">
              <Shield className="w-4 h-4 text-indigo-500" />
              Unbundled Data Consent Settings
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              MOSAIRA respects your privacy. Select explicitly how your contributions may be used:
            </p>

            <div className="space-y-2 text-xs">
              <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={DatasetLabService.getConsent().useForRAGCommons}
                  onChange={e => DatasetLabService.updateConsent({ useForRAGCommons: e.target.checked })}
                  className="accent-indigo-600 rounded"
                />
                <span>Allow inclusion in Public Knowledge Commons (RAG)</span>
              </label>

              <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={DatasetLabService.getConsent().useForInternalEval}
                  onChange={e => DatasetLabService.updateConsent({ useForInternalEval: e.target.checked })}
                  className="accent-indigo-600 rounded"
                />
                <span>Allow internal model quality evaluation</span>
              </label>

              <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={DatasetLabService.getConsent().useForTrainingCandidate}
                  onChange={e => DatasetLabService.updateConsent({ useForTrainingCandidate: e.target.checked })}
                  className="accent-indigo-600 rounded"
                />
                <span>Allow candidate for curated model fine-tuning dataset</span>
              </label>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowConsentModal(false)}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 text-white"
              >
                Save Consent Choices
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
