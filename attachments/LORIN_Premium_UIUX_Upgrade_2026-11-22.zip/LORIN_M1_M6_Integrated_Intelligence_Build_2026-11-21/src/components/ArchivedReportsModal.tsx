import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Archive, 
  ArchiveRestore, 
  Search, 
  X, 
  CheckCircle2, 
  ShieldAlert, 
  Clock, 
  Download, 
  Copy, 
  Check, 
  ExternalLink, 
  Filter, 
  Layers, 
  ChevronDown, 
  ChevronUp, 
  Cpu, 
  FileText,
  AlertTriangle
} from 'lucide-react';
import { ChatMessage, LorinCompletionReport, SpecialistRole } from '../types/lorin';
import { SPECIALISTS } from '../data/specialists';

interface ArchivedReportsModalProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onUnarchiveReport: (messageId: string) => void;
  onJumpToMessage?: (messageId: string) => void;
}

export const ArchivedReportsModal: React.FC<ArchivedReportsModalProps> = ({
  isOpen,
  onClose,
  messages,
  onUnarchiveReport,
  onJumpToMessage,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [expandedReportId, setExpandedReportId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Filter messages that have completion reports and are archived
  const archivedItems = messages.filter(
    (m) => m.completionReport && (m.isArchived || m.completionReport.isArchived)
  );

  // Filter by search query and status filter
  const filteredItems = archivedItems.filter((item) => {
    const report = item.completionReport!;
    const matchesStatus =
      selectedStatusFilter === 'ALL' || report.status === selectedStatusFilter;

    if (!matchesStatus) return false;

    if (!searchQuery.trim()) return true;

    const query = searchQuery.toLowerCase();
    const matchesObjective = report.objective.toLowerCase().includes(query);
    const matchesEvidence = report.verification.evidence.toLowerCase().includes(query);
    const matchesSynthesis = report.rawSynthesis.toLowerCase().includes(query);
    const matchesSpecialists = Object.values(report.specialistBreakdown).some(
      (s) => s.summary.toLowerCase().includes(query) || s.keyInsights.some((k) => k.toLowerCase().includes(query))
    );

    return matchesObjective || matchesEvidence || matchesSynthesis || matchesSpecialists;
  });

  const handleCopySummary = (item: ChatMessage) => {
    const report = item.completionReport!;
    const text = `[LORIN Task Audit Report]
Objective: ${report.objective}
Status: ${report.status} (${report.autonomyLevel})
Completed: ${report.completed.join('; ')}
Verification: ${report.verification.evidence}
Criteria Met: ${report.verification.acceptanceCriteriaMet ? 'YES' : 'NO'}
Backend: ${report.backendUsed} (${report.latencyMs}ms)
Archived At: ${new Date(item.archivedAt || item.timestamp).toLocaleString()}`;

    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExportAllMarkdown = () => {
    if (archivedItems.length === 0) return;
    const dateStr = new Date().toLocaleString();
    let md = `# LORIN Archived Tasks & Completion Reports Audit Trail\n`;
    md += `*Generated on ${dateStr}*\n\n`;
    md += `## Summary Statistics\n`;
    md += `- Total Archived Tasks: ${archivedItems.length}\n`;
    md += `- Filter Applied: ${selectedStatusFilter}\n\n`;
    md += `---\n\n`;

    archivedItems.forEach((item, idx) => {
      const rep = item.completionReport!;
      md += `### ${idx + 1}. ${rep.objective}\n`;
      md += `- **Status**: ${rep.status} | **Autonomy**: ${rep.autonomyLevel}\n`;
      md += `- **Date Completed**: ${new Date(item.timestamp).toLocaleString()}\n`;
      md += `- **Archived On**: ${new Date(item.archivedAt || item.timestamp).toLocaleString()}\n`;
      md += `- **Backend**: ${rep.backendUsed} (${rep.latencyMs}ms)\n\n`;
      md += `#### Completed Milestones\n`;
      rep.completed.forEach((c) => {
        md += `- [x] ${c}\n`;
      });
      md += `\n#### Empirical Verification Evidence\n`;
      md += `> ${rep.verification.evidence}\n`;
      md += `> Acceptance Criteria Met: ${rep.verification.acceptanceCriteriaMet ? 'PASSED' : 'UNMET'}\n\n`;
      md += `#### Raw Synthesis\n${rep.rawSynthesis}\n\n`;
      md += `---\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lorin_task_audit_trail_${Date.now()}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleExportAllJson = () => {
    if (archivedItems.length === 0) return;
    const payload = {
      exportedAt: new Date().toISOString(),
      system: 'LORIN Master Intelligence & Engineering System',
      auditVersion: '1.2',
      totalArchivedTasks: archivedItems.length,
      records: archivedItems.map((item) => ({
        messageId: item.id,
        timestamp: item.timestamp,
        archivedAt: item.archivedAt || item.timestamp,
        completionReport: item.completionReport,
      })),
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lorin_task_audit_trail_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs select-none"
          onClick={onClose}
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-4xl max-h-[88vh] rounded-2xl bg-[#111821] border border-[#283544] shadow-2xl flex flex-col overflow-hidden text-[#F1F5F9]"
            onClick={(e) => e.stopPropagation()}
          >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#283544] flex items-center justify-between bg-[#17212C]/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#0B0F14] border border-[#3A4B5F] flex items-center justify-center text-[#66E3CB]">
              <Archive className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">Archived Task Reports & Audit Trail</h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#66E3CB]/10 text-[#66E3CB] border border-[#66E3CB]/30">
                  {archivedItems.length} Archived
                </span>
              </div>
              <p className="text-xs text-[#A2AFBF] mt-0.5">
                Past completion reports archived to maintain a lean chat feed while preserving verifiable audit history.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {archivedItems.length > 0 && (
              <div className="hidden sm:flex items-center gap-1.5 mr-2">
                <button
                  onClick={handleExportAllMarkdown}
                  className="px-2.5 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[11px] font-mono text-[#A2AFBF] hover:text-white flex items-center gap-1.5 transition-colors"
                  title="Export all archived reports as Markdown"
                >
                  <Download className="w-3.5 h-3.5 text-[#66E3CB]" />
                  <span>Export MD</span>
                </button>
                <button
                  onClick={handleExportAllJson}
                  className="px-2.5 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[11px] font-mono text-[#A2AFBF] hover:text-white flex items-center gap-1.5 transition-colors"
                  title="Export all archived reports as JSON"
                >
                  <FileText className="w-3.5 h-3.5 text-[#A9B8FF]" />
                  <span>Export JSON</span>
                </button>
              </div>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-[#283544] text-[#A2AFBF] hover:text-white transition-colors"
              title="Close modal (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search & Filter Toolbar */}
        <div className="p-3.5 sm:px-5 border-b border-[#283544] bg-[#0B0F14]/70 flex flex-col sm:flex-row gap-2.5 sm:items-center justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#738297] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by objective, verification evidence, or specialist insights..."
              className="w-full bg-[#17212C] border border-[#283544] focus:border-[#66E3CB] pl-9 pr-3 py-1.5 rounded-xl text-xs text-white placeholder-[#738297] focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2 text-[#738297] hover:text-white text-xs"
              >
                Clear
              </button>
            )}
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] font-mono shrink-0">
            {['ALL', 'VERIFIED', 'COMPLETED', 'AWAITING_APPROVAL'].map((st) => (
              <button
                key={st}
                onClick={() => setSelectedStatusFilter(st)}
                className={`px-2.5 py-1 rounded-lg border transition-colors whitespace-nowrap ${
                  selectedStatusFilter === st
                    ? 'bg-[#17212C] text-[#66E3CB] border-[#66E3CB]/40'
                    : 'bg-transparent text-[#738297] hover:text-[#A2AFBF] border-[#283544]'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Content List Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {filteredItems.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-[#17212C] border border-[#283544] flex items-center justify-center text-[#738297] mx-auto">
                <Archive className="w-6 h-6" />
              </div>
              <div className="text-sm font-semibold text-white">
                {archivedItems.length === 0
                  ? 'No Archived Task Reports'
                  : 'No matching archived tasks'}
              </div>
              <p className="text-xs text-[#A2AFBF] max-w-md mx-auto leading-relaxed">
                {archivedItems.length === 0
                  ? 'When completed tasks fill the chat feed, click the Archive button on any report card to declutter the workspace while keeping full cryptographic audit trails here.'
                  : `No archived reports matched the query "${searchQuery}" with status "${selectedStatusFilter}".`}
              </p>
            </div>
          ) : (
            filteredItems.map((item) => {
              const rep = item.completionReport!;
              const isExpanded = expandedReportId === item.id;
              const isCopied = copiedId === item.id;

              return (
                <div
                  key={item.id}
                  className="rounded-xl bg-[#17212C] border border-[#283544] hover:border-[#3A4B5F] transition-all overflow-hidden shadow-sm"
                >
                  {/* Card Header */}
                  <div className="p-4 flex flex-col sm:flex-row sm:items-start justify-between gap-3 bg-[#17212C]">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold border ${
                            rep.status === 'VERIFIED'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                              : rep.status === 'COMPLETED'
                              ? 'bg-teal-500/10 text-[#66E3CB] border-teal-500/30'
                              : rep.status === 'AWAITING_APPROVAL'
                              ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                              : 'bg-[#283544] text-[#A2AFBF] border-[#3A4B5F]'
                          }`}
                        >
                          {rep.status}
                        </span>

                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0B0F14] text-[#A2AFBF] border border-[#283544]">
                          {rep.autonomyLevel.replace('LEVEL_', 'LVL ')}
                        </span>

                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#0B0F14] text-[#738297]">
                          {rep.backendUsed} · {rep.latencyMs}ms
                        </span>

                        <span className="text-[10px] font-mono text-[#738297] flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>Archived {new Date(item.archivedAt || item.timestamp).toLocaleDateString()}</span>
                        </span>
                      </div>

                      <h3 className="text-sm font-semibold text-white leading-snug">
                        {rep.objective}
                      </h3>
                    </div>

                    {/* Action buttons on card header */}
                    <div className="flex items-center gap-1.5 shrink-0 pt-1 sm:pt-0">
                      <button
                        onClick={() => handleCopySummary(item)}
                        className="p-1.5 rounded-lg bg-[#0B0F14] hover:bg-[#283544] border border-[#283544] text-[#A2AFBF] hover:text-white transition-colors"
                        title="Copy task audit summary"
                      >
                        {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => onUnarchiveReport(item.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-[#0B0F14] hover:bg-[#283544] border border-[#283544] text-xs font-mono text-[#66E3CB] hover:border-[#66E3CB]/40 flex items-center gap-1.5 transition-colors"
                        title="Restore this report to active chat feed"
                      >
                        <ArchiveRestore className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Restore to Feed</span>
                      </button>

                      {onJumpToMessage && (
                        <button
                          onClick={() => {
                            onJumpToMessage(item.id);
                            onClose();
                          }}
                          className="p-1.5 rounded-lg bg-[#0B0F14] hover:bg-[#283544] border border-[#283544] text-[#A2AFBF] hover:text-white transition-colors"
                          title="Jump to this message in chat view"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={() => setExpandedReportId(isExpanded ? null : item.id)}
                        className="p-1.5 rounded-lg bg-[#0B0F14] hover:bg-[#283544] border border-[#283544] text-[#A2AFBF] hover:text-white transition-colors"
                        title={isExpanded ? 'Collapse audit details' : 'Expand full audit breakdown'}
                      >
                        {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* Verification Evidence Preview */}
                  <div className="px-4 py-2.5 bg-[#111821] border-t border-[#283544] text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Iris Verification Evidence:</span>
                      </div>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                        rep.verification.acceptanceCriteriaMet 
                          ? 'bg-emerald-500/10 text-emerald-300' 
                          : 'bg-amber-500/10 text-amber-300'
                      }`}>
                        {rep.verification.acceptanceCriteriaMet ? 'Acceptance Criteria Met' : 'Unverified Criteria'}
                      </span>
                    </div>
                    <p className="text-slate-300 font-mono text-[11px] leading-relaxed line-clamp-2">
                      {rep.verification.evidence}
                    </p>
                  </div>

                  {/* Expanded Full Audit Detail */}
                  {isExpanded && (
                    <div className="p-4 bg-[#0B0F14] border-t border-[#283544] space-y-4 animate-fade-in text-xs">
                      {/* Completed Items */}
                      <div className="space-y-1.5">
                        <div className="text-[11px] font-mono text-[#66E3CB] font-bold">Completed Milestones:</div>
                        <ul className="space-y-1 pl-1">
                          {rep.completed.map((c, i) => (
                            <li key={i} className="flex items-start gap-2 text-[#A2AFBF] text-xs">
                              <span className="text-emerald-400 font-bold">✓</span>
                              <span>{c}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Specialist Breakdown */}
                      <div className="space-y-2 pt-2 border-t border-[#283544]/60">
                        <div className="text-[11px] font-mono text-[#A2AFBF] font-bold">
                          Specialist Intelligence Deliberations:
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {(Object.keys(rep.specialistBreakdown) as SpecialistRole[]).map((r) => {
                            const spec = SPECIALISTS[r];
                            const out = rep.specialistBreakdown[r];
                            if (!out) return null;
                            return (
                              <div key={r} className="p-2.5 rounded-lg bg-[#111821] border border-[#283544] space-y-1 text-xs">
                                <div className="flex items-center justify-between font-mono text-[10px]">
                                  <span className="font-bold text-white">{spec.name} ({spec.title})</span>
                                  <span className="text-[#738297]">{spec.domain}</span>
                                </div>
                                <p className="text-slate-300 text-[11px] leading-relaxed">{out.summary}</p>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Proposed Actions / Approvals if any */}
                      {rep.proposedActions && rep.proposedActions.length > 0 && (
                        <div className="p-3 rounded-lg bg-[#111821] border border-amber-500/30 space-y-2">
                          <div className="flex items-center gap-1.5 text-amber-300 font-mono text-[11px] font-bold">
                            <ShieldAlert className="w-3.5 h-3.5" />
                            <span>Action Requests Evaluated ({rep.proposedActions.length}):</span>
                          </div>
                          {rep.proposedActions.map((act) => (
                            <div key={act.id} className="text-[11px] font-mono text-slate-300">
                              <span className="text-white font-bold">{act.action}</span> on <span className="text-[#66E3CB]">{act.resource}</span> ({act.riskLevel} risk)
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Raw Synthesis excerpt */}
                      <div className="pt-2 border-t border-[#283544]/60 space-y-1">
                        <div className="text-[11px] font-mono text-[#738297]">Synthesis Excerpt:</div>
                        <div className="p-2.5 rounded-lg bg-[#111821] text-slate-300 text-[11px] font-mono leading-relaxed max-h-32 overflow-y-auto">
                          {rep.rawSynthesis}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        <div className="p-3.5 px-5 border-t border-[#283544] bg-[#17212C]/60 flex items-center justify-between text-xs text-[#738297] font-mono">
          <span>Showing {filteredItems.length} of {archivedItems.length} archived task records</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#283544] hover:bg-[#3A4B5F] text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
