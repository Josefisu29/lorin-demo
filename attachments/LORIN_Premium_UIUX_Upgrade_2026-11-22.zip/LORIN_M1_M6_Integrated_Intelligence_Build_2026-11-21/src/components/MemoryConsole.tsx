import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Search, 
  Plus, 
  Download, 
  Upload, 
  CheckCircle, 
  Trash2, 
  Edit3, 
  RotateCcw,
  XCircle,
  Check,
  ShieldCheck
} from 'lucide-react';
import { MemoryDomain, MemoryRecord, Principal } from '../types/lorin';
import { MemoryStore } from '../services/memoryStore';

interface MemoryConsoleProps {
  principal: Principal;
  records?: MemoryRecord[];
  onRefreshRecords?: () => void;
  activeProjectId?: string;
}

const DOMAIN_LABELS: Record<MemoryDomain, { label: string; desc: string }> = {
  USER_PREFERENCES: {
    label: 'User Preferences',
    desc: 'Approved operator styles, UI density, communication depth, and approval thresholds'
  },
  PROJECT_REQUIREMENTS: {
    label: 'Project Requirements',
    desc: 'Established invariants, confirmed architectural decisions, and technology baselines'
  },
  TASK_HISTORY: {
    label: 'Task History',
    desc: 'Summaries of executed tasks, completion digests, and verifiable outcomes'
  },
  KNOWLEDGE_BASE: {
    label: 'Knowledge Base',
    desc: 'Approved reference documentation, API contracts, SDK patterns, and schemas'
  },
  OPERATIONAL_LESSONS: {
    label: 'Operational Lessons',
    desc: 'Learned failure modes, regression findings, anti-hallucination rules, and benchmarks'
  }
};

export const MemoryConsole: React.FC<MemoryConsoleProps> = ({
  principal,
  records: externalRecords,
  onRefreshRecords,
  activeProjectId
}) => {
  const [internalRecords, setInternalRecords] = useState<MemoryRecord[]>(() => MemoryStore.getAllRecords());
  const records = externalRecords || internalRecords;

  const refreshAll = () => {
    setInternalRecords(MemoryStore.getAllRecords());
    if (onRefreshRecords) onRefreshRecords();
  };

  useEffect(() => {
    setInternalRecords(MemoryStore.getAllRecords());
    MemoryStore.syncFromBackend().then(() => {
      setInternalRecords(MemoryStore.getAllRecords());
    });
  }, [externalRecords]);

  const [activeDomain, setActiveDomain] = useState<MemoryDomain | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'CONFIRMED' | 'PROPOSED'>('ALL');
  
  // Modal State for adding/editing
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<MemoryRecord | null>(null);
  const [formDomain, setFormDomain] = useState<MemoryDomain>('PROJECT_REQUIREMENTS');
  const [formKey, setFormKey] = useState('');
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formProvenance, setFormProvenance] = useState('');
  const [formStatus, setFormStatus] = useState<'CONFIRMED' | 'PROPOSED'>('CONFIRMED');
  const [formTags, setFormTags] = useState('');
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  const filteredRecords = records.filter(r => {
    if (activeDomain !== 'ALL' && r.domain !== activeDomain) return false;
    if (statusFilter !== 'ALL' && r.status !== statusFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.title.toLowerCase().includes(q) ||
      r.content.toLowerCase().includes(q) ||
      r.key.toLowerCase().includes(q) ||
      r.provenance.toLowerCase().includes(q) ||
      r.tags.some(t => t.toLowerCase().includes(q))
    );
  });

  const proposedCount = records.filter(r => r.status === 'PROPOSED').length;

  const handleOpenAddModal = () => {
    setEditingRecord(null);
    setFormDomain(activeDomain === 'ALL' ? 'PROJECT_REQUIREMENTS' : activeDomain);
    setFormKey(`key_${Date.now().toString(36)}`);
    setFormTitle('');
    setFormContent('');
    setFormProvenance(`Manual entry by ${principal.name} (${principal.role})`);
    setFormStatus('CONFIRMED');
    setFormTags('architecture, invariants');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (rec: MemoryRecord) => {
    setEditingRecord(rec);
    setFormDomain(rec.domain);
    setFormKey(rec.key);
    setFormTitle(rec.title);
    setFormContent(rec.content);
    setFormProvenance(rec.provenance);
    setFormStatus(rec.status);
    setFormTags(rec.tags.join(', '));
    setIsModalOpen(true);
  };

  const handleSaveModal = (e: React.FormEvent) => {
    e.preventDefault();
    const tagsArray = formTags.split(',').map(t => t.trim()).filter(Boolean);

    if (editingRecord) {
      const res = MemoryStore.updateRecord(editingRecord.id, {
        domain: formDomain,
        key: formKey,
        title: formTitle,
        content: formContent,
        provenance: formProvenance,
        status: formStatus,
        tags: tagsArray
      }, principal);
      setActionNotice(res.message);
    } else {
      const res = MemoryStore.createRecord({
        domain: formDomain,
        key: formKey,
        title: formTitle,
        content: formContent,
        provenance: formProvenance,
        status: formStatus,
        tags: tagsArray,
        projectId: activeProjectId
      }, principal);
      setActionNotice(res.message);
    }

    refreshAll();
    setIsModalOpen(false);
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleConfirmSuggestion = (id: string) => {
    const res = MemoryStore.confirmSuggestion(id, principal);
    setActionNotice(res.message);
    refreshAll();
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleRejectSuggestion = (id: string) => {
    const res = MemoryStore.rejectSuggestion(id, principal);
    setActionNotice(res.message);
    refreshAll();
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleDeleteRecord = (id: string) => {
    const res = MemoryStore.deleteRecord(id, principal);
    setActionNotice(res.message);
    refreshAll();
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleExportJson = () => {
    const json = MemoryStore.exportJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lorin_memory_export_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = MemoryStore.importJson(content, principal);
      setActionNotice(res.message);
      refreshAll();
      setTimeout(() => setActionNotice(null), 4000);
    };
    reader.readAsText(file);
  };

  const handleResetDefaults = () => {
    if (!confirmClearAll) {
      setConfirmClearAll(true);
      return;
    }
    const ok = MemoryStore.resetToDefault(principal);
    setConfirmClearAll(false);
    if (ok) {
      setActionNotice('All memories were cleared locally. Cloud deletions are queued until Firestore is reachable; no sample memories were added.');
      refreshAll();
    } else {
      setActionNotice('Permission denied: verified System Owner access is required.');
    }
    setTimeout(() => setActionNotice(null), 3000);
  };

  return (
    <div className="lorin-module-page flex-1 overflow-y-auto bg-[#0B0F14] p-4 sm:p-6 space-y-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header Summary */}
        <div className="flex items-center justify-between border-b border-[#283544] pb-4 flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#17212C] border border-[#3A4B5F] flex items-center justify-center text-[#66E3CB]">
                <Database className="w-4 h-4" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white tracking-tight">Persistent Personal Memory</h1>
                <p className="text-xs text-[#A2AFBF] mt-0.5">
                  Domain-isolated personal memory with provenance tracking, candidate suggestion verification, and strict separation from conversation history and Vault documents.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {proposedCount > 0 && (
              <button
                onClick={() => setStatusFilter(statusFilter === 'PROPOSED' ? 'ALL' : 'PROPOSED')}
                className="px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-300 font-mono text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <span>{proposedCount} Proposed Suggestion{proposedCount > 1 ? 's' : ''}</span>
              </button>
            )}

            <button
              onClick={handleOpenAddModal}
              disabled={principal.role === 'GUEST'}
              className="px-3.5 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] disabled:opacity-40 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Memory</span>
            </button>

            <button
              onClick={handleExportJson}
              className="px-3 py-1.5 rounded-lg bg-[#111821] border border-[#283544] hover:border-[#3A4B5F] text-xs text-[#F1F5F9] flex items-center gap-1.5 transition-colors font-mono cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#66E3CB]" />
              <span>Export</span>
            </button>

            <label className="px-3 py-1.5 rounded-lg bg-[#111821] border border-[#283544] hover:border-[#3A4B5F] text-xs text-[#F1F5F9] flex items-center gap-1.5 transition-colors font-mono cursor-pointer">
              <Upload className="w-3.5 h-3.5 text-[#A9B8FF]" />
              <span>Import</span>
              <input type="file" accept=".json" onChange={handleImportJson} className="hidden" />
            </label>

            {principal.canonicalRole === 'SYSTEM_OWNER' && (
              confirmClearAll ? (
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-rose-400">Clear all account memories?</span>
                  <button onClick={handleResetDefaults} className="px-2 py-1.5 rounded-lg bg-rose-500/15 border border-rose-500/40 text-xs text-rose-300">Confirm</button>
                  <button onClick={() => setConfirmClearAll(false)} className="px-2 py-1.5 rounded-lg border border-[#283544] text-xs text-[#AAB6C5]">Cancel</button>
                </div>
              ) : (
                <button
                  onClick={handleResetDefaults}
                  className="px-2.5 py-1.5 rounded-lg bg-[#111821] border border-[#283544] hover:border-rose-500/40 text-xs text-[#738297] hover:text-rose-400 flex items-center gap-1 cursor-pointer"
                  title="Clear all memories for this account"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )
            )}
          </div>
        </div>

        {/* Action Notice Toast */}
        {actionNotice && (
          <div className="p-3 rounded-xl border border-[#66E3CB]/40 bg-[#17212C] text-[#66E3CB] text-xs font-mono flex items-center justify-between">
            <span>{actionNotice}</span>
            <button onClick={() => setActionNotice(null)} className="text-[#738297] hover:text-white">✕</button>
          </div>
        )}

        {/* Domain Navigation Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs">
          <button
            onClick={() => setActiveDomain('ALL')}
            className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
              activeDomain === 'ALL'
                ? 'bg-[#17212C] border-[#66E3CB] shadow-sm'
                : 'bg-[#111821] border-[#283544] hover:border-[#3A4B5F] text-[#A2AFBF]'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className={`text-[11px] font-bold ${activeDomain === 'ALL' ? 'text-[#66E3CB]' : 'text-white'}`}>
                All Domains
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#0B0F14] text-[#A2AFBF] tabular-nums">
                {records.length}
              </span>
            </div>
            <p className="text-[10px] text-[#738297] line-clamp-2 leading-relaxed">
              Unified view across all 5 personal memory domains
            </p>
          </button>

          {(Object.keys(DOMAIN_LABELS) as MemoryDomain[]).map((dom) => {
            const count = records.filter(r => r.domain === dom).length;
            const isSelected = activeDomain === dom;
            return (
              <button
                key={dom}
                onClick={() => setActiveDomain(dom)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#17212C] border-[#66E3CB] shadow-sm'
                    : 'bg-[#111821] border-[#283544] hover:border-[#3A4B5F] text-[#A2AFBF]'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[11px] font-bold truncate ${isSelected ? 'text-[#66E3CB]' : 'text-white'}`}>
                    {DOMAIN_LABELS[dom].label}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#0B0F14] text-[#A2AFBF] tabular-nums">
                    {count}
                  </span>
                </div>
                <p className="text-[10px] text-[#738297] line-clamp-2 leading-relaxed">
                  {DOMAIN_LABELS[dom].desc}
                </p>
              </button>
            );
          })}
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-3 rounded-xl bg-[#111821] border border-[#283544] text-xs">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-[#738297] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search memory records by title, key, provenance, or tag..."
              className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-1.5 pl-9 text-xs text-white placeholder-[#738297] focus:outline-none focus:border-[#66E3CB]"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[#738297] text-[11px] font-mono">Verification State:</span>
            {(['ALL', 'CONFIRMED', 'PROPOSED'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-mono transition-colors cursor-pointer ${
                  statusFilter === st
                    ? 'bg-[#17212C] text-[#66E3CB] border border-[#3A4B5F] font-bold'
                    : 'text-[#A2AFBF] hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Record Cards Grid */}
        <div className="space-y-3">
          {filteredRecords.length === 0 ? (
            <div className="text-center py-12 p-6 rounded-xl bg-[#111821] border border-[#283544] text-xs text-[#738297] font-mono">
              No memory records found matching your filter criteria.
            </div>
          ) : (
            filteredRecords.map((rec) => (
              <div
                key={rec.id}
                className={`p-4 rounded-xl bg-[#111821] border transition-all text-xs space-y-3 ${
                  rec.status === 'PROPOSED'
                    ? 'border-amber-500/40 bg-[#17212C]/60'
                    : 'border-[#283544] hover:border-[#3A4B5F]'
                }`}
              >
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm text-white">{rec.title}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        rec.status === 'CONFIRMED'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-amber-500/15 text-amber-300 border border-amber-500/40'
                      }`}>
                        {rec.status === 'CONFIRMED' ? 'CONFIRMED MEMORY' : 'CANDIDATE SUGGESTION'}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-[#0B0F14] border border-[#283544] text-[10px] font-mono text-[#A9B8FF]">
                        {DOMAIN_LABELS[rec.domain]?.label || rec.domain}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-[#738297] mt-1">
                      Key: <code className="text-[#A2AFBF]">{rec.key}</code> · ID: {rec.id} · Updated: {new Date(rec.updatedAt).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {rec.status === 'PROPOSED' && principal.role !== 'GUEST' && (
                      <>
                        <button
                          onClick={() => handleConfirmSuggestion(rec.id)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-mono text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                          title="Confirm and promote candidate memory to active LORIN context"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Confirm</span>
                        </button>
                        <button
                          onClick={() => handleRejectSuggestion(rec.id)}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 font-mono text-[11px] flex items-center gap-1 cursor-pointer"
                          title="Reject and discard candidate suggestion"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </>
                    )}

                    {principal.role !== 'GUEST' && (
                      <button
                        onClick={() => handleOpenEditModal(rec)}
                        className="p-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] text-[#A2AFBF] hover:text-white cursor-pointer"
                        title="Edit or correct memory record"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {principal.role === 'OWNER' && (
                      <button
                        onClick={() => handleDeleteRecord(rec.id)}
                        className="p-1.5 rounded-lg bg-[#17212C] hover:bg-rose-950/50 text-[#738297] hover:text-rose-400 cursor-pointer"
                        title="Delete record (Owner Only)"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <p className="text-[#F1F5F9] leading-relaxed text-xs">
                  {rec.content}
                </p>

                <div className="flex items-center justify-between flex-wrap gap-2 text-[11px] font-mono text-[#738297] pt-2 border-t border-[#283544]">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#66E3CB]" />
                    <span>Provenance:</span>
                    <span className="text-[#A2AFBF]">{rec.provenance}</span>
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    {rec.tags.map(t => (
                      <span key={t} className="px-1.5 py-0.5 rounded bg-[#0B0F14] border border-[#283544] text-[#A2AFBF] text-[10px]">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Modal for Add / Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <form
            onSubmit={handleSaveModal}
            className="w-full max-w-lg bg-[#111821] border border-[#3A4B5F] rounded-2xl p-5 space-y-4 text-xs shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-[#283544] pb-3">
              <h3 className="text-sm font-bold text-white">
                {editingRecord ? 'Edit & Correct Memory Record' : 'New Persistent Memory Record'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-[#738297] hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 font-mono">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#A2AFBF] mb-1 font-sans">Memory Domain</label>
                  <select
                    value={formDomain}
                    onChange={(e) => setFormDomain(e.target.value as MemoryDomain)}
                    className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white"
                  >
                    {(Object.keys(DOMAIN_LABELS) as MemoryDomain[]).map((dom) => (
                      <option key={dom} value={dom}>{DOMAIN_LABELS[dom].label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[#A2AFBF] mb-1">Key Identifier</label>
                  <input
                    type="text"
                    required
                    value={formKey}
                    onChange={(e) => setFormKey(e.target.value)}
                    className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white focus:outline-none focus:border-[#66E3CB]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#A2AFBF] mb-1 font-sans">Title</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Zero-Trust Backend Approval Invariant"
                  className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white font-sans focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div>
                <label className="block text-[#A2AFBF] mb-1 font-sans">Record Content</label>
                <textarea
                  required
                  rows={4}
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="State the confirmed preference, requirement, or operational lesson..."
                  className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white font-sans focus:outline-none focus:border-[#66E3CB]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#A2AFBF] mb-1 font-sans">Provenance / Source</label>
                  <input
                    type="text"
                    value={formProvenance}
                    onChange={(e) => setFormProvenance(e.target.value)}
                    className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white font-sans"
                  />
                </div>

                <div>
                  <label className="block text-[#A2AFBF] mb-1 font-sans">Verification Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as 'CONFIRMED' | 'PROPOSED')}
                    className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white"
                  >
                    <option value="CONFIRMED">CONFIRMED (Active in Context)</option>
                    <option value="PROPOSED">PROPOSED (Candidate Suggestion)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[#A2AFBF] mb-1 font-sans">Tags (comma-separated)</label>
                <input
                  type="text"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="security, auth, database"
                  className="w-full bg-[#0B0F14] border border-[#283544] rounded-lg px-3 py-2 text-white font-sans"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#283544]">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-[#283544] text-[#A2AFBF] text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs cursor-pointer"
              >
                {editingRecord ? 'Save Correction' : 'Create Record'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
