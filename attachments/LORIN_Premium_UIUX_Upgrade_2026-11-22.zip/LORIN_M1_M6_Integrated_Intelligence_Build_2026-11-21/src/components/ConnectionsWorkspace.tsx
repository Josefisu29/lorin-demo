import React, { useState, useEffect } from 'react';
import {
  Plug, Shield, RefreshCw, CheckCircle2, AlertTriangle, XCircle
} from 'lucide-react';
import { IntegrationConnector, AutomationPermissionLevel } from '../types/lorin';
import { LaurenVaultService } from '../services/laurenVaultService';
import { GoogleDriveService } from '../services/googleDriveService';

interface ConnectionsWorkspaceProps {
  driveAccessToken: string | null;
  onConnectDrive?: () => void;
}

const PERMISSION_LEVEL_META: Record<AutomationPermissionLevel, { label: string; desc: string; badge: string }> = {
  LEVEL_1_READ_ONLY: {
    label: 'Level 1 — Read-Only Inspection',
    desc: 'Permits non-mutating queries, status probes, and metadata inspection only.',
    badge: 'bg-slate-800 text-slate-300 border-slate-700'
  },
  LEVEL_2_PREPARE_DRAFT: {
    label: 'Level 2 — Assisted Drafts & Proposals',
    desc: 'Can prepare drafts, index local chunks, or synthesize responses without mutating external systems.',
    badge: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30'
  },
  LEVEL_3_ASSISTED_EXECUTION: {
    label: 'Level 3 — Approved Routine Actions',
    desc: 'Permits bounded user-scoped persistence and authorized synchronization within private namespaces.',
    badge: 'bg-teal-500/15 text-[#66E3CB] border-teal-500/30'
  },
  LEVEL_4_HIGH_IMPACT_APPROVAL: {
    label: 'Level 4 — High-Impact (Explicit Owner Approval)',
    desc: 'Requires cryptographic policy token and Lena Guardian verification before each execution.',
    badge: 'bg-amber-500/15 text-amber-300 border-amber-500/30'
  }
};

export const ConnectionsWorkspace: React.FC<ConnectionsWorkspaceProps> = ({
  driveAccessToken,
  onConnectDrive
}) => {
  const [connectors, setConnectors] = useState<IntegrationConnector[]>([
    {
      id: 'conn_gemini_api',
      name: 'Google Gemini Server Proxy',
      category: 'AI_PROVIDER',
      status: 'CONNECTED',
      permissionLevel: 'LEVEL_2_PREPARE_DRAFT',
      scopesGranted: ['models/gemini-3.8-flash', 'models/gemini-3.1-flash-lite', 'server-side-api-key'],
      endpointOrTarget: '/api/gemini/infer',
      lastVerifiedAt: Date.now(),
      statusSummary: 'Checking server proxy health...',
      enabled: true
    },
    {
      id: 'conn_ollama_local',
      name: 'Ollama Local Inference Daemon',
      category: 'AI_PROVIDER',
      status: 'DISCONNECTED',
      permissionLevel: 'LEVEL_2_PREPARE_DRAFT',
      scopesGranted: ['local-http-loopback', 'zero-cloud-egress'],
      endpointOrTarget: LaurenVaultService.getOllamaEndpoint(),
      lastVerifiedAt: Date.now(),
      statusSummary: 'Not probed yet.',
      enabled: true
    },
    {
      id: 'conn_google_drive',
      name: 'Google Drive Workspace API',
      category: 'STORAGE_CLOUD',
      status: driveAccessToken ? 'CONNECTED' : 'DISCONNECTED',
      permissionLevel: 'LEVEL_1_READ_ONLY',
      scopesGranted: ['https://www.googleapis.com/auth/drive.readonly', 'https://www.googleapis.com/auth/drive.file'],
      endpointOrTarget: 'https://www.googleapis.com/drive/v3/files',
      lastVerifiedAt: Date.now(),
      statusSummary: driveAccessToken
        ? 'Live OAuth 2.0 Bearer token active in session.'
        : 'No OAuth access token active. Operating in local demonstration sample mode.',
      enabled: true
    },
    {
      id: 'conn_firestore_vault',
      name: 'Firebase Auth & Private Firestore',
      category: 'DATABASE',
      status: 'CONNECTED',
      permissionLevel: 'LEVEL_3_ASSISTED_EXECUTION',
      scopesGranted: ['users/{uid}/sessions', 'security.rules-enforced', 'owner-allowlist'],
      endpointOrTarget: 'Firebase target not configured',
      lastVerifiedAt: Date.now(),
      statusSummary: 'Not configured. Requires owner-supplied Firebase project and verified Firestore rules.',
      enabled: false
    },
    {
      id: 'conn_device_media',
      name: 'Browser WebAudio, Speech & Camera Media',
      category: 'HARDWARE_MEDIA',
      status: 'CONNECTED',
      permissionLevel: 'LEVEL_1_READ_ONLY',
      scopesGranted: ['navigator.mediaDevices.getUserMedia', 'WebSpeechAPI', 'HardwareTrackMute'],
      endpointOrTarget: 'Browser Hardware MediaStream',
      lastVerifiedAt: Date.now(),
      statusSummary: 'Hardware track gating enabled (muting disables MediaStreamTrack.enabled).',
      enabled: true
    },
    {
      id: 'conn_policy_engine',
      name: 'Server Policy & Audit Control Plane',
      category: 'DEVELOPER_TOOL',
      status: 'CONNECTED',
      permissionLevel: 'LEVEL_4_HIGH_IMPACT_APPROVAL',
      scopesGranted: ['/api/policy/evaluate', '/api/policy/approve', '/api/policy/record-execution'],
      endpointOrTarget: '/api/policy/state',
      lastVerifiedAt: Date.now(),
      statusSummary: 'Durable server-side approval ledger active.',
      enabled: true
    }
  ]);

  const [isProbing, setIsProbing] = useState(false);

  const runLiveDiagnostics = async () => {
    setIsProbing(true);
    const now = Date.now();

    let geminiConnected = false;
    let geminiReason = 'Server unreachable';
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        const data = await res.json();
        geminiConnected = data.providerConnectivityVerified === true && data.liveGeminiAvailable === true;
        geminiReason = geminiConnected
          ? 'Upstream Gemini inference was verified by the server.'
          : data.geminiConfigured === true
          ? 'Gemini credential is configured, but upstream connectivity has not been tested.'
          : 'GEMINI_API_KEY is not configured on the server.';
      }
    } catch {
      geminiReason = 'Failed to reach /api/health endpoint.';
    }

    const ollamaEndpoint = LaurenVaultService.getOllamaEndpoint();
    const ollamaProbe = await LaurenVaultService.probeLocalOllama(ollamaEndpoint);
    const driveToken = driveAccessToken || GoogleDriveService.getAccessToken();

    setConnectors(prev =>
      prev.map(c => {
        if (c.id === 'conn_gemini_api') {
          return {
            ...c,
            status: geminiConnected ? 'CONNECTED' : 'STANDBY',
            lastVerifiedAt: now,
            statusSummary: geminiReason
          };
        }
        if (c.id === 'conn_ollama_local') {
          return {
            ...c,
            endpointOrTarget: ollamaEndpoint,
            status: ollamaProbe.reachable ? 'CONNECTED' : 'DISCONNECTED',
            lastVerifiedAt: now,
            statusSummary: ollamaProbe.reachable
              ? `Connected to local Ollama daemon (${ollamaProbe.models.length} models installed).`
              : `No local Ollama daemon detected at ${ollamaEndpoint}. Strict local mode will block cloud egress.`
          };
        }
        if (c.id === 'conn_google_drive') {
          return {
            ...c,
            status: driveToken ? 'CONNECTED' : 'DISCONNECTED',
            lastVerifiedAt: now,
            statusSummary: driveToken
              ? 'Active Google OAuth Bearer token verified.'
              : 'Disconnected — requires explicit Google OAuth sign-in for live Drive files.'
          };
        }
        return { ...c, lastVerifiedAt: now };
      })
    );

    setIsProbing(false);
  };

  useEffect(() => {
    runLiveDiagnostics();
  }, [driveAccessToken]);

  const handlePermissionChange = (id: string, level: AutomationPermissionLevel) => {
    setConnectors(prev =>
      prev.map(c => (c.id === id ? { ...c, permissionLevel: level } : c))
    );
  };

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] text-[#F1F5F9] overflow-y-auto">
      {/* Header */}
      <div className="px-6 py-4 border-b border-slate-800/80 bg-[#111821]/90 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-[#A9B8FF]">
            <Plug className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white">
              Connections, Scopes & Automation Governance
            </h1>
            <p className="text-xs text-[#AAB6C5]">
              Inspect real-time service connectivity, OAuth scopes, and enforce 4-tier automation permission boundaries.
            </p>
          </div>
        </div>

        <button
          onClick={runLiveDiagnostics}
          disabled={isProbing}
          className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold bg-[#17212C] hover:bg-slate-800 text-white border border-slate-700 transition-colors cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-[#66E3CB] ${isProbing ? 'animate-spin' : ''}`} />
          {isProbing ? 'Probing Endpoints...' : 'Verify All Connections'}
        </button>
      </div>

      {/* Main Content */}
      <div className="p-6 space-y-6 max-w-6xl">
        {/* 4-Tier Automation Governance Legend */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {(Object.keys(PERMISSION_LEVEL_META) as AutomationPermissionLevel[]).map(level => {
            const meta = PERMISSION_LEVEL_META[level];
            return (
              <div key={level} className="p-3.5 rounded-xl bg-[#111821] border border-slate-800/90 space-y-1.5">
                <span className={`inline-block text-[10px] font-mono px-2 py-0.5 rounded border ${meta.badge}`}>
                  {meta.label}
                </span>
                <p className="text-[11px] text-slate-400 leading-relaxed">{meta.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Connectors Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {connectors.map(conn => {
            return (
              <div
                key={conn.id}
                className="p-5 rounded-2xl bg-[#17212C] border border-slate-800 flex flex-col justify-between gap-4"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="text-sm font-bold text-white">{conn.name}</h3>
                      {conn.endpointOrTarget && (
                        <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                          Target: {conn.endpointOrTarget}
                        </div>
                      )}
                    </div>

                    {conn.status === 'CONNECTED' ? (
                      <span className="flex items-center gap-1.5 text-[10px] font-mono px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3" />
                        CONNECTED
                      </span>
                    ) : conn.status === 'STANDBY' ? (
                      <span className="flex items-center gap-1.5 text-[10px] font-mono px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                        <AlertTriangle className="w-3 h-3" />
                        STANDBY / FALLBACK
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5 text-[10px] font-mono px-2.5 py-1 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                        <XCircle className="w-3 h-3" />
                        DISCONNECTED
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 bg-[#111821] p-2.5 rounded-lg border border-slate-800/80">
                    {conn.statusSummary}
                  </p>

                  <div>
                    <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-1.5">
                      Authorized Scopes & Capabilities
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {conn.scopesGranted.map((scope: string, idx: number) => (
                        <span
                          key={idx}
                          className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800"
                        >
                          {scope}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Shield className="w-3.5 h-3.5 text-[#66E3CB]" />
                    <select
                      value={conn.permissionLevel}
                      onChange={e =>
                        handlePermissionChange(conn.id, e.target.value as AutomationPermissionLevel)
                      }
                      className="bg-[#111821] border border-slate-700 rounded-lg px-2.5 py-1 text-[11px] text-slate-200 focus:outline-none focus:border-[#66E3CB]"
                    >
                      <option value="LEVEL_1_READ_ONLY">Level 1: Read-Only</option>
                      <option value="LEVEL_2_PREPARE_DRAFT">Level 2: Assisted Draft</option>
                      <option value="LEVEL_3_ASSISTED_EXECUTION">Level 3: Assisted Execution</option>
                      <option value="LEVEL_4_HIGH_IMPACT_APPROVAL">Level 4: Owner Approval Required</option>
                    </select>
                  </div>

                  {conn.id === 'conn_google_drive' && !driveAccessToken && onConnectDrive && (
                    <button
                      onClick={onConnectDrive}
                      className="px-3 py-1 rounded-lg text-xs font-semibold bg-[#66E3CB] text-[#0B0F14] hover:bg-teal-300 transition-colors cursor-pointer"
                    >
                      Connect Google Drive OAuth
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
