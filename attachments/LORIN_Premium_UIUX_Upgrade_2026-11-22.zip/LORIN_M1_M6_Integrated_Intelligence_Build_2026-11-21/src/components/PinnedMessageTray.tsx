import React, { useState } from 'react';
import { 
  Pin, 
  PinOff, 
  Copy, 
  Check, 
  Sparkles, 
  User, 
  ChevronDown, 
  ChevronUp, 
  Download,
  FileText,
  FileCode
} from 'lucide-react';
import { ChatMessage } from '../types/lorin';

interface PinnedMessageTrayProps {
  pinnedMessages: ChatMessage[];
  onTogglePinMessage: (messageId: string) => void;
  onJumpToMessage?: (messageId: string) => void;
}

export const PinnedMessageTray: React.FC<PinnedMessageTrayProps> = ({
  pinnedMessages,
  onTogglePinMessage,
  onJumpToMessage,
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);

  if (pinnedMessages.length === 0) {
    return null;
  }

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  /**
   * Exports pinned context as structured Markdown documentation
   */
  const handleExportMarkdown = () => {
    const dateStr = new Date().toLocaleString();
    let md = `# LORIN Project Context & Pinned Directives\n`;
    md += `*Exported on ${dateStr} from active session*\n\n`;
    md += `## Pinned Directives Summary\n`;
    md += `- Total Items: ${pinnedMessages.length}\n`;
    md += `- Status: Active across specialist deliberations\n\n`;
    md += `---\n\n`;

    pinnedMessages.forEach((msg, idx) => {
      const type = msg.role === 'user' ? 'User Directive' : 'LORIN Synthesis / Context';
      const time = new Date(msg.timestamp).toLocaleString();
      md += `### ${idx + 1}. [${type}] — ${time}\n\n`;
      md += `${msg.content}\n\n`;
      if (msg.attachedFile) {
        md += `*Attached Asset: ${msg.attachedFile.name} (${Math.round(msg.attachedFile.size / 1024)} KB)*\n\n`;
      }
      md += `---\n\n`;
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lorin_pinned_context_${Date.now()}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };

  /**
   * Exports pinned context as structured JSON
   */
  const handleExportJson = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      collection: 'LORIN Pinned Session Directives',
      totalItems: pinnedMessages.length,
      items: pinnedMessages.map(m => ({
        id: m.id,
        role: m.role,
        content: m.content,
        timestamp: m.timestamp,
        attachedFile: m.attachedFile,
        sourcesCited: m.sourcesCited
      }))
    };

    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lorin_pinned_context_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };

  return (
    <div className="border-b border-[#283544] bg-[#0E1520]/95 backdrop-blur-xs transition-all">
      <div className="max-w-4xl mx-auto px-6 py-2.5">
        {/* Tray Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-md bg-[#66E3CB]/10 border border-[#66E3CB]/30 flex items-center justify-center text-[#66E3CB]">
              <Pin className="w-3 h-3 fill-current" />
            </div>
            <span className="text-xs font-mono font-bold text-white tracking-tight">
              Pinned Context & Directives ({pinnedMessages.length})
            </span>
            <span className="text-[11px] font-mono text-[#738297] hidden sm:inline">
              · Preserved across active session queries
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Export Dropdown Menu Button */}
            <div className="relative">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#17212C] hover:bg-[#283544] border border-[#283544] text-[11px] font-mono text-[#66E3CB] hover:text-white transition-colors"
                title="Export pinned items to file"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Pins</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {showExportMenu && (
                <div className="absolute right-0 mt-1.5 w-44 rounded-xl bg-[#111821] border border-[#3A4B5F] shadow-xl z-50 p-1 text-xs font-mono space-y-1 animate-fade-in">
                  <button
                    onClick={handleExportMarkdown}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-[#17212C] text-[#F1F5F9] flex items-center gap-2 transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5 text-[#66E3CB]" />
                    <span>Markdown (.md)</span>
                  </button>
                  <button
                    onClick={handleExportJson}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-[#17212C] text-[#F1F5F9] flex items-center gap-2 transition-colors"
                  >
                    <FileCode className="w-3.5 h-3.5 text-[#A9B8FF]" />
                    <span>JSON (.json)</span>
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#17212C] hover:bg-[#283544] text-[11px] font-mono text-[#A2AFBF] hover:text-white transition-colors"
            >
              <span>{isExpanded ? 'Collapse Tray' : 'Show Cards'}</span>
              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Pinned Cards Tray */}
        {isExpanded && (
          <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
            {pinnedMessages.map((msg) => (
              <div
                key={msg.id}
                className="p-3 rounded-xl bg-[#111821] border border-[#283544] hover:border-[#3A4B5F] text-xs space-y-2 transition-all flex flex-col justify-between group shadow-sm"
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono pb-1.5 border-b border-[#283544]/60">
                    <span className="flex items-center gap-1.5 font-bold text-[#66E3CB]">
                      {msg.role === 'user' ? (
                        <>
                          <User className="w-3 h-3" />
                          <span>USER DIRECTIVE</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3 h-3 text-[#A9B8FF]" />
                          <span className="text-[#A9B8FF]">LORIN CONTEXT</span>
                        </>
                      )}
                    </span>
                    <span className="text-[#738297] tabular-nums">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <p className="text-[#F1F5F9] line-clamp-3 leading-relaxed mt-2 font-sans select-text">
                    {msg.content}
                  </p>

                  {msg.attachedFile && (
                    <div className="mt-2 flex items-center gap-1.5 text-[10px] font-mono text-[#66E3CB]">
                      <FileText className="w-3 h-3" />
                      <span className="truncate">{msg.attachedFile.name}</span>
                    </div>
                  )}
                </div>

                {/* Card Action Controls: Copy & Explicit 'Remove Pin' Button */}
                <div className="flex items-center justify-between pt-2 border-t border-[#283544]/60 text-[11px] font-mono">
                  <button
                    onClick={() => handleCopy(msg.content, msg.id)}
                    className="flex items-center gap-1 text-[#738297] hover:text-[#A2AFBF] transition-colors"
                    title="Copy context text"
                  >
                    {copiedId === msg.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400 text-[10px]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span className="text-[10px]">Copy</span>
                      </>
                    )}
                  </button>

                  {/* Explicit 'Remove Pin' Button requested by user */}
                  <button
                    onClick={() => onTogglePinMessage(msg.id)}
                    className="flex items-center gap-1 px-2 py-0.5 rounded bg-rose-950/20 hover:bg-rose-900/40 border border-rose-800/40 hover:border-rose-600/60 text-rose-300 text-[10px] font-semibold transition-colors"
                    title="Remove Pin to declutter workspace"
                  >
                    <PinOff className="w-3 h-3 text-rose-400" />
                    <span>Remove Pin</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
