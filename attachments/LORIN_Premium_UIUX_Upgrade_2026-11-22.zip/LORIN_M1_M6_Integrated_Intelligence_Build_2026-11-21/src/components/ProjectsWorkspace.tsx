import React, { useState, useEffect } from 'react';
import {
  FolderKanban, Plus, CheckCircle2, Circle, Clock,
  GitBranch, ShieldCheck, ArrowUpRight, Trash2, Check,
  Code2, FileText, Sparkles
} from 'lucide-react';
import { ProjectRecord, ProjectTask } from '../types/lorin';
import { ProjectStore } from '../services/projectStore';

interface ProjectsWorkspaceProps {
  activeProjectId: string;
  onSelectActiveProject: (projectId: string) => void;
  onOpenChatWithProject?: (projectId: string) => void;
}

export const ProjectsWorkspace: React.FC<ProjectsWorkspaceProps> = ({
  activeProjectId,
  onSelectActiveProject,
  onOpenChatWithProject
}) => {
  const [projects, setProjects] = useState<ProjectRecord[]>(() => ProjectStore.getProjects());
  const [selectedId, setSelectedId] = useState<string>(activeProjectId || projects[0]?.id || '');
  const [showNewModal, setShowNewModal] = useState(false);

  // New project form state
  const [newName, setNewName] = useState('');
  const [newRepoPath, setNewRepoPath] = useState('');
  const [newClassification, setNewClassification] = useState<ProjectRecord['classification']>('INDEPENDENT_PRODUCT');
  const [newDescription, setNewDescription] = useState('');
  const [newStack, setNewStack] = useState('');

  // New task / requirement / decision inputs
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<ProjectTask['priority']>('HIGH');
  const [newRequirement, setNewRequirement] = useState('');
  const [newDecisionTitle, setNewDecisionTitle] = useState('');
  const [newDecisionRationale, setNewDecisionRationale] = useState('');

  useEffect(() => {
    setProjects(ProjectStore.getProjects());
    ProjectStore.syncFromBackend().then(() => {
      const latest = ProjectStore.getProjects();
      setProjects(latest);
      setSelectedId(current =>
        latest.some(project => project.id === current)
          ? current
          : (latest.find(project => project.id === activeProjectId)?.id || latest[0]?.id || '')
      );
    });
  }, [activeProjectId]);

  const selectedProject = projects.find(p => p.id === selectedId) || projects[0];

  const refreshProjects = () => {
    setProjects(ProjectStore.getProjects());
  };

  const handleSetActiveContext = (projectId: string) => {
    ProjectStore.setActiveProjectId(projectId);
    onSelectActiveProject(projectId);
    refreshProjects();
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    const created = ProjectStore.createProject({
      name: newName.trim(),
      classification: newClassification,
      description: newDescription.trim() || 'Independent software engineering project.',
      techStack: newStack.split(',').map(s => s.trim()).filter(Boolean),
      repositoryOrPath: newRepoPath.trim() || undefined
    });
    refreshProjects();
    setSelectedId(created.id);
    handleSetActiveContext(created.id);
    setShowNewModal(false);
    setNewName('');
    setNewRepoPath('');
    setNewDescription('');
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !newTaskTitle.trim()) return;
    ProjectStore.addTask(selectedProject.id, {
      title: newTaskTitle.trim(),
      priority: newTaskPriority,
      status: 'TODO',
      category: 'FEATURE'
    });
    setNewTaskTitle('');
    refreshProjects();
  };

  const handleToggleTask = (taskId: string) => {
    if (!selectedProject) return;
    ProjectStore.toggleTaskStatus(selectedProject.id, taskId);
    refreshProjects();
  };

  const handleAddRequirement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !newRequirement.trim()) return;
    ProjectStore.addRequirement(selectedProject.id, newRequirement.trim());
    setNewRequirement('');
    refreshProjects();
  };

  const handleAddDecision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !newDecisionTitle.trim() || !newDecisionRationale.trim()) return;
    ProjectStore.addDecision(selectedProject.id, {
      title: newDecisionTitle.trim(),
      rationale: newDecisionRationale.trim(),
      status: 'ACCEPTED'
    });
    setNewDecisionTitle('');
    setNewDecisionRationale('');
    refreshProjects();
  };

  const handleDeleteProject = (projectId: string) => {
    ProjectStore.deleteProject(projectId);
    const remaining = ProjectStore.getProjects();
    setProjects(remaining);
    if (selectedId === projectId) {
      setSelectedId(remaining[0]?.id || '');
      if (remaining[0]) handleSetActiveContext(remaining[0].id);
    }
  };

  const getClassificationBadge = (classification: ProjectRecord['classification']) => {
    switch (classification) {
      case 'PRIVATE_CORE':
        return { label: 'Private Core System', color: 'bg-teal-500/15 text-teal-300 border-teal-500/30' };
      case 'PUBLIC_PLATFORM':
        return { label: 'Public AI Platform', color: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30' };
      case 'INDEPENDENT_PRODUCT':
      default:
        return { label: 'Independent Product', color: 'bg-amber-500/15 text-amber-300 border-amber-500/30' };
    }
  };

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] text-[#F1F5F9] overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-slate-800/80 bg-[#111821]/90 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-[#66E3CB]">
            <FolderKanban className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-lg font-bold tracking-tight text-white">Engineering Projects & Context Isolation</h1>
              <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {projects.length} Isolated Contexts
              </span>
            </div>
            <p className="text-xs text-[#AAB6C5]">
              Manage independent software architectures, requirements, tasks, and technical decisions without cross-project contamination.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setShowNewModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold bg-[#66E3CB] text-[#0B0F14] hover:bg-teal-300 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            New Independent Project
          </button>
        </div>
      </div>

      {/* Main Split Layout */}
      <div className="lorin-project-layout flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden min-h-0">
        {/* Left Project List */}
        <div className="lorin-project-list lg:col-span-4 border-r border-slate-800/80 bg-[#111821]/50 overflow-y-auto p-4 space-y-2.5">
          <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 px-1 mb-2">
            Registered Project Environments
          </div>

          {projects.map(proj => {
            const isSelected = proj.id === selectedProject?.id;
            const isActiveContext = proj.id === activeProjectId;
            const badge = getClassificationBadge(proj.classification);
            const completedTasks = proj.tasks.filter(t => t.status === 'DONE').length;

            return (
              <div
                key={proj.id}
                onClick={() => setSelectedId(proj.id)}
                role="button"
                tabIndex={0}
                aria-pressed={isSelected}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    setSelectedId(proj.id);
                  }
                }}
                className={`lorin-project-card p-3.5 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#17212C] border-[#66E3CB]/50 shadow-lg'
                    : 'bg-[#111821]/90 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white">{proj.name}</span>
                      {isActiveContext && (
                        <span className="text-[10px] font-mono text-[#66E3CB]">
                          · Active Context
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">{proj.slug}</span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400">
                    {badge.label}
                  </span>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 mb-3">
                  {proj.description}
                </p>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800/70 font-mono">
                  <span>Tasks: {completedTasks}/{proj.tasks.length}</span>
                  <span aria-hidden="true">·</span>
                  <span>ADRs: {proj.decisions.length}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Project Detail */}
        {selectedProject ? (
          <div className="lorin-project-detail lg:col-span-8 overflow-y-auto p-6 space-y-6 min-h-0">
            {/* Project Top Banner */}
            <div className="p-5 rounded-2xl bg-[#17212C] border border-slate-800 space-y-4">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2.5">
                    <h2 className="text-xl font-bold text-white">{selectedProject.name}</h2>
                    <span className="text-xs font-mono text-[#66E3CB]">
                      {selectedProject.slug}
                    </span>
                  </div>
                  <p className="text-xs text-[#AAB6C5] mt-1 max-w-2xl">
                    {selectedProject.description}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {selectedProject.id === activeProjectId ? (
                    <span className="flex items-center gap-1.5 text-xs font-medium text-[#66E3CB]">
                      <Check className="w-3.5 h-3.5" />
                      Active Context
                    </span>
                  ) : (
                    <button
                      onClick={() => handleSetActiveContext(selectedProject.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 transition-colors cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#66E3CB]" />
                      Set as Active Context
                    </button>
                  )}

                  {onOpenChatWithProject && (
                    <button
                      onClick={() => {
                        handleSetActiveContext(selectedProject.id);
                        onOpenChatWithProject(selectedProject.id);
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#66E3CB] text-[#0B0F14] hover:bg-teal-300 transition-colors cursor-pointer"
                    >
                      Open in Chat
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    onClick={() => handleDeleteProject(selectedProject.id)}
                    title="Delete project"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 border border-transparent hover:border-rose-500/30 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Repository Path & Tech Stack */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3 border-t border-slate-800/80">
                <div className="p-3 rounded-xl bg-[#111821] border border-slate-800/90">
                  <div className="flex items-center gap-1.5 text-[11px] font-semibold text-teal-400 mb-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Workspace Path & Boundary Classification
                  </div>
                  <p className="text-xs text-slate-300 font-mono leading-relaxed">
                    {selectedProject.repositoryOrPath} · {selectedProject.classification}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-[#111821] border border-slate-800/90">
                  <div className="flex items-center gap-1.5 text-[11px] font-semibold text-indigo-300 mb-1.5">
                    <Code2 className="w-3.5 h-3.5" />
                    Designated Technology Stack
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedProject.techStack.map((tech, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800/90 text-slate-200 border border-slate-700"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Tasks & Engineering Backlog */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <div className="p-5 rounded-2xl bg-[#17212C] border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#66E3CB]" />
                    Engineering Tasks & Milestones
                  </h3>
                  <span className="text-[11px] font-mono text-slate-400">
                    {selectedProject.tasks.filter(t => t.status === 'DONE').length} of {selectedProject.tasks.length} Completed
                  </span>
                </div>

                <div className="space-y-2">
                  {selectedProject.tasks.map(task => (
                    <div
                      key={task.id}
                      onClick={() => handleToggleTask(task.id)}
                      role="button"
                      tabIndex={0}
                      aria-label={`${task.status === 'DONE' ? 'Reopen' : 'Complete'} task: ${task.title}`}
                      onKeyDown={(event) => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault();
                          handleToggleTask(task.id);
                        }
                      }}
                      className="lorin-project-task flex items-start justify-between gap-3 p-2.5 rounded-xl bg-[#111821] border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-colors"
                    >
                      <div className="flex items-start gap-2.5">
                        {task.status === 'DONE' ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        ) : task.status === 'IN_PROGRESS' ? (
                          <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        ) : (
                          <Circle className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                        )}
                        <span className={`text-xs ${task.status === 'DONE' ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                          {task.title}
                        </span>
                      </div>
                      <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded shrink-0 ${
                        task.priority === 'CRITICAL' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                        task.priority === 'HIGH' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                        'bg-slate-800 text-slate-400'
                      }`}>
                        {task.priority}
                      </span>
                    </div>
                  ))}
                </div>

                <form onSubmit={handleAddTask} className="flex flex-wrap gap-2 pt-2">
                  <input
                    type="text"
                    value={newTaskTitle}
                    onChange={e => setNewTaskTitle(e.target.value)}
                    placeholder="Add engineering task..."
                    className="min-w-0 flex-1 bg-[#111821] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#66E3CB]"
                  />
                  <select
                    value={newTaskPriority}
                    onChange={e => setNewTaskPriority(e.target.value as ProjectTask['priority'])}
                    className="bg-[#111821] border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-300"
                  >
                    <option value="CRITICAL">Critical</option>
                    <option value="HIGH">High</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="LOW">Low</option>
                  </select>
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] text-xs font-semibold hover:bg-teal-300 cursor-pointer"
                  >
                    Add
                  </button>
                </form>
              </div>

              {/* Project Requirements */}
              <div className="p-5 rounded-2xl bg-[#17212C] border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#A9B8FF]" />
                    Non-Negotiable Project Requirements
                  </h3>
                  <span className="text-[11px] font-mono text-slate-400">
                    {selectedProject.requirements.length} Specs
                  </span>
                </div>

                <ul className="space-y-2">
                  {selectedProject.requirements.map((req, idx) => (
                    <li
                      key={idx}
                      className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#111821] border border-slate-800/80 text-xs text-slate-200"
                    >
                      <span className="text-[10px] font-mono text-[#66E3CB] mt-0.5">0{idx + 1}</span>
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>

                <form onSubmit={handleAddRequirement} className="flex flex-wrap gap-2 pt-2">
                  <input
                    type="text"
                    value={newRequirement}
                    onChange={e => setNewRequirement(e.target.value)}
                    placeholder="Add project requirement or constraint..."
                    className="min-w-0 flex-1 bg-[#111821] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#66E3CB]"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 cursor-pointer"
                  >
                    Add Spec
                  </button>
                </form>
              </div>
            </div>

            {/* Architecture Decision Records (ADRs) */}
            <div className="p-5 rounded-2xl bg-[#17212C] border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <GitBranch className="w-4 h-4 text-amber-400" />
                  Architecture Decision Records (ADRs)
                </h3>
                <span className="text-[11px] font-mono text-slate-400">
                  Verified Engineering History
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {selectedProject.decisions.map(adr => (
                  <div
                    key={adr.id}
                    className="p-3.5 rounded-xl bg-[#111821] border border-slate-800/90 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-white">{adr.title}</span>
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                        {adr.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{adr.rationale}</p>
                    <div className="text-[10px] font-mono text-slate-500">
                      Recorded {new Date(adr.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleAddDecision} className="grid grid-cols-1 md:grid-cols-12 gap-2 pt-2">
                <input
                  type="text"
                  value={newDecisionTitle}
                  onChange={e => setNewDecisionTitle(e.target.value)}
                  placeholder="Decision title (e.g., Use PostgreSQL with Drizzle)..."
                  className="md:col-span-4 bg-[#111821] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#66E3CB]"
                />
                <input
                  type="text"
                  value={newDecisionRationale}
                  onChange={e => setNewDecisionRationale(e.target.value)}
                  placeholder="Technical rationale & trade-offs..."
                  className="md:col-span-6 bg-[#111821] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#66E3CB]"
                />
                <button
                  type="submit"
                  className="md:col-span-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 cursor-pointer"
                >
                  Record ADR
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="lg:col-span-8 flex items-center justify-center p-8 min-h-0">
            <div className="max-w-md text-center space-y-3">
              <div className="mx-auto w-12 h-12 rounded-2xl bg-[#17212C] border border-slate-700 flex items-center justify-center text-[#66E3CB]">
                <FolderKanban className="w-6 h-6" />
              </div>
              <h2 className="text-lg font-semibold text-white">No project registered yet</h2>
              <p className="text-sm text-slate-400">
                Register a project to establish its real repository, technology stack, requirements, tasks and independent context. LORIN will not invent project records or completion history.
              </p>
              <button
                onClick={() => setShowNewModal(true)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold bg-[#66E3CB] text-[#0B0F14] hover:bg-teal-300 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Register first project
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Create New Project Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#17212C] border border-slate-700 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Register Independent Software Project</h3>
              <button
                onClick={() => setShowNewModal(false)}
                className="text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
            </div>
            <p className="text-xs text-slate-300">
              Each registered project maintains its own requirements, architecture decisions, and chat context without inheriting LORIN or MOSAIRA branding or schemas.
            </p>
            <form onSubmit={handleCreateProject} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="e.g., Quantum Ledger API"
                  className="w-full bg-[#111821] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Repository / Path</label>
                  <input
                    type="text"
                    value={newRepoPath}
                    onChange={e => setNewRepoPath(e.target.value)}
                    placeholder="Add the real repository or local path (optional)"
                    className="w-full bg-[#111821] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Classification</label>
                  <select
                    value={newClassification}
                    onChange={e => setNewClassification(e.target.value as ProjectRecord['classification'])}
                    className="w-full bg-[#111821] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                  >
                    <option value="INDEPENDENT_PRODUCT">Independent Product</option>
                    <option value="PUBLIC_PLATFORM">Public Platform</option>
                    <option value="PRIVATE_CORE">Private System</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Architecture Summary & Objectives</label>
                <textarea
                  rows={2}
                  value={newDescription}
                  onChange={e => setNewDescription(e.target.value)}
                  placeholder="Describe the core product purpose and boundaries..."
                  className="w-full bg-[#111821] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Tech Stack (comma-separated)</label>
                <input
                  type="text"
                  value={newStack}
                  onChange={e => setNewStack(e.target.value)}
                  className="w-full bg-[#111821] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
                />
              </div>
              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 rounded-lg text-xs text-slate-300 hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-xs font-semibold bg-[#66E3CB] text-[#0B0F14] hover:bg-teal-300 cursor-pointer"
                >
                  Create Isolated Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
