/**
 * Centralized public brand configuration (working name: MOSAIRA).
 * Change name/tagline/colours/metadata here — do not hard-code across components.
 * Lauren / LORIN remains a separate private identity and must not reuse this brand.
 */
export const PUBLIC_BRAND = {
  workingName: 'MOSAIRA',
  pronunciation: 'moh-SAI-rah',
  tagline: 'One space. Many intelligences.',
  positioning:
    'A modern AI model ecosystem for discovering, using, comparing and responsibly improving multiple AI systems in one place.',
  legalStatus: 'provisional' as const,
  alternateCandidates: [
    'AURENZA',
    'ELVORA',
    'VELORA',
    'MOSAERA',
    'AVENOR',
    'LUMORA',
    'NOVARA',
    'ARVENA',
    'SOLVIRA',
    'ORIEL'
  ],
  colors: {
    midnight: '#0D1220',
    deepSurface: '#151C2B',
    raisedSurface: '#1C2638',
    lightCanvas: '#F5F7FB',
    darkText: '#202A3A',
    lightText: '#EAF0F7',
    indigo: '#8D83F6',
    aqua: '#62D9CF',
    warmHighlight: '#E9B76B'
  },
  social: {
    // Placeholders only — do not publish until owner approval + clearance
    website: '',
    twitter: '',
    github: ''
  }
} as const;

export const PRIVATE_ASSISTANT = {
  displayName: 'Lauren',
  systemName: 'LORIN',
  productType: 'private_personal_assistant' as const,
  publicDiscoverable: false,
  colors: {
    graphite: '#0B0F14',
    navy: '#121826',
    teal: '#2DD4BF',
    indigo: '#818CF8'
  }
} as const;
