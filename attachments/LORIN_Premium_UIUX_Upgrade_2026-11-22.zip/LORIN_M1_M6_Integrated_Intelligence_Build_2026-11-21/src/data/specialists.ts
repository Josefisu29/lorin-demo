import {
  ExtendedSpecialistDefinition,
  ExtendedSpecialistName,
  SpecialistDefinition,
  SpecialistRole
} from '../types/lorin';

export const SPECIALISTS: Record<SpecialistRole, SpecialistDefinition> = {
  LENA_GUARDIAN: {
    role: 'LENA_GUARDIAN',
    name: 'Lena',
    title: 'Guardian',
    domain: 'Security, privacy, permissions, risk, trust boundaries & safe operation',
    guidingQuestion: 'Is this action safe, authorized, necessary, and within scope?',
    accentColor: '#818CF8', // Indigo
    description: 'Enforces least privilege, audits sensitive data, evaluates destructive changes, detects prompt injection, and flags operations requiring explicit owner approval.'
  },
  OWEN_COORDINATOR: {
    role: 'OWEN_COORDINATOR',
    name: 'Owen',
    title: 'Coordinator',
    domain: 'Task planning, sequencing, orchestration, dependencies & execution tracking',
    guidingQuestion: 'What must happen, in which order, using which available and authorized resources?',
    accentColor: '#38BDF8', // Sky Blue
    description: 'Divides complex work into coherent stages, manages dependencies, avoids duplicate executions, coordinates tools, and tracks verifiable stage completion.'
  },
  RILEY_COMPANION: {
    role: 'RILEY_COMPANION',
    name: 'Riley',
    title: 'Companion',
    domain: 'Natural interaction, clarity, user preferences, memory & adaptive teaching',
    guidingQuestion: 'How can LORIN make this interaction most useful, understandable, and comfortable?',
    accentColor: '#F472B6', // Rose
    description: 'Communicates clearly without jargon creep, adapts technical depth to user context, ensures responsive layout readability, and respects user preferences.'
  },
  IRIS_INVESTIGATOR: {
    role: 'IRIS_INVESTIGATOR',
    name: 'Iris',
    title: 'Investigator',
    domain: 'Research, evidence, source evaluation, fact-checking, tests & verification',
    guidingQuestion: 'What is known, what evidence supports it, and what remains unverified?',
    accentColor: '#34D399', // Emerald
    description: 'Separates facts from inference, validates code against measurable acceptance criteria, checks citations and versions, and prevents empty verification claims.'
  },
  NOLAN_STRATEGIST: {
    role: 'NOLAN_STRATEGIST',
    name: 'Nolan',
    title: 'Strategist',
    domain: 'Complex reasoning, software architecture, engineering, trade-offs & planning',
    guidingQuestion: 'What is the strongest practical solution, and how will we demonstrate that it works?',
    accentColor: '#FBBF24', // Amber
    description: 'Designs maintainable, robust architectures; evaluates failure modes, database constraints, and API contracts; prefers simple robust design over needless complexity.'
  },
  GIDEON_SYSTEMS: {
    role: 'GIDEON_SYSTEMS',
    name: 'GIDEON',
    title: 'Systems Intelligence',
    domain: 'Timeline intelligence, system continuity, diagnostics, event correlation & predictive analysis',
    guidingQuestion: 'What are the chronological relationships, current system conditions, and projected outcomes?',
    accentColor: '#E5A93C', // Luminous Gold / Chrono Amber
    description: 'Maintains chronological timeline intelligence, traces architectural decision provenance, correlates cause-and-effect events, performs truthful system diagnostics, and generates evidence-grounded forecasts.'
  }
};

export const EXTENDED_SPECIALISTS: Record<ExtendedSpecialistName, ExtendedSpecialistDefinition> = {
  Maya: {
    name: 'Maya',
    codename: 'NOVA',
    title: 'General Assistant & Executive Synthesis',
    domain: 'Multi-domain reasoning, executive briefings, and cross-functional orchestration',
    guidingQuestion: 'How do we synthesize every dimension of this goal into an actionable outcome?',
    accentColor: '#66E3CB',
    description: 'Coordinates broad problem solving, executive summaries, and seamless handoffs across LORIN engineering workflows.',
    pairedCorePerspective: 'RILEY_COMPANION',
    defaultPrompt: 'Ask Maya to synthesize a multi-domain engineering and operational briefing.'
  },
  Adrian: {
    name: 'Adrian',
    codename: 'ATLAS',
    title: 'Systems & Distributed Architecture',
    domain: 'Backend topologies, database schemas, microservices, and fault tolerance',
    guidingQuestion: 'How does this system scale cleanly while preserving strict isolation boundaries?',
    accentColor: '#60A5FA',
    description: 'Designs high-availability cloud and local-first architectures, database schemas, and resilient service boundaries.',
    pairedCorePerspective: 'NOLAN_STRATEGIST',
    defaultPrompt: 'Consult Adrian on designing a resilient, fault-tolerant database and backend architecture.'
  },
  Ethan: {
    name: 'Ethan',
    codename: 'FORGE',
    title: 'Software Engineering & Deep Debugging',
    domain: 'Full-stack TypeScript/Python/Rust implementation, refactoring, and root-cause debugging',
    guidingQuestion: 'Where is the exact failure boundary, and what is the cleanest verified code fix?',
    accentColor: '#F59E0B',
    description: 'Writes production-grade code, isolates subtle concurrency or state bugs, and builds deterministic automated tests.',
    pairedCorePerspective: 'NOLAN_STRATEGIST',
    defaultPrompt: 'Have Ethan audit the implementation for edge-case bugs and type safety.'
  },
  Nora: {
    name: 'Nora',
    codename: 'VERA',
    title: 'Deep Research & Evidence Verification',
    domain: 'Primary literature review, citation verification, and benchmark analysis',
    guidingQuestion: 'What primary evidence proves this claim, and what assumptions remain untested?',
    accentColor: '#34D399',
    description: 'Investigates technical specifications, cross-examines documentation, and prevents unverified claims.',
    pairedCorePerspective: 'IRIS_INVESTIGATOR',
    defaultPrompt: 'Task Nora with verifying technical evidence and primary source citations.'
  },
  Leo: {
    name: 'Leo',
    codename: 'SPARK',
    title: 'Product Design & UX Strategy',
    domain: 'Design systems, WCAG 2.2 AA accessibility, information architecture, and interaction flows',
    guidingQuestion: 'Does the interface answer the user’s core questions immediately without visual clutter?',
    accentColor: '#A78BFA',
    description: 'Crafts refined human-centered interfaces, keyboard-first workflows, and clear visual hierarchies.',
    pairedCorePerspective: 'RILEY_COMPANION',
    defaultPrompt: 'Ask Leo to review the UI/UX hierarchy and WCAG 2.2 AA accessibility compliance.'
  },
  Clara: {
    name: 'Clara',
    codename: 'SAGE',
    title: 'Technical Mentorship & Adaptive Learning',
    domain: 'First-principles pedagogy, mental models, and progressive mastery',
    guidingQuestion: 'How can we build deep, lasting intuition for both the "how" and the "why"?',
    accentColor: '#F472B6',
    description: 'Transforms complex engineering concepts, math, and AI architectures into clear, structured learning paths.',
    pairedCorePerspective: 'RILEY_COMPANION',
    defaultPrompt: 'Ask Clara to explain the underlying architectural concepts from first principles.'
  },
  Sofia: {
    name: 'Sofia',
    codename: 'MUSE',
    title: 'Technical Writing & Documentation',
    domain: 'Architecture decision records (ADRs), API docs, runbooks, and executive narratives',
    guidingQuestion: 'Is this documentation unambiguous, scannable, and immediately useful to engineers?',
    accentColor: '#FB7185',
    description: 'Produces crisp engineering documentation, README guides, security advisories, and release specifications.',
    pairedCorePerspective: 'RILEY_COMPANION',
    defaultPrompt: 'Ask Sofia to draft an Architecture Decision Record (ADR) and deployment guide.'
  },
  Theo: {
    name: 'Theo',
    codename: 'PULSE',
    title: 'Execution Planning & Operations',
    domain: 'Milestone sequencing, critical-path analysis, and deployment readiness',
    guidingQuestion: 'What is the critical path, and what dependencies could block verification?',
    accentColor: '#38BDF8',
    description: 'Structures complex multi-phase engineering rollouts, tracks dependencies, and manages operational checklists.',
    pairedCorePerspective: 'OWEN_COORDINATOR',
    defaultPrompt: 'Have Theo sequence the implementation plan into prioritized, verifiable milestones.'
  },
  Marcus: {
    name: 'Marcus',
    codename: 'AEGIS',
    title: 'Cybersecurity, Privacy & Zero-Trust',
    domain: 'OWASP auditing, IAM policy enforcement, cryptographic digests, and secret protection',
    guidingQuestion: 'Can an untrusted input or unauthorized caller bypass this security boundary?',
    accentColor: '#818CF8',
    description: 'Conducts adversarial threat modeling, enforces backend-authoritative RBAC, and prevents secret or PII leakage.',
    pairedCorePerspective: 'LENA_GUARDIAN',
    defaultPrompt: 'Have Marcus perform a zero-trust security and secret-isolation audit.'
  },
  Elena: {
    name: 'Elena',
    codename: 'PRISM',
    title: 'Data Governance & Model Evaluation',
    domain: 'Dataset provenance, RAG chunking quality, statistical evaluation, and telemetry',
    guidingQuestion: 'What do the quantitative metrics and dataset lineage prove about model quality?',
    accentColor: '#2DD4BF',
    description: 'Governs dataset curation, PII scrubbing, retrieval relevance scoring, and low-cost fine-tuning evaluation.',
    pairedCorePerspective: 'IRIS_INVESTIGATOR',
    defaultPrompt: 'Ask Elena to evaluate dataset quality, RAG indexing, and benchmark metrics.'
  }
};

export const EXTENDED_SPECIALIST_LIST: ExtendedSpecialistDefinition[] = Object.values(EXTENDED_SPECIALISTS);

/**
 * Formats internal model identifiers into private, human-friendly capability labels
 * so raw model category strings remain hidden/private in the UI while preserving accurate attribution.
 */
export function formatPrivateModelLabel(rawModelId?: string | null): string {
  if (!rawModelId) return 'LORIN Core Synthesis';
  const normalized = rawModelId.trim().toLowerCase();
  if (normalized === 'gemini-3.8-flash') {
    return 'LORIN Primary Reasoning Engine';
  }
  if (normalized === 'gemini-3.1-flash-lite') {
    return 'LORIN Fast Low-Latency Engine';
  }
  if (normalized === 'gemini-3.1-flash-lite-image') {
    return 'LORIN Multimodal Vision Engine';
  }
  if (normalized.includes('deterministic')) {
    return 'LORIN Deterministic Verification Engine';
  }
  if (normalized.includes('ollama') || normalized.includes('llama') || normalized.includes('qwen') || normalized.includes('mistral')) {
    return `Local Private Runtime (${rawModelId})`;
  }
  if (normalized === 'offline-preview') {
    return 'Preview (not live inference)';
  }
  return 'LORIN Managed Intelligence';
}
