/**
 * MOSAIRA AI Lab Data Types
 * Enterprise AI Operations, Dataset Governance, Pipeline & Model Training
 */

export type DatasetSource = 'GOOGLE_DRIVE' | 'LOCAL_UPLOAD' | 'COMMONS_IMPORT';
export type DatasetFormat = 'JSONL' | 'CSV' | 'MARKDOWN' | 'TXT' | 'PDF';
export type PiiScanStatus = 'CLEAN' | 'ANONYMIZED' | 'REQUIRES_SCAN';
export type DatasetStatus = 'READY' | 'INGESTING' | 'PROCESSING' | 'ERROR';

export interface LabDataset {
  id: string;
  name: string;
  description: string;
  source: DatasetSource;
  format: DatasetFormat;
  sizeBytes: number;
  rowCount: number;
  piiStatus: PiiScanStatus;
  license: string;
  tags: string[];
  status: DatasetStatus;
  createdAt: number;
  googleDriveFileId?: string;
  sampleRows?: Record<string, any>[];
}

export type PipelineStageId = 
  | 'IMPORT'
  | 'SCHEMA_VALIDATION'
  | 'PII_ANONYMIZATION'
  | 'TEXT_EXTRACTION'
  | 'DEDUPLICATION'
  | 'CHUNKING'
  | 'EMBEDDING';

export type PipelineStageStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'SKIPPED';

export interface PipelineStage {
  id: PipelineStageId;
  name: string;
  status: PipelineStageStatus;
  durationMs: number;
  itemsProcessed: number;
  details?: string;
}

export interface PipelineJob {
  id: string;
  datasetId: string;
  datasetName: string;
  stages: PipelineStage[];
  status: 'IDLE' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  totalChunks: number;
  piiEntitiesRedacted: number;
  deduplicatedCount: number;
  startedAt: number;
  completedAt?: number;
}

export interface KnowledgeIndex {
  id: string;
  name: string;
  description: string;
  vectorDimension: number;
  modelName: string;
  docCount: number;
  totalChunks: number;
  isPublic: boolean;
  status: 'READY' | 'INDEXING' | 'STALE';
  lastUpdated: number;
}

export interface TrainingHyperparameters {
  learningRate: number;
  loraRank: number;
  loraAlpha: number;
  epochs: number;
  batchSize: number;
  warmupRatio: number;
}

export type TrainingStatus = 'PREPARED' | 'QUEUED' | 'TRAINING' | 'COMPLETED' | 'FAILED';

export interface TrainingLossPoint {
  epoch: number;
  loss: number;
  evalLoss?: number;
}

export interface TrainingJob {
  id: string;
  name: string;
  baseModel: string;
  targetPersona: string;
  datasetId: string;
  datasetName: string;
  hyperparameters: TrainingHyperparameters;
  status: TrainingStatus;
  currentEpoch: number;
  totalEpochs: number;
  lossHistory: TrainingLossPoint[];
  checkpointPath: string;
  startedAt?: number;
  completedAt?: number;
  errorMessage?: string;
}

export interface EvaluationBenchmark {
  name: string;
  category: string;
  score: number;
  targetScore: number;
  status: 'PASSED' | 'FAILED';
}

export interface EvaluationSuite {
  id: string;
  modelId: string;
  modelName: string;
  runAt: number;
  overallScore: number;
  benchmarks: EvaluationBenchmark[];
  hallucinationRatePct: number;
  avgLatencyMs: number;
  sampleOutputs: {
    prompt: string;
    baseOutput: string;
    fineTunedOutput: string;
    reasoning: string;
  }[];
}

export type ModelDeploymentStage = 'EXPERIMENTAL' | 'STAGING' | 'PRODUCTION' | 'ARCHIVED';

export interface RegisteredModel {
  id: string;
  name: string;
  version: string;
  baseModel: string;
  targetPersona: string;
  stage: ModelDeploymentStage;
  evalScore: number;
  parametersCount: string;
  fineTunedAt: number;
  deployedAt?: number;
  rollbackVersion?: string;
  artifactsPath: string;
}

export interface LabAuditRecord {
  id: string;
  timestamp: number;
  actor: string;
  action: string;
  target: string;
  status: 'SUCCESS' | 'WARNING' | 'DENIED';
  details: string;
}
