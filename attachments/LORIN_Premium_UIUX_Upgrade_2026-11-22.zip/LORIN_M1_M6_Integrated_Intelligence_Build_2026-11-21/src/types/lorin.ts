/**
 * LORIN Master Intelligence & Engineering System
 * Core Types & Multimodal Domain Interfaces (Version 2.0)
 */

export type SpecialistRole = 
  | 'LENA_GUARDIAN'
  | 'OWEN_COORDINATOR'
  | 'RILEY_COMPANION'
  | 'IRIS_INVESTIGATOR'
  | 'NOLAN_STRATEGIST'
  | 'GIDEON_SYSTEMS';

export type ExtendedSpecialistName =
  | 'Maya'
  | 'Adrian'
  | 'Ethan'
  | 'Nora'
  | 'Leo'
  | 'Clara'
  | 'Sofia'
  | 'Theo'
  | 'Marcus'
  | 'Elena';

export interface SpecialistDefinition {
  role: SpecialistRole;
  name: string;
  title: string;
  domain: string;
  guidingQuestion: string;
  accentColor: string;
  description: string;
}

export interface ExtendedSpecialistDefinition {
  name: ExtendedSpecialistName;
  codename: string;
  title: string;
  domain: string;
  guidingQuestion: string;
  accentColor: string;
  description: string;
  pairedCorePerspective: SpecialistRole;
  defaultPrompt: string;
}

export type TaskStatus = 
  | 'PROPOSED'
  | 'PREPARED'
  | 'ATTEMPTED'
  | 'COMPLETED'
  | 'VERIFIED'
  | 'FAILED'
  | 'BLOCKED'
  | 'AWAITING_APPROVAL';

export type AutonomyLevel =
  | 'LEVEL_0_OBSERVE'
  | 'LEVEL_1_RECOMMEND'
  | 'LEVEL_2_PREPARE'
  | 'LEVEL_3_EXECUTE_WITH_APPROVAL'
  | 'LEVEL_4_BOUNDED_AUTOMATION';

export type PolicyDecision = 'ALLOW' | 'DENY' | 'REQUIRES_APPROVAL';

/**
 * Canonical 6-Level Role Hierarchy (LORIN V2 Section 3):
 * Level 1 — SYSTEM_OWNER (legacy alias: OWNER)
 * Level 2 — SUPER_ADMIN
 * Level 3 — ADMINISTRATOR
 * Level 4 — SPECIALIST (legacy alias: ENGINEER / OPERATOR)
 * Level 5 — STANDARD_USER (legacy alias: VIEWER)
 * Level 6 — RESTRICTED (legacy alias: GUEST / DISABLED)
 */
export type CanonicalRole =
  | 'SYSTEM_OWNER'
  | 'SUPER_ADMIN'
  | 'ADMINISTRATOR'
  | 'SPECIALIST'
  | 'STANDARD_USER'
  | 'RESTRICTED';

export type LegacyUserRole = 'OWNER' | 'ENGINEER' | 'OPERATOR' | 'VIEWER' | 'GUEST' | 'DISABLED';

export type UserRole = CanonicalRole | LegacyUserRole;

export type AccountStatus = 'ACTIVE' | 'RESTRICTED' | 'DISABLED' | 'REVOKED';

export type CanonicalPermissionScope =
  | 'system.owner.manage'
  | 'system.configuration.manage'
  | 'system.security.manage'
  | 'system.audit.read'
  | 'users.read'
  | 'users.manage'
  | 'roles.read'
  | 'roles.manage'
  | 'providers.read'
  | 'providers.manage'
  | 'models.use'
  | 'models.configure'
  | 'projects.read'
  | 'projects.manage'
  | 'conversations.read'
  | 'conversations.manage'
  | 'memory.read'
  | 'memory.manage'
  | 'knowledge.read'
  | 'knowledge.manage'
  | 'tasks.create'
  | 'tasks.execute'
  | 'tasks.cancel'
  | 'integrations.manage'
  | 'approvals.review'
  | 'backups.manage'
  | 'gideon.access'
  | 'gideon.timeline.read'
  | 'gideon.timeline.write'
  | 'gideon.diagnostics.read'
  | 'gideon.predictions.create'
  | 'gideon.scenarios.create';

/**
 * Section 5 Centralized Permission System Scopes (LorinPermission)
 * Compatible with all CanonicalPermissionScope values.
 */
export type LorinPermission =
  | CanonicalPermissionScope
  | 'chat.access'
  | 'voice.access'
  | 'vision.access'
  | 'research.access'
  | 'coding.access'
  | 'knowledge.access'
  | 'projects.access'
  | 'files.manage_own'
  | 'system.read'
  | 'system.manage'
  | 'security.read'
  | 'security.manage'
  | 'audit.read'
  | 'backup.manage'
  | 'device_operations.execute'
  | 'ownership.manage';

export function normalizePermissionScope(permission: CanonicalPermissionScope | LorinPermission): CanonicalPermissionScope {
  switch (permission) {
    case 'chat.access':
    case 'voice.access':
    case 'vision.access':
      return 'models.use';
    case 'research.access':
      return 'gideon.access';
    case 'coding.access':
      return 'tasks.execute';
    case 'knowledge.access':
      return 'knowledge.read';
    case 'projects.access':
      return 'projects.read';
    case 'files.manage_own':
      return 'knowledge.read';
    case 'system.read':
      return 'providers.read';
    case 'system.manage':
      return 'system.configuration.manage';
    case 'security.read':
      return 'system.audit.read';
    case 'security.manage':
      return 'system.security.manage';
    case 'audit.read':
      return 'system.audit.read';
    case 'backup.manage':
      return 'backups.manage';
    case 'device_operations.execute':
      return 'tasks.execute';
    case 'ownership.manage':
      return 'system.owner.manage';
    default:
      return permission;
  }
}

export const ALL_CANONICAL_PERMISSIONS: CanonicalPermissionScope[] = [
  'system.owner.manage',
  'system.configuration.manage',
  'system.security.manage',
  'system.audit.read',
  'users.read',
  'users.manage',
  'roles.read',
  'roles.manage',
  'providers.read',
  'providers.manage',
  'models.use',
  'models.configure',
  'projects.read',
  'projects.manage',
  'conversations.read',
  'conversations.manage',
  'memory.read',
  'memory.manage',
  'knowledge.read',
  'knowledge.manage',
  'tasks.create',
  'tasks.execute',
  'tasks.cancel',
  'integrations.manage',
  'approvals.review',
  'backups.manage',
  'gideon.access',
  'gideon.timeline.read',
  'gideon.timeline.write',
  'gideon.diagnostics.read',
  'gideon.predictions.create',
  'gideon.scenarios.create'
];

export const SUPER_ADMIN_PERMISSIONS: CanonicalPermissionScope[] = ALL_CANONICAL_PERMISSIONS.filter(
  p => p !== 'system.owner.manage'
);

export function normalizeCanonicalRole(
  role?: string | null,
  accountStatus?: AccountStatus
): CanonicalRole {
  if (accountStatus === 'DISABLED' || accountStatus === 'REVOKED' || accountStatus === 'RESTRICTED') {
    return 'RESTRICTED';
  }
  const r = (role || 'GUEST').toUpperCase().trim();
  switch (r) {
    case 'SYSTEM_OWNER':
    case 'OWNER':
      return 'SYSTEM_OWNER';
    case 'SUPER_ADMIN':
      return 'SUPER_ADMIN';
    case 'ADMINISTRATOR':
    case 'ADMIN':
      return 'ADMINISTRATOR';
    case 'SPECIALIST':
    case 'ENGINEER':
    case 'OPERATOR':
      return 'SPECIALIST';
    case 'STANDARD_USER':
    case 'VIEWER':
      return 'STANDARD_USER';
    case 'RESTRICTED':
    case 'DISABLED':
    case 'GUEST':
    default:
      return 'RESTRICTED';
  }
}

export function getRoleHierarchyLevel(role?: string | null, accountStatus?: AccountStatus): 1 | 2 | 3 | 4 | 5 | 6 {
  const canonical = normalizeCanonicalRole(role, accountStatus);
  switch (canonical) {
    case 'SYSTEM_OWNER':
      return 1;
    case 'SUPER_ADMIN':
      return 2;
    case 'ADMINISTRATOR':
      return 3;
    case 'SPECIALIST':
      return 4;
    case 'STANDARD_USER':
      return 5;
    case 'RESTRICTED':
    default:
      return 6;
  }
}

export function getDefaultPermissionsForRole(
  role?: string | null,
  delegatedPermissions: CanonicalPermissionScope[] = [],
  accountStatus: AccountStatus = 'ACTIVE'
): CanonicalPermissionScope[] {
  if (accountStatus === 'DISABLED' || accountStatus === 'REVOKED') {
    return [];
  }
  const canonical = normalizeCanonicalRole(role, accountStatus);
  switch (canonical) {
    case 'SYSTEM_OWNER':
      return [...ALL_CANONICAL_PERMISSIONS];
    case 'SUPER_ADMIN':
      return [...SUPER_ADMIN_PERMISSIONS];
    case 'ADMINISTRATOR': {
      const baseAdmin: CanonicalPermissionScope[] = [
        'users.read',
        'roles.read',
        'providers.read',
        'models.use',
        'projects.read',
        'projects.manage',
        'conversations.read',
        'conversations.manage',
        'memory.read',
        'memory.manage',
        'knowledge.read',
        'knowledge.manage',
        'tasks.create',
        'tasks.execute',
        'tasks.cancel',
        'integrations.manage',
        'approvals.review',
        'system.audit.read',
        'gideon.access',
        'gideon.timeline.read',
        'gideon.timeline.write',
        'gideon.diagnostics.read',
        'gideon.predictions.create',
        'gideon.scenarios.create'
      ];
      const merged = new Set<CanonicalPermissionScope>([
        ...baseAdmin,
        ...delegatedPermissions.filter(p => p !== 'system.owner.manage')
      ]);
      return Array.from(merged);
    }
    case 'SPECIALIST': {
      const baseSpec: CanonicalPermissionScope[] = [
        'providers.read',
        'models.use',
        'projects.read',
        'conversations.read',
        'conversations.manage',
        'memory.read',
        'memory.manage',
        'knowledge.read',
        'knowledge.manage',
        'tasks.create',
        'tasks.execute',
        'tasks.cancel',
        'gideon.access',
        'gideon.timeline.read',
        'gideon.diagnostics.read'
      ];
      const merged = new Set<CanonicalPermissionScope>([
        ...baseSpec,
        ...delegatedPermissions.filter(
          p =>
            p !== 'system.owner.manage' &&
            p !== 'roles.manage' &&
            p !== 'users.manage' &&
            p !== 'system.security.manage'
        )
      ]);
      return Array.from(merged);
    }
    case 'STANDARD_USER': {
      return [
        'models.use',
        'projects.read',
        'conversations.read',
        'conversations.manage',
        'memory.read',
        'knowledge.read',
        'tasks.create',
        'gideon.access',
        'gideon.timeline.read'
      ];
    }
    case 'RESTRICTED':
    default:
      return [];
  }
}

export function isSystemOwnerPrincipal(principal?: Partial<Principal> | null): boolean {
  if (!principal || !principal.authenticated) return false;
  if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') return false;
  return normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus) === 'SYSTEM_OWNER';
}

export function isSuperAdminOrOwnerPrincipal(principal?: Partial<Principal> | null): boolean {
  if (!principal || !principal.authenticated) return false;
  if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') return false;
  const canonical = normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus);
  return canonical === 'SYSTEM_OWNER' || canonical === 'SUPER_ADMIN';
}

/**
 * Section 5 Centralized Permission Helpers
 */
export function isSystemOwner(principal?: Partial<Principal> | null): boolean {
  return isSystemOwnerPrincipal(principal);
}

export function isSuperAdmin(principal?: Partial<Principal> | null): boolean {
  if (!principal || !principal.authenticated) return false;
  if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') return false;
  return normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus) === 'SUPER_ADMIN';
}

export function isPrivilegedUser(principal?: Partial<Principal> | null): boolean {
  return isSuperAdminOrOwnerPrincipal(principal);
}

export function assertAuthenticated(principal?: Partial<Principal> | null): asserts principal is Principal {
  if (!principal || !principal.authenticated || !principal.id || principal.id === 'guest_unverified') {
    throw new Error('Authentication required: principal is not authenticated.');
  }
}

export function assertActiveAccount(principal?: Partial<Principal> | null): asserts principal is Principal {
  assertAuthenticated(principal);
  if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') {
    throw new Error(`Account is ${principal.accountStatus} and cannot perform actions.`);
  }
  if (
    principal.sessionRevokedAt &&
    principal.enrolledAt &&
    principal.enrolledAt <= principal.sessionRevokedAt
  ) {
    throw new Error('Session has been revoked by an administrator. Please re-authenticate.');
  }
  if (principal.sessionExpiresAt && Date.now() > principal.sessionExpiresAt) {
    throw new Error('Session has expired. Please re-authenticate.');
  }
}

export interface Principal {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  canonicalRole?: CanonicalRole;
  accountStatus?: AccountStatus;
  authenticated: boolean;
  emailVerified?: boolean;
  mfaEnabled?: boolean;
  roleVersion?: number;
  enrolledAt: number;
  sessionExpiresAt: number;
  sessionRevokedAt?: number;
  scopes: string[];
  permissions?: CanonicalPermissionScope[];
  delegatedPermissions?: CanonicalPermissionScope[];
  projectScopes?: string[];
  authorizedOwnerEmails?: string[];
}

export interface ManagedUserAccount {
  uid: string;
  email: string;
  displayName: string;
  canonicalRole: CanonicalRole;
  legacyRole: UserRole;
  accountStatus: AccountStatus;
  emailVerified: boolean;
  mfaEnabled?: boolean;
  roleVersion?: number;
  permissions: CanonicalPermissionScope[];
  delegatedPermissions: CanonicalPermissionScope[];
  projectScopes: string[];
  isPrimarySystemOwner?: boolean;
  sessionRevokedAt?: number;
  createdAt: number;
  updatedAt: number;
  lastActiveAt?: number;
  invitedBy?: string;
}

export interface FeatureAccessMatrixRow {
  categoryId: string;
  categoryNumber: number;
  categoryTitle: string;
  description: string;
  requiredPermissions: CanonicalPermissionScope[];
  associatedModules: WorkspaceView[];
  protectedEndpoints: string[];
  roleAccess: Record<CanonicalRole, 'FULL' | 'DELEGATED' | 'SCOPED' | 'LIMITED' | 'NONE'>;
}

export interface SystemControlConfig {
  registrationPolicy: 'INVITE_ONLY' | 'DOMAIN_RESTRICTED' | 'OPEN_STANDARD';
  requireEmailVerification: boolean;
  sessionTimeoutMinutes: number;
  defaultRoutingStrategy: 'LIVE_GEMINI' | 'OLLAMA_CLOUD' | 'CLOUD_INTELLIGENCE_ROUTER' | 'OLLAMA_LOCAL' | 'DETERMINISTIC_MOCK';
  allowedGeminiModels: string[];
  globalRateLimitRpm: number;
  dailyTokenBudget: number;
  highImpactRequiresApproval: boolean;
  auditRetentionDays: number;
  updatedAt: number;
  updatedBy: string;
}

export interface BackupSnapshotRecord {
  id: string;
  label: string;
  createdBy: string;
  createdByRole: CanonicalRole;
  createdAt: number;
  counts: {
    managedUsers: number;
    approvals: number;
    auditEvents: number;
  };
  integritySha256: string;
}

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface ActionRequest {
  id: string;
  action: string;
  resource: string;
  description: string;
  riskLevel: RiskLevel;
  requiredScope: string;
  parameters?: Record<string, any>;
  suggestedBy?: SpecialistRole;
}

export interface ApprovalRecord {
  id: string;
  actionDigest: string;
  action: string;
  resource: string;
  principalId: string;
  riskLevel: RiskLevel;
  parameters: Record<string, any>;
  createdAt: number;
  expiresAt: number;
  status: 'PENDING' | 'APPROVED' | 'DENIED' | 'EXPIRED' | 'CONSUMED';
  approvedBy?: string;
  approvedAt?: number;
  executedAt?: number;
  executionStatus?: 'SUCCEEDED' | 'FAILED';
}

export interface AuditEvent {
  id: string;
  timestamp: number;
  principalId: string;
  role: UserRole;
  action: string;
  resource: string;
  decision: PolicyDecision | 'EXECUTED';
  reason: string;
  digest?: string;
  metadata?: Record<string, any>;
}

export type MemoryDomain = 
  | 'USER_PREFERENCES'
  | 'PROJECT_REQUIREMENTS'
  | 'TASK_HISTORY'
  | 'KNOWLEDGE_BASE'
  | 'OPERATIONAL_LESSONS';

export interface MemoryRecord {
  id: string;
  domain: MemoryDomain;
  key: string;
  title: string;
  content: string;
  provenance: string;
  status: 'CONFIRMED' | 'PROPOSED';
  tags: string[];
  projectId?: string;
  createdAt: number;
  updatedAt: number;
}

export interface SpecialistOutput {
  role: SpecialistRole;
  summary: string;
  keyInsights: string[];
  riskOrVerificationNotes?: string;
}

export interface WorkflowStageItem {
  id: string;
  name: string;
  specialist?: SpecialistRole;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'BLOCKED' | 'FAILED';
  description: string;
  durationMs?: number;
  outputSummary?: string;
  completedAt?: number;
}

export interface ModelAttributionMetadata {
  requestedProvider: string;
  requestedModel: string;
  actualProvider: string;
  actualModel: string;
  taskCategory?: string;
  fallbackUsed: boolean;
  fallbackReason?: string;
  latencyMs: number;
  inputTokens?: number;
  outputTokens?: number;
  licenseClassification?: string;
}

export interface LorinCompletionReport {
  objective: string;
  status: TaskStatus;
  autonomyLevel: AutonomyLevel;
  completed: string[];
  verification: {
    tested: boolean;
    evidence: string;
    acceptanceCriteriaMet: boolean;
  };
  outstanding: string[];
  risks: string[];
  nextStep: string;
  specialistBreakdown: Record<SpecialistRole, SpecialistOutput>;
  proposedActions?: ActionRequest[];
  rawSynthesis: string;
  backendUsed: 'LIVE_GEMINI' | 'OLLAMA_CLOUD' | 'DETERMINISTIC_MOCK' | 'OLLAMA_LOCAL' | 'OFFLINE_KNOWLEDGE_VAULT' | 'NONE';
  latencyMs: number;
  modelAttribution?: ModelAttributionMetadata;
  workflowStages?: WorkflowStageItem[];
  isArchived?: boolean;
  archivedAt?: number;
}

export interface TestResult {
  id: string;
  phase: 'Phase 1 Core' | 'Phase 2 Security' | 'Phase 3 Memory' | 'Phase 4 Live Services' | 'Phase 4 Multimodal' | 'Phase 4 Knowledge';
  name: string;
  description: string;
  status: 'PASSED' | 'FAILED' | 'RUNNING' | 'PENDING';
  assertion: string;
  details: string;
  durationMs?: number;
}

/* Multimodal Chat Message */
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  conversationId?: string;
  projectId?: string;
  completionReport?: LorinCompletionReport;
  modelAttribution?: ModelAttributionMetadata;
  snapshotImage?: string; // base64 DataURL if snapshot was attached
  attachedFile?: {
    name: string;
    size: number;
    type: string;
  };
  sourcesCited?: {
    docTitle: string;
    snippet: string;
    docId: string;
  }[];
  isPinned?: boolean;
  isArchived?: boolean;
  archivedAt?: number;
}

export type WorkflowStage = 
  | 'IDLE'
  | 'DISCOVER'
  | 'INSPECT'
  | 'SECURITY_EVAL'
  | 'SPECIALIST_SYNTHESIS'
  | 'APPROVAL_GATE'
  | 'VERIFIED';

export interface WorkflowStageInfo {
  stage: WorkflowStage;
  label: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'blocked';
}

/* Offline & Hybrid Knowledge Vault Document */
export interface VaultDocument {
  id: string;
  title: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  importedAt: number;
  content: string;
  chunks: string[];
  chunkEmbeddings?: number[][];
  embeddingModelId?: string;
  embeddingDimension?: number;
  indexVersion?: number;
  embeddingIndexVersion?: number;
  tags: string[];
  collection: string;
  indexingStatus: 'INDEXED' | 'INDEXING' | 'FAILED' | 'REINDEX_REQUIRED';
}

/* Voice Session State */
export type VoiceState = 
  | 'IDLE'
  | 'REQUESTING_PERMISSION'
  | 'READY'
  | 'LISTENING'
  | 'PROCESSING'
  | 'SPEAKING'
  | 'MUTED'
  | 'ERROR';

/* Video Session State */
export type VideoState = 
  | 'IDLE'
  | 'STARTING'
  | 'PREVIEW_ACTIVE'
  | 'ANALYZING_FRAME'
  | 'MUTED'
  | 'ERROR';

/* Assistant Runtime State Indicator */
export type AssistantRuntimeState =
  | 'IDLE'
  | 'LISTENING'
  | 'PROCESSING'
  | 'RESPONDING'
  | 'WAITING_FOR_APPROVAL'
  | 'UNAVAILABLE';

/* Independent Project Management Interfaces */
export interface ProjectTask {
  id: string;
  title: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  status: 'TODO' | 'IN_PROGRESS' | 'DONE' | 'BLOCKED';
  category: 'FEATURE' | 'BUG' | 'SECURITY' | 'ARCHITECTURE';
  createdAt: number;
}

export interface ProjectDecision {
  id: string;
  title: string;
  rationale: string;
  status: 'ACCEPTED' | 'PROPOSED' | 'SUPERSEDED';
  createdAt: number;
}

export interface ProjectRecord {
  id: string;
  name: string;
  slug: string;
  classification: 'PRIVATE_CORE' | 'PUBLIC_PLATFORM' | 'INDEPENDENT_PRODUCT';
  description: string;
  techStack: string[];
  repositoryOrPath: string;
  status: 'ACTIVE' | 'PLANNING' | 'MAINTENANCE' | 'ARCHIVED';
  requirements: string[];
  tasks: ProjectTask[];
  decisions: ProjectDecision[];
  createdAt: number;
  updatedAt: number;
}

/* Permission-Based Integration & Automation Interfaces */
export type AutomationPermissionLevel =
  | 'LEVEL_1_READ_ONLY'
  | 'LEVEL_2_PREPARE_DRAFT'
  | 'LEVEL_3_ASSISTED_EXECUTION'
  | 'LEVEL_4_HIGH_IMPACT_APPROVAL';

export interface IntegrationConnector {
  id: string;
  name: string;
  category: 'AI_PROVIDER' | 'STORAGE_CLOUD' | 'DATABASE' | 'HARDWARE_MEDIA' | 'DEVELOPER_TOOL';
  status: 'CONNECTED' | 'STANDBY' | 'DISCONNECTED' | 'ERROR';
  permissionLevel: AutomationPermissionLevel;
  scopesGranted: string[];
  endpointOrTarget: string;
  lastVerifiedAt: number;
  statusSummary: string;
  enabled: boolean;
}

/* Navigation View Types */
export type WorkspaceView = 
  | 'chat'
  | 'projects'
  | 'memory'
  | 'tasks'
  | 'specialists'
  | 'voice'
  | 'video'
  | 'vault'
  | 'security'
  | 'connections'
  | 'deviceCenter'
  | 'terminal'
  | 'tests'
  | 'settings'
  | 'mosairaLab'
  | 'laurenVault'
  | 'ownerGateway'
  | 'gideon';

/* Multi-Conversation Session Interface (Part C) */
export interface ConversationSession {
  id: string;
  userId: string;
  title: string;
  projectId: string;
  messages: ChatMessage[];
  draftText?: string;
  isArchived?: boolean;
  isPinned?: boolean;
  createdAt: number;
  updatedAt: number;
}

/* Durable Task & Automation System Interfaces (Part O) */
export type DurableTaskState =
  | 'QUEUED'
  | 'RUNNING'
  | 'AWAITING_APPROVAL'
  | 'SUCCEEDED'
  | 'FAILED'
  | 'CANCELLED'
  | 'BLOCKED';

export interface DurableTaskStep {
  id: string;
  title: string;
  specialist: SpecialistRole;
  status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'SKIPPED';
  output?: string;
  completedAt?: number;
}

export interface DurableTaskRecord {
  id: string;
  title: string;
  description: string;
  projectId: string;
  executorKey?: string;
  state: DurableTaskState;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  riskLevel: RiskLevel;
  requiresOwnerApproval: boolean;
  approvalId?: string;
  dependencies: string[];
  steps: DurableTaskStep[];
  retryCount: number;
  maxRetries: number;
  scheduleCron?: string;
  executionLog: string[];
  resultSummary?: string;
  errorDetails?: string;
  createdBy: string;
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
}

/* LORIN Operating Modes, Personalities, Voices & Online/Offline Activation */
export type LorinOperatingMode =
  | 'ARCHITECT_STRATEGY'
  | 'DEEP_RESEARCH'
  | 'SECURITY_GUARDIAN'
  | 'RAPID_PAIR_ENGINEER'
  | 'LEARNING_MENTOR';

export type LorinPersonality =
  | 'ANALYTICAL_RIGOROUS'
  | 'CALM_CONVERSATIONAL'
  | 'CONCISE_TACTICAL'
  | 'SOCRATIC_CHALLENGER'
  | 'ADAPTIVE_COMPANION';

export type LorinVoiceProfile =
  | 'LAUREN_NATURAL'
  | 'LORIN_STUDIO'
  | 'LENA_GUARDIAN'
  | 'RILEY_COMPANION'
  | 'NOLAN_ARCHITECT';

export type LorinRuntimeActivation = 'ONLINE_ACTIVE' | 'OFFLINE_AIRGAPPED';

export type LorinThemeMode = 'dark' | 'light';

export type LearningSkillTier = 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED';

export interface LorinProfileConfig {
  operatingMode: LorinOperatingMode;
  personality: LorinPersonality;
  voiceProfile: LorinVoiceProfile;
  autonomyLevel: AutonomyLevel;
  runtimeActivation: LorinRuntimeActivation;
  themeMode?: LorinThemeMode;
  learningTier?: LearningSkillTier;
}

export interface DailyProjectActivityPoint {
  dateKey: string;       // YYYY-MM-DD
  dayLabel: string;      // e.g. 'Mon', 'Tue'
  tasksAndCommits: number;
  auditsAndReviews: number;
  totalEvents: number;
}

export interface DailyEngineeringGoal {
  id: string;
  title: string;
  projectId: string;
  dateKey: string;       // YYYY-MM-DD
  status: 'pending' | 'completed';
  linkedTaskId?: string;
  createdAt: number;
  completedAt?: number;
}

/* ============================================================================
 * LORIN Central Model Registry, Open-Weight Licensing & Task-Based Routing
 * ============================================================================ */

export type ModelProviderId = 'ollama-cloud' | 'google-gemini' | 'ollama-local' | 'embedding-provider';

export type ModelCapabilityTag =
  | 'chat'
  | 'reasoning'
  | 'coding'
  | 'agentic'
  | 'vision'
  | 'tools'
  | 'structured_output'
  | 'streaming'
  | 'embeddings'
  | 'long_context';

export type ModelLicenseCategory =
  | 'OPEN_SOURCE_PERMISSIVE'
  | 'OPEN_WEIGHT_CUSTOM_LICENSE'
  | 'OPEN_WEIGHT_USAGE_POLICY'
  | 'PROPRIETARY_CLOUD_HOSTED';

export type ModelAvailabilityState =
  | 'verified'
  | 'available_untested'
  | 'unavailable_in_catalogue'
  | 'unverified'
  | 'retired';

export type TaskRoutingCategory =
  | 'EVERYDAY_CONVERSATION'
  | 'ALTERNATIVE_EVERYDAY_REASONING'
  | 'COMPLEX_REASONING'
  | 'ARCHITECTURE_STRATEGY'
  | 'SOFTWARE_ENGINEERING_CODING'
  | 'ADVANCED_AGENTIC_CODING'
  | 'IMAGE_UNDERSTANDING'
  | 'LONG_CONTEXT_KNOWLEDGE'
  | 'STRUCTURED_TOOL_USE'
  | 'WEB_RESEARCH'
  | 'DOCUMENT_EMBEDDING_RETRIEVAL'
  | 'VOICE_RECOGNITION'
  | 'VOICE_GENERATION'
  | 'OFFLINE_DOCUMENT_ACCESS'
  | 'OFFLINE_AI_INFERENCE';

export interface ModelRegistryRecord {
  provider: ModelProviderId;
  modelId: string;
  resolvedTag?: string;
  displayName: string;
  family: string;
  mainResponsibility: string;
  defaultRoleAssignment?: string;
  recommendedApplication: string;
  officialReferenceUrl?: string;
  officialLibraryUrl?: string;
  capabilities: ModelCapabilityTag[];
  license: string;
  licenseClassification?: string;
  licenseCategory: ModelLicenseCategory;
  usagePolicyNotes: string;
  availability: ModelAvailabilityState;
  availabilityState?: string;
  enabled: boolean;
  enabledByAdmin?: boolean;
  defaultFor: TaskRoutingCategory[];
  contextLimit: number | null;
  contextWindowTokens?: number;
  maxOutputTokens: number | null;
  supportsVision: boolean;
  supportsTools: boolean;
  supportsStreaming: boolean;
  supportsEmbeddings: boolean;
  costProfile: 'economy' | 'standard' | 'premium' | 'unverified';
  costLatencyTier?: string;
  lastVerifiedAt: number | null;
  lastLatencyMs?: number | null;
  lastVerificationError?: string | null;
  versionTag?: string;
  usageStats?: {
    totalRequests: number;
    totalInputTokens: number;
    totalOutputTokens: number;
    averageLatencyMs: number;
    errorCount: number;
  };
}

export interface TaskRoutingPolicyEntry {
  capability: TaskRoutingCategory;
  capabilityTitle: string;
  preferredModels: string[];
  fallbackModels: string[];
  requiredCapabilities: ModelCapabilityTag[];
  maxContextTokens: number;
  maxOutputTokens: number;
  notes: string;
  category?: TaskRoutingCategory;
  label?: string;
  primaryModelIds?: string[];
  secondaryFallbackIds?: string[];
}

export interface VaultEmbeddingIndexMeta {
  activeEmbeddingModelId: string;
  embeddingModelId?: string;
  provider: 'ollama-cloud' | 'google-gemini' | 'deterministic-hash-vector' | 'embedding-provider';
  vectorDimension: number;
  indexVersion: number;
  lastReindexedAt: number;
  documentsIndexed: number;
  chunksIndexed: number;
  totalIndexedChunks?: number;
}

/* ==========================================================================
 * GIDEON — Systems Intelligence, Timeline Intelligence & Predictive Models
 * ========================================================================== */

export type GideonEventCategory =
  | 'conversation'
  | 'decision'
  | 'project'
  | 'task'
  | 'code_change'
  | 'test'
  | 'deployment'
  | 'configuration'
  | 'provider'
  | 'diagnostic'
  | 'security'
  | 'incident'
  | 'recovery'
  | 'memory';

export type GideonVerificationStatus = 'verified' | 'unverified' | 'inferred';

export interface GideonEvent {
  eventId: string;
  schemaVersion: number;
  ownerUid: string;
  projectId?: string;
  workspaceId?: string;
  category: GideonEventCategory;
  title: string;
  summary: string;
  actorId?: string;
  source: string;
  sourceReference?: string;
  occurredAt: number; // Unix timestamp ms
  recordedAt: number; // Unix timestamp ms
  relatedEventIds?: string[];
  correlationId?: string;
  verificationStatus: GideonVerificationStatus;
  outcome?: string;
  metadata?: Record<string, unknown>;
}

export type GideonDecisionStatus = 'PROPOSED' | 'APPROVED' | 'SUPERSEDED' | 'REJECTED';

export interface GideonDecision {
  decisionId: string;
  ownerUid?: string;
  projectId: string;
  title: string;
  decisionDescription: string;
  alternativesConsidered: string[];
  reasoning: string;
  supportingEvidence: string[];
  decisionOwner: string;
  creationTimestamp: number;
  reviewTimestamp?: number;
  status: GideonDecisionStatus;
  relatedRecordIds?: string[];
}

export type GideonMetricCategory =
  | 'api'
  | 'database'
  | 'auth'
  | 'storage'
  | 'model_provider'
  | 'tasks'
  | 'security'
  | 'worker';

export type GideonServiceHealth =
  | 'HEALTHY'
  | 'DEGRADED'
  | 'UNAVAILABLE'
  | 'NOT_CONFIGURED'
  | 'NOT_MONITORED'
  | 'UNKNOWN';

export interface GideonObservation {
  observationId: string;
  sourceIntegration: string;
  serviceReference: string;
  metricCategory: GideonMetricCategory;
  observedValueOrStatus: GideonServiceHealth;
  measurementTime: number;
  recordingTime: number;
  reliability: 'VERIFIED' | 'SELF_REPORTED' | 'ESTIMATED';
  latencyMs?: number;
  details?: string;
  relatedIncidentIds?: string[];
}

export type GideonConfidenceAssessment = 'HIGH' | 'MEDIUM' | 'LOW' | 'INSUFFICIENT_DATA';
export type GideonPredictionReviewStatus = 'ACTIVE' | 'SUPERSEDED' | 'CONFIRMED' | 'INVALIDATED';

export interface GideonPrediction {
  predictionId: string;
  ownerUid?: string;
  subject: string;
  projectId?: string;
  generatedTimestamp: number;
  forecastHorizon?: string;
  supportingEvidence: string[];
  assumptions: string[];
  potentialOutcome: string;
  confidenceAssessment: GideonConfidenceAssessment;
  knownLimitations: string[];
  recommendedActions: string[];
  reviewStatus: GideonPredictionReviewStatus;
}

export type GideonScenarioStatus = 'HYPOTHETICAL' | 'VERIFIED_FEASIBLE' | 'REJECTED';

export interface GideonScenario {
  scenarioId: string;
  ownerUid?: string;
  scenarioName: string;
  startingConditions: string[];
  proposedChanges: string[];
  assumptions: string[];
  dependencies: string[];
  expectedBenefits: string[];
  potentialRisks: string[];
  alternativeOutcomes: string[];
  evidenceAndLimitations: string[];
  recommendedNextAction: string;
  status: GideonScenarioStatus;
  createdAt: number;
}

export type GideonRelationshipType =
  | 'DIRECT_CAUSE'
  | 'CONTRIBUTING_FACTOR'
  | 'CORRELATED_SEQUENCE'
  | 'COINCIDENTAL';

export interface GideonCorrelation {
  correlationId: string;
  identifiedEvents: GideonEvent[];
  chronologicalRelationship: string;
  availableEvidence: string[];
  sourceReferences: string[];
  possibleRelationship: GideonRelationshipType;
  confidenceAndUncertainty: string;
  alternativeExplanations: string[];
  status: 'CONFIRMED' | 'HYPOTHESIS';
}

export interface GideonDiagnosticsSummary {
  checkedAt: number;
  overallStatus: 'HEALTHY' | 'DEGRADED' | 'UNAVAILABLE';
  observations: GideonObservation[];
  activeAlerts: string[];
}

export interface GideonStatus {
  active: boolean;
  version: string;
  totalEvents: number;
  totalDecisions: number;
  totalPredictions: number;
  activeScenarios: number;
  latestObservationAt: number;
  connectedServices: {
    backendApi: boolean;
    firestore: boolean;
    geminiLive: boolean;
    ollamaCloud: boolean;
    policyEngine: boolean;
  };
}

/* ==========================================================================
 * LORIN PRIMARY NODE, PRIVATE NETWORK, DEVICE CENTER & MULTI-DEVICE SYNC
 * ========================================================================== */

export type DeviceConnectionState =
  | 'online'
  | 'connecting'
  | 'offline'
  | 'sleeping'
  | 'unauthorized'
  | 'revoked'
  | 'error';

export type EnrolledDeviceType =
  | 'primary_laptop'
  | 'mobile_phone'
  | 'tablet'
  | 'secondary_laptop'
  | 'desktop_workstation';

export type DeviceAuthorizationStatus =
  | 'APPROVED'
  | 'PENDING_APPROVAL'
  | 'SUSPENDED'
  | 'REVOKED';

export type PrivateNetworkProviderType =
  | 'TAILSCALE'
  | 'WIREGUARD_OPTIONAL'
  | 'SECURE_LAN_OPTIONAL'
  | 'LOOPBACK_LOCAL'
  | 'CLOUD_HOSTED';

export type DeviceCapabilityScope =
  | 'chat.sync'
  | 'voice.access'
  | 'vision.access'
  | 'knowledge.local_query'
  | 'ollama.local_infer'
  | 'projects.sync'
  | 'tasks.sync'
  | 'node.commands.read'
  | 'node.commands.execute';

export interface EnrolledDeviceRecord {
  deviceId: string;
  ownerUid: string;
  deviceName: string;
  deviceType: EnrolledDeviceType;
  platformSummary: string;
  isPrimaryNode?: boolean;
  connectionState: DeviceConnectionState;
  authorizationStatus: DeviceAuthorizationStatus;
  connectionType: PrivateNetworkProviderType;
  tailscaleHostname?: string;
  tailscaleIp?: string;
  appVersion: string;
  grantedPermissions: DeviceCapabilityScope[];
  enrolledAt: number;
  lastActiveAt: number;
  lastSyncAt?: number;
  revokedAt?: number;
  revokedReason?: string;
  trustedCachePolicy: 'PERSISTENT_TRUSTED' | 'CLEAR_ON_LOGOUT';
}

export interface DevicePairingChallenge {
  challengeId: string;
  ownerUid: string;
  createdByDeviceId: string;
  oneTimeCode: string;
  qrPayloadString: string;
  targetDeviceType?: EnrolledDeviceType;
  proposedDeviceName?: string;
  createdAt: number;
  expiresAt: number;
  status: 'PENDING' | 'CONSUMED' | 'EXPIRED' | 'REVOKED';
  consumedByDeviceId?: string;
  consumedAt?: number;
}

export type PrimaryNodeLifecycleState =
  | 'RUNNING'
  | 'STARTING'
  | 'STOPPING'
  | 'STOPPED'
  | 'SLEEPING'
  | 'DEGRADED'
  | 'UNREACHABLE';

export interface PrimaryNodeTelemetry {
  nodeId: string;
  nodeName: string;
  hostPlatform: string;
  hostArch: string;
  nodeVersion: string;
  lifecycleState: PrimaryNodeLifecycleState;
  bindAddress: string;
  bindPort: number;
  startedAt: number;
  uptimeSeconds: number;
  lastHeartbeatAt: number;
  autoStartOnBootEnabled: boolean;
  cpuCount: number;
  loadAvg1m: number;
  memoryUsedMb: number;
  memoryTotalMb: number;
  memoryUsagePercent: number;
  localDatabaseEngine: 'SQLITE_ENCRYPTED_LOCAL';
  localDatabasePath: string;
  localDatabaseSizeBytes: number;
  services: {
    coreApi: 'RUNNING' | 'STOPPED';
    aiOrchestrator: 'RUNNING' | 'STOPPED';
    ollamaLocal: 'ONLINE' | 'OFFLINE';
    knowledgeVaultIndex: 'READY' | 'INDEXING' | 'OFFLINE';
    syncEngine: 'ACTIVE' | 'PAUSED' | 'OFFLINE';
    deviceManager: 'ACTIVE' | 'STOPPED';
  };
  ollamaStatus: {
    reachable: boolean;
    endpoint: string;
    availableModels: string[];
    lastCheckedAt: number;
    error?: string;
  };
  localKnowledgeStats: {
    indexedDocumentsCount: number;
    indexedChunksCount: number;
    localOnlyFilesCount: number;
    lastIndexedAt: number | null;
  };
}

export interface PrivateNetworkStatus {
  activeAdapter: PrivateNetworkProviderType;
  tailscale: {
    installed: boolean;
    backendState: 'Running' | 'Stopped' | 'NeedsLogin' | 'NoState' | 'NotInstalled';
    selfHostname?: string;
    tailnetDomain?: string;
    magicDnsEndpoint?: string;
    tailscaleIps?: string[];
    serveConfigured: boolean;
    serveHttpsEndpoint?: string;
    funnelEnabled: boolean; // Must remain false for private-only security
    lastProbedAt: number;
    statusDetail: string;
  };
  wireGuardAdapterReady: boolean;
  secureLanAdapterReady: boolean;
  secureTransportVerified: boolean;
  loopbackBindingEnforced: boolean;
  corsAllowedOrigins: string[];
}

export type HybridAvailabilityMode =
  | 'CLOUD_AND_NODE_AVAILABLE'
  | 'CLOUD_ONLY_NODE_UNAVAILABLE'
  | 'NODE_ONLY_INTERNET_UNAVAILABLE'
  | 'BOTH_UNAVAILABLE_CACHED_SHELL';

export interface SyncOutboxItem {
  operationId: string;
  userId: string;
  deviceId: string;
  entityType: 'conversation' | 'message' | 'project' | 'task' | 'memory' | 'setting' | 'knowledge_meta';
  entityId: string;
  action: 'UPSERT' | 'APPEND_MESSAGE' | 'DELETE';
  revision: number;
  payload: Record<string, unknown>;
  createdAt: number;
  retryCount: number;
  status: 'PENDING' | 'SYNCED' | 'CONFLICT' | 'FAILED';
  lastError?: string;
}

export interface SyncEngineStatusSummary {
  state: 'IDLE' | 'SYNCING' | 'OFFLINE_QUEUED' | 'CONFLICT_DETECTED' | 'ERROR';
  availabilityMode: HybridAvailabilityMode;
  pendingOutboxCount: number;
  syncedOperationsCount: number;
  conflictsCount: number;
  lastSyncedAt: number | null;
  activeDeviceId: string;
  activeDeviceState: DeviceConnectionState;
  lastError?: string | null;
}

export interface ApprovedNodeCommandSpec {
  commandId: string;
  title: string;
  description: string;
  category: 'AI_LOCAL' | 'KNOWLEDGE_INDEX' | 'STORAGE_HEALTH' | 'DIAGNOSTICS' | 'PROJECT_WORKSPACE';
  riskLevel: RiskLevel;
  requiresOwnerApproval: boolean;
  requiredScope: DeviceCapabilityScope;
  timeoutMs: number;
}

export interface ApprovedNodeCommandResult {
  executionId: string;
  commandId: string;
  deviceId: string;
  principalId: string;
  status: 'COMPLETED' | 'DENIED' | 'AWAITING_APPROVAL' | 'FAILED' | 'TIMED_OUT';
  outputSummary: string;
  structuredData?: Record<string, unknown>;
  startedAt: number;
  completedAt: number;
  durationMs: number;
  approvalId?: string;
  approvalRecord?: ApprovalRecord;
}


