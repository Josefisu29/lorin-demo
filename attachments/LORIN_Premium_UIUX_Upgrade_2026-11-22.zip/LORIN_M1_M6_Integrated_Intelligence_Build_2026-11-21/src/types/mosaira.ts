/**
 * MOSAIRA Public AI Ecosystem & Model Registry Interfaces (v6.0)
 */

export type OpennessClassification = 
  | 'OPEN_SOURCE'
  | 'OPEN_WEIGHT'
  | 'SOURCE_AVAILABLE'
  | 'HOSTED_API'
  | 'PROPRIETARY';

export type ModelHealthState = 
  | 'ACTIVE'
  | 'DEGRADED'
  | 'SUSPENDED'
  | 'VERIFICATION_REQUIRED'
  | 'OFFLINE';

export type PersonaArchetype = 
  | 'NOVA'
  | 'SAGE'
  | 'ATLAS'
  | 'ORBIT'
  | 'PIXEL'
  | 'ECHO'
  | 'LINGO'
  | 'PULSE'
  | 'FORGE'
  | 'SENTINEL';

export interface MosairaPersona {
  id: PersonaArchetype;
  humanName: string;
  title: string;
  voiceStyle: string;
  purpose: string;
  description: string;
  underlyingModelId: string;
  systemInstruction: string;
  supportedTasks: string[];
  avatarBg: string;
  accentColor: string;
}

export interface MosairaModel {
  modelId: string;
  displayName: string;
  personaId: PersonaArchetype;
  publisher: string;
  providerModelId: string;
  openness: OpennessClassification;
  licenseName: string;
  officialCardUrl?: string;
  modalities: ('text' | 'image' | 'audio' | 'code')[];
  contextLimit: number;
  outputLimit: number;
  toolCalling: boolean;
  fineTuningSupport: boolean;
  commercialUseAllowed: boolean;
  healthStatus: ModelHealthState;
  healthCheckedAt: number;
  latencyMs: number;
  costPer1kInputTokens: number;
  costPer1kOutputTokens: number;
  enabled: boolean;
}

export interface MosairaInferenceRequest {
  personaId: PersonaArchetype;
  modelId: string;
  prompt: string;
  temperature?: number;
  topP?: number;
  maxTokens?: number;
  byokKey?: string;
  consentForTraining?: boolean;
}

export interface MosairaInferenceResponse {
  rawResponse: string;
  personaUsed: PersonaArchetype;
  modelUsed: string;
  latencyMs: number;
  inputTokenCount: number;
  outputTokenCount: number;
  estimatedCostUsd: number;
  timestamp: number;
}

export interface MosairaComparisonResult {
  personaId: PersonaArchetype;
  modelId: string;
  displayName: string;
  responseText: string;
  latencyMs: number;
  ttftMs?: number;
  inputTokens?: number;
  outputTokens?: number;
  estimatedCost?: number;
  status: 'SUCCESS' | 'ERROR';
  errorDetails?: string;
}

export interface MosairaKnowledgeSource {
  id: string;
  title: string;
  publisher: string;
  url?: string;
  license: string;
  category: string;
  importedAt: number;
  content: string;
  chunks: string[];
  citationCount: number;
}

export interface MosairaConsentRecord {
  id: string;
  userId: string;
  timestamp: number;
  useForRAGCommons: boolean;
  useForInternalEval: boolean;
  useForTrainingCandidate: boolean;
  allowPublicDisplay: boolean;
}

export interface MosairaApiKey {
  id: string;
  keyPrefix: string;
  name: string;
  createdAt: number;
  lastUsedAt?: number;
  rateLimitRpm: number;
  status: 'ACTIVE' | 'REVOKED';
}
