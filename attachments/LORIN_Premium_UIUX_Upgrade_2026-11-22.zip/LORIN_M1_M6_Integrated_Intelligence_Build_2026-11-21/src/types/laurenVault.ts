/**
 * Lauren Private Knowledge Vault Data Types
 * Confidential personal knowledge, documents, private RAG & local model integrations
 */

export type DocumentConfidentiality = 'PUBLIC' | 'INTERNAL' | 'CONFIDENTIAL' | 'PROJECT_SECRET' | 'PERSONAL';

export interface DocumentChunk {
  id: string;
  chunkIndex: number;
  text: string;
  tokenCount: number;
}

export interface LaurenDocument {
  id: string;
  title: string;
  fileName: string;
  fileType: string;
  sizeBytes: number;
  source: 'LOCAL_UPLOAD' | 'GOOGLE_DRIVE' | 'MANUAL_NOTE';
  importedAt: number;
  content: string;
  chunks: DocumentChunk[];
  tags: string[];
  confidentialLevel: DocumentConfidentiality;
  collectionId?: string;
  googleDriveFileId?: string;
}

export interface KnowledgeCollection {
  id: string;
  name: string;
  description: string;
  docCount: number;
  color: string;
  createdAt: number;
}

export interface LaurenSourceCitation {
  docId: string;
  docTitle: string;
  chunkId: string;
  snippet: string;
  similarityScore: number;
  reasonUsed: string;
}

export interface VaultChatQuery {
  id: string;
  query: string;
  answer: string;
  timestamp: number;
  sourcesCited: LaurenSourceCitation[];
  modelUsed: string;
  latencyMs: number;
}

export interface LocalOllamaModel {
  name: string;
  sizeBytes: number;
  modifiedAt: string;
  digest: string;
  status: 'AVAILABLE' | 'PULLING' | 'ERROR';
}
