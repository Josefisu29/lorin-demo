import { CapabilityRegistry } from './src/core/capabilities/registry.ts';
import { JobService, createBuiltinCapabilities } from './src/core/jobs/jobService.ts';
import { LorinSqliteStore, defaultLorinDatabasePath } from './src/core/persistence/sqliteStore.ts';
import { ContinuousJobWorker, type WorkerSnapshot } from './src/core/jobs/workerLoop.ts';
import type { JobPrincipalResolver } from './src/core/jobs/jobService.ts';

const capabilityRegistry = createBuiltinCapabilities(new CapabilityRegistry());
let store: LorinSqliteStore | undefined;
let jobs: JobService | undefined;
let worker: ContinuousJobWorker | undefined;

function isServerlessRuntime(): boolean {
  return Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME || process.env.NETLIFY);
}

export function isTrustedLocalCoreRuntime(): boolean {
  if (isServerlessRuntime()) return false;
  if (process.env.LORIN_PRIMARY_NODE_STANDALONE === 'true' || process.env.LORIN_ENABLE_CORE_WORKER === 'true') return true;
  return process.env.NODE_ENV !== 'production';
}

export function getCoreCapabilities(principalPermissions: readonly string[]) {
  return capabilityRegistry.list().filter(capability =>
    capability.requiredPermissions.every(permission => principalPermissions.includes(permission))
  );
}

export function getCoreServices(): { store: LorinSqliteStore; jobs: JobService; capabilities: CapabilityRegistry } {
  if (isServerlessRuntime()) {
    throw new Error('DURABLE_LOCAL_STORE_UNAVAILABLE: The local SQLite core is disabled in serverless runtimes.');
  }
  if (!store) store = new LorinSqliteStore({ databasePath: defaultLorinDatabasePath() });
  if (!jobs) jobs = new JobService(store, capabilityRegistry);
  return { store, jobs, capabilities: capabilityRegistry };
}

export function startCoreWorker(resolvePrincipal: JobPrincipalResolver): WorkerSnapshot {
  if (isServerlessRuntime() || process.env.LORIN_ENABLE_CORE_WORKER !== 'true' || !isTrustedLocalCoreRuntime()) {
    throw new Error('CORE_WORKER_NOT_ENABLED');
  }
  const { jobs: jobService } = getCoreServices();
  if (!worker) worker = new ContinuousJobWorker(jobService, resolvePrincipal);
  return worker.start();
}

export function stopCoreWorker(): WorkerSnapshot {
  if (!worker) return {
    enabled: process.env.LORIN_ENABLE_CORE_WORKER === 'true', running: false, processedCount: 0
  };
  return worker.stop();
}

export function getCoreWorkerStatus(): WorkerSnapshot {
  return worker?.snapshot() || {
    enabled: process.env.LORIN_ENABLE_CORE_WORKER === 'true', running: false, processedCount: 0
  };
}

export function coreHealth(includePrivateDetails = false) {
  return {
    enabled: !isServerlessRuntime(),
    storeInitialized: Boolean(store),
    storage: isServerlessRuntime() ? 'REMOTE_ADAPTER_REQUIRED' : 'ENCRYPTED_LOCAL_SQLITE',
    runtime: process.release.name,
    nodeVersion: process.version,
    ...(includePrivateDetails && !isServerlessRuntime() ? { databasePath: defaultLorinDatabasePath() } : {}),
    executionLocation: isTrustedLocalCoreRuntime() ? 'LOCAL' : 'CLOUD',
    workerEnabled: isTrustedLocalCoreRuntime()
  };
}
