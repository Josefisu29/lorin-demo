# LORIN Primary Node — Windows Stop & Tailscale Serve Reset Script
param(
  [switch]$DisableTailscaleServe = $false
)

$Port = if ($env:LORIN_NODE_PORT) { $env:LORIN_NODE_PORT } else { 4310 }
Write-Host "Checking for running LORIN Primary Node process on port $Port..." -ForegroundColor Yellow

$connections = Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue
if ($connections) {
  foreach ($conn in $connections) {
    if ($conn.OwningProcess -gt 0) {
      Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue
      Write-Host "Stopped LORIN Primary Node process (PID $($conn.OwningProcess))." -ForegroundColor Green
    }
  }
} else {
  Write-Host "No active process found listening on loopback port $Port." -ForegroundColor Gray
}

if ($DisableTailscaleServe) {
  Write-Host "Resetting Tailscale Serve configuration..." -ForegroundColor Cyan
  tailscale serve reset
}
