#!/usr/bin/env bash
# ==============================================================================
# LORIN Primary Node — macOS & Linux Service Installer
# Configures automatic startup (launchd on macOS, systemd on Linux)
# Does NOT execute privileged actions silently; asks or requires explicit flags.
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
OS_TYPE="$(uname -s)"
PORT="${LORIN_NODE_PORT:-4310}"

echo "=========================================================="
echo " LORIN Primary Node — Unix Service Installer (${OS_TYPE})"
echo "=========================================================="

# 1. Dependency check
echo "1. Checking Node.js and dependencies in ${ROOT_DIR}..."
if ! command -v node >/dev/null 2>&1; then
  echo "Error: Node.js is required but not installed." >&2
  exit 1
fi

mkdir -p "${ROOT_DIR}/data"

# 2. Service registration
if [ "${OS_TYPE}" = "Darwin" ]; then
  PLIST_NAME="com.lorin.primarynode.plist"
  TARGET_PLIST="${HOME}/Library/LaunchAgents/${PLIST_NAME}"

  echo "2. Installing macOS launchd LaunchAgent..."
  mkdir -p "${HOME}/Library/LaunchAgents"

  # Substitute absolute root dir path into plist
  sed -e "s|/tmp/lorin-primary-node.log|${HOME}/Library/Logs/lorin-primary-node.log|g" \
      -e "s|/usr/local/bin/node|$(which node)|g" \
      "${SCRIPT_DIR}/${PLIST_NAME}" > "${TARGET_PLIST}"

  echo "   Installed to: ${TARGET_PLIST}"
  echo "   To start now: launchctl load ${TARGET_PLIST}"
  echo "   To stop:      launchctl unload ${TARGET_PLIST}"

elif [ "${OS_TYPE}" = "Linux" ]; then
  SYSTEMD_DIR="${HOME}/.config/systemd/user"
  SERVICE_FILE="lorin-node.service"

  echo "2. Installing Linux user-level systemd service..."
  mkdir -p "${SYSTEMD_DIR}"
  cp "${SCRIPT_DIR}/${SERVICE_FILE}" "${SYSTEMD_DIR}/${SERVICE_FILE}"

  echo "   Installed to: ${SYSTEMD_DIR}/${SERVICE_FILE}"
  echo "   Reloading systemd user daemon..."
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --user daemon-reload
    echo "   To enable on login: systemctl --user enable --now ${SERVICE_FILE}"
    echo "   To check status:   systemctl --user status ${SERVICE_FILE}"
    echo "   To view logs:      journalctl --user -u ${SERVICE_FILE} -f"
  fi
fi

echo "=========================================================="
echo " Tailscale Recommendation:"
echo " To expose privately over HTTPS across your authorized devices:"
echo "   tailscale serve --bg ${PORT}"
echo "=========================================================="
