# LORIN Primary Node — read-only Windows diagnostics.
$ErrorActionPreference = 'Continue'
$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
Set-Location $RepoRoot

Write-Host '=== LORIN Windows Companion Diagnostics ===' -ForegroundColor Cyan
$Node = Get-Command node -ErrorAction SilentlyContinue
$Npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
if ($Node) { Write-Host "Node: $((& node --version).Trim())" } else { Write-Host 'Node: MISSING' -ForegroundColor Red }
if ($Npm) { Write-Host "npm: $((& npm.cmd --version).Trim())" } else { Write-Host 'npm: MISSING' -ForegroundColor Red }
Write-Host "Node bind host policy: 127.0.0.1 (forced by start.ps1)"
Write-Host "Node port: $(if ($env:LORIN_NODE_PORT) { $env:LORIN_NODE_PORT } else { '4310 (default)' })"
Write-Host "Local TSX installed: $(Test-Path (Join-Path $RepoRoot 'node_modules\.bin\tsx.cmd'))"
Write-Host "Local data directory exists: $(Test-Path (Join-Path $env:USERPROFILE '.lorin\data'))"
Write-Host "Local key directory exists: $(Test-Path (Join-Path $env:USERPROFILE '.lorin\keys'))"
Write-Host "LORIN_ENABLE_CORE_WORKER: $(if ($env:LORIN_ENABLE_CORE_WORKER -eq 'true') { 'enabled by explicit environment setting' } else { 'disabled (safe default)' })"
if ($Node) {
  Write-Host "`nRunning repository preflight (read-only)..." -ForegroundColor Cyan
  & node scripts/preflight.mjs
  Write-Host "Preflight exit code: $LASTEXITCODE"
}
