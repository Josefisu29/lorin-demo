#!/usr/bin/env bash
set -euo pipefail

export LORIN_NODE_BIND_HOST="${LORIN_NODE_BIND_HOST:-127.0.0.1}"
export LORIN_NODE_PORT="${LORIN_NODE_PORT:-4310}"

echo "Starting LORIN Primary Laptop Node on http://${LORIN_NODE_BIND_HOST}:${LORIN_NODE_PORT} ..."
npx tsx lorin-node/src/core/node-runtime.ts
