# LORIN Primary Node — Windows start script.
# Runs the locally installed TSX binary only; never uses npx or downloads packages.
$ErrorActionPreference = 'Stop'
$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
Set-Location $RepoRoot

$NodeVersionText = (& node --version 2>$null).Trim().TrimStart('v')
if (-not $NodeVersionText) { throw 'Node.js is not installed or is not on PATH.' }
try { $NodeVersion = [version]$NodeVersionText } catch { throw "Could not parse Node version '$NodeVersionText'." }
if ($NodeVersion -lt [version]'24.12.0') { throw "Node.js 24.12.0 or newer is required. Current: $NodeVersionText." }

$env:LORIN_NODE_BIND_HOST = '127.0.0.1'
if (-not $env:LORIN_NODE_PORT) { $env:LORIN_NODE_PORT = '4310' }
$Port = 0
if (-not [int]::TryParse($env:LORIN_NODE_PORT, [ref]$Port) -or $Port -lt 1024 -or $Port -gt 65535) {
  throw 'LORIN_NODE_PORT must be an integer between 1024 and 65535.'
}

$TsxCommand = Join-Path $RepoRoot 'node_modules\.bin\tsx.cmd'
if (-not (Test-Path $TsxCommand -PathType Leaf)) {
  throw 'Local TSX executable is missing. Run lorin-node/scripts/install.ps1 after package preflight succeeds.'
}

Write-Host "Starting LORIN Primary Node on http://127.0.0.1:$Port ..." -ForegroundColor Cyan
& $TsxCommand 'lorin-node/src/core/node-runtime.ts'
if ($LASTEXITCODE -ne 0) { throw "LORIN Primary Node exited with code $LASTEXITCODE." }
