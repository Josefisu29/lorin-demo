#!/usr/bin/env bash
set -euo pipefail

PORT="${LORIN_NODE_PORT:-4310}"
echo "Checking for running LORIN Primary Node on port ${PORT}..."

PIDS=$(lsof -ti tcp:"${PORT}" 2>/dev/null || true)
if [ -n "${PIDS}" ]; then
  echo "Terminating LORIN Primary Node process (PID ${PIDS})..."
  kill -15 ${PIDS} 2>/dev/null || kill -9 ${PIDS} 2>/dev/null || true
  echo "LORIN Primary Node stopped successfully."
else
  echo "No active process found listening on port ${PORT}."
fi

if command -v tailscale >/dev/null 2>&1; then
  if [ "${1:-}" = "--reset-tailscale" ]; then
    echo "Resetting Tailscale Serve configuration..."
    tailscale serve reset || true
  fi
fi
