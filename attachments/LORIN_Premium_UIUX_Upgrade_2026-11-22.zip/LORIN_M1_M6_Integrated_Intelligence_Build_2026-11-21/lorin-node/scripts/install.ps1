# LORIN Primary Node — Windows installation and optional private Tailscale setup.
# This script never elevates privileges and never registers a system service silently.
param(
  [switch]$ConfigureTailscaleServe = $false,
  [switch]$RegisterStartupShortcut = $false
)

$ErrorActionPreference = 'Stop'
$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
Set-Location $RepoRoot
$Port = if ($env:LORIN_NODE_PORT) { [int]$env:LORIN_NODE_PORT } else { 4310 }

function Invoke-Checked([string]$Command, [string[]]$Arguments, [string]$Description) {
  Write-Host "`n== $Description ==" -ForegroundColor Cyan
  & $Command @Arguments
  if ($LASTEXITCODE -ne 0) {
    throw "$Description failed with exit code $LASTEXITCODE. No later installation steps were run."
  }
}

Write-Host '=== LORIN Primary Laptop Node Installer ===' -ForegroundColor Cyan
$NodeCommand = Get-Command node -ErrorAction SilentlyContinue
$NpmCommand = Get-Command npm.cmd -ErrorAction SilentlyContinue
if (-not $NodeCommand -or -not $NpmCommand) {
  throw 'Node.js and npm are required. Install the versions declared in package.json/packageManager, then rerun this script.'
}

$NodeVersionText = (& node --version).Trim().TrimStart('v')
try { $NodeVersion = [version]$NodeVersionText } catch { throw "Could not parse Node version '$NodeVersionText'." }
if ($NodeVersion -lt [version]'24.12.0') {
  throw "Node.js 24.12.0 or newer is required. Current version: $NodeVersionText."
}
$NpmVersion = (& npm.cmd --version).Trim()
if ($NpmVersion -ne '10.9.2') {
  throw "This release pins npm 10.9.2; current version is $NpmVersion."
}
if ($Port -lt 1024 -or $Port -gt 65535) { throw 'LORIN_NODE_PORT must be between 1024 and 65535.' }

# The preflight verifies package.json/package-lock.json before npm ci. It does
# not attempt to repair or silently rewrite a mismatched lockfile.
Invoke-Checked 'node' @('scripts/preflight.mjs', '--before-install') 'Validate runtime and lockfile before installing'
Invoke-Checked 'npm.cmd' @('ci') 'Install the exact locked dependencies'
Invoke-Checked 'node' @('scripts/preflight.mjs') 'Validate installed build environment'
Invoke-Checked 'npm.cmd' @('run', 'test:core') 'Run core security and behaviour tests'
Invoke-Checked 'npm.cmd' @('run', 'test:security:static') 'Run static security regressions'
Invoke-Checked 'npm.cmd' @('run', 'lint') 'Run TypeScript semantic checks'
Invoke-Checked 'npm.cmd' @('run', 'build') 'Build the LORIN web and server applications'

$DataPath = Join-Path $env:USERPROFILE '.lorin\data'
New-Item -ItemType Directory -Force -Path $DataPath | Out-Null
Write-Host "Local data directory prepared: $DataPath" -ForegroundColor Green

if ($ConfigureTailscaleServe) {
  if (-not (Get-Command tailscale.exe -ErrorAction SilentlyContinue)) {
    throw 'Tailscale was requested but tailscale.exe is not installed. Install/authenticate Tailscale first.'
  }
  $env:LORIN_NODE_BIND_HOST = '127.0.0.1'
  Write-Host "Configuring private Tailscale Serve -> loopback port $Port" -ForegroundColor Cyan
  Invoke-Checked 'tailscale.exe' @('serve', '--bg', "$Port") 'Configure explicit Tailscale Serve'
  Invoke-Checked 'tailscale.exe' @('serve', 'status') 'Verify Tailscale Serve status'
}

if ($RegisterStartupShortcut) {
  $StartScript = Join-Path $RepoRoot 'lorin-node\scripts\start.ps1'
  $Action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy RemoteSigned -File `"$StartScript`"" -WorkingDirectory $RepoRoot
  $Trigger = New-ScheduledTaskTrigger -AtLogOn
  Register-ScheduledTask -TaskName 'LorinPrimaryLaptopNode' -Action $Action -Trigger $Trigger -Description 'Starts the loopback-only LORIN Primary Node for the current user' -Force | Out-Null
  Write-Host 'Registered the explicitly requested user logon task.' -ForegroundColor Green
}

Write-Host "`nLORIN Primary Node prerequisites and production build passed. Start it with: .\lorin-node\scripts\start.ps1" -ForegroundColor Green
