# LORIN Continuation Working Build — 21 November 2026

This is a security-remediated working copy based on the saved 9 November LORIN continuation archive. It includes the 21 November reference-repository analysis, task-integrity changes, fail-closed approvals and reports.

## Important

This archive is **not a production release**. The static security regression suite passed 29/29 and TypeScript syntax transpilation passed 108/108. Semantic typechecking, Vitest, production build, Firebase/provider inference, offline acceptance, browser/device QA and deployment remain unverified or blocked. The package requires Node.js >=24.12.0. Reconcile the package manifest and lockfile on that runtime before running `npm ci`; do not run `npm ci` against the current mismatched lockfile.

## Start safely

1. Review `README.md` and `.env.example`.
2. Install the declared supported Node.js version (>=24.12.0).
3. Review `package.json` and `package-lock.json`; reconcile and regenerate the lockfile deliberately.
4. Install dependencies in a clean environment.
5. Run `npm run test:security:static`, `npm run lint`, `npm test` and `npm run build`.
6. Configure Firebase and provider credentials only in a trusted local environment or secret manager. Do not put secrets in frontend variables.
7. Read `docs/LORIN_BUILD_CONTINUATION_REPORT_2026-11-21.md` before enabling any live functionality.

The archive intentionally excludes `.env` files (retains `.env.example`), runtime identity/approval/conversation JSON, SQLite/runtime state, local encryption keys, generated `server.js`, build output and dependency folders.
