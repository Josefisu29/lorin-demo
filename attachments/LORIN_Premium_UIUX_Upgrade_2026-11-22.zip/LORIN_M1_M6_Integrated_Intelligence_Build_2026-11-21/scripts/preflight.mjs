import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const beforeInstall = process.argv.includes('--before-install');
const readJson = (name) => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const manifest = readJson('package.json');
const lock = readJson('package-lock.json');
const lockRoot = lock.packages?.[''] || {};
const results = [];
const add = (name, ok, detail) => results.push({ name, ok: Boolean(ok), detail });

function parseVersion(value) {
  const match = String(value).match(/^(\d+)\.(\d+)\.(\d+)/);
  return match ? match.slice(1).map(Number) : null;
}
function compareVersion(a, b) {
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] - b[i];
  return 0;
}

const requestedNode = parseVersion(manifest.engines?.node?.replace(/^>=\s*/, ''));
const currentNode = parseVersion(process.versions.node);
add('Node runtime', Boolean(requestedNode && currentNode && compareVersion(currentNode, requestedNode) >= 0),
  `current=${process.versions.node}; required=${manifest.engines?.node || 'not declared'}`);

const packageManager = String(manifest.packageManager || '');
const npmVersion = spawnSync('npm', ['--version'], { encoding: 'utf8' }).stdout?.trim() || 'unavailable';
const requestedNpm = packageManager.match(/^npm@(\d+\.\d+\.\d+)/)?.[1];
add('npm version', !requestedNpm || npmVersion === requestedNpm,
  `current=${npmVersion}; required=${requestedNpm || 'not pinned'}`);

const sections = ['dependencies', 'devDependencies', 'optionalDependencies'];
const declared = Object.fromEntries(sections.map((section) => [section, manifest[section] || {}]));
const locked = Object.fromEntries(sections.map((section) => [section, lockRoot[section] || {}]));
const mismatches = [];
for (const section of sections) {
  const names = new Set([...Object.keys(declared[section]), ...Object.keys(locked[section])]);
  for (const name of names) {
    if (declared[section][name] !== locked[section][name]) {
      mismatches.push(`${section}.${name}: manifest=${declared[section][name] ?? '—'}, lock=${locked[section][name] ?? '—'}`);
    }
  }
}
const missingEntries = [];
for (const section of sections) {
  for (const name of Object.keys(declared[section])) {
    if (!lock.packages?.[`node_modules/${name}`]) missingEntries.push(name);
  }
}
add('package-lock root alignment', mismatches.length === 0,
  mismatches.length ? mismatches.join('; ') : 'package.json dependency sections match package-lock.json');
add('direct dependency lock entries', missingEntries.length === 0,
  missingEntries.length ? `missing lock package records: ${missingEntries.join(', ')}` : 'all direct dependencies have lock package records');

const nodeModules = fs.existsSync(path.join(root, 'node_modules'));
add('installed dependencies', beforeInstall || nodeModules,
  beforeInstall ? 'pre-install phase: dependency installation is intentionally deferred' :
    nodeModules ? 'node_modules directory exists; package health still requires npm test/build' :
      'node_modules is absent; install only after reconciling package.json and package-lock.json');

let sqliteAvailable = false;
try {
  const { DatabaseSync } = await import('node:sqlite');
  sqliteAvailable = typeof DatabaseSync === 'function';
} catch {}
add('built-in node:sqlite', sqliteAvailable,
  sqliteAvailable ? 'DatabaseSync is available in this Node runtime' : 'node:sqlite DatabaseSync is unavailable in this Node runtime');

console.log(beforeInstall ? 'LORIN pre-install preflight' : 'LORIN build preflight');
console.log(`Runtime: Node ${process.versions.node} | npm ${npmVersion}`);
for (const result of results) console.log(`${result.ok ? 'PASS' : 'BLOCKED'} ${result.name}: ${result.detail}`);
const failed = results.filter((result) => !result.ok);
console.log(`\n${results.length - failed.length}/${results.length} preflight checks passed.`);
if (failed.length) process.exitCode = 1;
