import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createCrcTable() {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) c = 0xedb88320 ^ (c >>> 1);
      else c = c >>> 1;
    }
    table[n] = c;
  }
  return table;
}

const crcTable = createCrcTable();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function writePngChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4);
  data.copy(chunk, 8);
  const typeAndData = Buffer.concat([Buffer.from(type), data]);
  chunk.writeUInt32BE(crc32(typeAndData), 8 + len);
  return chunk;
}

function generatePngBuffer(width, height, isMaskable = false) {
  // Generate RGBA buffer
  const stride = width * 4;
  const rawScanlines = Buffer.alloc((stride + 1) * height);

  const cx = width / 2;
  const cy = height / 2;
  const maxR = width / 2;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * (stride + 1);
    rawScanlines[rowOffset] = 0; // Filter type 0 (None)

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Background color: #0B0F14 (R:11, G:15, B:20)
      let r = 11;
      let g = 15;
      let b = 20;
      let a = 255;

      // Outer ring at 0.7 * radius
      if (Math.abs(dist - maxR * 0.7) < Math.max(2, width * 0.015)) {
        // Iris border in #283544
        r = 40; g = 53; b = 68;
      }

      // Inner ring at 0.55 * radius in #66E3CB
      if (Math.abs(dist - maxR * 0.55) < Math.max(2, width * 0.02)) {
        r = 102; g = 227; b = 203; // #66E3CB
      }

      // 5 Specialist dots at radius 0.55
      const angles = [
        -Math.PI / 2, // Top (Lena)
        -Math.PI / 6, // Top-right (Owen)
        Math.PI / 6,  // Bottom-right (Nolan)
        (5 * Math.PI) / 6, // Bottom-left (Iris)
        -(5 * Math.PI) / 6 // Top-left (Riley)
      ];
      for (const ang of angles) {
        const dotX = cx + Math.cos(ang) * (maxR * 0.55);
        const dotY = cy + Math.sin(ang) * (maxR * 0.55);
        const dDot = Math.hypot(x - dotX, y - dotY);
        if (dDot < Math.max(3, width * 0.04)) {
          r = 102; g = 227; b = 203;
        }
      }

      // Central core emblem (radius 0.25) in #17212C
      if (dist < maxR * 0.28) {
        r = 23; g = 33; b = 44; // #17212C
      }

      // Central "L" glyph in #66E3CB and white
      const lx = x - cx;
      const ly = y - cy;
      const thick = Math.max(2, width * 0.035);
      const lH = maxR * 0.22;
      const lW = maxR * 0.16;
      if (
        (lx >= -lW / 2 && lx <= -lW / 2 + thick && ly >= -lH / 2 && ly <= lH / 2) ||
        (ly >= lH / 2 - thick && ly <= lH / 2 && lx >= -lW / 2 && lx <= lW / 2)
      ) {
        r = 241; g = 245; b = 249; // #F1F5F9
      }

      rawScanlines[pxOffset] = r;
      rawScanlines[pxOffset + 1] = g;
      rawScanlines[pxOffset + 2] = b;
      rawScanlines[pxOffset + 3] = a;
    }
  }

  const compressedData = zlib.deflateSync(rawScanlines);

  // PNG Header
  const pngSig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // 8 bits per channel
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0; // Deflate
  ihdr[11] = 0; // Filter 0
  ihdr[12] = 0; // Non-interlaced

  const ihdrChunk = writePngChunk('IHDR', ihdr);
  const idatChunk = writePngChunk('IDAT', compressedData);
  const iendChunk = writePngChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([pngSig, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Write 192x192
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), generatePngBuffer(192, 192));
console.log('Generated pwa-192x192.png');

// Write 512x512
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), generatePngBuffer(512, 512));
console.log('Generated pwa-512x512.png');

// Write 512x512 maskable
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), generatePngBuffer(512, 512, true));
console.log('Generated pwa-maskable-512x512.png');

// Write apple-touch-icon 180x180
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), generatePngBuffer(180, 180));
console.log('Generated apple-touch-icon.png');

// Write favicon.ico (192x192 png is valid modern favicon)
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), generatePngBuffer(64, 64));
console.log('Generated favicon.ico');
