/**
 * LORIN — Controlled One-Time System Owner Bootstrap Script (Section 10)
 *
 * Usage (run only from a trusted deployment/admin shell after the Firebase user exists):
 *   OWNER_EMAIL="owner@example.com" OWNER_UID="firebase-auth-uid" OWNER_DISPLAY_NAME="System Owner" npx tsx scripts/bootstrapSystemOwner.ts
 *
 * Safety & Security Invariants:
 * 1. Never uses hardcoded owner credentials or default passwords.
 * 2. Checks whether an active SYSTEM_OWNER already exists in the authoritative registry.
 * 3. Refuses to replace, overwrite, or duplicate an existing SYSTEM_OWNER.
 * 4. Emits an immutable audit record to stderr/stdout upon execution.
 */
import dotenv from 'dotenv';
import path from 'path';
import { bootstrapOneTimeSystemOwner, getAllManagedAccounts } from '../serverAuth';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });
dotenv.config({ path: path.resolve(process.cwd(), 'backend', '.env') });

async function runBootstrap() {
  const ownerEmail = (process.env.OWNER_EMAIL || '').trim().toLowerCase();
  const ownerDisplayName = (process.env.OWNER_DISPLAY_NAME || 'Primary System Owner').trim();
  const ownerUid = (process.env.OWNER_UID || '').trim();

  if (!ownerEmail || !ownerEmail.includes('@')) {
    console.error(
      '[LORIN Bootstrap Error] Missing valid OWNER_EMAIL environment variable. Bootstrap email must be explicitly configured in the trusted server environment.\n' +
        'Usage: OWNER_EMAIL="your.email@domain.com" OWNER_UID="firebase-auth-uid" npx tsx scripts/bootstrapSystemOwner.ts'
    );
    process.exit(1);
  }

  if (!ownerUid) {
    console.error('[LORIN Bootstrap Error] OWNER_UID must be the real Firebase Authentication UID of the designated owner. No synthetic owner UID will be created.');
    process.exit(1);
  }

  const result = bootstrapOneTimeSystemOwner({
    uid: ownerUid,
    email: ownerEmail,
    displayName: ownerDisplayName
  });

  const auditRecord = {
    event: 'system_owner_bootstrap_attempt',
    timestamp: new Date().toISOString(),
    targetEmail: ownerEmail,
    success: result.success,
    alreadyBootstrapped: Boolean(result.alreadyBootstrapped),
    message: result.message,
    activeSystemOwnersCount: getAllManagedAccounts().filter(
      a => a.canonicalRole === 'SYSTEM_OWNER' && a.accountStatus === 'ACTIVE'
    ).length
  };

  console.log(JSON.stringify(auditRecord, null, 2));

  if (!result.success) {
    process.exit(1);
  }
}

runBootstrap().catch(err => {
  console.error('[LORIN Bootstrap Fatal Error]', err instanceof Error ? err.message : String(err));
  process.exit(1);
});
