import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const auth = read('serverAuth.ts');
const server = read('server.ts');
const app = read('src/App.tsx');
const authHeaders = read('src/services/authHeaders.ts');
const modelBackend = read('src/services/modelBackend.ts');
const ollamaService = read('src/services/ollamaService.ts');
const node = read('serverPrimaryNode.ts');
const policy = read('src/services/policyEngine.ts');
const tasks = read('src/services/taskQueueService.ts');
const memory = read('src/services/memoryStore.ts');
const offlineKnowledge = read('src/services/offlineIntelligenceService.ts');
const firebase = read('src/services/firebase.ts');
const ignore = read('.gitignore');
const bootstrap = read('scripts/bootstrapSystemOwner.ts');
const envExample = read('.env.example');
const firestoreRules = read('firestore.rules');
const firebaseConfig = JSON.parse(read('firebase-applet-config.json'));
const firebaseCliConfig = JSON.parse(read('firebase.json'));
const connections = read('src/components/ConnectionsWorkspace.tsx');

const checks = [];
function check(name, fn) {
  fn();
  checks.push(name);
}

check('No built-in owner email in server auth', () => {
  assert.doesNotMatch(auth, /isahjoseph20030429@gmail\.com/i);
  assert.match(auth, /process\.env\.OWNER_EMAIL\s*\|\|\s*''/);
  assert.match(auth, /managed\.canonicalRole === 'SYSTEM_OWNER' && !emailVerified/);
  assert.match(auth, /emailVerified = false/);
  assert.match(auth, /mapCanonicalToLegacyRole\(effectiveCanonical, managed\.accountStatus\)/);
});

check('No app-minted HMAC bearer-token implementation', () => {
  assert.doesNotMatch(auth, /createSessionToken|createHmac|timingSafeEqual|lorin_sess_/);
  assert.match(auth, /Identity Toolkit accounts:lookup/);
});

check('Legacy auth-session route fails closed and never mints principal', () => {
  const start = server.indexOf("app.post('/api/auth/session'");
  assert.notEqual(start, -1, 'legacy endpoint should remain as an explicit compatibility failure');
  const end = server.indexOf('// 1b. Authenticated Principal Identity Endpoint', start);
  assert.notEqual(end, -1, 'could not delimit compatibility route');
  const route = server.slice(start, end);
  assert.match(route, /FIREBASE_AUTH_REQUIRED/);
  assert.match(route, /status\(401\)/);
  assert.doesNotMatch(route, /createSessionToken|buildPrincipal/);
});

check('Client no longer performs anonymous session bootstrap', () => {
  assert.doesNotMatch(app, /fetch\(['"]\/api\/auth\/session/);
  assert.doesNotMatch(app, /getStoredSessionToken|setStoredSessionToken/);
  assert.match(app, /canonicalRole: 'STANDARD_USER'/);
});

check('Private request helpers only use current Firebase identity', () => {
  assert.match(authHeaders, /const user = auth\.currentUser/);
  assert.match(authHeaders, /user\.getIdToken\(\)/);
  assert.doesNotMatch(authHeaders, /fetch\(['"]\/api\/auth\/session|Authorization:\s*`Bearer \$\{stored\}`/);
  assert.match(authHeaders, /clearStoredSessionToken\(\)/);
});

check('Production node encryption requires configured high-entropy key', () => {
  assert.match(node, /LORIN_NODE_STORAGE_KEY/);
  assert.match(node, /Buffer\.byteLength\(configured, 'utf8'\) < 32/);
  assert.match(node, /NODE_ENV === 'production' \|\| process\.env\.VERCEL/);
  assert.match(node, /crypto\.randomBytes\(32\)/);
  assert.doesNotMatch(node, /hostname\(\).*platform\(\).*lorin_primary_node/s);
  assert.match(node, /LEGACY_MIGRATION_AES_KEY/);
  assert.match(node, /this\.persistStore\(\); \/\/ Migrate legacy ciphertext/);
});

check('Client policy defaults to fail-closed and never falls back to local approval in production mode', () => {
  assert.match(policy, /private static failClosedWhenServerOffline = true/);
  assert.match(policy, /Authoritative approval service is unavailable/);
  assert.match(policy, /Authoritative approval validation service is unavailable/);
});

check('Node command owner approval is action-bound and never trusts a browser boolean', () => {
  const start = server.indexOf("app.post('/api/node/commands/execute'");
  const end = server.indexOf('// Normalize parser and route errors', start);
  assert.notEqual(start, -1);
  const route = server.slice(start, end);
  assert.match(route, /evaluateServerPolicyAction\(principal, policyRequest\)/);
  assert.doesNotMatch(route, /ownerApproved/);
  assert.match(route, /approvalRecord\?\.status === 'CONSUMED'/);
  assert.match(node, /ownerApprovalVerified/);
});

check('Task API rejects client-forged completion claims without a trusted execution receipt', () => {
  assert.match(server, /export function sanitizeSubmittedTasksForServer/);
  assert.match(server, /state: 'BLOCKED'/);
  assert.match(server, /rejected an unverified client completion claim/);
  assert.match(server, /sanitizeSubmittedTasksForServer\(req\.body\.tasks\)/);
  assert.match(tasks, /A task can only run when its executorKey is registered/);
});

check('Server port comes from validated PORT environment', () => {
  assert.match(server, /process\.env\.PORT\?\.trim\(\) \|\| '3000'/);
  assert.match(server, /PORT < 1 \|\| PORT > 65535/);
});


check('Memory storage is account-scoped and legacy global memory is quarantined', () => {
  assert.match(memory, /lorin_persistent_memory_v2/);
  assert.match(memory, /encodeURIComponent\(this\.activeUserId\)/);
  assert.match(memory, /static setActiveUser\(/);
  assert.match(memory, /principal\.id === this\.activeUserId/);
  assert.match(memory, /LEGACY_MEMORY_BACKUP_KEY/);
  assert.doesNotMatch(memory, /SEED_MEMORY_RECORDS/);
  assert.match(memory, /auth\.currentUser\?\.uid !== userId/);
  assert.match(memory, /loadMemoryRecordsRemote\(userId\)/);
  assert.match(memory, /deleteMemoryRecordRemote/);
  assert.match(memory, /MEMORY_SYNC_QUEUE_KEY/);
  assert.match(memory, /flushPendingOperations/);
  assert.match(memory, /isValidMemoryRecord/);
  assert.match(memory, /candidate\.status !== 'PROPOSED'/);
});

check('Memory synchronization uses authenticated, user-scoped Firestore records', () => {
  assert.match(firebase, /export async function loadMemoryRecordsRemote\(userId: string\)/);
  assert.match(firebase, /where\('userId', '==', userId\)/);
  assert.match(firebase, /auth\.currentUser\.uid !== userId/);
  assert.match(firebase, /export async function deleteMemoryRecordRemote/);
});

check('Static knowledge does not contain the real owner email or obsolete HMAC session claims', () => {
  assert.doesNotMatch(offlineKnowledge, /isahjoseph20030429@gmail\.com/i);
  assert.doesNotMatch(offlineKnowledge, /stateless HMAC|lorin_sess_/i);
});

check('Owner bootstrap requires a real Firebase UID supplied by a trusted operator', () => {
  assert.match(bootstrap, /const ownerUid = \(process\.env\.OWNER_UID \|\| ''\)\.trim\(\)/);
  assert.match(bootstrap, /if \(!ownerUid\)/);
  assert.match(bootstrap, /real Firebase Authentication UID/);
});

check('Firestore memory rules enforce owner scoping and memory schema limits', () => {
  assert.match(firestoreRules, /function isValidMemoryRecord/);
  assert.match(firestoreRules, /request\.resource\.data\.userId == request\.auth\.uid/);
  assert.match(firestoreRules, /data\.content\.size\(\) <= 20000/);
  assert.match(firestoreRules, /data\.status in \['CONFIRMED', 'PROPOSED'\]/);
});

check('Private runtime files are excluded from source control', () => {
  for (const entry of [
    '.lorin_session_secret',
    'allowed_owners.json',
    'server_rbac_users.json',
    'server_policy_state.json',
    'server_conversations.json',
    'server_workspace_state.json',
    '.gideon_data/',
    'data/*.sqlite'
  ]) assert.ok(ignore.includes(entry), `missing ignore entry: ${entry}`);
});

check('System health matrix requires Firebase authentication and account-scopes device counts', () => {
  const start = server.indexOf("app.get('/api/system/health-matrix'");
  assert.notEqual(start, -1);
  const end = server.indexOf('// 1a-2. Session Status', start);
  assert.notEqual(end, -1);
  const route = server.slice(start, end);
  assert.match(route, /requireAuthenticatedPrincipal\(req, res\)/);
  assert.match(route, /listDevicesForUser\(principal\.id, isPrivileged\)/);
  assert.doesNotMatch(route, /listDevicesForUser\('system_health_audit', true\)/);
});

check('System health does not claim unprobed browser or cloud services are healthy', () => {
  assert.match(server, /NOT_VERIFIED/);
  assert.match(server, /notVerifiedCount/);
  assert.match(server, /positively verified/);
  assert.match(server, /deploymentVerified: false/);
  assert.match(server, /multiInstanceDurabilityVerified: false/);
  assert.match(server, /INFO_VOICE_REQUIRES_DEVICE_PROBE/);
  assert.match(server, /INFO_VISION_REQUIRES_DEVICE_PROBE/);
});

check('Health matrix UI renders NOT_VERIFIED as a neutral state', () => {
  const deviceCenter = read('src/services/deviceCenterService.ts');
  const deviceUI = read('src/components/NetworkDeviceControlCenter.tsx');
  assert.match(deviceCenter, /'NOT_VERIFIED'/);
  assert.match(deviceUI, /sub\.state === 'NOT_VERIFIED'/);
});

check('Anonymous MOSAIRA inference is bounded and request metadata validated', () => {
  const start = server.indexOf("app.post('/api/mosaira/infer'");
  const end = server.indexOf('/* ============================================================================', start);
  assert.notEqual(start, -1);
  const route = server.slice(start, end);
  assert.match(route, /mosaira_public_ip_/);
  assert.match(route, /mosaira_public_global/);
  assert.match(route, /PUBLIC_RATE_LIMITED/);
  assert.match(route, /systemInstruction.*MAX_PROMPT_CHARS/);
  assert.match(route, /Persona name must be a string/);
});

check('Private Vault and memory context are not sent to cloud by default', () => {
  assert.match(modelBackend, /Privacy by default[\s\S]{0,220}return false;/);
  const testSource = read('src/tests/lorinV2.spec.ts');
  assert.match(testSource, /Keeps private context local by default/);
  assert.match(testSource, /isCloudContextPermitted\(\)\)\.toBe\(false\)/);
});

check('Local-first cloud fallback requires the Settings mode opt-in and keeps private context on a separate gate', () => {
  assert.match(app, /allowCloudFallback: backendMode === 'LOCAL_FIRST_WITH_CLOUD_FALLBACK'/);
  assert.match(app, /allowCloudContextTransmission: CloudPrivacyGate\.isCloudContextPermitted\(\)/);
  assert.match(modelBackend, /options\?\.allowCloudFallback === true/);
  assert.match(modelBackend, /!snapshotImage/);
  assert.match(modelBackend, /!emittedAnyChunk/);
  assert.match(modelBackend, /failure\?\.noFallback !== true/);
  assert.match(modelBackend, /options\?\.allowCloudContextTransmission === true && CloudPrivacyGate\.isCloudContextPermitted\(\)/);
  assert.match(modelBackend, /cloudContextAllowed \? context : undefined/);
});

check('Local Ollama transport is loopback-only and uses the strict tested NDJSON consumer', () => {
  assert.match(ollamaService, /checkLocalStatus\(\)/);
  assert.match(ollamaService, /parsed\.protocol !== 'http:'/);
  assert.match(ollamaService, /new Set\(\['localhost', '127\.0\.0\.1', '\[::1\]', '::1'\]\)/);
  assert.match(ollamaService, /consumeOllamaNdjsonStream\(response\.body/);
  assert.match(ollamaService, /LOCAL_OLLAMA_REQUEST_ABORTED_OR_TIMED_OUT/);
});

check('Provider health distinguishes configured credentials from verified upstream connectivity', () => {
  const authSource = read('serverAuth.ts');
  const connections = read('src/components/ConnectionsWorkspace.tsx');
  const terminal = read('src/components/TerminalWorkbench.tsx');
  assert.match(authSource, /liveGeminiAvailable: false/);
  assert.match(authSource, /providerConnectivityVerified: false/);
  assert.match(server, /CONFIGURED_NOT_PROBED/);
  assert.match(modelBackend, /data\.providerConnectivityVerified === true && data\.liveGeminiAvailable === true/);
  assert.match(connections, /data\.providerConnectivityVerified === true/);
  assert.match(terminal, /upstream verified:/);
});


check('Owner bootstrap promotion occurs only after successful one-time bootstrap', () => {
  const start = server.indexOf("app.post('/api/rbac/bootstrap-owner'");
  const end = server.indexOf("app.get('/api/rbac/system-config'", start);
  assert.notEqual(start, -1);
  assert.notEqual(end, -1);
  const route = server.slice(start, end);
  const refusal = route.indexOf('if (!bootstrapRes.success)');
  const promotion = route.indexOf('addAuthorizedOwnerEmail(principal.email)');
  assert.ok(refusal >= 0 && promotion > refusal, 'owner registry promotion must follow successful bootstrap gate');
  assert.match(route.slice(refusal, promotion), /return res\.status\(409\)/);
});

check('One-time owner bootstrap requires and binds the real Firebase UID', () => {
  assert.match(auth, /uid: string;[\s\S]{0,180}email: string;/);
  assert.match(auth, /The real Firebase Authentication UID is required/);
  assert.match(auth, /existingMatching\.uid !== normalizedUid/);
  assert.doesNotMatch(auth, /uid: params\.uid \|\| `owner_/);
});

check('System-wide node and network diagnostics are privileged-only', () => {
  const nodeStart = server.indexOf("app.get('/api/node/status'");
  const nodeEnd = server.indexOf('// 2. Primary Node Lifecycle', nodeStart);
  const nodeRoute = server.slice(nodeStart, nodeEnd);
  assert.match(nodeRoute, /isSuperAdminOrOwnerServer\(principal\)/);
  assert.match(nodeRoute, /PRIVILEGED_ROLE_REQUIRED/);
  const networkStart = server.indexOf("app.get('/api/network/status'");
  const networkEnd = server.indexOf("app.post('/api/network/tailscale/endpoint'", networkStart);
  const networkRoute = server.slice(networkStart, networkEnd);
  assert.match(networkRoute, /isSuperAdminOrOwnerServer\(principal\)/);
  assert.match(networkRoute, /PRIVILEGED_ROLE_REQUIRED/);
});

check('System health matrix redacts global account and host details for standard users', () => {
  const start = server.indexOf("app.get('/api/system/health-matrix'");
  const end = server.indexOf('// 1a-2. Session Status', start);
  const route = server.slice(start, end);
  assert.match(route, /activeAccountsCount:[\s\S]{0,140}countActiveSystemOwners\(\)/);
  assert.match(route, /systemDiagnosticsRestricted/);
  assert.match(route, /accountScope: 'self'/);
});


check('Primary owner can be optionally bound to the configured Firebase UID', () => {
  assert.match(auth, /const PRIMARY_OWNER_UID = \(process\.env\.OWNER_UID \|\| ''\)/);
  assert.match(auth, /normalizedEmail === PRIMARY_OWNER && PRIMARY_OWNER_UID && uid && uid !== PRIMARY_OWNER_UID/);
  assert.match(auth, /isVerifiedOwner\(normalizedEmail, emailVerified, uid\)/);
  assert.match(auth, /isVerifiedOwner\(principal\.email, principal\.emailVerified, principal\.id\)/);
  assert.match(envExample, /OWNER_UID=""/);
});

check('Adding an owner email never fabricates a Firebase UID', () => {
  const start = auth.indexOf('export function addOwnerEmail');
  const end = auth.indexOf('export const addAuthorizedOwnerEmail', start);
  const fn = auth.slice(start, end);
  assert.doesNotMatch(fn, /usr_owner_|Date\.now\(\).*uid|indexAccount\(newOwnerAcc\)/);
  assert.match(fn, /keep only the email allowlist/i);
});


check('Firebase email lookup cannot inherit a managed role from a different UID', () => {
  const start = auth.indexOf('export async function verifyFirebaseIdToken');
  const end = auth.indexOf('export function extractBearerToken', start);
  const fn = auth.slice(start, end);
  assert.match(fn, /emailBoundAccount\.uid !== user\.localId/);
  assert.match(fn, /return null;[\s\S]{0,180}const principal = buildPrincipal/);
});

check('Enhanced core job routes remain authenticated and owner-scoped', () => {
  const jobsListStart = server.indexOf("app.get('/api/core/jobs'");
  const jobsGetStart = server.indexOf("app.get('/api/core/jobs/:jobId'");
  const cancelStart = server.indexOf("app.post('/api/core/jobs/:jobId/cancel'");
  assert.notEqual(jobsListStart, -1);
  assert.notEqual(jobsGetStart, -1);
  assert.notEqual(cancelStart, -1);
  assert.match(server.slice(jobsListStart, jobsGetStart), /requireAuth/);
  const getRoute = server.slice(jobsGetStart, server.indexOf("app.post('/api/core/jobs/:jobId/approve'", jobsGetStart));
  assert.match(getRoute, /requireAuth/);
  assert.match(getRoute, /getJob\(req\.params\.jobId, req\.principal!\.id\)/);
  const cancelRoute = server.slice(cancelStart, server.indexOf("app.post('/api/core/worker/run-once'", cancelStart));
  assert.match(cancelRoute, /requireAuth/);
  assert.match(cancelRoute, /jobs\.cancel\(req\.params\.jobId, req\.principal!\)/);
});

check('Enhanced approval and local worker endpoints require privileged roles', () => {
  const approveStart = server.indexOf("app.post('/api/core/jobs/:jobId/approve'");
  const workerStart = server.indexOf("app.post('/api/core/worker/run-once'");
  assert.match(server.slice(approveStart, workerStart), /requireAuth, requireSuperAdminOrOwner/);
  assert.match(server.slice(workerStart, workerStart + 1_200), /requireAuth, requireSuperAdminOrOwner/);
  assert.match(server.slice(workerStart, workerStart + 1_200), /isTrustedLocalCoreRuntime\(\)/);
});

check('New capability engine rechecks exact action digest before invoking registered code', () => {
  const jobsCore = read('src/core/jobs/jobService.ts');
  const policyCore = read('src/core/security/policy.ts');
  const registryCore = read('src/core/capabilities/registry.ts');
  assert.match(jobsCore, /expectedDigest !== job\.actionDigest/);
  assert.match(jobsCore, /this\.capabilities\.invoke\(job\.capabilityId/);
  assert.match(policyCore, /capability\.risk === 'CRITICAL'[\s\S]{0,280}return deny/);
  assert.match(policyCore, /A server-resolved resource owner is required/);
  assert.match(registryCore, /Capability registry is sealed/);
  assert.match(registryCore, /MAX_INPUT_BYTES = 64 \* 1024/);
});

check('Job execution revalidates latest account state and approval before invoking capabilities', () => {
  const jobsCore = read('src/core/jobs/jobService.ts');
  const authCore = read('serverAuth.ts');
  assert.match(authCore, /export function resolveCurrentManagedJobPrincipal\(uid: string\)/);
  assert.match(authCore, /managed\.uid !== uid/);
  assert.match(jobsCore, /resolvePrincipal \? await resolvePrincipal\(job\.ownerUid\) : null/);
  assert.match(jobsCore, /EXECUTION_POLICY_REVALIDATION_FAILED/);
  assert.match(jobsCore, /SESSION_REVOKED_AFTER_JOB_CREATION/);
  assert.match(jobsCore, /EXECUTION_APPROVAL_REVALIDATION_FAILED/);
  assert.match(server, /jobs\.runOne\(workerId, 'LOCAL_NODE', resolveCurrentManagedJobPrincipal\)/);
});

check('Unconfirmed Firebase target is disabled and requires explicit owner configuration', () => {
  assert.match(firebaseConfig.projectId, /^SET_/);
  assert.match(firebaseConfig.apiKey, /^SET_/);
  assert.equal(firebaseCliConfig.firestore.database, '(default)');
  assert.match(firebase, /VITE_FIREBASE_PROJECT_ID \|\| firebaseConfig\.projectId/);
  assert.match(envExample, /FIREBASE_PROJECT_ID=/);
  assert.match(envExample, /FIREBASE_FIRESTORE_DATABASE_ID=/);
  assert.match(auth, /const FIREBASE_CONFIGURED = Boolean\(/);
  assert.match(auth, /if \(!FIREBASE_CONFIGURED\) return null/);
  assert.match(auth, /code: 'FIREBASE_NOT_CONFIGURED'/);
  assert.match(auth, /databaseConfigured: FIREBASE_CONFIGURED/);
  assert.doesNotMatch(server + connections, /hospitalmanagtsystem|ai-studio-lorinunifiedmast/);
});

check('Local store binds encrypted records to their owning database row', () => {
  const storeCore = read('src/core/persistence/sqliteStore.ts');
  assert.match(storeCore, /cipher\.setAAD/);
  assert.match(storeCore, /decipher\.setAAD/);
  assert.match(storeCore, /lorin-job-v1/);
  assert.match(storeCore, /BEGIN IMMEDIATE/);
  assert.match(storeCore, /DURABLE_LOCAL_STORE_UNAVAILABLE/);
});

check('Network listener defaults to loopback and requires trusted TLS termination for network binds', () => {
  assert.match(server, /LORIN_SERVER_HOST \|\| '127\.0\.0\.1'/);
  assert.match(server, /LORIN_ALLOW_NETWORK_BIND !== 'true'/);
  assert.match(server, /LORIN_NETWORK_TLS_TERMINATED !== 'true'/);
  assert.match(envExample, /LORIN_NETWORK_TLS_TERMINATED=false/);
});

console.log(`LORIN static security regression checks: ${checks.length}/${checks.length} PASS`);
for (const name of checks) console.log(`PASS ${name}`);
