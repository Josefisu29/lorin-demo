import test from 'node:test';
import assert from 'node:assert/strict';
import { consumeOllamaNdjsonStream } from '../../src/core/providers/ollamaNdjson.ts';

function streamFrom(chunks: string[]): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  return new ReadableStream<Uint8Array>({
    start(controller) {
      for (const chunk of chunks) controller.enqueue(encoder.encode(chunk));
      controller.close();
    }
  });
}

test('Ollama NDJSON parser handles packets split across arbitrary byte chunks', async () => {
  const chunks = ['{"model":"qwen3', '.5:latest","response":"hel', 'lo ","done":false}\n{"response":"world","done":true}\n'];
  const observed: string[] = [];
  const result = await consumeOllamaNdjsonStream(streamFrom(chunks), 'fallback', value => observed.push(value));
  assert.deepEqual(result, { success: true, text: 'hello world', modelUsed: 'qwen3.5:latest' });
  assert.deepEqual(observed, ['hello ', 'hello world']);
});

test('Ollama NDJSON parser refuses truncated output without the done marker', async () => {
  const result = await consumeOllamaNdjsonStream(streamFrom(['{"response":"partial"}\n']), 'qwen', () => {});
  assert.equal(result.success, false);
  assert.equal(result.error, 'LOCAL_OLLAMA_STREAM_INCOMPLETE');
});

test('Ollama NDJSON parser rejects malformed packets', async () => {
  const result = await consumeOllamaNdjsonStream(streamFrom(['{"response":}\n']), 'qwen', () => {});
  assert.equal(result.success, false);
  assert.equal(result.error, 'LOCAL_OLLAMA_INVALID_STREAM_PACKET');
});

test('Ollama NDJSON parser surfaces provider errors without marking inference successful', async () => {
  const result = await consumeOllamaNdjsonStream(streamFrom(['{"error":"model not found"}\n']), 'qwen', () => {});
  assert.equal(result.success, false);
  assert.equal(result.error, 'model not found');
});

test('Ollama NDJSON parser enforces an output bound', async () => {
  const result = await consumeOllamaNdjsonStream(streamFrom(['{"response":"12345"}\n']), 'qwen', () => {}, { maxOutputCharacters: 4 });
  assert.equal(result.success, false);
  assert.equal(result.error, 'LOCAL_OLLAMA_OUTPUT_LIMIT_EXCEEDED');
});

test('Ollama NDJSON parser accepts a final done packet without a trailing newline', async () => {
  const result = await consumeOllamaNdjsonStream(streamFrom(['{"response":"final","done":true}']), 'qwen', () => {});
  assert.deepEqual(result, { success: true, text: 'final', modelUsed: 'qwen' });
});
