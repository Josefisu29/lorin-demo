import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path: string) => readFileSync(new URL(`../../${path}`, import.meta.url), 'utf8');

const app = read('src/App.tsx');
const toolbar = read('src/components/LorinWorkspaceToolbar.tsx');
const sidebar = read('src/components/SidebarNavigation.tsx');
const chat = read('src/components/ChatWorkspace.tsx');
const css = read('src/index.css');

test('private application shell mounts the shared toolbar and accessible main landmark', () => {
  assert.match(app, /<LorinWorkspaceToolbar\s/);
  assert.match(app, /id="lorin-main-content"/);
  assert.match(app, /href="#lorin-main-content"/);
  assert.match(app, /aria-label="LORIN main workspace"/);
});

test('workspace toolbar displays configured preference without claiming provider health', () => {
  assert.match(toolbar, /Configured runtime preference/);
  assert.match(toolbar, /Provider health is shown separately/);
  assert.match(toolbar, /pendingApprovalsCount/);
  assert.match(toolbar, /isMicActive/);
  assert.match(toolbar, /isCameraActive/);
});

test('sidebar exposes distinct Knowledge Vault and Private Vault routes', () => {
  assert.match(sidebar, /id: 'vault'[\s\S]*?label: 'Knowledge Vault'/);
  assert.match(sidebar, /id: 'laurenVault'[\s\S]*?label: 'Private Vault'/);
  assert.match(sidebar, /PolicyEngine\.canAccessModule\(principal, item\.id\)/);
});

test('sidebar keeps the major intelligence, execution and privacy workspaces discoverable', () => {
  for (const route of ['chat', 'projects', 'tasks', 'specialists', 'gideon', 'voice', 'video', 'deviceCenter', 'connections', 'memory', 'security', 'ownerGateway', 'settings']) {
    assert.ok(sidebar.includes(`id: '${route}'`), `missing navigation route: ${route}`);
  }
});

test('suggested conversation starters fill the draft and do not auto-submit', () => {
  assert.match(chat, /setInputText\(suggestion\.prompt\)/);
  assert.match(chat, /textareaRef\.current\.focus\(\)/);
  assert.match(chat, /Review this code or software problem/);
  assert.match(chat, /Help me research and understand a topic/);
});

test('responsive layout and reduced-motion support are defined', () => {
  assert.match(css, /@media \(max-width: 767px\)/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
  assert.match(css, /\.lorin-commandbar/);
  assert.match(css, /\.lorin-welcome-actions/);
});

test('MOSAiRA entry is described as a separate platform boundary', () => {
  const navigationShell = read('src/components/NavigationShell.tsx');
  assert.match(navigationShell, /separate MOSAIRA platform/);
  assert.match(navigationShell, /LORIN private data and owner permissions are not shared/);
});

test('device center does not invent online availability or subsystem counts before health data arrives', () => {
  const devices = read('src/components/NetworkDeviceControlCenter.tsx');
  assert.match(devices, /useState<HybridAvailabilityMode \| null>\(null\)/);
  assert.match(devices, /AVAILABILITY NOT VERIFIED/);
  assert.doesNotMatch(devices, /subsystems\.length \|\| 18/);
  assert.doesNotMatch(devices, /category === 'core'\)\.length \|\| 5/);
});

test('hologram presence does not fabricate speech amplitude', () => {
  const hologram = read('src/components/ImmersiveHologramModal.tsx');
  assert.doesNotMatch(hologram, /Math\.random\(\).*audioLevel|setAudioLevel\(synthSpeaking/);
  assert.match(hologram, /audioLevel=\{0\}/);
});

test('model and diagnostic surfaces display unknown measurements as unknown', () => {
  const gateway = read('src/components/UnifiedOwnerGateway.tsx');
  const inspector = read('src/components/ContextInspectorPanel.tsx');
  assert.doesNotMatch(gateway, /contextLimit \|\| 128000/);
  assert.match(gateway, /Context not reported/);
  assert.match(inspector, /Not measured/);
});
