import { coreHealth } from '../serverCore.ts';

console.log(JSON.stringify(coreHealth(true), null, 2));
