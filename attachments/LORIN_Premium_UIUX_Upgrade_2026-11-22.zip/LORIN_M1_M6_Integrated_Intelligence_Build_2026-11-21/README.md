# LORIN — Personal Intelligence. Everywhere.

> **M1–M6 integration working build — 21 November 2026.** This is an enhanced source working copy, not a production-ready release or Windows installer. See `docs/LORIN_M1_M6_IMPLEMENTATION_REPORT_2026-11-21.md`, `docs/LORIN_M1_M6_VERIFICATION_2026-11-21.md`, `docs/LORIN_M1_M6_COMPLETION_BACKLOG_2026-11-21.md` and `BUILD_STATUS_2026-11-21_ENHANCED.md` before running it. Latest supported test evidence: 24/24 focused core tests, 38/38 static security checks and 120 TypeScript/TSX implementation files parsed with zero syntax diagnostics. Full dependency installation and production build remain blocked by the Node/package-lock environment requirements below.

**System Classification:** Private, owner-controlled personal assistant (`LORIN`) with a separately governed public AI research/model platform (`MOSAIRA`)  
**Architecture:** Full-Stack TypeScript, React 19, Express Server Proxy, `@google/genai` SDK, Local Ollama Runtime, and Firebase Authentication & Firestore.

---

## 1. Architecture & Security Boundaries

1. **Intended Public/Private Boundary (release verification still required):**
   - **LORIN (Private Assistant):** Firebase-authenticated personal assistant with server-resolved roles, private memory, Knowledge Vault, projects, tasks and permission-gated tools. Do not expose private memory, credentials, owner controls or private routes to public users.
   - **MOSAIRA (Separate Public AI Platform):** Model discovery, comparison, playground, dataset governance and developer capabilities. The current codebase contains both product areas in one application/repository; route separation alone is not a complete tenant/security boundary. Public MOSAIRA deployment must remain blocked until independent trust boundaries, databases, privileged sessions and storage access are tested.

2. **Server-Side Only Gemini API Integration:**
   - `GEMINI_API_KEY` is read exclusively by the backend (`server.ts` / `api/index.ts`).
   - It is **never** exposed in `VITE_*` client variables, browser `localStorage`, or frontend bundles.
   - Internal model identifiers are resolved authoritatively on the server (`GEMINI_MODEL`) and abstracted behind private capability tier labels in the user interface.

3. **Unified LORIN Specialist Responsibilities:**
   - `Lena` — Guardian: permissions, security and risk.
   - `Owen` — Coordinator: plans, integrations and workflows.
   - `Riley` — Companion: voice, interaction and adaptive guidance.
   - `Iris` — Investigator: research, evidence and verification.
   - `Nolan` — Strategist: decision support and planning.
   - `GIDEON` — Timeline intelligence: continuity, events and project history.
   These are the six core specialist responsibilities coordinated by one LORIN assistant. The current source also defines ten extended specialist profiles; their canonical status and whether they belong to private LORIN or a separate public catalogue remain unresolved and must be decided before release. MOSAIRA's public personas must not be treated as private LORIN specialists.

---

## 2. Environment Variables

Copy `.env.example` to `.env` (or `backend/.env` on Windows):

| Variable | Scope | Description |
| :--- | :--- | :--- |
| `GEMINI_API_KEY` | **Backend Only** | Google Gemini API key used by `@google/genai` on the server. Never prefix with `VITE_`. |
| `GEMINI_MODEL` | **Backend Only** | Optional default model override (`gemini-3.8-flash` or `gemini-3.1-flash-lite`). |
| `OLLAMA_BASE_URL` | **Backend / Local** | Local Ollama server URL (default: `http://localhost:11434`). |
| `OWNER_EMAIL` | **Backend Only** | Verified Firebase email designated as the primary System Owner. Leave blank until owner provisioning is deliberately configured. |
| `OWNER_UID` | **Backend Only** | Optional exact Firebase Auth UID binding for `OWNER_EMAIL`; set it to prevent the primary owner email from inheriting privileges through a different Firebase UID. |
| `APP_URL` | **Backend** | Hosted base URL (default: `http://localhost:3000`). |
| `PORT` | **Backend** | HTTP server listen port (default: `3000`). |

---

## 3. Local Windows Development Setup

### Step 1 — Validate the Build Environment Before Installing
Use Node.js **24.12 or newer** and npm **10.9.2** (the project versions are declared in `package.json`).

Open **PowerShell** in the project root and run:
```powershell
node scripts/preflight.mjs --before-install
```

Do not proceed if preflight reports a Node-version or package-lock mismatch. The current delivered source snapshot has a known package manifest/lockfile mismatch; the lockfile must be reconciled in a supported Node 24.12+ environment before the clean install can succeed. Once preflight passes, install the exact locked dependencies:
```powershell
npm ci
node scripts/preflight.mjs
```
Do not use `npm install` as a workaround for the mismatch because it can silently rewrite the lockfile and make the result non-reproducible.

### Step 2 — Configure `.env`
Create your local `.env` file from the template:
```powershell
# PowerShell
Copy-Item .env.example .env

# Or in cmd.exe:
copy .env.example .env
```
Open `.env` and set only the providers and Firebase settings you intend to use. Set `OWNER_EMAIL` and, preferably, `OWNER_UID` only for the designated, verified Firebase account. The server automatically checks both `./.env` and `./backend/.env`.

### One-time System Owner provisioning

1. Create the designated Firebase Authentication account and complete email verification.
2. Set `OWNER_EMAIL` and the real Firebase Authentication UID (`OWNER_UID`) only in the trusted server/deployment environment.
3. From a trusted administrator shell, run `npx tsx scripts/bootstrapSystemOwner.ts` with those variables set. Do not generate or guess a UID.
4. The CLI bootstraps the server-managed registry. It does not provision the Firestore `user_roles/{uid}` document through Firebase Admin SDK; complete that Firestore role-record bootstrap through your trusted Firebase administrator process before relying on privileged Firestore rules.

Never place credentials in chat, source code, `.env.example`, frontend variables or the release ZIP.

### Step 3 — Start the Full-Stack Development Server
```powershell
npm run dev
```
Open `http://localhost:3000` in your browser.

### Step 4 — Verify Health & Run Automated Tests
```powershell
# Check provider health endpoint
curl http://localhost:3000/api/health
curl http://localhost:3000/api/providers/status

# Run unit & security verification suite
npm test

# Run TypeScript static typecheck and production build
npm run lint
npm run build
```

---

## 4. Vercel Production Deployment Setup

The repository includes `vercel.json` and the serverless entry point `api/index.ts` which exports the Express `app` while serving the compiled Vite SPA from `dist/`.

1. **Import Project into Vercel:**
   - Connect your Git repository to Vercel.
   - Framework Preset: `Vite` (Build command: `npm run build`, Output directory: `dist`).

2. **Configure Vercel Environment Variables:**
   In **Vercel Project Settings → Environment Variables**, add:
   - `GEMINI_API_KEY` (Mark as Sensitive / Backend only — **do not** add `VITE_` prefix)
   - `GEMINI_MODEL` = `gemini-3.8-flash`
   - `OWNER_EMAIL` = `<your-verified-firebase-email>`

3. **Deploy & Verify (not yet release-verified):**
   - Deploy to a private Preview environment first.
   - Verify `/api/health`, authenticated `/api/me`, Firestore rules, authenticated provider inference and PWA routes before production.
   - Note: Local `localhost:11434` Ollama daemons are reachable only from the local host; on Vercel, a local Ollama instance is not reachable without a separately secured private network gateway.
   - The current server also writes some policy, conversation and workspace snapshots to local JSON files or `/tmp` in serverless mode. This is not durable multi-instance cloud persistence; do not enable production multi-instance operation until those stores are migrated to an authoritative shared database.
   - The owner bootstrap script requires the real Firebase UID (`OWNER_UID`) as well as the verified `OWNER_EMAIL`. Run it only from a trusted administrator shell after the Firebase user exists.

---

## 5. Google AI Studio Environment

- In Google AI Studio Build, `GEMINI_API_KEY` is injected into the server environment automatically.
- The Express server runs on port `3000` (`npm run dev`) and proxies all `/api/*` routes while serving the React application.


## Local-node encryption key

- Local development creates a random 32-byte installation key at `~/.lorin/keys/node-storage-key` with restrictive filesystem permissions. Back it up securely; losing it makes local encrypted node state unrecoverable.
- Production and serverless deployments must configure `LORIN_NODE_STORAGE_KEY` in the hosting secret manager. Generate at least 32 bytes of cryptographically random secret material (for example, `openssl rand -hex 32`). Never commit this key or place it in a `VITE_*` variable.
- The server can read existing local records encrypted by the prior machine-derived key for migration, then rewrites successfully loaded records using the new installation key. This legacy path is decrypt-only and disabled in production/serverless deployments.
- Build the production server before starting it: `npm run build` followed by `npm start`. The generated `server.js` file is not source-controlled.

## 2026-11-21 continuation status

The current continuation working copy includes user-state integrity fixes, fail-closed policy behavior when the policy server is unavailable, action-bound owner approvals for high-impact primary-node commands, and server-side sanitization of unverified client task-completion claims. It also includes source-level reviews of six uploaded reference archives (one duplicate archive is identified explicitly).

- See `docs/LORIN_BUILD_CONTINUATION_REPORT_2026-11-21.md` for the current build status, tests, blockers and next engineering milestones.
- See `docs/LORIN_REFERENCE_REPOSITORY_DECISIONS_2026-11-21.md` for the full JARVIS / ULTRON / legacy J.A.R.V.I.S. source analysis and licensing/safety decisions.
- See `docs/LORIN_V2_FEATURE_MATRIX.md` and `docs/LORIN_V2_IMPLEMENTATION_LOG.md` for dated capability status and changes.

**This is an enhanced engineering source build, not a production release.** Latest M1–M6 work passes 24/24 focused core tests and 38/38 static security checks; syntax transpilation passes for 120 non-declaration TypeScript/TSX implementation and test files. Semantic typechecking, full Vitest, a production build, live Firebase/provider inference, physical browser/device QA and deployment remain unverified. Firebase is deliberately unconfigured until the owner supplies the intended LORIN project; see `docs/FIREBASE_PROJECT_CONFIGURATION_REQUIRED.md`. The declared Node requirement is `>=24.12.0`; the inspected build environment used Node 22.16.0. The package manifest/lockfile mismatch must be reconciled before `npm ci` can pass. See the M1–M6 implementation and verification reports for exact acceptance status.


## M1–M6 integrated engineering continuation — 21 November 2026

The M1–M6 additions connect local Ollama health/streaming and privacy-gated routing, an owner-scoped encrypted local retrieval index, an opt-in leased job worker with restricted file capabilities, explicit VAD/foreground wake phrase controls, paired-device foundations, and guarded Windows PowerShell setup scripts. See:

- `docs/LORIN_M1_M6_IMPLEMENTATION_REPORT_2026-11-21.md`
- `docs/LORIN_M1_M6_VERIFICATION_2026-11-21.md`
- `docs/LORIN_M1_M6_COMPLETION_BACKLOG_2026-11-21.md`

Latest tests: 24/24 core and 38/38 static security checks pass. The local index remains supplemental (not a complete data migration); cloud sync/backup, general code sandbox, live voice/vision, physical paired-device tests, Windows DPAPI/ACL protection and installer are outstanding. Production build remains blocked by Node and lockfile requirements.

## Finished-LORIN acceptance target

The user's intended capabilities and the exact evidence still required for each one are tracked in `docs/LORIN_TARGET_CAPABILITY_ACCEPTANCE_MATRIX_2026-11-21.md`. The phased engineering plan is `docs/LORIN_NEXT_RELEASE_COMPLETION_PLAN_2026-11-21.md`. These documents explicitly distinguish existing source, tested foundations, live acceptance and work not yet built.
