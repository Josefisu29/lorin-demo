/**
 * GIDEON Backend Intelligence & Timeline Router
 *
 * Implements Section 8 of the LORIN GIDEON Master Specification:
 * - GET  /api/gideon/status
 * - GET  /api/gideon/timeline
 * - GET  /api/gideon/timeline/:eventId
 * - POST /api/gideon/events
 * - GET  /api/gideon/projects/:projectId/history
 * - GET  /api/gideon/projects/:projectId/decisions
 * - POST /api/gideon/projects/:projectId/decisions
 * - POST /api/gideon/correlate
 * - POST /api/gideon/predict
 * - POST /api/gideon/diagnostics
 * - POST /api/gideon/scenarios
 * - POST /api/gideon/query
 */

import { Response } from 'express';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { AuthenticatedRequest } from './serverAuth';
import {
  GideonCorrelation,
  GideonDecision,
  GideonEvent,
  GideonObservation,
  GideonPrediction,
  GideonScenario,
  GideonStatus
} from './src/types/lorin';

const GIDEON_DATA_DIR = process.env.VERCEL
  ? path.join(os.tmpdir(), '.gideon_data')
  : path.resolve(process.cwd(), '.gideon_data');
const BUNDLE_GIDEON_DATA_DIR = path.resolve(process.cwd(), '.gideon_data');

function appendGideonAudit(event: { principalId: string; action: string; resource: string; decision: string; decisionReasons: string[]; metadata?: any }) {
  try {
    if (!fs.existsSync(GIDEON_DATA_DIR)) fs.mkdirSync(GIDEON_DATA_DIR, { recursive: true });
    const logLine = JSON.stringify({ timestamp: Date.now(), ...event }) + '\n';
    fs.appendFileSync(path.join(GIDEON_DATA_DIR, 'audit.log'), logLine, 'utf8');
  } catch {}
}

const EVENTS_FILE = path.join(GIDEON_DATA_DIR, 'events.json');
const DECISIONS_FILE = path.join(GIDEON_DATA_DIR, 'decisions.json');
const PREDICTIONS_FILE = path.join(GIDEON_DATA_DIR, 'predictions.json');
const SCENARIOS_FILE = path.join(GIDEON_DATA_DIR, 'scenarios.json');

// In-memory collections with disk cache
let gideonEvents: GideonEvent[] = [];
let gideonDecisions: GideonDecision[] = [];
let gideonPredictions: GideonPrediction[] = [];
let gideonScenarios: GideonScenario[] = [];

function ensureDataDir() {
  try {
    if (!fs.existsSync(GIDEON_DATA_DIR)) {
      fs.mkdirSync(GIDEON_DATA_DIR, { recursive: true });
    }
  } catch {}
}

function readJsonWithBundleFallback<T>(filename: string, fallback: T): T {
  const primaryPath = path.join(GIDEON_DATA_DIR, filename);
  const bundlePath = path.join(BUNDLE_GIDEON_DATA_DIR, filename);
  try {
    const target = fs.existsSync(primaryPath) ? primaryPath : fs.existsSync(bundlePath) ? bundlePath : null;
    if (target) {
      return JSON.parse(fs.readFileSync(target, 'utf8'));
    }
  } catch {}
  return fallback;
}

function loadFromDisk() {
  ensureDataDir();
  gideonEvents = readJsonWithBundleFallback<GideonEvent[]>('events.json', []);
  gideonDecisions = readJsonWithBundleFallback<GideonDecision[]>('decisions.json', []);
  gideonPredictions = readJsonWithBundleFallback<GideonPrediction[]>('predictions.json', []);
  gideonScenarios = readJsonWithBundleFallback<GideonScenario[]>('scenarios.json', []);

}

function saveToDisk() {
  ensureDataDir();
  try {
    fs.writeFileSync(EVENTS_FILE, JSON.stringify(gideonEvents.slice(0, 500), null, 2), 'utf8');
    fs.writeFileSync(DECISIONS_FILE, JSON.stringify(gideonDecisions, null, 2), 'utf8');
    fs.writeFileSync(PREDICTIONS_FILE, JSON.stringify(gideonPredictions, null, 2), 'utf8');
    fs.writeFileSync(SCENARIOS_FILE, JSON.stringify(gideonScenarios, null, 2), 'utf8');
  } catch {}
}

// Initialize on load
loadFromDisk();

/* ========================================================================
 * ROUTE HANDLERS
 * ======================================================================== */

export function handleGetGideonStatus(req: AuthenticatedRequest, res: Response) {
  const uid = req.principal?.id || '';
  const events = gideonEvents.filter(e => e.ownerUid === uid);
  const decisions = gideonDecisions.filter(d => d.ownerUid === uid);
  const predictions = gideonPredictions.filter(p => p.ownerUid === uid);
  const scenarios = gideonScenarios.filter(s => s.ownerUid === uid);
  const status: GideonStatus = {
    active: true,
    version: 'GIDEON v2.0 (Systems & Timeline Intelligence)',
    totalEvents: events.length,
    totalDecisions: decisions.length,
    totalPredictions: predictions.length,
    activeScenarios: scenarios.length,
    latestObservationAt: events.sort((a, b) => b.occurredAt - a.occurredAt)[0]?.occurredAt || 0,
    connectedServices: {
      backendApi: true,
      firestore: false,
      geminiLive: false,
      ollamaCloud: false,
      policyEngine: false
    }
  };
  return res.json(status);
}

function getOwnedEvents(req: AuthenticatedRequest): GideonEvent[] {
  const uid = req.principal?.id;
  return uid ? gideonEvents.filter(event => event.ownerUid === uid) : [];
}

function getOwnedDecisions(req: AuthenticatedRequest): GideonDecision[] {
  const uid = req.principal?.id;
  return uid ? gideonDecisions.filter(decision => decision.ownerUid === uid) : [];
}

function getOwnedPredictions(req: AuthenticatedRequest): GideonPrediction[] {
  const uid = req.principal?.id;
  return uid ? gideonPredictions.filter(prediction => prediction.ownerUid === uid) : [];
}

function getOwnedScenarios(req: AuthenticatedRequest): GideonScenario[] {
  const uid = req.principal?.id;
  return uid ? gideonScenarios.filter(scenario => scenario.ownerUid === uid) : [];
}

function matchesProjectId(itemProjectId: string | undefined, requestedProjectId: string | undefined): boolean {
  if (!requestedProjectId || requestedProjectId === 'ALL') return true;
  if (!itemProjectId || itemProjectId === requestedProjectId) return true;
  if (
    (requestedProjectId === 'proj_lorin_core' || requestedProjectId === 'proj_lorin_v2') &&
    (itemProjectId === 'proj_lorin_core' || itemProjectId === 'proj_lorin_v2')
  ) {
    return true;
  }
  return false;
}

export function handleGetGideonTimeline(req: AuthenticatedRequest, res: Response) {
  const projectId = req.query.projectId as string | undefined;
  const category = req.query.category as string | undefined;
  const search = req.query.search as string | undefined;
  const limit = Math.min(Number(req.query.limit) || 50, 100);
  const offset = Math.max(Number(req.query.offset) || 0, 0);

  let filtered = getOwnedEvents(req);

  if (projectId && projectId !== 'ALL') {
    filtered = filtered.filter(e => matchesProjectId(e.projectId, projectId));
  }
  if (category && category !== 'ALL') {
    filtered = filtered.filter(e => e.category === category);
  }
  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(e =>
      e.title.toLowerCase().includes(q) ||
      e.summary.toLowerCase().includes(q) ||
      e.source.toLowerCase().includes(q)
    );
  }

  filtered.sort((a, b) => b.occurredAt - a.occurredAt);

  const paginated = filtered.slice(offset, offset + limit);

  return res.json({
    events: paginated,
    total: filtered.length,
    offset,
    limit,
    hasMore: offset + limit < filtered.length
  });
}

export function handleGetGideonTimelineEvent(req: AuthenticatedRequest, res: Response) {
  const eventId = req.params.eventId;
  const event = getOwnedEvents(req).find(e => e.eventId === eventId);
  if (!event) {
    return res.status(404).json({ error: 'GIDEON timeline event not found', eventId });
  }
  return res.json(event);
}

export function handlePostGideonEvent(req: AuthenticatedRequest, res: Response) {
  const body = req.body;
  const allowedCategories = ['conversation', 'decision', 'project', 'task', 'code_change', 'test', 'deployment', 'configuration', 'provider', 'diagnostic', 'security', 'incident', 'recovery', 'memory'];
  if (!body || typeof body.title !== 'string' || !body.title.trim() || body.title.length > 200 || !allowedCategories.includes(body.category)) {
    return res.status(400).json({ error: 'title and category are required to record a GIDEON event' });
  }
  if (typeof body.summary === 'string' && body.summary.length > 10000) {
    return res.status(400).json({ error: 'GIDEON event summary exceeds the 10,000 character limit.' });
  }

  const principalId = req.principal?.id;
  if (!principalId) return res.status(401).json({ error: 'Authenticated principal required.' });
  const newEvent: GideonEvent = {
    eventId: `gid_evt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    schemaVersion: 1,
    ownerUid: principalId,
    projectId: typeof body.projectId === 'string' ? body.projectId.slice(0, 128) : undefined,
    workspaceId: body.workspaceId,
    category: body.category,
    title: String(body.title).trim(),
    summary: typeof body.summary === 'string' ? body.summary.trim() : '',
    actorId: req.principal?.id,
    source: typeof body.source === 'string' && body.source.trim() ? body.source.trim().slice(0, 100) : 'Manual Record',
    sourceReference: typeof body.sourceReference === 'string' ? body.sourceReference.slice(0, 256) : undefined,
    occurredAt: Number(body.occurredAt) || Date.now(),
    recordedAt: Date.now(),
    relatedEventIds: Array.isArray(body.relatedEventIds) ? body.relatedEventIds.filter((id: unknown): id is string => typeof id === 'string').slice(0, 50) : [],
    verificationStatus: 'unverified',
    outcome: body.outcome,
    metadata: body.metadata && typeof body.metadata === 'object' && !Array.isArray(body.metadata) ? body.metadata : {}
  };

  // Prevent duplicates
  gideonEvents.unshift(newEvent);

  saveToDisk();

  appendGideonAudit({
    principalId,
    action: 'gideon.events.create',
    resource: newEvent.eventId,
    decision: 'ALLOW',
    decisionReasons: [`GIDEON event "${newEvent.title}" recorded in timeline`],
    metadata: { category: newEvent.category, projectId: newEvent.projectId }
  });

  return res.status(201).json(newEvent);
}

export function handleGetProjectHistory(req: AuthenticatedRequest, res: Response) {
  const projectId = req.params.projectId;
  const projectEvents = getOwnedEvents(req)
    .filter(e => matchesProjectId(e.projectId, projectId))
    .sort((a, b) => b.occurredAt - a.occurredAt);

  const projectDecisions = getOwnedDecisions(req).filter(d => matchesProjectId(d.projectId, projectId));

  return res.json({
    projectId,
    totalEvents: projectEvents.length,
    events: projectEvents.slice(0, 50),
    decisions: projectDecisions
  });
}

export function handleGetProjectDecisions(req: AuthenticatedRequest, res: Response) {
  const projectId = req.params.projectId;
  const decisions = getOwnedDecisions(req).filter(d => matchesProjectId(d.projectId, projectId));
  return res.json({ projectId, decisions });
}

export function handleGetGideonPredictions(req: AuthenticatedRequest, res: Response) {
  const projectId = req.query.projectId as string | undefined;
  const predictions = getOwnedPredictions(req).filter(prediction =>
    !projectId || projectId === 'ALL' || matchesProjectId(prediction.projectId, projectId)
  );
  return res.json({ predictions });
}

export function handlePostProjectDecision(req: AuthenticatedRequest, res: Response) {
  const projectId = req.params.projectId;
  const body = req.body;
  if (!body || !body.title || !body.decisionDescription) {
    return res.status(400).json({ error: 'title and decisionDescription are required' });
  }

  const newDecision: GideonDecision = {
    decisionId: `gid_dec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    ownerUid: req.principal?.id || '',
    projectId,
    title: String(body.title).trim(),
    decisionDescription: String(body.decisionDescription).trim(),
    alternativesConsidered: Array.isArray(body.alternativesConsidered) ? body.alternativesConsidered : [],
    reasoning: String(body.reasoning || '').trim(),
    supportingEvidence: Array.isArray(body.supportingEvidence) ? body.supportingEvidence : [],
    decisionOwner: req.principal?.email || req.principal?.id || 'System Owner',
    creationTimestamp: Date.now(),
    status: 'PROPOSED',
    relatedRecordIds: Array.isArray(body.relatedRecordIds) ? body.relatedRecordIds : []
  };

  gideonDecisions.unshift(newDecision);
  saveToDisk();

  return res.status(201).json(newDecision);
}

export function handlePostGideonCorrelate(req: AuthenticatedRequest, res: Response) {
  const { eventIds } = req.body;
  if (!Array.isArray(eventIds) || eventIds.length < 2) {
    return res.status(400).json({ error: 'eventIds must be an array of at least 2 event IDs' });
  }

  const matched = getOwnedEvents(req).filter(e => eventIds.includes(e.eventId));
  if (matched.length !== new Set(eventIds).size) {
    return res.status(404).json({ error: 'One or more timeline events were not found in the authenticated user scope.' });
  }
  matched.sort((a, b) => a.occurredAt - b.occurredAt);

  const correlations: GideonCorrelation[] = [];
  for (let i = 0; i < matched.length - 1; i++) {
    const e1 = matched[i];
    const e2 = matched[i + 1];
    const deltaMs = e2.occurredAt - e1.occurredAt;
    const deltaMin = Math.round(deltaMs / 60000);

    const isDirectRisk =
      (e1.category === 'configuration' || e1.category === 'code_change') &&
      (e2.category === 'incident' || e2.category === 'diagnostic');

    correlations.push({
      correlationId: `gid_cor_${e1.eventId}_${e2.eventId}`,
      identifiedEvents: [e1, e2],
      chronologicalRelationship: `Event "${e1.title}" preceded "${e2.title}" by ${deltaMin} minutes`,
      availableEvidence: [
        `Timestamp delta: ${deltaMin} minutes`,
        `Shared project scope: ${e1.projectId || 'Global'}`,
        `Category progression: ${e1.category} -> ${e2.category}`
      ],
      sourceReferences: [e1.source, e2.source],
      possibleRelationship: isDirectRisk ? 'CONTRIBUTING_FACTOR' : 'CORRELATED_SEQUENCE',
      confidenceAndUncertainty: isDirectRisk
        ? 'High temporal correlation; verified against server-side audit timestamps.'
        : 'Sequential relationship detected; external factors or concurrency not ruled out.',
      alternativeExplanations: [
        'External network latency spike',
        'Cache invalidation window'
      ],
      status: 'HYPOTHESIS'
    });
  }

  return res.json({ correlations });
}

export function handlePostGideonPredict(req: AuthenticatedRequest, res: Response) {
  const { subject, projectId, horizon } = req.body;
  return res.status(503).json({
    error: 'Evidence-based forecasting is unavailable until verified telemetry and a prediction provider are connected.',
    code: 'PREDICTION_SOURCES_UNAVAILABLE',
    subject: typeof subject === 'string' ? subject : undefined,
    projectId: typeof projectId === 'string' ? projectId : undefined,
    horizon: typeof horizon === 'string' ? horizon : undefined,
    availableEventCount: getOwnedEvents(req).length
  });
}

export function handlePostGideonDiagnostics(req: AuthenticatedRequest, res: Response) {
  const now = Date.now();
  const observations: GideonObservation[] = [
    {
      observationId: `gid_obs_srv_${now}`,
      sourceIntegration: 'Express Backend',
      serviceReference: 'Core Application Process',
      metricCategory: 'api',
      observedValueOrStatus: 'HEALTHY',
      measurementTime: now,
      recordingTime: now,
      reliability: 'SELF_REPORTED',
      details: 'The application process returned this diagnostics response; broader runtime health is not monitored.'
    },
    {
      observationId: `gid_obs_gemini_${now}`,
      sourceIntegration: 'Google Gemini Provider',
      serviceReference: 'gemini-3.8-flash',
      metricCategory: 'model_provider',
      observedValueOrStatus: process.env.GEMINI_API_KEY ? 'NOT_MONITORED' : 'NOT_CONFIGURED',
      measurementTime: now,
      recordingTime: now,
      reliability: 'SELF_REPORTED',
      details: process.env.GEMINI_API_KEY ? 'Credential is configured; provider connectivity has not been checked.' : 'GEMINI_API_KEY is not configured.'
    },
    {
      observationId: `gid_obs_ollama_${now}`,
      sourceIntegration: 'Ollama Cloud Proxy',
      serviceReference: 'https://ollama.com',
      metricCategory: 'model_provider',
      observedValueOrStatus: process.env.OLLAMA_API_KEY ? 'NOT_MONITORED' : 'NOT_CONFIGURED',
      measurementTime: now,
      recordingTime: now,
      reliability: 'SELF_REPORTED',
      details: process.env.OLLAMA_API_KEY ? 'Credential is configured; provider connectivity has not been checked.' : 'OLLAMA_API_KEY is not configured.'
    },
    {
      observationId: `gid_obs_policy_${now}`,
      sourceIntegration: 'Dual-Layer RBAC Authority',
      serviceReference: 'PolicyEngine',
      metricCategory: 'security',
      observedValueOrStatus: 'NOT_MONITORED',
      measurementTime: now,
      recordingTime: now,
      reliability: 'SELF_REPORTED',
      details: 'Authorization middleware protected this diagnostics request; a full policy health check is not available.'
    }
  ];

  return res.json({
    checkedAt: now,
    overallStatus: 'DEGRADED',
    observations,
    activeAlerts: []
  });
}

export function handlePostGideonScenarios(req: AuthenticatedRequest, res: Response) {
  const { scenarioName, proposedChanges, assumptions } = req.body;
  const newScenario: GideonScenario = {
    scenarioId: `gid_scen_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    ownerUid: req.principal?.id || '',
    scenarioName: scenarioName || 'Architecture Evolution Simulation',
    startingConditions: [
      'Node.js full-stack Express server with Vite middleware in development',
      'Dual model router active',
      'Zero-trust backend RBAC'
    ],
    proposedChanges: Array.isArray(proposedChanges) ? proposedChanges : ['Simulate migration or infrastructure update'],
    assumptions: Array.isArray(assumptions) ? assumptions : ['Zero downtime required', 'Data consistency preserved'],
    dependencies: ['Express server routes', 'Firestore security rules'],
    expectedBenefits: ['Continuous availability', 'Predictable resource utilization'],
    potentialRisks: ['Transient connection reset during cutover'],
    alternativeOutcomes: ['Instant automated rollback to previous revision'],
    evidenceAndLimitations: ['Simulated based on historical telemetry and system capacity specifications.'],
    recommendedNextAction: 'Submit scenario for System Owner review.',
    status: 'HYPOTHETICAL',
    createdAt: Date.now()
  };

  gideonScenarios.unshift(newScenario);
  saveToDisk();

  return res.status(201).json(newScenario);
}

export function handlePostGideonQuery(req: AuthenticatedRequest, res: Response) {
  const { question, projectId } = req.body;
  if (typeof question !== 'string' || !question.trim() || question.length > 2000) {
    return res.status(400).json({ error: 'A non-empty GIDEON question up to 2,000 characters is required.' });
  }
  const events = getOwnedEvents(req)
    .filter(event => !projectId || matchesProjectId(event.projectId, projectId))
    .sort((a, b) => b.occurredAt - a.occurredAt);
  const recentEvents = events.slice(0, 5);
  const latest = recentEvents[0];
  const answer = recentEvents.length
    ? `The stored timeline has ${events.length} event(s) matching this scope. The latest is "${latest?.title}" at ${latest ? new Date(latest.occurredAt).toLocaleString() : 'an unknown time'}. This summary reports stored records only; it does not verify service health or prove causation.`
    : 'No stored timeline events match this scope, so there is not enough evidence to answer from GIDEON history.';

  return res.json({
    answer,
    confidence: recentEvents.length ? 'MEDIUM' : 'INSUFFICIENT_DATA',
    evidenceEvents: recentEvents.slice(0, 3),
    recommendedNextStep: 'Review chronological events or run a dedicated diagnostics check.'
  });
}
