# LORIN M1–M6 Integrated Working Build Status — 21 November 2026

**Release class:** Enhanced source working build. **Not production-ready; not an installer.**

## Verified in this source snapshot

| Area | Status | Evidence / limits |
|---|---|---|
| Existing LORIN application retained | PASS | Built as a separate copy of the integrated 21 Nov working archive |
| Local-first model routing | PASS (unit/static) | Capability and health-aware decision helper; unknown context/cost remain unknown |
| Local Ollama health probe | IMPLEMENTED | `/api/tags` probe restricted to loopback HTTP endpoint; real daemon not available for live verification |
| Local Ollama streaming | IMPLEMENTED + parser tests | `/api/generate`, bounded NDJSON parser, explicit `done:true` required, abort and failure handling; no physical local Ollama server available here |
| Gemini/Ollama Cloud dispatch | CODE PRESENT / LIVE UNVERIFIED | Existing server adapters retained; API credentials/upstream live checks unavailable in this environment |
| Local-first explicit fallback | IMPLEMENTED | Settings mode maps to explicit prompt-fallback permission; private context has separate consent gate; no image is forwarded; no fallback after partial stream |
| Unified encrypted local knowledge index | PASS (focused tests) | Owner scope, encrypted payloads, blind term index, source provenance, SQLite restart/delete tests |
| Conversation/Memory/Vault/Project/GIDEON indexing | IMPLEMENTED / PARTIAL | Supplemental index from existing stores; source stores remain authoritative; complete migration not performed |
| Cloud sync and unified backup/restore | NOT COMPLETE | Firebase target intentionally unconfigured; sync engine, conflict resolution and end-to-end backup restore remain pending |
| Durable job worker | PASS (focused tests) | Opt-in continuous worker, single-concurrency loop, SQLite leases and interrupted-job fail-closed handling |
| Job authorization | PASS (focused tests) | Current principal, session, permissions, capability policy, action digest and approval rechecked at execution |
| Safe file capabilities | LIMITED IMPLEMENTATION | Bounded workspace read and approved create-new-file with independent SHA-256 verification; no overwrite, shell or arbitrary code execution |
| Task workspace | IMPLEMENTED / RUNTIME UNVERIFIED | UI for durable jobs, worker control, approval, retry and postcondition verification; full browser/API integration not run |
| Voice activity detection | IMPLEMENTED / DEVICE UNVERIFIED | VAD connected to live DSP callback only during an explicit microphone session |
| Foreground “Hey LORIN” | LIMITED | Click-to-arm browser speech recognition; not an offline/native always-on wake-word engine |
| STT/TTS | EXISTING / DEVICE UNVERIFIED | Existing browser recognition, clip transcription and speech synthesis retained; full-duplex, interruption and quality acceptance not run |
| Snapshot vision | EXISTING / DEVICE UNVERIFIED | Existing preview/snapshot workflows retained; not continuous real-time video analysis |
| Device pairing and revocation | EXISTING / DEVICE UNVERIFIED | Authenticated pairing and owner-controlled device actions retained; physical pairing/revocation test not run |
| Local offline Ollama | IMPLEMENTED / DEVICE UNVERIFIED | Local inference restricted to loopback; complete offline app workflow not acceptance-tested |
| Windows helper scripts | IMPLEMENTED / WINDOWS UNVERIFIED | PowerShell preflight/install/start/doctor scripts; they refuse unsupported Node and inconsistent lockfile |
| Windows installer / DPAPI key protection | NOT COMPLETE | No installer executable; DPAPI wrapping and Windows ACL verification still required |
| TypeScript/TSX syntax check | PASS | 120 non-declaration TypeScript/TSX implementation files parsed with zero syntax diagnostics using the environment's global TypeScript 5.8.3; syntax-only, not semantic typecheck |
| Focused core suite | PASS — 24/24 | `npm run test:core` |
| Static security regressions | PASS — 38/38 | `npm run test:security:static` |
| Full semantic typecheck | BLOCKED | Project dependencies unavailable; no installed `node_modules` |
| Full Vitest suite | NOT RUN | No clean dependency install |
| Vite + server production build | BLOCKED | Vite/esbuild executables unavailable; dependency lockfile mismatch |
| Runtime preflight | BLOCKED — 2/6 PASS | Node 22.16.0 available; project requires >=24.12.0; direct dependency lock entries mismatch; no `node_modules`; npm 10.9.2 and built-in SQLite pass |
| Firebase/Gemini/Ollama live integration | NOT RUN | Firebase deliberately unconfigured pending correct project; live API credentials/network unavailable |
| Browser/microphone/camera/physical devices | NOT RUN | Requires real browser, permissioned devices and provider connectivity |
| Production deployment | NOT RUN | No production deployment performed |

## M1–M6 source changes

### M1 — Real AI intelligence integration
- Connected the local-first Settings choice to the main request path as explicit permission for prompt-only cloud fallback.
- Private Vault/Memory context is separately gated and remains withheld unless explicitly permitted.
- Fallback does not forward images and is blocked after partial streamed output, on sensitive/local-only requests, aborts or provider no-fallback errors.
- Local Ollama health checks use `/api/tags` on loopback only; local streaming uses `/api/generate`.
- Added a standalone NDJSON parser; it requires a final `done:true`, caps output, handles split packets and rejects malformed, provider-error and incomplete streams.
- Live Gemini, Ollama Cloud and local daemon requests still require configured services for acceptance.

### M2 — Unified memory and knowledge
- Connected existing conversation turns, confirmed memory summaries, Vault snippets, active project details and GIDEON events to an owner-scoped encrypted local knowledge index.
- Each result retains source domain, source ID, source label and verification status for citation.
- The index is supplemental, not a destructive migration or replacement for existing domain stores.
- Complete Firestore/cloud sync, cross-device conflict resolution, full backup/restore and index rebuild lifecycle remain pending.

### M3 — Complete automation foundation
- Added explicit continuous worker start/stop/status controls and task workspace panel.
- Durable leases prevent uncertain replay after a worker crash; stale jobs are blocked, not blindly re-executed.
- Added owner-scoped list/retry/verify routes; retries are bounded and approval-sensitive jobs require fresh approval.
- Added bounded workspace file read and approved create-new-file capabilities with path/symlink checks, no-overwrite behavior and independent SHA-256 verification.
- Arbitrary shell commands, unrestricted coding execution and general repository test runners remain disabled/pending.

### M4 — Voice and vision
- Integrated VAD activity events into explicit microphone DSP sessions and exposed status in the voice UI.
- Added opt-in foreground “Hey LORIN” arming using browser speech recognition after a user click.
- Fixed an inherited extra closing brace in `VoiceChatView.tsx` that prevented parsing.
- Improved wake phrase matching to whole-word matching.
- Existing STT/TTS, interruption and snapshot vision code remains; full-duplex, offline wake word, real-time video understanding and device acceptance remain pending.

### M5 — Devices and offline intelligence
- Preserved authenticated pairing, owner-controlled device actions/revocation, local companion runtime and local Ollama transport.
- Local Ollama browser transport is loopback-only.
- Physical device pairing, revocation, browser-to-companion integration and disconnected-mode acceptance remain not run.

### M6 — Windows desktop companion
- Added/updated PowerShell install, start and doctor scripts with explicit Node/npm requirements, build preflight, exact `npm ci`, test/typecheck/build steps and loopback binding.
- Optional Tailscale Serve and logon task require explicit command-line switches.
- No elevation or silent system-service registration.
- A signed installer, DPAPI-protected key material, Windows ACL hardening and physical Windows acceptance have not been delivered.

## Required next blockers

1. Run in Node.js >=24.12.0 with npm 10.9.2.
2. Reconcile and regenerate `package-lock.json` from the approved `package.json` in a connected, trusted environment; review dependency changes, do not blindly upgrade.
3. `npm ci`, semantic typecheck, full Vitest, production build and server boot.
4. Configure the intended Firebase project (the previous inherited project target has been neutralized).
5. Perform live Gemini, Ollama Cloud and local Ollama integration tests; configure provider health and routing acceptance.
6. Finish backup/restore and authenticated cloud sync across Memory, Vault, conversations, projects and GIDEON.
7. Expand safe executors and independent verifiers; test continuous worker lifecycle under process restart and database contention.
8. Perform microphone, STT/TTS, wake phrase, interruption and camera/snapshot acceptance on supported hardware.
9. Test paired-device lifecycle, revoke/expiry, offline operation and local companion bridge.
10. Implement and test Windows DPAPI key protection, restrictive ACLs, installer/uninstaller, backup recovery and release signing.
11. Run full production security, load, recovery and deployment acceptance before marking production-ready.
