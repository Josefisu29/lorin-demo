import { randomUUID } from 'node:crypto';
import type { CapabilityContext, CapabilityRegistry } from '../capabilities/registry.ts';
import { validateCapabilityInput } from '../capabilities/registry.ts';
import { actionDigest, canonicalJson } from '../security/canonical.ts';
import { evaluateCapabilityPolicy, type PolicyContext, type PolicyPrincipal } from '../security/policy.ts';
import { LorinSqliteStore, type DurableApproval, type DurableJob } from '../persistence/sqliteStore.ts';

export interface JobPrincipal extends PolicyPrincipal {
  email?: string;
}

function canonicalResultJson(value: unknown): string {
  return canonicalJson(value);
}

export interface JobCreateRequest {
  capabilityId: string;
  resource: string;
  parameters: unknown;
  approvalId?: string;
}

export class JobService {
  constructor(
    private readonly store: LorinSqliteStore,
    private readonly capabilities: CapabilityRegistry
  ) {}

  create(principal: JobPrincipal, request: JobCreateRequest, policyContext: PolicyContext): {
    job: DurableJob;
    approval?: DurableApproval;
    policy: ReturnType<typeof evaluateCapabilityPolicy>;
  } {
    if (!request || typeof request.resource !== 'string' || !request.resource.trim() || request.resource.length > 300) {
      throw new Error('JOB_RESOURCE_INVALID');
    }
    const capability = this.capabilities.get(request.capabilityId);
    if (!capability) throw new Error('CAPABILITY_NOT_FOUND');
    const validation = validateCapabilityInput(request.parameters, capability.inputSchema);
    if (validation.length) {
      const error = new Error('CAPABILITY_INPUT_INVALID');
      Object.assign(error, { issues: validation });
      throw error;
    }

    const policy = evaluateCapabilityPolicy(principal, capability, policyContext);
    if (!policy.allowed) {
      this.store.recordAudit({
        ownerUid: principal.id, actorUid: principal.id, action: 'capability.denied', resource: request.resource,
        decision: 'DENY', reason: policy.reasons.join(' '),
        metadata: { capabilityId: capability.id, policy }
      });
      throw new Error(`POLICY_DENIED:${policy.reasons.join(' ')}`);
    }

    const digest = actionDigest({
      principalId: principal.id,
      capabilityId: capability.id,
      resource: request.resource,
      parameters: request.parameters
    });

    if (policy.requiresApproval) {
      const created = this.store.createJobWithApproval({
        ownerUid: principal.id,
        capabilityId: capability.id,
        capabilityVersion: capability.version,
        resource: request.resource,
        parameters: request.parameters,
        actionDigest: digest
      });
      return { job: created.job, approval: created.approval, policy };
    }

    const job = this.store.createJob({
      ownerUid: principal.id,
      capabilityId: capability.id,
      capabilityVersion: capability.version,
      resource: request.resource,
      parameters: request.parameters,
      actionDigest: digest,
      state: capability.execute ? 'QUEUED' : 'BLOCKED'
    });
    return { job, policy };

  }

  approve(jobId: string, approvalId: string, approver: JobPrincipal): DurableJob {
    if (!['SYSTEM_OWNER', 'SUPER_ADMIN'].includes(approver.canonicalRole)) throw new Error('APPROVER_ROLE_REQUIRED');
    const job = this.store.getJob(jobId);
    if (!job) throw new Error('JOB_NOT_FOUND');
    if (job.state !== 'AWAITING_APPROVAL') throw new Error('JOB_NOT_AWAITING_APPROVAL');
    if (approver.id === job.ownerUid) throw new Error('INDEPENDENT_APPROVER_REQUIRED');
    const approval = this.store.getApproval(approvalId, job.ownerUid);
    if (!approval || approval.status !== 'PENDING') throw new Error('APPROVAL_NOT_PENDING');
    if (approval.capabilityId !== job.capabilityId || approval.resource !== job.resource || approval.actionDigest !== job.actionDigest) {
      throw new Error('APPROVAL_BINDING_MISMATCH');
    }
    const expectedDigest = actionDigest({
      principalId: job.ownerUid,
      capabilityId: job.capabilityId,
      resource: job.resource,
      parameters: job.parameters
    });
    if (approval.actionDigest !== expectedDigest) throw new Error('APPROVAL_PARAMETER_DIGEST_MISMATCH');
    return this.store.approveJobWithApproval(jobId, approvalId, approver.id);
  }

  async runOne(workerId: string, source: CapabilityContext['source'] = 'LOCAL_NODE'): Promise<DurableJob | undefined> {
    const job = this.store.claimNextJob(workerId);
    if (!job) return undefined;
    const expectedDigest = actionDigest({
      principalId: job.ownerUid,
      capabilityId: job.capabilityId,
      resource: job.resource,
      parameters: job.parameters
    });
    if (!job.actionDigest || expectedDigest !== job.actionDigest) {
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'BLOCKED', actorUid: workerId,
        errorCode: 'ACTION_DIGEST_MISMATCH', reason: 'Encrypted job payload no longer matches its original action digest.'
      });
    }
    const capability = this.capabilities.get(job.capabilityId);
    if (!capability || !capability.enabled || !capability.execute || capability.version !== job.capabilityVersion) {
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'BLOCKED', actorUid: workerId,
        errorCode: 'CAPABILITY_UNAVAILABLE', reason: 'The pinned capability version or trusted executor is unavailable.'
      });
    }

    const startedAt = Date.now();
    try {
      const result = await this.capabilities.invoke(job.capabilityId, job.parameters, {
        principalId: job.ownerUid,
        requestId: randomUUID(),
        source,
        locale: 'en'
      });
      const finishedAt = Date.now();
      const receiptResultJson = canonicalResultJson(result);
      if (Buffer.byteLength(receiptResultJson, 'utf8') > 256 * 1024) throw new Error('CAPABILITY_RECEIPT_TOO_LARGE');
      const receipt = {
        receiptVersion: 1,
        jobId: job.id,
        capabilityId: capability.id,
        capabilityVersion: capability.version,
        workerId,
        startedAt,
        finishedAt,
        durationMs: finishedAt - startedAt,
        result
      };
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'COMPLETED', actorUid: workerId,
        receipt, reason: 'Registered server-side capability returned successfully; completion recorded, not independently verified.'
      });
    } catch (error: any) {
      const candidate = typeof error?.message === 'string' ? error.message : '';
      const code = /^[A-Z0-9_:-]{1,80}$/.test(candidate) ? candidate : 'CAPABILITY_EXECUTION_FAILED';
      return this.store.transitionJob({
        jobId: job.id, workerId, nextState: 'FAILED', actorUid: workerId,
        errorCode: code, reason: 'Registered capability failed; no success claim was recorded.'
      });
    }
  }

  cancel(jobId: string, principal: JobPrincipal): DurableJob {
    return this.store.cancelJob(jobId, principal.id);
  }
}

export function createBuiltinCapabilities(registry: CapabilityRegistry): CapabilityRegistry {
  registry.register({
    id: 'lorin.system.health.read',
    version: 1,
    title: 'Read local runtime health',
    description: 'Returns real, non-sensitive runtime process measurements from the local worker.',
    category: 'SYSTEM',
    risk: 'READ',
    requiredPermissions: ['providers.read'],
    inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    timeoutMs: 2_000,
    localOnly: true,
    enabled: true,
    execute: (_input, context) => {
      if (context.signal.aborted) throw new Error('CAPABILITY_CANCELLED');
      const memory = process.memoryUsage();
      return {
        capturedAt: new Date().toISOString(),
        runtime: process.release.name,
        nodeVersion: process.version,
        platform: process.platform,
        architecture: process.arch,
        uptimeSeconds: Math.floor(process.uptime()),
        memory: { rssBytes: memory.rss, heapUsedBytes: memory.heapUsed, heapTotalBytes: memory.heapTotal }
      };
    }
  });
  registry.register({
    id: 'lorin.time.read',
    version: 1,
    title: 'Read current local-node time',
    description: 'Returns the local host clock timestamp and timezone offset.',
    category: 'SYSTEM',
    risk: 'READ',
    requiredPermissions: ['providers.read'],
    inputSchema: { type: 'object', properties: {}, required: [], additionalProperties: false },
    timeoutMs: 1_000,
    localOnly: true,
    enabled: true,
    execute: (_input, context) => {
      if (context.signal.aborted) throw new Error('CAPABILITY_CANCELLED');
      const now = new Date();
      return { iso: now.toISOString(), local: now.toString(), offsetMinutes: -now.getTimezoneOffset() };
    }
  });
  registry.seal();
  return registry;
}
