export type PrivacyMode = 'LOCAL_ONLY' | 'LOCAL_PREFERRED' | 'BALANCED' | 'CLOUD_ALLOWED';
export type QueryKind = 'CHAT' | 'RESEARCH' | 'CODE' | 'VISION' | 'AUDIO' | 'LONG_CONTEXT' | 'SENSITIVE';
export type ProviderKind = 'OLLAMA_LOCAL' | 'GEMINI_CLOUD' | 'OTHER_CLOUD';

export interface ProviderCandidate {
  id: string;
  kind: ProviderKind;
  modelId: string;
  healthy: boolean;
  enabled: boolean;
  contextWindow: number;
  capabilities: readonly QueryKind[];
  estimatedLatencyMs?: number;
  estimatedCostUsdPer1kTokens?: number;
  supportsStreaming: boolean;
  supportsTools: boolean;
  lastVerifiedAt?: number;
}

export interface RouteRequest {
  kind: QueryKind;
  privacyMode: PrivacyMode;
  estimatedInputTokens: number;
  estimatedOutputTokens: number;
  requireStreaming?: boolean;
  requireTools?: boolean;
  allowCloudFallback?: boolean;
  minimumHealthAgeMs?: number;
}

export interface RouteDecision {
  selected?: ProviderCandidate;
  candidatesConsidered: string[];
  rejected: Array<{ providerId: string; reason: string }>;
  reason: string;
  fallbackAllowed: boolean;
  requiresUserNotice: boolean;
}

/** Deterministic, explainable routing. It never executes a provider request. */
export function routeModelRequest(request: RouteRequest, providers: readonly ProviderCandidate[], now = Date.now()): RouteDecision {
  const rejected: RouteDecision['rejected'] = [];
  const considered: string[] = [];
  const requestedTokens = Math.max(0, request.estimatedInputTokens) + Math.max(0, request.estimatedOutputTokens);
  const maxHealthAge = request.minimumHealthAgeMs ?? 5 * 60_000;

  for (const provider of providers) {
    considered.push(provider.id);
    let reason = '';
    if (!provider.enabled) reason = 'Provider is disabled by configuration.';
    else if (!provider.healthy) reason = 'Provider has no current successful health probe.';
    else if (!Number.isFinite(provider.lastVerifiedAt)) reason = 'Provider health has not been timestamp-verified.';
    else if (now - (provider.lastVerifiedAt as number) > maxHealthAge) reason = 'Provider health evidence is stale.';
    else if ((provider.lastVerifiedAt as number) - now > 60_000) reason = 'Provider health timestamp is implausibly far in the future.';
    else if (!provider.capabilities.includes(request.kind)) reason = `Provider does not declare ${request.kind} capability.`;
    else if (provider.contextWindow < requestedTokens) reason = 'Requested context estimate exceeds the provider context window.';
    else if (request.requireStreaming && !provider.supportsStreaming) reason = 'Streaming is required but unavailable.';
    else if (request.requireTools && !provider.supportsTools) reason = 'Tool calling is required but unavailable.';
    else if (request.privacyMode === 'LOCAL_ONLY' && provider.kind !== 'OLLAMA_LOCAL') reason = 'Privacy policy forbids cloud inference for this request.';
    else if (request.privacyMode === 'LOCAL_PREFERRED' && provider.kind !== 'OLLAMA_LOCAL' && !request.allowCloudFallback) reason = 'Cloud fallback has not been explicitly permitted.';
    if (reason) rejected.push({ providerId: provider.id, reason });
  }

  const eligible = providers.filter(provider => !rejected.some(item => item.providerId === provider.id));
  const rank = (provider: ProviderCandidate): number => {
    const localPreference = request.privacyMode === 'LOCAL_ONLY' || request.privacyMode === 'LOCAL_PREFERRED' ? (provider.kind === 'OLLAMA_LOCAL' ? 0 : 1) : 0;
    const latency = provider.estimatedLatencyMs ?? 60_000;
    const cost = provider.estimatedCostUsdPer1kTokens ?? (provider.kind === 'OLLAMA_LOCAL' ? 0 : 1);
    const contextSlack = Math.max(0, provider.contextWindow - requestedTokens) / Math.max(1, provider.contextWindow);
    return localPreference * 1_000_000 + latency * 2 + cost * 80_000 - contextSlack * 100;
  };
  eligible.sort((a, b) => rank(a) - rank(b));

  if (!eligible.length) {
    return {
      selected: undefined, candidatesConsidered: considered, rejected,
      reason: request.privacyMode === 'LOCAL_ONLY'
        ? 'No eligible local provider is available. The request was not sent to a cloud provider.'
        : 'No provider currently satisfies the request requirements. No synthetic response will be substituted.',
      fallbackAllowed: false, requiresUserNotice: true
    };
  }

  const selected = eligible[0];
  return {
    selected,
    candidatesConsidered: considered,
    rejected,
    reason: `Selected ${selected.id} using declared capability, health, context, privacy, latency and cost constraints.`,
    fallbackAllowed: request.privacyMode !== 'LOCAL_ONLY' && request.allowCloudFallback === true,
    requiresUserNotice: selected.kind !== 'OLLAMA_LOCAL'
  };
}

export function classifyQueryKind(input: { text?: string; hasImage?: boolean; hasAudio?: boolean; sensitive?: boolean }): QueryKind {
  if (input.sensitive) return 'SENSITIVE';
  if (input.hasImage) return 'VISION';
  if (input.hasAudio) return 'AUDIO';
  const text = input.text || '';
  if (/```|\b(function|class|import|typescript|javascript|python|rust|compile|debug|refactor)\b/i.test(text)) return 'CODE';
  if (/\b(research|sources|citations|compare|investigate|latest|evidence)\b/i.test(text)) return 'RESEARCH';
  if (text.length > 12_000) return 'LONG_CONTEXT';
  return 'CHAT';
}
