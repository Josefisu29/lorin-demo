export type CapabilityRisk = 'READ' | 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
export type JsonSchemaType = 'object' | 'string' | 'number' | 'integer' | 'boolean' | 'array';

export interface JsonSchema {
  type: JsonSchemaType;
  description?: string;
  properties?: Record<string, JsonSchema>;
  required?: string[];
  additionalProperties?: boolean;
  items?: JsonSchema;
  enum?: Array<string | number | boolean | null>;
  minLength?: number;
  maxLength?: number;
  minimum?: number;
  maximum?: number;
  minItems?: number;
  maxItems?: number;
}

export interface CapabilityContext {
  principalId: string;
  requestId: string;
  locale?: string;
  source: 'WEB' | 'LOCAL_NODE' | 'SCHEDULED';
  signal: AbortSignal;
}

export interface CapabilityDefinition<TInput = Record<string, unknown>, TResult = unknown> {
  id: string;
  version: number;
  title: string;
  description: string;
  category: 'SYSTEM' | 'MEMORY' | 'PROJECT' | 'FILE' | 'NETWORK' | 'DEVICE' | 'COMMUNICATION';
  risk: CapabilityRisk;
  requiredPermissions: readonly string[];
  inputSchema: JsonSchema;
  timeoutMs: number;
  localOnly?: boolean;
  requiresApproval?: boolean;
  enabled: boolean;
  execute?: (input: TInput, context: CapabilityContext) => Promise<TResult> | TResult;
}

export interface ValidationIssue {
  path: string;
  message: string;
}


function deepFreeze<T>(value: T): T {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const child of Object.values(value as Record<string, unknown>)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function validateBySchema(value: unknown, schema: JsonSchema, path: string, issues: ValidationIssue[]): void {
  const fail = (message: string) => issues.push({ path, message });

  switch (schema.type) {
    case 'object': {
      if (!isPlainObject(value)) return fail('must be a plain object');
      const properties = schema.properties || {};
      for (const required of schema.required || []) {
        if (!Object.hasOwn(value, required)) issues.push({ path: `${path}.${required}`, message: 'is required' });
      }
      if (schema.additionalProperties !== true) {
        for (const key of Object.keys(value)) {
          if (!Object.hasOwn(properties, key)) issues.push({ path: `${path}.${key}`, message: 'is not an allowed property' });
        }
      }
      for (const [key, child] of Object.entries(properties)) {
        if (Object.hasOwn(value, key)) validateBySchema(value[key], child, `${path}.${key}`, issues);
      }
      break;
    }
    case 'string':
      if (typeof value !== 'string') return fail('must be a string');
      if (schema.minLength !== undefined && value.length < schema.minLength) fail(`must contain at least ${schema.minLength} characters`);
      if (schema.maxLength !== undefined && value.length > schema.maxLength) fail(`must contain at most ${schema.maxLength} characters`);
      if (schema.enum && !schema.enum.includes(value)) fail('must be one of the allowed values');
      break;
    case 'number':
    case 'integer':
      if (typeof value !== 'number' || !Number.isFinite(value)) return fail('must be a finite number');
      if (schema.type === 'integer' && !Number.isInteger(value)) fail('must be an integer');
      if (schema.minimum !== undefined && value < schema.minimum) fail(`must be at least ${schema.minimum}`);
      if (schema.maximum !== undefined && value > schema.maximum) fail(`must be at most ${schema.maximum}`);
      if (schema.enum && !schema.enum.includes(value)) fail('must be one of the allowed values');
      break;
    case 'boolean':
      if (typeof value !== 'boolean') return fail('must be a boolean');
      break;
    case 'array':
      if (!Array.isArray(value)) return fail('must be an array');
      if (schema.minItems !== undefined && value.length < schema.minItems) fail(`must contain at least ${schema.minItems} items`);
      if (schema.maxItems !== undefined && value.length > schema.maxItems) fail(`must contain at most ${schema.maxItems} items`);
      if (schema.items) value.forEach((item, index) => validateBySchema(item, schema.items!, `${path}[${index}]`, issues));
      break;
  }
}

const MAX_INPUT_BYTES = 64 * 1024;
const MAX_INPUT_DEPTH = 24;
const MAX_INPUT_NODES = 5_000;

function validateJsonEnvelope(input: unknown): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const seen = new WeakSet<object>();
  let nodes = 0;
  const walk = (value: unknown, path: string, depth: number): void => {
    nodes += 1;
    if (nodes > MAX_INPUT_NODES) { issues.push({ path, message: 'exceeds the maximum JSON node count' }); return; }
    if (depth > MAX_INPUT_DEPTH) { issues.push({ path, message: 'exceeds the maximum JSON nesting depth' }); return; }
    if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
    if (typeof value === 'number') {
      if (!Number.isFinite(value)) issues.push({ path, message: 'must be a finite JSON number' });
      return;
    }
    if (typeof value !== 'object') { issues.push({ path, message: 'must contain JSON-compatible values only' }); return; }
    if (seen.has(value as object)) { issues.push({ path, message: 'must not contain circular references' }); return; }
    seen.add(value as object);
    if (Array.isArray(value)) {
      if (value.length > 1_000) issues.push({ path, message: 'exceeds the maximum array length' });
      value.slice(0, 1_000).forEach((item, index) => walk(item, `${path}[${index}]`, depth + 1));
    } else {
      const prototype = Object.getPrototypeOf(value);
      if (prototype !== Object.prototype && prototype !== null) {
        issues.push({ path, message: 'must be a plain JSON object' });
      } else {
        const entries = Object.entries(value as Record<string, unknown>);
        if (entries.length > 256) issues.push({ path, message: 'exceeds the maximum object property count' });
        for (const [key, child] of entries.slice(0, 256)) {
          if (key === '__proto__' || key === 'prototype' || key === 'constructor') {
            issues.push({ path: `${path}.${key}`, message: 'uses a prohibited property name' });
          }
          walk(child, `${path}.${key}`, depth + 1);
        }
      }
    }
    seen.delete(value as object);
  };
  walk(input, '$', 0);
  if (!issues.length) {
    try {
      if (Buffer.byteLength(JSON.stringify(input), 'utf8') > MAX_INPUT_BYTES) {
        issues.push({ path: '$', message: `exceeds the ${MAX_INPUT_BYTES}-byte input limit` });
      }
    } catch {
      issues.push({ path: '$', message: 'must be serializable JSON' });
    }
  }
  return issues;
}

function validateSchemaDefinition(schema: JsonSchema, path = '$schema', depth = 0): void {
  if (!schema || typeof schema !== 'object' || depth > MAX_INPUT_DEPTH) throw new TypeError(`Invalid capability schema at ${path}`);
  if (schema.type === 'object') {
    if (schema.additionalProperties !== false) throw new TypeError(`Object schemas must set additionalProperties=false at ${path}`);
    const properties = schema.properties || {};
    for (const key of Object.keys(properties)) {
      if (key === '__proto__' || key === 'prototype' || key === 'constructor') throw new TypeError(`Prohibited schema property at ${path}.${key}`);
      validateSchemaDefinition(properties[key], `${path}.${key}`, depth + 1);
    }
    for (const key of schema.required || []) {
      if (!Object.hasOwn(properties, key)) throw new TypeError(`Required property has no schema at ${path}.${key}`);
    }
  }
  if (schema.type === 'array' && schema.items) validateSchemaDefinition(schema.items, `${path}[]`, depth + 1);
}

export function validateCapabilityInput(input: unknown, schema: JsonSchema): ValidationIssue[] {
  const issues = validateJsonEnvelope(input);
  if (!issues.length) validateBySchema(input, schema, '$', issues);
  return issues;
}

/** Server-owned allowlist. Models and browser clients cannot register executors. */
export class CapabilityRegistry {
  private readonly definitions = new Map<string, CapabilityDefinition>();
  private frozen = false;

  register<TInput, TResult>(definition: CapabilityDefinition<TInput, TResult>): void {
    if (this.frozen) throw new Error('Capability registry is sealed');
    if (!/^[a-z][a-z0-9]*(?:[.-][a-z0-9]+)*$/.test(definition.id)) {
      throw new TypeError(`Invalid capability ID: ${definition.id}`);
    }
    if (this.definitions.has(definition.id)) throw new Error(`Capability already registered: ${definition.id}`);
    if (!Number.isInteger(definition.version) || definition.version < 1) throw new TypeError('Capability version must be a positive integer');
    if (!Number.isInteger(definition.timeoutMs) || definition.timeoutMs < 100 || definition.timeoutMs > 120_000) {
      throw new RangeError('Capability timeout must be between 100ms and 120000ms');
    }
    if (definition.inputSchema.type !== 'object') {
      throw new TypeError('Capability input schema must be a closed object schema.');
    }
    validateSchemaDefinition(definition.inputSchema);
    const schemaSnapshot = deepFreeze(structuredClone(definition.inputSchema));
    const permissionSnapshot = Object.freeze([...definition.requiredPermissions]);
    this.definitions.set(definition.id, deepFreeze({
      ...definition,
      requiredPermissions: permissionSnapshot,
      inputSchema: schemaSnapshot
    }));
  }

  seal(): void { this.frozen = true; }

  get(id: string): CapabilityDefinition | undefined { return this.definitions.get(id); }

  list(): Array<Omit<CapabilityDefinition, 'execute'>> {
    return Array.from(this.definitions.values()).map(({ execute: _execute, ...publicDefinition }) => publicDefinition);
  }

  async invoke(id: string, input: unknown, context: Omit<CapabilityContext, 'signal'>): Promise<unknown> {
    const definition = this.definitions.get(id);
    if (!definition || !definition.enabled) throw new Error('CAPABILITY_UNAVAILABLE');
    const issues = validateCapabilityInput(input, definition.inputSchema);
    if (issues.length) {
      const error = new Error('CAPABILITY_INPUT_INVALID');
      Object.assign(error, { issues });
      throw error;
    }
    if (!definition.execute) throw new Error('CAPABILITY_EXECUTOR_NOT_INSTALLED');

    const controller = new AbortController();
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      const executionContext = { ...context, signal: controller.signal };
      return await Promise.race([
        Promise.resolve(definition.execute(input as never, executionContext)),
        new Promise<never>((_, reject) => {
          timeout = setTimeout(() => {
            controller.abort(new Error('CAPABILITY_EXECUTION_TIMEOUT'));
            reject(new Error('CAPABILITY_EXECUTION_TIMEOUT'));
          }, definition.timeoutMs);
          timeout.unref?.();
        })
      ]);
    } finally {
      if (timeout) clearTimeout(timeout);
    }
  }
}
