import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, Play, RefreshCw, Cpu, Activity, Shield, Database } from 'lucide-react';
import { Principal } from '../types/lorin';
import { PolicyEngine } from '../services/policyEngine';
import { MemoryStore } from '../services/memoryStore';
import { VerificationRunner } from '../services/verificationRunner';
import { testFirestoreConnection } from '../services/firebase';
import { VaultStore } from '../services/vaultStore';
import { RoutingStrategy } from '../services/modelBackend';
import { getAuthHeaders } from '../services/authHeaders';

interface TerminalWorkbenchProps {
  principal: Principal;
  backendMode: RoutingStrategy;
  onNavigateToTab: (tab: any) => void;
  pendingApprovalsCount: number;
}

interface LogLine {
  id: string;
  type: 'cmd' | 'output' | 'error' | 'success' | 'system';
  text: string;
  timestamp: string;
}

export const TerminalWorkbench: React.FC<TerminalWorkbenchProps> = ({
  principal,
  backendMode,
  onNavigateToTab,
  pendingApprovalsCount,
}) => {
  const [inputCmd, setInputCmd] = useState('');
  const [logs, setLogs] = useState<LogLine[]>([
    {
      id: '1',
      type: 'system',
      text: 'LORIN Unified Master Intelligence & Engineering System [Version 1.1]',
      timestamp: new Date().toLocaleTimeString()
    },
    {
      id: '2',
      type: 'system',
      text: 'Type "help" to display available CLI commands, or "test" to run Phase 1-4 test suite.',
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [isRunning, setIsRunning] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = (type: LogLine['type'], text: string) => {
    setLogs(prev => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        type,
        text,
        timestamp: new Date().toLocaleTimeString()
      }
    ]);
  };

  const handleCommand = async (cmdStr: string) => {
    const trimmed = cmdStr.trim();
    if (!trimmed) return;

    addLog('cmd', `lorin@system:~$ ${trimmed}`);
    setInputCmd('');
    setIsRunning(true);

    const parts = trimmed.split(' ');
    const main = parts[0].toLowerCase();

    try {
      if (main === 'help') {
        addLog('output', `Available Commands:
  help                           - Show this help manual
  status                         - Display system status and telemetry
  test                           - Run Phase 1-4 automated verification suite
  db ping                        - Ping live Firebase Firestore database
  gemini ping                    - Test live Server-Side Gemini API proxy
  vault stats                    - Display Offline Knowledge Vault statistics
  vault search <query>           - Run BM25 lexical search on Knowledge Vault
  infer <prompt>                 - Trigger live multi-specialist synthesis
  policy check <action> <target> - Evaluate policy decision for an action
  memory list                    - Print persistent memory counts across domains
  audit list                     - Display recent audit stream events
  clear                          - Clear terminal display buffer`);
      } else if (main === 'status') {
        const memCount = MemoryStore.getAllRecords().length;
        const auditCount = PolicyEngine.getAuditEvents().length;
        const vaultCount = VaultStore.getDocuments().length;
        addLog('output', `System Telemetry Status:
  Runtime:       LORIN Unified System Active
  Principal:     ${principal.name} (${principal.role}) [ID: ${principal.id}]
  Backend Mode:  ${backendMode}
  Database:      Firebase Firestore (ai-studio-lorinunifiedmast-f3e946a9-6d06-4c74-9692-7ea833dba84f)
  Approvals:     ${pendingApprovalsCount} pending
  Knowledge Docs:${vaultCount} indexed documents
  Memory Records:${memCount} across 5 domains
  Audit Stream:  ${auditCount} recorded events
  Guardians:     Lena, Owen, Riley, Iris, Nolan operational`);
      } else if (main === 'db') {
        addLog('system', 'Pinging Firebase Firestore database...');
        const t0 = performance.now();
        const res = await testFirestoreConnection();
        const latency = Math.round(performance.now() - t0);
        if (res.connected) {
          addLog('success', `[DB PING SUCCESS] Firestore connected (${latency}ms). Master Gate & ABAC rules active.`);
        } else {
          addLog('error', `[DB PING ERROR] ${res.error || 'Connection failed'}`);
        }
      } else if (main === 'gemini') {
        addLog('system', 'Pinging Live Gemini Server Proxy (/api/health)...');
        const t0 = performance.now();
        const res = await fetch('/api/health');
        const latency = Math.round(performance.now() - t0);
        if (res.ok) {
          const data = await res.json();
          addLog(data.providerConnectivityVerified && data.liveGeminiAvailable ? 'success' : 'system', `[API SERVER RESPONDED] Gemini configured: ${Boolean(data.geminiConfigured)}; upstream verified: ${Boolean(data.providerConnectivityVerified && data.liveGeminiAvailable)} (${latency}ms).`);
        } else {
          addLog('error', `[PROXY ERROR] HTTP status ${res.status}`);
        }
      } else if (main === 'vault') {
        const sub = parts[1]?.toLowerCase();
        if (sub === 'search') {
          const q = parts.slice(2).join(' ');
          const hits = VaultStore.search(q);
          if (!hits.length) {
            addLog('output', `No vault records found matching "${q}".`);
          } else {
            addLog('output', `Vault hits for "${q}" (${hits.length} matches):\n` +
              hits.map(h => `  - [Score ${h.score.toFixed(1)}] ${h.document.title}: "${h.snippet.slice(0, 100)}..."`).join('\n')
            );
          }
        } else {
          const docs = VaultStore.getDocuments();
          const bytes = VaultStore.getTotalBytes();
          const collections = VaultStore.getCollections();
          addLog('output', `Offline Knowledge Vault:
  Total Documents: ${docs.length}
  Total Size:      ${(bytes / 1024).toFixed(1)} KB
  Collections:     ${collections.join(', ')}
  Lexical Engine:  BM25 with dynamic snippet scoring & delimiter encapsulation`);
        }
      } else if (main === 'infer') {
        const promptText = parts.slice(1).join(' ');
        if (!promptText) {
          addLog('error', 'Usage: infer <prompt text>');
        } else {
          addLog('system', `Dispatching live inference prompt: "${promptText}"...`);
          const t0 = performance.now();
          const res = await fetch('/api/gemini/infer', {
            method: 'POST',
            headers: await getAuthHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ prompt: promptText })
          });
          const latency = Math.round(performance.now() - t0);
          if (res.ok) {
            const data = await res.json();
            addLog('success', `[INFERENCE COMPLETE (${latency}ms)]:\n${data.rawSynthesis || JSON.stringify(data, null, 2)}`);
          } else {
            addLog('error', `Inference request failed with HTTP status ${res.status}`);
          }
        }
      } else if (main === 'test') {
        addLog('system', 'Executing Phase 1-4 Automated Test Suite (15 assertions)...');
        const results = await VerificationRunner.runAllTests();
        const passed = results.filter(r => r.status === 'PASSED').length;
        results.forEach(r => {
          if (r.status === 'PASSED') {
            addLog('success', `[PASS] ${r.name} (${r.durationMs}ms)`);
          } else {
            addLog('error', `[FAIL] ${r.name}: ${r.details}`);
          }
        });
        addLog('output', `Result: ${passed}/${results.length} tests passed.`);
      } else if (main === 'policy') {
        const action = parts[2] || 'deploy_production';
        const target = parts[3] || 'services://production';
        const res = await PolicyEngine.evaluateAction(principal, {
          id: `cli_${Date.now()}`,
          action,
          resource: target,
          description: 'CLI Policy Check',
          riskLevel: 'HIGH',
          requiredScope: 'admin'
        });
        addLog('output', `Policy Evaluation for '${action}' on '${target}':
  Decision: ${res.decision}
  Reason:   ${res.reason}
  Digest:   ${res.digest}`);
      } else if (main === 'memory') {
        const records = MemoryStore.getAllRecords();
        addLog('output', `Persistent Memory Registry (${records.length} records):
${records.map(r => `  - [${r.domain}] ${r.title} (${r.status}) [key: ${r.key}]`).join('\n')}`);
      } else if (main === 'audit') {
        const events = PolicyEngine.getAuditEvents().slice(0, 5);
        addLog('output', `Recent Audit Events (${events.length}):
${events.map(e => `  - [${new Date(e.timestamp).toLocaleTimeString()}] ${e.decision}: ${e.action} (${e.role}) -> ${e.reason}`).join('\n')}`);
      } else if (main === 'clear') {
        setLogs([]);
      } else {
        addLog('error', `lorin: command not found: "${main}". Type "help" for available commands.`);
      }
    } catch (e: any) {
      addLog('error', `Execution error: ${e.message}`);
    } finally {
      setIsRunning(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleCommand(inputCmd);
    }
  };

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#090d16] overflow-hidden">
      {/* Telemetry Strip */}
      <div className="px-6 py-3 border-b border-slate-800 bg-[#0e1626] flex items-center justify-between flex-wrap gap-4 text-xs font-mono">
        <div className="flex items-center gap-6 text-slate-400">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-sky-400" />
            <span>Model: <strong className="text-white">{backendMode}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-indigo-400" />
            <span>Principal: <strong className="text-white">{principal.role}</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-400" />
            <span>Memory: <strong className="text-white">{MemoryStore.getAllRecords().length} records</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" />
            <span>Pending Approvals: <strong className="text-white">{pendingApprovalsCount}</strong></span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleCommand('test')}
            disabled={isRunning}
            className="px-2.5 py-1 rounded bg-sky-500/10 border border-sky-500/30 text-sky-300 hover:bg-sky-500/20 text-[11px] transition-colors"
          >
            Run Tests
          </button>
          <button
            onClick={() => handleCommand('status')}
            disabled={isRunning}
            className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800 text-[11px] transition-colors"
          >
            Status
          </button>
        </div>
      </div>

      {/* Terminal Output Area */}
      <div className="flex-1 p-6 overflow-y-auto font-mono text-xs space-y-2 select-text">
        {logs.map((log) => (
          <div
            key={log.id}
            className={`leading-relaxed whitespace-pre-wrap ${
              log.type === 'cmd' ? 'text-sky-400 font-semibold' :
              log.type === 'error' ? 'text-rose-400' :
              log.type === 'success' ? 'text-emerald-400' :
              log.type === 'system' ? 'text-indigo-300 font-medium' :
              'text-slate-300'
            }`}
          >
            {log.text}
          </div>
        ))}
        {isRunning && (
          <div className="flex items-center gap-2 text-sky-400">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Executing...</span>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Command Input Prompt */}
      <div className="p-4 border-t border-slate-800 bg-[#0e1626] flex items-center gap-3">
        <span className="text-sky-400 font-mono text-xs font-bold whitespace-nowrap">
          lorin@{principal.role.toLowerCase()}:~$
        </span>
        <input
          type="text"
          value={inputCmd}
          onChange={(e) => setInputCmd(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isRunning}
          placeholder="Type 'help', 'status', 'test', 'policy check <action> <target>', or 'memory list'..."
          className="flex-1 bg-transparent border-0 text-slate-100 font-mono text-xs focus:ring-0 focus:outline-none placeholder-slate-600"
          autoFocus
        />
        <button
          onClick={() => handleCommand(inputCmd)}
          disabled={!inputCmd.trim() || isRunning}
          className="px-3 py-1 rounded bg-sky-500 hover:bg-sky-400 disabled:opacity-40 text-slate-950 font-bold text-xs font-mono transition-colors"
        >
          Send
        </button>
      </div>
    </div>
  );
};
