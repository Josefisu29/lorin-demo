import React, { useState, useEffect } from 'react';
import {
  FolderGit2,
  Lock,
  ShieldCheck,
  Sliders,
  ArrowLeft,
  Wifi,
  WifiOff,
  Gauge,
  Volume2,
  Key,
  Users,
  Grid,
  Database,
  Plus,
  RefreshCw,
  Ban,
  CheckCircle2,
  AlertTriangle,
  LogOut,
  Cpu,
  HardDrive
} from 'lucide-react';
import {
  AccountStatus,
  BackupSnapshotRecord,
  CanonicalRole,
  getRoleHierarchyLevel,
  isSuperAdminOrOwnerPrincipal,
  isSystemOwnerPrincipal,
  LorinProfileConfig,
  ManagedUserAccount,
  ModelRegistryRecord,
  normalizeCanonicalRole,
  Principal,
  SystemControlConfig,
  TaskRoutingPolicyEntry
} from '../types/lorin';
import {
  LORIN_AUTONOMY_LEVELS,
  LORIN_OPERATING_MODES,
  LORIN_PERSONALITIES,
  LORIN_SECURE_ACCESS_VECTORS,
  LORIN_VOICE_PROFILES
} from '../services/lorinProfileService';
import {
  ALL_REGISTERED_MODULES,
  GLOBAL_FEATURE_ACCESS_MATRIX,
  PolicyEngine
} from '../services/policyEngine';
import { OllamaService } from '../services/ollamaService';
import { MosairaLabHub } from './lab/MosairaLabHub';
import { LaurenVaultHub } from './vault/LaurenVaultHub';

interface Props {
  principal: Principal;
  onReturnToPublic: () => void;
  profileConfig?: LorinProfileConfig;
  onOpenModeAndAccessModal?: (tab?: 'persona' | 'levels' | 'access_runtime') => void;
  onToggleOnlineOffline?: () => void;
}

export type OwnerWorkspace = 'hub' | 'rbac' | 'matrix' | 'config' | 'lab' | 'vault';

const CANONICAL_ROLES_LIST: CanonicalRole[] = [
  'SYSTEM_OWNER',
  'SUPER_ADMIN',
  'ADMINISTRATOR',
  'SPECIALIST',
  'STANDARD_USER',
  'RESTRICTED'
];

export const UnifiedOwnerGateway: React.FC<Props> = ({
  principal,
  onReturnToPublic,
  profileConfig,
  onOpenModeAndAccessModal,
  onToggleOnlineOffline
}) => {
  const [workspace, setWorkspace] = useState<OwnerWorkspace>('hub');
  const [managedUsers, setManagedUsers] = useState<ManagedUserAccount[]>(() => PolicyEngine.getManagedAccounts());
  const [systemConfig, setSystemConfig] = useState<SystemControlConfig>(() => PolicyEngine.getSystemControlConfig());
  const [backups, setBackups] = useState<BackupSnapshotRecord[]>(() => PolicyEngine.getBackupSnapshots());
  const [statusBanner, setStatusBanner] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Invite / Create user form state
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteDisplayName, setInviteDisplayName] = useState('');
  const [inviteRole, setInviteRole] = useState<CanonicalRole>('SPECIALIST');
  const [inviteProjects, setInviteProjects] = useState('proj_lorin_core');

  // Confirmation modal state for sensitive operations
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    description: string;
    confirmLabel: string;
    onConfirm: () => Promise<void>;
  } | null>(null);

  // Snapshot label state
  const [backupLabel, setBackupLabel] = useState('Production Control Plane Checkpoint');

  // Central Model Registry & Task Routing state
  const [registryModels, setRegistryModels] = useState<ModelRegistryRecord[]>([]);
  const [taskRoutingTable, setTaskRoutingTable] = useState<TaskRoutingPolicyEntry[]>([]);
  const [ollamaCloudConfigured, setOllamaCloudConfigured] = useState(false);
  const [syncingCatalogue, setSyncingCatalogue] = useState(false);
  const [verifyingModelId, setVerifyingModelId] = useState<string | null>(null);

  const actorCanonical = normalizeCanonicalRole(principal.canonicalRole || principal.role, principal.accountStatus);
  const isSystemOwner = isSystemOwnerPrincipal(principal);
  const isSuperAdminOrOwner = isSuperAdminOrOwnerPrincipal(principal);
  const canAccessControlPlane = PolicyEngine.canAccessModule(principal, 'ownerGateway');

  const refreshControlPlaneState = () => {
    setManagedUsers(PolicyEngine.getManagedAccounts());
    setSystemConfig(PolicyEngine.getSystemControlConfig());
    setBackups(PolicyEngine.getBackupSnapshots());
    OllamaService.fetchCentralModelRegistry().then(data => {
      if (data) {
        setRegistryModels(data.models || []);
        setTaskRoutingTable(data.taskRoutingTable || []);
        setOllamaCloudConfigured(Boolean(data.ollamaCloudConfigured));
      }
    });
  };

  useEffect(() => {
    PolicyEngine.syncFromBackend().then(refreshControlPlaneState);
  }, []);

  if (!canAccessControlPlane) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-[#0B0F14] text-[#F1F5F9] p-8 text-center">
        <div className="max-w-md p-6 rounded-2xl bg-[#111821] border border-rose-500/30 space-y-4">
          <AlertTriangle className="w-10 h-10 text-rose-400 mx-auto" />
          <h2 className="text-lg font-bold text-white">Access Denied — Control Plane Restricted</h2>
          <p className="text-xs text-[#A2AFBF] leading-relaxed">
            Only the verified <span className="font-mono text-white">SYSTEM_OWNER</span>, authorized{' '}
            <span className="font-mono text-white">SUPER_ADMIN</span>, or explicitly delegated{' '}
            <span className="font-mono text-white">ADMINISTRATOR</span> accounts may access the LORIN Control Centre.
          </p>
          <button
            onClick={onReturnToPublic}
            className="px-4 py-2 rounded-xl bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-xs font-semibold text-white cursor-pointer"
          >
            Return to Workspace
          </button>
        </div>
      </div>
    );
  }

  if (workspace === 'lab') {
    return (
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <div className="px-6 py-2.5 bg-[#111821] border-b border-[#283544] flex items-center justify-between">
          <button
            onClick={() => setWorkspace('hub')}
            className="text-xs font-mono text-[#66E3CB] hover:underline flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Super Admin & System Owner Control Centre</span>
          </button>
          <span className="text-[11px] font-mono text-[#A2AFBF]">MOSAIRA AI Lab Operations</span>
        </div>
        <MosairaLabHub
          principal={principal}
          onSwitchToLaurenVault={() => setWorkspace('vault')}
        />
      </div>
    );
  }

  if (workspace === 'vault') {
    return (
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <div className="px-6 py-2.5 bg-[#111821] border-b border-[#283544] flex items-center justify-between">
          <button
            onClick={() => setWorkspace('hub')}
            className="text-xs font-mono text-[#66E3CB] hover:underline flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Super Admin & System Owner Control Centre</span>
          </button>
          <span className="text-[11px] font-mono text-[#A2AFBF]">Lauren Private Knowledge Vault</span>
        </div>
        <LaurenVaultHub
          principal={principal}
          onSwitchToMosairaLab={() => setWorkspace('lab')}
        />
      </div>
    );
  }

  const isOnline = profileConfig ? profileConfig.runtimeActivation === 'ONLINE_ACTIVE' : true;

  const handleInviteUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusBanner(null);
    const scopes = inviteProjects
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);
    const res = await PolicyEngine.inviteManagedAccount(principal, {
      email: inviteEmail,
      displayName: inviteDisplayName,
      role: inviteRole,
      projectScopes: scopes.length > 0 ? scopes : ['proj_lorin_core']
    });
    setStatusBanner({ type: res.success ? 'success' : 'error', text: res.message });
    if (res.success) {
      setInviteEmail('');
      setInviteDisplayName('');
      refreshControlPlaneState();
    }
  };

  const handleRoleChangeRequest = (account: ManagedUserAccount, nextRole: CanonicalRole) => {
    if (nextRole === account.canonicalRole) return;
    setConfirmDialog({
      title: `Confirm Role Assignment (${account.email})`,
      description: `Change authoritative role for ${account.email} from ${account.canonicalRole} (Level ${getRoleHierarchyLevel(account.canonicalRole)}) to ${nextRole} (Level ${getRoleHierarchyLevel(nextRole)})? This change takes effect immediately across backend and Firestore rules.`,
      confirmLabel: `Assign ${nextRole}`,
      onConfirm: async () => {
        const res = await PolicyEngine.assignAccountRole(principal, account.uid, nextRole);
        setStatusBanner({ type: res.success ? 'success' : 'error', text: res.message });
        refreshControlPlaneState();
        setConfirmDialog(null);
      }
    });
  };

  const handleStatusChangeRequest = (account: ManagedUserAccount, nextStatus: AccountStatus) => {
    setConfirmDialog({
      title: `Confirm Account Status Change (${account.email})`,
      description: `Set account status for ${account.email} to ${nextStatus}? ${
        nextStatus === 'DISABLED' || nextStatus === 'REVOKED'
          ? 'All active sessions and tokens for this user will be immediately rejected by the backend.'
          : 'This account will be restored to active standing.'
      }`,
      confirmLabel: `Set ${nextStatus}`,
      onConfirm: async () => {
        const res = await PolicyEngine.updateAccountStatus(principal, account.uid, nextStatus);
        setStatusBanner({ type: res.success ? 'success' : 'error', text: res.message });
        refreshControlPlaneState();
        setConfirmDialog(null);
      }
    });
  };

  const handleRevokeSessionsRequest = (account: ManagedUserAccount) => {
    setConfirmDialog({
      title: `Revoke Active Sessions (${account.email})`,
      description: `Force-invalidate all active tokens and sessions for ${account.email}? The user will be required to re-authenticate before performing any protected operation.`,
      confirmLabel: 'Revoke Sessions Now',
      onConfirm: async () => {
        const res = await PolicyEngine.revokeAccountSessions(principal, account.uid);
        setStatusBanner({ type: res.success ? 'success' : 'error', text: res.message });
        refreshControlPlaneState();
        setConfirmDialog(null);
      }
    });
  };

  const handleSaveSystemConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await PolicyEngine.updateSystemControlConfig(principal, systemConfig);
    setStatusBanner({ type: res.success ? 'success' : 'error', text: res.message });
    refreshControlPlaneState();
  };

  const handleCreateBackup = async () => {
    const res = await PolicyEngine.createBackupSnapshot(principal, backupLabel);
    setStatusBanner({ type: res.success ? 'success' : 'error', text: res.message });
    refreshControlPlaneState();
  };

  return (
    <div className="lorin-module-page flex-1 flex flex-col h-full bg-[#0B0F14] text-[#F1F5F9] font-sans overflow-y-auto p-4 sm:p-6 md:p-8">
      <div className="max-w-6xl mx-auto w-full space-y-6">
        {/* Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#283544] pb-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5 flex-wrap">
              <ShieldCheck className="w-6 h-6 text-[#66E3CB]" />
              <h1 className="text-xl font-bold text-white tracking-tight">
                LORIN Super Admin & System Owner Control Centre
              </h1>
              <span className="text-[10px] font-mono px-2.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
                LEVEL {getRoleHierarchyLevel(actorCanonical)} · {actorCanonical}
              </span>
            </div>
            <p className="text-xs text-[#A2AFBF]">
              Authenticated as <span className="font-mono text-white">{principal.email || 'Unavailable'}</span> · Centralized RBAC, Global Feature Matrix & Dual-Product Governance
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {onToggleOnlineOffline && (
              <button
                onClick={onToggleOnlineOffline}
                className={`px-3.5 py-2 rounded-xl border text-xs font-mono font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                  isOnline
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/25'
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/30 hover:bg-amber-500/25'
                }`}
              >
                {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
                <span>{isOnline ? 'LORIN Online Active' : 'LORIN Offline Air-Gapped'}</span>
              </button>
            )}

            <button
              onClick={onReturnToPublic}
              className="px-3.5 py-2 bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] rounded-xl text-xs font-semibold text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-[#A2AFBF]" />
              <span>Return to Public MOSAIRA</span>
            </button>
          </div>
        </div>

        {/* Navigation Sub-Tabs for Control Centre */}
        <div className="flex flex-wrap items-center gap-2 border-b border-[#283544] pb-3">
          {[
            { id: 'hub', label: '1. Control Plane Overview', icon: ShieldCheck },
            { id: 'rbac', label: `2. User, Role & Session Governance (${managedUsers.length})`, icon: Users },
            { id: 'matrix', label: '3. Global Feature Matrix (17 Categories)', icon: Grid },
            { id: 'config', label: '4. Providers, Budgets & Backups', icon: Database },
            { id: 'lab', label: '5. MOSAIRA AI Lab', icon: FolderGit2 },
            { id: 'vault', label: '6. Lauren Private Vault', icon: Lock }
          ].map(tab => {
            const Icon = tab.icon;
            const active = workspace === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setWorkspace(tab.id as OwnerWorkspace)}
                className={`px-3.5 py-2 rounded-xl text-xs font-mono font-semibold flex items-center gap-2 transition-all cursor-pointer border ${
                  active
                    ? 'bg-[#66E3CB] text-slate-950 border-[#66E3CB] font-bold'
                    : 'bg-[#111821] text-[#A2AFBF] border-[#283544] hover:text-white hover:border-[#3A4B5F]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Feedback Banner */}
        {statusBanner && (
          <div
            className={`p-3.5 rounded-xl border text-xs font-mono flex items-center justify-between ${
              statusBanner.type === 'success'
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-950/40 border-rose-500/40 text-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {statusBanner.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>{statusBanner.text}</span>
            </div>
            <button
              onClick={() => setStatusBanner(null)}
              className="text-[10px] underline opacity-80 hover:opacity-100 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Confirmation Modal for Sensitive Role / Status / Session Operations */}
        {confirmDialog && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
            <div className="max-w-md w-full p-6 rounded-2xl bg-[#111821] border border-[#3A4B5F] space-y-4 shadow-2xl">
              <div className="flex items-center gap-2.5 text-amber-400">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <h3 className="text-sm font-bold text-white">{confirmDialog.title}</h3>
              </div>
              <p className="text-xs text-[#A2AFBF] leading-relaxed">{confirmDialog.description}</p>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setConfirmDialog(null)}
                  className="px-3.5 py-2 rounded-xl bg-[#17212C] hover:bg-[#283544] text-xs font-semibold text-[#A2AFBF] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDialog.onConfirm}
                  className="px-4 py-2 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs cursor-pointer"
                >
                  {confirmDialog.confirmLabel}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 1: OVERVIEW & DIAGNOSTICS */}
        {workspace === 'hub' && (
          <div className="space-y-6">
            {/* Canonical Role Hierarchy & System Owner Protection Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 rounded-2xl bg-[#111821] border border-[#283544] space-y-1">
                <div className="text-[10px] font-mono text-[#738297] uppercase">Active Clearance</div>
                <div className="text-base font-bold text-[#66E3CB] font-mono">{actorCanonical}</div>
                <div className="text-[11px] text-[#A2AFBF]">
                  {isSuperAdminOrOwner ? '16/16 Modules Unrestricted' : 'Delegated Access'}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#111821] border border-[#283544] space-y-1">
                <div className="text-[10px] font-mono text-[#738297] uppercase">System Owners</div>
                <div className="text-base font-bold text-white font-mono tabular-nums">
                  {PolicyEngine.countActiveSystemOwners()} Active
                </div>
                <div className="text-[11px] text-emerald-400">Last-Owner Protection Enforced</div>
              </div>

              <div className="p-4 rounded-2xl bg-[#111821] border border-[#283544] space-y-1">
                <div className="text-[10px] font-mono text-[#738297] uppercase">Managed Identities</div>
                <div className="text-base font-bold text-white font-mono tabular-nums">
                  {managedUsers.length} Accounts
                </div>
                <div className="text-[11px] text-[#A9B8FF]">6-Level Canonical Hierarchy</div>
              </div>

              <div className="p-4 rounded-2xl bg-[#111821] border border-[#283544] space-y-1">
                <div className="text-[10px] font-mono text-[#738297] uppercase">Firebase & Rules</div>
                <div className="text-base font-bold text-emerald-400 font-mono">VERIFIED</div>
                <div className="text-[11px] text-[#A2AFBF]">Auth + Firestore RBAC Active</div>
              </div>
            </div>

            {/* Active LORIN Modes, Personalities, Voices, Levels & Secure Access Bar */}
            {profileConfig && (
              <div className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="text-sm font-bold text-white flex items-center gap-2">
                      <Sliders className="w-4 h-4 text-[#66E3CB]" />
                      <span>LORIN Active Intelligence Profile & Runtime State</span>
                    </h2>
                    <p className="text-xs text-[#A2AFBF] mt-0.5">
                      Configure LORIN's active operating mode, personality, speech synthesis voice, autonomy level, and Online/Offline execution boundary.
                    </p>
                  </div>
                  {onOpenModeAndAccessModal && (
                    <button
                      onClick={() => onOpenModeAndAccessModal('persona')}
                      className="px-3.5 py-2 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      <span>Configure Modes, Voices & Access</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
                  <div className="p-3 rounded-xl bg-[#0B0F14] border border-[#283544]">
                    <div className="text-[10px] text-[#738297] uppercase">Operating Mode</div>
                    <div className="text-white font-bold mt-0.5">{LORIN_OPERATING_MODES[profileConfig.operatingMode].shortLabel}</div>
                    <div className="text-[10px] text-[#66E3CB] mt-0.5">
                      Lead: {LORIN_OPERATING_MODES[profileConfig.operatingMode].leadSpecialist.split('_')[0]}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#0B0F14] border border-[#283544]">
                    <div className="text-[10px] text-[#738297] uppercase">Personality & Tone</div>
                    <div className="text-white font-bold mt-0.5">{LORIN_PERSONALITIES[profileConfig.personality].shortLabel}</div>
                    <div className="text-[10px] text-[#A9B8FF] mt-0.5 truncate">
                      {LORIN_PERSONALITIES[profileConfig.personality].label}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#0B0F14] border border-[#283544]">
                    <div className="text-[10px] text-[#738297] uppercase flex items-center gap-1">
                      <Volume2 className="w-3 h-3 text-[#66E3CB]" />
                      <span>Voice Profile</span>
                    </div>
                    <div className="text-white font-bold mt-0.5">{LORIN_VOICE_PROFILES[profileConfig.voiceProfile].shortLabel}</div>
                    <div className="text-[10px] text-[#66E3CB] mt-0.5 tabular-nums">
                      Pitch {LORIN_VOICE_PROFILES[profileConfig.voiceProfile].pitch} · Rate {LORIN_VOICE_PROFILES[profileConfig.voiceProfile].rate}x
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#0B0F14] border border-[#283544]">
                    <div className="text-[10px] text-[#738297] uppercase flex items-center gap-1">
                      <Gauge className="w-3 h-3 text-[#A9B8FF]" />
                      <span>Autonomy Level</span>
                    </div>
                    <div className="text-white font-bold mt-0.5 tabular-nums">
                      {LORIN_AUTONOMY_LEVELS[profileConfig.autonomyLevel].shortLabel}
                    </div>
                    <div className="text-[10px] text-emerald-400 mt-0.5 truncate">
                      {LORIN_AUTONOMY_LEVELS[profileConfig.autonomyLevel].approvalRequirement}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Workspace Switcher Bento Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Workspace 1: MOSAIRA AI Lab */}
              <div className="p-6 rounded-2xl bg-[#111821] border border-[#283544] hover:border-[#66E3CB]/60 transition-all space-y-5 shadow-xl flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="p-3 rounded-xl bg-teal-500/10 border border-teal-500/20 text-[#66E3CB]">
                      <FolderGit2 className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-mono px-2.5 py-1 rounded bg-[#17212C] text-[#A2AFBF] border border-[#283544]">
                      Platform Engineering
                    </span>
                  </div>

                  <div>
                    <h2 className="text-base font-bold text-white tracking-tight">MOSAIRA AI Lab</h2>
                    <p className="text-xs text-[#A2AFBF] mt-1 leading-relaxed">
                      The owner and Super Admin operations workspace for the public platform. Govern public datasets, connect Google Drive (<span className="font-mono text-white">AI_DATA_VAULT/</span>), execute 7-stage normalization, configure LoRA adapters, and manage model registry rollbacks.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setWorkspace('lab')}
                  className="w-full py-3 px-4 bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                >
                  <span>Launch MOSAIRA AI Lab</span>
                </button>
              </div>

              {/* Workspace 2: Lauren Private Knowledge Vault */}
              <div className="p-6 rounded-2xl bg-[#111821] border border-[#283544] hover:border-[#A9B8FF]/60 transition-all space-y-5 shadow-xl flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-[#A9B8FF]">
                      <Lock className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-mono px-2.5 py-1 rounded bg-[#17212C] text-[#A2AFBF] border border-[#283544]">
                      Confidential & Air-Gapped
                    </span>
                  </div>

                  <div>
                    <h2 className="text-base font-bold text-white tracking-tight">Lauren Private Knowledge Vault</h2>
                    <p className="text-xs text-[#A2AFBF] mt-1 leading-relaxed">
                      Your confidential personal assistant workspace. Index private documents, query private RAG with transparent <span className="text-[#A9B8FF] font-semibold">"Why did Lauren use this source?"</span> citations, and route requests to local Ollama on port 11434.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setWorkspace('vault')}
                  className="w-full py-3 px-4 bg-[#A9B8FF] hover:bg-[#92a4ff] text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                >
                  <span>Launch Lauren Private Vault</span>
                </button>
              </div>
            </div>

            {/* How LORIN Is Accessed Securely Matrix */}
            <div className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Key className="w-4 h-4 text-[#66E3CB]" />
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                    How LORIN Is Accessed Securely (Online & Offline Architecture)
                  </h3>
                </div>
                {onOpenModeAndAccessModal && (
                  <button
                    onClick={() => onOpenModeAndAccessModal('access_runtime')}
                    className="text-[11px] font-mono text-[#66E3CB] hover:underline cursor-pointer"
                  >
                    Open Full Access & Runtime Diagnostics ➔
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                {LORIN_SECURE_ACCESS_VECTORS.slice(0, 3).map((vec) => (
                  <div key={vec.id} className="p-3 rounded-xl bg-[#0B0F14] border border-[#283544] space-y-1">
                    <div className="font-bold text-white text-xs">{vec.title}</div>
                    <div className="text-[10px] font-mono text-[#66E3CB]">{vec.shortcutOrEndpoint}</div>
                    <p className="text-[11px] text-[#A2AFBF] leading-relaxed">{vec.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: USER, ROLE & SESSION GOVERNANCE */}
        {workspace === 'rbac' && (
          <div className="space-y-6">
            {/* Invite / Provision Account Form */}
            {isSuperAdminOrOwner && (
              <div className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-sm font-bold text-white flex items-center gap-2">
                      <Plus className="w-4 h-4 text-[#66E3CB]" />
                      <span>Provision / Invite User Account</span>
                    </h2>
                    <p className="text-xs text-[#A2AFBF] mt-0.5">
                      Assign an authoritative 6-level canonical role and project scope. Only SYSTEM_OWNER may create or promote a SYSTEM_OWNER.
                    </p>
                  </div>
                  <button
                    onClick={refreshControlPlaneState}
                    className="px-3 py-1.5 rounded-xl bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-xs font-mono text-[#A2AFBF] flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Sync Registry</span>
                  </button>
                </div>

                <form onSubmit={handleInviteUser} className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs font-mono">
                  <input
                    type="email"
                    required
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    placeholder="user@domain.com"
                    className="px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-white placeholder-[#738297]"
                  />
                  <input
                    type="text"
                    value={inviteDisplayName}
                    onChange={(e) => setInviteDisplayName(e.target.value)}
                    placeholder="Display Name"
                    className="px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-white placeholder-[#738297]"
                  />
                  <select
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value as CanonicalRole)}
                    className="px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-[#66E3CB]"
                  >
                    {CANONICAL_ROLES_LIST.map(r => (
                      <option key={r} value={r} disabled={r === 'SYSTEM_OWNER' && !isSystemOwner}>
                        L{getRoleHierarchyLevel(r)}: {r} {r === 'SYSTEM_OWNER' && !isSystemOwner ? '(Owner Only)' : ''}
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={inviteProjects}
                    onChange={(e) => setInviteProjects(e.target.value)}
                    placeholder="proj_lorin_core, *"
                    className="px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-white placeholder-[#738297]"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Provision Account</span>
                  </button>
                </form>
              </div>
            )}

            {/* Managed Accounts Table */}
            <div className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-white">
                  Authoritative Identity & Role Registry ({managedUsers.length} Accounts)
                </h2>
                <span className="text-[11px] font-mono text-[#738297]">
                  System Owners: {PolicyEngine.countActiveSystemOwners()} · Super Admins: {managedUsers.filter(u => u.canonicalRole === 'SUPER_ADMIN').length}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="border-b border-[#283544] text-[#738297] text-[11px]">
                      <th className="py-2.5 px-3">User / Email</th>
                      <th className="py-2.5 px-3">Canonical Role (6-Level)</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3">Permissions & Project Scope</th>
                      <th className="py-2.5 px-3 text-right">Administrative Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#283544]/60">
                    {managedUsers.map(acc => {
                      const isTargetOwner = acc.canonicalRole === 'SYSTEM_OWNER';
                      const lockedForSuperAdmin = isTargetOwner && !isSystemOwner;
                      return (
                        <tr key={acc.uid} className="hover:bg-[#17212C]/50">
                          <td className="py-3 px-3">
                            <div className="font-bold text-white flex items-center gap-1.5">
                              <span>{acc.displayName}</span>
                              {acc.isPrimarySystemOwner && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                  PRIMARY OWNER
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-[#A2AFBF]">{acc.email}</div>
                          </td>

                          <td className="py-3 px-3">
                            <select
                              disabled={!isSuperAdminOrOwner || lockedForSuperAdmin || Boolean(acc.isPrimarySystemOwner)}
                              value={acc.canonicalRole}
                              onChange={(e) => handleRoleChangeRequest(acc, e.target.value as CanonicalRole)}
                              className="bg-[#0B0F14] border border-[#3A4B5F] rounded-lg px-2.5 py-1 text-xs text-[#66E3CB] disabled:opacity-50"
                            >
                              {CANONICAL_ROLES_LIST.map(r => (
                                <option key={r} value={r} disabled={r === 'SYSTEM_OWNER' && !isSystemOwner}>
                                  L{getRoleHierarchyLevel(r)} · {r}
                                </option>
                              ))}
                            </select>
                          </td>

                          <td className="py-3 px-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                acc.accountStatus === 'ACTIVE'
                                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                                  : acc.accountStatus === 'RESTRICTED'
                                  ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                                  : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                              }`}
                            >
                              {acc.accountStatus}
                            </span>
                          </td>

                          <td className="py-3 px-3 text-[11px] text-[#A2AFBF]">
                            <div>{acc.permissions.length} Canonical Scopes</div>
                            <div className="text-[10px] text-[#738297]">
                              Projects: {acc.projectScopes.join(', ') || 'None'}
                            </div>
                          </td>

                          <td className="py-3 px-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {acc.accountStatus === 'ACTIVE' ? (
                                <button
                                  disabled={!isSuperAdminOrOwner || lockedForSuperAdmin || Boolean(acc.isPrimarySystemOwner)}
                                  onClick={() => handleStatusChangeRequest(acc, 'DISABLED')}
                                  className="px-2 py-1 rounded bg-rose-950/50 hover:bg-rose-900/60 border border-rose-500/30 text-rose-300 text-[10px] disabled:opacity-40 cursor-pointer flex items-center gap-1"
                                  title="Disable account and block all backend requests"
                                >
                                  <Ban className="w-3 h-3" />
                                  <span>Disable</span>
                                </button>
                              ) : (
                                <button
                                  disabled={!isSuperAdminOrOwner || lockedForSuperAdmin}
                                  onClick={() => handleStatusChangeRequest(acc, 'ACTIVE')}
                                  className="px-2 py-1 rounded bg-emerald-950/50 hover:bg-emerald-900/60 border border-emerald-500/30 text-emerald-300 text-[10px] disabled:opacity-40 cursor-pointer flex items-center gap-1"
                                >
                                  <CheckCircle2 className="w-3 h-3" />
                                  <span>Re-Enable</span>
                                </button>
                              )}

                              <button
                                disabled={!isSuperAdminOrOwner || lockedForSuperAdmin}
                                onClick={() => handleRevokeSessionsRequest(acc)}
                                className="px-2 py-1 rounded bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[#A2AFBF] hover:text-white text-[10px] disabled:opacity-40 cursor-pointer flex items-center gap-1"
                                title="Revoke active sessions & evict token cache"
                              >
                                <LogOut className="w-3 h-3" />
                                <span>Revoke Sessions</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: GLOBAL FEATURE ACCESS MATRIX (17 CATEGORIES) */}
        {workspace === 'matrix' && (
          <div className="space-y-6">
            <div className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-sm font-bold text-white">
                    Global Feature Access Matrix (17 Canonical Categories & 16 Modules)
                  </h2>
                  <p className="text-xs text-[#A2AFBF] mt-0.5">
                    Both <span className="font-mono text-[#66E3CB]">SYSTEM_OWNER</span> (Level 1) and{' '}
                    <span className="font-mono text-[#66E3CB]">SUPER_ADMIN</span> (Level 2) have full unrestricted access across all 16 LORIN application modules ({ALL_REGISTERED_MODULES.length}/16).
                  </p>
                </div>
                <span className="text-xs font-mono px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  Synchronized Frontend + Backend Policy
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr className="border-b border-[#283544] text-[#738297] text-[10px]">
                      <th className="py-2.5 px-2.5">#</th>
                      <th className="py-2.5 px-2.5">Feature Category</th>
                      <th className="py-2.5 px-2.5">Required Permissions</th>
                      <th className="py-2.5 px-2.5">SYSTEM_OWNER</th>
                      <th className="py-2.5 px-2.5">SUPER_ADMIN</th>
                      <th className="py-2.5 px-2.5">ADMIN</th>
                      <th className="py-2.5 px-2.5">SPECIALIST</th>
                      <th className="py-2.5 px-2.5">STANDARD</th>
                      <th className="py-2.5 px-2.5">RESTRICTED</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#283544]/60 text-[11px]">
                    {GLOBAL_FEATURE_ACCESS_MATRIX.map(row => (
                      <tr key={row.categoryId} className="hover:bg-[#17212C]/40">
                        <td className="py-2.5 px-2.5 text-[#738297] tabular-nums">{row.categoryNumber}</td>
                        <td className="py-2.5 px-2.5">
                          <div className="font-bold text-white">{row.categoryTitle}</div>
                          <div className="text-[10px] text-[#A2AFBF] max-w-xs">{row.description}</div>
                        </td>
                        <td className="py-2.5 px-2.5 text-[#A9B8FF] text-[10px]">
                          {row.requiredPermissions.join(', ')}
                        </td>
                        {(['SYSTEM_OWNER', 'SUPER_ADMIN', 'ADMINISTRATOR', 'SPECIALIST', 'STANDARD_USER', 'RESTRICTED'] as CanonicalRole[]).map(roleKey => {
                          const val = row.roleAccess[roleKey];
                          return (
                            <td key={roleKey} className="py-2.5 px-2.5">
                              <span
                                className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  val === 'FULL'
                                    ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                    : val === 'DELEGATED' || val === 'SCOPED'
                                    ? 'bg-sky-500/15 text-sky-300 border border-sky-500/30'
                                    : val === 'LIMITED'
                                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                    : 'bg-slate-800/80 text-slate-500'
                                }`}
                              >
                                {val}
                              </span>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: PROVIDERS, MODELS, BUDGETS & BACKUPS */}
        {workspace === 'config' && (
          <div className="space-y-6">
            {/* Central Open-Weight & Cloud Model Registry (Section 3.3, 3.4, 3.5, 3.8) */}
            <div className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-[#66E3CB]" />
                    <h2 className="text-sm font-bold text-white">
                      Central Open-Weight & Cloud Model Registry (Ollama Cloud + Google Gemini)
                    </h2>
                  </div>
                  <p className="text-xs text-[#A2AFBF] mt-1">
                    Cloud-first open-weight model registry (`https://ollama.com`) with controlled verification before activation, license governance, and zero local GPU requirement.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold border ${
                      ollamaCloudConfigured
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                        : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                    }`}
                  >
                    {ollamaCloudConfigured ? 'OLLAMA CLOUD: CONNECTED' : 'OLLAMA_API_KEY: AWAITING SERVER ENV'}
                  </span>
                  {isSuperAdminOrOwner && (
                    <>
                      <button
                        type="button"
                        disabled={syncingCatalogue}
                        onClick={async () => {
                          setSyncingCatalogue(true);
                          const res = await OllamaService.activateAllModelsInRegistry();
                          setSyncingCatalogue(false);
                          setStatusBanner({
                            type: res.success ? 'success' : 'error',
                            text: res.message
                          });
                          if (res.models) setRegistryModels(res.models);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-[11px] font-mono font-bold text-emerald-300 flex items-center gap-1.5 cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Activate All 12 Models</span>
                      </button>
                      <button
                        type="button"
                        disabled={syncingCatalogue}
                        onClick={async () => {
                          setSyncingCatalogue(true);
                          const res = await OllamaService.syncOllamaCloudCatalogue();
                          setSyncingCatalogue(false);
                          setStatusBanner({
                            type: res.synced ? 'success' : 'error',
                            text: res.message
                          });
                          if (res.models) setRegistryModels(res.models);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[11px] font-mono font-bold text-[#66E3CB] flex items-center gap-1.5 cursor-pointer"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${syncingCatalogue ? 'animate-spin' : ''}`} />
                        <span>Sync Catalogue (/api/tags)</span>
                      </button>
                    </>
                  )}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[#283544] text-[10px] font-mono uppercase text-[#738297]">
                      <th className="py-2 px-2">Model & Resolved Tag</th>
                      <th className="py-2 px-2">Provider</th>
                      <th className="py-2 px-2">Default Role Assignment</th>
                      <th className="py-2 px-2">Capabilities & Context</th>
                      <th className="py-2 px-2">License Governance</th>
                      <th className="py-2 px-2">Verification & Status</th>
                      <th className="py-2 px-2 text-right">Admin Control</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#283544]/60 text-xs font-mono">
                    {registryModels.map(m => {
                      const isEnabled = m.enabledByAdmin ?? m.enabled;
                      const avail = m.availabilityState || m.availability;
                      const ctxTokens = m.contextWindowTokens || m.contextLimit || 128000;
                      return (
                        <tr key={m.modelId} className="hover:bg-[#17212C]/40">
                          <td className="py-2.5 px-2">
                            <div className="font-bold text-white">{m.displayName}</div>
                            <div className="text-[10px] text-[#66E3CB]">{m.resolvedTag || m.modelId}</div>
                          </td>
                          <td className="py-2.5 px-2">
                            <span className="px-2 py-0.5 rounded bg-[#0B0F14] border border-[#283544] text-[10px] text-[#A9B8FF]">
                              {m.provider}
                            </span>
                          </td>
                          <td className="py-2.5 px-2 text-[11px] text-[#D7E0EA] max-w-xs">
                            {m.defaultRoleAssignment || m.mainResponsibility}
                          </td>
                          <td className="py-2.5 px-2">
                            <div className="text-[10px] text-[#A2AFBF]">
                              {(ctxTokens / 1000).toFixed(0)}K ctx · {m.costLatencyTier || m.costProfile}
                            </div>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {m.capabilities.slice(0, 4).map(cap => (
                                <span
                                  key={cap}
                                  className="px-1.5 py-0.2 rounded bg-[#17212C] text-[9px] text-[#66E3CB]"
                                >
                                  {cap}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="py-2.5 px-2">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                m.licenseCategory === 'OPEN_SOURCE_PERMISSIVE'
                                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                  : m.licenseCategory === 'OPEN_WEIGHT_CUSTOM_LICENSE' ||
                                    m.licenseCategory === 'OPEN_WEIGHT_USAGE_POLICY'
                                  ? 'bg-sky-500/15 text-sky-300 border border-sky-500/30'
                                  : 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
                              }`}
                            >
                              {m.licenseCategory}
                            </span>
                            <div className="text-[10px] text-[#738297] mt-0.5">{m.licenseClassification || m.license}</div>
                          </td>
                          <td className="py-2.5 px-2">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                avail === 'VERIFIED_READY' || avail === 'verified'
                                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                  : avail === 'CATALOGUE_MATCHED' || avail === 'available_untested'
                                  ? 'bg-sky-500/15 text-sky-300 border border-sky-500/30'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {avail}
                            </span>
                            <div className="text-[10px] text-[#738297] mt-0.5">
                              {isEnabled ? 'Enabled in Router' : 'Disabled until verified'}
                            </div>
                          </td>
                          <td className="py-2.5 px-2 text-right space-x-1.5">
                            {isSuperAdminOrOwner && (
                              <>
                                <button
                                  type="button"
                                  disabled={verifyingModelId === m.modelId}
                                  onClick={async () => {
                                    setVerifyingModelId(m.modelId);
                                    const res = await OllamaService.verifyModelInRegistry(m.modelId);
                                    setVerifyingModelId(null);
                                    setStatusBanner({
                                      type: res.verified ? 'success' : 'error',
                                      text: res.message
                                    });
                                    refreshControlPlaneState();
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-[#66E3CB]/15 hover:bg-[#66E3CB]/25 border border-[#66E3CB]/40 text-[10px] text-[#66E3CB] font-bold cursor-pointer"
                                >
                                  {verifyingModelId === m.modelId ? 'Probing...' : 'Verify & Enable'}
                                </button>
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await OllamaService.updateModelRegistryState(m.modelId, {
                                      enabledByAdmin: !isEnabled
                                    });
                                    refreshControlPlaneState();
                                  }}
                                  className="px-2 py-1 rounded-lg bg-[#17212C] hover:bg-[#283544] border border-[#3A4B5F] text-[10px] text-white cursor-pointer"
                                >
                                  {isEnabled ? 'Disable' : 'Enable'}
                                </button>
                              </>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 15-Capability Task-Based Intelligence Routing Table (Section 3.6) */}
            {taskRoutingTable.length > 0 && (
              <div className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-mono uppercase tracking-wider text-[#66E3CB] font-bold">
                    Task-Based Intelligence Routing Policy (Section 3.6)
                  </h3>
                  <span className="text-[11px] font-mono text-[#A2AFBF]">
                    {taskRoutingTable.length} Task Categories Configured
                  </span>
                </div>
                <div className="overflow-x-auto max-h-64 overflow-y-auto">
                  <table className="w-full text-left border-collapse text-[11px] font-mono">
                    <thead>
                      <tr className="border-b border-[#283544] text-[10px] uppercase text-[#738297]">
                        <th className="py-2 px-2">Task / Capability</th>
                        <th className="py-2 px-2">Primary Model / Service</th>
                        <th className="py-2 px-2">Secondary / Fallback</th>
                        <th className="py-2 px-2">Routing Notes</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#283544]/60">
                      {taskRoutingTable.map(entry => (
                        <tr key={entry.category || entry.capability} className="hover:bg-[#17212C]/40">
                          <td className="py-2 px-2 font-bold text-white">{entry.label || entry.capabilityTitle}</td>
                          <td className="py-2 px-2 text-[#66E3CB]">
                            {(entry.primaryModelIds || entry.preferredModels).join(' / ')}
                          </td>
                          <td className="py-2 px-2 text-[#A9B8FF]">
                            {(entry.secondaryFallbackIds || entry.fallbackModels).join(' / ')}
                          </td>
                          <td className="py-2 px-2 text-[#A2AFBF]">{entry.notes}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* System Control Configuration */}
              <form
                onSubmit={handleSaveSystemConfig}
                className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-4"
              >
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#66E3CB]" />
                  <h2 className="text-sm font-bold text-white">
                    AI Provider Routing, Rate Limits & Security Policy
                  </h2>
                </div>

                <div className="space-y-3 text-xs font-mono">
                  <div>
                    <label className="block text-[#A2AFBF] mb-1">Registration Policy</label>
                    <select
                      value={systemConfig.registrationPolicy}
                      onChange={(e) =>
                        setSystemConfig({ ...systemConfig, registrationPolicy: e.target.value as any })
                      }
                      className="w-full px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-white"
                    >
                      <option value="INVITE_ONLY">INVITE_ONLY (Recommended Private Default)</option>
                      <option value="DOMAIN_RESTRICTED">DOMAIN_RESTRICTED</option>
                      <option value="OPEN_STANDARD">OPEN_STANDARD (Assigns STANDARD_USER)</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[#A2AFBF] mb-1">Global Rate Limit (RPM)</label>
                      <input
                        type="number"
                        value={systemConfig.globalRateLimitRpm}
                        onChange={(e) =>
                          setSystemConfig({ ...systemConfig, globalRateLimitRpm: Number(e.target.value) || 60 })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[#A2AFBF] mb-1">Daily Token Budget</label>
                      <input
                        type="number"
                        value={systemConfig.dailyTokenBudget}
                        onChange={(e) =>
                          setSystemConfig({ ...systemConfig, dailyTokenBudget: Number(e.target.value) || 250000 })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[#A2AFBF] mb-1">Session Timeout (Mins)</label>
                      <input
                        type="number"
                        value={systemConfig.sessionTimeoutMinutes}
                        onChange={(e) =>
                          setSystemConfig({ ...systemConfig, sessionTimeoutMinutes: Number(e.target.value) || 60 })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[#A2AFBF] mb-1">Audit Retention (Days)</label>
                      <input
                        type="number"
                        value={systemConfig.auditRetentionDays}
                        onChange={(e) =>
                          setSystemConfig({ ...systemConfig, auditRetentionDays: Number(e.target.value) || 90 })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-white"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-[#66E3CB] hover:bg-[#52d6be] text-slate-950 font-bold text-xs cursor-pointer"
                >
                  Save & Synchronize Control Plane Configuration
                </button>
              </form>

              {/* Backup & Recovery Administration */}
              <div className="p-5 rounded-2xl bg-[#111821] border border-[#283544] space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-[#A9B8FF]" />
                    <h2 className="text-sm font-bold text-white">
                      Backup, Retention & Recovery Checkpoints
                    </h2>
                  </div>
                  <p className="text-xs text-[#A2AFBF]">
                    Generate SHA-256 verified state snapshots of managed RBAC accounts, policy approvals, and audit records.
                  </p>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={backupLabel}
                      onChange={(e) => setBackupLabel(e.target.value)}
                      className="flex-1 px-3 py-2 rounded-xl bg-[#0B0F14] border border-[#283544] text-xs font-mono text-white"
                      placeholder="Snapshot label..."
                    />
                    <button
                      type="button"
                      onClick={handleCreateBackup}
                      className="px-4 py-2 rounded-xl bg-[#A9B8FF] hover:bg-[#92a4ff] text-slate-950 font-bold text-xs cursor-pointer shrink-0"
                    >
                      Create Snapshot
                    </button>
                  </div>

                  <div className="space-y-2 max-h-56 overflow-y-auto">
                    {backups.length === 0 ? (
                      <div className="text-xs font-mono text-[#738297] py-4 text-center">
                        No backup snapshots created in this session yet.
                      </div>
                    ) : (
                      backups.map(bkp => (
                        <div
                          key={bkp.id}
                          className="p-3 rounded-xl bg-[#0B0F14] border border-[#283544] text-xs font-mono space-y-1"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-white">{bkp.label}</span>
                            <span className="text-[10px] text-[#66E3CB]">{bkp.createdByRole}</span>
                          </div>
                          <div className="text-[10px] text-[#A2AFBF]">
                            Users: {bkp.counts.managedUsers} · Approvals: {bkp.counts.approvals} · Audits: {bkp.counts.auditEvents}
                          </div>
                          <div className="text-[10px] text-[#738297] truncate">
                            SHA-256: {bkp.integritySha256}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* System Invariants & Privacy Boundary Notice */}
        <div className="p-4 rounded-xl bg-[#17212C] border border-[#283544] flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-[#A2AFBF]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#66E3CB]" />
            <span>Isolation Invariant: Only verified SYSTEM_OWNER & SUPER_ADMIN have unrestricted LORIN access.</span>
          </div>
          <span className="text-[#738297]">Zero-Trust Firebase RBAC Active</span>
        </div>
      </div>
    </div>
  );
};
