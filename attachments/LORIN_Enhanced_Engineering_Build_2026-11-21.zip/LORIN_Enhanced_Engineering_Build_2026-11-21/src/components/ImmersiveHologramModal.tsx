import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Mic,
  Eye,
  Cpu,
  Layers,
  Send,
  FolderKanban,
  BookOpen,
  ShieldCheck,
  Terminal,
  Compass,
  Radio,
  Sliders,
  Camera
} from 'lucide-react';
import { LorinCharacter, STATE_LABELS } from './LorinCharacter';
import {
  CharacterPresentation,
  LorinCharacterState,
  LorinEnvironment,
  resolveExpressionForState
} from '../services/lorinPresence';
import { CameraFramingPreset } from '../holographic/core/HologramRuntime';
import {
  HologramQualityProfile,
  QualityManager,
  QualityProfileSettings
} from '../holographic/core/QualityManager';
import {
  detectRenderingCapabilitiesSync,
  RenderingCapabilitiesReport
} from '../holographic/core/RenderingCapabilities';
import {
  PixelStreamingAdapter,
  PixelStreamingStatus
} from '../holographic/streaming/PixelStreamingAdapter';
import { ProjectStore } from '../services/projectStore';
import { LaurenVaultService } from '../services/laurenVaultService';
import { AudioService } from '../services/audioService';
import { LorinCompletionReport, Principal, WorkspaceView } from '../types/lorin';
import { getAuthHeaders } from '../services/authHeaders';

export interface ImmersiveHologramModalProps {
  isOpen: boolean;
  onClose: () => void;
  principal: Principal;
  characterState: LorinCharacterState;
  environment: LorinEnvironment;
  presentation: CharacterPresentation;
  activeProjectId: string;
  pendingApprovalsCount: number;
  isLoading: boolean;
  latestResponseText?: string;
  onSendMessage: (prompt: string) => Promise<LorinCompletionReport>;
  onSwitchWorkspace: (view: WorkspaceView) => void;
}

export const ImmersiveHologramModal: React.FC<ImmersiveHologramModalProps> = ({
  isOpen,
  onClose,
  principal,
  characterState,
  environment,
  activeProjectId,
  pendingApprovalsCount,
  isLoading,
  latestResponseText,
  onSendMessage,
  onSwitchWorkspace
}) => {
  const [cameraPreset, setCameraPreset] = useState<CameraFramingPreset>('upper_body');
  const [qualityProfile, setQualityProfile] = useState<QualityProfileSettings>(() =>
    QualityManager.getActiveProfile()
  );
  const [measuredFps, setMeasuredFps] = useState<number>(() => QualityManager.getMeasuredFps());
  const [capabilities] = useState<RenderingCapabilitiesReport>(() =>
    detectRenderingCapabilitiesSync()
  );
  const [streamStatus, setStreamStatus] = useState<PixelStreamingStatus>(() =>
    PixelStreamingAdapter.getStatus()
  );
  const [signallingUrlInput, setSignallingUrlInput] = useState<string>(
    () => PixelStreamingAdapter.getStatus().signallingUrl
  );
  const [showStreamingConfig, setShowStreamingConfig] = useState(false);
  const [promptText, setPromptText] = useState('');
  const [isSpeakingLocal, setIsSpeakingLocal] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const [localReply, setLocalReply] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const unsubQuality = QualityManager.subscribe((prof, fps) => {
      setQualityProfile(prof);
      setMeasuredFps(fps);
    });
    const unsubStream = PixelStreamingAdapter.subscribe(st => {
      setStreamStatus(st);
    });

    const interval = window.setInterval(() => {
      setMeasuredFps(QualityManager.getMeasuredFps());
      const synthSpeaking =
        typeof window !== 'undefined' &&
        'speechSynthesis' in window &&
        window.speechSynthesis.speaking;
      setIsSpeakingLocal(synthSpeaking);
      setAudioLevel(synthSpeaking ? 42 + Math.round(Math.random() * 28) : 0);
    }, 250);

    return () => {
      window.clearInterval(interval);
      unsubQuality();
      unsubStream();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const activeProject = ProjectStore.getProject(activeProjectId);
  const indexedDocsCount = LaurenVaultService.getDocuments().length;
  const effectiveState: LorinCharacterState = isSpeakingLocal
    ? 'SPEAKING'
    : isLoading
    ? 'THINKING'
    : characterState;
  const activeExpression = resolveExpressionForState(effectiveState);

  const handlePromptSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = promptText.trim();
    if (!clean || isLoading) return;
    setPromptText('');
    try {
      const report = await onSendMessage(clean);
      setLocalReply(report.rawSynthesis);
      if (report.rawSynthesis) {
        AudioService.speak(report.rawSynthesis.slice(0, 360), () => {
          setIsSpeakingLocal(false);
          setAudioLevel(0);
        });
      }
    } catch {
      // Handled by parent state
    }
  };

  const handleSaveSignallingUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    PixelStreamingAdapter.updateConfig({ signallingUrl: signallingUrlInput });
    if (signallingUrlInput.trim()) {
      const headers = await getAuthHeaders();
      const bearer = (headers as Record<string, string>).Authorization?.replace(/^Bearer\s+/i, '');
      await PixelStreamingAdapter.connect(bearer || principal.id);
    } else {
      PixelStreamingAdapter.disconnect();
    }
  };

  const displayReply = localReply || latestResponseText;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.22 }}
        className="fixed inset-0 z-50 bg-[#0B0F14]/95 backdrop-blur-xl flex flex-col overflow-hidden text-[#F1F5F9]"
        role="dialog"
        aria-modal="true"
        aria-label="LORIN Full Immersive Holographic Mode"
      >
        {/* Top Spatial Control Bar */}
        <header className="px-4 sm:px-6 py-3.5 border-b border-[#283544] bg-[#111821]/90 flex flex-wrap items-center justify-between gap-3 z-20">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#66E3CB] shadow-[0_0_12px_#66E3CB]" />
            <div>
              <h2 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
                <span>LORIN — Dedicated Holographic Stage</span>
                <span className="px-2 py-0.5 rounded bg-[#17212C] border border-[#3A4B5F] text-[10px] font-mono text-[#66E3CB]">
                  HYBRID DIGITAL HUMAN · {capabilities.preferredNativeBackend}
                </span>
              </h2>
              <p className="text-[11px] text-[#A2AFBF] font-mono">
                State: <strong className="text-[#66E3CB]">{STATE_LABELS[effectiveState]}</strong> · Expression:{' '}
                <strong className="text-[#A9B8FF]">{activeExpression}</strong> · Environment:{' '}
                <strong className="text-white">{environment}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Camera Framing Selector */}
            <div className="flex items-center gap-1 bg-[#17212C] border border-[#283544] rounded-lg p-1 text-[11px] font-mono">
              <Camera className="w-3.5 h-3.5 text-[#66E3CB] ml-1.5 mr-1" />
              {(['portrait', 'upper_body', 'full_stage', 'cinematic'] as CameraFramingPreset[]).map(preset => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setCameraPreset(preset)}
                  className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                    cameraPreset === preset
                      ? 'bg-[#66E3CB] text-[#0B0F14] font-bold'
                      : 'text-[#A2AFBF] hover:text-white'
                  }`}
                >
                  {preset === 'portrait'
                    ? 'Portrait'
                    : preset === 'upper_body'
                    ? 'Upper Body'
                    : preset === 'full_stage'
                    ? 'Full Stage'
                    : 'Cinematic'}
                </button>
              ))}
            </div>

            {/* Quality Profile Selector */}
            <div className="flex items-center gap-1.5 bg-[#17212C] border border-[#283544] rounded-lg px-2.5 py-1 text-[11px] font-mono">
              <Sliders className="w-3.5 h-3.5 text-[#A9B8FF]" />
              <select
                aria-label="Hologram rendering quality profile"
                value={qualityProfile.profile}
                onChange={e =>
                  QualityManager.setQualityProfile(e.target.value as HologramQualityProfile)
                }
                className="bg-transparent text-white focus:outline-none cursor-pointer"
              >
                <option value="ULTRA" className="bg-[#111821]">ULTRA Quality</option>
                <option value="HIGH" className="bg-[#111821]">HIGH Quality</option>
                <option value="BALANCED" className="bg-[#111821]">BALANCED Quality</option>
                <option value="LOW" className="bg-[#111821]">LOW Power</option>
                <option value="MOBILE" className="bg-[#111821]">MOBILE Profile</option>
              </select>
              <span className="text-[#66E3CB] pl-1 border-l border-[#283544]">{measuredFps} FPS</span>
            </div>

            <button
              type="button"
              onClick={() => setShowStreamingConfig(prev => !prev)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer ${
                streamStatus.state === 'CONNECTED'
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : 'bg-[#17212C] border-[#283544] text-[#A2AFBF] hover:text-white'
              }`}
            >
              <Radio className="w-3.5 h-3.5 text-[#66E3CB]" />
              <span>UE5.8 Stream: {streamStatus.state}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg bg-[#17212C] hover:bg-[#1F2D3C] border border-[#283544] text-[#A2AFBF] hover:text-white transition-colors cursor-pointer"
              aria-label="Exit Immersive Holographic Mode"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Main 3-Column Spatial Holographic Stage */}
        <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 gap-4 p-4 sm:p-6 overflow-y-auto">
          {/* Left Spatial Column: Real System & Environment Controls */}
          <div className="lg:col-span-3 flex flex-col gap-4 justify-center">
            <div className="p-4 rounded-2xl bg-[#111821]/85 border border-[#283544] backdrop-blur-md space-y-3 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider font-mono text-[#66E3CB] flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Rendering Telemetry</span>
                </span>
                <span className="text-[11px] font-mono text-[#A2AFBF]">{capabilities.gpuVendorHint.slice(0, 24)}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2.5 rounded-xl bg-[#17212C] border border-[#283544]">
                  <div className="text-[10px] text-[#A2AFBF]">Active Engine</div>
                  <div className="text-[#66E3CB] font-bold mt-0.5">Babylon.js {capabilities.preferredNativeBackend}</div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#17212C] border border-[#283544]">
                  <div className="text-[10px] text-[#A2AFBF]">Frame Rate</div>
                  <div className="text-white font-bold mt-0.5">{measuredFps} FPS</div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#17212C] border border-[#283544]">
                  <div className="text-[10px] text-[#A2AFBF]">Subsurface Skin</div>
                  <div className="text-[#A9B8FF] font-bold mt-0.5">
                    {qualityProfile.enableSubsurfaceScattering ? 'Active (PBR SSS)' : 'Standard'}
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#17212C] border border-[#283544]">
                  <div className="text-[10px] text-[#A2AFBF]">Eye Optics</div>
                  <div className="text-[#66E3CB] font-bold mt-0.5">
                    {qualityProfile.enableClearCoatEyes ? 'ClearCoat Cornea' : 'Standard'}
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Environment Switcher */}
            <div className="p-4 rounded-2xl bg-[#111821]/85 border border-[#283544] backdrop-blur-md space-y-3 shadow-xl">
              <div className="text-xs font-bold uppercase tracking-wider font-mono text-[#A9B8FF] flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                <span>Spatial Environment Switcher</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    onSwitchWorkspace('voice');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-[#17212C] hover:bg-[#1F2D3C] border border-[#283544] text-left flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Mic className="w-4 h-4 text-[#66E3CB] shrink-0" />
                  <span>Voice Stage</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onSwitchWorkspace('video');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-[#17212C] hover:bg-[#1F2D3C] border border-[#283544] text-left flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Eye className="w-4 h-4 text-[#A9B8FF] shrink-0" />
                  <span>Vision Stage</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onSwitchWorkspace('gideon');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-[#17212C] hover:bg-[#1F2D3C] border border-[#283544] text-left flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Compass className="w-4 h-4 text-[#E8BE78] shrink-0" />
                  <span>Research / GIDEON</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onSwitchWorkspace('terminal');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-[#17212C] hover:bg-[#1F2D3C] border border-[#283544] text-left flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Terminal className="w-4 h-4 text-[#66E3CB] shrink-0" />
                  <span>Coding Workbench</span>
                </button>
              </div>
            </div>
          </div>

          {/* Center Column: Primary Full-Scale 3D Digital Human Stage */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center relative min-h-[380px]">
            <div className="relative w-full h-full flex items-center justify-center rounded-3xl bg-radial from-[#172A3A]/50 via-[#0E1621]/70 to-[#0B0F14] border border-[#283544] p-4 shadow-2xl overflow-hidden">
              <LorinCharacter
                state={effectiveState}
                presentation="full"
                environment="immersive"
                audioLevel={audioLevel}
                isSpeaking={isSpeakingLocal}
                force3D={true}
                cameraPreset={cameraPreset}
                onCameraPresetChange={setCameraPreset}
                showStatus={true}
                className="mx-auto"
              />
            </div>
          </div>

          {/* Right Spatial Column: Real Project, Knowledge Vault & Unreal Pixel Streaming Adapter */}
          <div className="lg:col-span-3 flex flex-col gap-4 justify-center">
            <div className="p-4 rounded-2xl bg-[#111821]/85 border border-[#283544] backdrop-blur-md space-y-3 shadow-xl">
              <div className="text-xs font-bold uppercase tracking-wider font-mono text-[#66E3CB] flex items-center gap-1.5">
                <FolderKanban className="w-3.5 h-3.5" />
                <span>Live Workspace Context</span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-xl bg-[#17212C] border border-[#283544]">
                  <div className="text-[10px] font-mono text-[#A2AFBF]">Active Project</div>
                  <div className="font-semibold text-white mt-0.5 truncate">
                    {activeProject?.name || 'LORIN Core Intelligence'}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      onSwitchWorkspace('vault');
                      onClose();
                    }}
                    className="p-2.5 rounded-xl bg-[#17212C] hover:bg-[#1F2D3C] border border-[#283544] text-left cursor-pointer"
                  >
                    <div className="text-[10px] font-mono text-[#A2AFBF] flex items-center gap-1">
                      <BookOpen className="w-3 h-3 text-[#66E3CB]" />
                      <span>Vault Docs</span>
                    </div>
                    <div className="text-sm font-bold text-white mt-0.5 font-mono">{indexedDocsCount} Indexed</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onSwitchWorkspace('security');
                      onClose();
                    }}
                    className="p-2.5 rounded-xl bg-[#17212C] hover:bg-[#1F2D3C] border border-[#283544] text-left cursor-pointer"
                  >
                    <div className="text-[10px] font-mono text-[#A2AFBF] flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-[#E8BE78]" />
                      <span>Approvals</span>
                    </div>
                    <div className="text-sm font-bold text-white mt-0.5 font-mono">{pendingApprovalsCount} Pending</div>
                  </button>
                </div>
              </div>
            </div>

            {/* Unreal Engine 5.8 + MetaHuman Pixel Streaming Adapter Card */}
            {(showStreamingConfig || streamStatus.configured) && (
              <form
                onSubmit={handleSaveSignallingUrl}
                className="p-4 rounded-2xl bg-[#111821]/90 border border-[#3A4B5F] space-y-2.5 shadow-xl"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-mono text-[#E8BE78]">
                    Unreal 5.8 MetaHuman Pixel Stream
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#17212C] text-[#A2AFBF]">
                    {streamStatus.state}
                  </span>
                </div>
                <p className="text-[11px] text-[#A2AFBF] leading-relaxed">
                  {streamStatus.statusMessage}
                </p>
                <input
                  type="text"
                  value={signallingUrlInput}
                  onChange={e => setSignallingUrlInput(e.target.value)}
                  placeholder="wss://pixelstream-host.domain:8888"
                  className="w-full px-3 py-1.5 rounded-lg bg-[#0B0F14] border border-[#283544] text-xs font-mono text-white placeholder-[#738297] focus:outline-none focus:border-[#66E3CB]"
                />
                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    className="flex-1 py-1.5 px-3 rounded-lg bg-[#66E3CB] hover:bg-[#52cfb7] text-[#0B0F14] font-bold text-xs cursor-pointer"
                  >
                    {signallingUrlInput.trim() ? 'Connect WebRTC Stream' : 'Use Browser-Native 3D'}
                  </button>
                  {streamStatus.state === 'CONNECTED' && (
                    <button
                      type="button"
                      onClick={() => PixelStreamingAdapter.disconnect()}
                      className="py-1.5 px-3 rounded-lg bg-rose-950/50 border border-rose-500/40 text-rose-200 text-xs cursor-pointer"
                    >
                      Disconnect
                    </button>
                  )}
                </div>
              </form>
            )}

            {/* Latest Holographic Response Preview */}
            {displayReply && (
              <div className="p-4 rounded-2xl bg-[#111821]/85 border border-[#283544] space-y-2 max-h-48 overflow-y-auto">
                <div className="text-[10px] font-mono uppercase tracking-wider text-[#66E3CB]">
                  LORIN Response Synthesis
                </div>
                <p className="text-xs text-[#F1F5F9] leading-relaxed whitespace-pre-wrap">
                  {displayReply.slice(0, 420)}
                  {displayReply.length > 420 ? '…' : ''}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Direct Holographic Prompt Bar */}
        <footer className="px-4 sm:px-6 py-3.5 border-t border-[#283544] bg-[#111821]/95">
          <form onSubmit={handlePromptSubmit} className="max-w-3xl mx-auto flex items-center gap-3">
            <input
              type="text"
              value={promptText}
              onChange={e => setPromptText(e.target.value)}
              placeholder="Speak or type directly to LORIN in Full Immersive Holographic Mode..."
              disabled={isLoading}
              className="flex-1 px-4 py-2.5 rounded-xl bg-[#17212C] border border-[#283544] text-xs sm:text-sm text-white placeholder-[#738297] focus:outline-none focus:border-[#66E3CB]"
            />
            <button
              type="submit"
              disabled={isLoading || !promptText.trim()}
              className="px-4 py-2.5 rounded-xl bg-[#66E3CB] hover:bg-[#52cfb7] disabled:opacity-50 text-[#0B0F14] font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isLoading ? 'Synthesizing...' : 'Transmit'}</span>
            </button>
          </form>
        </footer>
      </motion.div>
    </AnimatePresence>
  );
};
