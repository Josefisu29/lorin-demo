/**
 * Server-side Firebase ID token verification, centralized role resolution (6-level hierarchy),
 * account status & session revocation enforcement, and System Owner invariant protection.
 * Never trust client-supplied role/email/authenticated flags for authorization.
 */
import { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import fs from 'fs';
import os from 'os';
import path from 'path';
import firebaseConfig from './firebase-applet-config.json';
import {
  AccountStatus,
  ALL_CANONICAL_PERMISSIONS,
  CanonicalPermissionScope,
  CanonicalRole,
  getDefaultPermissionsForRole,
  LorinPermission,
  ManagedUserAccount,
  normalizeCanonicalRole,
  normalizePermissionScope,
  SUPER_ADMIN_PERMISSIONS,
  UserRole
} from './src/types/lorin';

// This module is evaluated before server.ts body code, so load the server environment here
// before resolving owner identity or Firebase configuration.
dotenv.config({ path: path.resolve(process.cwd(), '.env') });
dotenv.config({ path: path.resolve(process.cwd(), 'backend', '.env') });

export interface VerifiedPrincipal {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  canonicalRole: CanonicalRole;
  accountStatus: AccountStatus;
  authenticated: true;
  emailVerified: boolean;
  mfaEnabled?: boolean;
  roleVersion?: number;
  scopes: string[];
  permissions: CanonicalPermissionScope[];
  delegatedPermissions: CanonicalPermissionScope[];
  projectScopes: string[];
  enrolledAt: number;
  sessionExpiresAt: number;
  sessionRevokedAt?: number;
}

declare global {
  namespace Express {
    interface Request {
      principal?: VerifiedPrincipal;
      verifiedPrincipal?: VerifiedPrincipal;
      rawIdToken?: string;
    }
  }
}

const FIREBASE_API_KEY = process.env.VITE_FIREBASE_API_KEY || firebaseConfig.apiKey;
const FIREBASE_PROJECT_ID = process.env.FIREBASE_PROJECT_ID || process.env.VITE_FIREBASE_PROJECT_ID || firebaseConfig.projectId;
const tokenCache = new Map<string, { principal: VerifiedPrincipal; verifiedAt: number; expiresAt: number }>();
const CACHE_TTL_MS = 60_000;

const PRIMARY_OWNER = (process.env.OWNER_EMAIL || '').trim().toLowerCase();
const PRIMARY_OWNER_UID = (process.env.OWNER_UID || '').trim();
const ENV_OWNER_EMAIL = PRIMARY_OWNER;

function resolveWritableFilePath(fileName: string): string {
  const localPath = path.join(process.cwd(), fileName);
  if (process.env.VERCEL) {
    return path.join(os.tmpdir(), fileName);
  }
  return localPath;
}

const ALLOWED_OWNERS_FILE = resolveWritableFilePath('allowed_owners.json');
const FALLBACK_OWNERS_FILE = path.join(process.cwd(), 'allowed_owners.json');
const RBAC_USERS_FILE = resolveWritableFilePath('server_rbac_users.json');
const FALLBACK_RBAC_USERS_FILE = path.join(process.cwd(), 'server_rbac_users.json');

function loadAllowedOwners(): Set<string> {
  const set = new Set<string>(PRIMARY_OWNER ? [PRIMARY_OWNER] : []);
  if (ENV_OWNER_EMAIL && ENV_OWNER_EMAIL.includes('@')) {
    set.add(ENV_OWNER_EMAIL);
  }
  try {
    const fileToRead = fs.existsSync(ALLOWED_OWNERS_FILE)
      ? ALLOWED_OWNERS_FILE
      : (fs.existsSync(FALLBACK_OWNERS_FILE) ? FALLBACK_OWNERS_FILE : null);
    if (fileToRead) {
      const data = JSON.parse(fs.readFileSync(fileToRead, 'utf-8'));
      if (Array.isArray(data)) {
        data.forEach(e => {
          if (typeof e === 'string' && e.includes('@')) {
            set.add(e.trim().toLowerCase());
          }
        });
      }
    }
  } catch {
    // Default fallback
  }
  return set;
}

const allowedOwnerEmailsSet = loadAllowedOwners();

const managedAccountsByUid = new Map<string, ManagedUserAccount>();
const managedAccountsByEmail = new Map<string, ManagedUserAccount>();

function mapCanonicalToLegacyRole(canonicalRole: CanonicalRole, status: AccountStatus): UserRole {
  if (status === 'DISABLED' || status === 'REVOKED') return 'DISABLED';
  switch (canonicalRole) {
    case 'SYSTEM_OWNER':
      return 'OWNER';
    case 'SUPER_ADMIN':
      return 'SUPER_ADMIN';
    case 'ADMINISTRATOR':
      return 'ADMINISTRATOR';
    case 'SPECIALIST':
      return 'ENGINEER';
    case 'STANDARD_USER':
      return 'STANDARD_USER';
    case 'RESTRICTED':
    default:
      return 'GUEST';
  }
}

function indexAccount(acc: ManagedUserAccount): void {
  managedAccountsByUid.set(acc.uid, acc);
  if (acc.email) {
    managedAccountsByEmail.set(acc.email.trim().toLowerCase(), acc);
  }
}

function persistManagedAccounts(): void {
  try {
    const list = Array.from(managedAccountsByUid.values());
    fs.writeFileSync(RBAC_USERS_FILE, JSON.stringify(list, null, 2), 'utf-8');
  } catch {
    // In-memory store remains authoritative in read-only serverless environments
  }
}

function loadManagedAccounts(): void {
  managedAccountsByUid.clear();
  managedAccountsByEmail.clear();
  try {
    const fileToRead = fs.existsSync(RBAC_USERS_FILE)
      ? RBAC_USERS_FILE
      : (fs.existsSync(FALLBACK_RBAC_USERS_FILE) ? FALLBACK_RBAC_USERS_FILE : null);
    if (fileToRead) {
      const parsed = JSON.parse(fs.readFileSync(fileToRead, 'utf-8'));
      if (Array.isArray(parsed) && parsed.length > 0) {
        parsed.forEach((acc: ManagedUserAccount) => {
          const email = typeof acc.email === 'string' ? acc.email.trim().toLowerCase() : '';
          if (!email || email.endsWith('.internal')) return;
          if (acc.canonicalRole === 'SYSTEM_OWNER' && !allowedOwnerEmailsSet.has(email)) return;
          indexAccount(acc);
        });
      }
    }
  } catch {
    // Start with no managed accounts; verified users receive the least-privilege default.
  }
  persistManagedAccounts();
}

loadManagedAccounts();

export type AuthenticatedRequest = Request;

export function getOwnerEmail(): string {
  return PRIMARY_OWNER;
}

export function getOwnerEmails(): string[] {
  return Array.from(allowedOwnerEmailsSet);
}

export const getAuthorizedOwnerEmails = getOwnerEmails;

export function getAllManagedAccounts(): ManagedUserAccount[] {
  return Array.from(managedAccountsByUid.values()).sort((a, b) => {
    const levelDiff =
      ['SYSTEM_OWNER', 'SUPER_ADMIN', 'ADMINISTRATOR', 'SPECIALIST', 'STANDARD_USER', 'RESTRICTED'].indexOf(a.canonicalRole) -
      ['SYSTEM_OWNER', 'SUPER_ADMIN', 'ADMINISTRATOR', 'SPECIALIST', 'STANDARD_USER', 'RESTRICTED'].indexOf(b.canonicalRole);
    return levelDiff !== 0 ? levelDiff : b.updatedAt - a.updatedAt;
  });
}

export function getManagedAccountByUidOrEmail(uid?: string, email?: string): ManagedUserAccount | undefined {
  if (uid) {
    if (managedAccountsByUid.has(uid)) {
      return managedAccountsByUid.get(uid);
    }
  }
  if (email) {
    return managedAccountsByEmail.get(email.trim().toLowerCase());
  }
  return undefined;
}

export function countActiveSystemOwners(): number {
  return Array.from(managedAccountsByUid.values()).filter(
    acc => acc.canonicalRole === 'SYSTEM_OWNER' && acc.accountStatus === 'ACTIVE'
  ).length;
}

export function addOwnerEmail(email: string): { success: boolean; message: string; emails: string[] } {
  if (!email || typeof email !== 'string' || !email.includes('@')) {
    return { success: false, message: 'Invalid email address format.', emails: getOwnerEmails() };
  }
  const normalized = email.trim().toLowerCase();
  allowedOwnerEmailsSet.add(normalized);
  try {
    fs.writeFileSync(ALLOWED_OWNERS_FILE, JSON.stringify(Array.from(allowedOwnerEmailsSet), null, 2));
  } catch (err) {
    console.error('Failed to persist allowed_owners.json:', err);
  }

  // Also synchronize into RBAC managed accounts registry
  const existing = managedAccountsByEmail.get(normalized);
  if (existing) {
    existing.canonicalRole = 'SYSTEM_OWNER';
    existing.legacyRole = 'OWNER';
    existing.accountStatus = 'ACTIVE';
    existing.permissions = [...ALL_CANONICAL_PERMISSIONS];
    existing.updatedAt = Date.now();
    indexAccount(existing);
  }
  // If the person has not authenticated yet, keep only the email allowlist
  // entry. Their managed account is created later from the real Firebase UID;
  // never invent a synthetic UID that could be mistaken for an identity.
  persistManagedAccounts();

  return { success: true, message: `Added ${normalized} to authorized owner emails.`, emails: getOwnerEmails() };
}

export const addAuthorizedOwnerEmail = addOwnerEmail;

export function removeOwnerEmail(email: string, _actorEmail?: string): { success: boolean; message: string; emails: string[] } {
  if (!email || typeof email !== 'string') {
    return { success: false, message: 'Invalid email address.', emails: getOwnerEmails() };
  }
  const normalized = email.trim().toLowerCase();
  if (normalized === PRIMARY_OWNER) {
    return { success: false, message: 'Primary System Owner email cannot be removed.', emails: getOwnerEmails() };
  }
  if (allowedOwnerEmailsSet.size <= 1) {
    return { success: false, message: 'Cannot remove the last remaining System Owner.', emails: getOwnerEmails() };
  }
  const removed = allowedOwnerEmailsSet.delete(normalized);
  if (removed) {
    try {
      fs.writeFileSync(ALLOWED_OWNERS_FILE, JSON.stringify(Array.from(allowedOwnerEmailsSet), null, 2));
    } catch (err) {
      console.error('Failed to persist allowed_owners.json:', err);
    }
    const existing = managedAccountsByEmail.get(normalized);
    if (existing && existing.canonicalRole === 'SYSTEM_OWNER') {
      existing.canonicalRole = 'SPECIALIST';
      existing.legacyRole = 'ENGINEER';
      existing.permissions = getDefaultPermissionsForRole('SPECIALIST', [], existing.accountStatus);
      existing.updatedAt = Date.now();
      indexAccount(existing);
      persistManagedAccounts();
    }
  }
  return {
    success: removed,
    message: removed ? `Removed ${normalized} from authorized owner emails.` : 'Email was not found in owner list.',
    emails: getOwnerEmails()
  };
}

export const removeAuthorizedOwnerEmail = removeOwnerEmail;

export function isVerifiedOwner(email: string | undefined | null, emailVerified = false, uid?: string): boolean {
  if (!email || !emailVerified) return false;
  const normalizedEmail = email.trim().toLowerCase();
  if (!allowedOwnerEmailsSet.has(normalizedEmail)) return false;
  // When the primary Firebase UID is configured, bind the primary owner email
  // to that exact Firebase identity. Callers without a UID use this only for
  // non-authenticating registration-eligibility display, never role assignment.
  if (normalizedEmail === PRIMARY_OWNER && PRIMARY_OWNER_UID && uid && uid !== PRIMARY_OWNER_UID) return false;
  if (normalizedEmail === PRIMARY_OWNER && PRIMARY_OWNER_UID && uid === '') return false;
  return true;
}

/**
 * Controlled System Owner / Super Admin Role & Account Management Operations
 * Enforces all Section 3, 4, and 5 invariants on the backend.
 */
export function inviteOrCreateManagedAccount(
  actor: { id: string; email: string; canonicalRole: CanonicalRole },
  params: {
    email: string;
    displayName?: string;
    role: CanonicalRole;
    delegatedPermissions?: CanonicalPermissionScope[];
    projectScopes?: string[];
  }
): { success: boolean; message: string; account?: ManagedUserAccount } {
  const email = (params.email || '').trim().toLowerCase();
  if (!email || !email.includes('@')) {
    return { success: false, message: 'A valid email address is required.' };
  }

  // Only SYSTEM_OWNER or SUPER_ADMIN can create/invite accounts
  if (actor.canonicalRole !== 'SYSTEM_OWNER' && actor.canonicalRole !== 'SUPER_ADMIN') {
    return { success: false, message: 'Forbidden: Only System Owner or Super Admin can provision accounts.' };
  }

  // SUPER_ADMIN cannot create or promote a SYSTEM_OWNER or SUPER_ADMIN
  if ((params.role === 'SYSTEM_OWNER' || params.role === 'SUPER_ADMIN') && actor.canonicalRole !== 'SYSTEM_OWNER') {
    return {
      success: false,
      message:
        params.role === 'SYSTEM_OWNER'
          ? 'Security Invariant Violation: Super Admin cannot assign or promote any account to SYSTEM_OWNER.'
          : 'Security Invariant Violation: Only System Owner can appoint or invite a SUPER_ADMIN account.'
    };
  }

  const targetRole = normalizeCanonicalRole(params.role, 'ACTIVE');
  const delegated = (params.delegatedPermissions || []).filter(p => p !== 'system.owner.manage');
  const permissions = getDefaultPermissionsForRole(targetRole, delegated, 'ACTIVE');

  const existing = managedAccountsByEmail.get(email);
  if (existing) {
    if ((existing.canonicalRole === 'SYSTEM_OWNER' || existing.canonicalRole === 'SUPER_ADMIN') && actor.canonicalRole !== 'SYSTEM_OWNER') {
      return {
        success: false,
        message:
          existing.canonicalRole === 'SYSTEM_OWNER'
            ? 'Security Invariant Violation: Super Admin cannot modify an existing SYSTEM_OWNER account.'
            : 'Security Invariant Violation: Only System Owner can modify an existing SUPER_ADMIN account.'
      };
    }
    existing.displayName = params.displayName?.trim() || existing.displayName;
    existing.canonicalRole = targetRole;
    existing.legacyRole = mapCanonicalToLegacyRole(targetRole, 'ACTIVE');
    existing.accountStatus = 'ACTIVE';
    existing.roleVersion = (existing.roleVersion || 1) + 1;
    existing.delegatedPermissions = delegated;
    existing.permissions = permissions;
    existing.projectScopes = params.projectScopes || existing.projectScopes;
    existing.updatedAt = Date.now();
    indexAccount(existing);
    if (targetRole === 'SYSTEM_OWNER') {
      allowedOwnerEmailsSet.add(email);
    }
    persistManagedAccounts();
    return { success: true, message: `Updated existing account ${email} to ${targetRole}.`, account: existing };
  }

  const newAccount: ManagedUserAccount = {
    uid: `usr_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`,
    email,
    displayName: params.displayName?.trim() || email.split('@')[0] || 'LORIN User',
    canonicalRole: targetRole,
    legacyRole: mapCanonicalToLegacyRole(targetRole, 'ACTIVE'),
    accountStatus: 'ACTIVE',
    emailVerified: true,
    permissions,
    delegatedPermissions: delegated,
    projectScopes: params.projectScopes && params.projectScopes.length > 0 ? params.projectScopes : ['proj_lorin_core'],
    isPrimarySystemOwner: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    invitedBy: actor.email
  };

  indexAccount(newAccount);
  if (targetRole === 'SYSTEM_OWNER') {
    allowedOwnerEmailsSet.add(email);
  }
  persistManagedAccounts();
  return { success: true, message: `Account ${email} provisioned with role ${targetRole}.`, account: newAccount };
}

export function updateManagedAccountRole(
  actor: { id: string; email: string; canonicalRole: CanonicalRole },
  targetUid: string,
  newRoleInput: string,
  delegatedPermissions?: CanonicalPermissionScope[],
  projectScopes?: string[]
): { success: boolean; message: string; account?: ManagedUserAccount } {
  if (actor.canonicalRole !== 'SYSTEM_OWNER' && actor.canonicalRole !== 'SUPER_ADMIN') {
    return { success: false, message: 'Forbidden: Only System Owner or Super Admin can modify roles.' };
  }

  const target = managedAccountsByUid.get(targetUid) || managedAccountsByEmail.get(targetUid.toLowerCase());
  if (!target) {
    return { success: false, message: 'Target user account not found.' };
  }

  const desiredRole = normalizeCanonicalRole(newRoleInput, target.accountStatus === 'DISABLED' ? 'ACTIVE' : target.accountStatus);

  // Invariant 1: SUPER_ADMIN cannot promote self or anyone else to SYSTEM_OWNER or SUPER_ADMIN
  if ((desiredRole === 'SYSTEM_OWNER' || desiredRole === 'SUPER_ADMIN') && actor.canonicalRole !== 'SYSTEM_OWNER') {
    return {
      success: false,
      message:
        desiredRole === 'SYSTEM_OWNER'
          ? 'Security Invariant Violation: Super Admin cannot promote itself or any user to SYSTEM_OWNER.'
          : 'Security Invariant Violation: Only System Owner can appoint or promote a user to SUPER_ADMIN.'
    };
  }

  // Invariant 2: SUPER_ADMIN cannot demote or alter a SYSTEM_OWNER or SUPER_ADMIN account
  if ((target.canonicalRole === 'SYSTEM_OWNER' || target.canonicalRole === 'SUPER_ADMIN') && actor.canonicalRole !== 'SYSTEM_OWNER') {
    return {
      success: false,
      message:
        target.canonicalRole === 'SYSTEM_OWNER'
          ? 'Security Invariant Violation: Super Admin cannot demote or modify a SYSTEM_OWNER account.'
          : 'Security Invariant Violation: Only System Owner can revoke or modify a SUPER_ADMIN account.'
    };
  }

  // Invariant 3: Primary System Owner email cannot be demoted
  if (target.email.toLowerCase() === PRIMARY_OWNER && desiredRole !== 'SYSTEM_OWNER') {
    return {
      success: false,
      message: 'Security Invariant Violation: Primary System Owner account cannot be demoted.'
    };
  }

  // Invariant 4: Cannot remove/demote the last active SYSTEM_OWNER
  if (target.canonicalRole === 'SYSTEM_OWNER' && desiredRole !== 'SYSTEM_OWNER' && countActiveSystemOwners() <= 1) {
    return {
      success: false,
      message: 'Security Invariant Violation: Cannot demote the last active SYSTEM_OWNER.'
    };
  }

  const cleanDelegated = (delegatedPermissions ?? target.delegatedPermissions).filter(p => p !== 'system.owner.manage');
  target.canonicalRole = desiredRole;
  target.legacyRole = mapCanonicalToLegacyRole(desiredRole, target.accountStatus);
  target.roleVersion = (target.roleVersion || 1) + 1;
  target.delegatedPermissions = cleanDelegated;
  target.permissions = getDefaultPermissionsForRole(desiredRole, cleanDelegated, target.accountStatus);
  if (projectScopes) {
    target.projectScopes = projectScopes;
  }
  target.updatedAt = Date.now();

  if (desiredRole === 'SYSTEM_OWNER') {
    allowedOwnerEmailsSet.add(target.email.toLowerCase());
  } else if (target.email.toLowerCase() !== PRIMARY_OWNER) {
    allowedOwnerEmailsSet.delete(target.email.toLowerCase());
  }

  // Invalidate token cache for target user so role change takes immediate effect
  for (const [tok, entry] of tokenCache.entries()) {
    if (entry.principal.id === target.uid || entry.principal.email.toLowerCase() === target.email.toLowerCase()) {
      tokenCache.delete(tok);
    }
  }

  indexAccount(target);
  persistManagedAccounts();
  return {
    success: true,
    message: `Updated ${target.email} role to ${desiredRole}.`,
    account: target
  };
}

export function updateManagedAccountStatus(
  actor: { id: string; email: string; canonicalRole: CanonicalRole },
  targetUid: string,
  newStatus: AccountStatus
): { success: boolean; message: string; account?: ManagedUserAccount } {
  if (actor.canonicalRole !== 'SYSTEM_OWNER' && actor.canonicalRole !== 'SUPER_ADMIN') {
    return { success: false, message: 'Forbidden: Only System Owner or Super Admin can change account status.' };
  }

  const target = managedAccountsByUid.get(targetUid) || managedAccountsByEmail.get(targetUid.toLowerCase());
  if (!target) {
    return { success: false, message: 'Target user account not found.' };
  }

  if ((target.canonicalRole === 'SYSTEM_OWNER' || target.canonicalRole === 'SUPER_ADMIN') && actor.canonicalRole !== 'SYSTEM_OWNER') {
    return {
      success: false,
      message:
        target.canonicalRole === 'SYSTEM_OWNER'
          ? 'Security Invariant Violation: Super Admin cannot disable or restrict a SYSTEM_OWNER account.'
          : 'Security Invariant Violation: Only System Owner can disable or revoke a SUPER_ADMIN account.'
    };
  }

  if (target.email.toLowerCase() === PRIMARY_OWNER && newStatus !== 'ACTIVE') {
    return {
      success: false,
      message: 'Security Invariant Violation: Primary System Owner account cannot be disabled or revoked.'
    };
  }

  if (target.canonicalRole === 'SYSTEM_OWNER' && newStatus !== 'ACTIVE' && countActiveSystemOwners() <= 1) {
    return {
      success: false,
      message: 'Security Invariant Violation: Cannot disable or revoke the last active SYSTEM_OWNER.'
    };
  }

  target.accountStatus = newStatus;
  target.legacyRole = mapCanonicalToLegacyRole(target.canonicalRole, newStatus);
  target.roleVersion = (target.roleVersion || 1) + 1;
  target.permissions = getDefaultPermissionsForRole(target.canonicalRole, target.delegatedPermissions, newStatus);
  if (newStatus === 'DISABLED' || newStatus === 'REVOKED') {
    target.sessionRevokedAt = Date.now();
  }
  target.updatedAt = Date.now();

  // Evict cached tokens for target account
  for (const [tok, entry] of tokenCache.entries()) {
    if (entry.principal.id === target.uid || entry.principal.email.toLowerCase() === target.email.toLowerCase()) {
      tokenCache.delete(tok);
    }
  }

  indexAccount(target);
  persistManagedAccounts();
  return {
    success: true,
    message: `Account ${target.email} status updated to ${newStatus}.`,
    account: target
  };
}

export function revokeManagedAccountSessions(
  actor: { id: string; email: string; canonicalRole: CanonicalRole },
  targetUid: string
): { success: boolean; message: string; revokedAt?: number; account?: ManagedUserAccount } {
  if (actor.canonicalRole !== 'SYSTEM_OWNER' && actor.canonicalRole !== 'SUPER_ADMIN') {
    return { success: false, message: 'Forbidden: Only System Owner or Super Admin can revoke user sessions.' };
  }

  const target = managedAccountsByUid.get(targetUid) || managedAccountsByEmail.get(targetUid.toLowerCase());
  if (!target) {
    return { success: false, message: 'Target user account not found.' };
  }

  if ((target.canonicalRole === 'SYSTEM_OWNER' || target.canonicalRole === 'SUPER_ADMIN') && actor.canonicalRole !== 'SYSTEM_OWNER') {
    return {
      success: false,
      message:
        target.canonicalRole === 'SYSTEM_OWNER'
          ? 'Security Invariant Violation: Super Admin cannot revoke SYSTEM_OWNER sessions.'
          : 'Security Invariant Violation: Only System Owner can revoke SUPER_ADMIN sessions.'
    };
  }

  const revokedAt = Date.now();
  target.sessionRevokedAt = revokedAt;
  target.updatedAt = revokedAt;

  for (const [tok, entry] of tokenCache.entries()) {
    if (entry.principal.id === target.uid || entry.principal.email.toLowerCase() === target.email.toLowerCase()) {
      tokenCache.delete(tok);
    }
  }

  indexAccount(target);
  persistManagedAccounts();
  return {
    success: true,
    message: `Revoked active sessions for ${target.email}.`,
    revokedAt,
    account: target
  };
}

export function buildPrincipal(
  uid: string,
  email: string,
  emailVerified: boolean,
  displayName?: string
): VerifiedPrincipal {
  const normalizedEmail = (email || '').trim().toLowerCase();
  const isOwnerByEmail = isVerifiedOwner(normalizedEmail, emailVerified, uid);
  let managed = getManagedAccountByUidOrEmail(uid, normalizedEmail);

  if (!managed) {
    // Unknown verified accounts enter with ordinary-user privileges and no project grants.
    const initialCanonical: CanonicalRole = isOwnerByEmail ? 'SYSTEM_OWNER' : 'STANDARD_USER';
    managed = {
      uid,
      email: normalizedEmail,
      displayName: displayName || (isOwnerByEmail ? 'System Owner' : normalizedEmail.split('@')[0] || 'User'),
      canonicalRole: initialCanonical,
      legacyRole: isOwnerByEmail ? 'OWNER' : 'STANDARD_USER',
      accountStatus: 'ACTIVE',
      emailVerified,
      permissions: getDefaultPermissionsForRole(initialCanonical, [], 'ACTIVE'),
      delegatedPermissions: [],
      projectScopes: isOwnerByEmail ? ['*'] : [],
      isPrimarySystemOwner: normalizedEmail === PRIMARY_OWNER,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      lastActiveAt: Date.now()
    };
    indexAccount(managed);
    persistManagedAccounts();
  } else {
    // Reconcile if this email is in the verified owner list
    if (isOwnerByEmail && managed.accountStatus === 'ACTIVE' && managed.canonicalRole !== 'SYSTEM_OWNER') {
      managed.canonicalRole = 'SYSTEM_OWNER';
      managed.legacyRole = 'OWNER';
      managed.permissions = [...ALL_CANONICAL_PERMISSIONS];
    }
    managed.lastActiveAt = Date.now();
    indexAccount(managed);
  }

  // An owner registry entry is not enough on its own: the current Firebase
  // identity must also report a verified email before SYSTEM_OWNER is surfaced.
  const effectiveCanonical =
    managed.canonicalRole === 'SYSTEM_OWNER' && !emailVerified
      ? 'RESTRICTED'
      : normalizeCanonicalRole(managed.canonicalRole, managed.accountStatus);
  const effectivePermissions = getDefaultPermissionsForRole(
    effectiveCanonical,
    managed.delegatedPermissions,
    managed.accountStatus
  );

  const legacyScopes =
    effectiveCanonical === 'SYSTEM_OWNER' || effectiveCanonical === 'SUPER_ADMIN'
      ? ['*']
      : effectiveCanonical === 'ADMINISTRATOR'
      ? ['admin:delegated', 'code:read', 'chat:write', 'vault:read', ...effectivePermissions]
      : effectiveCanonical === 'SPECIALIST'
      ? ['code:read', 'chat:write', 'vault:read', ...effectivePermissions]
      : effectiveCanonical === 'STANDARD_USER'
      ? ['chat:write', 'vault:read', ...effectivePermissions]
      : ['read:public'];

  return {
    id: uid,
    name: displayName || managed.displayName || (isOwnerByEmail ? 'Owner' : normalizedEmail.split('@')[0] || 'User'),
    email: normalizedEmail,
    role: mapCanonicalToLegacyRole(effectiveCanonical, managed.accountStatus),
    canonicalRole: effectiveCanonical,
    accountStatus: managed.accountStatus,
    authenticated: true,
    emailVerified,
    scopes: legacyScopes,
    permissions: effectivePermissions,
    delegatedPermissions: managed.delegatedPermissions || [],
    projectScopes: managed.projectScopes || [],
    enrolledAt: managed.createdAt || Date.now(),
    sessionExpiresAt: Date.now() + 3_600_000,
    sessionRevokedAt: managed.sessionRevokedAt
  };
}

/**
 * Verify a Firebase ID token through Identity Toolkit accounts:lookup.
 * Application-minted HMAC/session tokens are deliberately not accepted.
 * Returns null when the token is missing, expired, or invalid.
 */
export async function verifyFirebaseIdToken(idToken: string): Promise<VerifiedPrincipal | null> {
  if (!idToken || typeof idToken !== 'string' || idToken.length < 20) {
    return null;
  }

  const cached = tokenCache.get(idToken);
  if (cached && cached.expiresAt > Date.now()) {
    const managed = getManagedAccountByUidOrEmail(cached.principal.id, cached.principal.email);
    if (managed) {
      if (managed.accountStatus === 'DISABLED' || managed.accountStatus === 'REVOKED') {
        tokenCache.delete(idToken);
        return null;
      }
      if (managed.sessionRevokedAt && managed.sessionRevokedAt > cached.verifiedAt) {
        tokenCache.delete(idToken);
        return null;
      }
    }
    const latestPrincipal = buildPrincipal(
      cached.principal.id,
      cached.principal.email,
      cached.principal.emailVerified,
      cached.principal.name
    );
    tokenCache.set(idToken, { ...cached, principal: latestPrincipal });
    return latestPrincipal;
  }

  try {
    const res = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${FIREBASE_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken })
      }
    );

    if (!res.ok) {
      return null;
    }

    const data = await res.json() as {
      users?: Array<{
        localId: string;
        email?: string;
        emailVerified?: boolean;
        displayName?: string;
        disabled?: boolean;
      }>;
    };

    const user = data.users?.[0];
    if (!user?.localId || user.disabled === true) {
      return null;
    }

    // Managed records are bound to a Firebase UID. Do not fall back to a
    // same-email record belonging to another UID, especially for privileged
    // identities; account recreation requires an explicit recovery/transfer.
    const emailBoundAccount = user.email
      ? getManagedAccountByUidOrEmail(undefined, user.email)
      : undefined;
    if (emailBoundAccount && emailBoundAccount.uid !== user.localId) {
      return null;
    }

    const principal = buildPrincipal(
      user.localId,
      user.email || '',
      user.emailVerified === true,
      user.displayName
    );

    if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') {
      return null;
    }

    const now = Date.now();
    tokenCache.set(idToken, { principal, verifiedAt: now, expiresAt: now + CACHE_TTL_MS });

    if (tokenCache.size > 500) {
      const oldest = tokenCache.keys().next().value;
      if (oldest) tokenCache.delete(oldest);
    }

    return principal;
  } catch {
    return null;
  }
}

export function extractBearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (header && typeof header === 'string' && header.toLowerCase().startsWith('bearer ')) {
    return header.slice(7).trim();
  }
  const alt = req.headers['x-firebase-id-token'];
  if (typeof alt === 'string' && alt.length > 20) {
    return alt.trim();
  }
  return null;
}

/**
 * Requires a valid Firebase ID token and an ACTIVE (non-disabled, non-revoked) account.
 */
export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const token = extractBearerToken(req);
  if (!token) {
    res.status(401).json({
      error: 'Authentication required. Provide a Firebase ID token via Authorization: Bearer <token>.'
    });
    return;
  }

  const principal = await verifyFirebaseIdToken(token);
  if (!principal) {
    res.status(401).json({ error: 'Invalid, expired, or revoked authentication token.' });
    return;
  }

  if (principal.accountStatus === 'DISABLED' || principal.accountStatus === 'REVOKED') {
    res.status(403).json({
      error: 'Forbidden: Your account has been disabled or your session was revoked by an administrator.'
    });
    return;
  }

  req.principal = principal;
  req.verifiedPrincipal = principal;
  req.rawIdToken = token;
  next();
}

/**
 * Requires verified SYSTEM_OWNER (Level 1).
 */
export async function requireOwner(req: Request, res: Response, next: NextFunction): Promise<void> {
  await requireAuth(req, res, () => {
    const principal = req.verifiedPrincipal;
    if (
      !principal ||
      principal.canonicalRole !== 'SYSTEM_OWNER' ||
      !isVerifiedOwner(principal.email, principal.emailVerified, principal.id)
    ) {
      res.status(403).json({
        error: 'Forbidden: verified System Owner authentication required for this operation.'
      });
      return;
    }
    next();
  });
}

/**
 * Requires verified SYSTEM_OWNER (Level 1) or SUPER_ADMIN (Level 2).
 */
export async function requireSuperAdminOrOwner(req: Request, res: Response, next: NextFunction): Promise<void> {
  await requireAuth(req, res, () => {
    const principal = req.verifiedPrincipal;
    if (
      !principal ||
      (principal.canonicalRole !== 'SYSTEM_OWNER' && principal.canonicalRole !== 'SUPER_ADMIN')
    ) {
      res.status(403).json({
        error: 'Forbidden: System Owner or Super Admin authorization required.'
      });
      return;
    }
    next();
  });
}

/**
 * Requires a specific canonical permission scope evaluated against the principal's authoritative permissions.
 */
export function requirePermission(requiredScopeInput: CanonicalPermissionScope | LorinPermission) {
  const requiredScope = normalizePermissionScope(requiredScopeInput);
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    await requireAuth(req, res, () => {
      const principal = req.verifiedPrincipal;
      if (!principal) {
        res.status(401).json({ error: 'Authentication required.' });
        return;
      }
      if (principal.canonicalRole === 'SYSTEM_OWNER') {
        next();
        return;
      }
      if (principal.canonicalRole === 'SUPER_ADMIN' && requiredScope !== 'system.owner.manage') {
        next();
        return;
      }
      if (principal.permissions && principal.permissions.includes(requiredScope)) {
        next();
        return;
      }
      res.status(403).json({
        error: `Forbidden: Missing required permission '${requiredScopeInput}' for role '${principal.canonicalRole}'.`
      });
    });
  };
}

/**
 * Section 10: Controlled One-Time System Owner Bootstrap.
 * Verifies whether a SYSTEM_OWNER already exists, refuses to replace or duplicate an existing owner,
 * and safely initializes the designated primary System Owner.
 */
export function bootstrapOneTimeSystemOwner(params: {
  uid: string;
  email: string;
  displayName?: string;
}): {
  success: boolean;
  message: string;
  account?: ManagedUserAccount;
  alreadyBootstrapped?: boolean;
} {
  const normalizedEmail = (params.email || '').trim().toLowerCase();
  const normalizedUid = (params.uid || '').trim();
  if (!normalizedEmail || !normalizedEmail.includes('@')) {
    return { success: false, message: 'A valid owner email address is required for bootstrap.' };
  }
  if (!normalizedUid || normalizedUid.length > 128 || /\s/.test(normalizedUid)) {
    return { success: false, message: 'The real Firebase Authentication UID is required for owner bootstrap.' };
  }

  const existingOwners = getAllManagedAccounts().filter(
    a => a.canonicalRole === 'SYSTEM_OWNER' && a.accountStatus === 'ACTIVE'
  );

  // If an active SYSTEM_OWNER already exists with a different email, refuse replacement/duplication via bootstrap
  const existingMatching = existingOwners.find(a => a.email.toLowerCase() === normalizedEmail);
  if (existingOwners.length > 0 && !existingMatching) {
    return {
      success: false,
      alreadyBootstrapped: true,
      message: `Bootstrap refused: An active SYSTEM_OWNER already exists (${existingOwners[0].email}). Use controlled owner transfer instead.`
    };
  }

  if (existingMatching) {
    if (existingMatching.uid !== normalizedUid) {
      return {
        success: false,
        alreadyBootstrapped: true,
        message: 'Bootstrap refused: the verified email is already bound to a different Firebase UID. Use the controlled owner recovery/transfer procedure.'
      };
    }
    return {
      success: true,
      alreadyBootstrapped: true,
      account: existingMatching,
      message: `System Owner ${normalizedEmail} is already bootstrapped and active.`
    };
  }

  const ownerAccount: ManagedUserAccount = {
    uid: normalizedUid,
    email: normalizedEmail,
    displayName: params.displayName?.trim() || 'Primary System Owner',
    canonicalRole: 'SYSTEM_OWNER',
    legacyRole: 'OWNER',
    accountStatus: 'ACTIVE',
    emailVerified: true,
    roleVersion: 1,
    permissions: [...ALL_CANONICAL_PERMISSIONS],
    delegatedPermissions: [],
    projectScopes: ['*'],
    isPrimarySystemOwner: true,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    lastActiveAt: Date.now(),
    invitedBy: 'system-bootstrap'
  };

  allowedOwnerEmailsSet.add(normalizedEmail);
  indexAccount(ownerAccount);
  persistManagedAccounts();

  return {
    success: true,
    alreadyBootstrapped: false,
    account: ownerAccount,
    message: `Primary System Owner (${normalizedEmail}) bootstrapped successfully.`
  };
}

export function publicHealthPayload(geminiConfigured: boolean, extras?: Record<string, unknown>) {
  return {
    status: 'ok',
    // Credential presence is not proof of upstream model connectivity. This
    // endpoint verifies only that the API server is responding.
    liveGeminiAvailable: false,
    providerConnectivityVerified: false,
    geminiConfigured,
    databaseConfigured: true,
    serverTime: new Date().toISOString(),
    policyEngineActive: true,
    rbacHierarchyActive: true,
    firebaseProjectConfigured: Boolean(FIREBASE_PROJECT_ID),
    // Intentionally omit owner email / private identity details
    ...extras
  };
}
