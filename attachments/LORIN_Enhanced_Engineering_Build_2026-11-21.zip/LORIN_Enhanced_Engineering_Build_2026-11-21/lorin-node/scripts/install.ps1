# LORIN Primary Node — Windows Installation & Optional Tailscale Serve Setup
# Never installs privileged OS services silently; requires explicit Owner flags.
param(
  [switch]$ConfigureTailscaleServe = $false,
  [switch]$RegisterStartupShortcut = $false
)

$ErrorActionPreference = "Stop"
$Port = if ($env:LORIN_NODE_PORT) { $env:LORIN_NODE_PORT } else { 4310 }

Write-Host "=== LORIN Primary Laptop Node Installer ===" -ForegroundColor Cyan
Write-Host "1. Verifying npm dependencies..."
npm install

if (-not (Test-Path "data")) {
  New-Item -ItemType Directory -Path "data" | Out-Null
}

if ($ConfigureTailscaleServe) {
  Write-Host "2. Configuring Tailscale Serve (Private Tailnet HTTPS -> http://127.0.0.1:$Port)..." -ForegroundColor Cyan
  tailscale serve --bg $Port
  tailscale serve status
} else {
  Write-Host "Tip: Run 'tailscale serve --bg $Port' after authenticating Tailscale to enable private HTTPS access." -ForegroundColor Yellow
}

if ($RegisterStartupShortcut) {
  Write-Host "3. Registering user-level login task for LORIN Primary Node..." -ForegroundColor Cyan
  $WorkDir = (Get-Location).Path
  $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$WorkDir\lorin-node\scripts\start.ps1`"" -WorkingDirectory $WorkDir
  $Trigger = New-ScheduledTaskTrigger -AtLogOn
  Register-ScheduledTask -TaskName "LorinPrimaryLaptopNode" -Action $Action -Trigger $Trigger -Description "Starts LORIN Primary Node on user login" -Force | Out-Null
  Write-Host "Registered user-level logon task 'LorinPrimaryLaptopNode'." -ForegroundColor Green
}
