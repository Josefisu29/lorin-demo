# LORIN Primary Node — Windows Start Script
# Binds strictly to loopback (127.0.0.1:4310) for secure Tailscale Serve proxying.

$ErrorActionPreference = "Stop"
$env:LORIN_NODE_BIND_HOST = "127.0.0.1"
if (-not $env:LORIN_NODE_PORT) {
  $env:LORIN_NODE_PORT = "4310"
}

Write-Host "Starting LORIN Primary Laptop Node on http://127.0.0.1:$($env:LORIN_NODE_PORT) ..." -ForegroundColor Cyan
npx tsx lorin-node/src/core/node-runtime.ts
