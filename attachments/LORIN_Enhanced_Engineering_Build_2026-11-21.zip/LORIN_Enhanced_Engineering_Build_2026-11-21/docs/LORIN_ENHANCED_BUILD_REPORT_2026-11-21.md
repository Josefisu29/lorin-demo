# LORIN Enhanced Engineering Build — Report

**Date:** 21 November 2026  
**Build identity:** `LORIN_Enhanced_Engineering_Build_2026-11-21`  
**Parent baseline:** `LORIN_Continued_Reference_Integrated_Working_Build_2026-11-21`  
**Release class:** enhanced source working build; not production-ready.

## Executive summary

A separate enhanced working copy has been produced from the 21 November LORIN baseline. The baseline archive remains unchanged. The existing application was preserved: React 19 / Vite / TypeScript front end, Express server, Firebase identity, Gemini and Ollama integration code, PWA, Babylon.js character renderer, Memory, Knowledge Vault, projects, GIDEON, voice/vision, local-node and MOSAIRA code remain in the repository.

The enhancement adds a typed capability/job core, persistent local job and approval records, action-bound approvals, encrypted payloads, auditable state transitions, privacy-aware route planning and a standalone voice activity detector. It does not replace the existing provider, memory or audio systems; new modules are deliberately small and separately verifiable.

## Added and modified components

### New modules

- `src/core/security/canonical.ts` — canonical JSON serialization and SHA-256 action binding.
- `src/core/capabilities/registry.ts` — server-owned allowlist, closed nested schemas, 64 KiB envelope cap, depth/node/array/property bounds and cooperative cancellation.
- `src/core/security/policy.ts` — verified principal and account state, permissions, resource ownership, local-only constraints, risk-based approvals and critical-risk denial.
- `src/core/persistence/sqliteStore.ts` — transactional SQLite jobs/approvals, AES-256-GCM payload encryption with record-specific associated data, path/symlink checks and tamper-evident hash-chained audit events.
- `src/core/jobs/jobService.ts` — digest-bound job creation/approval, single-use approval dispatch and worker receipts.
- `src/core/routing/modelRouter.ts` — explainable local-first/cloud-permitted candidate scoring with timestamped health evidence.
- `src/core/voice/voiceActivityDetector.ts` — frame-based adaptive VAD with onset hysteresis, speech pre-roll and silence hangover.
- `serverCore.ts` — lazy local core service composition and serverless fail-closed behavior.
- `scripts/core-health.ts` — local diagnostic command.
- `scripts/tests/core-security.test.ts` — focused automated tests.

### Server integration

`server.ts` now exposes authenticated core status, capability listing, owner-scoped job operations, approval, cancellation and an owner/Super Admin run-once worker endpoint. The server binds to loopback by default. Non-loopback binding requires explicit network permission and an operator acknowledgement that HTTPS is terminated by a trusted proxy. The acknowledgement is not itself TLS.

`package.json` now includes `test:core` and `core:health` scripts. `.env.example` documents the local-core storage and network-bind settings.

## Security and reliability properties

1. Model/browser clients cannot register executors in the server-side registry.
2. Capability input schemas close unknown fields at every nested object layer; JSON payloads are size/depth/node-count bounded and dangerous prototype-related property names are rejected.
3. Every durable job carries a canonical action digest over principal, capability, exact resource and parameters. It is rechecked immediately before execution.
4. Approval jobs bind approval ID, owner UID, capability, resource, parameters and digest. Review is owner/Super Admin role-gated, and approval consumption is atomic and single-use before worker execution.
5. Stored payload ciphertext uses AES-256-GCM with associated data containing the owning record identity and metadata; moving valid ciphertext to another row fails authentication.
6. `COMPLETED` does not imply `VERIFIED`. Generic job transitions cannot mark a job verified; an independent trusted postcondition verifier is not yet available.
7. Critical-risk capability execution is denied in this release.
8. Default server bind is loopback. Non-loopback binding is explicit and must be behind a trusted TLS terminator.
9. The local SQLite adapter refuses serverless runtimes rather than treating ephemeral storage as durable.

## What is actually executable now

The startup registry contains only two local read-only built-in capabilities:

- `lorin.system.health.read`
- `lorin.time.read`

The local worker endpoint processes one queued job per request. There is not yet an always-on worker, retry scheduler, event stream, web UI job manager or a library of file/device/OS capabilities. The new model router does not yet replace the app's live Gemini/Ollama dispatch path. The VAD algorithm is not yet connected to `AudioService`, browser microphone capture, transcription or TTS.

The new SQLite store currently backs the new core job/approval path only. It does not claim to migrate all previous Memory, Vault, conversation, project, GIDEON or MOSAIRA stores into one database.

## Verification results in the supplied environment

| Check | Result | Notes |
|---|---|---|
| Core security/behavior tests | **PASS — 9/9** | Canonical digest, schema/input boundaries, policy, route privacy, VAD, encrypted SQLite, approval and audit-chain cases |
| Enhanced static security regression | **PASS — 34/34** | Original 29 assertions preserved; five enhanced-core assertions added |
| TypeScript syntax transpilation | **PASS — 118 files; 0 syntax errors** | Syntax-only, not semantic typechecking |
| Local core health script | **PASS** | Local metadata emitted; database remains lazy/uninitialized until used |
| ZIP integrity | **PASS** | Final archive verified after packaging |
| Full `tsc --noEmit` | **BLOCKED / NOT VERIFIED** | Dependencies are not installed in this runtime |
| Vitest suite | **NOT RUN** | `node_modules` not installed |
| Vite + Express production build | **BLOCKED** | Attempted; Vite executable is unavailable because dependencies are not installed |
| Clean npm dependency install | **BLOCKED** | Supplied environment is Node `22.16.0`, manifest requires `>=24.12.0`; lockfile-only refresh timed out with no lockfile changes |
| Firebase Emulator/live Auth/Firestore | **NOT RUN** | Requires project configuration and test credentials |
| Gemini/Ollama live inference | **NOT RUN** | Requires real provider configuration and reachability |
| Browser microphone/camera/device/offline QA | **NOT RUN** | Requires real browser/device session |
| Windows desktop installer | **NOT BUILT** | Packaging, IPC, ACL/secret store, lifecycle and Windows acceptance remain future work |
| Deployment | **NOT RUN** | No release deployment was made |

## Important packaging blocker

`package.json` declares Node `>=24.12.0`, 17 production, 9 development and 3 optional dependencies. The root manifest in `package-lock.json` has 11 production, 10 development and 0 optional entries. The declared runtime and lockfile are not aligned. A package-lock-only npm update was attempted but timed out in the build environment; the lockfile was not modified. `npm run lint` fails because `vite-plugin-pwa/client` and `vite/client` types are unavailable without dependencies; `npm run build` stops because Vite is not installed. Do not run `npm ci` until dependency declarations and the lockfile have been reconciled on a supported Node runtime.

## Known storage limitations

- SQLite payload data is encrypted, but some row metadata remains plaintext (IDs, owner UID, capability/resource, state and timestamps); this is not full-database encryption.
- POSIX permissions are set by code. Windows ACL/DPAPI integration is not implemented and must be verified before a Windows production release.
- The audit chain is tamper-evident for ordinary data changes, but a privileged attacker who can replace the database can reconstruct it. Use external anchoring for stronger evidence.
- Node's built-in `node:sqlite` may emit an experimental warning; validate it against the exact supported Node release.

## Release conclusion

This is a materially improved **engineering source build**. The original 29 static security assertions remain, and five additional enhanced-core assertions have been added, for **34/34 total**. It is not a complete production assistant, compiled application or Windows installer. The next mandatory milestone is M0 build recovery on Node >=24.12.0: reconcile lockfile/manifest, clean install, semantic typecheck, Vitest, production build, then live Firebase/provider and browser tests.
