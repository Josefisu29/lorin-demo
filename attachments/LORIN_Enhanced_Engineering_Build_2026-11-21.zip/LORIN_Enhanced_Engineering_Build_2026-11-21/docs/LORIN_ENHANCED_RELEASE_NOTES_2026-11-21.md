# LORIN Enhanced — Release Notes

## Added

- Server-owned capability registry with strict nested schemas, bounded JSON inputs and bounded timeouts.
- Deny-by-default execution policy with principal, permission, owner scope, local-only and risk checks.
- Local SQLite job and approval persistence, AES-256-GCM payload encryption and record-bound associated data.
- Canonical action digest on every job and revalidation immediately before executor invocation.
- Atomic, single-use approvals consumed immediately before worker execution.
- Hash-chained audit events and explicit job lifecycle states.
- Local-first explainable provider route planner requiring recent health evidence.
- Standalone adaptive voice activity detection with onset, pre-roll and hangover.
- Authenticated API endpoints for core health, capabilities, jobs, approvals, cancellation and one-shot local worker execution.
- Loopback-first server binding with explicit network/TLS-termination gate.
- Focused `npm run test:core` and `npm run core:health` commands.

## Preserved

The existing LORIN React/Vite experience, Gemini/Ollama adapter code, Firebase identity, Memory, Knowledge Vault, projects, GIDEON, MOSAIRA, Babylon.js avatar, voice/vision and local-node features remain in the source working copy. No competitor project was merged wholesale.

## Intentionally not enabled

- General-purpose shell or terminal execution.
- Model-generated source hot-loading into privileged services.
- Autonomous device flashing/reboot/ADB actions.
- Hidden camera or microphone access, or wake-word always-on listening.
- Arbitrary filesystem or network actions.
- Critical-risk tools.

## Known not-yet-integrated areas

- Provider router not yet wired to the full inference dispatcher.
- VAD not yet connected to the live audio service.
- New job engine has no continuous worker loop or task-management UI.
- Local SQLite only covers new core job/approval records, not every existing app store.
- Cloud persistence adapter, semantic typecheck, Vitest, production build, provider/Firebase/device acceptance and Windows installer remain outstanding.
