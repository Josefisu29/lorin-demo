// Chữ hiện ra lấy từ từ điển. Trong trình duyệt là window.t (i18n/index.js nạp trước mọi
// module này); dưới node - nơi test require() thẳng file này - `window` CHƯA KHAI BÁO nên
// đọc window.t là ReferenceError chứ không phải undefined, phải hỏi bằng typeof. Ở đó đọc
// thẳng vi.json để hàm vẫn trả về chữ thật, không phải mã khoá trần.
function graphTw(khoa, bien) {
  if (typeof window !== "undefined" && window.t) return window.t(khoa, bien);
  try {
    var s = require("./i18n/vi.json")[khoa] || khoa;
    return String(s).replace(/\{(\w+)\}/g, function (m, ten) {
      return (bien && bien[ten] != null) ? String(bien[ten]) : m;
    });
  } catch (e) { return khoa; }
}

// ============================================
// JAVIS OS - Knowledge graph "Tinh vân bộ não" (force-graph / d3-force, kiểu Obsidian)
// Engine d3-force. Thiết kế: node = sao phát sáng, TÔ MÀU THEO DANH MỤC
// (thư mục cha, khớp nhãn PERSONAL/BUSINESS...), hover = rọi đèn vùng liên quan (synapse), thở nhẹ
// lúc nghỉ, nhãn chỉ hiện khi hover / zoom sát / vài hub lớn.
// ============================================

// --- Bảng màu danh mục: gán theo tên danh mục ổn định ---
// Hai bảng CÙNG THỨ TỰ HUE nên một thư mục giữ nguyên "màu nhận dạng" khi đổi tông:
// chàm vẫn là chàm, lục vẫn là lục - chỉ đổi độ đậm cho hợp nền.
// Tối: màu rực để nổi trên nền đen. Sáng: mực sẫm cùng hue, đều đạt >=4.5:1 trên
// giấy ngà - bê nguyên bảng rực sang nền trắng thì chấm nào cũng nhợt như nhau.
const CAT_COLORS_DARK = ["#8b93ff", "#3fdc9a", "#f0a24a", "#ff7a9c", "#4aa8ff", "#b98cff",
  "#f0c853", "#5ad1c4", "#e07ad1", "#7ed957", "#ff9f6b", "#9fb0cf"];
const CAT_COLORS_LIGHT = ["#4a52c9", "#0f8f63", "#b46a10", "#c93b62", "#1668c4", "#7340c9",
  "#96760a", "#0e8b81", "#a83c95", "#3e8f22", "#c9551f", "#5a688a"];

// Bảng đang dùng + các màu phụ thuộc tông của lớp vẽ. Đổi tông thì hoán bảng rồi
// vẽ lại; không rebuild đồ thị nên vị trí node và trạng thái hover giữ nguyên.
let CAT_COLORS = CAT_COLORS_DARK;
let INK = {
  hoverCore: "#ffffff",                      // lõi node đang trỏ - "nóng nhất"
  fallback: "#b98cff",
  glowCore: "rgba(255,255,255,0.95)",        // lõi trắng nóng của quầng sáng
  glowStops: [[0.28, 0.9], [0.6, 0.32]],
  linkIdle: "rgba(150,140,220,0.07)",
  linkOn: "rgba(175,155,255,0.4)",
  linkOff: "rgba(140,140,200,0.02)",
  labelHalo: "rgba(4,6,12,0.85)",
  labelText: "rgba(233,235,246,0.96)",
};
const INK_LIGHT = {
  hoverCore: "#2a2138",
  fallback: "#7340c9",
  // Trên giấy KHÔNG có "lõi trắng nóng": quầng sáng đổi thành vệt mực loang,
  // đậm ở tâm rồi thấm nhạt ra - cùng hue với node.
  glowCore: null,
  glowStops: [[0.0, 0.55], [0.30, 0.30], [0.62, 0.11]],
  linkIdle: "rgba(120,100,170,0.16)",
  linkOn: "rgba(96,60,180,0.55)",
  linkOff: "rgba(140,140,200,0.05)",
  labelHalo: "rgba(251,249,247,0.92)",
  labelText: "rgba(32,28,44,0.97)",
};
const INK_DARK = INK;

function _catOf(node) {
  const segs = (node.path || "").split("/");
  let cat = segs.length >= 2 ? segs[segs.length - 2] : "root";
  cat = cat.replace(/^\d+\s*[-_.]\s*/, "").trim().toLowerCase();   // bỏ tiền tố "07 - "
  return cat || "root";
}
function _hash(s) { let h = 0; s = String(s || ""); for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }

// Gán màu danh mục (tuần tự theo danh mục) vào n.color của từng node.
// Nhớ CHỈ SỐ danh mục (không phải màu) để đổi tông chỉ là tra lại bảng khác.
window.JavisCatColorize = function (nodes) {
  const idx = {}; let next = 0;
  (nodes || []).forEach(n => {
    const segs = (n.path || "").split("/");
    let cat = (segs.length >= 2 ? segs[segs.length - 2] : "root").replace(/^\d+\s*[-_.]\s*/, "").trim().toLowerCase() || "root";
    if (!(cat in idx)) { idx[cat] = next; next++; }
    n.__catIdx = idx[cat];
    n.color = CAT_COLORS[idx[cat] % CAT_COLORS.length];   // ghi đè màu tím backend bằng màu danh mục
  });
  window.__javisCatIdx = idx;
  window.__javisCatMap = _mapFromIdx(idx);   // để nhãn danh mục tô chữ khớp màu
  return window.__javisCatMap;
};

function _mapFromIdx(idx) {
  const map = {};
  Object.keys(idx || {}).forEach(k => { map[k] = CAT_COLORS[idx[k] % CAT_COLORS.length]; });
  return map;
}

// Mở một lối tra màu cho nhãn danh mục trong app.js.
// để nó lấy đúng bảng màu của tông đang bật.
window.JavisCatColorAt = function (idx) {
  return CAT_COLORS[(idx || 0) % CAT_COLORS.length];
};

// --- Sprite quầng sáng (cache theo màu) → vẽ bằng drawImage (rẻ), tạo hiệu ứng tinh vân ---
const _glowCache = {};
function _hexA(hex, a) {
  const m = String(hex || "#9d7aff").replace("#", "");
  const r = parseInt(m.substring(0, 2), 16), g = parseInt(m.substring(2, 4), 16), b = parseInt(m.substring(4, 6), 16);
  return `rgba(${r || 157},${g || 122},${b || 255},${a})`;
}
function _glowSprite(color) {
  const key = color + (INK === INK_LIGHT ? "|L" : "|D");
  if (_glowCache[key]) return _glowCache[key];
  const s = 64, cv = document.createElement("canvas"); cv.width = cv.height = s;
  const ctx = cv.getContext("2d");
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  if (INK.glowCore) g.addColorStop(0, INK.glowCore);   // lõi trắng nóng (chỉ tông tối)
  INK.glowStops.forEach(([at, a]) => g.addColorStop(at, _hexA(color, a)));
  g.addColorStop(1, _hexA(color, 0));                  // viền tan vào nền
  ctx.fillStyle = g; ctx.fillRect(0, 0, s, s);
  _glowCache[key] = cv; return cv;
}

// Đổi tông: hoán bảng màu + bảng mực, gán lại màu cho node đang có, rồi vẽ lại.
// Không nạp lại dữ liệu nên toạ độ node, cụm đang rọi sáng và node đang trỏ giữ nguyên.
function _applyGraphTheme(light) {
  CAT_COLORS = light ? CAT_COLORS_LIGHT : CAT_COLORS_DARK;
  INK = light ? INK_LIGHT : INK_DARK;
  if (window.__javisCatIdx) window.__javisCatMap = _mapFromIdx(window.__javisCatIdx);
  const g = window.__javisGraph;
  if (g && g._recolor) g._recolor();
  try { window.dispatchEvent(new Event("javis-catcolors-change")); } catch (e) {}
}
// Đọc tông hiện tại từ thuộc tính trên <html>. Bọc typeof vì file này còn được nạp
// trong Node (test JS ở tests/js/) với DOM giả lập tối thiểu, không có documentElement.
function _themeIsLight() {
  return typeof document !== "undefined" && document.documentElement
    ? document.documentElement.getAttribute("data-theme") === "light"
    : false;
}
// KHÔNG dùng window.javisTheme.on() ở đây: file này có lúc nạp trước theme.js, khi đó
// window.javisTheme chưa tồn tại nên đăng ký hụt IM LẶNG và đồ thị kẹt ở bảng màu tối.
// Nghe thẳng sự kiện + tự đọc thuộc tính thì đúng ở mọi thứ tự nạp.
if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
  window.addEventListener("javis-theme-change", function (e) {
    _applyGraphTheme(!!(e && e.detail && e.detail.light));
  });
}
_applyGraphTheme(_themeIsLight());

// Lực kéo mọi node về tâm (0,0) tỉ lệ khoảng cách → cả mạng co lại thành hình tròn ở giữa,
// node bị kéo ra sẽ tự trôi về. (d3 custom force: hàm(alpha) + initialize(nodes)).
function _centerGravity(strength) {
  let _nodes = [];
  const force = (alpha) => {
    const k = strength * alpha;
    for (let i = 0; i < _nodes.length; i++) { const n = _nodes[i]; n.vx -= n.x * k; n.vy -= n.y * k; }
  };
  force.initialize = (ns) => { _nodes = ns; };
  return force;
}

// ---- Remembered layout (2026-11-12) ----
// Where every dot came to rest is kept in this browser, per graph, so the next opening starts from that picture instead
// of from a heap in the middle. Why: the library ran 24 physics steps IN ONE GO before the first frame and then five
// seconds of physics, on every opening and after every new note. Measured with 2,600 notes: one block of 255 ms on a
// desktop and 1.1 s on a phone, then five seconds at a few frames a second. A graph that starts where it last settled
// needs neither: no warm-up, a short settle for the notes that are new.
// Only numbers are stored (a hash of each note's id and two coordinates), never a name or a path.
const POS_KEY = "javis.graphPos.";        // + the graph's query (source=... / path=...)
const POS_INDEX = "javis.graphPos.keys";  // the queries kept, most recent first
const POS_KEEP = 3;                       // graphs remembered per browser
const POS_MAX_NODES = 15000;              // beyond this the copy would crowd localStorage
const POS_HIT = 0.9;                      // share of notes that must have a remembered place to skip the warm-up
// Physics steps after which a layout counts as settled (d3-force cools down in about 300). A slow machine runs far
// fewer in its five seconds; the count is kept with the layout and adds up over openings, and until it is reached
// every opening settles a little more.
const POS_SETTLED_TICKS = 300;
// Below this many physics steps a second the machine is too slow to animate the settling: every step is a visible
// stutter (measured on a simulated phone, 1,900 notes: 7 steps a second, each a 140 ms block). Such a machine keeps the
// layout it ended on, which is the very picture it always came to rest on after its five seconds.
const POS_SLOW_RATE = 20;

function _posStore() {
  try { return (typeof localStorage !== "undefined" && localStorage) || null; } catch (e) { return null; }
}

// The last layout of this graph: {map: hash of id -> [x, y], ticks: physics steps it has had}, or null.
function _posLoad(query) {
  const st = _posStore();
  if (!st || !query) return null;
  try {
    const rec = JSON.parse(st.getItem(POS_KEY + query) || "null");
    const flat = rec && rec.p;
    if (!Array.isArray(flat) || flat.length < 3) return null;
    const map = new Map();
    for (let i = 0; i + 2 < flat.length; i += 3) map.set(flat[i], [flat[i + 1], flat[i + 2]]);
    return { map, ticks: Number(rec.t) || 0, slow: !!rec.s };
  } catch (e) { return null; }
}

function _posSave(query, nodes, ticks, slow) {
  const st = _posStore();
  if (!st || !query || !nodes || !nodes.length || nodes.length > POS_MAX_NODES) return false;
  const flat = [];
  for (let i = 0; i < nodes.length; i++) {
    const n = nodes[i];
    if (typeof n.x !== "number" || typeof n.y !== "number" || !isFinite(n.x) || !isFinite(n.y)) continue;
    flat.push(_hash(n.id), Math.round(n.x), Math.round(n.y));
  }
  if (flat.length < 3) return false;
  try {
    let keys = [];
    try { keys = JSON.parse(st.getItem(POS_INDEX) || "[]"); } catch (e) { keys = []; }
    if (!Array.isArray(keys)) keys = [];
    keys = [query].concat(keys.filter(k => k !== query));
    keys.slice(POS_KEEP).forEach(k => { try { st.removeItem(POS_KEY + k); } catch (e) {} });
    keys = keys.slice(0, POS_KEEP);
    st.setItem(POS_KEY + query, JSON.stringify({ t: Math.max(0, Math.round(Number(ticks) || 0)), s: slow ? 1 : 0, p: flat }));
    st.setItem(POS_INDEX, JSON.stringify(keys));
    return true;
  } catch (e) { return false; }   // storage full or blocked: the graph simply settles from scratch next time
}

// Put the remembered places on `nodes`. A note with no place (new since the last visit) starts beside a note it links
// to, so it does not fly in from the middle. Returns "" when too little was remembered (the physics lays it all out),
// "settle" when the dots are placed but still need a short settle (new notes, or a layout that never cooled down), and
// "still" when every dot stands where a settled layout left it (or where a slow machine's layout ended): nothing to
// compute at all.
function _posApply(known, nodes, links) {
  if (!known || !known.map || !nodes || !nodes.length) return "";
  let placed = 0;
  const byId = new Map();
  nodes.forEach(n => {
    byId.set(n.id, n);
    const p = known.map.get(_hash(n.id));
    if (p) { n.x = p[0]; n.y = p[1]; placed++; }
  });
  if (placed / nodes.length < POS_HIT) {
    nodes.forEach(n => { delete n.x; delete n.y; });   // too little remembered: let the physics lay it all out
    return "";
  }
  if (placed === nodes.length) return (known.ticks >= POS_SETTLED_TICKS || known.slow) ? "still" : "settle";
  (links || []).forEach(l => {
    const a = byId.get(l.source), b = byId.get(l.target);
    if (!a || !b) return;
    const from = typeof a.x === "number" ? a : (typeof b.x === "number" ? b : null);
    const to = from === a ? b : a;
    if (!from || typeof to.x === "number") return;
    const h = _hash(to.id);
    to.x = from.x + ((h % 41) - 20);
    to.y = from.y + (((h >>> 8) % 41) - 20);
  });
  return "settle";
}

class JavisGraph {
  constructor(container) {
    this.container = container;
    this.graph = null;
    this.level = 0;
    this._thinking = false;
    this._fitted = false;
    this._t0 = 0;
    this._hoverId = null;
    this._veLienTuc = false;   // nhịp vẽ hiện tại, xem _nhipVe()
    // Lần cuối có gì đó động. Phải là RẤT LÂU RỒI chứ không phải 0: performance.now() lúc
    // trang vừa nạp cũng chỉ vài trăm mili giây, nên để 0 thì "chưa từng động" lại bị tính
    // là "vừa mới động" suốt quãng ân hạn đầu tiên.
    this._dongLuc = -1e12;
    this._chuotTren = false;   // con trỏ có đang ở trên vùng đồ thị không
    this._daNgheChuot = false;
    this._nbrs = new Set();
    this._catFilter = null;
    this._dangCham = false;    // ngón tay / nút chuột đang giữ trên quả cầu
    this._daKeo = false;       // người dùng đã kéo hay phóng từ lần về giữa trước (xem _henVeGiua)
    this._henGiua = null;      // hẹn giờ về giữa
    this._loaiTro = "";        // "mouse" | "touch" | "pen" của lần chạm cuối
    this._diemCham = null;
    window.__javisGraph = this;
    try { window.dispatchEvent(new Event("javis-graph-created")); } catch (e) {}
  }

  _prep(nodes) {
    nodes = nodes || [];
    if (!this._catMap) { this._catMap = {}; this._catNext = 0; }
    const markHubs = nodes.length > 6;                          // chỉ đánh dấu hub khi nạp cả mạng
    const hubIds = markHubs
      ? new Set([...nodes].sort((a, b) => (b.links || 0) - (a.links || 0)).slice(0, 4).map(n => n.id))
      : null;
    nodes.forEach(n => {
      const cat = _catOf(n);
      // Gán màu TUẦN TỰ theo danh mục (mỗi danh mục một màu khác nhau) - không hash để tránh trùng.
      // Lưu CHỈ SỐ để đổi tông chỉ cần tra lại bảng màu khác, khỏi gán lại từ đầu.
      if (!(cat in this._catMap)) { this._catMap[cat] = this._catNext; this._catNext++; }
      n.__cat = cat;
      n.__catIdx = this._catMap[cat];
      n.__c = CAT_COLORS[n.__catIdx % CAT_COLORS.length];
      n.__r = 3 + Math.sqrt(Math.min(55, n.links || 0)) * 1.9;   // chấm sáng vừa (glow tinh linh)
      n.__ph = (_hash(n.id) % 628) / 100;                       // pha thở lệch nhau
      if (markHubs) n.__hub = hubIds.has(n.id);
    });
  }

  async load(query = "source=all") {
    const res = await fetch(`/graph?${query}&orphans=1`);   // 2D hiện CẢ note cô đơn (như graph view Obsidian)
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || graphTw("graph.load_failed", { status: res.status }));
    const nodes = Array.isArray(data.nodes) ? data.nodes : [];
    this._catMap = null;                     // gán lại màu danh mục tươi cho mỗi lần nạp
    this._prep(nodes);
    window.__javisCatIdx = this._catMap;                    // danh mục → chỉ số
    window.__javisCatMap = _mapFromIdx(this._catMap);       // để nhãn danh mục (app.js) tô chữ khớp màu node
    const links = (data.edges || []).map(e => ({ source: e.source, target: e.target }));
    // Start from where this graph last settled (see "Remembered layout" above).
    const known = _posLoad(query);
    const remembered = _posApply(known, nodes, links);   // "", "settle" or "still"
    this._query = query;
    this._ticks = remembered && known ? known.ticks : 0;   // physics steps this layout has had so far
    this._slow = !!(remembered && known && known.slow);     // this machine could not animate the settling last time

    if (!this.graph) {
      if (!window.ForceGraph) throw new Error(graphTw("graph.lib_2d_missing"));
      const self = this;
      this.graph = ForceGraph()(this.container)
        .backgroundColor("rgba(0,0,0,0)")
        // Vẽ liên tục hay để thư viện tự bỏ khung: quyết định theo TÌNH HUỐNG, xem _nhipVe().
        // Trước 0.63.7 đặt cứng false, nghĩa là vẽ lại MỌI khung hình mãi mãi kể cả khi vật lý
        // đã nguội và không một chấm nào nhúc nhích. Đo trên bộ não 844 note: màn chính ăn 34%
        // một nhân CPU trong lúc không ai đụng vào gì, và 44% con số đó là vẽ lại một bức hình
        // y hệt bức trước. Máy yếu thì đó là cả cái "siêu đơ" người dùng kêu.
        .autoPauseRedraw(true)
        .nodeId("id")
        .nodeRelSize(1)
        .nodeVal(n => { const r = (n.__r || 4) + 5; return r * r; })   // vùng bắt hover rộng hơn hình (dễ trỏ)
        .warmupTicks(24)
        .cooldownTime(5000)
        .linkColor(l => {
          if (self._hoverId != null) {
            const s = (l.source && l.source.id) || l.source, t = (l.target && l.target.id) || l.target;
            return (s === self._hoverId || t === self._hoverId) ? INK.linkOn : INK.linkOff;
          }
          return INK.linkIdle;                      // dây nối mờ hơn (đỡ đậm)
        })
        .linkWidth(l => {
          if (self._hoverId != null) {
            const s = (l.source && l.source.id) || l.source, t = (l.target && l.target.id) || l.target;
            if (s === self._hoverId || t === self._hoverId) return 1;   // hover cũng mảnh (trước 1.8)
          }
          return 0.4;                               // dây mảnh hơn
        })
        .nodeCanvasObjectMode(() => "replace")
        .nodeCanvasObject((n, ctx, scale) => self._drawNode(n, ctx, scale))
        .onNodeHover(n => {
          self._hoverId = n ? n.id : null;
          self._nhipVe();          // rê vào một chấm là bật lại vẽ liên tục, rời ra thì thôi
          self._nbrs = new Set();
          if (n) {
            self.graph.graphData().links.forEach(l => {
              const s = (l.source && l.source.id) || l.source, t = (l.target && l.target.id) || l.target;
              if (s === n.id) self._nbrs.add(t); else if (t === n.id) self._nbrs.add(s);
            });
          }
          self.container.style.cursor = n ? "pointer" : "grab";
        })
        .onNodeClick(n => { if (window.onGraphNodeClick) window.onGraphNodeClick(n); })   // chỉ mở note, KHÔNG lia camera
        .onNodeDrag(() => { self._engineOn = true; })                                     // a drag reheats the physics
        .onNodeDragEnd(n => { n.fx = null; n.fy = null; self._engineOn = true; self._syncLoop(); })   // thả kéo → node tự trôi về
        .onBackgroundClick(() => { self._catFilter = null; })                            // KHÔNG recenter → bấm được node viền
        .minZoom(0.05).maxZoom(3)                                                         // min nâng lên = mức fit sau khi lắng
        .onEngineTick(() => { self._ticks = (self._ticks || 0) + 1; self._runTicks = (self._runTicks || 0) + 1; })
        .onEngineStop(() => {
          self._engineOn = false;
          self._rememberLayout();
          // What follows a stop is the user's own doing (dragging a dot reheats the physics): the usual five seconds.
          try { self.graph.cooldownTime(JavisGraph.cooldownFor("")); } catch (e) {}
          if (self._fitted) { self._syncLoop(); return; }
          self._fitted = true;
          // The user is already dragging or zooming: the camera is theirs, do not pull it back to the middle.
          if (!self._daKeo) self._fit(500);
          self._syncLoop();
        });

      // Lực đẩy vừa (node gần nhau, không văng) + hút MẠNH về tâm (co thành khối TRÒN, kéo node lẻ vào)
      // + link ngắn (cụm liên kết bám sát). Cân bằng để tròn co vào giữa như Obsidian mà chấm vẫn tách.
      try { this.graph.d3Force("charge").strength(-70); } catch (e) {}
      try { const lf = this.graph.d3Force("link"); if (lf) lf.distance(26); } catch (e) {}
      try { this.graph.d3Force("gravity", _centerGravity(0.1)); } catch (e) {}           // hút mạnh hơn → kéo cụm rời/xa vào gần
      this._ngheChuot();
      this.resize();
    }

    this._fitted = false;
    // The fade-in needs a redraw on every frame for 0.7 s. A layout that is shown exactly as it was left ("still") is
    // drawn ONCE, at full strength: on a slow machine every extra frame of a large graph is a visible stutter (about
    // 140 ms each on a simulated phone with 1,900 notes), and a single frame caught mid-fade would stay dim for good.
    this._t0 = remembered === "still" ? 0 : (typeof performance !== "undefined" ? performance.now() : Date.now());
    try { this.graph.minZoom(0.05); } catch (e) {}   // mở lại giới hạn để lần fit mới không bị kẹp
    this._physicsFor(nodes.length, remembered);
    this.graph.graphData({ nodes, links });
    this.resize();
    // The picture is already the settled one: frame it now instead of after the physics has cooled down.
    if (remembered) this._fit(0);
    // Nothing will move, so the framing above is final: no second, animated framing when the physics reports its stop.
    if (remembered === "still") this._fitted = true;
    return data;
  }

  // How much physics a load gets. `remembered` is what _posApply said: "" (nothing to start from), "settle" (the dots
  // stand where they last were, new notes still have to find their place) or "still" (a settled layout, unchanged).
  // The warm-up runs in one go before the first frame, so its length is what the user feels as a freeze: 24 steps are
  // kept for small graphs (they cost a few milliseconds there), fewer as the graph grows, none when remembered.
  static warmupFor(count, remembered) {
    if (remembered) return 0;
    return count > 1500 ? 6 : (count > 600 ? 12 : 24);
  }
  static cooldownFor(remembered) { return remembered === "still" ? 0 : (remembered ? 1500 : 5000); }

  _physicsFor(count, remembered) {
    if (!this.graph) return;
    // Every caller hands new data to the library right after this, which starts its physics: the loop must run.
    this._engineOn = true;
    this._syncLoop();
    const warm = JavisGraph.warmupFor(count, remembered);
    if (!remembered) this._ticks = warm;   // a layout from scratch: the count starts over (warm-up steps included)
    // This run, for the speed check in _rememberLayout: steps done, when it began and how long it is given.
    this._runTicks = 0;
    this._runStart = (typeof performance !== "undefined" ? performance.now() : Date.now());
    this._runBudget = JavisGraph.cooldownFor(remembered);
    try { this.graph.warmupTicks(warm); } catch (e) {}
    try { this.graph.cooldownTime(JavisGraph.cooldownFor(remembered)); } catch (e) {}
  }

  // Keep where the dots stand now for the next opening (called when the physics stops).
  _rememberLayout() {
    if (!this.graph || !this._query || this._tlTimer) return false;   // a timelapse is not a settled layout
    // How fast did this run go? Only a run that used its whole time says something: one cut short (the physics cooled
    // down early) or stretched (the page was left while it ran, the loop paused) keeps the earlier verdict.
    const took = (typeof performance !== "undefined" ? performance.now() : Date.now()) - (this._runStart || 0);
    const budget = this._runBudget || 0;
    if (budget >= 1000 && took >= budget && took <= budget + 1500) {
      this._slow = JavisGraph.slowRun(this._runTicks || 0, took);
    }
    try { return _posSave(this._query, this.graph.graphData().nodes, this._ticks || 0, this._slow); } catch (e) { return false; }
  }
  // Did a run of `ticks` physics steps in `ms` go too slowly to be worth animating again?
  static slowRun(ticks, ms) { return ms > 0 && (ticks * 1000) / ms < POS_SLOW_RATE; }

  _drawNode(n, ctx, scale) {
    if (n.x == null || n.y == null) return;
    const t = (typeof performance !== "undefined" ? performance.now() : Date.now());
    const ent = this._t0 ? Math.min(1, (t - this._t0) / 700) : 1;      // fade-in khi mở
    const hovering = this._hoverId != null;
    const isHover = n.id === this._hoverId;
    const isNbr = hovering && this._nbrs.has(n.id);
    const catDim = this._catFilter && n.__cat !== this._catFilter && !isHover && !isNbr;
    const dim = (hovering && !isHover && !isNbr) || catDim;
    const breathe = 1 + 0.05 * Math.sin(t / 650 + (n.__ph || 0));       // thở nhẹ, lệch pha
    // Nhịp thở theo giọng. Biên độ GIỮ NHỎ và nhịp CHẬM: mức âm đã được làm trơn ở setLevel,
    // nhưng biên độ cũ (0,46 lúc nghĩ, chu kỳ 1,4 giây) vẫn làm cả quả cầu phình co như bơm
    // hơi. Nay lúc nghĩ tối đa 0,16 với chu kỳ ~2,6 giây, lúc đọc tối đa 0,12 - thấy là nó
    // đang sống theo tiếng nói, chứ không thấy nó giật.
    const pulse = this._thinking
      ? (1 + (0.06 + 0.10 * this.level) * Math.sin(t / 420))
      : (1 + 0.12 * this.level);
    let born = 1;
    if (n.__born) { const age = (t - n.__born) / 500; born = age < 1 ? age : 1; if (age >= 1) n.__born = 0; }  // nảy sinh
    const r = (n.__r || 5) * (isHover ? 1.35 : 1) * breathe * pulse * (0.4 + 0.6 * born);
    const alpha = (dim ? 0.14 : 1) * ent * (0.4 + 0.6 * born);

    // Quầng sáng (tông sáng: vệt mực loang quanh chấm)
    ctx.globalAlpha = alpha;
    const spr = _glowSprite(n.__c || INK.fallback);
    const gsz = r * 2.4;                       // quầng sáng tinh linh (to hơn) nhưng vẫn tách chấm
    ctx.drawImage(spr, n.x - gsz / 2, n.y - gsz / 2, gsz, gsz);
    // Lõi đặc
    ctx.globalAlpha = Math.min(1, alpha + 0.15);
    ctx.beginPath(); ctx.arc(n.x, n.y, r * 0.5, 0, Math.PI * 2);
    ctx.fillStyle = isHover ? INK.hoverCore : (n.__c || INK.fallback);
    ctx.fill();
    ctx.globalAlpha = 1;

    // Nhãn: CHỈ note đang trỏ (như Obsidian). KHÔNG hiện-hết-khi-zoom (vừa loạn, vừa làm zoom khựng
    // do phải vẽ hàng trăm chữ mỗi frame).
    const showLabel = isHover;
    if (showLabel && n.label) {
      const la = (dim ? 0.16 : (isHover ? 1 : 0.85)) * ent;
      const fs = Math.max(9, 11 / scale);
      ctx.font = `${fs}px -apple-system, Segoe UI, sans-serif`;
      ctx.textAlign = "center"; ctx.textBaseline = "top";
      const ly = n.y + r + 2;
      ctx.globalAlpha = la;
      ctx.lineWidth = 3 / scale; ctx.strokeStyle = INK.labelHalo;
      ctx.strokeText(n.label, n.x, ly);
      ctx.fillStyle = INK.labelText;
      ctx.fillText(n.label, n.x, ly);
      ctx.globalAlpha = 1;
    }
  }

  // Đổi tông: gán lại màu node theo bảng mới rồi ép vẽ lại một frame.
  // Không đụng graphData().nodes/links nên d3-force không bị khởi động lại - đồ thị
  // đứng yên tại chỗ, chỉ đổi màu. (Đổ lại graphData sẽ làm mạng giật và fit lại camera.)
  _recolor() {
    if (!this.graph) return;
    const d = this.graph.graphData();
    (d.nodes || []).forEach(n => {
      if (n.__catIdx != null) n.__c = CAT_COLORS[n.__catIdx % CAT_COLORS.length];
      if (n.color) n.color = n.__c || n.color;
    });
    // Ép force-graph vẽ lại dây nối (linkColor là hàm nên chỉ cần đánh thức vòng vẽ).
    try { this.graph.linkColor(this.graph.linkColor()); } catch (e) {}
    this._poke(300);
  }

  // Lề chừa quanh đồ thị khi canh khung, TÍNH THEO khung thật chứ không phải số cố định.
  //
  // Trước bản này là `zoomToFit(500, 70)` - 70px mỗi bên, hằng số hợp lý cho khoang não
  // desktop (~900x700) nhưng thảm hoạ trên điện thoại. Khoang não mobile chỉ cao khoảng
  // 228px, nên 70px trên cộng 70px dưới ăn mất 140px, còn đúng 88px cho TOÀN BỘ đồ thị -
  // đó chính là "cục nhỏ xíu giữa màn hình" chủ repo chụp lại. Theo tỉ lệ thì desktop giữ
  // nguyên cảm giác cũ (700 * 0.10 = 70) còn mobile tự co xuống (228 * 0.10 = 23).
  _fitPad() {
    const w = this.container ? this.container.clientWidth : 0;
    const h = this.container ? this.container.clientHeight : 0;
    const nho = Math.min(w || 800, h || 600);
    return Math.max(10, Math.min(70, Math.round(nho * 0.10)));
  }

  _fit(ms = 400) {
    if (!this.graph) return;
    this._poke(ms + 400);   // the camera glides inside the library's loop
    try {
      this.graph.zoomToFit(ms, this._fitPad());                 // canh cho MỌI node vừa khung
      // Sau khi fit: chặn zoom-out nhỏ hơn mức "mọi node vừa khung". Đặt sau khi hoạt ảnh
      // fit chạy xong, nếu không nó đọc phải mức zoom giữa chừng.
      setTimeout(() => {
        try { this.graph.minZoom(Math.min(this.graph.zoom() * 0.95, 1.2)); } catch (e) {}
      }, ms + 100);
    } catch (e) {}
  }

  // Canh lại khung theo yêu cầu (bung/thu khoang não trên điện thoại). Mở lại minZoom
  // trước: lần fit trước đã kẹp nó ở mức của khung CŨ, giữ nguyên là khung to hơn không
  // bao giờ zoom-out đủ để thấy hết.
  refit(ms = 400) {
    if (!this.graph) return;
    this.resize();
    try { this.graph.minZoom(0.05); } catch (e) {}
    this._fit(ms);
  }

  resize() {
    if (!this.graph || !this.container) return;
    const p = this.container.parentElement;
    const w = this.container.clientWidth || (p ? p.clientWidth : 800);
    const h = this.container.clientHeight || (p ? p.clientHeight : 600);
    if (w && h) this.graph.width(w).height(h);
    this._poke(300);        // a new size clears the canvas: the library must draw it again
  }

  // --- Nhịp vẽ: chỉ vẽ liên tục khi THẬT SỰ có gì đang động ---
  //
  // Ba thứ làm quả cầu động: giọng nói (mỗi chấm thở theo mức âm), nhịp NGHĨ, và con trỏ
  // đang rê trên một chấm (rọi sáng vùng liên quan). Ngoài ba cái đó, hình vẽ ra giống hệt
  // khung trước, nên vẽ lại là đốt CPU không đổi lại gì.
  //
  // GIỮ THÊM một quãng ân hạn sau khi hết động: mức âm đi xuống CHẬM (xem setLevel), dừng vẽ
  // ngay lúc vừa dứt tiếng là quả cầu đứng khựng giữa nhịp thở, nhìn như app treo. Hết ân hạn
  // thì biên độ thở còn dưới 5%, đóng băng ở đó mắt không nhận ra.
  static get AN_HAN_MS() { return 1200; }

  /** Chuột đang ở TRÊN quả cầu thì luôn vẽ liên tục.
   *
   *  Đây là chốt an toàn quan trọng, KHÔNG phải tối ưu: thư viện đồ thị dò xem con trỏ đang
   *  ở trên chấm nào NGAY TRONG vòng vẽ của nó. Dừng vẽ thì nó cũng thôi dò, nên nếu chỉ
   *  dựa vào onNodeHover để bật lại thì thành bài toán con gà quả trứng: không vẽ nên không
   *  biết đang hover, không biết hover nên không vẽ, và hiệu ứng rọi sáng chết hẳn.
   *
   *  Nghe ngay trên khung chứa nên không phụ thuộc ruột thư viện: con trỏ vừa chạm vào vùng
   *  đồ thị là vẽ lại liên tục, rời ra thì hết ân hạn là đóng băng. */
  _ngheChuot() {
    const el = this.container;
    if (!el || this._daNgheChuot) return;
    this._daNgheChuot = true;
    const cham = () => { if (this._synthetic) return; this._chuotTren = true; this._nhipVe(); };
    const roi = (e) => {
      this._chuotTren = false;
      this._dropHover();
      this._nhipVe();
      if (e && e.pointerType === "mouse") this._henVeGiua();   // chuột rời quả cầu: hết xem, đếm giờ về giữa
    };
    el.addEventListener("pointerenter", cham);
    el.addEventListener("pointermove", cham);
    el.addEventListener("pointerdown", (e) => {
      cham(); this._dangCham = true; this._loaiTro = e.pointerType; this._huyVeGiua();
      this._diemCham = [e.clientX, e.clientY];
    });
    // Chỉ tính là KÉO khi tay đi quá vài px: bấm một chấm để mở note thì không cần camera chạy về đâu cả.
    el.addEventListener("pointermove", (e) => {
      const d = this._diemCham;
      if (this._dangCham && d && Math.abs(e.clientX - d[0]) + Math.abs(e.clientY - d[1]) > 8) this._daKeo = true;
    });
    el.addEventListener("pointerleave", roi);
    // Thả tay (ngón hay chuột) sau khi kéo, và lăn chuột để phóng: đếm giờ về giữa. Nghe ở window cho pointerup vì ngón
    // có thể nhấc ra ngoài khung đồ thị.
    const tha = () => { if (this._dangCham) { this._dangCham = false; this._henVeGiua(); } };
    if (typeof window.addEventListener === "function") {
      window.addEventListener("pointerup", tha);
      window.addEventListener("pointercancel", tha);
    }
    el.addEventListener("wheel", () => { this._daKeo = true; this._loaiTro = "mouse"; this._henVeGiua(); }, { passive: true });
  }

  // The pointer left the graph: tell the library, which has no "pointer left" of its own (2026-11-12). It keeps the last
  // position it saw, so the dot under that spot stayed "hovered" for good: the highlight stayed lit with the pointer
  // elsewhere on the page, and because a hovered dot keeps the drawing on, the graph went on drawing every frame until
  // the pointer came back (measured on a simulated phone: main thread 88% busy, nobody touching anything). A pointer
  // move far outside the canvas makes the library's next frame report "nothing hovered" through onNodeHover.
  _dropHover() {
    const el = this.container;
    if (this._hoverId == null || !el || typeof el.querySelector !== "function" || typeof PointerEvent !== "function") return;
    const canvas = el.querySelector("canvas");
    if (!canvas) return;
    this._synthetic = true;     // our own pointermove listener must not read this as the pointer coming back
    try {
      canvas.dispatchEvent(new PointerEvent("pointermove", { bubbles: true, clientX: -100000, clientY: -100000, pointerType: "mouse" }));
    } catch (e) { /* no synthetic events here: the hover clears on the next real move */ }
    this._synthetic = false;
  }

  // --- Kéo tự do, buông tay vài giây thì tự về giữa (0.422.0, chủ repo xin) ---
  //
  // Ngón tay kéo quả cầu đi đâu, chụm hai ngón phóng to bao nhiêu cũng được. Buông ra VE_GIUA_MS là cả đồ thị trôi
  // êm về giữa, vừa khung như lúc mới mở, khỏi phải tự lần lại chỗ cũ trên màn hình điện thoại nhỏ. Máy tính: chuột
  // còn nằm trên quả cầu nghĩa là người ta đang soi một vùng, nên chờ chuột rời đi rồi mới đếm.
  //
  // Chỉ chạy sau một lần NGƯỜI DÙNG kéo hay phóng (_daKeo), không bao giờ tự giật camera khi không ai đụng vào.
  static get VE_GIUA_MS() { return 3000; }

  _huyVeGiua() {
    if (this._henGiua) { clearTimeout(this._henGiua); this._henGiua = null; }
  }

  _henVeGiua() {
    this._huyVeGiua();
    if (!this._daKeo) return;
    this._henGiua = setTimeout(() => {
      this._henGiua = null;
      if (this._dangCham) return;                                   // đang giữ tay: lần thả sau sẽ hẹn lại
      if (this._chuotTren && this._loaiTro === "mouse") return;     // chuột còn trên quả cầu: chờ nó rời đi
      this._daKeo = false;
      this.refit(700);
    }, JavisGraph.VE_GIUA_MS);
  }

  _nhipVe() {
    const dong = this.level > 0.02 || this._thinking || this._hoverId != null || this._chuotTren;
    const gio = (typeof performance !== "undefined" ? performance.now() : Date.now());
    if (dong) this._dongLuc = gio;
    const left = JavisGraph.AN_HAN_MS - (gio - (this._dongLuc || 0));   // what is left of the grace period
    const can = dong || left > 0;
    // 2026-11-12: when only the grace period keeps the drawing on, look again when it ends. Nobody else does: this
    // function runs on events, and since the voice pump stopped calling setLevel on every silent frame the last event
    // (the pointer leaving the graph, the end of a thought) left the graph drawing every frame for good. Measured on a
    // simulated phone, 1,900 notes, after the pointer crossed the graph once: main thread 88% busy with nobody
    // touching anything, 21% once the drawing stops.
    if (this._graceTimer) { clearTimeout(this._graceTimer); this._graceTimer = null; }
    if (can && !dong) {
      this._graceTimer = setTimeout(() => { this._graceTimer = null; this._nhipVe(); }, left + 20);
      if (this._graceTimer && typeof this._graceTimer.unref === "function") this._graceTimer.unref();   // node (tests)
    }
    if (can === this._veLienTuc) return;          // không đổi thì đừng gọi lại thư viện
    this._veLienTuc = can;
    if (this.graph) { try { this.graph.autoPauseRedraw(!can); } catch (e) {} }
    this._syncLoop();
  }

  // --- The library's own loop sleeps too when nothing can change the picture (2026-11-12) ---
  //
  // autoPauseRedraw only skips the DRAWING: the library still asks for a frame on every frame to look whether there is
  // something to draw, and each of those frames makes the browser tick every CSS animation on the page as well.
  // Measured on a simulated phone, home screen left alone: main thread 21% busy for a picture that does not change.
  // So when nothing moves (no voice, no thinking, no pointer on the graph), the physics has stopped and no camera
  // glide is on its way, the loop is paused. Everything that can change the picture wakes it: _nhipVe (voice,
  // thinking, pointer), new data and drags (_engineOn), and _poke for the one-off redraws (camera glide, new size,
  // new colours, a highlighted category). A wake-up the library never confirms (onEngineStop not fired) leaves the loop
  // running, which is the old behaviour.
  _loopNeeded(gio) {
    return !!(this._veLienTuc || this._engineOn || this._tlTimer || gio < (this._pokeUntil || 0));
  }
  _syncLoop() {
    if (!this.graph || this._parked) return;      // parked: another page is in front, console.js paused the graph
    const gio = (typeof performance !== "undefined" ? performance.now() : Date.now());
    if (this._pokeTimer) { clearTimeout(this._pokeTimer); this._pokeTimer = null; }
    if (this._loopNeeded(gio)) {
      if (this._loopOff) { this._loopOff = false; try { this.graph.resumeAnimation(); } catch (e) {} }
      // Only a one-off redraw keeps it awake: look again when that is over.
      if (!this._veLienTuc && !this._engineOn && !this._tlTimer) {
        this._pokeTimer = setTimeout(() => { this._pokeTimer = null; this._syncLoop(); }, (this._pokeUntil || 0) - gio + 20);
        if (this._pokeTimer && typeof this._pokeTimer.unref === "function") this._pokeTimer.unref();   // node (tests)
      }
    } else if (!this._loopOff) {
      this._loopOff = true;
      try { this.graph.pauseAnimation(); } catch (e) {}
    }
  }
  // Keep the loop running for `ms`: something is about to be drawn that no event of ours announces.
  _poke(ms) {
    const gio = (typeof performance !== "undefined" ? performance.now() : Date.now());
    this._pokeUntil = Math.max(this._pokeUntil || 0, gio + (ms || 300));
    this._syncLoop();
  }

  // --- Điều khiển vòng đời đồ thị ---
  pause() {
    this._parked = true;
    if (this.graph) { try { this.graph.pauseAnimation(); } catch (e) {} }
  }
  wake() {
    this._parked = false;
    this._loopOff = true;       // paused by pause() above, whatever it was before
    this._poke(300);            // one redraw on coming back (the size may have changed meanwhile), then sleep if idle
  }
  resume() { this.wake(); }
  setThinking(active) { this._thinking = !!active; this._nhipVe(); }

  // Mức âm để thổi vào nhịp thở của quả cầu. LÀM TRƠN trước khi dùng.
  //
  // `voice.getLevel()` là trung bình phổ THÔ, đọc lại 60 lần mỗi giây. Tiếng nói vốn lên
  // xuống liên tục, nên con số ấy nhảy loạn từng khung hình; nhân thẳng vào bán kính mỗi
  // chấm là cả quả cầu rung bần bật (chủ dự án 15/09: "nói nhiều lúc quả cầu bị giựt không
  // cố định"). Tệ hơn, ở nhịp NGHĨ biên độ cũ tới 0,46 nên có lúc MỌI chấm cùng co còn 0,54
  // lần - nhìn y như quả cầu tự thu nhỏ lại, đúng cái "tự zoom out ra luôn" anh ấy tả, dù
  // camera không hề đổi.
  //
  // Lên NHANH, xuống CHẬM (như đồng hồ VU của bàn trộn âm): bắt kịp lúc bật tiếng mà không
  // rơi thẳng đứng lúc ngắt quãng giữa hai từ.
  setLevel(l) {
    const raw = Math.max(0, Math.min(1, l || 0));
    const cu = this.level || 0;
    this.level = cu + (raw - cu) * (raw > cu ? 0.30 : 0.06);
    this._nhipVe();
  }

  // Rọi sáng một danh mục (bấm nhãn PERSONAL/SALES... quanh não). null = bỏ lọc.
  spotlightCategory(cat) {
    this._catFilter = cat ? String(cat).replace(/^\d+\s*[-_.]\s*/, "").trim().toLowerCase() : null;
    // Draw the new highlight now (the label that was clicked sits outside the canvas, so no pointer woke the graph).
    try { if (this.graph) this.graph.linkColor(this.graph.linkColor()); } catch (e) {}
    this._poke(300);
    return this._catFilter;
  }

  nodeStats() {
    const d = this.graph ? this.graph.graphData() : { nodes: [], links: [] };
    return { nodes: d.nodes.length, links: d.links.length };
  }

  // --- Timelapse "cuộc đời brain": dựng lại mạng từ trống, note hiện dần theo thời gian tạo ---
  // Node sinh ra được XÓA toạ độ để d3 đặt lại từ đầu → mạng tự nở và co kéo hữu cơ như não
  // đang lớn lên. Link chỉ hiện khi CẢ HAI đầu đã ra đời. Chỉ chạy khi user bấm - không nền.
  // Nhịp CỐ ĐỊNH cho mỗi note (không ép tổng thời gian): não càng dày phim càng dài,
  // xem thư thái như lật album - yêu cầu của chủ, đừng đổi lại thành duration.
  // 160ms/note = chủ chốt sau khi thử 320ms thấy hơi rề.
  startTimelapse(perNoteMs = 160) {
    if (!this.graph || this._tlTimer) return false;
    const d = this.graph.graphData();
    if (!d.nodes.length) return false;
    this._tlFull = { nodes: d.nodes, links: d.links };            // snapshot khôi phục khi dừng/xong
    const order = [...d.nodes].sort((a, b) => (a.t || 0) - (b.t || 0));
    order.forEach(n => { delete n.x; delete n.y; delete n.vx; delete n.vy; n.fx = null; n.fy = null; });
    const total = order.length;
    const present = new Set();
    let i = 0;
    const self = this;
    // Warmup 24 tick sync mỗi lần đổ data sẽ khựng khi lặp hàng trăm lần → tắt trong lúc chiếu
    try { this.graph.warmupTicks(0); } catch (e) {}
    this.graph.graphData({ nodes: [], links: [] });               // não trống - thức giấc
    this._engineOn = true;
    this._tlTimer = setInterval(() => {
      const now = (typeof performance !== "undefined" ? performance.now() : Date.now());
      const n = order[i];
      present.add(n.id); n.__born = now;
      i += 1;
      const links = self._tlFull.links.filter(l => {
        const s = (l.source && l.source.id) || l.source, t = (l.target && l.target.id) || l.target;
        return present.has(s) && present.has(t);
      });
      self.graph.graphData({ nodes: order.slice(0, i), links });
      if (i >= total) self.stopTimelapse();                       // hết phim → trả lại trạng thái thường
    }, perNoteMs);
    this._syncLoop();
    return true;
  }

  stopTimelapse() {
    if (this._tlTimer) { clearInterval(this._tlTimer); this._tlTimer = null; }
    // The dots already stand where the film left them: no warm-up, a short settle (it was 24 steps in one go).
    if (this._tlFull) {
      this._physicsFor(this._tlFull.nodes.length, "settle");
      this.graph.graphData(this._tlFull); this._tlFull = null;
    }
    try { window.dispatchEvent(new Event("javis-timelapse-end")); } catch (e) {}
  }

  get timelapseRunning() { return !!this._tlTimer; }

  addOrUpdate(node, linkTargets, isNew) {
    if (!this.graph || !node || !node.id) return { created: false };
    const d = this.graph.graphData();
    let n = d.nodes.find(x => x.id === node.id);
    if (!n) {
      n = { ...node };
      this._prep([n]);
      n.__born = (typeof performance !== "undefined" ? performance.now() : Date.now());   // hiệu ứng nảy sinh
      // A new note appears beside a note it links to (2026-11-12), not in the middle of the graph.
      const near = (linkTargets || []).map(tid => d.nodes.find(x => x.id === tid)).find(x => x && typeof x.x === "number");
      if (near && typeof n.x !== "number") {
        const h = _hash(n.id);
        n.x = near.x + ((h % 41) - 20); n.y = near.y + (((h >>> 8) % 41) - 20);
      }
      d.nodes.push(n);
    } else {
      Object.assign(n, { label: node.label, path: node.path, links: node.links, color: node.color });
      this._prep([n]);
    }
    // CHỈ nối tới node CÓ THẬT trong đồ thị. force-graph ném "node not found" và chết cả vòng
    // vẽ khi gặp một đầu dây trỏ vào hư không - mà chuyện đó xảy ra thường xuyên một cách rất
    // đời: note bị lọc khỏi đồ thị vì không có liên kết nào, note vừa bị xoá, hay một đoạn mã
    // bash `[[ ... ]]` bị đọc nhầm thành wikilink. Phía server đã thôi gửi rác (bỏ khối mã
    // trước khi dò), nhưng chốt phải có ở đây: một đầu dây hỏng không được phép giết đồ thị.
    const coNode = new Set(d.nodes.map(x => x.id));
    (linkTargets || []).forEach(tid => {
      if (!coNode.has(tid)) return;
      const dup = d.links.some(l => {
        const s = (l.source && l.source.id) || l.source, t = (l.target && l.target.id) || l.target;
        return (s === node.id && t === tid) || (s === tid && t === node.id);
      });
      if (!dup) d.links.push({ source: node.id, target: tid });
    });
    // One note joined a graph that is already laid out: no warm-up (it ran 24 steps over EVERY dot in one go, a
    // freeze on a large brain each time Javis wrote a note), only a short settle.
    this._physicsFor(d.nodes.length, "settle");
    this.graph.graphData({ nodes: d.nodes, links: d.links });
    return { created: !!isNew };
  }
}

window.JavisGraph = JavisGraph;
// For tests: the remembered-layout helpers.
JavisGraph._layoutMemory = { load: _posLoad, save: _posSave, apply: _posApply, KEY: POS_KEY, INDEX: POS_INDEX, KEEP: POS_KEEP, HIT: POS_HIT, SETTLED_TICKS: POS_SETTLED_TICKS, SLOW_RATE: POS_SLOW_RATE };
