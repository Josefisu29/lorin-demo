// model-list.js - DANH SÁCH CHỌN MODEL dùng chung.
//
// Hai chỗ trong app cần đúng một danh sách này: thanh model dưới khung chat
// (model-picker.js) và ô Model trong Cài đặt trợ lý (studio.js). Tới 0.62.2 ô của trợ lý là
// một <select> thuần: không có ô tìm, và nhà chưa cắm key thì bị LỌC MẤT hẳn thay vì hiện ra
// có ổ khoá - nên người dùng không biết là có nhà đó mà chưa mở được (chủ repo báo 21/09).
//
// Đáng lẽ chỉ cần chép markup sang, nhưng chép là hai bản trôi lệch nhau ngay lần sửa sau.
// Nên phần thân (ô tìm + nhóm theo nhà + hàng model + hàng khoá) nằm ở đây, mỗi bên tự lo
// phần riêng của mình: thanh chat thêm hàng Effort và chuyện ghim phiên, trợ lý thêm hàng
// "Mặc định" và hàng "model đang lưu".
//
// CSS vẫn là các lớp .mb-* trong style.css, không đẻ bộ lớp thứ hai.
(function () {
  "use strict";

  const CACHE = {};                     // provider id -> {models, ts}
  const CACHE_MS = 5 * 60 * 1000;       // không giữ catalog cũ suốt cả tab

  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  const T = (k) => (window.t ? window.t(k) : k);
  const IC = (n, o) => (window.ic ? window.ic(n, o) : "");

  // Danh sách model của một nhà. Hỏng thì trả mảng rỗng chứ không ném: một nhà chết không
  // được kéo cả bảng chọn chết theo.
  //
  // Cache HẾT HẠN thì trả ngay bản cũ và làm mới NGẦM (stale-while-revalidate). Trước đây
  // hết 5 phút là lần bấm sau phải chờ trọn một lượt tải live - với Codex (ép refresh=1) là
  // vài giây popup trống trơn, chủ repo báo 27/09 "ấn vào danh sách model load rất chậm".
  const DANG_TAI = {};                  // provider id -> Promise đang bay (gộp các lần gọi trùng)
  // 2026-11-13: an EMPTY answer is not a list to keep. It used to sit in the cache for five minutes and then be
  // handed out once more while the refresh ran, so one slow gateway (or a card fixed a moment ago on the Models
  // page) left the picker saying "no model list" long after the list was there. An empty entry is asked again on
  // the next open, and it carries the server's reason so the picker can say WHY (`why`).
  const EMPTY_MS = 4000;                // only spares the server a burst of repeats while one popup redraws
  let GEN = 0;                          // bumped by clearCache: an answer asked for before it is not kept
  function tai(pid) {
    if (DANG_TAI[pid]) return DANG_TAI[pid];
    // Codex: catalog tĩnh của nó vốn rỗng nên phải ép lấy live.
    const force = pid === "openai-oauth" ? "&refresh=1" : "";
    const gen = GEN;
    const p = fetch("/provider/models?provider=" + encodeURIComponent(pid) + force)
      .then((r) => r.json())
      .then((d) => {
        const ids = (d && d.models) || [];
        return { models: ids, ts: Date.now(), why: ids.length ? "" : String((d && d.error) || "") };
      })
      .catch(() => {
        // The network failed: a list already in hand is worth more than an empty one, and is tried again at the
        // usual pace instead of on every open.
        const c = gen === GEN ? CACHE[pid] : null;
        return c && c.models.length ? { models: c.models, ts: Date.now(), why: "" } : { models: [], ts: Date.now(), why: "" };
      })
      .then((e) => {
        if (DANG_TAI[pid] === p) delete DANG_TAI[pid];
        if (gen === GEN) CACHE[pid] = e;   // the Models page changed a key meanwhile: this answer is the old one
        return e.models;
      });
    DANG_TAI[pid] = p;
    return p;
  }
  async function models(pid) {
    const c = CACHE[pid];
    if (c) {
      const age = Date.now() - c.ts;
      if (!c.models.length) return age >= EMPTY_MS ? tai(pid) : c.models;
      if (age >= CACHE_MS) tai(pid);
      return c.models;
    }
    return tai(pid);
  }
  /** Danh sách đang có sẵn (kể cả đã cũ), hoặc null khi chưa từng tải: để người gọi biết có
   *  phải chờ mạng hay không mà vẽ khung trước. An empty answer that is due for another try counts as "not
   *  loaded", so the caller draws "loading" and asks again instead of repeating the old empty list. */
  function peek(pid) {
    const c = CACHE[pid];
    if (!c) return null;
    if (!c.models.length && Date.now() - c.ts >= EMPTY_MS) return null;
    return c.models;
  }
  /** Why the last answer for this provider was empty (the server's own sentence), or "". */
  function why(pid) { return (CACHE[pid] && CACHE[pid].why) || ""; }

  function clearCache() {
    GEN++;
    Object.keys(CACHE).forEach((k) => delete CACHE[k]);
    Object.keys(DANG_TAI).forEach((k) => delete DANG_TAI[k]);
  }

  // Dựng HTML thân bảng chọn. Trả chuỗi; người gọi tự nhét vào khung của mình rồi tự bắt sự
  // kiện (cả hai bên đều đã có vòng bắt click riêng, gắn thêm ở đây là bắt hai lần).
  //
  // o = {
  //   providers  : [{id, label, configured, ...}] - NGUYÊN danh sách, kể cả nhà chưa cắm key
  //                (chúng hiện ra có ổ khoá, đó mới là điều người dùng cần thấy)
  //   expanded   : id nhà đang sổ ra
  //   filter     : chữ đang lọc
  //   selected   : {provider, model} đang chọn, hoặc null
  //   searchId   : id cho ô tìm (mỗi khung một id, kẻo hai khung cùng mở là trùng)
  //   short      : (id) => nhãn hiển thị của một model; mặc định để nguyên
  //   mark       : (p)  => HTML dán sau tên nhà (thanh chat dùng để đánh dấu model chính)
  //   limit      : trần số model mỗi nhà, mặc định 60
  //   extraTop   : HTML chèn ngay dưới ô tìm (hàng "Mặc định", hàng "model đang lưu"...)
  //   noWait     : chưa có danh sách của nhà đang mở thì vẽ dòng "đang tải" chứ không chờ
  // }
  //
  // Sau khi gọi, o.cho là mảng Promise của những nhà còn đang tải (lúc tìm kiếm, hoặc noWait).
  // Người gọi đợi chúng rồi vẽ lại; KHÔNG chặn cả bảng chờ mạng.
  //
  // Ba luật chủ repo chốt 27/09:
  // - Nhà ĐÃ KẾT NỐI đứng đầu, nhà còn khoá xuống dưới (giữ thứ tự gốc trong mỗi nhóm).
  //   Trước đây nhà khoá xen giữa, phải cuộn qua mới thấy nhà dùng được.
  // - expanded rỗng = không nhà nào sổ ra. Bấm lại tên nhà đang mở là thu lại (người gọi đặt
  //   expanded = ""), để OpenRouter hơn 300 model không chắn lối sang nhà khác.
  // - Có chữ tìm thì tìm TRÊN MỌI nhà đã kết nối, không chỉ nhà đang mở. Chữ trùng tên nhà thì
  //   hiện cả danh sách của nhà đó.
  function nhaDaXep(provs) {
    return provs.map((p, i) => [p, i])
      .sort((x, y) => (Number(!!y[0].configured) - Number(!!x[0].configured)) || (x[1] - y[1]))
      .map((x) => x[0]);
  }

  async function render(o) {
    o = o || {};
    o.cho = [];
    // 0.350.0 (owner, docs/dev/2026-10-model-routing-spec.md 2.6): the chat composer lists connected providers only.
    // Callers that still want the locked rows with their "add a key" way out (the assistant's model list) leave it off.
    const provs = nhaDaXep((o.providers || []).filter((p) => !o.connectedOnly || p.configured));
    const sel = o.selected || {};
    const short = o.short || ((x) => x);
    const mark = o.mark || (() => "");
    const limit = o.limit || 60;
    const q = (o.filter || "").trim().toLowerCase();

    const dauNha = (p, mo) => {
      const on = !!p.configured;
      // Nhà chưa cắm key: KHÔNG có data-prov (bấm vào không sổ ra được) + ổ khoá + một dòng
      // chỉ đúng chỗ đi mở khoá. Đây chính là phần ô <select> cũ làm mất.
      return `<div class="mb-prov ${on ? "" : "off"}" data-prov="${on ? esc(p.id) : ""}">`
        + `<span>${p.label}${mark(p)}</span>`
        + `<span>${on ? IC(mo ? "chevron-down" : "chevron-right")
                      : IC("lock", { cls: "ic-dim" })}</span></div>`
        + (on ? "" : `<div class="mb-link" data-goto="models">+ ${esc(T("mpick.add_key"))}</div>`);
    };
    const hangModel = (p, ids) => {
      let h = "";
      for (const id of ids.slice(0, limit)) {
        const cur = p.id === sel.provider && id === sel.model;
        h += `<div class="mb-item ${cur ? "cur" : ""}" data-prov="${esc(p.id)}" `
          + `data-model="${esc(id)}"><span class="tick">`
          + `${cur ? IC("check", { cls: "ic-ok" }) : ""}</span><span>${esc(short(id))}</span></div>`;
      }
      if (ids.length > limit) {
        h += `<div class="mb-empty">${esc(T("mpick.more").replace("{n}", String(ids.length - limit)))}</div>`;
      }
      return h;
    };
    const dangTai = `<div class="mb-empty pg-loading">${esc(T("mpick.loading"))}</div>`;
    // No list: say why (the server's sentence: wrong address, refused key, a seller that lists nothing) and give
    // the way out, the Models page, where the address is fixed or a model name is typed. Both callers already send
    // a click on [data-goto] to that page.
    const khongCoDanhSach = (p) => {
      const lyDo = why(p.id);
      return `<div class="mb-empty">${esc(T("mpick.no_list"))}${lyDo ? " " + esc(lyDo) : ""}</div>`
        + `<div class="mb-link" data-goto="models">${esc(T("mpick.fix_on_models"))}</div>`;
    };

    let html = `<input class="mb-search" id="${esc(o.searchId || "mlSearch")}" `
      + `placeholder="${esc(T("mpick.search_ph"))}" value="${esc(o.filter || "")}">`;
    html += o.extraTop || "";

    if (q) {
      let thay = 0;
      for (const p of provs) {
        const trungTen = (p.label || "").toLowerCase().includes(q) || (p.id || "").toLowerCase().includes(q);
        if (!p.configured) {
          if (trungTen) { html += dauNha(p, false); thay++; }
          continue;
        }
        // Search reads what is in hand, an empty answer included: asking a dead gateway again on every keystroke
        // would flash "loading" under the search box. Opening the provider is what asks again.
        const ds = CACHE[p.id] ? CACHE[p.id].models : null;
        if (!ds) {
          o.cho.push(models(p.id));
          html += dauNha(p, true) + dangTai;
          thay++;
          continue;
        }
        if (Date.now() - (CACHE[p.id].ts || 0) >= CACHE_MS) models(p.id);   // làm mới ngầm
        const ids = trungTen ? ds : ds.filter((id) => id.toLowerCase().includes(q));
        if (!ids.length) continue;
        html += dauNha(p, true) + hangModel(p, ids);
        thay++;
      }
      if (!thay) html += `<div class="mb-empty">${esc(T("mpick.no_match"))}</div>`;
      return html;
    }

    for (const p of provs) {
      const mo = !!o.expanded && p.id === o.expanded;
      html += dauNha(p, mo);
      if (!p.configured || !mo) continue;
      // noWait: chưa có danh sách thì vẽ dòng "đang tải" thay vì bắt cả bảng chờ mạng.
      if (o.noWait && !peek(p.id)) {
        o.cho.push(models(p.id));
        html += dangTai;
        continue;
      }
      const ids = await models(p.id);
      if (!ids.length) html += khongCoDanhSach(p);
      html += hangModel(p, ids);
    }
    return html;
  }

  window.JavisModelList = { models, peek, why, render, clearCache };
})();
