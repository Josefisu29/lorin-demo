/* file-editor.js - Khung sua file bung GIUA MAN HINH, goi tu link file trong chat.
   window.JavisEditFile(brainRelPath): mo modal doc /files/read, sua text (.md co nut gat
   Nguon/Xem), luu /files/write, xem truoc anh/pdf, file khac cho tai.

   Doc lap: tu chen CSS, gan modal vao <body> nen chay duoc tu MOI trang (chat toan trang,
   chat HUD, trang Tep tin) khong phu thuoc layout. Khong dung 2 editor cu (khong so vo).

   Quy uoc duong dan: link trong chat la TUONG DOI GOC BRAIN. /files/read nhan ca 2 quy uoc
   nhung /files/write chi tinh theo TRAN DUYET -> phai ghep tien to 'home' (nha cua brain) truoc
   khi doc/ghi de LUU dung cho (localhost tran = ca o dia). Tien to lay tu /files/list (truong home).

   Ghi chu: KHONG dung ky tu em dash o bat ky dau. */
(function () {
  "use strict";

  // Chữ hiện ra lấy từ từ điển. Trong trình duyệt là window.t (i18n/index.js nạp trước mọi
  // module này); dưới node - nơi test require() thẳng file này - `window` CHƯA KHAI BÁO nên
  // đọc window.t là ReferenceError chứ không phải undefined, phải hỏi bằng typeof. Ở đó đọc
  // thẳng vi.json để hàm vẫn trả về chữ thật, không phải mã khoá trần.
  function tw(khoa, bien) {
    if (typeof window !== "undefined" && window.t) return window.t(khoa, bien);
    try {
      var s = require("./i18n/vi.json")[khoa] || khoa;
      return String(s).replace(/\{(\w+)\}/g, function (m, ten) {
        return (bien && bien[ten] != null) ? String(bien[ten]) : m;
      });
    } catch (e) { return khoa; }
  }

  // (i) button from info-tip.js; without it (node tests) the explanation is drawn inline.
  function infoBtn() { var J = typeof window !== "undefined" && window.JavisInfo; return J ? J.btn(tw("info.more")) : ""; }
  function infoBody(html) {
    var J = typeof window !== "undefined" && window.JavisInfo;
    return J ? J.body(html) : '<div class="info-body">' + html + "</div>";
  }

  var IMG = [".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico"];

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function brain() { return window.currentBrainPath ? (window.currentBrainPath() || "brain") : "brain"; }
  function extOf(p) {
    var b = String(p || "").replace(/\/+$/, "").split("/").pop();
    var i = b.lastIndexOf(".");
    return i >= 0 ? b.slice(i).toLowerCase() : "";
  }
  function baseOf(p) { return String(p || "").replace(/\/+$/, "").split("/").pop(); }

  // --- tien to 'home' (nha brain) tinh theo tran duyet, cache theo brain ---
  var homeCache = {};
  function getHome(b) {
    if (homeCache[b] != null) return Promise.resolve(homeCache[b]);
    return fetch("/files/list?brain=" + encodeURIComponent(b))
      .then(function (r) { return r.ok ? r.json() : {}; })
      .then(function (d) { var h = (d && d.home) || ""; homeCache[b] = h; return h; })
      .catch(function () { return ""; });   // that bai: tien to rong (dung khi tran == brain)
  }
  // brainRel -> path theo tran duyet (ghep home). Da la path tran thi giu nguyen.
  function ceilPath(home, brainRel) {
    var rel = String(brainRel || "").replace(/\\/g, "/").replace(/^\.?\//, "").replace(/\/+$/, "");
    var h = String(home || "").replace(/\\/g, "/").replace(/^\.?\//, "").replace(/\/+$/, "");
    if (!h || rel === h || rel.indexOf(h + "/") === 0) return rel;
    return h + "/" + rel;
  }
  function rawUrl(b, ceilRel, dl) {
    return "/files/raw?brain=" + encodeURIComponent(b) + "&path=" + encodeURIComponent(ceilRel) + (dl ? "&dl=1" : "");
  }

  // ---------------------------------------------------------------- CSS (chen 1 lan)
  function injectCss() {
    if (document.getElementById("jvfe-css")) return;
    var s = document.createElement("style");
    s.id = "jvfe-css";
    s.textContent =
      ".jvfe-modal{position:fixed;inset:0;z-index:3000;display:none;align-items:center;justify-content:center;" +
      "background:rgba(0,0,0,.55);backdrop-filter:blur(3px);padding:24px;box-sizing:border-box}" +
      ".jvfe-modal.open{display:flex;animation:jvfeIn .16s ease}" +
      "@keyframes jvfeIn{from{opacity:.3}to{opacity:1}}" +
      ".jvfe-card{width:min(920px,94vw);max-height:88vh;display:flex;flex-direction:column;" +
      "background:var(--bg2);border:1px solid var(--border);border-radius:14px;" +
      "box-shadow:0 24px 70px rgba(0,0,0,.6);overflow:hidden}" +
      ".jvfe-head{display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid var(--border)}" +
      ".jvfe-title{font-weight:600;font-size:14px;color:var(--text);flex:1;overflow:hidden;" +
      "text-overflow:ellipsis;white-space:nowrap;display:flex;align-items:center;gap:7px}" +
      ".jvfe-actions{display:flex;gap:6px;flex:none;align-items:center;flex-wrap:wrap}" +
      // Man hep: thanh nut trum khong du cho -> nut Dong bi day ra ngoai va nguoi dung
      // mac ket trong trinh sua. Cho phep xuong dong va giu nut Dong luon o cuoi.
      //
      // Va tu 0.55.57, o dien thoai thi TOAN MAN HINH thay vi mot the noi giua nen mo. Chu repo
      // bao 2026-09-08: "mo file.txt trong khung chat hoac khung .md thi khong an nut tat duoc,
      // khong co cach nao back lai man hinh cu". The noi giua duoc can theo 88vh cua man hinh
      // DAY DU, ma ban phim ao chiem gan nua man - nen dau the (cho co nut Dong) bi day len
      // ngoai vung nhin thay, va nguoi dung khong con duong ra. Dan the vao bon canh thi dau
      // the luon nam dung mep tren, ban phim che gi thi che.
      "@media(max-width:700px){" +
        // 0.65.30: dan kin man thi chua VUNG AN TOAN cua iPhone mo tu man hinh chinh (thanh
        // trang thai trong suot de len dau the, che mat nut Dong).
        ".jvfe-modal{padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) " +
        "env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px);align-items:stretch;justify-content:stretch}" +
        // Cao theo khung (da tru vung an toan) chu khong 100dvh, keo the tran xuong duoi day.
        ".jvfe-card{width:100%;max-width:none;height:auto;align-self:stretch;max-height:none;" +
        "border-radius:0;border:0}" +
        // Dau the dinh o tren ke ca khi than cuon: nut Dong khong bao gio troi khoi tam tay.
        ".jvfe-head{position:sticky;top:0;z-index:2;background:var(--bg2);flex-wrap:wrap;gap:6px}" +
        ".jvfe-actions{width:100%;justify-content:flex-end}.jvfe-actions .icon{order:99}" +
        // 32px la co chuot; ngon tay can 40px tro len moi bam trung chac.
        ".jvfe-btn.icon{width:40px;height:40px}.jvfe-btn{padding:8px 12px}" +
        ".jvfe-text{min-height:0}" +
      "}" +
      // Khoa cuon nen khi dang mo. Lop nay duoc gan tu 0.9.x nhung CHUA BAO GIO co luat CSS
      // nao - tuc trang phia sau van cuon duoc duoi ngon tay, dung kieu hong am tham.
      "body.jvfe-open{overflow:hidden}" +
      ".jvfe-seg{display:flex;gap:4px;margin-right:4px}" +
      ".jvfe-btn{background:var(--bg3);border:1px solid var(--border);color:var(--text2);" +
      "border-radius:7px;padding:5px 11px;font-size:13px;cursor:pointer;font-family:inherit}" +
      ".jvfe-btn:hover{color:var(--text-hi);border-color:var(--accent)}" +
      ".jvfe-btn.active{color:var(--accent);border-color:var(--accent)}" +
      ".jvfe-btn.icon{width:32px;height:32px;padding:0;font-size:14px}" +
      ".jvfe-btn.saved{color:var(--green);border-color:var(--green)}" +
      // Thanh link chia se. Xuong dong duoc vi tren dien thoai mot hang bon mon khong du cho,
      // va o nhap link chiem het be ngang con lai de nguoi ta nhin thay CA duong link.
      ".jvfe-share{padding:10px 14px;border-bottom:1px solid var(--border);background:var(--bg3);" +
      "font-size:13px;color:var(--text2)}" +
      ".jvfe-share-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}" +
      ".jvfe-share-url{flex:1 1 220px;min-width:0;padding:7px 10px;border-radius:8px;" +
      "border:1px solid var(--border);background:var(--bg2);color:var(--text-hi);font-size:13px}" +
      ".jvfe-body{flex:1;min-height:0;overflow:auto;background:var(--bg);display:flex;flex-direction:column}" +
      // .html: preview pane (white page, like a browser tab) or the code pane, one at a time.
      ".jvfe-html{flex:1;min-height:52vh;display:flex;flex-direction:column}" +
      ".jvfe-html-prev,.jvfe-html-src{flex:1;min-height:0;display:flex;flex-direction:column}" +
      ".jvfe-html.mode-preview .jvfe-html-src,.jvfe-html.mode-code .jvfe-html-prev{display:none}" +
      ".jvfe-html-src .jvhl{flex:1;display:flex;flex-direction:column}" +
      ".jv-html-frame{flex:1;width:100%;min-height:52vh;border:0;background:#fff;display:block}" +
      ".jvfe-text{flex:1;min-height:52vh;width:100%;box-sizing:border-box;border:0;outline:none;resize:none;" +
      "background:var(--bg);color:var(--text);font-family:ui-monospace,Menlo,Consolas,monospace;" +
      "font-size:13.5px;line-height:1.6;padding:16px}" +
      ".jvfe-prev{padding:16px 20px;color:var(--text);line-height:1.7;overflow:auto}" +
      ".jvfe-prev h1,.jvfe-prev h2,.jvfe-prev h3,.jvfe-prev h4{margin:.7em 0 .35em;line-height:1.3}" +
      ".jvfe-prev pre{background:var(--bg2);padding:10px 12px;border-radius:8px;overflow:auto}" +
      ".jvfe-prev code{background:var(--bg2);padding:1px 5px;border-radius:4px;font-size:.92em}" +
      ".jvfe-prev pre code{background:none;padding:0}" +
      ".jvfe-prev img{max-width:100%;height:auto;border-radius:8px}" +
      ".jvfe-prev table{border-collapse:collapse}.jvfe-prev th,.jvfe-prev td{border:1px solid var(--border);padding:5px 9px}" +
      ".jvfe-note{padding:18px;color:var(--text3);font-size:14px;line-height:1.6}" +
      ".jvfe-note a{color:var(--accent)}" +
      ".jvfe-img{padding:16px;text-align:center;overflow:auto}" +
      ".jvfe-img img{max-width:100%;height:auto;border-radius:8px}" +
      ".jvfe-frame{width:100%;height:72vh;border:0;background:#fff;display:block}" +
      ".jvfe-pdf{max-height:72vh;overflow:auto;-webkit-overflow-scrolling:touch}";
    document.head.appendChild(s);
  }

  // Man cam ung (dien thoai/tablet) hay khong. Quyet dinh MOT viec duy nhat nhung quan trong:
  // co tu dat con tro vao o soan khi vua mo file hay khong.
  //
  // Tren dien thoai, focus la ban phim ao bat len ngay lap tuc va an mat nua man hinh, keo theo
  // trinh duyet tu cuon o soan vao giua - dau the cung nut Dong bi day khuat. Nguoi dung mo mot
  // file .txt de DOC lai bi nem thang vao che do go chu, roi khong thoat ra duoc. Tren may tinh
  // thi focus san van dung: go duoc ngay, va luon co phim Esc lam duong lui.
  function laCamUng() {
    try {
      return window.matchMedia("(pointer: coarse)").matches || window.innerWidth <= 860;
    } catch (e) { return false; }
  }
  function focusNeuDuocPhep(el) {
    if (!el || laCamUng()) return;
    setTimeout(function () { try { el.focus(); } catch (e) {} }, 30);
  }

  // ---------------------------------------------------------------- modal (dung 1 lan, tai su dung)
  var modal = null, card = null, elTitle = null, elActions = null, elBody = null, curSave = null;
  var daDayLichSu = false;   // da chen mot buoc lich su cho nut Back chua
  // Autosave and dictation mic of the open text file (editor-autosave.js, editor-dictate.js, 2026-11-09).
  var curAuto = null, curMic = null;
  // Detach both from the file being left: the mic first, so words still being heard are in what close() writes.
  function dropAssist() {
    var a = curAuto, m = curMic;
    curAuto = null; curMic = null;
    if (m) { try { m.destroy(); } catch (e) {} }
    if (a) { try { a.close(); } catch (e) {} }
  }
  var elShareModal = null;   // thanh hien link chia se CUA MODAL nay (an mac dinh)

  function build() {
    if (modal) return;
    injectCss();
    modal = document.createElement("div");
    modal.className = "jvfe-modal";
    modal.innerHTML =
      '<div class="jvfe-card" role="dialog" aria-modal="true">' +
        '<div class="jvfe-head"><span class="jvfe-title"></span><span class="jvfe-actions"></span></div>' +
        '<div class="jvfe-share" hidden></div>' +
        '<div class="jvfe-body"></div>' +
      "</div>";
    document.body.appendChild(modal);
    card = modal.querySelector(".jvfe-card");
    elTitle = modal.querySelector(".jvfe-title");
    elActions = modal.querySelector(".jvfe-actions");
    elBody = modal.querySelector(".jvfe-body");
    elShareModal = modal.querySelector(".jvfe-share");
    // Bam nen mo -> dong. Bat CA hai su kien: iOS khong phai luc nao cung sinh mousedown cho
    // mot the <div> tron, nen chi nghe mousedown la tren dien thoai bam nen khong an gi.
    modal.addEventListener("mousedown", function (e) { if (e.target === modal) close(); });
    modal.addEventListener("click", function (e) { if (e.target === modal) close(); });
    // Nut Back cua dien thoai (va cu vuot canh man hinh) phai dong trinh sua, khong phai thoat
    // ca app. Truoc day khong co nhanh nay nen nguoi dung bam Back la bay ra khoi Javis - mot
    // duong "lui" ma khong ai muon. Ca app khong dung History API o cho nao khac, nen chen mot
    // buoc o day khong dam vao dieu huong nao.
    window.addEventListener("popstate", function () {
      if (!isOpen()) return;
      daDayLichSu = false;      // buoc vua bi go chinh la buoc minh chen
      close();
    });
    document.addEventListener("keydown", function (e) {
      if (!isOpen()) return;
      if (e.key === "Escape") { e.stopPropagation(); close(); return; }
      if ((e.ctrlKey || e.metaKey) && (e.key === "s" || e.key === "S")) {
        e.preventDefault(); e.stopPropagation(); if (curSave) curSave();
      }
    }, true);
  }
  function isOpen() { return modal && modal.classList.contains("open"); }
  function close() {
    if (!modal) return;
    // Closing (X, Esc, the backdrop, a Back swipe) writes the words typed since the last autosave first.
    dropAssist();
    modal.classList.remove("open");
    elBody.innerHTML = ""; elActions.innerHTML = ""; curSave = null;   // don iframe/textarea
    if (elShareModal) { elShareModal.innerHTML = ""; elShareModal.hidden = true; }
    document.body.classList.remove("jvfe-open");
    // Dong bang nut X / Esc / bam nen: nha luon buoc lich su da chen, khong thi nguoi dung phai
    // bam Back mot cai "khong lam gi" truoc khi thuc su roi trang.
    if (daDayLichSu) {
      daDayLichSu = false;
      try { history.back(); } catch (e) {}
    }
  }
  function closeBtn() {
    var b = document.createElement("button");
    b.className = "jvfe-btn icon"; b.innerHTML = ic("x"); b.title = tw("fedit.close_esc");
    b.onclick = close; return b;
  }

  // ---------------------------------------------------------------- mo file
  // Bung modal voi mot tieu de, than "dang mo", va chen MOT buoc lich su de nut Back (va cu
  // vuot canh man hinh) dong modal thay vi thoat app. Dung chung cho open() va openPdf().
  function moModal(tieuDe) {
    build();
    elTitle.innerHTML = esc(tieuDe);
    dropAssist();
    elActions.innerHTML = ""; elBody.innerHTML = '<div class="jvfe-note">' + esc(tw("fedit.opening")) + "</div>";
    curSave = null;
    if (elShareModal) { elShareModal.innerHTML = ""; elShareModal.hidden = true; }
    modal.classList.add("open");
    document.body.classList.add("jvfe-open");
    if (!daDayLichSu) {
      try { history.pushState({ jvfe: 1 }, ""); daDayLichSu = true; } catch (e) {}
    }
  }
  function open(brainRel) {
    if (!brainRel) return;
    var b = brain();
    moModal(baseOf(brainRel));

    var ext = extOf(brainRel);
    getHome(b).then(function (home) {
      var ceil = ceilPath(home, brainRel);
      // Anh / PDF: xem truoc thang qua /files/raw (khong doc dang text).
      if (IMG.indexOf(ext) >= 0) { renderImage(b, ceil, brainRel); return; }
      if (ext === ".pdf") { renderPdf(rawUrl(b, ceil), baseOf(brainRel)); return; }
      // Con lai: doc noi dung.
      fetch("/files/read?brain=" + encodeURIComponent(b) + "&path=" + encodeURIComponent(ceil))
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          if (!isOpen()) return;
          if (!res.ok || res.d.error) { renderError(b, ceil, brainRel, res.d && res.d.error); return; }
          if (res.d.editable) renderEditor(b, ceil, brainRel, res.d);
          else renderReadonly(b, ceil, brainRel, res.d);
        })
        .catch(function () { if (isOpen()) renderError(b, ceil, brainRel, null); });
    });
  }

  function renderImage(b, ceil, brainRel) {
    elActions.appendChild(shareBtn(b, ceil)); elActions.appendChild(openLink(b, ceil)); elActions.appendChild(dlLink(b, ceil)); elActions.appendChild(closeBtn());
    elBody.innerHTML = '<div class="jvfe-img"><img src="' + esc(rawUrl(b, ceil)) + '" alt="' + esc(baseOf(brainRel)) + '"></div>';
  }
  // 0.332.0: same as the pinned editor (console.js): the PDF scrolls in its own box, and a phone gets a
  // floating close button, because Safari on an iPhone grows a PDF iframe to the whole document.
  //
  // Nhan URL (khong phai duong dan brain) de mo duoc ca link PDF trong chat (openPdf ben duoi).
  // iPhone/iPad: KHONG co nut "Mo tab moi" va nut Tai ve khong phai link. App cai ra man hinh
  // chinh ma di theo mot link /files/raw (ke ca target="_blank") thi iPad thay CA app bang trang
  // PDF, khong con duong quay lai (video chu repo 05/11/2026). Tai ve o day = bang chia se iOS.
  function renderPdf(url, ten) {
    if (laIOS()) elActions.appendChild(taiVeIOS(url, ten));
    else {
      elActions.appendChild(openLinkUrl(url)); elActions.appendChild(dlLinkUrl(url, ten));
    }
    elActions.appendChild(closeBtn());
    elBody.innerHTML = '<div class="jvfe-pdf"><iframe class="jvfe-frame" src="' + esc(url) + '"></iframe></div>';
    var x = closeBtn();
    x.className = "pdf-float-close";
    x.setAttribute("aria-label", tw("fedit.close_esc"));
    elBody.appendChild(x);
  }
  function renderReadonly(b, ceil, brainRel, d) {
    elActions.appendChild(openLink(b, ceil)); elActions.appendChild(dlLink(b, ceil)); elActions.appendChild(closeBtn());
    elBody.innerHTML = '<div class="jvfe-prev"><pre style="white-space:pre-wrap;margin:0">' + esc(d.content || "") + "</pre></div>";
  }
  function renderError(b, ceil, brainRel, msg) {
    elActions.innerHTML = ""; elActions.appendChild(closeBtn());
    elBody.innerHTML = '<div class="jvfe-note">' + esc(msg || tw("fedit.read_err")) +
      ' - <a href="' + esc(rawUrl(b, ceil)) + '" target="_blank" rel="noopener">' + esc(tw("fedit.open_tab")) + "</a>" +
      ' · <a href="' + esc(rawUrl(b, ceil, 1)) + '">' + esc(tw("common.download")) + "</a></div>";
  }
  function dlLink(b, ceil) {
    var a = document.createElement("a");
    a.href = rawUrl(b, ceil, 1); a.title = tw("common.download");
    a.innerHTML = '<button class="jvfe-btn icon" type="button">⇩</button>';
    return a;
  }
  // Cung nut Tai ve nhung tu mot URL bat ky: duong /files/raw, /upload/raw thi them dl=1 de may
  // chu ep tai kem dung ten file; URL khac dua thuoc tinh download.
  function dlLinkUrl(url, ten) {
    var a = document.createElement("a");
    a.href = /\/(files|upload)\/raw\?/.test(url) ? url + "&dl=1" : url;
    a.download = ten || ""; a.title = tw("common.download");
    a.innerHTML = '<button class="jvfe-btn icon" type="button">⇩</button>';
    return a;
  }
  function openLinkUrl(url) {
    var a = document.createElement("a");
    a.href = url; a.target = "_blank"; a.rel = "noopener"; a.title = tw("fedit.open_tab");
    a.innerHTML = '<button class="jvfe-btn icon" type="button">↗</button>';
    return a;
  }

  // iPadOS 13+ khai minh la Mac, chi lo ra qua maxTouchPoints (cung luat voi chat-render.js).
  function laIOS() {
    try {
      var ua = navigator.userAgent || "";
      return /iP(hone|ad|od)/.test(ua) || (navigator.platform === "MacIntel" && (navigator.maxTouchPoints || 0) > 1);
    } catch (e) { return false; }
  }
  // Nut Tai ve tren iPhone/iPad: bang chia se cua iOS ("Luu vao Tep", gui qua Zalo...). Bang do
  // chi mo duoc NGAY trong cu bam, nen file duoc tai san thanh File luc khung xem vua mo (cung
  // cach khung xem anh lam). Bam khi file chua ve kip: doi file ve roi thu mo bang; iOS tu choi
  // vi da qua cu bam thi bao bam lai, luc do file da san. Khong co bang chia se (iOS rat cu)
  // thi moi mo cua so moi, la cach duy nhat con lai.
  function taiVeIOS(url, ten) {
    var btn = document.createElement("button");
    btn.className = "jvfe-btn icon"; btn.type = "button"; btn.innerHTML = "⇩";
    btn.title = tw("common.download"); btn.setAttribute("aria-label", tw("common.download"));
    var tep = null, cho = null;
    ten = String(ten || "").split("?")[0] || "file.pdf";
    if (!/\.[a-z0-9]{2,5}$/i.test(ten)) ten += ".pdf";
    try {
      if (typeof fetch === "function" && typeof File === "function" && navigator.canShare) {
        cho = fetch(url, { credentials: "same-origin" }).then(function (r) {
          if (!r.ok) throw new Error("http " + r.status);
          return r.blob();
        }).then(function (bl) {
          var f = new File([bl], ten, { type: bl.type || "application/pdf" });
          if (navigator.canShare({ files: [f] })) tep = f;
          return tep;
        }).catch(function () { return null; });
      }
    } catch (e) { cho = null; }
    function moCuaSo() { window.open(url, "_blank"); }
    function chiaSe(f) {
      navigator.share({ files: [f] }).catch(function (err) {
        if (err && err.name === "AbortError") return;        // nguoi dung tu dong bang chia se
        if (err && err.name === "NotAllowedError") { baoBamLai(); return; }
        moCuaSo();
      });
    }
    function baoBamLai() {
      var c = tw("fedit.dl_tap_again");
      if (window.JavisToast) window.JavisToast(c); else { try { alert(c); } catch (e) {} }
    }
    btn.onclick = function () {
      if (tep && navigator.share) { chiaSe(tep); return; }
      if (!cho || !navigator.share) { moCuaSo(); return; }
      btn.disabled = true;
      cho.then(function (f) {
        btn.disabled = false;
        if (f) chiaSe(f); else moCuaSo();
      });
    };
    return btn;
  }
  // Nut "Mo tab moi": xem file dung nhu trinh duyet hien no (vd .html chay that). Bam link
  // file trong chat gio mo THANG trinh sua thay vi tai ve, nen ca hai y dinh cu - xem va tai -
  // phai co san ngay tren thanh nay. Trinh sua dinh (console.js) da co doi nut nay tu truoc.
  function openLink(b, ceil) {
    var a = document.createElement("a");
    a.href = rawUrl(b, ceil); a.target = "_blank"; a.rel = "noopener"; a.title = tw("fedit.open_tab");
    a.innerHTML = '<button class="jvfe-btn icon" type="button">↗</button>';
    return a;
  }

  // ---- Nut CHIA SE: mot duong link ai cam cung xem duoc, KHONG can dang nhap ----
  // Trang mo ra la BAN HOAN THIEN chu khong phai ma nguon: .html chay that, .md hien dam
  // nghieng va anh. Phia may chu lo phan dung trang (server/share_render.py) va lo cach ly
  // noi dung (header sandbox) - o day chi lo cai nut.
  //
  // Link tro toi FILE THAT chu khong phai ban chup: sua file thi nguoi xem tai lai la thay
  // ban moi. Chu du an chon vay ngay 18/09.
  //
  // `hostEl` la cho VE THANH LINK ra. De trong thi dung thanh cua modal nay. Trinh sua dinh
  // (noteEditor trong console.js) la MOT khung khac han, khong dung modal nay, nen no truyen
  // o chua cua no vao - nguoi dung mo file o khung nao cung phai thay nut Chia se, chu khong
  // phai doan xem minh dang o khung nao. `lop` doi ten lop nut cho hop thanh cong cu so tai.
  function shareBtn(b, ceil, hostEl, lop) {
    injectCss();   // goi tu khung khac: modal chua dung nen CSS .jvfe-share chua duoc chen
    var btn = document.createElement("button");
    btn.className = (lop == null ? "jvfe-btn icon" : lop); btn.type = "button";
    // "share-2" (ba nut tron noi nhau) chu KHONG phai "link": trong trinh sua .md, thanh dinh
    // dang markdown ngay ben duoi da co nut Chen lien ket dung dung ic("link"), nen hai cai
    // giong het nhau - chu du an bao 18/09: "trung voi icon them link mat roi". Icon nay vua
    // duoc them vao icons.manifest.json va sinh lai bo vendor.
    // Khong de emoji lam duong lui: giao dien dashboard cam emoji (test_icons.py canh).
    btn.innerHTML = ic("share-2");
    btn.title = tw("fedit.share_title");
    // Da co link san thi nut sang len ngay tu luc mo file, de nguoi dung biet file nay DANG
    // duoc chia se ma khong phai bam thu.
    fetch("/share/of?brain=" + encodeURIComponent(b) + "&path=" + encodeURIComponent(ceil))
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d && d.share) btn.classList.add("active"); })
      .catch(function () {});
    btn.onclick = function () {
      btn.disabled = true;
      fetch("/share/create", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ brain: b, path: ceil }),
      })
        .then(function (r) { return r.json().catch(function () { return {}; }); })
        .then(function (d) {
          btn.disabled = false;
          if (!d || !d.ok) { veThanhShare(null, d && d.error); return; }
          btn.classList.add("active");
          veThanhShare(location.origin + d.path, "", d.token);
        })
        .catch(function () { btn.disabled = false; veThanhShare(null, tw("app.err_net")); });
    };
    return btn;

    function veThanhShare(url, loi, token) {
      var elShare = hostEl || elShareModal;
      if (!elShare) return;
      elShare.innerHTML = "";
      elShare.hidden = false;
      if (!url) {
        elShare.textContent = loi || tw("app.err_cap");
        return;
      }
      var o = document.createElement("input");
      o.type = "text"; o.readOnly = true; o.value = url; o.className = "jvfe-share-url";
      o.onclick = function () { o.select(); };
      var chep = document.createElement("button");
      chep.className = "jvfe-btn"; chep.type = "button"; chep.textContent = tw("common.copy");
      chep.onclick = function () {
        // navigator.clipboard chi co tren HTTPS (hoac localhost). Tren HTTP trong mang LAN no
        // KHONG ton tai, nen phai co duong lui bang execCommand - khong thi bam Chep im lang
        // khong lam gi, dung canh nguoi dung thay "hong ma khong bao".
        var xong = function () {
          chep.textContent = tw("common.copied");
          setTimeout(function () { chep.textContent = tw("common.copy"); }, 1400);
        };
        if (navigator.clipboard && window.isSecureContext) {
          navigator.clipboard.writeText(url).then(xong).catch(function () { o.select(); });
        } else {
          o.select();
          try { document.execCommand("copy"); xong(); } catch (e) {}
        }
      };
      var mo = document.createElement("a");
      mo.href = url; mo.target = "_blank"; mo.rel = "noopener";
      mo.innerHTML = '<button class="jvfe-btn" type="button">' + esc(tw("fedit.share_open")) + "</button>";
      var thu = document.createElement("button");
      thu.className = "jvfe-btn"; thu.type = "button"; thu.textContent = tw("fedit.share_revoke");
      thu.onclick = function () {
        thu.disabled = true;
        fetch("/share/revoke", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token: token }),
        }).then(function () {
          btn.classList.remove("active");
          elShare.innerHTML = "";
          elShare.textContent = tw("fedit.share_revoked");
          setTimeout(function () { elShare.hidden = true; elShare.textContent = ""; }, 1800);
        }).catch(function () { thu.disabled = false; });
      };
      var hang = document.createElement("div");
      hang.className = "jvfe-share-row";
      hang.appendChild(o); hang.appendChild(chep); hang.appendChild(mo); hang.appendChild(thu);
      // Who can see the link and how edits show up: behind the (i) at the end of the row.
      hang.insertAdjacentHTML("beforeend", infoBtn());
      elShare.appendChild(hang);
      elShare.insertAdjacentHTML("beforeend", infoBody(esc(tw("fedit.share_note"))));
    }
  }

  // Nut Luu (dung getContent de lay noi dung THAT theo che do dang mo) + Tai + Dong.
  // 2026-11-09: the file also saves itself a moment after typing stops (editor-autosave.js), and the button shows
  // that state. `o`: original (the file as read), sources (input elements), apply(text) for a restored draft,
  // mic {host, target} for the dictation button (prose files only).
  function appendSaveAndClose(b, ceil, getContent, o) {
    o = o || {};
    var save = document.createElement("button");
    save.className = "jvfe-btn"; save.innerHTML = ic("save") + " " + esc(tw("common.save")); save.title = tw("fedit.save_title");
    function write(content, opt) {
      var fd = new FormData();
      fd.append("brain", b); fd.append("path", ceil); fd.append("content", content);
      return fetch("/files/write", { method: "POST", body: fd, keepalive: !!(opt && opt.keepalive) })
        .then(function (r) { return r.json().catch(function () { return {}; }); })
        .then(function (r) { return !!(r && r.ok); }, function () { return false; });
    }
    function paint(st) {
      save.classList.toggle("saved", st === "saved");
      save.disabled = false;
      save.innerHTML = st === "saved" ? ic("check", { cls: "ic-ok" }) + " " + esc(tw("fedit.saved"))
        : st === "saving" ? ic("save") + " " + esc(tw("cs.ne_saving"))
        : st === "error" ? ic("triangle-alert", { cls: "ic-warn" }) + " " + esc(tw("cs.ne_save_err"))
        : ic("save") + " " + esc(tw("common.save"));
      save.title = tw(st === "error" ? "cs.ne_save_err_title" : "fedit.save_title");
    }
    var AS = typeof window !== "undefined" && window.JavisAutosave;
    curSave = function () { paint("saving"); return write(getContent()).then(function (ok) { paint(ok ? "saved" : "error"); return ok; }); };
    // Started at once, or by the caller once the editor shows its final form (`deferAuto`, the .md editor switching to
    // the rendered view): the text counted as saved must be read in that form, or opening and closing a note would
    // rewrite it.
    function startAuto() {
      if (!AS || o.original == null || curAuto || !save.isConnected) return;
      var auto = AS.attach({
        key: b + "::" + ceil,
        original: o.original,
        get: getContent,
        baseline: typeof o.baseline === "function" ? o.baseline() : o.baseline,
        save: write,
        sources: o.sources || [],
        apply: o.apply,
        onStatus: paint,
      });
      curAuto = auto;
      curSave = function () { return auto.flush(); };
    }
    save.onclick = function () { if (curSave) curSave(); };
    elActions.appendChild(save);
    var ED = typeof window !== "undefined" && window.JavisEditorDictate;
    if (ED && o.mic) {
      curMic = ED.attach({ host: o.mic.host, target: o.mic.target, onChange: function () { if (curAuto) curAuto.poke(); } });
      if (o.mic.host === elActions) { curMic.button.classList.add("jvfe-btn", "icon"); elActions.insertBefore(curMic.button, save); }
    }
    elActions.appendChild(shareBtn(b, ceil));
    elActions.appendChild(openLink(b, ceil));
    elActions.appendChild(dlLink(b, ceil));
    elActions.appendChild(closeBtn());
    if (!o.deferAuto) startAuto();
    return startAuto;
  }

  function renderEditor(b, ceil, brainRel, d) {
    var isMd = extOf(brainRel) === ".md";
    // .md + du bo may WYSIWYG (mdToHtml + JavisNoteEditor) -> soan nhu Word; con lai -> textarea nguon.
    if (isMd && typeof window.mdToHtml === "function" && window.JavisNoteEditor) renderMdEditor(b, ceil, d);
    else if (window.JavisHtmlPreview && window.JavisHtmlPreview.isHtmlPath(ceil)) renderHtmlEditor(b, ceil, d);
    else renderPlainEditor(b, ceil, d);
  }

  // .html (0.430.2): opens on the PREVIEW, like an artifact, with a Code tab holding the usual
  // highlighted editor. The preview draws the code currently in the editor (html-preview.js), so an
  // edit shows on the next switch back without saving first. Save and Ctrl+S work from either tab.
  function renderHtmlEditor(b, ceil, d) {
    var HP = window.JavisHtmlPreview;
    elActions.innerHTML = "";
    elBody.innerHTML = '<div class="jvfe-html mode-preview">' +
      '<div class="jvfe-html-prev"></div>' +
      '<div class="jvfe-html-src"><textarea class="jvfe-text" spellcheck="false"></textarea></div></div>';
    var box = elBody.firstChild;
    var prev = box.querySelector(".jvfe-html-prev");
    var ta = box.querySelector(".jvfe-text");
    ta.value = d.content || "";
    try { if (window.JavisCodeHL) window.JavisCodeHL.attach(ta, "html"); } catch (e) {}
    var shown = null;   // the code the preview last drew, so switching tabs does not reload it for nothing
    function draw() {
      if (shown === ta.value) return;
      shown = ta.value;
      HP.render(prev, ta.value, ceil, function (path) { return rawUrl(b, path); });
    }
    var seg = document.createElement("span");
    seg.className = "jvfe-seg";
    [["preview", tw("crender.ap_preview")], ["code", tw("crender.ap_source")]].forEach(function (m) {
      var btn = document.createElement("button");
      btn.type = "button"; btn.className = "jvfe-btn" + (m[0] === "preview" ? " active" : "");
      btn.textContent = m[1]; btn.dataset.mode = m[0];
      btn.onclick = function () {
        box.className = "jvfe-html mode-" + m[0];
        seg.querySelectorAll("button").forEach(function (x) { x.classList.toggle("active", x === btn); });
        if (m[0] === "preview") draw(); else focusNeuDuocPhep(ta);
      };
      seg.appendChild(btn);
    });
    elActions.appendChild(seg);
    appendSaveAndClose(b, ceil, function () { return ta.value; },
      { original: d.content || "", sources: [ta], apply: function (t) { ta.value = t; } });
    draw();
  }

  // File text thuong (khong phai .md): textarea nguon, co to mau cu phap neu la file code.
  function renderPlainEditor(b, ceil, d) {
    elActions.innerHTML = "";
    elBody.innerHTML = '<textarea class="jvfe-text" spellcheck="false"></textarea>';
    var ta = elBody.querySelector(".jvfe-text");
    ta.value = d.content || "";
    // .html, .css, .js, .json, .py... -> lop mau chong khit ben duoi (code-hl.js). Khong nhan
    // ra ngon ngu hoac file qua to thi attach tra null va o sua chay y nhu cu.
    try {
      var lang = window.JavisCodeHL ? window.JavisCodeHL.langFromPath(ceil) : "";
      if (lang) window.JavisCodeHL.attach(ta, lang);
    } catch (e) {}
    // Bo dem tu + ky tu (0.65.32), dung chung ham cua trinh sua dinh (console.js).
    var NE0 = window.JavisNoteEditor;
    if (NE0 && NE0.ganDemTu) NE0.ganDemTu(elActions, function () { return { text: ta.value, md: false }; }, [ta]);
    appendSaveAndClose(b, ceil, function () { return ta.value; }, {
      original: d.content || "", sources: [ta], apply: function (t) { ta.value = t; },
      mic: extOf(ceil) === ".txt" ? { host: elActions, target: function () { return { kind: "ta", el: ta }; } } : null,
    });
    focusNeuDuocPhep(ta);
  }

  // .md: WYSIWYG 2 khung (ban render sua truc tiep + nguon markdown) dung LAI bo may editor cay.
  function renderMdEditor(b, ceil, d) {
    var NE = window.JavisNoteEditor;
    elActions.innerHTML = "";
    elBody.innerHTML =
      '<div class="ne-body ne-md mode-source" id="jvfeNe">' +
        '<div class="ne-fmt"></div>' +
        '<div class="ne-panes">' +
          '<div class="ne-prev ne-wys" contenteditable="true" spellcheck="false"></div>' +
          '<div class="ne-src"><textarea spellcheck="false"></textarea></div>' +
        "</div>" +
      "</div>";
    var neBody = elBody.querySelector("#jvfeNe");
    var wys = neBody.querySelector(".ne-wys");
    var ta = neBody.querySelector(".ne-src textarea");
    ta.value = d.content || "";
    // Duong dan tuong doi trong .md tinh theo thu muc chua chinh file do (xem ungVienAnh
    // trong chat-render.js), khong phai theo goc brain.
    var thuMuc = ceil.indexOf("/") >= 0 ? ceil.slice(0, ceil.lastIndexOf("/")) : "";
    wys.innerHTML = window.mdToHtml(ta.value, b, { thuMuc: thuMuc });
    // Tick checkbox task trong ban render -> tu luu ngay (nhu Obsidian)
    wys.addEventListener("jv-task-toggle", function () { if (curSave) curSave(); });

    var curMode = "source";
    function srcToWys() { wys.innerHTML = window.mdToHtml(ta.value, b, { thuMuc: thuMuc }); }
    function wysToSrc() { var md = NE.mdFromHtml(wys.innerHTML); if (md != null) ta.value = md; }
    function mdGetter() {
      if (curMode === "wys") { var md = NE.mdFromHtml(wys.innerHTML); return md != null ? md : ta.value; }
      return ta.value;
    }

    var seg = document.createElement("span"); seg.className = "ne-seg";
    var bWys = document.createElement("button"); bWys.className = "jvfe-btn"; bWys.textContent = tw("common.edit");
    var bSrc = document.createElement("button"); bSrc.className = "jvfe-btn active"; bSrc.textContent = tw("fedit.tab_source");
    function setMode(m) {
      if (m === curMode) return;
      if (m === "source") wysToSrc(); else srcToWys();
      curMode = m;
      neBody.className = "ne-body ne-md " + (m === "wys" ? "mode-wys" : "mode-source");
      if (demLai) demLai();
      bWys.classList.toggle("active", m === "wys"); bSrc.classList.toggle("active", m === "source");
    }
    // Nguoi dung TU BAM sang che do soan thi cho focus that: do la y dinh ro rang cua ho,
    // khac han chuyen tu dat con tro ngay luc file vua mo ra.
    bWys.onclick = function () { setMode("wys"); try { wys.focus(); } catch (e) {} };
    bSrc.onclick = function () { setMode("source"); try { ta.focus(); } catch (e) {} };
    seg.appendChild(bWys); seg.appendChild(bSrc); elActions.appendChild(seg);

    var demLai = null;
    NE.buildToolbar(neBody.querySelector(".ne-fmt"), { mode: function () { return curMode; }, ta: ta, wys: wys,
      onChange: function () { if (demLai) demLai(); if (curAuto) curAuto.poke(); } });
    // Bo dem tu + ky tu (0.65.32): dem chu HIEN RA, giong trinh sua dinh.
    if (NE.ganDemTu) demLai = NE.ganDemTu(neBody.querySelector(".ne-fmt"), function () {
      return curMode === "wys" ? { text: wys.innerText, md: false } : { text: ta.value, md: true };
    }, [ta, wys]);
    var typedEarly = false;
    ta.addEventListener("input", function () { typedEarly = true; });
    var startAuto = appendSaveAndClose(b, ceil, mdGetter, {
      original: d.content || "", sources: [ta, wys], deferAuto: true,
      // Typed before the rendered view took over: those words still count as unsaved.
      baseline: function () { return typedEarly ? (d.content || "") : null; },
      apply: function (t) { ta.value = t; srcToWys(); if (demLai) demLai(); },
      mic: { host: neBody.querySelector(".ne-fmt"), target: function () {
        return curMode === "wys" ? { kind: "wys", el: wys } : { kind: "ta", el: ta };
      } },
    });

    // Vao che do Sua (WYSIWYG) khi Turndown san sang; offline khong nap duoc thi o lai Nguon (van sua tot).
    // Autosave starts once the mode is settled (see appendSaveAndClose), also when Turndown cannot load.
    if (window.TurndownService) { setMode("wys"); focusNeuDuocPhep(wys); startAuto(); }
    else NE.ensureTurndown().then(function () {
      if (!neBody.isConnected) return;
      if (isOpen() && window.TurndownService) { setMode("wys"); focusNeuDuocPhep(wys); }
      startAuto();
    }, function () { if (neBody.isConnected) startAuto(); });
  }

  // Xem mot PDF tu URL (link trong chat tren iPhone/iPad, chat-render.js goi). Cung khung voi
  // PDF mo tu duong dan brain: nut Dong, nut Back cua may dong duoc, nut Tai ve.
  function openPdf(url, ten) {
    if (!url) return;
    ten = String(ten || "").split("?")[0] || baseOf(String(url).split("?")[0]) || "file.pdf";
    moModal(ten);
    renderPdf(url, ten);
  }

  if (typeof window !== "undefined") {
    window.JavisEditFile = open;
    window.JavisFileEditor = { open: open, close: close, openPdf: openPdf };
    // Trinh sua dinh (console.js) dung lai DUNG cai nut nay, khong chep lai logic:
    // mot cho sua la ca hai khung cung doi.
    window.JavisShareBtn = shareBtn;
  }
  if (typeof module !== "undefined" && module.exports) {
    module.exports = { ceilPath: ceilPath, laIOS: laIOS };
  }
})();
