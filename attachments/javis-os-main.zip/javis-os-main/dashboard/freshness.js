/* Người gác cổng bản cũ: phát hiện trình duyệt đang chạy code KHÔNG khớp với máy chủ.
 *
 * VÌ SAO CÓ FILE NÀY (vụ 03/09/2026)
 * Chủ repo báo "up file vẫn không chọn được nhiều file" sau khi bản vá đã lên main và đã
 * cập nhật máy chủ. Hoá ra trình duyệt chạy sessions-ui.js CŨ, trong khi dòng chữ ngay
 * cạnh cái ô đó lại là chữ MỚI - vì hai thứ đi hai đường khác nhau tới trình duyệt:
 *   - từ điển i18n: tải kèm `cache: no-cache`, luôn hỏi lại máy chủ  -> LUÔN mới
 *   - file .js/.css: mang `?v=<phiên bản>` + đóng dấu cache 1 năm immutable -> đứng yên
 *     vĩnh viễn nếu có tầng cache nào bỏ qua phần `?v=`
 * Kết quả là một sự cố CÂM: bản vá "không ăn", người dùng tưởng code sai, người sửa không
 * tài nào tái hiện. Chú thích trong main.root() cho thấy repo đã vấp đúng chuyện này một
 * lần trước đó (console.js đứng yên suốt hàng chục bản mà không ai biết).
 *
 * VÌ SAO KHÔNG CHỈ SO SỐ PHIÊN BẢN
 * Ở đúng ca trên, số phiên bản KHỚP mà nội dung thì cũ. Nên file này so chính NỘI DUNG:
 * server nhúng vào trang crc32 của từng file .js/.css, ở đây tải lại đúng URL ấy (lấy từ
 * cache, không tốn mạng) rồi băm và đối chiếu. Lệch nghĩa là thứ đang chạy không phải thứ
 * máy chủ có.
 *
 * ĐIỂM TỰA: index.html được trả kèm `no-store` nên nó LUÔN mới, kể cả khi mọi file JS
 * quanh nó đã cũ. Khối <script id="javis-fresh"> nằm trong đó vì vậy luôn nói thật.
 * Chính file này cũng nạp KHÔNG kèm `?v=` và được đóng dấu `no-cache` (xem middleware
 * _static_cache_headers) - người gác cổng mà cũ theo thì nó gác cái gì.
 */
(function () {
  "use strict";

  var CHU_KY_MS = 5 * 60 * 1000;     // nhịp hỏi lại máy chủ xem đã có bản mới chưa
  var KHOA_DA_TAI = "javis-fresh-reloaded";   // chống vòng lặp tải lại vô tận
  // 0.415.0: vân tay của bộ file đã đo là KHỚP trên máy này. Bộ file không đổi thì lần mở sau khỏi đo lại: đo là tải lại
  // từ cache và băm từng file (hơn trăm file, gần 4 MB) ngay sau lúc mở trang, việc nặng nhất của một chiếc điện thoại
  // vào đúng lúc nó đang bận dựng giao diện. Lệch chỉ xảy ra khi bộ file vừa đổi (bản cập nhật), và lúc đó vân tay đổi
  // theo nên vẫn đo như cũ.
  var KHOA_DA_DO = "javis-fresh-checked";

  function moc() {
    var el = document.getElementById("javis-fresh");
    if (!el) return null;
    try { return JSON.parse(el.textContent || "{}"); } catch (e) { return null; }
  }

  /* crc32 khớp từng bit với zlib.crc32 bên Python (server dùng chính hàm đó).
   * Không dùng crypto.subtle: nó chỉ có trong ngữ cảnh bảo mật, mà Javis rất hay chạy
   * trên http:// theo IP của VPS - dùng nó là người gác cổng chết lặng đúng lúc cần nhất. */
  var BANG = null;
  function bangCrc() {
    if (BANG) return BANG;
    BANG = new Uint32Array(256);
    for (var i = 0; i < 256; i++) {
      var c = i;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      BANG[i] = c >>> 0;
    }
    return BANG;
  }

  function crc32(bytes) {
    var t = bangCrc(), c = 0xFFFFFFFF;
    for (var i = 0; i < bytes.length; i++) c = t[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
    c = (c ^ 0xFFFFFFFF) >>> 0;
    var s = c.toString(16);
    while (s.length < 8) s = "0" + s;
    return s;
  }

  /* Tải một file tĩnh ĐÚNG như trình duyệt đã tải nó lúc dựng trang: KHÔNG ép làm mới, để
   * nó trả về đúng bản đang nằm trong cache (của trình duyệt hay của proxy). Đây mới là
   * thứ cần đo - ép làm mới là đo file trên máy chủ, tức là đo nhầm đầu. */
  function taiNhuTrang(url) {
    return fetch(url, { credentials: "same-origin" })
      .then(function (r) { return r.ok ? r.arrayBuffer() : null; })
      .catch(function () { return null; });
  }

  /* Trả về danh sách file mà NỘI DUNG đang chạy khác nội dung máy chủ. */
  function doLech(m) {
    var ds = Object.keys(m.assets || {});
    if (!ds.length) return Promise.resolve([]);
    var ver = encodeURIComponent(m.version || "0");
    return Promise.all(ds.map(function (rel) {
      // `?v=` phải TRÙNG KHÍT khoá mà trang đã dùng lúc nạp file, nếu không ta đo một URL
      // khác - cache miss, tải lại từ máy chủ, tức là đo file TRÊN MÁY CHỦ chứ không phải
      // file trình duyệt ĐANG CHẠY, đúng cái bẫy mà chú thích taiNhuTrang ở trên cảnh báo.
      // Server đóng dấu bằng vân tay từng file (xem `root()` trong main.py), nên khoá là
      // chính crc trong `m.assets`; rơi về số phiên bản cho bản server cũ hơn.
      var khoa = encodeURIComponent(m.assets[rel] || "") || ver;
      return taiNhuTrang("/static/" + rel + "?v=" + khoa).then(function (buf) {
        if (!buf) return null;                       // không đọc được thì im, đừng báo oan
        return crc32(new Uint8Array(buf)) === m.assets[rel] ? null : rel;
      });
    })).then(function (kq) { return kq.filter(Boolean); });
  }

  // ── Dải báo ───────────────────────────────────────────────────────────────────
  function veDai(tieuDe, chiTiet, nhanNut, khiBam) {
    if (document.getElementById("javis-fresh-bar")) return;
    var css = document.createElement("style");
    css.textContent =
      "#javis-fresh-bar{position:fixed;left:50%;transform:translateX(-50%);top:14px;z-index:99999;" +
      "display:flex;align-items:center;gap:12px;width:min(92vw,720px);box-sizing:border-box;padding:12px 16px;" +
      "border-radius:12px;border:1px solid var(--yellow,#e0a800);background:var(--bg2,#1b1f2a);" +
      "color:var(--text,#e8eaf0);font-size:16px;line-height:1.5;box-shadow:0 10px 30px rgba(0,0,0,.4)}" +
      "#javis-fresh-bar .jf-txt{flex:1 1 auto;min-width:0;overflow-wrap:anywhere}" +
      "#javis-fresh-bar .jf-sub{display:block;margin-top:3px;font-size:14px;opacity:.8}" +
      // Owner screenshot 25/10/2026: "Tải lại" was near-black on the light theme's dark amber (3.1:1) and
      // cramped, "Để sau" was grey text with a border at 1.3:1, barely there. Ink now flips with the theme
      // (--on-accent: white on paper, near-black on dark), and both buttons share one height and padding.
      "#javis-fresh-bar button{flex:none;cursor:pointer;border-radius:8px;font-size:16px;line-height:1.25;" +
      "padding:8px 16px;min-height:40px;font-family:inherit;font-weight:600;" +
      "border:1px solid var(--btn-line,rgba(140,140,160,.5))}" +
      "#javis-fresh-bar .jf-ok{background:var(--yellow,#e0a800);border-color:var(--yellow,#e0a800);" +
      "color:var(--on-accent,#1a1a1a);font-weight:700}" +
      "#javis-fresh-bar .jf-x{background:var(--btn-fill,transparent);color:var(--text,#e8eaf0)}" +
      "#javis-fresh-bar .jf-x:hover{background:var(--btn-fill-hover,transparent)}" +
      "@media(max-width:600px){#javis-fresh-bar{flex-wrap:wrap;gap:10px;top:max(12px,env(safe-area-inset-top))}" +
      "#javis-fresh-bar .jf-txt{flex:1 0 100%}#javis-fresh-bar button{white-space:nowrap}}";
    var bar = document.createElement("div");
    bar.id = "javis-fresh-bar";
    bar.setAttribute("role", "status");
    var txt = document.createElement("div");
    txt.className = "jf-txt";
    txt.textContent = tieuDe;
    if (chiTiet) {
      var sub = document.createElement("span");
      sub.className = "jf-sub";
      sub.textContent = chiTiet;
      txt.appendChild(sub);
    }
    var ok = document.createElement("button");
    ok.className = "jf-ok";
    ok.textContent = nhanNut;
    ok.onclick = khiBam;
    var x = document.createElement("button");
    x.className = "jf-x";
    x.textContent = window.t("cs.fm_fix_later");
    x.onclick = function () { bar.remove(); };
    bar.appendChild(txt); bar.appendChild(ok); bar.appendChild(x);
    document.head.appendChild(css);
    document.body.appendChild(bar);
  }

  /* KHÔNG tự tải lại trang. Người dùng có thể đang gõ dở một câu dài, và mất chữ đang gõ vì
   * một thứ họ không hề bấm là tệ hơn hẳn cái nó chữa. Chỉ hiện dải và để họ bấm. */
  function baoCoBanMoi(verMoi) {
    veDai(window.t("fresh.new_ver", { ver: verMoi }),
          window.t("fresh.new_ver_sub"), window.t("fresh.reload"), function () { location.reload(); });
  }

  function baoChayBanCu(ds, daThuTaiLai) {
    var ten = ds.slice(0, 3).join(", ")
      + (ds.length > 3 ? " " + window.t("fresh.more_files", { count: ds.length - 3 }) : "");
    if (!daThuTaiLai) {
      veDai(window.t("fresh.stale_title"),
            window.t("fresh.stale_sub", { ds: ten }), window.t("fresh.reload"), function () {
              try { sessionStorage.setItem(KHOA_DA_TAI, "1"); } catch (e) { /* noop */ }
              location.reload();
            });
      return;
    }
    // Tải lại rồi mà vẫn lệch: cache nằm ngoài tầm với của trang (proxy, CDN). Nói THẲNG
    // phải làm gì, đừng để người dùng bấm Tải lại mãi mà không hiểu vì sao không đổi.
    veDai(window.t("fresh.stuck_title"),
          window.t("fresh.stuck_sub", { phim: "Ctrl+Shift+R", phim_mac: "Cmd+Shift+R", ds: ten }),
          window.t("common.retry"), function () { location.reload(true); });
  }

  /* Tải lại trang SAU khi máy chủ đã thật sự lên (0.415.0). Bấm cập nhật xong, trang tải lại 1,5 giây sau khi /version
   * báo số mới; nếu lúc đó máy chủ hay đường hầm trước nó còn chập chờn thì trang mới mở ra nhận toàn trang lỗi, in mã
   * khoá thay cho chữ và đứng đó (khách báo 30/10/2026). Hỏi /app-version và từ điển gốc, đủ HAI lần liền đều ra JSON
   * thì mới tải lại; quá 90 giây vẫn tải lại (i18n/index.js còn tự hồi nếu lần đó vẫn trượt). */
  function choSanRoiTaiLai() {
    var batDau = Date.now(), dat = 0;
    function json(url) {
      return fetch(url, { credentials: "same-origin", cache: "no-store" })
        .then(function (r) { return r.ok ? r.json() : null; })
        .catch(function () { return null; });
    }
    function thu() {
      Promise.all([json("/app-version"), json("/static/i18n/vi.json")]).then(function (kq) {
        dat = (kq[0] && kq[0].version && kq[1]) ? dat + 1 : 0;
        if (dat >= 2 || Date.now() - batDau > 90000) { location.reload(); return; }
        setTimeout(thu, 1000);
      });
    }
    thu();
  }
  window.JavisReloadWhenReady = choSanRoiTaiLai;

  // ── Chạy ──────────────────────────────────────────────────────────────────────
  var m = moc();
  if (!m) return;              // server chưa nhúng khối này (bản cũ) - im lặng, đừng phá gì

  /* 2026-11-08 (owner: "mỗi khi update load lại trang thì load lại cache luôn được không?"). Code and styles already
   * refresh by themselves: every .js/.css URL carries its own content hash, and this page itself is never cached. What
   * a reload did NOT renew is what Javis keeps in localStorage, which Ctrl+Shift+R does not touch either: the list of
   * reads each moment batches (fetch-gop.js, keys "javis.batch.*"), recorded by the previous version's code. So the
   * first page opened on a new version drops them and they are recorded again from this version. This file runs before
   * fetch-gop.js reads them. */
  var LAST_VERSION_KEY = "javis-fresh-version";
  function clearVersionCaches() {
    try {
      for (var i = localStorage.length - 1; i >= 0; i--) {
        var k = localStorage.key(i);
        if (k && k.indexOf("javis.batch.") === 0) localStorage.removeItem(k);
      }
    } catch (e) { /* noop */ }
  }
  try {
    var seenVersion = localStorage.getItem(LAST_VERSION_KEY);
    if (seenVersion !== m.version) {
      if (seenVersion) clearVersionCaches();
      localStorage.setItem(LAST_VERSION_KEY, String(m.version || ""));
    }
  } catch (e) { /* noop */ }

  // Vân tay của cả bộ file (tên + crc từng file), đo bằng chính crc32 ở trên.
  var vanTay = "";
  try {
    var chuoi = (m.version || "") + "|" + Object.keys(m.assets || {}).sort().map(function (k) { return k + ":" + m.assets[k]; }).join(",");
    vanTay = crc32(new TextEncoder().encode(chuoi));
  } catch (e) { vanTay = ""; }
  function daDo() { try { return !!vanTay && localStorage.getItem(KHOA_DA_DO) === vanTay; } catch (e) { return false; } }
  function ghiDaDo(ok) {
    try { if (ok && vanTay) localStorage.setItem(KHOA_DA_DO, vanTay); else localStorage.removeItem(KHOA_DA_DO); } catch (e) { /* noop */ }
  }

  var daThu = false;
  try { daThu = sessionStorage.getItem(KHOA_DA_TAI) === "1"; } catch (e) { /* noop */ }

  function kiemNoiDung() {
    if (daDo()) return;
    doLech(m).then(function (ds) {
      ghiDaDo(!ds.length);
      if (!ds.length) {
        try { sessionStorage.removeItem(KHOA_DA_TAI); } catch (e) { /* noop */ }
        return;
      }
      console.warn("[javis fresh] running a stale copy of:", ds.join(", "));
      baoChayBanCu(ds, daThu);
    });
  }

  // Đo SAU khi trang dựng xong: đây là lưới an toàn, không được làm chậm lúc mở app.
  if (document.readyState === "complete") setTimeout(kiemNoiDung, 1200);
  else window.addEventListener("load", function () { setTimeout(kiemNoiDung, 1200); });

  /* Máy chủ được cập nhật trong lúc tab đang mở: số phiên bản đổi, còn trang thì vẫn là
   * trang cũ. Hỏi lại theo nhịp, và hỏi luôn khi người dùng quay lại tab (rất hay là lúc
   * họ vừa bấm cập nhật ở tab khác). */
  var daBao = false;
  function kiemPhienBan() {
    if (daBao || document.hidden) return;
    fetch("/app-version", { credentials: "same-origin", cache: "no-store" })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (!d || !d.version || d.version === m.version) return;
        daBao = true;
        // Đang chờ ở nút Cập nhật ngay: bản mới đã lên đúng như người dùng vừa bấm, tải lại luôn
        // chứ đừng hỏi thêm một lần nữa.
        if (window.__javisUpdating) { choSanRoiTaiLai(); return; }
        baoCoBanMoi(d.version);
      })
      .catch(function () { /* mất mạng một nhịp không phải chuyện để làm phiền người dùng */ });
  }

  setInterval(kiemPhienBan, CHU_KY_MS);

  /* 0.418.0: hỏi phiên bản NGAY sau khi mở, thử lại tới khi máy chủ trả lời. Khi máy chủ không với tới được, sw.js đưa ra
   * khung trang đã giữ lần trước; khung đó có thể là bản trước một lần cập nhật. Lệch số phiên bản thì: trang vừa mở
   * (dưới 2 phút), ô chat còn trống và chưa tự tải lại trong 30 giây qua: tải lại luôn; còn lại hiện thanh mời tải lại. */
  var batDau = Date.now(), KHOA_TU_TAI = "javis-fresh-autoreload";
  function kiemSom(lan) {
    fetch("/app-version", { credentials: "same-origin", cache: "no-store" })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (!d || !d.version) { throw new Error("chua"); }
        if (d.version === m.version || daBao) return;
        var o = document.getElementById("chatInput");
        var luc = 0;
        try { luc = Number(sessionStorage.getItem(KHOA_TU_TAI) || 0); } catch (e) { /* noop */ }
        if (Date.now() - batDau < 120000 && !(o && o.value.trim()) && Date.now() - luc > 30000) {
          try { sessionStorage.setItem(KHOA_TU_TAI, String(Date.now())); } catch (e) { /* noop */ }
          location.reload();
          return;
        }
        daBao = true;
        baoCoBanMoi(d.version);
      })
      .catch(function () { if (lan < 24) setTimeout(function () { kiemSom(lan + 1); }, 5000); });
  }
  setTimeout(function () { kiemSom(0); }, 2500);

  // Đăng ký service worker cho mọi người (trước đây chỉ khi bật thông báo đẩy), để có đường lùi ở trên. Chỉ chạy trong
  // ngữ cảnh an toàn (https hay localhost); trên http theo IP thì trình duyệt không cho, bỏ qua lặng lẽ.
  try {
    if ("serviceWorker" in navigator && window.isSecureContext) {
      window.addEventListener("load", function () {
        setTimeout(function () { navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(function () {}); }, 3000);
      });
    }
  } catch (e) { /* noop */ }
  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) kiemPhienBan();
  });
})();
