// model-picker.js: đổi model (đa nhà cung cấp) + effort ngay trên khung chat.
// Thuần frontend: đọc/ghi qua /settings + /provider/models (đã có sẵn ở backend).
//
// MODEL THEO PHIÊN (16/08): đổi model NGAY TRONG một phiên chat = ghim model đó cho
// riêng phiên (POST /sessions/{id}/model) + vẫn cập nhật mặc định chung như cũ. Mở lại
// phiên cũ là thấy đúng model đã chọn trong nó; đổi model ở phiên/tab khác không kéo
// phiên đã ghim đổi theo. Phiên chưa từng đổi tay vẫn bám mặc định chung.
(function () {
  "use strict";

  // Thang độ sâu suy nghĩ - phải KHỚP engine.REASONING_LEVELS bên server, nếu không người dùng
  // chọn xong server lọc về "off" mà giao diện vẫn khoe đang bật.
  const EFFORT = [["off", "models.r_off"], ["low", "models.r_low"], ["medium", "models.r_med"],
                  ["high", "models.r_high"], ["xhigh", "models.r_xhigh"], ["ultra", "models.r_ultra"]];
  // Effort chip labels (0.153.0, English as the owner asked): full keys so the i18n test can read them.
  const EFF_KEY = { off: "eff.off", low: "eff.low", medium: "eff.medium", high: "eff.high", xhigh: "eff.xhigh", ultra: "eff.ultra" };
  // FAST_NOTE_BEGIN
  // Fast mode per brain (researched 2026-10-15, see docs/superpowers/specs/2026-10-15-composer-plus-fast-mode-design.md).
  // Claude only on Opus 5.5, Opus 5 and Opus 4.8; an empty model means Claude Code's default (Opus), so it counts.
  function fastNote(provider, model) {
    const m = String(model || "").toLowerCase();
    // The Claude Code alias "opus" points at Opus 5.5 (first in the catalog and the fallback default).
    // Same rule as server/fast_mode.py: the version ends the id or is followed by a date (-YYYYMMDD).
    const opusOk = !m || m === "opus" || /opus-(?:5-5|4-8|5)(?=$|-\d{8}(?!\d)|[^-\d.])/.test(m);
    if (provider === "anthropic-cli") return opusOk ? { supported: true, note: "fast.claude" } : { supported: false, note: "fast.model_none" };
    if (provider === "anthropic-api") return opusOk ? { supported: true, note: "fast.api" } : { supported: false, note: "fast.model_none" };
    if (provider === "openai-oauth") return { supported: true, note: "fast.codex" };
    if (provider === "openai" || provider === "openrouter" || provider === "gemini") return { supported: true, note: "fast.api" };
    return { supported: false, note: "fast.none" };
  }
  // FAST_NOTE_END
  let state = { providers: [], main: { provider: "", model: "" }, reasoning: "off", fast: false, defaults: {} };
  let agentEff = null;   // { slug, level } while the chat in front is an assistant's (0.193.0)
  let sessionPin = null;   // {provider, model} phiên đang mở đã ghim; null = theo mặc định chung
  let pinBroken = false;   // phiên có ghim nhưng ghim HỎNG (provider mất key) - server đang chạy mặc định chung
  let pinLimited = 0;      // 0.285.0: the pinned plan is out of quota until this epoch; the chat runs on the main model
  let pinSid = null;       // phiên mà sessionPin đang nói về (chống vẽ nhầm khi đổi phiên nhanh)
  let pendingPin = null;   // model chọn khi CHƯA có phiên (chat trống) - áp ngay khi mint id
  // Owner, 05/11/2026: where the chat in front REALLY runs (server `_route_view`): {provider, model, name, fallback,
  // reason, until, limited:{provider: epoch}, selected_*}. From /sessions/{id}/meta or /chat/route, then from the
  // "route" frame each turn sends. null = unknown, the chip shows the chosen model as before.
  let route = null;
  let routeTimer = null;  // reads the route again when the resting card's quota is due back
  const lastRoute = {};   // session id -> {provider, fallback} of the last turn seen, for the one-line notices
  let expanded = null;     // provider đang mở rộng trong popover; "" = đã thu hết (bấm lại tên nhà)
  let filter = "";

  const short = (m) => (m || "").split("/").pop().replace(/^(claude-|gpt-)/, "").slice(0, 26) || window.t("models.mp_default");
  const provShort = (lbl) => (lbl || "").split(" ")[0];
  // Chip text: the model name alone. No model set means the provider's own default, so the provider name stands in
  // ("Claude") rather than a bare "Default".
  // 0.355.0: when the server knows which model "default" stands for, the chip names it.
  const chipLabel = (eff, p) => (eff.model ? prettyModel(eff.model)
    : (state.defaults || {})[eff.provider] ? prettyModel(state.defaults[eff.provider]) : (p ? provShort(p.label) : "Model"));
  const defText = (pid) => (state.defaults || {})[pid] ? window.t("models.mp_default_is", { m: state.defaults[pid] })
    : ["anthropic-cli", "openai-oauth", "grok-cli", "antigravity-cli"].indexOf(pid) >= 0
      ? window.t("models.mp_default_cli") : window.t("models.mp_default");
  // "claude-opus-4-8-20260101" -> "Opus 4.8", "gpt-5.1-codex" -> "GPT-5.1 codex", "openai/gpt-4o" -> "GPT-4o",
  // "gemini-2.5-pro" -> "Gemini 2.5 pro". Pure, so the node test can run it.
  function prettyModel(id) {
    let n = String(id || "").split("/").pop().replace(/[-@]\d{8}$/, "").replace(/^claude-/, "");
    const fam = /^(opus|sonnet|haiku|fable)((?:-\d{1,2})*)(.*)$/i.exec(n);
    if (fam) {
      const ver = fam[2] ? " " + fam[2].slice(1).split("-").join(".") : "";
      return (fam[1][0].toUpperCase() + fam[1].slice(1).toLowerCase() + ver + fam[3].replace(/-/g, " ")).trim();
    }
    if (/^gpt-/i.test(n)) return ("GPT-" + n.slice(4)).replace(/-(?=[a-z])/g, " ").replace(/^GPT /, "GPT-");
    n = n.replace(/-/g, " ").replace(/:/g, " ");
    return n ? n[0].toUpperCase() + n.slice(1) : n;
  }
  const $ = (id) => document.getElementById(id);
  const curSid = () => { try { return (window.JavisSessions && window.JavisSessions.current()) || null; } catch (e) { return null; } };
  const curBrain = () => { try { return (window.JavisSessions && window.JavisSessions.brain()) || ""; } catch (e) { return ""; } };
  // Model ĐANG HIỆU LỰC cho khung chat trước mặt: ghim của phiên thắng mặc định chung.
  const effective = () => sessionPin || state.main;
  // What the composer SHOWS (owner, 05/11/2026: "khung chat bị chuyển thì phải chuyển luôn model ở khung đang chat"): the
  // fallback card really answering, else the chosen model. Chip, picker tick, effort lock, Fast bolt, plan ring and
  // `/model` all follow it. The choice itself (`effective`) is kept, so the chat goes back to it once its quota returns.
  const shown = () => (route && route.fallback ? { provider: route.provider, model: route.model || "" } : effective());
  // The Effort the chip shows and the slider sets (owner, 05/11/2026: "Effort cũng theo model dự phòng luôn"): an
  // assistant's own level in its chat, the fallback card's own level while one answers, else the chosen card's.
  const onFallback = () => !!(route && route.fallback && route.reasoning);
  const shownEffort = () => (agentEff ? agentEff.level : onFallback() ? route.reasoning : state.reasoning);

  async function saveModel(patch) {
    const fd = new FormData();
    fd.append("section", "model");
    fd.append("data", JSON.stringify(patch));
    try { await fetch("/settings", { method: "POST", body: fd }); } catch (e) {}
  }

  async function saveAgentEffort(slug, level) {
    const fd = new FormData();
    fd.append("level", level);
    fd.append("brain", curBrain() || "brain");
    try { await fetch(`/agents/${encodeURIComponent(slug)}/reasoning`, { method: "POST", body: fd }); } catch (e) {}
    try { window.dispatchEvent(new CustomEvent("javis:agent-reasoning", { detail: { slug: slug, level: level } })); } catch (e) {}
  }

  async function pinToSession(sid, prov, model) {
    const fd = new FormData();
    fd.append("provider", prov);
    fd.append("model", model || "");
    fd.append("brain", curBrain());   // phiên chưa có hàng trong DB thì server tự tạo
    try { await fetch(`/sessions/${encodeURIComponent(sid)}/model`, { method: "POST", body: fd }); } catch (e) {}
  }

  // 0.461.0: a Javis Core chat's pin is Javis Core's pin, also shown and set as the Model of its card on the Partners
  // page (the agent editor). The chip tells the page through one event.
  const CORE_EVENT = "javis:core-model";
  function coreChanged() {
    if (!(agentEff && agentEff.slug === "javis-core")) return;
    try { window.dispatchEvent(new CustomEvent(CORE_EVENT, { detail: { from: "chat" } })); } catch (e) {}
  }

  async function loadState() {
    try {
      const s = await (await fetch("/settings")).json();
      const m = s.model || {};
      state.providers = m.providers || [];
      state.main = m.main || { provider: "anthropic-cli", model: "" };
      state.reasoning = m.reasoning || "off";
      state.fast = m.fast === true;
      state.defaults = (m.routing || {}).defaults || {};
    } catch (e) {}
  }

  // Hỏi server "phiên đang mở có ghim model riêng không". Đổi phiên nhanh tay thì chỉ
  // kết quả của phiên MỚI NHẤT được vẽ (so pinSid trước khi dùng).
  async function loadSessionPin() {
    const sid = curSid();
    pinSid = sid;
    if (!sid) {
      sessionPin = null; pinBroken = false; pinLimited = 0; pendingPin = null; agentEff = null;
      await refreshRoute();
      return;
    }
    pendingPin = null;
    try {
      const r = await fetch(`/sessions/${encodeURIComponent(sid)}/meta`);
      const d = r.ok ? await r.json() : null;
      if (pinSid !== sid) return;   // user đã nhảy sang phiên khác trong lúc chờ
      setRoute((d && d.route) || null);
      // pin_ok=false: ghim còn trong DB nhưng không chạy được (provider mất key) -
      // server đang rơi về mặc định chung, nên hiển thị cũng phải theo mặc định chung.
      pinBroken = !!(d && d.pinned_provider && d.pin_ok === false);
      pinLimited = (d && d.pin_limited_until) || 0;
      // 0.193.0: in an assistant's chat the effort chip shows and sets that assistant's own level (default medium).
      agentEff = d && d.agent_slug ? { slug: d.agent_slug, level: d.agent_reasoning || "medium" } : null;
      sessionPin = (d && d.pinned_provider && !pinBroken)
        ? { provider: d.pinned_provider, model: d.pinned_model || "" } : null;
    } catch (e) { if (pinSid === sid) { sessionPin = null; pinBroken = false; pinLimited = 0; agentEff = null; setRoute(null); } }
  }

  // FALLBACK_BEGIN
  // Keep the route and, while a card rests, read it again a few seconds after its quota is due back, so the chip turns
  // green by itself (the server goes back to the chosen model on its own; nothing saved ever changed).
  function setRoute(r) {
    route = r && r.provider ? r : null;
    if (routeTimer) { clearTimeout(routeTimer); routeTimer = null; }
    const until = route && route.fallback ? Number(route.until || 0) : 0;
    const wait = until ? until * 1000 - Date.now() + 5000 : 0;
    if (wait > 0 && wait < 6 * 3600 * 1000) {
      routeTimer = setTimeout(async () => { routeTimer = null; await refreshRoute(); renderBar(); }, wait);
    }
  }
  // Read the route only (the pin is left alone): the open chat's from its meta, an empty chat's from /chat/route
  // (where its first turn would run, the main card being perhaps out of quota).
  async function refreshRoute() {
    const sid = curSid();
    try {
      const r = await fetch(sid ? `/sessions/${encodeURIComponent(sid)}/meta` : "/chat/route");
      const d = r.ok ? await r.json() : null;
      if (curSid() !== sid) return;
      setRoute(sid ? (d && d.route) : d);
    } catch (e) {}
  }
  // "14:30" for a reset today, "06/11 14:30" for a later day.
  function hhmm(epoch) {
    const d = new Date(Number(epoch) * 1000);
    if (isNaN(d.getTime())) return "";
    const p2 = (n) => String(n).padStart(2, "0");
    const t = p2(d.getHours()) + ":" + p2(d.getMinutes());
    return d.toDateString() === new Date().toDateString() ? t : p2(d.getDate()) + "/" + p2(d.getMonth() + 1) + " " + t;
  }
  // Tooltip of the chip while a fallback card answers: what was chosen and why it is not running, then what runs.
  function fallbackTitle(r, selP, runP) {
    const why = r.reason === "quota"
      ? (r.until ? window.t("mpick.route_quota_until", { time: hhmm(r.until) }) : window.t("mpick.route_quota"))
      : r.reason === "signin" ? window.t("mpick.route_signin") : window.t("mpick.route_unavailable");
    const sel = (selP ? selP.label : r.selected_name || r.selected_provider) + " · "
      + (r.selected_model || defText(r.selected_provider));
    const run = (runP ? runP.label : r.name || r.provider) + " · " + (r.model || defText(r.provider));
    return window.t("mpick.route_chosen", { model: sel, why: why }) + "\n" + window.t("mpick.route_running", { model: run });
  }
  // The line a turn's "route" frame adds to the chat, or "": the first turn on a fallback card says so, the first one
  // back on the chosen card says that too. Lines are not repeated turn after turn; a rerouted turn already has its line.
  function routeLine(sid, d) {
    const prev = lastRoute[sid];
    lastRoute[sid] = { provider: d.provider, fallback: !!d.fallback };
    if (d.rerouted) return "";
    if (d.fallback) return prev && prev.fallback && prev.provider === d.provider ? "" : (d.content || "");
    return prev && prev.fallback ? window.t("mpick.route_back", { nha: d.name || d.provider }) : "";
  }
  // Tags in the picker: a card resting out of quota, a card that lost its sign-in, and the card a fallback turn
  // really runs on.
  function routeTags(pid) {
    let h = "";
    if (route && route.limited && route.limited[pid]) {
      h += ' <span class="mb-tag is-limited" title="' + escAttr(route.limited[pid] ? window.t("mpick.route_quota_until",
        { time: hhmm(route.limited[pid]) }) : "") + '">' + escAttr(window.t("mpick.tag_limited")) + "</span>";
    }
    // A card that lost its sign-in needs the owner, not a wait: its own tag, never "out of quota until".
    if (route && Array.isArray(route.signed_out) && route.signed_out.indexOf(pid) >= 0) {
      h += ' <span class="mb-tag is-limited" title="' + escAttr(window.t("mpick.tag_signed_out_tip")) + '">'
        + escAttr(window.t("mpick.tag_signed_out")) + "</span>";
    }
    if (route && route.fallback && route.provider === pid) {
      h += ' <span class="mb-tag is-running">' + escAttr(window.t("mpick.tag_running")) + "</span>";
    }
    return h;
  }
  const escAttr = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  // FALLBACK_END

  function renderBar() {
    const eff = effective();
    const p = state.providers.find((x) => x.id === eff.provider);
    const mt = $("mbModelTxt");
    // Owner, 05/11/2026: a fallback card answering shows ITS model on the chip, with an amber dot; the tooltip keeps
    // the chosen one and why it is not running. The choice itself is untouched and comes back by itself.
    const fb = route && route.fallback ? route : null;
    const runP = fb ? state.providers.find((x) => x.id === fb.provider) : null;
    if (mt) {
      // 0.180.0 (owner): the chip shows the model name only, like "Opus 5.5" in the Claude app. The provider moves to
      // the tooltip; the pin state shows as an icon (below).
      mt.textContent = fb ? chipLabel({ provider: fb.provider, model: fb.model }, runP) : chipLabel(eff, p);
      mt.title = fb ? fallbackTitle(fb, state.providers.find((x) => x.id === fb.selected_provider), runP)
        : (p ? p.label + " · " + (eff.model || defText(eff.provider)) + "\n" : "") + (sessionPin
        ? window.t(agentEff && agentEff.slug === "javis-core" ? "mpick.core_pin_title" : "mpick.pin_title")
        : pinBroken
          ? window.t(pinLimited ? "mpick.pin_limited_title" : "mpick.pin_broken_title")
          : window.t("mpick.follow_default"));
      // The per-session pin keeps a visible mark (owner: "chế độ ghim vẫn hoạt động nhé"): a small pin icon on the
      // chip instead of the old "· ghim" text, orange-amber when the pin is broken. Screen readers get it in words.
      const chip = $("mbOpen");
      if (chip) {
        chip.classList.toggle("is-pinned", !!sessionPin);
        chip.classList.toggle("is-pin-broken", pinBroken && !fb);
        chip.classList.toggle("is-fallback", !!fb);
        let pin = chip.querySelector(".mb-pin");
        if (!pin) {
          pin = document.createElement("span");
          pin.className = "mb-pin";
          pin.setAttribute("aria-hidden", "true");
          pin.innerHTML = typeof ic === "function" ? ic("pin") : "";
          chip.insertBefore(pin, chip.querySelector(".mb-caret"));
        }
        pin.hidden = !(sessionPin || pinBroken);
        chip.setAttribute("aria-label", mt.textContent
          + (fb ? ", " + window.t("mpick.fallback_aria", { nha: fb.selected_name || fb.selected_provider }) : "")
          + (sessionPin ? ", " + window.t("mpick.pin") : pinBroken ? ", " + window.t("mpick.pin_broken") : ""));
      }
    }
    const eb = $("effTxt");
    if (eb) {
      // A locked Antigravity model runs at the level in its name, so the chip shows that level.
      const effM = shown();
      const own = window.JavisEffortSlider && window.JavisEffortSlider.isLocked(effM.provider, effM.model)
        ? window.JavisEffortSlider.lockedLevel(effM.model) : "";
      const lvl = shownEffort();
      eb.textContent = window.t(EFF_KEY[own || (EFFORT.find((e) => e[0] === lvl) || EFFORT[0])[0]]);
      const effB = $("effBtn");
      if (effB) effB.title = agentEff ? window.t("mpick.eff_agent")
        : onFallback() ? window.t("mpick.eff_fallback", { nha: route.name || route.provider }) : "";
    }
    renderFast();
  }

  // 0.329.0: the bolt sits in the Effort popover (effort-slider.js) and the composer button became the plan usage
  // ring (plan-limit.js). The Effort chip carries a small bolt while Fast mode is on, so it stays visible.
  function fastTitle(on) {
    const eff = shown();
    const n = fastNote(eff.provider, eff.model);
    // 0.164.0: the last real state this brain reported (cooldown, provider refusal) as an extra line.
    const st = fastStates[eff.provider];
    const key = n.supported && on ? fastStateKey(st) : "";
    return "Fast mode\n" + window.t(n.note) + (key ? "\n" + window.t(key, { reason: (st && st.reason) || "" }) : "");
  }
  function renderFast() {
    const eff = shown();
    const on = fastNote(eff.provider, eff.model).supported && state.fast;
    const fi = $("effFast");
    if (fi) fi.hidden = !on;
    if (effSlider && effSlider.refreshFast) effSlider.refreshFast();
    try { if (window.JavisPlanLimit) window.JavisPlanLimit.setProvider(eff.provider); } catch (e) {}
  }
  // FAST_STATE_BEGIN
  // Tooltip line for the last Fast mode state a brain reported (server: fast_mode.states()).
  function fastStateKey(st) {
    const s = st && st.state;
    if (s === "cooldown") return "fast.state_cooldown";
    if (s === "fallback") return "fast.state_fallback";
    // Claude Code reports off with a reason (e.g. out_of_credits when usage credits are not enabled).
    if (s === "off" && st.reason) return st.reason === "out_of_credits" ? "fast.state_credits" : "fast.state_off";
    return "";
  }
  // FAST_STATE_END
  let fastStates = {};
  // Read on hover/focus: cheap, and always fresh after the last turn.
  async function refreshFastState() {
    try {
      const r = await fetch("/model/fast-state");
      const d = r.ok ? await r.json() : null;
      fastStates = (d && d.states) || {};
    } catch (e) {}
    renderFast();
  }

  // Màn cảm ứng (điện thoại, máy tính bảng): focus một ô nhập là bật bàn phím ảo.
  const camUng = () => { try { return window.matchMedia("(pointer: coarse)").matches; } catch (e) { return false; } };
  let luotVe = 0;   // chỉ lượt vẽ MỚI NHẤT được ghi vào popup (lượt chờ mạng về muộn thì bỏ)

  async function renderPop() {
    const pop = $("mbPop");
    if (!pop) return;
    if (expanded == null) expanded = shown().provider || state.main.provider || "anthropic-cli";
    const luot = ++luotVe;
    // Nhà nào chưa có danh sách thì vẽ khung + dòng "đang tải" NGAY, rồi vẽ lại khi mạng về
    // (o.cho). Trước đây popup mở ra trống trơn trong lúc chờ (Codex mất vài giây).
    const o = {
    // Thân bảng (ô tìm + nhà + model + hàng khoá) dựng bởi model-list.js, dùng CHUNG với ô
    // The assistant's model on the Studio side. The thinking level has its own chip and popover since 0.153.0.
      providers: state.providers,
      expanded, filter,
      selected: shown(),   // the tick sits on the model really answering
      searchId: "mbSearch",
      short,
      mark: (p) => (p.is_main ? " " + ic("check", { cls: "ic-ok" }) : "") + routeTags(p.id),
      noWait: true,
      connectedOnly: true,   // 0.350.0: providers not connected are not listed in the chat picker
    };
    let html = await window.JavisModelList.render(o);
    if (luot !== luotVe || pop.hidden) return;
    // An assistant's chat with its own model: one row to go back to following the main chat's model (0.285.0).
    if (agentEff && (sessionPin || pinBroken)) {
      html = '<button type="button" class="mb-follow">' + (typeof ic === "function" ? ic("rotate-cw") : "") + " " +
        window.t("mpick.follow_main") + "</button>" + html;
    }
    // Ô tìm đang được gõ thì giữ con trỏ ở đó sau khi vẽ lại. Mới MỞ bảng thì chỉ tự focus
    // trên máy có bàn phím thật: trên điện thoại focus là bật bàn phím ảo che nửa bảng, người
    // dùng chỉ muốn bấm chọn model (chủ repo báo 27/09 "tự nhảy lên bàn phím").
    const dangGo = document.activeElement && document.activeElement.id === "mbSearch";
    pop.innerHTML = html;
    const se = $("mbSearch");
    if (se) {
      se.oninput = () => { filter = se.value; renderPop(); };
      if (dangGo || !camUng()) { se.focus(); se.selectionStart = se.selectionEnd = se.value.length; }
    }
    if (o.cho.length) {
      await Promise.all(o.cho);
      if (luot === luotVe && !pop.hidden) renderPop();
    }
  }

  // Đang gõ trong ô chat mà bấm chip model: hạ bàn phím xuống trước, kẻo bàn phím che bảng.
  function dropKeyboard() {
    if (!camUng()) return;
    const a = document.activeElement;
    if (a && a !== document.body && typeof a.blur === "function") a.blur();
  }
  function open() {
    const pop = $("mbPop");
    if (!pop) return;
    if (sheetMode()) { sheetOpen(); return; }
    effClose(); closePlus(); closeLimit();
    dropKeyboard();
    pop.hidden = false; renderPop();
  }
  function close() {
    if (sheetIsOpen()) { sheetClose(); return; }
    const pop = $("mbPop"); if (pop) pop.hidden = true;
  }
  function isOpen() { const pop = $("mbPop"); return pop && !pop.hidden; }

  // Where the slider's level goes: the assistant's own level, the fallback card's own effort while one answers (its card
  // on the Models page; the chosen card's stays as it was), else the chosen card's.
  async function saveEffort(v) {
    if (agentEff) { agentEff.level = v; renderBar(); await saveAgentEffort(agentEff.slug, v); return; }
    if (onFallback()) {
      const pid = route.provider;
      route.reasoning = v; renderBar();
      await saveModel({ profile: { provider: pid, reasoning: v } });
      await loadState(); renderBar();   // that card may be MAIN, whose effort is the chat's main level
      return;
    }
    state.reasoning = v; renderBar(); await saveModel({ reasoning: v });
  }

  // Effort chip (0.153.0): split from the model picker, opens a small popover with a slider.
  let effSlider = null;
  // Draws the slider into #effPop. Shared by the popover of a computer and the sheet of a phone.
  function effMount() {
    const pop = $("effPop"), btn = $("effBtn");
    if (!pop || !window.JavisEffortSlider) return false;
    if (effSlider) { effSlider.destroy(); effSlider = null; }
    const eff = shown();
    pop.hidden = false;
    pop.style.left = "";
    const locked = window.JavisEffortSlider.isLocked(eff.provider, eff.model);
    if (btn) btn.setAttribute("aria-expanded", "true");
    const fn = fastNote(eff.provider, eff.model);
    effSlider = window.JavisEffortSlider.mount(pop, {
      value: shownEffort(),
      fast: {
        supported: fn.supported, on: state.fast, title: fastTitle,
        onHover: () => { if (state.fast) refreshFastState(); },
        onToggle: async (on) => { state.fast = on; renderFast(); await saveModel({ fast: state.fast }); },
      },
      locked: locked,
      lockedValue: locked ? window.JavisEffortSlider.lockedLevel(eff.model) : "",
      onChange: saveEffort,
    });
    return true;
  }
  function effOpen() {
    const pop = $("effPop"), btn = $("effBtn");
    if (sheetMode()) { sheetOpen(); return; }
    close(); closePlus(); closeLimit();
    if (!effMount()) return;
    // Keep the popover inside the card: on a narrow phone the chip sits far enough right that a
    // popover opened at its left edge would spill past the screen.
    const card = pop.offsetParent;
    const maxLeft = card ? Math.max(8, card.clientWidth - pop.offsetWidth - 8) : 8;
    pop.style.left = (btn ? Math.min(btn.offsetLeft, maxLeft) : 8) + "px";
    if (effSlider.focus) effSlider.focus();
  }
  function effUnmount() {
    const pop = $("effPop"), btn = $("effBtn");
    if (effSlider) { effSlider.destroy(); effSlider = null; }
    if (pop) pop.hidden = true;
    if (btn) btn.setAttribute("aria-expanded", "false");
  }
  function effClose() {
    if (sheetIsOpen()) { sheetClose(); return; }
    effUnmount();
  }
  function effIsOpen() { const pop = $("effPop"); return pop && !pop.hidden; }

  // SHEET_BEGIN
  // Phone sheet (owner, 11/11/2026: "sắp xếp lại mức suy luận và lựa chọn mô hình cũng như hiển thị mức dùng của gói được
  // gọn hơn"): up to 860px the ring, the model chip and the Effort chip read as ONE pill (style.css), and a tap on any
  // of them opens ONE sheet from the bottom with the three panels stacked: plan usage, Effort, model list. The panels
  // are the same elements a computer opens one by one (#limitPop, #effPop, #mbPop), so both widths share every rule.
  const sheetMq = (() => { try { return window.matchMedia("(max-width: 860px)"); } catch (e) { return null; } })();
  const sheetMode = () => !!(sheetMq && sheetMq.matches && $("cpSheet"));
  const sheetIsOpen = () => { const s = $("cpSheet"); return !!(s && s.classList.contains("is-open")); };
  const SHEET_CHIPS = ["mbOpen", "effBtn", "limitBtn"];
  let sheetHome = null;   // where #cpSheet lives in the card, to put it back on close
  function sheetOpen() {
    const s = $("cpSheet"), pop = $("mbPop"), card = $("cpSheetCard");
    if (!s || !pop || sheetIsOpen()) return;
    closePlus();
    dropKeyboard();
    // The sheet covers the whole screen, so it leaves the card for <body> while open: an ancestor that clips or
    // transforms (the Chat page slot, a sliding page) cannot cut it or drag it along.
    sheetHome = { parent: s.parentNode, next: s.nextSibling };
    document.body.appendChild(s);
    s.classList.add("is-open");
    if (card) {
      card.setAttribute("role", "dialog");
      card.setAttribute("aria-modal", "true");
      card.setAttribute("aria-labelledby", "cpSheetTitle");
      card.style.transform = "";
    }
    pop.hidden = false;
    // The list scrolls inside its panel: bring the model in use into view, it is rarely among the first rows.
    renderPop().then(() => {
      const cur = sheetIsOpen() && pop.querySelector(".mb-item.cur");
      if (cur) pop.scrollTop = Math.max(0, cur.offsetTop - pop.offsetTop - (pop.clientHeight - cur.offsetHeight) / 2);
    }).catch(() => {});
    effMount();
    try { if (window.JavisPlanLimit && window.JavisPlanLimit.showInSheet) window.JavisPlanLimit.showInSheet(); } catch (e) {}
    SHEET_CHIPS.forEach((id) => { const b = $(id); if (b) b.setAttribute("aria-expanded", "true"); });
    const x = $("cpSheetClose");
    if (x && !camUng()) { try { x.focus({ preventScroll: true }); } catch (e) {} }
  }
  function sheetClose() {
    const s = $("cpSheet"), pop = $("mbPop"), card = $("cpSheetCard");
    if (!s || !sheetIsOpen()) return;
    s.classList.remove("is-open");
    if (pop) pop.hidden = true;
    effUnmount();
    closeLimit();
    if (card) { ["role", "aria-modal", "aria-labelledby"].forEach((a) => card.removeAttribute(a)); card.style.transform = ""; }
    SHEET_CHIPS.forEach((id) => { const b = $(id); if (b) b.setAttribute("aria-expanded", "false"); });
    if (sheetHome && sheetHome.parent) {
      const next = sheetHome.next && sheetHome.next.parentNode === sheetHome.parent ? sheetHome.next : null;
      sheetHome.parent.insertBefore(s, next);
    }
    sheetHome = null;
    filter = "";
  }
  // A phone turned sideways past 860px, or a window dragged wider: the sheet goes away, the popovers take over.
  if (sheetMq) {
    const onMq = () => { if (sheetIsOpen() && !sheetMq.matches) sheetClose(); };
    if (sheetMq.addEventListener) sheetMq.addEventListener("change", onMq); else if (sheetMq.addListener) sheetMq.addListener(onMq);
  }
  // Pull the sheet down by its head to close it (the grabber says so). A short pull springs back.
  (function () {
    let y0 = null, dy = 0;
    const end = (shut) => {
      const card = $("cpSheetCard");
      y0 = null;
      if (card) { card.classList.remove("is-dragging"); card.style.transform = ""; }
      if (shut) sheetClose();
    };
    document.addEventListener("pointerdown", (e) => {
      if (!sheetIsOpen() || !e.target.closest || !e.target.closest("#cpSheetHead") || e.target.closest("#cpSheetClose")) return;
      y0 = e.clientY; dy = 0;
      const card = $("cpSheetCard"); if (card) card.classList.add("is-dragging");
    });
    document.addEventListener("pointermove", (e) => {
      if (y0 == null) return;
      dy = Math.max(0, e.clientY - y0);
      const card = $("cpSheetCard"); if (card) card.style.transform = "translateY(" + dy + "px)";
    });
    document.addEventListener("pointerup", () => { if (y0 != null) end(dy > 70); });
    document.addEventListener("pointercancel", () => { if (y0 != null) end(false); });
  })();
  // SHEET_END

  // POP_ANCHOR_BEGIN
  // Owner, 14/11/2026: "ấn vào model trong khung cộng sự popup bị nhảy lên trên khá xa với khung khiến cho việc lựa
  // chọn model bị khó khăn". The composer's popovers (model list, Effort, plan usage, the + menu) opened above the WHOLE
  // card, so a tall card (a file attached, a few lines typed) left them far above the chip, and a long model list then
  // ran past the top of the chat column, which cut its first rows off. They now open just above the row of chips and
  // stop at the top of the part of the screen in view (style.css reads the two values). A phone's sheet is not in the
  // card, so it is not affected.
  const ANCHORED_POPS = ["mbPop", "effPop", "limitPop", "plusMenu"];
  const POP_GAP = 6;     // between the popover and the row, as it was between the popover and the card
  const POP_MIN = 160;   // a few rows at least, even in a very short window
  function placePops() {
    const card = $("hudVoice"), row = $("cpRow");
    if (!card || !row || row.offsetParent !== card) return;
    card.style.setProperty("--cp-pop-bottom", Math.max(POP_GAP, card.clientHeight - row.offsetTop + POP_GAP) + "px");
    // The highest point a popover may reach: under the global header, and inside every box that clips its overflow
    // (the console view, a page body), or its top rows are cut off.
    let top = 0;
    const head = document.querySelector(".hud-top");
    if (head) { const r = head.getBoundingClientRect(); if (r.height) top = r.bottom; }
    for (let el = card.parentElement; el && el !== document.body; el = el.parentElement) {
      const cs = getComputedStyle(el);
      if (cs.overflowX !== "visible" || cs.overflowY !== "visible") top = Math.max(top, el.getBoundingClientRect().top);
    }
    const room = Math.floor(row.getBoundingClientRect().top - POP_GAP - top - 8);
    card.style.setProperty("--cp-pop-room", Math.max(POP_MIN, room) + "px");
  }
  const anyPopOpen = () => ANCHORED_POPS.some((id) => { const p = $(id); return !!(p && !p.hidden); });
  function watchPops() {
    const card = $("hudVoice");
    if (!card) return;
    // Placed the moment one opens, whoever opens it (this file, plan-limit.js, composer-plus.js), before it is painted.
    const mo = new MutationObserver(() => { if (anyPopOpen()) placePops(); });
    ANCHORED_POPS.forEach((id) => { const p = $(id); if (p) mo.observe(p, { attributes: true, attributeFilter: ["hidden"] }); });
    // And again when the card changes size while one is open (a file dropped in, the text wraps) or the window does.
    if (window.ResizeObserver) new ResizeObserver(() => { if (anyPopOpen()) placePops(); }).observe(card);
    window.addEventListener("resize", () => { if (anyPopOpen()) placePops(); });
  }
  if (document.readyState !== "loading") watchPops();
  else document.addEventListener("DOMContentLoaded", watchPops);
  // POP_ANCHOR_END

  function closeLimit() { try { if (window.JavisPlanLimit) window.JavisPlanLimit.close(); } catch (e) {} }
  function closePlus() { try { if (window.JavisComposerMenu) window.JavisComposerMenu.close(); } catch (e) {} }

  // Chọn một model: ghi mặc định chung (chat mới sau này theo cái vừa chọn) + GHIM cho phiên
  // đang mở (phiên này giữ đúng model kể cả khi mặc định chung bị đổi ở chỗ khác). Dùng chung
  // cho cú bấm trong bảng chọn và lệnh `/model <tên>` của khung chat.
  async function chonModel(prov, model) {
    // 0.285.0 (owner, 22/10/2026): in an assistant's chat (any partner, Javis Core) the choice pins THAT chat only. It
    // used to also rewrite the main chat's model. An assistant chat with no pin follows the main chat's model.
    if (!agentEff) await saveModel({ main: { provider: prov, model: model } });
    const sid = curSid();
    if (sid) {
      sessionPin = { provider: prov, model: model };
      pinBroken = false;   // ghim mới đè ghim hỏng cũ
      pinSid = sid;
      await pinToSession(sid, prov, model);
      coreChanged();
    } else {
      // Chat trống chưa mint id: nhớ lựa chọn, app.js gọi claimPending(sid) lúc gửi
      // tin đầu để phiên mới sinh ra đã mang đúng ghim.
      pendingPin = { provider: prov, model: model };
      sessionPin = null;
    }
    await loadState(); await refreshRoute(); renderBar();   // the route too: picking a card lifts its out-of-quota mark
    // The new model may lock or unlock the slider.
    if (sheetIsOpen()) effMount();
    else if (effIsOpen()) { effClose(); effOpen(); }
  }

  // `/model <tên>`: tìm trong model của các nhà ĐÃ KẾT NỐI. Khớp NGUYÊN id thì thắng ngay; nếu
  // không thì khớp một phần, và chỉ đổi khi ra ĐÚNG MỘT model - đoán bừa giữa hai nhà là đổi
  // nhầm bộ não. Trả {kind: "one"|"many"|"none", prov, model, ds}.
  async function timModel(query) {
    const q = String(query || "").trim().toLowerCase();
    if (!q) return { kind: "none" };
    const nhaOk = state.providers.filter((p) => p.configured);
    const dem = await Promise.all(nhaOk.map(async (p) => {
      let ids = [];
      try { ids = (window.JavisModelList ? await window.JavisModelList.models(p.id) : p.models) || []; }
      catch (e) { ids = p.models || []; }
      return { p, ids: ids.map((m) => (typeof m === "string" ? m : (m && (m.id || m.name)) || "")).filter(Boolean) };
    }));
    const dung = [], gan = [];
    dem.forEach(({ p, ids }) => ids.forEach((id) => {
      const k = id.toLowerCase();
      if (k === q) dung.push({ prov: p.id, model: id, label: p.label });
      else if (k.includes(q)) gan.push({ prov: p.id, model: id, label: p.label });
    }));
    const kq = dung.length ? dung : gan;
    if (kq.length === 1) return { kind: "one", prov: kq[0].prov, model: kq[0].model, label: kq[0].label };
    if (kq.length > 1) return { kind: "many", ds: kq.slice(0, 6).map((x) => (provShort(x.label) + " " + x.model)) };
    return { kind: "none" };
  }

  document.addEventListener("click", async (e) => {
    if (sheetMode() || sheetIsOpen()) {
      // Phone: the three chips are one pill and one sheet. Only a tap on the dim part or on X closes it.
      const up = sheetIsOpen();
      if (e.target.closest("#mbOpen, #effBtn, #limitBtn")) { up ? sheetClose() : sheetOpen(); return; }
      if (!up) return;
      if (e.target.closest("#cpSheetClose") || !e.target.closest("#cpSheetCard")) { sheetClose(); return; }
      if (!e.target.closest("#mbPop")) return;
    } else {
      if (e.target.closest("#mbOpen")) { isOpen() ? close() : open(); return; }
      if (e.target.closest("#effBtn")) { effIsOpen() ? effClose() : effOpen(); return; }
      if (!e.target.closest("#effPop") && effIsOpen()) effClose();
      if (!e.target.closest("#mbPop") && !e.target.closest("#mbOpen")) { if (isOpen()) close(); return; }
    }

    const goto = e.target.closest("[data-goto]");
    if (goto) {
      close();
      try { if (window.Alpine) Alpine.store("nav").go(goto.dataset.goto); } catch (er) {}
      return;
    }
    if (e.target.closest(".mb-follow")) {
      const sid = curSid();
      if (sid) await pinToSession(sid, "", "");
      coreChanged();
      sessionPin = null; pinBroken = false; pinLimited = 0; pendingPin = null;
      await loadState(); await refreshRoute(); renderBar(); close();
      return;
    }
    const item = e.target.closest(".mb-item");
    if (item) {
      await chonModel(item.dataset.prov, item.dataset.model);
      close();
      return;
    }
    const prov = e.target.closest(".mb-prov");
    // Bấm lại tên nhà đang mở là THU lại: OpenRouter hơn 300 model, không thu được thì phải
    // cuộn hết mới sang được nhà khác (chủ repo báo 27/09).
    if (prov && prov.dataset.prov) {
      expanded = expanded === prov.dataset.prov ? "" : prov.dataset.prov;
      renderPop(); return;
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (sheetIsOpen()) { sheetClose(); const m = $("mbOpen"); if (m) m.focus(); return; }
    if (isOpen()) close();
    if (effIsOpen()) { effClose(); const b = $("effBtn"); if (b) b.focus(); }
  });

  window.initModelBar = async function () {
    await loadState(); await loadSessionPin(); renderBar();
    // Tải sẵn danh sách của nhà đang dùng lúc rảnh, để lần bấm chip đầu tiên mở ra có ngay.
    try { const pid = state.main.provider; if (pid && window.JavisModelList) window.JavisModelList.models(pid); } catch (e) {}
  };

  // Phiên mới mint id xong (app.js gọi ngay lúc gửi tin đầu): model đã chọn khi khung
  // còn trống đi theo phiên vừa sinh, không bị phiên khác đổi mặc định chung đè mất.
  window.JavisModelBar = {
    claimPending: function (sid) {
      if (!pendingPin || !sid) return;
      sessionPin = pendingPin; pinSid = sid;
      pinToSession(sid, pendingPin.provider, pendingPin.model);
      pendingPin = null;
      renderBar();
    },
    // Lệnh `/model` của khung chat (chat-lenh.js): mở bảng chọn, đổi theo tên, hoặc cho biết model hiện tại.
    // Trả true nếu bảng chọn có mặt để mở (thanh model ẩn thì false, chỗ gọi tự nói model hiện tại).
    open: function () { if (!$("mbPop")) return false; open(); return true; },
    chon: async function (query) {
      const r = await timModel(query);
      if (r.kind === "one") { await chonModel(r.prov, r.model); return { kind: "one", label: provShort(r.label), model: r.model }; }
      return r;
    },
    fastNote: fastNote,
    prettyModel: prettyModel,
    // app.js hands over each turn's "route" frame (owner, 05/11/2026): the chip follows the model really answering,
    // with no reload and no engine restart. Returns the one line to add to the chat, or "".
    noteRoute: function (sid, d) {
      if (!sid || !d || !d.provider) return "";
      const line = routeLine(sid, d);
      if (sid === curSid()) { setRoute(d); renderBar(); if (isOpen()) renderPop(); }
      return line;
    },
    closeAll: function () { close(); effClose(); closePlus(); },
    // plan-limit.js asks: true while the three chips open the phone sheet, so the ring does not open its own popover.
    sheetOwns: function () { return sheetMode() || sheetIsOpen(); },
    hienTai: function () {
      const eff = shown();
      const p = state.providers.find((x) => x.id === eff.provider);
      return { label: p ? provShort(p.label) : eff.provider, model: eff.model || "" };
    },
    // app.js gọi mỗi lần GỬI TIN: server đóng dấu model đang chạy cho phiên ngay lượt
    // đầu, nên bar phải chuyển sang "ghim" tại chỗ - không chờ tới lần đổi phiên mới
    // vẽ lại, kẻo trong lúc đó đổi mặc định chung ở trang Models là bar nói sai.
    noteStamped: function (sid) {
      if (!sid || (sessionPin && pinSid === sid)) return;
      // A Javis Core chat has no stamp of its own: it runs on Javis Core's pin, or on the main model while there is none
      // (server `_chat_provider_for_session`). Showing the main model as pinned here made an unpinned Core chat look
      // pinned, and then "change" when the main model changed (owner, 04/11/2026).
      if (agentEff && agentEff.slug === "javis-core" && pinSid === sid) return;
      sessionPin = { provider: state.main.provider, model: state.main.model };
      pinBroken = false; pinSid = sid;
      renderBar();
    },
  };

  // Đổi phiên (mở phiên cũ, chat mới, xoá phiên) → hỏi lại ghim của phiên rồi vẽ lại.
  window.addEventListener("javis:sessions-changed", async () => { await loadSessionPin(); renderBar(); });
  // The Models page turned Fast mode on or off from a card's Effort sheet: the composer's bolt follows at once.
  window.addEventListener("javis:fast-changed", (e) => { state.fast = !!(e.detail && e.detail.on); renderFast(); });
  // The Core card pinned or unpinned Javis Core: an open Core chat redraws its chip.
  window.addEventListener(CORE_EVENT, async (e) => {
    if ((e.detail || {}).from === "chat" || !(agentEff && agentEff.slug === "javis-core")) return;
    await loadSessionPin(); renderBar();
  });

  // Từ điển về (fetch bất đồng bộ, thường SAU khi chip model đã vẽ) hoặc người dùng đổi
  // ngôn ngữ giao diện: vẽ lại chip, và vẽ lại cả bảng chọn nếu nó đang mở.
  window.addEventListener("javis:i18n", () => {
    renderBar();
    if (isOpen()) renderPop();
  });

  if (document.readyState !== "loading") window.initModelBar();
  else document.addEventListener("DOMContentLoaded", () => window.initModelBar());
})();
