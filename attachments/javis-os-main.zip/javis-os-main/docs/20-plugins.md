# Plugins: thêm công cụ native cho mọi engine

***Tiếng Việt** · [English](en/20-plugins.md)*

Plugin là cách thêm **công cụ mới** cho Javis mà không phải sửa mã nguồn: một thư mục Python thả vào đúng chỗ, Javis tự nạp, và từ đó mọi engine (Claude Code, ChatGPT/Codex, OpenRouter, OpenAI, Anthropic, Gemini) đều gọi được công cụ đó.

Trang này hướng dẫn đọc danh sách plugin trong dashboard, bật/tắt từng cái, hiểu 11 plugin có sẵn, và cách tự cài plugin riêng kèm rào an toàn bắt buộc phải biết trước khi làm.

## Tính năng này là gì

Một plugin là **một thư mục** gồm 2 file:

- `plugin.yaml`: khai báo tên, slug, mô tả, phiên bản, bật hay tắt, mức quyền tối thiểu, danh sách tool và hook.
- `plugin.py`: mã Python, bắt buộc có hàm `register(ctx)`. Trong hàm đó bạn gọi `ctx.register_tool(...)` để thêm tool, và/hoặc `ctx.register_hook(...)` để thêm hook.

Plugin cho Javis hai thứ:

- **Tool**: một công cụ engine gọi được, ví dụ `javis_now` (hỏi bây giờ mấy giờ theo giờ Việt Nam) hay `javis_generate_image` (tạo ảnh). Tool của plugin đi qua MCP Hub nên **mọi engine đều dùng được**, không riêng Claude Code.
- **Hook**: đoạn mã chạy **quanh mỗi lần gọi tool**. Bản hiện tại hỗ trợ hai sự kiện quanh tool: `pre_tool_call` (trước khi tool chạy) và `post_tool_call` (sau khi tool chạy xong). Khi không plugin nào đăng ký hook thì Javis không bọc gì cả, nên không tốn thêm gì. Sự kiện thứ ba, `chatbot_turn_context`, chạy một lần mỗi lượt bot chuyên trách và cho plugin thêm một dòng ngữ cảnh (xem [bên dưới](#hook-ngữ-cảnh-lượt-chatbot-chatbot_turn_context)).

Tool của plugin **tôn trọng đúng 3 mức quyền** của Javis y như tool khác, nên một loop đang ở chế độ chỉ-đọc sẽ không tự gọi được tool ghi của plugin.

## Plugin khác Skill và MCP thế nào

Ba thứ này hay bị lẫn. Phân biệt bằng câu hỏi "cái đang thiếu là gì":

| Thiếu gì | Dùng cái nào | Bản chất |
|---|---|---|
| Javis chưa biết **cách làm** một loại việc theo chuẩn của bạn | **Skill** | Một file `SKILL.md` chứa hướng dẫn. Không chạy mã, chỉ dạy AI làm đúng quy trình. Xem [Skills](06-skills.md). |
| Cần một **hành động thật** bằng Python (tính toán, biến đổi dữ liệu, gọi một API đơn giản, đọc/ghi file theo luật riêng) mà chưa có nguồn nào phủ | **Plugin** | Mã Python chạy thật, thêm tool/hook cho mọi engine. |
| Cần **nguồn dữ liệu ngoài** đã có server sẵn (POS, quảng cáo, lịch, email, ghi chú...) | **Kết nối (MCP)** | Đấu server có sẵn ở trang Kết nối, không phải viết mã. Xem [Kết nối & số liệu kinh doanh](09-mcp-va-so-lieu.md). |

Nói ngắn: skill là **tri thức cách làm**, plugin là **mã chạy thật**, MCP là **nguồn dữ liệu có sẵn**. Nếu việc bạn cần đã có MCP thì đừng viết plugin.

## Mở ở đâu trong Javis

Mở dashboard (mặc định tại cổng 7777), nhìn thanh điều hướng bên trái, bấm nhóm **Năng lực** để mở ra, rồi bấm mục **Plugins**. Đầu trang hiện tiêu đề **Plugins** kèm dòng phụ "Tool/hook native cho mọi engine".

Ngay dưới tiêu đề là ba khối giới thiệu:

1. Dòng mô tả: "Plugin thêm **tool** (công cụ engine gọi được) và **hook** native cho Javis mà không sửa lõi - dùng được ở MỌI engine (Claude Code, Codex, API) qua hub, tôn trọng 3 mức quyền như tool khác."
2. Khung cảnh báo màu cam (chỉ hiện khi máy này tắt plugin người dùng): "**⚠ Plugin do bạn cài đang bị tắt trên máy này.** Máy này đặt biến môi trường `JAVIS_ENABLE_USER_PLUGINS=false` nên plugin toàn cục/brain không chạy. Bỏ biến đó (hoặc đặt true) rồi khởi động lại Javis. Plugin có sẵn (bundled) vẫn chạy bình thường."
3. Dòng chỉ đường xám: "Thả plugin TOÀN CỤC (dùng cho MỌI brain) vào `<đường dẫn thật trên máy bạn>` · mỗi plugin gồm `plugin.yaml` + `plugin.py`. Hoặc bảo Javis trong khung chat: "tạo plugin ..."."

Đường dẫn trong dòng thứ 3 là đường dẫn **thật** trên máy đang chạy Javis, cứ sao chép từ màn hình ra chứ đừng gõ tay theo tài liệu.

Bên dưới là danh sách thẻ plugin, xếp theo nguồn: Có sẵn trước, rồi Toàn cục, rồi Brain này; trong mỗi nhóm xếp theo tên. Nếu chưa có plugin nào, trang hiện dòng "Chưa có plugin nào. Thả một thư mục plugin vào `<đường dẫn>` rồi tải lại."

## Đọc một thẻ plugin

Mỗi plugin là một thẻ. Đọc từ trên xuống:

**Dòng đầu (bên trái):** biểu tượng 🧩, tên hiển thị của plugin, rồi **slug** in nhỏ mờ (chính là tên thư mục), rồi một nhãn nguồn:

| Nhãn nguồn | Nghĩa là | Nằm ở đâu |
|---|---|---|
| **Có sẵn** (xanh lá) | Plugin đi kèm app, do Javis phát hành, tin cậy | `system/plugins/<slug>/` trong thư mục cài đặt |
| **Toàn cục** (xanh dương) | Plugin bạn tự cài, dùng chung cho **mọi brain** | Thư mục state của Javis, `<JAVIS_STATE_DIR>/plugins/<slug>/` |
| **Brain này** (cam) | Plugin bạn tự cài, chỉ dùng cho **một brain** | `<brain>/plugins/<slug>/` (brain cũ có thể là `<brain>/Javis/plugins/<slug>/`) |

Trùng slug thì nguồn sau đè nguồn trước: một plugin "Brain này" tên `datetime-vn` sẽ thay chỗ bản "Có sẵn" cùng tên.

**Dòng đầu (bên phải):** trạng thái hiện tại (xem bảng ở mục "Bảng tra nhanh nút và trạng thái").

**Dòng mô tả:** nội dung trường `description` trong `plugin.yaml`.

**Dòng thông tin:** ghép bằng dấu chấm giữa, gồm "quyền tối thiểu: ..." rồi phiên bản (`v1.0.0`) rồi tác giả. Ví dụ: "quyền tối thiểu: chỉ đọc · v1.0.0 · Javis (bundled)".

**Hàng chip:** mỗi tool plugin cung cấp là một chip có biểu tượng 🔧 kèm tên tool; mỗi hook là một chip 🪝 kèm tên sự kiện. Đây chính là những cái tên engine sẽ gọi, nên nếu muốn nhờ Javis dùng đúng tool nào, cứ nhắc tên trong chip.

**Nút cuối thẻ:** **Bật** hoặc **Tắt** (nhãn đổi theo trạng thái hiện tại).

Thẻ của plugin không chạy sẽ hiển thị mờ đi. Nếu plugin lỗi, dòng lý do lỗi hiện màu đỏ ngay dưới hàng chip.

## Cách dùng (từng bước)

### Bước 1: Xem plugin nào đang chạy

Vào **Năng lực > Plugins**. Nhìn cột trạng thái bên phải mỗi thẻ. Chỉ những thẻ ghi **● đang chạy** mới thực sự có tool bơm ra cho engine. Thẻ mờ là không dùng được lúc này.

### Bước 2: Bật hoặc tắt một plugin

1. Tìm thẻ plugin cần đổi.
2. Bấm nút **Bật** (hoặc **Tắt**) ở cuối thẻ.
3. Danh sách tự tải lại, trạng thái đổi ngay.

Với plugin **Có sẵn**, Javis không sửa file của app: lựa chọn bật/tắt được ghi ra file `plugins.json` trong thư mục state. Nhờ vậy cập nhật Javis lên bản mới **không làm mất** lựa chọn của bạn.

Với plugin **Toàn cục** và **Brain này**, Javis ghi thẳng `enabled: true/false` vào `plugin.yaml` của plugin đó.

Bật/tắt có hiệu lực ngay, không cần khởi động lại: Javis làm mới bộ nhớ đệm của hub nên tool xuất hiện hoặc biến mất ở lượt chat kế tiếp, và chỉ mục năng lực `Javis/index.md` của brain cũng được dựng lại.

Ngoại lệ duy nhất: nếu bạn bật một plugin **Toàn cục/Brain này** trên máy đặt `JAVIS_ENABLE_USER_PLUGINS=false`, Javis hiện hộp thoại báo: "Đã bật trong manifest NHƯNG máy này đang tắt plugin do người dùng cài bằng JAVIS_ENABLE_USER_PLUGINS=false. Bỏ biến đó (hoặc đặt true) rồi khởi động lại để chạy." Thẻ khi đó chuyển sang **⚠ tắt bằng env**.

### Bước 3: Kiểm tra tool đã ra tới engine chưa

Mở khung trò chuyện và hỏi thẳng, ví dụ "bây giờ mấy giờ" (plugin `datetime-vn`) hoặc "liệt kê các Trang Facebook của tôi" (plugin `meta-pages-graph`). Javis biết plugin nào đang chạy vì danh sách "Plugins đang chạy" kèm tên tool được đưa sẵn vào ngữ cảnh mỗi lượt chat.

Nếu tool bị chặn vì mức quyền, câu trả lời sẽ chứa nguyên văn dòng lỗi bắt đầu bằng `ERROR: tool '<tên>' cần mức quyền cao hơn`. Nếu tool cần một kết nối chưa có, lỗi sẽ nói rõ phải vào trang nào để đấu nối.

## Các plugin có sẵn

Đây là các plugin đi kèm app (nhãn **Có sẵn**). Tất cả bật sẵn trừ `tool-audit`.

| Tên trên thẻ | slug | Tool cung cấp | Quyền tối thiểu | Mặc định |
|---|---|---|---|---|
| Thời gian & ngày (múi giờ chọn ở Cài đặt) | `datetime-vn` | `javis_now`, `javis_date_add` | chỉ đọc | Bật |
| Đặt việc định kỳ & nhắc hẹn | `javis-schedule` | `javis_schedule` | ghi (safe) | Bật |
| Giao việc Kanban | `javis-task` | `javis_task` | ghi (safe) | Bật |
| Quản lý nhóm chat | `javis-team` | `javis_team` | ghi (safe), chỉ chủ | Bật |
| Đấu thêm MCP | `javis-connect` | `javis_add_mcp` | ghi (safe) | Bật |
| Tạo và xem ảnh (ChatGPT) | `image-chatgpt` | `javis_generate_image`, `javis_describe_image` | ghi (safe); xem ảnh: chỉ đọc | Bật |
| Đọc video YouTube | `youtube-read` | `javis_youtube_read` | chỉ đọc | Bật |
| Meta Ads (Graph API) | `meta-ads-graph` | `meta_ads_accounts`, `meta_ads_insights`, `meta_ads_campaigns`, `meta_ads_get` | chỉ đọc | Bật |
| Facebook Trang (Graph API) | `meta-pages-graph` | `fb_pages_list`, `fb_page_posts`, `fb_page_comments`, `fb_page_post`, `fb_page_photo`, `fb_page_album`, `fb_page_video`, `fb_page_edit`, `fb_page_delete`, `fb_page_reply` | toàn quyền | Bật |
| Nhật ký dùng tool | `tool-audit` | `javis_tool_stats` + hook `post_tool_call` | chỉ đọc | **Tắt** |

Từng cái làm được gì:

- **Giao việc Kanban**: giao một việc nền vào hàng đợi ngay từ chat (`op=add`) và xem việc đang chạy tới đâu (`op=list`). Có từ 0.17.1. Trước đó đường duy nhất để giao việc là `POST /kanban/task`, mà gọi được nó thì phải chạy được lệnh máy - nên chỉ Claude Code với Codex làm được, dù tài liệu vẫn hứa mọi bộ não đều làm được. Tool này gọi thẳng vào hàng đợi in-process, không mở thêm cửa HTTP nào. Mặc định giao việc ở mức `full` (tự thao tác ra ngoài như lúc chat); nói rõ nếu muốn việc chỉ ghi nháp (`auto`) hay chỉ đọc (`suggest`). Trước 0.55.62 tool này từ chối mức full và mặc định `suggest`. Chuyển cột, duyệt việc chờ phê duyệt vẫn làm ở trang Việc; huỷ việc thì làm được ngay trong chat (`op=cancel`). Từ 0.107.0 nhận thêm `route`: `auto` (một worker chung làm) hoặc `wf:<slug>` để chạy đúng một quy trình có thật; slug sai bị từ chối, còn route auto mà tên việc nhắc tới một quy trình có thật thì tool cảnh báo.
- **Quản lý nhóm chat**: nhờ Javis ngay trong chat tạo nhóm chat, đổi tên, thêm bớt trợ lý, chọn trưởng nhóm, lưu trữ hay xoá nhóm, và tạo trợ lý mới với model riêng rồi ghép vào nhóm trong một lần ("tạo nhóm thử gồm ba trợ lý, mỗi người một model"). Có từ 0.173.0. Tool gọi thẳng cùng bộ thao tác mà trang Nhóm dùng, nên luật y như bấm tay. Xoá chỉ nhận nhóm đã lưu trữ và chỉ khi bạn nói rõ là xoá; file trợ lý không bị xoá theo. Bot chăm khách không thấy tool này. Từ 0.357.0 tool còn **giao một việc cho Team có sẵn** (op `dispatch`) và đọc lại trạng thái, nghiệm thu của việc (op `job`); kết quả tự báo về khung chat đã giao.
- **Đấu thêm MCP**: nhờ Javis ngay trong chat đấu một nguồn MCP mới, và nó **hiện ra trang Kết nối** ở khu "Đã kết nối" như tài khoản bạn tự thêm bằng tay, dùng chung cho mọi bộ não. Trước plugin này Javis không có đường nào ghi vào kho kết nối, nên nó chỉ còn cách chạy `claude mcp add` - server đó rơi vào cấu hình riêng của Claude Code, sáu bộ não còn lại không thấy, và trên trang Kết nối nó không nằm ở khu "Đã kết nối" mà lọt xuống khu gập "Kết nối sẵn của Claude Code và Codex" (mặc định đóng), nên nhìn vào tưởng như chẳng có gì được thêm. Ba rào an toàn: mức quyền mặc định là **chỉ đọc** (muốn cho ghi thì bạn tự nâng ở trang Kết nối); nguồn chạy bằng **lệnh trên máy** (stdio) được thêm ở trạng thái **tắt** để bạn tự đọc lệnh rồi mới bật; dịch vụ đã có sẵn trong Kho kết nối (Gmail, Lịch, POS...) thì Javis chỉ tay sang đúng card chứ không đẻ một bản tự khai song song. Thử kết nối hỏng thì mục đó **vẫn nằm lại** trang Kết nối kèm lý do, chứ không biến mất im lặng.
- **Zalo mở rộng (gói `javis.zalo` trên Javis Store)**: từ 0.73.0 các tool Zalo bù chỗ MCP chuẩn còn thiếu không còn đi sẵn trong app nữa, để ai không dùng Zalo thì không phải mang theo. Gói gồm gửi ảnh và file (`zalo_send_image`), tag đúng người, ghi chú, nhắc hẹn, poll trong nhóm (`zalo_group_members`, `zalo_send_mention`, `zalo_create_note`, `zalo_create_reminder`, `zalo_create_poll`) và đọc ảnh trong nhóm (`zalo_read_images`). Quét QR Zalo xong là Javis mời cài; máy đã dùng Zalo từ trước thì trang Kết nối hiện nút cài. Chi tiết ở [Zalo](12-zalo.md).
- **Thời gian & ngày (VN)**: cho Javis biết hôm nay là ngày nào, mấy giờ, thứ mấy theo giờ Việt Nam (UTC+7), và tính ngày tương đối ("3 ngày nữa", "tuần trước"). Thuần thư viện chuẩn, không cần mạng. Đây cũng là plugin mẫu đơn giản nhất để đọc khi bạn muốn tự viết plugin.
- **Đặt việc định kỳ & nhắc hẹn**: cho phép tạo, liệt kê, huỷ việc định kỳ và nhắc hẹn **ngay trong câu chat**, khỏi gõ YAML tay. Việc lặp và bền được ghi ra `Javis/loops/<slug>.md` (mở sửa được trong Obsidian); nhắc một lần hoặc lịch cron thì vào kho nhắc hẹn. Chi tiết ở [Việc định kỳ & Nhắc hẹn](08-viec-dinh-ky.md).
- **Tạo ảnh (ChatGPT)**: tạo ảnh từ mô tả bằng chính **gói ChatGPT** bạn đang đăng nhập (OAuth), không cần khoá API OpenAI. Ảnh lưu vào `attachments/` của brain rồi nhúng thẳng vào câu trả lời. Cần đã kết nối ChatGPT ở trang **Models**; chưa kết nối thì tool trả về câu "Chưa kết nối ChatGPT (OAuth). Vào trang Model đăng nhập ChatGPT rồi thử lại...".
- **Đọc video YouTube**: dán link video vào chat rồi nhờ tóm tắt. Plugin lấy **phụ đề thật** của video (đường mà trình phát YouTube dùng) nên Javis đọc được lời thoại chứ không đoán theo tiêu đề. Không cần khoá API, không cần đăng nhập YouTube, chạy trên **mọi engine** kể cả engine API vốn không mở được URL. Khi YouTube chặn máy chủ, nó tự đổi lần lượt qua sáu kiểu trình phát rồi mới nhờ tới yt-dlp, nên vượt được phần lớn ca bị nghi là robot. Video không có phụ đề, video riêng tư hoặc bị YouTube chặn thì tool nói thẳng lý do để Javis khỏi bịa. Video dài bị cắt bớt thì nhờ "đọc tiếp" là nó đọc khúc sau. Chi tiết ở [Trò chuyện](02-tro-chuyen-va-giong-noi.md).
- **Luật cho từng cuộc chat Zalo**: đặt cách ứng xử cho từng nhóm hoặc từng khách trên Zalo bằng lời (im lặng, báo mọi tin, báo theo từ khoá, nhắc khi quên trả lời quá N phút). Luật ghi ra `Javis/zalo/<slug>.md` nên xem và sửa lại được.
- **Gửi tin Zalo an toàn**: gửi tin Zalo thay cho tool thô. Nó khoá cứng vào tài khoản đang nghe và chỉ gửi được cho cuộc chat trong danh sách đang theo dõi; tên khớp nhiều người thì từ chối và bắt hỏi lại. Hai plugin Zalo dùng chung với [Kênh Zalo](12-zalo.md).
- **Meta Ads (Graph API)**: đọc số liệu quảng cáo Facebook/Instagram (danh sách tài khoản ads, chiến dịch, hiệu suất). **Chỉ đọc, không tiêu tiền.** Cần đã đấu kết nối "Meta Ads (Facebook & Instagram)" ở trang Kết nối.
- **Facebook Trang (Graph API)**: quản lý Trang/Fanpage. Đọc danh sách Trang, bài và bình luận là chỉ-đọc; đăng bài, đăng ảnh, đăng album, đăng video, sửa chữ, xoá bài, trả lời bình luận là hành động **thật, công khai** và cần mức toàn quyền. Dùng Fanpage đã nối ở thẻ Facebook Messenger trang Kết nối (hoặc kết nối "Facebook Trang" trong Kho nếu đã cài từ trước).
- **Theo dõi Facebook (Apify)** không còn nằm sẵn trong Javis (từ 12/11/2026): tool `fb_monitor` đi cùng gói **Theo dõi Facebook (Apify)** trong Kho cài đặt. Đã cài gói đó từ trước thì bấm cập nhật gói là có lại; chưa cài thì cài gói rồi dán Personal API token của apify.com ở trang Kết nối.
- **Nhật ký dùng tool**: đếm số lần **mỗi** tool được engine gọi (qua hook `post_tool_call`) rồi cho xem thống kê tool hay dùng nhất. Đây là ví dụ minh hoạ cơ chế hook, nên mặc định để tắt; bật ở trang Plugins, chat vài lượt có gọi tool, rồi hỏi Javis "tool nào hay dùng nhất".

Lưu ý về cột "Quyền tối thiểu": đó là mức khai báo cho **cả plugin** và là cái hiển thị trên thẻ. Từng tool bên trong vẫn có mức riêng. Ví dụ `meta-pages-graph` ghi "toàn quyền" trên thẻ, nhưng ba tool đọc bài/bình luận của nó chỉ cần mức chỉ-đọc, còn các tool đăng và xoá mới cần toàn quyền.

## Plugin đến từ một Gói

Từ 0.55.23, một **Gói** cài ở trang **Năng lực > Kho cài đặt** mang theo được cả plugin, tức cả công cụ mới, chứ không chỉ dịch vụ kết nối. Thẻ của chúng hiện ở trang này với nhãn nguồn **Từ gói**.

Khác ba nguồn kia ở ba điểm:

- **Bật, tắt và gỡ đều làm ở Kho cài đặt**, không làm ở đây. Plugin đi theo cả gói, nên tách ra bật lẻ chỉ gây nhầm. Thẻ ở trang này có nút dẫn thẳng sang đó.
- **Biến môi trường `JAVIS_ENABLE_USER_PLUGINS` không áp cho gói.** Gói đi qua trình cài, tức bạn đã xem màn hình liệt kê từng tệp mã rồi mới bấm đồng ý, và chữ ký mã được đối chiếu mỗi lần nạp.
- **Mã trong gói bị khoá theo nội dung.** Lúc cài, Javis ghi lại một dấu vân tay của toàn bộ mã trong gói. Mỗi lần nạp, nó tính lại và đối chiếu: lệch một byte là plugin **không chạy**, và thẻ nói rõ "mã trong gói đã đổi so với lúc bạn đồng ý cài". Muốn dùng tiếp thì cài lại ở Kho cài đặt để xem và xác nhận lại.

Lưu ý khi tự sửa: mở tệp `plugin.py` của một gói bằng trình soạn thảo trên Windows rồi lưu là đủ để dấu vân tay lệch, vì nhiều trình soạn thảo tự đổi ký tự xuống dòng. Đó không phải lỗi, chỉ là nội dung tệp thật sự đã khác. Sửa plugin thì nên sửa trong thư mục plugin của bạn chứ không sửa trong gói.

Một gói **không được** mang plugin trùng tên với plugin có sẵn của Javis. Trình cài từ chối ngay và nói tên bị trùng, để không có chuyện một gói lặng lẽ thay thế công cụ lõi.

## Gỡ hẳn một plugin khỏi danh sách

Nút **Tắt** giữ thẻ lại cho bạn nhìn; nút **Gỡ** thì cho nó biến khỏi danh sách chính. Cả hai đều làm tool của plugin biến mất khỏi mọi bộ não, khác nhau ở chỗ bạn còn định dùng lại hay không.

Gỡ **không xoá tệp** trong bản cài. Javis chỉ ghi nhớ lựa chọn đó vào thư mục state, nên cập nhật Javis lên bản mới không làm plugin mọc lại, mà cài lại thì chỉ mất một cú bấm ở mục **Đã gỡ** nằm cuối trang (mặc định gập).

Áp cho cả plugin **Có sẵn** đi kèm Javis. Đây là cách dọn bộ mặc định cho gọn nếu bạn không dùng tới.

## Mức quyền tối thiểu và chế độ chạy

Mỗi tool plugin khai báo một mức quyền tối thiểu; mỗi lượt chạy của Javis lại có một trần quyền. Tool chỉ chạy khi trần của lượt chạy đủ cao.

| Mức tối thiểu của tool (nhãn trên thẻ) | Ý nghĩa | Chạy được ở chế độ nào |
|---|---|---|
| `readonly` - "chỉ đọc" | Chỉ đọc hoặc tính toán, không đổi gì | Mọi chế độ |
| `safe` - "ghi (safe)" | Có ghi file hoặc tiêu quota | Chế độ Tự làm an toàn và Toàn quyền |
| `full` - "toàn quyền" | Hành động thật ra ngoài (đăng bài, xoá, gửi) | Chỉ chế độ Toàn quyền |

Khung chat bạn gõ tay chạy ở mức đầy đủ nên gọi được cả ba loại. Ngược lại, một [việc định kỳ](08-viec-dinh-ky.md) đang để chế độ **Đề xuất** chỉ chạy được tool chỉ-đọc; gặp tool mức cao hơn nó trả về `ERROR: tool '<tên>' cần mức quyền cao hơn (...)` và dừng lại thay vì làm liều. Đây là lớp chặn cứng trong mã, không phải lời dặn trong prompt, nên model không "nói khéo" để vượt được.

## Cài plugin của bạn

### Bước 1: Chọn nơi đặt

Có hai chỗ, tuỳ bạn muốn plugin dùng chung hay dùng riêng:

- **Toàn cục** (khuyên dùng): `<JAVIS_STATE_DIR>/plugins/<slug>/`. Mọi brain đều thấy plugin này, và mọi engine đều gọi được. Đường dẫn thật đang hiện sẵn ở dòng chỉ đường trên trang Plugins, cứ sao chép từ đó. Mặc định `JAVIS_STATE_DIR` là thư mục `server/` của dự án; trên Docker/VPS thường là `/data/state`.
- **Riêng một brain**: `<brain>/plugins/<slug>/`. Chỉ brain đó dùng được. Hợp khi plugin gắn chặt với dữ liệu của một brain cụ thể.

`<slug>` là tên thư mục, phải là chữ thường ASCII không dấu, bắt đầu bằng chữ hoặc số, chỉ chứa chữ số, dấu chấm, gạch dưới, gạch nối. Sai kiểu chữ thì Javis bỏ qua plugin và báo "slug không hợp lệ".

### Bước 2: Viết plugin.yaml

```yaml
name: Tính tiền ship
slug: tinh-tien-ship
version: 1.0.0
description: Tính phí giao hàng theo cân nặng và khu vực theo bảng giá của shop.
author: Bạn
enabled: false            # luôn tạo ở trạng thái TẮT, tự bật sau khi đọc lại mã
min_mode: readonly        # readonly | safe | full
tools: [tinh_tien_ship]
hooks: []                 # ví dụ: [post_tool_call]
```

Hai trường `tools` và `hooks` ở đây chỉ để **hiển thị chip trên thẻ**. Cái thực sự tạo ra tool là mã trong `plugin.py`, nên hãy giữ hai danh sách này khớp với mã cho khỏi rối.

### Bước 3: Viết plugin.py

```python
def register(ctx):
    def handler(args, ctx):        # args là dict; trả về chuỗi. Lỗi thì trả "ERROR: ..."
        kg = float((args or {}).get("kg") or 0)
        return f"Phí ship: {int(kg * 5000)} đồng"

    ctx.register_tool(
        name="tinh_tien_ship",
        description="Tính phí giao hàng theo cân nặng (kg). Dùng khi khách hỏi phí ship.",
        handler=handler,
        min_mode="readonly",
        schema={"type": "object",
                "properties": {"kg": {"type": "number", "description": "Cân nặng kiện hàng"}},
                "required": ["kg"]},
    )
```

Vài điều cần nhớ khi viết:

- Tên tool phải bắt đầu bằng chữ thường, chỉ gồm chữ thường, số và gạch dưới.
- `description` là thứ engine đọc để quyết định **khi nào** gọi tool, nên viết rõ tình huống và tham số. Mô tả mờ thì tool nằm im không ai gọi.
- Handler có thể là hàm thường hoặc `async`. Trả về chuỗi là gọn nhất; trả về dict thì Javis tự chuyển thành JSON.
- `ctx` có sẵn `ctx.slug`, `ctx.vault_root` (brain đang làm việc) và `ctx.data_dir` (thư mục riêng để plugin lưu state, **không** nằm trong brain nên không làm bẩn ghi chú của bạn).
- Muốn tool tự từ chối khi chưa đủ điều kiện (chưa đăng nhập, thiếu khoá), truyền thêm `check_fn=` là một hàm trả về `None` khi sẵn sàng hoặc một câu tiếng Việt giải thích khi chưa.
- Một plugin lỗi **không làm sập** Javis: mọi bước nạp, mọi lần gọi tool và hook đều được bọc lại, lỗi chỉ hiện trên thẻ plugin đó.

### Bước 4: Bật plugin

Từ 0.162.0, Javis **tải plugin do bạn cài theo mặc định**: plugin nào có `enabled: true` (tức bạn đã bấm **Bật** trên thẻ) là chạy, không cần biến môi trường nào.

Muốn chặn hẳn plugin người dùng trên một máy (ví dụ máy chủ dùng chung):

1. Mở file `.env` ở thư mục gốc dự án (chưa có thì tạo, xem [Cấu hình .env](16-cau-hinh-env.md)).
2. Thêm một dòng: `JAVIS_ENABLE_USER_PLUGINS=false`
3. Lưu file và **khởi động lại Javis**.

Giá trị tắt nhận `0`, `false`, `no` hoặc `off` (không phân biệt hoa thường). Tên cũ `JAVIS_ENABLE_VAULT_PLUGINS` vẫn còn tác dụng, nhưng nếu đặt cả hai thì tên mới thắng.

## Rào an toàn (đọc trước khi cài plugin lạ)

Đây là phần quan trọng nhất của trang này.

- **Plugin do bạn cài chạy mã Python thật, trong chính tiến trình server của Javis.** Nó có quyền của tiến trình đó: đọc ghi file, gọi mạng, đọc biến môi trường. Từ 0.162.0 chủ dự án quyết định **cho tải mặc định**; chốt chặn còn lại là công tắc **Bật** của từng plugin (`enabled: true` trong `plugin.yaml`).
- **Chỉ bật plugin khi bạn đã tự đọc mã của nó.** Lưu ý: ai ghi được vào thư mục `plugins/` (kể cả model, vì nó ghi được vào brain) cũng có thể ghi `enabled: true`. Máy chủ dùng chung hoặc chạy bot cho người lạ thì nên đặt `JAVIS_ENABLE_USER_PLUGINS=false`.
- **Plugin có sẵn (nhãn "Có sẵn") không chịu công tắc này** vì chúng đi kèm bản phát hành Javis. Chúng vẫn chạy bình thường kể cả khi máy đặt `false`.
- **Plugin do Javis tạo qua chat luôn ở trạng thái tắt** (`enabled: false`) và mức `readonly`. Javis không tự bật hộ; bạn phải đọc mã rồi tự bấm **Bật**.
- **Đừng viết plugin để làm hành động tiền bạc, tạo đơn, gửi tin hay đăng bài.** Những việc đó nên đi qua kết nối MCP và hệ mức quyền, nơi đã có lớp chặn và nhật ký. Plugin nên để `min_mode: readonly` trừ khi bạn cố ý cần khác.
- **Đừng nhân bản plugin có sẵn vào brain.** Chúng đi theo app và tự cập nhật; bản sao trong brain sẽ đè mất bản gốc và không được cập nhật nữa.

## Nhờ Javis tạo plugin bằng lời

Bạn không cần tự gõ hai file. Mở khung trò chuyện và nói thẳng, ví dụ: "Tạo cho tôi một plugin tính phí ship theo cân nặng, bảng giá 5 nghìn một ký, dưới 1 ký tính tròn."

Javis sẽ tự chọn loại năng lực phù hợp trước (nếu chỉ cần hướng dẫn thì nó tạo skill, nếu là nguồn dữ liệu có sẵn thì nó khuyên đấu MCP), kiểm tra trùng với những gì brain đã có, rồi mới ghi thư mục plugin. Khi tạo xong nó báo lại tên file và nhắc bạn rằng plugin đang tắt cùng cách mở khoá biến môi trường.

Sau đó bạn tự làm 3 việc: mở `plugin.py` đọc lại mã (dùng trang **Tệp tin** nếu plugin nằm trong brain), đặt biến môi trường nếu chưa có, rồi vào **Plugins** bấm **Bật**.

## Hook: chạy quanh mỗi lần gọi tool

Ngoài tool, plugin còn đăng ký được hook. Bản hiện tại có hai sự kiện:

| Sự kiện | Bắn khi nào | Nhận được gì |
|---|---|---|
| `pre_tool_call` | Ngay trước khi một tool bất kỳ chạy | `tool_name`, `args`, `mode`, `vault_root`, `turn` |
| `post_tool_call` | Ngay sau khi tool chạy xong | thêm `result` |

`turn` cho hook biết **ai đang nói** trong lượt gọi tool đó: `kenh` (kênh), `sender_id` (mã người gửi tin này, trong nhóm vẫn là người gửi chứ không phải nhóm), `chat_type` (`private` hoặc `group`), `chat_id` (cuộc trò chuyện) và `la_chu` (`true` ở dashboard và kênh quản trị của chủ, luôn `false` với bot chuyên trách). Không xác định được (việc nền, engine chưa mang được khoá lượt) thì `turn` là `None`: hook cần danh tính phải coi `None` là "không ai", đừng coi là chủ máy.

Hook bọc **mọi** tool call, kể cả tool của MCP và tool lõi, chứ không riêng tool của plugin đó. Dùng để ghi nhật ký, đếm, cảnh báo. Khi không plugin nào đăng ký hook, Javis không bọc gì nên không mất thêm hiệu năng. Plugin `tool-audit` là ví dụ chạy được: bật nó lên là mỗi lượt gọi tool được đếm vào một file riêng của plugin.

## Hook ngữ cảnh lượt chatbot (`chatbot_turn_context`)

Sự kiện thứ ba không bọc tool call mà chạy **một lần mỗi lượt bot chuyên trách trả lời**, ngay trước khi engine soạn câu. Nó giải một việc mà mô hình tự làm không được: biết **tài khoản nào** đang nhắn. Mô hình chỉ thấy tên hiển thị, mà tên thì ai cũng gõ được ("em là mẹ bé An"). Lớp kênh thì biết mã tài khoản thật, và hook này chuyển mã đó cho plugin, không cho mô hình.

Callback nhận các khoá sau (luôn khai `**kwargs`, khoá mới có thể thêm về sau):

| Khoá | Ý nghĩa |
|---|---|
| `channel` | Kênh của lượt: `zalo_personal`, `telegram`, `zalo`, `messenger`... |
| `account_id` | Tài khoản kênh mà bot đang trực, rỗng nếu bot chưa gắn tài khoản |
| `bot_id` | Mã bot chuyên trách |
| `chat_type` | `private` hoặc `group` |
| `chat_id` | Cuộc trò chuyện (trong nhóm là mã nhóm) |
| `sender_id` | Mã tài khoản do nền tảng cấp cho người gửi tin này, không bao giờ là tên hiển thị. Trong nhóm vẫn là người gửi. Sự kiện có người vào nhóm thì rỗng |
| `vault_root` | Đường dẫn brain của bot |
| `trial` | `true` ở lượt **Thử bot** |

Callback trả về **một dòng chữ ngắn** hoặc `None`. Javis đặt dòng đó vào prompt hệ thống của đúng lượt này, trong một khối có nhãn và rào `<operator_context>`, ghi rõ đây là thông tin từ hệ thống của chủ bot chứ không phải lời người nhắn tự khai.

```python
def register(ctx):
    def _ngu_canh(sender_id="", chat_type="", **kwargs):
        if chat_type != "private":
            return None                      # nhóm: không nói gì
        return "Khách quen" if sender_id in KHACH_QUEN else None
    ctx.register_hook("chatbot_turn_context", _ngu_canh)
```

Rào Javis tự giữ, plugin không nới được:

- **Không plugin nào nghe thì prompt giống hệt từng byte** như trước khi có hook này.
- Lõi **không bao giờ tự ghi mã người gửi vào prompt**. Chỉ dòng plugin trả về mới vào, nên plugin nên trả kết luận ("đã xác nhận") chứ đừng trả lại mã.
- Mỗi dòng bị ép về **một dòng**: xuống dòng, ký tự điều khiển, ký tự đảo chiều và ký tự vô hình thành dấu cách; cắt ở **300 ký tự**. Nhiều plugin thì mỗi plugin một dòng, tổng **900 ký tự**. Chữ `<operator_context>` trong dòng bị gỡ để không ai đóng được khối.
- Callback ném lỗi hoặc chạy quá **2 giây** thì bị bỏ qua và ghi log, lượt trả lời vẫn đi tiếp. Callback đồng bộ chạy ở luồng riêng nên không chặn các cuộc chat khác.
- Mỗi callback nhận **bản sao riêng** của các khoá: plugin trước sửa gì cũng không đổi thứ plugin sau thấy.

Ba loại lượt đều bắn hook: lượt thật, lượt **Trả lời giúp tin này / Gợi ý câu trả lời** ở Hộp thư (người gửi là người nhắn tin cuối của cuộc chat), và lượt **Thử bot**. Lượt thử mang `trial: true` và người gửi giả của trang thử (`javis-try-user`, cuộc chat `javis-try`), cùng người gửi giả mà lượt thử vẫn dùng cho mọi kiểm tra theo người. Mã giả đó không khớp ai thật, nên plugin kiểu sổ danh sách sẽ cho thấy nhánh "người lạ". Muốn xử lý lượt thử khác đi thì plugin tự đọc `trial`.

Plugin dùng hook này vẫn chịu đúng rào chung: plugin người dùng tự cài chỉ chạy khi đặt `JAVIS_ENABLE_USER_PLUGINS=true`, plugin của Gói đi qua trình cài, và nên khai `min_mode: readonly` nếu nó chỉ đọc.

## Trang riêng và đường HTTP (từ 0.64.26)

Plugin mở được đường web của riêng nó, dưới `/ext/<slug>/`. Dùng cho trang cài đặt, hoặc cho dịch vụ bên ngoài gọi vào (webhook, cửa OAuth). Gói **Javis Gate** (`javis.gate`) trong kho là ví dụ chạy thật.

```python
def register(ctx):
    ctx.register_http("", trang_cai_dat)                          # phải đăng nhập dashboard
    ctx.register_http("webhook", nhan_tin, methods=("POST",),
                      public=True, no_cookie=True)                # máy chủ ngoài gọi vào
    ctx.register_well_known("oauth-authorization-server", meta)  # /.well-known/...
```

- **Mặc định phải đăng nhập bằng trình duyệt.** Token API không mở được trang của plugin.
- **`public=True`**: vào không cần đăng nhập, plugin tự xác thực (chữ ký, token). Chỉ áp cho đúng method đã khai.
- **`no_cookie=True`** (đi cùng `public`): miễn chặn CSRF, và Javis gỡ hẳn cookie trước khi giao request cho plugin.
- **`register_well_known`**: chỉ GET, công khai, không cookie. Hai plugin xin cùng tên thì plugin nạp trước giữ.
- Khai `page: ""` trong `plugin.yaml` thì thẻ plugin có nút **Mở trang**.
- Chỉ plugin đi kèm app, plugin của gói đã cài và plugin toàn cục mới có đường. **Plugin trong brain thì không**, vì model ghi được vào brain.

## Javis Gate: AI bên ngoài nhắn vào khung chat (từ 0.440.0)

Gói **Javis Gate** (`javis.gate`) mở cửa MCP có OAuth cho ChatGPT, Claude và AI khác. Ngoài bộ công
cụ Javis đã có, cửa này có thêm năm công cụ chỉ AI bên ngoài thấy (`server/chat_bridge.py`):

| Công cụ | Việc | Mức quyền |
|---|---|---|
| `javis_chat_find` | Tìm hội thoại theo tên (không phân biệt dấu) hoặc nội dung | Mọi mức |
| `javis_chat_read` | Đọc các tin cuối của một hội thoại | Mọi mức |
| `javis_chat_send` | Nhắn vào hội thoại như chủ gõ, chờ câu trả lời | Chỉ Toàn quyền |
| `javis_chat_result` | Đọc câu trả lời khi Javis làm lâu | Mọi mức |
| `javis_chat_note` | Ghi lại cuộc chat bên ngoài: chủ nói gì, đã chốt gì (từ 0.441.0) | Ghi nháp, Toàn quyền |

- **Tin nhắn chạy đúng như chủ gõ:** đi qua chính vòng chat của dashboard, nên chữ chạy trên mọi tab
  đang mở, có nút Dừng, lưu vào Lịch sử, ghi `memory/conversations` và vào vòng tự học. Bong bóng
  tin mang nhãn **từ ChatGPT** hay **từ Claude**.
- **Hội thoại đang trả lời** thì tin thành tin gõ thêm, như khi chủ gõ thêm lúc Javis đang làm.
- **Chỉ hội thoại của chủ** (khung Trò chuyện, chat với Cộng sự). Hội thoại của khách và nhóm chat thì
  không đọc, không nhắn được.
- **Ghi chép không chạy Javis:** `javis_chat_note` chỉ lưu, không tốn hạn mức bộ não của Javis, nhưng đi
  qua đúng đường lưu lượt chat nên vẫn vào Lịch sử, nhật ký và vòng tự học. Mỗi cuộc chat bên ngoài có một
  hội thoại riêng **Từ ChatGPT: <tên>** (hay **Từ Claude: ...**); đưa `id` thì ghi thẳng vào hội thoại đó
  của Javis. Javis không đọc được lịch sử chat của ChatGPT hay Claude, nên đây là cách AI bên ngoài tự gửi
  sang phần đáng giữ.
- Năm công cụ **không bao giờ** có trong bộ công cụ của chính Javis: chúng chỉ hiện khi cửa của gói gọi
  `mcp_hub.tra_loi_jsonrpc(..., gate={"source": "<tên AI>"})`.

## Bảng tra nhanh nút và trạng thái

| Bạn thấy | Ý nghĩa / thao tác |
|---|---|
| **● đang chạy** (xanh lá) | Plugin đã nạp, tool của nó đang có mặt cho engine |
| **⚠ tắt bằng env** (cam) | Bạn đã bật plugin nhưng máy này đặt `JAVIS_ENABLE_USER_PLUGINS=false` |
| **⚠ lỗi** (đỏ) | Manifest hỏng hoặc mã nạp không được; lý do hiện ngay dưới hàng chip |
| **○ tắt** (xám) | Plugin có mặt nhưng đang tắt, không có tool nào ra |
| **● bật (chưa nạp)** (cam) | Trạng thái hiếm: đã bật nhưng chưa nạp được vì lý do khác. Tải lại trang, nếu vẫn vậy thì xem log server |
| Nhãn **Có sẵn** / **Toàn cục** / **Brain này** | Nguồn của plugin (app / thư mục chung mọi brain / một brain) |
| Chip **🔧 tên** | Một tool plugin cung cấp; đây là tên engine sẽ gọi |
| Chip **🪝 tên** | Một hook plugin đăng ký (`pre_tool_call`, `post_tool_call` hoặc `chatbot_turn_context`) |
| "quyền tối thiểu: chỉ đọc / ghi (safe) / toàn quyền" | Mức quyền tối thiểu để tool của plugin được phép chạy |
| Nút **Bật** | Bật plugin (thẻ đang tắt) |
| Nút **Tắt** | Tắt plugin (thẻ đang bật) |
| Thẻ hiển thị mờ | Plugin không đang chạy |
| Khung cảnh báo cam đầu trang | Chưa mở khoá plugin người dùng; plugin có sẵn vẫn chạy |

## Mẹo

- Trước khi định viết plugin, hỏi lại: cái thiếu là **cách làm** hay **hành động**? Thiếu cách làm thì viết skill, rẻ và dễ sửa hơn nhiều.
- Đọc `system/plugins/datetime-vn/plugin.py` làm mẫu khởi động: nó ngắn, thuần thư viện chuẩn, đủ minh hoạ một tool đọc. Muốn xem mẫu có hook thì đọc `tool-audit`.
- Đặt plugin ở **Toàn cục** trừ khi có lý do rõ ràng để buộc vào một brain. Toàn cục không phụ thuộc brain nên bạn đổi brain vẫn dùng được.
- Không dùng plugin nào thì **tắt** thay vì xoá thư mục, để lần sau bật lại là xong.
- Tắt bớt plugin không dùng cũng làm gọn danh sách tool đưa cho model, giúp nó chọn tool đúng hơn.
- Muốn biết Javis đang thấy những năng lực gì (agent, skill, workflow, loop, plugin) thì mở file `Javis/index.md` trong brain bằng trang **Tệp tin**; file này tự dựng lại mỗi khi bạn bật/tắt plugin.

## Sự cố thường gặp

- **Thẻ ghi "⚠ tắt bằng env":** máy này đặt `JAVIS_ENABLE_USER_PLUGINS=false`. Bỏ dòng đó trong `.env` (hoặc đặt `true`) rồi khởi động lại Javis. Biến này chỉ được đọc lúc khởi động.
- **Đã đặt biến môi trường mà vẫn bị chặn:** kiểm tra file `.env` nằm đúng thư mục gốc dự án, dòng biến không bị dấu `#` ở đầu, và giá trị là `true` (hoặc `1`/`yes`/`on`). Trên Docker thì đặt biến ở phần Environment của container chứ không phải trong file trên máy chủ.
- **Plugin mới thả vào mà không hiện trên trang:** thư mục phải nằm **trực tiếp** trong thư mục plugins (không lồng thêm cấp), và bên trong phải có `plugin.py` (hoặc `__init__.py`). Thiếu thì Javis không coi đó là plugin. Tên thư mục cũng phải là slug hợp lệ (chữ thường không dấu).
- **Thẻ ghi "⚠ lỗi" kèm "thiếu plugin.py":** thư mục chỉ có `plugin.yaml`. Thêm file mã vào.
- **Thẻ ghi "⚠ lỗi" kèm "manifest lỗi: ...":** `plugin.yaml` sai cú pháp YAML. Hay gặp nhất là mô tả có dấu hai chấm mà không bọc nháy.
- **Thẻ ghi "⚠ lỗi" kèm "thiếu hàm register(ctx)":** `plugin.py` chưa có hàm `register`, hoặc bạn đặt tên khác. Hàm phải tên đúng là `register` và nhận một tham số.
- **Thẻ ghi "⚠ lỗi" kèm tên một lỗi Python (ví dụ `ModuleNotFoundError`):** mã plugin dùng thư viện chưa cài trong môi trường Python của Javis. Cài thư viện đó vào đúng môi trường ảo Javis đang chạy, rồi khởi động lại.
- **Plugin đang chạy nhưng engine không thấy tool:** nhiều khả năng tên tool **trùng** với một tool đã có của MCP hoặc tool lõi. Javis không cho plugin chiếm chỗ tool lõi, nó bỏ qua tool trùng và ghi một dòng vào log server. Đổi tên tool trong `plugin.py` cho khác đi (đặt tiền tố riêng là cách chắc nhất). Các tên lõi không được dùng lại: `javis_connections`, `javis_read_file`, `javis_list_dir`, `javis_write_file`, `javis_use_skill`.
- **Tool trả về `ERROR: tool '<tên>' cần mức quyền cao hơn`:** lượt chạy đang bị hạn chế mức quyền. Nếu là việc định kỳ, nâng chế độ của việc đó (xem [Việc định kỳ & Nhắc hẹn](08-viec-dinh-ky.md)); nếu là plugin của bạn thì xem lại `min_mode` khai trong `register_tool`.
- **Tool trả về "Chưa kết nối ...":** plugin cần một kết nối mà bạn chưa đấu. Làm theo đúng câu hướng dẫn trong lỗi, thường là vào trang **Kết nối** (hoặc **Models** với plugin tạo ảnh).
- **Bấm Bật báo "không tìm thấy plugin":** danh sách trên màn hình đã cũ so với đĩa (bạn vừa xoá hoặc đổi tên thư mục). Tải lại trang.
- **Bấm Bật báo "ghi manifest lỗi":** Javis không ghi được vào `plugin.yaml`, thường do quyền thư mục hoặc file đang mở khoá bởi chương trình khác. Xem thêm [Khắc phục sự cố & FAQ](17-khac-phuc-su-co.md).

## Liên quan

- [Skills](06-skills.md) - khi cái bạn thiếu là tri thức cách làm chứ không phải mã chạy.
- [Kết nối & số liệu kinh doanh](09-mcp-va-so-lieu.md) - đấu nguồn dữ liệu ngoài; các plugin Meta Ads, Facebook Trang và Apify lấy token từ đây.
- [Models & engine](10-models-va-engine.md) - vì sao mọi engine đều gọi được tool của plugin.
- [Việc định kỳ & Nhắc hẹn](08-viec-dinh-ky.md) - ba mức quyền của việc chạy nền, và plugin `javis-schedule`.
- [Zalo Agent MCP](12-zalo.md) - Zalo nay dùng MCP của CLI riêng `javis-zalo`, không còn plugin riêng.
- [Cấu hình .env](16-cau-hinh-env.md) - cách đặt biến môi trường và khởi động lại.
- [Agents & Workflows](07-agents-va-workflows.md) - các loại năng lực khác của Javis.
