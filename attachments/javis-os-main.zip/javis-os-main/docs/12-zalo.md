# Zalo Agent MCP

***Tiếng Việt** · [English](en/12-zalo-agent-mcp.md)*

> **Javis có BA chỗ dính tới Zalo, đừng lẫn.** Trang này nói về chỗ thứ nhất: đăng nhập
> **chính tài khoản Zalo của bạn** để Javis thao tác thay bạn. Hai chỗ kia dùng API chính
> thức, an toàn, nhưng chỉ thấy được thứ người ta nhắn thẳng cho bot.
>
> | | Zalo Agent MCP (trang này) | [Kênh Zalo Bot](26-kenh-zalo-bot.md) | [Chatbot](25-chatbot.md) |
> |---|---|---|---|
> | Là ai | Chính bạn | Một bot riêng | Một bot riêng, đứng tên Agent |
> | API | Không chính thức (zca-js) | Chính thức | Chính thức |
> | Rủi ro khoá tài khoản | Có | Không | Không |
> | Đọc được hội thoại cũ | Có | Chỉ tin gửi cho bot | Chỉ tin gửi cho bot |
> | Nhắn cho người chưa quen bot | Được | Không | Không |
> | Dùng để | Javis làm việc thay bạn | **Bạn** nhắn cho Javis | **Khách** nhắn cho Javis |
>
> Dùng cả ba cùng lúc cũng được, chúng không đụng nhau.

Javis kết nối Zalo cá nhân bằng MCP của
[`javis-zalo`](https://github.com/blogminhquy/javis-zalo), bản CLI Zalo riêng của Javis. Chỉ có
một tiến trình MCP: đăng nhập QR, đọc hoặc tìm hội thoại và gửi tin qua các tool của nó.

> `javis-zalo` dùng API Zalo không chính thức qua `zca-js`. Zalo không hỗ trợ cách
> kết nối này và tài khoản có thể bị hạn chế hoặc khoá. Nên dùng tài khoản phụ, tránh
> gửi tự động hàng loạt và tự chịu trách nhiệm khi sử dụng.

## Cần chuẩn bị

- Node.js 20 trở lên trên máy hoặc VPS chạy Javis, và máy tải được từ GitHub (lần đầu).
- Điện thoại đã đăng nhập tài khoản Zalo cần kết nối.
- Javis đã được khởi động và bạn đăng nhập được dashboard.

Javis ghim `javis-zalo` theo tag phát hành (hiện là `v1.2.0`) và cài thẳng từ tarball của tag
đó trên GitHub, không cần tài khoản npm hay Git. Chỉ thư viện `zca-js` bên dưới đi theo bản chính
thức trên npm. Từ 0.83.0 Javis thay `zalo-agent-cli` 1.6.2 của tác giả ngoài bằng bản riêng này;
kết nối đã đăng nhập từ trước tự chuyển sang mà không phải quét QR lại.

## Kết nối bằng QR

1. Mở **Kết nối** → tìm **Zalo Agent MCP** → bấm **Kết nối**.
2. Đọc cảnh báo rủi ro, nhập tên gợi nhớ nếu cần rồi bấm **Hiện mã QR**.
3. Trong app Zalo trên điện thoại, mở trình quét QR và quét mã trên dashboard.
4. Khi thẻ tài khoản xuất hiện trong phần **Đã kết nối**, kết nối đã sẵn sàng.
5. Muốn nối thêm tài khoản, bấm **＋ Thêm tài khoản**. Mỗi tài khoản dùng một thư mục
   phiên riêng nên không ghi đè phiên của nhau.

Nút **Hướng dẫn trên GitHub** trong thẻ Zalo luôn mở trang tài liệu này:

<https://github.com/blogminhquy/javis-os/blob/main/docs/12-zalo.md>

## Nhập tin cũ vào Hộp thư (từ 0.174.0)

Mới đăng nhập Zalo vào Javis thì Hộp thư chỉ có tin từ lúc bật **Ghi hội thoại** trở đi. Muốn có cả tin cũ, bấm **Nhập tin cũ** trên thẻ tài khoản Zalo ở trang Chatbot, thẻ Bot, mục Kênh chưa có bot. Zalo đã gắn bot thì bấm vào ô Zalo trên thẻ bot đó.

- Javis lấy các tin javis-zalo tự kéo về mỗi lần kết nối: khoảng **2 tuần** gần nhất, vì Zalo không cho lấy xa hơn. Tối đa 5.000 tin mỗi lần.
- Cuộc chat **chưa có tin** thì nhập hết. Cuộc chat **đã có tin** thì chỉ thêm các tin **cũ hơn tin đầu tiên** của nó, xếp lên trên cùng đúng thứ tự thời gian (trước bản này cuộc chat đã có tin bị bỏ qua hẳn).
- Bot **không trả lời** các tin này, chúng **không tính là chưa đọc**, và nhóm vẫn chỉ giữ 1.000 tin gần nhất như thường lệ.
- Vừa quét QR xong thì đợi vài phút cho Zalo tải xong tin cũ rồi hãy bấm. Bấm lại nhiều lần không bị nhân đôi.

## Các tool MCP

| Tool | Công dụng | Mức thao tác |
|---|---|---|
| `zalo_get_messages` | Đọc tin mới trong bộ đệm, đọc tiếp bằng `since` (số thứ tự) | Đọc |
| `zalo_get_history` | Lấy lịch sử một cuộc chat (kể cả nhóm), có phân trang, kèm `replyTo` và `mentions` | Đọc |
| `zalo_search_history` | Tìm trong lịch sử mọi cuộc chat theo người gửi hoặc khoảng ngày | Đọc |
| `zalo_get_group_joins` | Ai đã vào nhóm và vào lúc nào, lọc theo nhóm, người hoặc khoảng ngày | Đọc |
| `zalo_list_join_requests` | Ai đang xin vào một nhóm phải duyệt | Đọc |
| `zalo_review_join_requests` | Duyệt hoặc từ chối người xin vào nhóm | Nguy hiểm |
| `zalo_list_threads` | Liệt kê các cuộc chat đang có trong bộ đệm | Đọc |
| `zalo_search_threads` | Tìm nhóm hoặc người theo tên | Đọc |
| `zalo_get_labels` | Tag (thẻ phân loại) chủ gắn cho cuộc chat trong app Zalo, của một cuộc chat hoặc tất cả (từ javis-zalo 1.6.0) | Đọc |
| `zalo_view_media` | Tải/mở ảnh, âm thanh hoặc video trên máy chủ (bộ não không thấy ảnh, xem `zalo_read_images` bên dưới) | Đọc |
| `zalo_mark_read` | Đánh dấu đã xử lý đến một cursor | Ghi |
| `zalo_send_message` | Gửi tin cho cá nhân hoặc nhóm | Nguy hiểm |
| `zalo_send_file` | Gửi file (Excel, PDF, Word...) kèm lời nhắn, chỉ file nằm trong hộp gửi của phiên (xem "Gửi ảnh và file") | Nguy hiểm |

Danh sách trên theo mã nguồn `javis-zalo` 1.5.0. Tên tham số lấy từ mã nguồn: kiểu cuộc chat của
`zalo_send_message` là `threadType` (0 = chat riêng, 1 = nhóm), và `zalo_get_messages` đọc bằng
`since` chứ không có `cursor`. Lịch sử chỉ có từ lúc MCP kết nối, cộng phần Zalo gửi lại lúc kết
nối (khoảng hai tuần gần nhất); tin cũ hơn thì không API nào lấy được.

### Khi nào có thể thiếu tin (từ 0.183.0, javis-zalo 1.5.0)

Ba tool đọc tin chỉ đọc kho do chính javis-zalo gom: tin tới lúc đang kết nối, cộng phần Zalo gửi
lại mỗi lần vừa kết nối. Không có cách hỏi lại Zalo lịch sử chat riêng sau đó. Nên tin tới đúng lúc
mất kết nối (Javis khởi động lại hay cập nhật, mạng rớt, một phiên Zalo Web khác đang giữ kết nối)
chỉ thấy được nếu phần gửi lại mang nó về.

- Kho lịch sử giờ **lưu ra đĩa** (30 ngày) trong thư mục phiên của tài khoản, nên khởi động lại
  không còn xoá sạch.
- Mỗi kết quả đọc có thêm `sync`. `sync.complete: false` nghĩa là trong khoảng đó có lúc mất kết
  nối mà phần gửi lại chưa phủ hết (`sync.gaps` ghi từ lúc nào đến lúc nào): có thể đang thiếu tin,
  **không phải** là khách chưa trả lời. Javis khi đó giữ bước đang chờ (duyệt, phát hành) và báo chủ.
- Tin tới lúc mất kết nối mà phần gửi lại mang về được đưa vào luồng tin mới, đánh dấu
  `recovered: true`, nên Hộp thư cũng có.

### Tin tới là Javis đọc ngay, không quét theo giờ (javis-zalo 1.10.0)

Trước đây cứ 20 giây Javis hỏi `javis-zalo` một lần xem có tin mới không, kể cả những ngày không có tin
nào, và tin nhóm vẫn chờ tới 20 giây bot mới thấy. Từ javis-zalo 1.10.0, `javis-zalo` báo cho Javis ngay
khi có tin (hoặc khi kết nối Zalo rớt, nối lại), và Javis chỉ đọc lúc đó.

- Tín hiệu chỉ đi trong máy (`127.0.0.1`), kèm một mã riêng của lần chạy Javis hiện tại, và không mang
  nội dung tin. Tin vẫn được đọc qua tool `zalo_get_messages` như cũ.
- Javis chỉ coi một tài khoản là "tự báo" sau khi nhận được tín hiệu đầu tiên từ đúng tiến trình
  `javis-zalo` đang chạy. Chưa có tín hiệu (bản javis-zalo cũ, tiến trình vừa dựng lại) thì Javis đọc
  theo nhịp 20 giây như trước.
- Khi mọi tài khoản đều tự báo và không có tin nào đang giữ, vòng đọc ngủ hẳn, không chạy theo nhịp
  nào. Nó chỉ thức khi có việc: `javis-zalo` báo có tin, tiến trình `javis-zalo` thoát (Javis đọc ngay
  một lượt, lượt đó dựng lại tiến trình), một bot nhận hay rời vị trí, một tài khoản được bật, hoặc một
  kết nối được lưu ở trang Kết nối.
- Trong lúc có tin đang giữ (chờ khách nhắn xong, chờ chủ trả lời tay), vòng đọc chạy nhịp ngắn để
  nhả đúng giờ rồi ngủ lại. Việc đó không gọi `javis-zalo`.
- Tắt cho cả máy: đặt biến môi trường `JAVIS_ZALO_PUSH=0` rồi khởi động lại Javis.

## Duyệt người xin vào nhóm

Từ Javis 0.84.7 (javis-zalo 1.2.0), với nhóm bật "duyệt thành viên":

- **Javis báo bạn khi có người xin vào**, qua chuông hòm thư và Telegram của bạn: một tin cho mỗi nhóm, có tên người
  xin và tên nhóm.
- **Bạn ra lệnh, Javis làm.** Hỏi "ai đang xin vào nhóm Zoom | Javis OS?" thì Javis liệt kê; bảo "duyệt hết" hay
  "duyệt Lan, từ chối Minh" thì Javis làm và nói lại kết quả từng người.
- **Bot chuyên trách không bao giờ tự duyệt.** Sự kiện xin vào nhóm không tới bot.
- Tài khoản Zalo đã quét QR phải là **trưởng hoặc phó nhóm**, không thì Zalo từ chối. Duyệt là thao tác nguy hiểm
  (đổi thành viên nhóm), nên kết nối Zalo phải ở mức Toàn quyền.

## Người mới vào nhóm

Từ Javis 0.84.2 (javis-zalo 1.1.0), Javis biết ai vừa vào nhóm và vào **lúc nào**, kể cả người
được thêm vào bởi chính tài khoản của bạn:

- **Hỏi lại được.** "Tuần này ai mới vào nhóm Zoom | Javis OS?" thì bộ não gọi
  `zalo_get_group_joins` và trả tên kèm giờ vào. Nhật ký nằm ở
  `~/.zalo-agent-cli/group-joins.jsonl` trong thư mục phiên của kết nối, giữ 5000 lượt gần nhất,
  còn nguyên sau khi khởi động lại.
- **Bot chuyên trách nhận được sự kiện.** Ở nhóm đã cho phép bot, mỗi người mới vào là một sự
  kiện gửi tới Agent của bot, bất kể chế độ "trả lời khi nào". Agent làm theo chỉ dẫn của nó (ví dụ
  chào và hỏi thăm), và câu nó gửi tự tag đúng người mới. Javis **không có lời chào mặc định**:
  chỉ dẫn của Agent không nói gì về người mới thì bot im. Nhiều người vào cùng lúc mà bot đã hết
  hạn mức thì bot cũng im chứ không nói "nhắn hơi nhanh".
- **Giới hạn.** Zalo chỉ báo sự kiện này lúc đang kết nối, và danh sách thành viên không có ngày
  vào nhóm. Người vào trước khi có tính năng này, hoặc trong lúc máy chạy Javis tắt, thì không có
  trong nhật ký.

## Gói Zalo mở rộng (Javis Store)

Ba nhóm tool dưới đây (đọc ảnh, gửi ảnh và file, tag người cùng ghi chú, nhắc hẹn, poll) bù đúng
chỗ MCP chuẩn còn thiếu. Từ 0.73.0 chúng nằm trong gói **`javis.zalo`** trên Javis Store thay vì
đi sẵn trong app, để ai không dùng Zalo thì không phải mang theo:

- **Quét QR Zalo xong là Javis mời cài gói**, qua đúng màn hình đồng ý của kho: liệt kê từng tệp
  mã, công tắc "chạy ngay" bật sẵn vì bạn vừa tự đấu Zalo. Bấm Cài là có đủ tool.
- **Máy đã đấu Zalo từ trước** thì trang Kết nối hiện dải nhắc kèm nút **Cài gói đi kèm**.
  Javis không bao giờ tự cài gói có mã mà không hỏi.
- Kết nối Zalo, Hộp thư và chatbot Zalo vẫn ở trong app, chạy bình thường dù chưa cài gói. Thiếu
  gói thì chỉ thiếu các tool mở rộng.

## Đọc ảnh trong nhóm

MCP của Zalo chỉ trả **đường link** của ảnh, giữ tin trong 2 giờ, và `zalo_view_media` mở ảnh
bằng trình xem ảnh của máy chủ chứ không đưa cho bộ não. Nên gói `javis.zalo` có tool
`zalo_read_images`:

| Tool | Công dụng | Mức thao tác |
|---|---|---|
| `zalo_read_images` | Lấy ảnh người ta gửi trong nhóm về brain và cho bộ não biết trong ảnh có gì | Ghi (lưu ảnh vào brain) |

Nói trong chat như bình thường, ví dụ “xem ảnh hoá đơn chị Lan vừa gửi trong nhóm Kinh doanh”.

- **Ảnh lấy thẳng từ Zalo**, không phụ thuộc bộ đệm 2 giờ của MCP: Javis hỏi Zalo các tin gần
  nhất của nhóm (mặc định 30, tối đa 100) và lấy tối đa 8 ảnh mới nhất. Chat riêng thì chỉ lấy
  được ảnh còn trong bộ đệm MCP.
- **Ảnh lưu vào `attachments/zalo/<id nhóm>/`** của brain, nên hiện được ngay trong khung chat.
- **Mọi bộ não đều "thấy" ảnh.** Claude Code và Codex tự mở file ảnh. Các engine API (OpenRouter,
  Gemini...) không tự xem ảnh được, nên ChatGPT trên gói bạn đang đăng nhập nhìn ảnh rồi tả lại,
  chép nguyên văn chữ và số trong ảnh. Chưa đăng nhập ChatGPT ở trang Model thì vẫn tải được ảnh,
  chỉ thiếu phần tả.

Phần ChatGPT xem ảnh nằm trong app (plugin có sẵn `image-chatgpt`, tool `javis_describe_image`),
nên xem được cả mọi ảnh khác trong brain, có cài gói Zalo hay không.

## Gửi ảnh và file

`zalo_send_message` ở trên **chỉ gửi được chữ**. Muốn gửi ảnh (ví dụ ảnh Javis vừa tạo) hay
file (báo cáo PDF, bảng tính) thì dùng tool `zalo_send_image` trong gói `javis.zalo`. Nó dùng
đúng tài khoản Zalo bạn đã quét QR.

| Tool | Công dụng | Mức thao tác |
|---|---|---|
| `zalo_send_image` | Gửi ảnh hoặc file kèm lời nhắn | Nguy hiểm (mức Toàn quyền) |

Nói trong chat như bình thường, ví dụ “gửi ảnh này cho nhóm Kinh doanh” hoặc “gửi báo cáo
tháng 7 cho anh Nam qua Zalo”.

Ba điều nên biết:

- **Chỉ gửi được file nằm trong bộ não đang dùng.** Đây là rào an toàn cố ý: nếu không, một
  câu chat khéo léo có thể khiến Javis gửi file bất kỳ trên máy chủ ra ngoài, mà tin nhắn Zalo
  thì không thu hồi được.
- **Một lượt gửi cùng một loại**, hoặc toàn ảnh hoặc toàn file, tối đa 10 file. Trộn lẫn thì
  Zalo hiển thị sai kiểu nên Javis sẽ báo lại thay vì tự đoán.
- **Đấu nhiều tài khoản Zalo thì Javis hỏi lại** nên gửi bằng tài khoản nào. Gửi nhầm tài
  khoản là gửi dưới danh tính người khác, nên đây là chỗ không được đoán.

Cần Node.js 20+ trên máy chạy Javis, giống như phần kết nối Zalo.

### Vì sao file đi đường khác ảnh (từ 0.139.0)

Ảnh tải lên Zalo là có link ngay. File (Excel, PDF, Word, zip, video, cả ảnh `.bmp`) thì khác:
Zalo nhận xong mới báo "đã tải lên" qua **kết nối thời gian thực** của tài khoản. Trước 0.139.0
Javis gửi file bằng một lệnh chạy một lần, không mở kết nối đó, nên lệnh chờ mãi rồi bị cắt ở
120 giây, file không tới (14/10/2026 gửi bảng Excel 11 KB cho nhân sự treo hai lần, phải đổi
sang ảnh). Mở thêm kết nối riêng cũng không được: Zalo chỉ giữ một kết nối Web mỗi tài khoản và
sẽ đá kết nối đang trực Hộp thư.

Từ 0.139.0 file đi qua tool `zalo_send_file` của chính tiến trình MCP đang giữ kết nối:

- Javis chép file vào hộp gửi của phiên Zalo (`.zalo-agent-cli/outbox/` trong thư mục phiên), gọi
  tool, xong thì xoá bản chép. Tool chỉ nhận file trong hộp gửi đó, nên model gọi thẳng tool cũng
  không gửi được file nào khác trên máy chủ.
- **Zalo không xác nhận trong 60 giây thì báo lỗi rõ và KHÔNG gửi gì**, kể cả khi xác nhận tới
  muộn sau đó. Gửi lại là an toàn. Kết nối thời gian thực đang rớt thì báo ngay, không chờ.
- Ảnh (jpg, png, webp, gif) vẫn đi đường cũ.
- Kết nối Zalo còn chạy bản `javis-zalo` cũ (chưa có tool này) thì Javis báo cập nhật Javis rồi
  tắt-bật lại kết nối Zalo, không phải quét QR lại.

Lệnh dòng lệnh `javis-zalo msg send-file` gửi file khi không có kết nối thời gian thực thì báo lỗi
ngay. Thêm `--listen` để nó tự mở kết nối cho lượt gửi đó, nhưng chỉ dùng trên máy KHÔNG chạy MCP
Zalo, vì kết nối mới sẽ đá MCP ra.

## Tag người, ghi chú, nhắc hẹn và poll

`zalo_send_message` chỉ gửi chữ nên không tag được ai, và MCP của Zalo cũng không có ghi chú, nhắc hẹn hay poll. Gói
`javis.zalo` bù đúng các chỗ đó bằng năm tool, mọi bộ não đều gọi được:

| Tool | Công dụng | Mức thao tác |
|---|---|---|
| `zalo_group_members` | Liệt kê thành viên một nhóm (id kèm tên), hoặc tra một người theo tên | Đọc |
| `zalo_send_mention` | Gửi tin vào nhóm và tag đúng người | Nguy hiểm (mức Toàn quyền) |
| `zalo_create_note` | Tạo ghi chú nhóm, ghim được | Nguy hiểm (mức Toàn quyền) |
| `zalo_create_reminder` | Nhắc hẹn hiện trong Zalo, chọn giờ và lặp (hằng ngày, tuần, tháng) | Nguy hiểm (mức Toàn quyền) |
| `zalo_create_poll` | Poll cho nhóm: chọn nhiều đáp án, ẩn danh, hạn đóng | Nguy hiểm (mức Toàn quyền) |

Nói trong chat như bình thường, ví dụ “nhắn nhóm Kinh doanh tag @minhquy họp lúc 9h nhé” hoặc “tạo poll trưa nay ăn gì trong nhóm Lớp Javis”.

Bốn điều nên biết:

- **Tag chỉ cần nói tên.** “@minhquy” hay “Minh Quý” đều được, không phân biệt hoa thường hay dấu. Javis tìm ID Zalo thật trong
  những người đã nhắn ở nhóm đó trước, rồi tới danh sách thành viên của Zalo. **Trùng tên hoặc không thấy thì Javis hỏi lại kèm
  danh sách ứng viên**, không đoán, vì tag nhầm người thì không rút lại được. Tag cả nhóm (`@All`) chỉ khi bạn yêu cầu rõ.
- **Nhắc hẹn này khác nhắc hẹn riêng của Javis** (`javis_schedule`): nó hiện trong Zalo nên cả nhóm cùng thấy. Giờ tính theo múi giờ của Javis.
- **Nhóm khoá quyền tạo ghi chú hoặc poll của thành viên** thì Zalo từ chối và Javis báo thẳng lý do đó. Nếu lệnh quá giờ, Javis nói
  **không rõ đã tạo chưa** và dặn xem lại nhóm trước khi thử tiếp, để khỏi ra hai poll.
- **Đấu nhiều tài khoản Zalo thì Javis hỏi lại** nên dùng tài khoản nào, giống phần gửi ảnh.

Bot chuyên trách đứng trong nhóm Zalo thì **tự tag người nó đang trả lời**, không cần công cụ nào ở trên, xem [Chatbot](25-chatbot.md).

## Chữ đậm, chữ màu và "đang soạn tin" (từ 0.413.0)

Bot trả lời trên Zalo cá nhân giờ nhắn giống người thật hơn:

- **Chữ đậm, nghiêng, gạch ngang và chữ màu.** Bot viết `**85.000đ**` thì khách thấy chữ đậm, không còn thấy dấu sao. Màu viết `{red:Giảm 50%}`, có `red`, `orange`, `yellow`, `green`, và `{big:...}`, `{small:...}` để đổi cỡ chữ. Dòng `- ` thành dấu `•`, tiêu đề thành một dòng đậm. Bot được dặn chỉ nhấn một hai chỗ như người thật nhắn tin.
- **"Đang soạn tin".** Trong chat riêng, khách thấy dòng "đang soạn tin" trong lúc bot viết câu trả lời. Phần này cần javis-zalo 1.9.0 trở lên; bản cũ hơn thì bot vẫn trả lời bình thường, chỉ không hiện dòng đó. Trong nhóm không hiện, vì nhiều tin bot chọn không trả lời.

Tin có định dạng đi qua lệnh `javis-zalo msg send --style`. Lệnh đó lỗi thì tin vẫn đi dưới dạng chữ thường, đã bỏ ký hiệu.

## Cách dùng trong chat

Có thể nói tự nhiên:

- “Tìm nhóm Kinh doanh trên Zalo.”
- “Đọc 20 tin gần nhất của nhóm Kinh doanh.”
- “Có tin Zalo nào mới không?”
- “Gửi nhóm Kinh doanh: 9 giờ sáng mai họp nhé.”

Khi gửi tin, nên nêu rõ tên hoặc `threadId`, nội dung và đó là cá nhân hay nhóm. Nếu kết
quả tìm kiếm có nhiều cuộc chat trùng tên, Javis phải hỏi lại thay vì tự đoán.
Nếu chỉ có một kết quả khớp chính xác, Javis gửi ngay bằng `zalo_send_message`; không cần
bật listener, không cần người nhận nhắn trước và không phụ thuộc danh sách theo dõi.

## Phân quyền

Kết nối mới mặc định ở mức **Toàn quyền** để có thể dùng `zalo_send_message`.

- **Chỉ đọc**: chỉ dùng năm tool đọc.
- **Ghi nháp**: thêm `zalo_mark_read`, vẫn chặn gửi tin.
- **Toàn quyền**: cho phép gửi tin (`zalo_send_message`, `zalo_send_image`) và các tool tag người, ghi chú, nhắc hẹn, poll.

Bạn đổi quyền trong menu của chip tài khoản ở trang **Kết nối**. Việc nền chạy ở chế độ
giới hạn vẫn bị MCP Hub chặn gửi tin, dù tài khoản đang đặt Toàn quyền.

## Khác với tích hợp Zalo cũ

Luồng mới đã bỏ sidecar `listen --webhook`, endpoint `/hook/zalo`, panel “Nghe tin liên
tục”, file luật theo từng cuộc chat và hai plugin `javis_zalo_rule`/`javis_zalo_send`.
Không còn việc một tiến trình listener tự tắt rồi bật lại connector MCP.

Do đó Javis không tự chuyển tiếp tin Zalo sang Telegram ở nền. Khi cần kiểm tra tin, hãy
hỏi Javis; MCP có thể dùng `zalo_get_messages` cho tin đang đệm hoặc
`zalo_get_history` cho lịch sử.

## Xử lý lỗi

- **Không hiện QR**: kiểm tra `node --version` phải từ 20 trở lên và máy truy cập được npm và
  GitHub (`codeload.github.com`).
- **QR hết hạn**: đóng cửa sổ kết nối rồi bấm **Kết nối** để tạo mã mới.
- **Không thấy cuộc chat**: thử `zalo_search_threads`; nếu cần tin cũ, dùng
  `zalo_get_history` thay vì chỉ dùng `zalo_get_messages`.
- **Tool gửi bị chặn**: mở menu chip tài khoản và chuyển quyền sang **Toàn quyền**.
- **Báo phiên đang được dùng nơi khác**: đóng Zalo Web hoặc tiến trình
  `javis-zalo` (hay `zalo-agent-cli` cũ) khác đang dùng cùng tài khoản, rồi thử lại.
- **Bot im sau khi Javis khởi động lại**: trước 0.114.0, nếu Javis tắt không êm (crash, bị
  dừng cứng khi cập nhật) thì tiến trình `javis-zalo` cũ còn sống. Server mới mở thêm một phiên,
  và cùng một tài khoản có hai phiên nghe. Zalo chỉ đẩy tin về một phiên nên bot đọc phiên kia
  và không thấy gì. Từ 0.114.0 Javis ghi lại mọi tiến trình MCP nó mở và tự dọn tiến trình sót
  của lần chạy trước. Bản cũ hơn thì khởi động lại cả máy chủ (hoặc container) là sạch.
- **Muốn đăng nhập lại từ đầu**: xoá connection trên dashboard, sau đó kết nối và quét QR
  lại. Thư mục phiên của connection khác không bị ảnh hưởng.

## Tham khảo

- [Repository `javis-zalo`](https://github.com/blogminhquy/javis-zalo)
- [zca-js](https://github.com/RFS-ADRENO/zca-js), thư viện nói chuyện với Zalo bên dưới
- [Kết nối và phân quyền MCP trong Javis](09-mcp-va-so-lieu.md)
