# Cấu hình .env

***Tiếng Việt** · [English](en/16-env-configuration.md)*

Trang này liệt kê các biến môi trường mà Javis OS đọc lúc khởi động, kèm ý nghĩa, giá trị mặc định và khi nào cần đổi. Nội dung dựa vào file `env.example` và cách server thực sự đọc `os.getenv(...)` trong mã nguồn (`server/config.py`, `server/main.py`, `server/web_security.py`, `server/claude_cli.py`, `server/sessions.py`, `server/plugins_host.py`...).

Điểm quan trọng nhất cần nhớ: **mọi dòng để trống vẫn chạy được**. Trên máy cá nhân, bạn gần như không cần đụng tới file `.env`. Việc chỉnh `.env` chủ yếu dành cho khi bạn đưa Javis lên VPS/server public hoặc muốn đổi giọng đọc, cổng, đường dẫn dữ liệu.

Riêng khi cài bằng **Hostinger Docker Manager**, không cần nhìn thấy toàn bộ danh
sách nâng cao bên dưới. Compose Hostinger chỉ đưa 3 trường người dùng lên ô
Environment: `DOMAIN_NAME`, `JAVIS_ADMIN_USER`, `JAVIS_ADMIN_PASSWORD`, cộng một
trường tuỳ chọn `JAVIS_AUTO_UPDATE`. Các biến nội bộ về cổng, state, brain và thư
mục làm việc nằm sẵn trong Docker image.

## Tính năng này là gì

`.env` là một file văn bản đặt ở **thư mục gốc dự án** (nơi có `env.example`, `docker-compose.yml`, thư mục `server/`). Mỗi dòng là một biến dạng `TÊN_BIẾN=giá trị`. Khi Javis khởi động, nó đọc các biến này để biết: nghe ở cổng nào, có bắt buộc đăng nhập không, dữ liệu Second Brain nằm ở đâu, giọng đọc mặc định là gì.

Cần phân biệt rõ 3 nơi cấu hình để khỏi nhầm:

- **File `.env`**: các thiết lập cấp hệ thống, đọc 1 lần lúc khởi động. Đổi xong phải khởi động lại Javis mới có hiệu lực.
- **Bảng ⚙ Cài đặt trong app** (trang Tài khoản, Models, Kênh...): các thiết lập đổi nóng qua giao diện, lưu vào `settings.json`, không cần sửa file. Ví dụ: đổi model, khoá API OpenRouter, token Telegram, tên miền riêng, logo. Xem thêm ở [Models & engine](10-models-va-engine.md), [Bảo mật & tài khoản](14-bao-mat-tai-khoan.md), [Thương hiệu & tên miền](15-thuong-hieu-ten-mien.md).
- **Vài khoá trong `settings.json` chưa có giao diện**: hiện có khối `media` (luật dọn ảnh/tệp tạm). Muốn đổi thì phải mở file sửa tay. Xem mục riêng bên dưới.

Nói gọn: `.env` lo phần "chạy ở đâu, ai được vào, dữ liệu nằm đâu". Bảng Cài đặt trong app lo phần "dùng model nào, khoá gì, giọng gì". Còn `settings.json` là nơi cả hai gặp nhau, và một vài khoá hiếm dùng chỉ sửa được ở đó.

## Mở ở đâu trong Javis

`.env` không có nút bấm trong dashboard. Đây là file bạn tự tạo và sửa bằng trình soạn thảo văn bản (Notepad, VS Code...).

Các bước tạo file `.env` lần đầu:

1. Mở thư mục gốc dự án (nơi bạn tải/giải nén Javis; bản Docker thì là `/app` bên trong image, còn `.env` đặt cạnh `docker-compose.yml` trên host).
2. Tìm file mẫu `env.example` (tên cố ý KHÔNG có dấu chấm đầu - để Docker Manager của Hostinger không tự quét file `.env*` rồi nhập cả dòng chú thích vào ô Environment).
3. Sao chép nó và đổi tên bản sao thành `.env` (bản sao CÓ dấu chấm đầu, không có phần đuôi `.txt`).
4. Mở `.env` bằng trình soạn thảo, bỏ dấu `#` ở đầu dòng biến bạn muốn bật, rồi điền giá trị.
5. Lưu file. Khởi động lại Javis.

Cách sao chép nhanh bằng lệnh (chạy trong thư mục dự án):

- Windows PowerShell: `Copy-Item env.example .env`
- Git Bash / Linux / macOS: `cp env.example .env`

Lưu ý về dấu `#`: dòng bắt đầu bằng `#` là dòng chú thích, Javis bỏ qua. Muốn bật một biến đang bị chú thích, xoá dấu `#` ở đầu dòng đó. Ví dụ đổi từ `# JAVIS_PORT=7777` thành `JAVIS_PORT=8080`.

## Danh sách các biến

Gom theo chức năng. Cột "Mặc định" là giá trị dùng khi bạn để trống hoặc không khai báo. Nhóm 1 đến 5 là những biến người dùng thường đụng; nhóm 6 và 7 là biến nâng cao, hầu như không cần sửa.

### Nhóm 1: Hiển thị workspace

| Biến | Ý nghĩa | Mặc định | Khi nào đổi |
|---|---|---|---|
| `WORKSPACE_NAME` | Tên workspace hiển thị trên dashboard | `Javis OS` | Muốn đặt tên riêng cho không gian làm việc. Lưu ý: nếu bạn đã đặt tên trong app thì app ưu tiên tên đã lưu, biến này chỉ là dự phòng. |
| `USER_NAME` | Tên người dùng hiển thị | `Bạn` | Muốn Javis xưng hô bằng tên bạn thay vì "Bạn". |

### Nhóm 2: Mạng (cổng và địa chỉ nghe)

| Biến | Ý nghĩa | Mặc định | Khi nào đổi |
|---|---|---|---|
| `JAVIS_HOST` | Địa chỉ server nghe. `127.0.0.1` = chỉ máy này truy cập được. `0.0.0.0` = nghe mọi nơi (public, ai có địa chỉ đều vào được) | `127.0.0.1` (Docker image đặt sẵn `0.0.0.0`) | Chỉ đổi sang `0.0.0.0` khi chạy trên VPS/server và muốn truy cập từ máy khác. Khi đó phải bật đăng nhập (xem nhóm 3). |
| `JAVIS_PORT` | Cổng nghe của dashboard | `7777` | Cổng `7777` bị chiếm hoặc muốn cổng khác. Đổi xong nhớ mở đúng cổng đó trên trình duyệt. |

Chi tiết quan trọng về `JAVIS_HOST`: Javis dùng cơ chế "an toàn mặc định". Nếu bạn để địa chỉ nghe KHÔNG phải loopback (tức khác `127.0.0.1`, `localhost`, `::1`), server tự coi là đang chạy public và **tự bật bắt buộc đăng nhập** để không ai vào được nếu chưa có tài khoản. Lý do: bộ não AI chạy với đầy quyền trên máy, để hở là nguy hiểm.

### Nhóm 3: Đăng nhập và bảo mật

| Biến | Ý nghĩa | Mặc định | Khi nào đổi |
|---|---|---|---|
| `JAVIS_REQUIRE_LOGIN` | Ép bật/tắt bắt buộc đăng nhập. `1`/`true`/`yes`/`on` = bật. `0`/`false`/`no`/`off` = tắt | Tự động (bật khi bind public) | Chạy localhost rồi expose ra ngoài qua tunnel (Cloudflare, ngrok...): đặt `JAVIS_REQUIRE_LOGIN=1` để chặn người lạ. |
| `JAVIS_ADMIN_USER` | Tên đăng nhập admin tạo sẵn lúc deploy | `admin` | Đặt cùng `JAVIS_ADMIN_PASSWORD` để tạo sẵn tài khoản, server public không có lúc nào trống admin. |
| `JAVIS_ADMIN_PASSWORD` | Mật khẩu admin tạo sẵn lúc deploy | (trống) | Deploy public: đặt mật khẩu mạnh ở đây. Có biến này và chưa có admin, Javis tạo tài khoản admin ngay lúc khởi động và đóng luôn màn hình tạo tài khoản (an toàn nhất cho public). |
| `JAVIS_RESET_2FA` | Gỡ xác thực 2 lớp MỘT lần lúc khởi động, khi bị khoá vì mất điện thoại hoặc 2FA do người lạ cài. Đăng xuất mọi phiên và ghi vào nhật ký bảo mật | (trống) | Đặt `1`, Redeploy, đăng nhập, bật 2FA mới rồi xoá biến. Mỗi giá trị chỉ áp dụng một lần nên để quên biến cũng không xoá 2FA mới; cần lại thì đặt giá trị khác (ví dụ ngày hôm đó). Xem [Khi nghi bị chiếm quyền](14-bao-mat-tai-khoan.md#khi-nghi-bị-chiếm-quyền). |
| `JAVIS_SETUP_2FA` | Mở sẵn màn quét QR bật xác thực 2 lớp ở trang Tài khoản. `1` = mở sẵn | Tắt | Muốn bật 2FA ngay lần đầu đăng nhập. Cờ này chỉ là **lời nhắc**: nó KHÔNG tự bật 2FA. Phải quét QR và nhập đúng một mã thì mới bật thật, vì bật trước lúc bạn chứng minh app sinh đúng mã là tự khoá mình ra ngoài. Bật hay tắt 2FA lúc nào cũng được ngay trong Dashboard → Tài khoản, không cần biến này. |
| `JAVIS_SECURE_COOKIE` | Bật cookie chỉ gửi qua HTTPS. `1`/`true`/`yes`/`on` = bật | Tắt | Chỉ bật khi CHẮC CHẮN chạy HTTPS đầu-cuối (domain riêng có SSL). Bật nhầm khi proxy đang chạy HTTP sẽ kẹt vòng đăng nhập (nhập đúng mật khẩu vẫn bị đá về trang login). |
| `JAVIS_ALLOWED_HOSTS` | Thêm hostname được phép gọi Javis (chống CSRF và DNS-rebinding). Nhiều tên cách nhau dấu phẩy | (trống) | Chạy sau reverse proxy với tên miền chưa khai trong app mà chưa đặt mật khẩu, bị 403 "host không được phép". Mặc định đã cho `localhost`, `127.0.0.1`, `::1` và tên miền bạn đặt ở Cài đặt. |
| `JAVIS_ENABLE_USER_PLUGINS` | Công tắc tắt hẳn plugin do bạn cài. Đặt `false` là không nạp | Bật | Từ 0.162.0 plugin do bạn cài được tải mặc định; từng plugin vẫn chỉ chạy khi bạn bật nó trong app. Đặt `false` khi muốn chặn hẳn trên máy này (plugin user chạy CODE PYTHON THẬT trong tiến trình server). Alias cũ: `JAVIS_ENABLE_VAULT_PLUGINS`. Plugin đi kèm app (bundled) không chịu công tắc này. Xem [Plugins](20-plugins.md). |
| `JAVIS_BLOCK_BOTS` | Trả 403 cho bot AI, máy tìm kiếm, công cụ SEO và máy quét tự khai tên, để link quản trị lỡ lộ ra ngoài không bị đọc hay đưa lên Google. `0`/`false`/`no`/`off` = tắt | Bật | Một dịch vụ bạn dùng bị chặn nhầm vì tên trùng danh sách. Tắt chỉ bỏ lớp 403; header `noindex` và `/robots.txt` vẫn giữ. Xem [Chặn công cụ tìm kiếm và bot AI](14-bao-mat-tai-khoan.md#chặn-công-cụ-tìm-kiếm-và-bot-ai). |
| `JAVIS_TERMINAL` | Công tắc tắt hẳn Terminal (nhóm Năng lực). `0`/`off`/`false`/`no` = tắt | Bật | Không muốn có dòng lệnh nào mở được từ trình duyệt. Terminal vốn đã chỉ mở cho trình duyệt ĐÃ ĐĂNG NHẬP (token API không vào được), nhưng nhiều người vẫn muốn khoá cứng ở tầng máy chủ. Xem [Terminal](27-tab-code-terminal.md). |
| `JAVIS_TERMINAL_SHELL` | Shell mà Terminal chạy | `$SHELL`, không có thì `bash`/`sh`. Windows: `powershell.exe` rồi `cmd.exe` | Muốn ép dùng một shell khác (`zsh`, `fish`, `cmd.exe`). |
| `JAVIS_TERMINAL_CWD` | Thư mục terminal mở ra | HOME của user chạy Javis | Muốn shell mở sẵn ở gốc brain hoặc một thư mục dự án khác. |
| `JAVIS_AUTO_INSTALL_CLIS` | Bản Docker tự cài Antigravity CLI (`agy`) và Grok Build (`grok`) lúc khởi động nếu chưa có | `1` (bật) | Đặt `0` khi máy chủ không ra được Internet hoặc bạn không muốn có hai CLI này. Cài một lần, giữ qua mọi lần cập nhật; nhật ký cài ở `/data/home/.cli-auto-install/install.log`. |
| `JAVIS_TERMINAL_REMOTE` | Khai với các CLI trong Terminal rằng người dùng ngồi ở MÁY KHÁC (đặt `SSH_CONNECTION`) | Tự đoán: bật khi máy chủ không có màn hình (VPS, Docker), tắt trên Windows/macOS chạy thẳng và Linux có màn hình | Đăng nhập `agy`, `claude`, `codex`... in link rồi đứng im vì chúng tưởng trình duyệt nằm cùng máy. Bật (`1`) để chúng hỏi chỗ dán mã. Tắt (`0`) nếu máy chủ thật sự mở được trình duyệt cho bạn (X11 forwarding chẳng hạn). Xem [Terminal](27-tab-code-terminal.md). |

Về tài khoản admin lần đầu: khi chạy public mà chưa có admin, lần đầu mở app chỉ hỏi tên đăng nhập và mật khẩu, nên **ai mở link trước sẽ tạo được admin**. Vì vậy nên đặt sẵn `JAVIS_ADMIN_USER` + `JAVIS_ADMIN_PASSWORD` (`install.sh` đã hỏi sẵn) để server boot lên là có admin, hoặc tạo tài khoản ngay sau khi deploy. Đăng nhập xong thì bật xác thực 2 lớp (2FA). Xem thêm ở [Bảo mật & tài khoản](14-bao-mat-tai-khoan.md).

Về tên miền riêng và HTTPS: VPS dùng Caddy nhập tên miền ngay trong **Cài đặt → Chung → Tên miền & SSL** rồi bấm **Bật SSL**. Riêng Hostinger, wizard tạo sẵn biến `DOMAIN_NAME` để sao chép sang Docker Manager rồi Redeploy. Khi truy cập đúng tên miền qua HTTPS, server tự bật cookie Secure nên không cần đặt `JAVIS_SECURE_COOKIE` thủ công. Chi tiết ở [Thương hiệu & tên miền](15-thuong-hieu-ten-mien.md).

### Nhóm 4: Đường dẫn dữ liệu (Second Brain và state)

| Biến | Ý nghĩa | Mặc định | Khi nào đổi |
|---|---|---|---|
| `CLAUDE_CWD` | Thư mục dự phòng cho vài việc phụ của engine Claude (nhập nguồn, terminal khi chưa chọn brain). Từ 0.55.58 **chat luôn chạy trong thư mục brain đang chọn** và không đọc biến này nữa, nên file Javis tạo từ chat nằm đúng trong brain | Thư mục gốc dự án (Docker: `/app`) | Hầu như không cần đặt. |
| `BRAINS_DIR` | Thư mục cha chứa mọi brain, mỗi thư mục con là một Second Brain. Brain mặc định là `<BRAINS_DIR>/Brain Default` | `brains/` trong dự án (Docker: `/brains`) | Muốn để nhiều brain ở nơi khác (ví dụ ổ dữ liệu riêng, mount git-backup). |
| `OBSIDIAN_VAULT_PATH` | Đường dẫn vault Second Brain chính | `vault/` trong dự án (Docker: `/data/vault`) | Trên server đã có vault Obsidian thật thì trỏ biến này vào đó. Để trống thì Javis dùng vault mẫu trong repo (máy mới chạy được ngay). |
| `BRAIN_PATH` | Thư mục brain kiểu cũ, thời một-brain. Chỉ còn để migrate dữ liệu cũ | `brain/` trong dự án (Docker: `/data/brain`) | Hầu như không cần đụng. Đừng dùng cho cài mới. |
| `SOURCES_PATH` | Nơi lưu file đính kèm từ chat (làm source cho Second Brain) | `brain/01 - Sources/` trong dự án | Muốn tách thư mục nguồn ra chỗ khác. |
| `JAVIS_STATE_DIR` | Nơi Javis ghi state riêng: `settings.json`, phiên đăng nhập, cấu hình việc định kỳ, khoá mã hoá `.secret_key`, cơ sở dữ liệu hội thoại | `server/` (Docker: `/data/state`) | Docker/VPS phải trỏ vào volume ghi được (vì cây mã nguồn trong container là chỉ đọc). Máy cá nhân để trống là được. |
| `JAVIS_SESSIONS_DB` | Đường dẫn file cơ sở dữ liệu lưu phiên hội thoại (`conversations.db`) | Nằm trong `JAVIS_STATE_DIR` | Muốn để file lịch sử phiên ở nơi khác. Xem [Phiên hội thoại](04-phien-hoi-thoai.md). |
| `JAVIS_FILES_ROOT` | Trần duyệt của trang Tệp tin (không cho bấm "Lên" quá đây). `brain`/`vault` = khoá trong brain; `drive`/`root` = cả ổ đĩa chứa brain; `<đường dẫn>` = một thư mục cụ thể (phải chứa brain) | localhost: cả ổ đĩa; bind public: khoá brain | Chạy public (VPS) mà vẫn muốn duyệt rộng thì đặt `drive` hoặc một thư mục cha. Muốn khoá chặt trong brain khi chạy local thì đặt `brain`. |

Ghi chú về Second Brain: `BRAINS_DIR` là thư mục thật sự chứa các brain của bạn (không phải `brain/` ở gốc repo, đó là đường dẫn kiểu cũ). Để trống là chạy được ngay với dữ liệu mẫu trong repo. Đọc thêm cách vận hành bộ nhớ ở [Second Brain: bộ nhớ, Wiki, INGEST](13-second-brain-bo-nho-wiki.md) và [Đồ thị tri thức](03-do-thi-tri-thuc.md).

**Cảnh báo về `.secret_key`:** trong thư mục `JAVIS_STATE_DIR` có một tệp nhỏ tên `.secret_key`. Nó là khoá dùng để mã hoá các trường bí mật trong `settings.json` (API key OpenRouter/Anthropic/OpenAI/Gemini, token đăng nhập ChatGPT, token Telegram, token GitHub sao lưu, key ElevenLabs). Chép `settings.json` sang máy khác mà quên `.secret_key` thì **mọi khoá mất trắng**: Javis không giải mã được nên trả về chuỗi rỗng và bạn phải nhập lại từng cái. Sao lưu thì sao lưu cả cặp. Nếu máy thiếu thư viện `cryptography`, Javis không mã hoá được: secret rơi về tiền tố `plain:` kèm một dòng cảnh báo trong log; cài `pip install cryptography` rồi khởi động lại là xong. Chi tiết ở [Bảo mật & tài khoản](14-bao-mat-tai-khoan.md).

### Nhóm 5: Giọng đọc (TTS)

| Biến | Ý nghĩa | Mặc định | Khi nào đổi |
|---|---|---|---|
| `TTS_VOICE` | Giọng đọc mặc định (dùng Edge TTS miễn phí) | `en-US-EmmaMultilingualNeural` | Muốn giọng khác. Ví dụ giọng nam tiếng Việt hoặc giọng tiếng nước ngoài. |
| `TTS_RATE` | Tốc độ đọc, dạng phần trăm cộng/trừ | `+5%` | Thấy đọc nhanh quá thì giảm (ví dụ `+0%` hoặc `-10%`), muốn nhanh hơn thì tăng (ví dụ `+15%`). |

Lưu ý: hai biến TTS này áp cho giọng Edge TTS miễn phí mặc định. Nếu bạn chọn dùng nhà cung cấp giọng khác (OpenAI TTS hoặc ElevenLabs), phần đó cấu hình trong bảng Cài đặt của app chứ không qua `.env`. Cách trò chuyện và bật giọng nói xem ở [Trò chuyện & giọng nói](02-tro-chuyen-va-giong-noi.md).

### Nhóm 6: Deploy, tên miền và cập nhật

| Biến | Ý nghĩa | Mặc định | Khi nào đổi |
|---|---|---|---|
| `DOMAIN_NAME` | Tên miền mà reverse proxy (Traefik của Hostinger) định tuyến về Javis. Javis đọc để đối chiếu với tên miền bạn nhập trong app và biết có cần Redeploy không | (trống; compose Hostinger đặt `localhost`) | Deploy Hostinger: đặt bằng tên miền của bạn trong Docker Manager rồi Redeploy. Wizard trong app có nút **Sao chép biến** để copy sẵn dòng này. |
| `JAVIS_DEPLOY_TARGET` | Khai rõ đang chạy ở môi trường nào: `hostinger`, `vps`, `native`, `windows` | Tự đoán (hostname `.hstgr.cloud` = hostinger; chạy Docker = vps) | Hầu như không cần đặt tay. Compose Hostinger đã đặt sẵn `hostinger`. Đặt khi Javis đoán sai môi trường và wizard tên miền hiện sai hướng dẫn. |
| `WATCHTOWER_TOKEN` | Token cho nút "Cập nhật ngay" (trang **Cập nhật**) gọi Watchtower khi chạy Docker | Trong `docker-compose.yml`: `javis-update`. Ngoài Docker: trống (không có biến thì Javis coi như Watchtower không chạy) | Muốn chặt hơn: đổi thành chuỗi ngẫu nhiên, đặt cùng giá trị cho cả app lẫn service watchtower. |
| `JAVIS_AUTO_UPDATE` | Cho Watchtower TỰ đi tìm bản mới rồi dựng lại container, khỏi cần bấm nút | `false` | Mặc định tắt có chủ ý: bật là app tự khởi động lại bất cứ lúc nào có bản mới, cắt ngang việc nền và phiên chat đang chạy. Đặt trong `.env` (Hostinger: ô Environment) rồi dựng lại stack. |
| `JAVIS_AUTO_UPDATE_INTERVAL` | Chu kỳ Watchtower đi tìm bản mới, tính bằng GIÂY | `86400` (24 giờ) | Chỉ có tác dụng khi `JAVIS_AUTO_UPDATE=true`. Đừng đặt quá ngắn: mỗi lần có bản mới là một lần app khởi động lại. |
| `JAVIS_RESUME_AFTER_RESTART` | Việc đang dở lúc máy chủ khởi động lại (việc team, lượt chat, việc nền) tự chạy tiếp | `1` | Đặt `0` để quay về cách cũ: việc bị cắt chờ bạn bấm Làm tiếp hoặc Thử lại. Bước đã kịp làm một việc ra ngoài (gửi, đăng) thì luôn dừng hỏi, không tự làm lại. |

### Nhóm 7: Biến nâng cao (hiếm khi cần đụng)

| Biến | Ý nghĩa | Mặc định | Khi nào đổi |
|---|---|---|---|
| `JAVIS_MINIFY` | Máy chủ tự nén gọn JS/CSS của giao diện trước khi gửi cho trình duyệt (bỏ chú thích và khoảng trắng thừa, giữ nguyên số dòng; từ 0.416.0). `0` = gửi nguyên bản | `1` | Chỉ cần khi gỡ lỗi giao diện và muốn xem đúng mã nguồn trong công cụ của trình duyệt. Tắt thì lần mở đầu tải nặng hơn khoảng 40%. |
| `JAVIS_CLAUDE_IDLE_TIMEOUT` | Trần chờ khi engine đã trả lời rồi im giữa chừng mà KHÔNG có tool nào đang chạy, tính bằng giây. `0` = không giới hạn | `0` | Mặc định bỏ trần: engine im lặng KHÔNG có nghĩa là treo (model suy nghĩ ở mức nỗ lực cao, hoặc đang soạn nội dung một file dài để ghi ra, đều im hàng phút). Chỉ đặt số dương nếu bạn thật sự cần cắt lượt tự động. |
| `JAVIS_CLAUDE_FIRST_TIMEOUT` | Trần chờ chữ ĐẦU TIÊN của một lượt, tính bằng giây. `0` = không giới hạn | `0` | Cùng lý do với biến trên: hội thoại dài thì lượt đầu phải nạp lại toàn bộ ngữ cảnh nên lâu. |
| `JAVIS_CLAUDE_TOOL_TIMEOUT` | Trần chờ khi một TOOL của Claude Code hay Codex đang chạy dở (render video, tách nền, build...), tính bằng giây. `0` = không giới hạn | `0` (không giới hạn) | Từ 2026-11-07 mặc định bỏ trần. Đặt một số dương nếu muốn tự cắt tool chạy quá lâu. Nút Dừng luôn cắt được. |
| `JAVIS_CODEX_SANDBOX` | Có dùng rào sandbox riêng của Codex (ChatGPT) cho việc nền không. `auto` = có, khớp mức quyền của việc (suggest thành read-only, auto thành workspace-write). `off` = không đặt rào riêng | `auto`, nhưng **ảnh Docker đặt sẵn `off`** | Codex bọc lệnh đọc/ghi file bằng bubblewrap, mà bubblewrap không khởi động nổi trong container (user thường, không có CAP_SYS_ADMIN, Ubuntu 24.04 còn chặn user namespace bằng AppArmor) nên rào đó không phải chặt hơn mà là chết hẳn - mọi việc nền chạy bằng ChatGPT đều không đọc nổi một file nào. Chạy ngoài Docker thì để `auto`. Đánh đổi khi `off`: Codex không có allowlist per-call như Claude nên mức `suggest` mất thứ chặn nó ghi file; rào tiền/đơn/đăng bài/gửi tin KHÔNG bị ảnh hưởng vì chúng nằm ở MCP Hub. |
| `JAVIS_AGY_PROMPT_DAI` | Ép cách Javis đưa prompt cho Antigravity CLI khi prompt dài hơn trần dòng lệnh: `stdin` (bơm qua ống dẫn), `file` (ghi ra file rồi bảo model tự đọc), `argv` (nhét thẳng vào dòng lệnh) | (trống, Javis tự chọn: stdin trước, hỏng thì tự lui về file) | Chỉ khi máy bạn gặp ca lạ. Windows chặn tổng dòng lệnh ở 32767 ký tự trong khi system prompt của Javis đã hơn 36.000, nên `argv` ở đó là chắc chắn gãy. Xem [Models & engine](10-models-va-engine.md). |
| `JAVIS_AGY_TIMEOUT` | Trần thời gian một lượt chạy của Antigravity CLI, tính bằng giây. Javis truyền luôn số này xuống `--print-timeout` của chính CLI | `0` (không giới hạn) | Để trống hoặc `0` là không có trần ở mức `full`/`auto`; mức `suggest` vẫn giữ lưới 15 phút vì nó không tự duyệt tool. Đặt một số dương khi muốn tự cắt lượt dài. Javis luôn truyền một số cho `agy`, vì nếu không nó tự cắt ở phút thứ 5. |
| `JAVIS_AGY_MCP_HOME` | Javis có được ghi cấu hình MCP vào HOME của bạn không (`~/.gemini/config/mcp_config.json` - chỗ `agy` THẬT SỰ nạp MCP). `0` = không, chỉ ghi `<brain>/.agents/mcp_config.json` | (trống = có ghi) | Đặt `0` là chấp nhận Antigravity **mất hết tool của Javis** trên mọi bản `agy` chưa vá issue #60 (bản đó tìm thấy cấu hình workspace rồi bỏ qua). Chỉ đặt nếu bạn không muốn Javis đụng vào file dùng chung với Antigravity IDE. |
| `JAVIS_AGY_MCP_CONFIG` | Ghi cấu hình MCP cho `agy` vào ĐÚNG file này thay cho hai đường HOME mặc định | (trống) | Dùng khi bản `agy` của bạn để cấu hình ở chỗ khác. |
| `JAVIS_AGY_MCP_KEY` | Tên khoá URL Javis ghi vào entry MCP: `serverUrl` (hiện hành) hoặc `url` (bản 1.0.x cũ) | (trống = ghi cả hai) | Chỉ khi bản `agy` của bạn từ chối entry có khoá lạ. Ghi cả hai là để bản nào cũng nhận ra; máy dựng Javis không tải được `agy` nên chỗ này chưa đo trực tiếp được. |
| `JAVIS_GROK_BIN` | Đường dẫn thẳng tới binary `grok` (Grok Build CLI) | (trống, Javis tự tìm trong PATH và `~/.local/bin`) | Chỉ khi máy cài nó ở chỗ lạ. |
| `GROK_DISABLE_AUTOUPDATER` | Tắt bộ tự cập nhật của Grok Build CLI. Javis TỰ đặt `1` cho mọi lượt nó chạy `grok` | `1` (Javis đặt, nhưng tôn trọng giá trị bạn đặt sẵn) | Đặt `0` nếu muốn CLI tự nâng cấp. Không nên: Javis chạy nó headless, bộ cập nhật xen vào giữa lượt là in thêm chữ vào luồng kết quả hoặc ghi vào chỗ chỉ đọc. Nâng cấp tay bằng `grok update`. |
| `JAVIS_GROK_TIMEOUT` | Trần thời gian một lượt chạy của Grok Build CLI, tính bằng giây | `0` (không giới hạn) | Để trống hoặc `0` là không có trần. Riêng bản CLI không khai cờ `--permission-mode` vẫn giữ lưới 900 giây: Javis không truyền được cờ đó, một lượt headless dừng lại hỏi duyệt sẽ treo im tới vô tận, và lưới này là thứ duy nhất gỡ được. |
| `JAVIS_BG_MAX_WALL_S` | Trần thời gian một lần chạy việc nền (Kanban, nhắc hẹn, bước workflow), tính bằng giây | `0` (không giới hạn) | Đặt một số dương nếu muốn việc nền tự dừng sau chừng đó giây. Dừng tay ở trang Việc lúc nào cũng được. |
| `JAVIS_TEAM_TURN_TIMEOUT` / `JAVIS_TEAM_STEP_TIMEOUT` | Trần thời gian một lần trả lời trong Nhóm / một bước của việc nhóm, tính bằng giây | `0` (không giới hạn) | Đặt số dương để có trần lại (thấp nhất 30 và 60 giây). |
| `JAVIS_MAX_TOOL_ROUNDS` | Số vòng gọi tool tối đa cho MỘT lượt trả lời của **bot nói chuyện với khách** khi chạy bằng API key (OpenRouter, OpenAI, Anthropic, Gemini, Groq, DeepSeek, Ollama). Bị kẹp trong khoảng 1 đến 120 | `30` | Việc của chính bạn (khung chat, trang Code, việc nền) không dùng trần này mà dùng `JAVIS_MAX_TOOL_ROUNDS_CODING` bên dưới. Giữ thấp để người lạ nhắn bot không bắt Javis đốt hàng trăm vòng token. Claude Code và Codex KHÔNG chịu trần này - chúng tự quản vòng lặp của mình. |
| `JAVIS_MAX_TOOL_ROUNDS_CODING` | Số vòng gọi tool tối đa cho MỘT lượt **việc của bạn** chạy bằng API key: mọi khung chat của bạn, trang Code, và việc nền (task, loop, workflow, team). Kẹp tối đa 2000, `0` là không đặt trần | `500` | Phanh chính chống model kẹt là phát hiện lặp không tiến triển (gọi y nguyên mà kết quả y nguyên: dừng ở vòng thứ 5; chờ một việc đang chạy: tối đa 30 lần; xoay vòng A-B-A-B: dừng). Việc dài như điền cả trăm dòng sheet hay dựng video chạy được tới hết. Tên biến giữ từ thời chỉ trang Code dùng. |
| `JAVIS_TOOL_LOOP_BUDGET_CHARS` | Ngân sách ký tự cho kết quả tool trong MỘT lượt chạy bằng API key. Vượt thì kết quả cũ được rút về đoạn đầu, kết quả mới nhất giữ nguyên | `200000` | Để lượt dài không tràn ngữ cảnh của model và không đắt dần mỗi vòng. Model có cửa sổ lớn (1 triệu token) thì tăng; model cửa sổ nhỏ hay báo quá hạn mức giữa chừng thì giảm. `0` là tắt. |
| `JAVIS_TOOL_RESULT_SHAPING` | Bật tắt việc làm gọn kết quả tool trước khi model đọc: kết quả lớn được cất nguyên vẹn (mã hoá), model nhận phần gọn kèm mã tham chiếu và đọc lại bằng `javis_query`. `0` là tắt, `1` là bật kể cả khi bạn đang để mức tiết kiệm Tắt | bật, trừ khi bạn tự chọn mức tiết kiệm Tắt | Tắt khi cần so sánh với hành vi cũ. Cũng chỉnh được bằng `mcp.result_shaping` (`"auto"`, `true`, `false`) trong `settings.json` |
| `JAVIS_TOOL_RESULT_INLINE_CHARS` | Kết quả tool dài tới ngần này ký tự (sau khi bỏ thụt dòng và trường rỗng) thì đưa thẳng cho model, dài hơn thì cất và đưa phần gọn. Kẹp trong khoảng 2.000 đến 200.000 | `8000` | Model có cửa sổ ngữ cảnh rộng và bạn muốn ít vòng gọi hơn thì tăng. Tăng là tốn token hơn |
| `JAVIS_TOOL_RESULT_PREVIEW_CHARS` | Kích thước phần gọn model nhận thay cho một kết quả lớn | `6000` | Hiếm khi cần đổi |
| `JAVIS_TOOL_RESULT_TTL_HOURS` | Bản đầy đủ của kết quả tool được giữ bao nhiêu giờ rồi tự xoá. Kẹp 1 đến 336 | `24` | Việc dài nhiều ngày cần đọc lại kết quả cũ thì tăng |
| `JAVIS_TOOL_RESULT_STORE_MB` | Trần dung lượng kho kết quả tool (`tool_results.sqlite3` trong thư mục state). Đầy thì bản cũ nhất bị xoá trước | `256` | VPS ít đĩa thì giảm |
| `JAVIS_QUERY_MAX_PAGES` | Số trang tối đa `javis_query` tự lật khi gom dữ liệu từ một tool đọc. Kẹp 1 đến 500 | `200` | Nguồn dữ liệu giới hạn tần suất chặt thì giảm |
| `JAVIS_SCOUT` | Bật tắt trinh sát (`javis_scout`): model chính giao việc đọc dữ liệu nặng cho model việc nền, chỉ nhận lại kết luận. `0` là tắt | bật | Tắt nếu không muốn model nền bị gọi giữa lượt chat. Cũng chỉnh được bằng `mcp.scout` trong `settings.json` |
| `JAVIS_SCOUT_MAX_WALL_S` / `JAVIS_SCOUT_MAX_PARALLEL` | Trần thời gian một lượt trinh sát (giây) và số trinh sát chạy cùng lúc trên cả máy | `300` / `2` | Model nền chậm thì tăng thời gian. Hết giờ hoặc hết chỗ thì model chính tự làm như cũ |
| `JAVIS_RECIPES` | Bật tắt "công thức" của việc định kỳ: sau hai lần chạy giống nhau ở hai ngày khác nhau, Javis tự lấy sẵn dữ liệu trước khi model chạy. `0` là tắt | bật | Tắt nếu muốn mọi lần chạy đều do model tự dò từ đầu. Cũng chỉnh được bằng `mcp.recipes`. Xoá một công thức: xoá file trong `<brain>/Javis/recipes/` |
| `JAVIS_KANBAN_MAX_WORKERS` | Số việc Kanban chạy song song. Bị kẹp trong khoảng 1 đến 8 | `2` | VPS khoẻ và hàng việc dài thì tăng; máy yếu hoặc hay nghẽn thì để `1`. Xem [Việc / Kanban](21-viec-kanban.md). |
| `JAVIS_TEAM_PARALLEL` | Số team chạy việc cùng lúc trên cả máy. Kẹp trong khoảng 1 đến 64 | `4` | Nhiều team cùng có việc mà team sau cứ phải chờ thì tăng. Máy yếu hoặc muốn tiết kiệm lượt gói thì giảm. Mỗi team chạy tối đa `JAVIS_TEAM_JOBS` việc một lúc. |
| `JAVIS_TEAM_JOBS` | Số việc MỘT team chạy cùng lúc, khi các việc thuộc các cộng sự khác nhau. Tối thiểu 1 | `3` | Từ 12/11/2026 hai cộng sự có hai việc khác nhau thì làm song song. Việc của cùng một cộng sự, và việc ghi rõ "sau khi ... xong", vẫn chạy lần lượt. Đặt `1` để mỗi team chạy từng việc một như trước. |
| `JAVIS_TEAM_CLI_SLOTS` | Số lượt team gọi model CÙNG LÚC trên mỗi engine dùng gói đăng ký (Claude Code, ChatGPT qua Codex, Grok Build, Antigravity CLI). Kẹp trong khoảng 1 đến 64 | `3` | Từ 0.257.0 một cộng sự làm được ở nhiều team cùng lúc, nên đây là cái phanh. Để thấp: chạy chục tiến trình cùng lúc trên một tài khoản gói dễ dính giới hạn tốc độ hoặc bị khoá tài khoản. Lượt vượt trần thì chờ, không mất. |
| `JAVIS_TEAM_API_SLOTS` | Như trên nhưng cho mỗi engine dùng API key (OpenRouter, OpenAI, Anthropic, Gemini, Groq, DeepSeek, Ollama...) | `6` | Gói API của bạn cho phép nhiều lời gọi song song thì tăng; hay gặp lỗi 429 thì giảm. |
| `JAVIS_TEAM_JOB_PARALLEL` | Số bước Làm của MỘT việc team chạy cùng lúc (mỗi cộng sự một bước). Kẹp trong khoảng 1 đến 64 | `3` | Từ 0.260.0 trưởng nhóm chia việc cho 3 người thì 3 người làm cùng lúc rồi mới tổng hợp. Đặt `1` để làm lần lượt như trước. |
| `JAVIS_TEAM_TOOL_SLOTS` | Số lượt có công cụ (đọc ghi file, MCP) chạy cùng lúc trong MỘT thư mục làm việc. Team đã ghim thư mục riêng thì tính riêng, chưa ghim thì tính chung cả brain | `3` | Đặt `1` nếu muốn chặt như trước 0.260.0: trong một thư mục chỉ một cộng sự ghi file một lúc, không ai ghi đè ai, đổi lại chậm hơn. |
| `JAVIS_MEMORY_INDEX_MAX` | Trần ký tự của chỉ mục bộ nhớ (`MEMORY.md`) nạp vào mọi lượt chat. Vượt trần thì Javis rút gọn dần mô tả chứ không bỏ ký ức | `20000` | Bộ nhớ quá dày làm mỗi lượt chat tốn token; muốn siết thì hạ số này. Xem [Second Brain](13-second-brain-bo-nho-wiki.md). |
| `JAVIS_CLAUDE_ENGINE` | (Lịch sử) Từ 0.9.37 engine Claude luôn chạy qua Agent SDK chính chủ - biến này không còn tác dụng, đặt `cli`/`sdk-loops` sẽ bị bỏ qua kèm một dòng log | `sdk` | Không cần đụng. Engine Claude trục trặc thì báo lỗi kèm log server. |
| `JAVIS_CODEX_BIN` | Đường dẫn tuyệt đối tới file thực thi `codex` | Tự dò trong PATH và các chỗ cài quen thuộc | Cài Codex CLI ở nơi lạ mà Javis không tìm ra. |
| `CLAUDE_CONFIG_DIR` | Thư mục cấu hình của Claude Code (nơi có `.credentials.json`). Đặt biến này là ĐÈ hẳn, giống hành vi của Claude Code | `~/.claude` | Bạn đã tự đổi thư mục cấu hình Claude Code. |
| `CLAUDE_CODE_OAUTH_TOKEN` | Token OAuth của Claude Code, dùng để hỏi danh sách model thật từ Anthropic | (trống, đọc từ file credentials) | Môi trường không có file credentials (CI, container tối giản) mà vẫn muốn danh sách model động. |
| `JAVIS_CLAUDE_PROJECTS_DIR` | Nơi Javis đọc log phiên Claude Code để tính **Mức dùng** | `~/.claude/projects` | Log Claude Code nằm chỗ khác. Xem [Mức dùng: token & chi phí](23-muc-dung-token.md). |
| `JAVIS_CODEX_SESSIONS_DIR` | Nơi Javis đọc log phiên Codex để tính **Mức dùng** | `~/.codex/sessions` | Log Codex nằm chỗ khác. |
| `JAVIS_YOUTUBE_PROXY` | Proxy RIÊNG cho phần đọc phụ đề YouTube, dạng `http://user:mat-khau@may-chu:cong`. Chỉ lưu lượng đi YouTube mới qua đây | (trống, đi thẳng) | Javis báo "YouTube nghi máy chủ này là robot" lặp đi lặp lại. Gốc rễ của lỗi đó là **danh tiếng địa chỉ IP**: YouTube đánh dấu dải IP của các nhà cung cấp máy chủ (AWS, Google Cloud, Azure, VPS giá rẻ), nên cùng một đoạn mã chạy ở nhà thì trôi chảy còn chạy trên VPS thì bị hỏi giấy. Trỏ qua một proxy dân cư là đứng ở chỗ khác trên Internet. Đừng dùng `HTTPS_PROXY` của hệ thống cho việc này: nó đẩy **toàn bộ** lưu lượng của Javis qua đó, gồm cả gọi model và MCP, vừa chậm vừa lộ dữ liệu cho bên thứ ba. Xem [Trò chuyện](02-tro-chuyen-va-giong-noi.md). |
| `JAVIS_IMAGE_HOST_MODEL` | Ghim cứng model chat "chủ" dùng để gọi tool tạo ảnh qua gói ChatGPT | trống (tự chọn: `gpt-5.5` nếu gói có, không thì model khác trong danh sách model ChatGPT của tài khoản) | Muốn ép đúng một model. Không đặt thì Javis tự đổi model khi gói báo "model is not supported". |
| `JAVIS_IMAGE_MODEL` | Model sinh ảnh thật sự | `gpt-image-2` | Như trên. |

Ghi chú: `JAVIS_ENABLE_USER_PLUGINS` cũng là biến nâng cao nhưng vì nó là rào bảo mật nên đã nằm ở nhóm 3.

## Khối `media` trong settings.json (không có giao diện)

Thư mục `attachments/` và `inbox/` của mỗi brain là **vùng cache**, không phải kho tri thức: ảnh là nguyên liệu đi qua, đọc xong rút thành `.md` là đủ. Vì thế Javis tự dọn chúng theo tuổi và theo dung lượng, sáu tiếng quét một lần. Thư mục stage tạm (nơi tệp bạn dán vào khung chat rơi xuống) có hạn riêng, ngắn hơn hẳn.

Luật dọn này **chưa có ô nào trong Cài đặt**. Muốn đổi, mở `settings.json` trong thư mục state (máy cá nhân: `server/settings.json`; Docker: `/data/state/settings.json`) và sửa khối `media`:

```json
"media": {
  "enabled": true,
  "max_age_days": 30,
  "max_mb": 300,
  "staging_days": 3
}
```

| Khoá | Ý nghĩa | Mặc định |
|---|---|---|
| `enabled` | `false` = không dọn gì cả | `true` |
| `max_age_days` | Tệp media cũ hơn số ngày này bị xoá. Đặt `0` hoặc số âm = tắt luật tuổi | `30` |
| `max_mb` | Trần dung lượng vùng media của mỗi brain, tính bằng MB. Đặt `0` hoặc số âm = tắt luật dung lượng | `300` |
| `staging_days` | Hạn riêng cho thư mục stage tạm trong thư mục state | `3` |

Sửa xong phải khởi động lại Javis. Ảnh đã bị dọn mà vẫn còn được nhắc trong hội thoại cũ sẽ hiện thành một ô xám báo ảnh đã hết hạn, không phải icon vỡ. Muốn giữ ảnh lâu dài thì đấu một kho ngoài (ví dụ Drive) qua trang **Kết nối**, đừng để Javis ôm.

## Điểm cần nhớ về ANTHROPIC_API_KEY

Javis dùng chính **gói subscription** bạn đang trả làm bộ não (Claude Code cho gói Claude, Codex cho gói ChatGPT), nên **không cần** biến `ANTHROPIC_API_KEY` trong `.env`. Các MCP bạn cài vào Claude Code, Javis tự kế thừa. Nếu muốn dùng model qua nhà cung cấp API (OpenRouter, OpenAI API, Anthropic API, Google Gemini API, Groq API), bạn nhập khoá trong app ở trang **Models**, không đặt trong `.env`. Khoá nhập ở đó được mã hoá trước khi lưu xuống `settings.json`. Xem [Models & engine](10-models-va-engine.md).

## Ví dụ một file .env tối giản

Máy cá nhân, chỉ muốn đổi tên và tốc độ đọc, để nguyên phần còn lại:

```
WORKSPACE_NAME=Trợ lý của Quy
USER_NAME=Quy
TTS_RATE=+0%
```

Deploy public trên VPS, tạo sẵn admin và mở cho truy cập từ ngoài:

```
JAVIS_HOST=0.0.0.0
JAVIS_ADMIN_USER=admin
JAVIS_ADMIN_PASSWORD=doi-mat-khau-that-manh-o-day
OBSIDIAN_VAULT_PATH=/data/vault
JAVIS_STATE_DIR=/data/state
JAVIS_ALLOWED_HOSTS=javis.tencuaban.com
```

Ở ví dụ thứ hai, vì `JAVIS_HOST=0.0.0.0` (public) nên Javis tự bật bắt buộc đăng nhập, và vì đã có `JAVIS_ADMIN_PASSWORD` nên bạn đăng nhập luôn bằng tài khoản đó, không có lúc nào server trống admin.

## Mẹo

1. Luôn giữ lại `env.example` làm bản gốc tham chiếu. Chỉ sửa `.env`.
2. Đổi biến trong `.env` xong phải khởi động lại Javis mới ăn. Khác với bảng Cài đặt trong app (đổi là ăn ngay).
3. Không chắc một biến làm gì thì cứ để nguyên dấu `#` (chú thích) cho an toàn. Mặc định đã chạy tốt.
4. Với các biến bật/tắt (`JAVIS_REQUIRE_LOGIN`, `JAVIS_SECURE_COOKIE`, `JAVIS_ENABLE_USER_PLUGINS`), giá trị bật chấp nhận `1`, `true`, `yes`, `on`. Giá trị tắt chấp nhận `0`, `false`, `no`, `off`.
5. File `.env` chứa mật khẩu và cấu hình nhạy cảm. Không đưa lên nơi công khai. Trên máy chung, đặt quyền đọc hạn chế. Tệp `.secret_key` trong thư mục state cũng vậy, và nó còn quan trọng hơn: mất là mất luôn mọi API key đã lưu.
6. Plugin do bạn cài chạy code Python thật trong tiến trình server. Javis tải chúng mặc định nhưng chỉ chạy plugin bạn đã bật; chỉ bật plugin khi biết rõ nó đến từ đâu, và đặt `JAVIS_ENABLE_USER_PLUGINS=false` nếu máy này không nên chạy plugin nào.

## Sự cố thường gặp

**Sửa .env rồi mà không thấy đổi gì.** Bạn chưa khởi động lại Javis. `.env` chỉ đọc lúc khởi động. Tắt server rồi mở lại.

**Đổi cổng xong không vào được app.** Bạn đang mở trình duyệt ở cổng cũ. Ví dụ đổi `JAVIS_PORT=8080` thì phải mở `http://localhost:8080`, không phải `7777` nữa.

**Đăng nhập đúng mật khẩu nhưng cứ bị đá về trang login.** Nhiều khả năng bạn đã bật `JAVIS_SECURE_COOKIE=1` nhưng thực tế đang truy cập qua HTTP (không phải HTTPS). Cookie Secure chỉ gửi qua HTTPS nên trình duyệt không giữ được phiên. Xoá dòng đó hoặc đặt về tắt, khởi động lại.

**Mọi thao tác trả 403 "host không được phép".** Bạn vào Javis bằng một tên miền chưa nằm trong allowlist, trong lúc chưa đặt mật khẩu. Thêm tên miền vào `JAVIS_ALLOWED_HOSTS` (hoặc nhập nó ở Cài đặt → Tên miền & SSL), hoặc đơn giản là đặt mật khẩu.

**Đã bật plugin trong app rồi mà nó vẫn không chạy.** Xem `.env` có dòng `JAVIS_ENABLE_USER_PLUGINS=false` không: có thì bỏ dòng đó (hoặc đặt `true`) rồi khởi động lại. Trong app, Javis cũng ghi rõ câu này khi bạn bật một plugin đang bị tắt.

**Đặt tên workspace trong .env mà app hiển thị tên khác.** App ưu tiên tên đã lưu trong Cài đặt hơn biến `WORKSPACE_NAME`. Sửa tên trong bảng Cài đặt của app, hoặc xoá tên đã lưu để app dùng lại giá trị từ `.env`.

**Trỏ OBSIDIAN_VAULT_PATH vào vault thật mà Javis không thấy dữ liệu.** Kiểm tra đường dẫn có đúng và Javis có quyền đọc thư mục đó không. Trên Docker phải mount đúng volume vào đường dẫn bạn khai. Sau khi sửa, khởi động lại và dựng lại đồ thị (xem [Đồ thị tri thức](03-do-thi-tri-thuc.md)).

**Khôi phục backup xong thì mọi API key trống trơn.** Bạn chép `settings.json` mà không chép `.secret_key` cùng thư mục. Không khôi phục được, phải nhập lại key ở trang Models và Kênh.

Nếu còn vướng, xem thêm [Khắc phục sự cố & FAQ](17-khac-phuc-su-co.md).

## Liên quan

- [Bắt đầu & thiết lập lần đầu](01-bat-dau-thiet-lap.md)
- [Bảo mật & tài khoản](14-bao-mat-tai-khoan.md)
- [Thương hiệu & tên miền riêng](15-thuong-hieu-ten-mien.md)
- [Models & engine](10-models-va-engine.md)
- [Plugins](20-plugins.md)
- [Mức dùng: token & chi phí](23-muc-dung-token.md)
