/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  LayoutGrid,
  MessageSquare,
  Eye,
  Database,
  GraduationCap,
  Box,
  FolderGit2,
  Shield,
  LogOut,
  Menu,
  X,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Volume2
} from 'lucide-react';
import {
  auth,
  db,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  serverTimestamp,
  onAuthStateChanged,
  signInWithGoogleAndDrive,
  signOutLorin,
  handleFirestoreError,
  OperationType,
  type User
} from './lib/firebase';
import {
  INITIAL_PROJECTS,
  INITIAL_DOCUMENTS,
  INITIAL_CONVERSATIONS,
  INITIAL_LEARNING_PATHS,
  INITIAL_VISION_ANALYSES,
  INITIAL_WORLD_PRESETS,
  type ProjectRecord,
  type KnowledgeDocumentRecord,
  type ConversationRecord,
  type ChatMessageRecord,
  type LearningPathRecord,
  type VisionAnalysisRecord
} from './data/seedData';
import type { VirtualWorldSceneSpec } from './utils/lorinLogic';
import { ChatWorkspace } from './components/ChatWorkspace';
import { VisionWorkspace } from './components/VisionWorkspace';
import { KnowledgeVault } from './components/KnowledgeVault';
import { LearningLab } from './components/LearningLab';
import { VirtualWorldStudio } from './components/VirtualWorldStudio';
import { ProjectsAndMaps } from './components/ProjectsAndMaps';

export type LorinModuleId =
  | 'command'
  | 'assistant'
  | 'vault'
  | 'world'
  | 'projects'
  | 'vision'
  | 'learning'
  | 'settings';

export default function App() {
  const [activeModule, setActiveModule] = useState<LorinModuleId>('command');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  // Firebase Auth User
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [preferredVoice, setPreferredVoice] = useState<
    'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr'
  >('Kore');

  // Application State (seeded with rich engineering data and synced with Firestore when signed in)
  const [projects, setProjects] = useState<ProjectRecord[]>(INITIAL_PROJECTS);
  const [documents, setDocuments] =
    useState<KnowledgeDocumentRecord[]>(INITIAL_DOCUMENTS);
  const [conversations, setConversations] = useState<ConversationRecord[]>(
    INITIAL_CONVERSATIONS
  );
  const [activeConversationId, setActiveConversationId] = useState<string>(
    INITIAL_CONVERSATIONS[0].conversationId
  );
  const [learningPaths, setLearningPaths] = useState<LearningPathRecord[]>(
    INITIAL_LEARNING_PATHS
  );
  const [visionAnalyses, setVisionAnalyses] = useState<VisionAnalysisRecord[]>(
    INITIAL_VISION_ANALYSES
  );
  const [activeWorldScene, setActiveWorldScene] =
    useState<VirtualWorldSceneSpec>(INITIAL_WORLD_PRESETS.laboratory);
  const [activityLogs, setActivityLogs] = useState<
    Array<{ id: string; operation: string; module: string; time: string }>
  >([
    {
      id: 'act_1',
      operation: 'Initialized LORIN Private Intelligence Workspace & 8-Pillar Security Rules',
      module: 'workspace',
      time: 'Just now'
    }
  ]);

  // Listen to Firebase Auth state & owner-scoped Firestore collections
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setAuthReady(true);
    });
    return () => unsubAuth();
  }, []);

  useEffect(() => {
    if (!authReady || !currentUser) return;

    const projQuery = query(
      collection(db, 'projects'),
      where('ownerId', '==', currentUser.uid)
    );
    const unsubProj = onSnapshot(
      projQuery,
      (snap) => {
        if (!snap.empty) {
          const loaded: ProjectRecord[] = snap.docs.map((d) => {
            const data = d.data();
            return {
              projectId: data.projectId,
              ownerId: data.ownerId,
              name: data.name,
              description: data.description,
              status: data.status,
              objectives: Array.isArray(data.objectives) ? data.objectives : [],
              updatedAtLabel: 'Synced with Firestore'
            };
          });
          setProjects((prev) => {
            const existingIds = new Set(loaded.map((l) => l.projectId));
            return [...loaded, ...prev.filter((p) => !existingIds.has(p.projectId))];
          });
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'projects')
    );

    const docQuery = query(
      collection(db, 'documents'),
      where('ownerId', '==', currentUser.uid)
    );
    const unsubDocs = onSnapshot(
      docQuery,
      (snap) => {
        if (!snap.empty) {
          const loadedDocs: KnowledgeDocumentRecord[] = snap.docs.map((d) => {
            const data = d.data();
            return {
              documentId: data.documentId,
              filename: data.filename,
              format: data.format,
              size: data.size,
              collectionName: data.collectionName,
              processingStatus: data.processingStatus,
              extractedText: data.extractedText,
              tags: Array.isArray(data.tags) ? data.tags : [],
              updatedAtLabel: 'Synced with Firestore'
            };
          });
          setDocuments((prev) => {
            const ids = new Set(loadedDocs.map((l) => l.documentId));
            return [...loadedDocs, ...prev.filter((p) => !ids.has(p.documentId))];
          });
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'documents')
    );

    return () => {
      unsubProj();
      unsubDocs();
    };
  }, [authReady, currentUser]);

  const logActivity = async (
    operation: string,
    module:
      | 'workspace'
      | 'vision'
      | 'vault'
      | 'learning'
      | 'world'
      | 'integrations'
  ) => {
    const newEntry = {
      id: `act_${Date.now()}`,
      operation: operation.slice(0, 120),
      module,
      time: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
    setActivityLogs((prev) => [newEntry, ...prev.slice(0, 19)]);

    if (currentUser?.emailVerified) {
      const activityId = newEntry.id;
      try {
        await setDoc(doc(db, 'activity_logs', activityId), {
          activityId,
          ownerId: currentUser.uid,
          operation: newEntry.operation,
          module,
          createdAt: serverTimestamp()
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `activity_logs/${activityId}`);
      }
    }
  };

  // Handlers for Conversation Threads
  const handleNewConversation = (projectId: string) => {
    const newConv: ConversationRecord = {
      conversationId: `conv_${Date.now()}`,
      title: `Engineering Session #${conversations.length + 1}`,
      status: 'active',
      relatedProjectId: projectId,
      updatedAtLabel: 'Just now',
      messages: [
        {
          messageId: `msg_${Date.now()}_init`,
          conversationId: `conv_${Date.now()}`,
          senderType: 'lorin',
          content:
            'New LORIN engineering thread initialized. Ready for text, camera snapshot inspection, microphone input, or Knowledge Vault queries.',
          modelUsed: 'gemini-3.8-flash',
          timestampLabel: new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
          })
        }
      ]
    };
    setConversations((prev) => [newConv, ...prev]);
    setActiveConversationId(newConv.conversationId);
  };

  const handleAppendMessage = (conversationId: string, msg: ChatMessageRecord) => {
    setConversations((prev) =>
      prev.map((c) =>
        c.conversationId === conversationId
          ? {
              ...c,
              updatedAtLabel: 'Just now',
              messages: [...c.messages, msg]
            }
          : c
      )
    );
  };

  // Handlers for Knowledge Vault Documents
  const handleAddDocument = async (newDoc: KnowledgeDocumentRecord) => {
    setDocuments((prev) => [newDoc, ...prev]);
    if (currentUser?.emailVerified) {
      try {
        await setDoc(doc(db, 'documents', newDoc.documentId), {
          documentId: newDoc.documentId,
          ownerId: currentUser.uid,
          filename: newDoc.filename.slice(0, 200),
          format: newDoc.format.slice(0, 32),
          size: Math.min(52428800, Math.max(0, Math.floor(newDoc.size))),
          collectionName: newDoc.collectionName.slice(0, 80),
          processingStatus: newDoc.processingStatus,
          extractedText: newDoc.extractedText.slice(0, 50000),
          tags: newDoc.tags.slice(0, 10),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `documents/${newDoc.documentId}`);
      }
    }
  };

  const handleDeleteDocument = async (documentId: string) => {
    setDocuments((prev) => prev.filter((d) => d.documentId !== documentId));
    if (currentUser?.emailVerified) {
      try {
        await deleteDoc(doc(db, 'documents', documentId));
      } catch {
        // Ignore if local seed doc
      }
    }
  };

  // Handlers for Projects
  const handleCreateProject = async (newProj: ProjectRecord) => {
    setProjects((prev) => [newProj, ...prev]);
    if (currentUser?.emailVerified) {
      try {
        await setDoc(doc(db, 'projects', newProj.projectId), {
          projectId: newProj.projectId,
          ownerId: currentUser.uid,
          name: newProj.name.slice(0, 120),
          description: newProj.description.slice(0, 2000),
          status: newProj.status,
          objectives: newProj.objectives.slice(0, 10),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `projects/${newProj.projectId}`);
      }
    }
  };

  const handleUpdateProjectStatus = async (
    projectId: string,
    status: ProjectRecord['status']
  ) => {
    const target = projects.find((p) => p.projectId === projectId);
    if (!target || target.status === 'Archived') return;

    setProjects((prev) =>
      prev.map((p) =>
        p.projectId === projectId
          ? { ...p, status, updatedAtLabel: 'Updated just now' }
          : p
      )
    );

    if (currentUser?.emailVerified && target.ownerId === currentUser.uid) {
      try {
        await updateDoc(doc(db, 'projects', projectId), {
          status,
          updatedAt: serverTimestamp()
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `projects/${projectId}`);
      }
    }
  };

  // Course Generation from Knowledge Vault Document
  const handleGenerateCourseFromDoc = (docItem: KnowledgeDocumentRecord) => {
    const newPath: LearningPathRecord = {
      learningPathId: `path_vault_${Date.now()}`,
      title: `Mastery Track: ${docItem.filename}`,
      subject: docItem.collectionName,
      targetLevel: 'intermediate',
      status: 'active',
      completedLessons: 0,
      totalLessons: 3,
      averageScore: 0,
      conceptOverview: docItem.extractedText.slice(0, 500),
      keyTakeaways: [
        `Derived directly from indexed Knowledge Vault specification "${docItem.filename}".`,
        'Verify primary architectural boundaries and operational thresholds before deployment.'
      ],
      workedExample: `// Extracted Reference from ${docItem.filename}:\nconst verifiedSource = "${docItem.filename}";\nconsole.log("Source verified:", verifiedSource);`,
      codingPrompt: `Log "Source verified: ${docItem.filename}" to verify comprehension of the specification.`,
      starterCode: `const verifiedSource = "${docItem.filename}";\nconsole.log("Source verified:", verifiedSource);`,
      expectedOutputSubstring: `Source verified: ${docItem.filename}`,
      quizQuestions: [
        {
          id: `vq_${Date.now()}_1`,
          question: `Which Knowledge Vault collection stores "${docItem.filename}"?`,
          options: [
            docItem.collectionName,
            'Unindexed Public Scratchpad',
            'External Unverified Cache'
          ],
          correctIndex: 0,
          explanation: `"${docItem.filename}" is indexed under the "${docItem.collectionName}" collection.`
        }
      ]
    };
    setLearningPaths((prev) => [newPath, ...prev]);
    setActiveModule('learning');
    logActivity(
      `Generated Learning Lab course from Vault document "${docItem.filename}"`,
      'learning'
    );
  };

  // Reconstruct Vision Inspection in 3D World Studio
  const handleReconstructIn3D = (
    preset: 'laboratory' | 'classroom' | 'observatory' | 'solar_array',
    summaryTitle: string
  ) => {
    const basePreset = INITIAL_WORLD_PRESETS[preset] || INITIAL_WORLD_PRESETS.laboratory;
    setActiveWorldScene({
      ...basePreset,
      name: `3D Reconstruction: ${summaryTitle.slice(0, 70)}`
    });
    setActiveModule('world');
    logActivity(`Reconstructed "${summaryTitle}" in 3D Virtual World Studio`, 'world');
  };

  const navItems: Array<{
    id: LorinModuleId;
    label: string;
    shortDesc: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    {
      id: 'command',
      label: 'Command Centre',
      shortDesc: 'Overview & Quick Launch',
      icon: LayoutGrid
    },
    {
      id: 'assistant',
      label: 'AI Assistant',
      shortDesc: 'Text, Camera & Mic Chat',
      icon: MessageSquare
    },
    {
      id: 'vault',
      label: 'RAG Knowledge Vault',
      shortDesc: 'Chunks, Diffs & Drive',
      icon: Database
    },
    {
      id: 'world',
      label: '3D World Studio',
      shortDesc: 'Three.js PBR Spatial Lab',
      icon: Box
    },
    {
      id: 'projects',
      label: 'Projects & Live Collab',
      shortDesc: 'Priorities, Dashboards & Maps',
      icon: FolderGit2
    },
    {
      id: 'vision',
      label: 'Vision Intelligence',
      shortDesc: 'Image, Video & Animation',
      icon: Eye
    },
    {
      id: 'learning',
      label: 'Learning Laboratory',
      shortDesc: 'Courses, Quizzes & Code',
      icon: GraduationCap
    },
    {
      id: 'settings',
      label: 'Security & Control Plane',
      shortDesc: 'Auth, Voices & Audit Log',
      icon: Shield
    }
  ];

  const userDisplayName =
    currentUser?.displayName || currentUser?.email || 'Authorized Owner';

  return (
    <div className="min-h-screen bg-[#0B0F14] text-[#F1F5F9] grid grid-cols-1 lg:grid-cols-[260px_1fr]">
      {/* Responsive Left Sidebar Navigation (CSS Grid column 1 on desktop, drawer on mobile) */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#111821] border-r border-slate-800/90 flex flex-col justify-between transition-transform duration-200 lg:static lg:translate-x-0 ${
          mobileNavOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 space-y-5">
          {/* Brand Identity */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#66E3CB]/15 border border-[#66E3CB]/40 flex items-center justify-center font-display font-bold text-[#66E3CB] text-sm">
                L
              </div>
              <div>
                <div className="font-display font-bold text-sm tracking-tight text-slate-100">
                  LORIN
                </div>
                <div className="text-[11px] text-slate-400">
                  Private Intelligence v2.0
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setMobileNavOpen(false)}
              className="lg:hidden p-1.5 text-slate-400 hover:text-white cursor-pointer"
              aria-label="Close navigation menu"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Primary Module Switcher */}
          <nav className="space-y-1" aria-label="LORIN Workspace Modules">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeModule === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveModule(item.id);
                    setMobileNavOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors cursor-pointer border ${
                    isActive
                      ? 'bg-[#17212C] border-[#66E3CB]/40 text-[#66E3CB]'
                      : 'border-transparent text-slate-300 hover:bg-[#17212C]/60 hover:text-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <div className="truncate">
                    <div className="text-xs font-semibold leading-tight">
                      {item.label}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">
                      {item.shortDesc}
                    </div>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Specialist Perspectives & Owner Session Status */}
        <div className="p-4 border-t border-slate-800/80 space-y-3 bg-[#0B0F14]/40">
          <div className="text-[11px] text-slate-400 space-y-1">
            <div className="font-semibold text-slate-300">
              Coordinated Specialist Modes
            </div>
            <div className="font-mono text-[10px] text-slate-400">
              Lena · Owen · Riley · Iris · Nolan
            </div>
          </div>

          {currentUser ? (
            <div className="space-y-2">
              <div className="text-xs font-medium text-slate-200 truncate">
                {userDisplayName}
              </div>
              <button
                type="button"
                onClick={signOutLorin}
                className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs text-slate-300 border border-slate-700 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => signInWithGoogleAndDrive().catch(() => {})}
              className="gsi-material-button w-full"
            >
              <div className="gsi-material-button-state"></div>
              <div className="gsi-material-button-content-wrapper">
                <div className="gsi-material-button-icon">
                  <svg
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 48 48"
                    style={{ display: 'block' }}
                  >
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    ></path>
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    ></path>
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    ></path>
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    ></path>
                    <path fill="none" d="M0 0h48v48H0z"></path>
                  </svg>
                </div>
                <span className="gsi-material-button-contents">
                  Sign in with Google
                </span>
              </div>
            </button>
          )}
        </div>
      </aside>

      {/* Main Content Area (CSS Grid Column 2) */}
      <div className="flex flex-col min-w-0">
        {/* Top Bar Contract (Max 4 top-level interactive groups, clean separation) */}
        <header className="h-14 px-5 bg-[#111821]/90 border-b border-slate-800/80 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileNavOpen(true)}
              className="lg:hidden p-1.5 rounded-lg bg-[#17212C] text-slate-200 cursor-pointer"
              aria-label="Open navigation menu"
            >
              <Menu className="w-4 h-4" />
            </button>
            <div className="text-sm font-semibold text-slate-100">
              {navItems.find((n) => n.id === activeModule)?.label}
            </div>
          </div>

          {/* Quick View Switcher Bar for AI Assistant, RAG Vault, 3D Studio, and Projects */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveModule('assistant')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                activeModule === 'assistant'
                  ? 'bg-[#66E3CB] text-[#0B0F14] font-semibold'
                  : 'bg-[#17212C] text-slate-300 hover:text-white'
              }`}
            >
              AI Assistant
            </button>
            <button
              type="button"
              onClick={() => setActiveModule('vault')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                activeModule === 'vault'
                  ? 'bg-[#66E3CB] text-[#0B0F14] font-semibold'
                  : 'bg-[#17212C] text-slate-300 hover:text-white'
              }`}
            >
              RAG Vault
            </button>
            <button
              type="button"
              onClick={() => setActiveModule('world')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                activeModule === 'world'
                  ? 'bg-[#66E3CB] text-[#0B0F14] font-semibold'
                  : 'bg-[#17212C] text-slate-300 hover:text-white'
              }`}
            >
              3D Studio
            </button>
            <button
              type="button"
              onClick={() => setActiveModule('projects')}
              className={`hidden sm:inline-flex px-2.5 py-1 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                activeModule === 'projects'
                  ? 'bg-[#A9B8FF] text-[#0B0F14] font-semibold'
                  : 'bg-[#17212C] text-slate-300 hover:text-white'
              }`}
            >
              Projects & Collab
            </button>
          </div>
        </header>

        {/* Active Module Viewport */}
        <main className="flex-1 p-5 overflow-y-auto">
          {activeModule === 'command' && (
            <div className="space-y-6">
              {/* Hero Welcome & Quick Launch */}
              <div className="bg-[#111821] border border-slate-800/90 rounded-2xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-2 max-w-2xl">
                  <div className="text-xs font-mono text-[#66E3CB] uppercase tracking-wider">
                    LORIN Unified Master Intelligence System
                  </div>
                  <h1 className="text-2xl font-display font-bold text-slate-100">
                    Private Engineering, Multimodal Research, RAG Knowledge & 3D Creation Studio
                  </h1>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    Coordinate software architecture, high-thinking security audits, optical & video diagnostics, deterministic RAG document citations, real-time project task prioritization, and Three.js spatial simulations from a single workspace.
                  </p>
                </div>

                <div className="flex flex-wrap gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveModule('assistant')}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs hover:bg-[#52cdb5] cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Open AI Assistant (Text/Cam/Mic)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveModule('projects')}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#17212C] hover:bg-slate-800 text-slate-100 border border-slate-700 font-semibold text-xs cursor-pointer"
                  >
                    <FolderGit2 className="w-4 h-4 text-[#A9B8FF]" />
                    <span>Project Dashboard & Priorities</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveModule('world')}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#17212C] hover:bg-slate-800 text-slate-100 border border-slate-700 font-semibold text-xs cursor-pointer"
                  >
                    <Box className="w-4 h-4 text-[#E8BE78]" />
                    <span>Launch 3D World Studio</span>
                  </button>
                </div>
              </div>

              {/* 4-Card KPI Summary Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-4 space-y-1">
                  <div className="text-xs text-slate-400">Active Engineering Projects</div>
                  <div className="text-2xl font-mono font-bold text-slate-100">
                    {projects.length}
                  </div>
                  <div className="text-[11px] text-[#66E3CB]">
                    Real-time WebSocket (/collab) enabled
                  </div>
                </div>

                <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-4 space-y-1">
                  <div className="text-xs text-slate-400">Knowledge Vault Documents</div>
                  <div className="text-2xl font-mono font-bold text-slate-100">
                    {documents.length}
                  </div>
                  <div className="text-[11px] text-[#A9B8FF]">
                    Deterministic RAG chunking & Drive sync
                  </div>
                </div>

                <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-4 space-y-1">
                  <div className="text-xs text-slate-400">Learning Laboratory Tracks</div>
                  <div className="text-2xl font-mono font-bold text-slate-100">
                    {learningPaths.length}
                  </div>
                  <div className="text-[11px] text-[#E8BE78]">
                    Avg Mastery Score:{' '}
                    {Math.round(
                      learningPaths.reduce((acc, p) => acc + p.averageScore, 0) /
                        Math.max(1, learningPaths.length)
                    )}
                    %
                  </div>
                </div>

                <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-4 space-y-1">
                  <div className="text-xs text-slate-400">Active 3D Spatial Scene</div>
                  <div className="text-lg font-mono font-bold text-slate-100 truncate">
                    {activeWorldScene.environmentPreset}
                  </div>
                  <div className="text-[11px] text-[#66E3CB]">
                    {activeWorldScene.objects.length} composite PBR assemblies
                  </div>
                </div>
              </div>

              {/* Capability Modules Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  {
                    id: 'assistant' as LorinModuleId,
                    title: 'Central LORIN AI Assistant',
                    desc: 'Multimodal chat composer with text, inline camera snapshot capture, microphone voice input, High Thinking (gemini-4-carbon), Search/Maps Grounding, and Live Voice API.',
                    accent: 'text-[#66E3CB]'
                  },
                  {
                    id: 'vault' as LorinModuleId,
                    title: 'Knowledge Vault AI & RAG',
                    desc: 'Deterministic 600-character chunking, passage-level citation scoring, cross-version document diff comparison, and Google Drive import/export.',
                    accent: 'text-[#A9B8FF]'
                  },
                  {
                    id: 'world' as LorinModuleId,
                    title: '3D Virtual World Studio',
                    desc: 'Interactive Three.js PBR workspace with RoomEnvironment reflections, composite 3–12 part assemblies, raycast inspection, and natural-language scene generation.',
                    accent: 'text-[#E8BE78]'
                  },
                  {
                    id: 'projects' as LorinModuleId,
                    title: 'Project Management & Real-Time Collaboration',
                    desc: 'Task prioritization (High / Medium / Low), customizable user dashboards, live WebSocket shared document editing, task comment threads, and team messaging.',
                    accent: 'text-[#66E3CB]'
                  },
                  {
                    id: 'vision' as LorinModuleId,
                    title: 'Vision Intelligence System',
                    desc: 'Optical hardware inspection, dual-image differential comparison, video timeline understanding (gemini-4-argon), and image-to-video animation (gemini-omni-1.2-flash).',
                    accent: 'text-[#A9B8FF]'
                  },
                  {
                    id: 'learning' as LorinModuleId,
                    title: 'AI Learning Laboratory',
                    desc: 'Adaptive engineering curricula, sandboxed JavaScript coding laboratory, comprehension quizzes with hidden answers until submission, and Vault-to-course synthesis.',
                    accent: 'text-[#E8BE78]'
                  }
                ].map((card) => (
                  <div
                    key={card.id}
                    onClick={() => setActiveModule(card.id)}
                    className="bg-[#111821] hover:bg-[#17212C] border border-slate-800/90 hover:border-slate-700 rounded-xl p-5 flex flex-col justify-between gap-4 transition-colors cursor-pointer"
                  >
                    <div className="space-y-2">
                      <h2 className={`text-sm font-semibold ${card.accent}`}>
                        {card.title}
                      </h2>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {card.desc}
                      </p>
                    </div>
                    <div className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-200">
                      <span>Launch Module</span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#66E3CB]" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeModule === 'assistant' && (
            <ChatWorkspace
              conversations={conversations}
              activeConversationId={activeConversationId}
              onSelectConversation={setActiveConversationId}
              onNewConversation={handleNewConversation}
              onAppendMessage={handleAppendMessage}
              documents={documents}
              projects={projects}
              preferredVoice={preferredVoice}
              onLogActivity={(op, mod) => logActivity(op, mod)}
            />
          )}

          {activeModule === 'vault' && (
            <KnowledgeVault
              documents={documents}
              onAddDocument={handleAddDocument}
              onDeleteDocument={handleDeleteDocument}
              onGenerateCourseFromDoc={handleGenerateCourseFromDoc}
              onLogActivity={(op, mod) => logActivity(op, mod)}
            />
          )}

          {activeModule === 'world' && (
            <VirtualWorldStudio
              activeScene={activeWorldScene}
              onUpdateScene={setActiveWorldScene}
              onLogActivity={(op, mod) => logActivity(op, mod)}
            />
          )}

          {activeModule === 'projects' && (
            <ProjectsAndMaps
              projects={projects}
              onCreateProject={handleCreateProject}
              onUpdateProjectStatus={handleUpdateProjectStatus}
              currentUserName={userDisplayName}
              onLogActivity={(op, mod) => logActivity(op, mod)}
            />
          )}

          {activeModule === 'vision' && (
            <VisionWorkspace
              analyses={visionAnalyses}
              onSaveAnalysis={(rec) =>
                setVisionAnalyses((prev) => [rec, ...prev])
              }
              onReconstructIn3D={handleReconstructIn3D}
              onLogActivity={(op, mod) => logActivity(op, mod)}
            />
          )}

          {activeModule === 'learning' && (
            <LearningLab
              learningPaths={learningPaths}
              onUpdateLearningPath={(updated) =>
                setLearningPaths((prev) =>
                  prev.map((p) =>
                    p.learningPathId === updated.learningPathId ? updated : p
                  )
                )
              }
              onAddLearningPath={(created) =>
                setLearningPaths((prev) => [created, ...prev])
              }
              onLogActivity={(op, mod) => logActivity(op, mod)}
            />
          )}

          {activeModule === 'settings' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <div className="lg:col-span-6 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
                <h1 className="text-base font-semibold text-slate-100">
                  Owner Security Control Plane & Preferences
                </h1>
                <p className="text-xs text-slate-400">
                  Strict identity isolation between private LORIN and external platforms.
                </p>

                <div className="space-y-3 pt-2">
                  <div>
                    <label className="block text-xs text-slate-300 mb-1 flex items-center gap-1.5">
                      <Volume2 className="w-3.5 h-3.5 text-[#66E3CB]" />
                      <span>Preferred TTS Voice (gemini-3.8-flash-tts)</span>
                    </label>
                    <select
                      value={preferredVoice}
                      onChange={(e) => setPreferredVoice(e.target.value as any)}
                      className="w-full bg-[#0B0F14] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
                    >
                      <option value="Kore">Kore (Calm Analytical)</option>
                      <option value="Zephyr">Zephyr (Conversational)</option>
                      <option value="Puck">Puck (Crisp Technical)</option>
                      <option value="Charon">Charon (Deep Resonant)</option>
                      <option value="Fenrir">Fenrir (Direct Executive)</option>
                    </select>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#0B0F14] border border-slate-800 space-y-1.5 text-xs">
                    <div className="font-semibold text-[#66E3CB] flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>8-Pillar Firestore Security Rules Deployed</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      Default-Deny fallback, verified-email write enforcement, split-collection PII isolation (<code className="text-[#A9B8FF]">/users/&#123;userId&#125;/private/info</code>), and terminal state locking are active.
                    </p>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-6 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
                <h2 className="text-sm font-semibold text-slate-100">
                  Immutable Session Activity Audit Log
                </h2>
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {activityLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3 rounded-lg bg-[#0B0F14] border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-mono text-[#66E3CB] uppercase mr-2">
                          [{log.module}]
                        </span>
                        <span className="text-slate-200">{log.operation}</span>
                      </div>
                      <span className="text-[11px] font-mono text-slate-500">
                        {log.time}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
