import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Film,
  Sparkles,
  Box,
  Layers,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Video
} from 'lucide-react';
import type { VisionAnalysisRecord } from '../data/seedData';

interface VisionWorkspaceProps {
  analyses: VisionAnalysisRecord[];
  onSaveAnalysis: (record: VisionAnalysisRecord) => void;
  onReconstructIn3D: (
    preset: 'laboratory' | 'classroom' | 'observatory' | 'solar_array',
    summary: string
  ) => void;
  onLogActivity: (operation: string, module: 'vision') => void;
}

export const VisionWorkspace: React.FC<VisionWorkspaceProps> = ({
  analyses,
  onSaveAnalysis,
  onReconstructIn3D,
  onLogActivity
}) => {
  const [activeTab, setActiveTab] = useState<
    'inspect' | 'compare' | 'video' | 'animate'
  >('inspect');
  const [primaryImage, setPrimaryImage] = useState<string | null>(null);
  const [secondaryImage, setSecondaryImage] = useState<string | null>(null);
  const [question, setQuestion] = useState(
    'Inspect visible hardware components, labels, clearances, and potential anomalies.'
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Video Understanding & Animation state
  const [videoBase64, setVideoBase64] = useState<string | null>(null);
  const [videoMimeType, setVideoMimeType] = useState('video/mp4');
  const [videoSummary, setVideoSummary] = useState<string | null>(null);
  const [animatePrompt, setAnimatePrompt] = useState(
    'Slow orbital camera pan across the autonomous robotics laboratory with crisp reflections.'
  );
  const [animateAspectRatio, setAnimateAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);

  // Camera state
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const generateDiagnosticSampleImage = (variant: 'A' | 'B') => {
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 380;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';
    ctx.fillStyle = '#0B0F14';
    ctx.fillRect(0, 0, 640, 380);
    ctx.strokeStyle = variant === 'A' ? '#66E3CB' : '#E8BE78';
    ctx.lineWidth = 3;
    ctx.strokeRect(28, 28, 584, 324);
    ctx.fillStyle = '#17212C';
    ctx.fillRect(60, 80, 220, 180);
    ctx.fillRect(340, 80, 220, 180);
    ctx.fillStyle = variant === 'A' ? '#66E3CB' : '#E8BE78';
    ctx.font = 'bold 16px monospace';
    ctx.fillText(
      `SIC INVERTER BOARD — REV-${variant} (${variant === 'A' ? '600V' : '800V'})`,
      60,
      60
    );
    ctx.fillStyle = '#F1F5F9';
    ctx.font = '13px monospace';
    ctx.fillText('PHASE LEG U4-U6: SOLDER WETTING OK', 75, 130);
    ctx.fillText(
      `CREEPAGE SLOT: ${variant === 'A' ? '6.0mm' : '8.5mm'} ISOLATION`,
      75,
      165
    );
    ctx.fillText(
      `HEATSINK SENSOR: ${variant === 'A' ? '64.2 C' : '49.1 C'}`,
      355,
      130
    );
    return canvas.toDataURL('image/png');
  };

  const handleImageFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    slot: 'primary' | 'secondary'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        if (slot === 'primary') setPrimaryImage(reader.result);
        else setSecondaryImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleVideoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVideoMimeType(file.type || 'video/mp4');
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setVideoBase64(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const toggleCamera = async () => {
    if (cameraActive) {
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      setCameraActive(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      streamRef.current = stream;
      setCameraActive(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      }, 60);
    } catch {
      setPrimaryImage(generateDiagnosticSampleImage('B'));
    }
  };

  const captureCameraSnapshot = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 380;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      setPrimaryImage(canvas.toDataURL('image/png'));
    }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraActive(false);
  };

  const runVisionAnalysis = async () => {
    const imgA = primaryImage || generateDiagnosticSampleImage('B');
    if (!primaryImage) setPrimaryImage(imgA);

    setIsProcessing(true);
    setErrorMsg(null);
    try {
      const imagesPayload = [{ base64: imgA, mimeType: 'image/png' }];
      if (activeTab === 'compare') {
        const imgB = secondaryImage || generateDiagnosticSampleImage('A');
        if (!secondaryImage) setSecondaryImage(imgB);
        imagesPayload.push({ base64: imgB, mimeType: 'image/png' });
      }

      const res = await fetch('/api/gemini/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          images: imagesPayload,
          question,
          mode: activeTab === 'compare' ? 'compare' : 'inspect'
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Vision inspection failed');

      const record: VisionAnalysisRecord = {
        analysisId: `vis_${Date.now()}`,
        title: data.title || 'Optical Engineering Inspection',
        question,
        resultSummary: data.resultSummary || 'Inspection complete.',
        uncertaintyNotes:
          data.uncertaintyNotes || 'Verify internal layers with non-optical instrumentation.',
        detectedElements: Array.isArray(data.detectedElements)
          ? data.detectedElements.slice(0, 10)
          : [],
        recommendedScenePreset: ['laboratory', 'classroom', 'observatory', 'solar_array'].includes(
          data.recommendedScenePreset
        )
          ? data.recommendedScenePreset
          : 'laboratory',
        createdAtLabel: 'Just now'
      };
      onSaveAnalysis(record);
      onLogActivity(`Completed gemini-4-argon vision inspection: ${record.title}`, 'vision');
    } catch (err: any) {
      setErrorMsg(err?.message || 'Vision analysis request failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  const runVideoUnderstanding = async () => {
    if (!videoBase64) {
      setErrorMsg('Please upload an MP4/WebM video file first.');
      return;
    }
    setIsProcessing(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/gemini/video-analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoBase64,
          mimeType: videoMimeType,
          question
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Video analysis failed');
      setVideoSummary(data.summary);
      onLogActivity('Executed gemini-4-argon video timeline analysis', 'vision');
    } catch (err: any) {
      setErrorMsg(err?.message || 'Video analysis failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  const runAnimateImageToVideo = async () => {
    const imgToAnimate = primaryImage || generateDiagnosticSampleImage('B');
    if (!primaryImage) setPrimaryImage(imgToAnimate);

    setIsProcessing(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/gemini/animate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: animatePrompt,
          imageBase64: imgToAnimate,
          imageMimeType: 'image/png',
          aspectRatio: animateAspectRatio
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Video animation failed');

      setGeneratedVideoUrl(`data:${data.mimeType || 'video/mp4'};base64,${data.videoBase64}`);
      onLogActivity(
        `Animated image into ${animateAspectRatio} video via gemini-omni-1.2-flash`,
        'vision'
      );
    } catch (err: any) {
      setErrorMsg(err?.message || 'Image-to-video synthesis failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Left Column: Visual Input & Mode Controls */}
      <div className="lg:col-span-7 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h1 className="text-base font-semibold text-slate-100">
              Vision Intelligence & Multimodal Studio
            </h1>
            <p className="text-xs text-slate-400">
              Image & Video understanding via <span className="font-mono text-[#66E3CB]">gemini-4-argon</span> ·
              Video synthesis via <span className="font-mono text-[#A9B8FF]">gemini-omni-1.2-flash</span>
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-[#0B0F14] p-1 rounded-lg border border-slate-800">
            {[
              { id: 'inspect', label: 'Inspect Image' },
              { id: 'compare', label: 'Compare 2 Images' },
              { id: 'video', label: 'Analyze Video' },
              { id: 'animate', label: 'Animate to Video' }
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-[#17212C] text-[#66E3CB]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Image / Camera Controls */}
        {activeTab !== 'video' && (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs font-medium text-slate-200 border border-slate-700 cursor-pointer">
                <Upload className="w-3.5 h-3.5 text-[#66E3CB]" />
                <span>Upload Primary Image</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageFileUpload(e, 'primary')}
                  className="hidden"
                />
              </label>

              {activeTab === 'compare' && (
                <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs font-medium text-slate-200 border border-slate-700 cursor-pointer">
                  <Layers className="w-3.5 h-3.5 text-[#A9B8FF]" />
                  <span>Upload Comparison Image B</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageFileUpload(e, 'secondary')}
                    className="hidden"
                  />
                </label>
              )}

              <button
                type="button"
                onClick={toggleCamera}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs font-medium text-[#66E3CB] border border-[#66E3CB]/30 cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>{cameraActive ? 'Stop Camera' : 'Camera Snapshot'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setPrimaryImage(generateDiagnosticSampleImage('B'));
                  if (activeTab === 'compare') {
                    setSecondaryImage(generateDiagnosticSampleImage('A'));
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#0B0F14] hover:bg-slate-900 text-xs text-slate-300 border border-slate-800 cursor-pointer"
              >
                <span>Load Rev-B PCB Sample</span>
              </button>
            </div>

            {cameraActive && (
              <div className="p-3 bg-[#0B0F14] border border-slate-800 rounded-xl flex items-center justify-between">
                <video
                  ref={videoRef}
                  className="w-64 h-36 rounded-lg bg-black object-cover border border-[#66E3CB]/40"
                  muted
                  playsInline
                />
                <button
                  type="button"
                  onClick={captureCameraSnapshot}
                  className="px-4 py-2 rounded-lg bg-[#66E3CB] text-[#0B0F14] text-xs font-semibold cursor-pointer"
                >
                  Capture Optical Frame
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {primaryImage && (
                <div className="bg-[#0B0F14] border border-slate-800 rounded-lg p-2">
                  <div className="text-[11px] text-slate-400 mb-1 font-mono">
                    Primary Frame (Input A)
                  </div>
                  <img
                    src={primaryImage}
                    alt="Primary inspection frame"
                    className="w-full h-44 object-contain rounded"
                  />
                </div>
              )}
              {activeTab === 'compare' && secondaryImage && (
                <div className="bg-[#0B0F14] border border-slate-800 rounded-lg p-2">
                  <div className="text-[11px] text-slate-400 mb-1 font-mono">
                    Comparison Frame (Input B)
                  </div>
                  <img
                    src={secondaryImage}
                    alt="Secondary comparison frame"
                    className="w-full h-44 object-contain rounded"
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* Video Upload Tab */}
        {activeTab === 'video' && (
          <div className="space-y-3">
            <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs font-medium text-slate-200 border border-slate-700 cursor-pointer">
              <Video className="w-4 h-4 text-[#A9B8FF]" />
              <span>Select Video File (MP4 / WebM) for gemini-4-argon Analysis</span>
              <input
                type="file"
                accept="video/*"
                onChange={handleVideoFileUpload}
                className="hidden"
              />
            </label>
            {videoBase64 && (
              <div className="text-xs text-[#66E3CB] font-mono">
                Video loaded ({videoMimeType}) — Ready for temporal inspection.
              </div>
            )}
          </div>
        )}

        {/* Prompt / Action Controls */}
        {activeTab === 'animate' ? (
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs text-slate-400 mb-1">
                  Motion & Camera Prompt (gemini-omni-1.2-flash)
                </label>
                <input
                  type="text"
                  value={animatePrompt}
                  onChange={(e) => setAnimatePrompt(e.target.value)}
                  className="w-full bg-[#17212C] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Aspect Ratio
                </label>
                <select
                  value={animateAspectRatio}
                  onChange={(e) => setAnimateAspectRatio(e.target.value as '16:9' | '9:16')}
                  className="w-full bg-[#17212C] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
                >
                  <option value="16:9">16:9 Landscape</option>
                  <option value="9:16">9:16 Vertical</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={runAnimateImageToVideo}
              disabled={isProcessing}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#A9B8FF] text-[#0B0F14] font-semibold text-xs hover:bg-[#93a5ff] disabled:opacity-40 cursor-pointer"
            >
              {isProcessing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Film className="w-4 h-4" />
              )}
              <span>Animate Image to Video (gemini-omni-1.2-flash)</span>
            </button>

            {generatedVideoUrl && (
              <div className="p-3 bg-[#0B0F14] border border-slate-800 rounded-xl space-y-2">
                <div className="text-xs font-medium text-[#66E3CB]">
                  Synthesized Video Stream ({animateAspectRatio})
                </div>
                <video
                  src={generatedVideoUrl}
                  controls
                  autoPlay
                  loop
                  className="w-full max-h-64 rounded-lg bg-black"
                />
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <div>
              <label className="block text-xs text-slate-400 mb-1">
                Inspection Question / Diagnostic Objective
              </label>
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="w-full bg-[#17212C] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
              />
            </div>

            <button
              type="button"
              onClick={activeTab === 'video' ? runVideoUnderstanding : runVisionAnalysis}
              disabled={isProcessing}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs hover:bg-[#52cdb5] disabled:opacity-40 cursor-pointer"
            >
              {isProcessing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>
                {activeTab === 'video'
                  ? 'Analyze Video with gemini-4-argon'
                  : activeTab === 'compare'
                  ? 'Run Differential Image Comparison (gemini-4-argon)'
                  : 'Run Structural Vision Inspection (gemini-4-argon)'}
              </span>
            </button>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 rounded-lg bg-red-950/50 border border-red-800 text-xs text-red-200">
            {errorMsg}
          </div>
        )}

        {videoSummary && (
          <div className="p-4 bg-[#0B0F14] border border-slate-800 rounded-xl space-y-2">
            <h3 className="text-xs font-semibold text-[#66E3CB]">
              Video Understanding Report (gemini-4-argon)
            </h3>
            <p className="text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
              {videoSummary}
            </p>
          </div>
        )}
      </div>

      {/* Right Column: Structured Inspection History & 3D World Reconstruction Bridge */}
      <div className="lg:col-span-5 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4 overflow-y-auto max-h-[calc(100vh-8.5rem)]">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 className="text-sm font-semibold text-slate-100">
            Verified Visual Inspection Records
          </h2>
          <span className="text-xs font-mono text-slate-400">
            {analyses.length} saved
          </span>
        </div>

        <div className="space-y-3">
          {analyses.map((item) => (
            <div
              key={item.analysisId}
              className="p-4 rounded-xl bg-[#0B0F14] border border-slate-800/90 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold text-slate-100">
                    {item.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {item.createdAtLabel} · Query: {item.question}
                  </p>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {item.resultSummary}
              </p>

              {item.detectedElements.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#66E3CB]" />
                    <span>Detected Components:</span>
                  </div>
                  <ul className="text-xs text-slate-300 list-disc list-inside space-y-0.5">
                    {item.detectedElements.map((el, i) => (
                      <li key={i}>{el}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="p-2.5 rounded-lg bg-[#17212C]/70 border border-[#E8BE78]/30 text-xs text-slate-300 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-[#E8BE78] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-[#E8BE78]">Iris Uncertainty Note:</strong>{' '}
                  {item.uncertaintyNotes}
                </div>
              </div>

              <div className="pt-1 flex justify-end">
                <button
                  type="button"
                  onClick={() =>
                    onReconstructIn3D(item.recommendedScenePreset, item.title)
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-slate-800 text-[#66E3CB] border border-[#66E3CB]/30 text-xs font-medium cursor-pointer"
                >
                  <Box className="w-3.5 h-3.5" />
                  <span>Reconstruct in 3D World Studio ({item.recommendedScenePreset})</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
