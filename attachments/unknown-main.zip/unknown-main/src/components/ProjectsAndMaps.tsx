import React, { useState, useEffect, useRef } from 'react';
import {
  APIProvider,
  Map as GoogleMap,
  AdvancedMarker,
  Pin
} from '@vis.gl/react-google-maps';
import {
  FolderGit2,
  Plus,
  MessageSquare,
  FileEdit,
  Users,
  CheckCircle2,
  ArrowUpDown,
  LayoutDashboard,
  MapPin,
  ExternalLink,
  Send,
  SlidersHorizontal,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  Loader2,
  CalendarRange
} from 'lucide-react';
import {
  sortAndFilterProjectTasks,
  computeProjectDashboardMetrics,
  type ProjectTask,
  type TaskPriority,
  type TaskStatus,
  type DashboardWidgetConfig
} from '../utils/lorinLogic';
import type { ProjectRecord } from '../data/seedData';
import { ProjectGanttTimeline } from './ProjectGanttTimeline';
import { TaskDragBoard } from './TaskDragBoard';

interface ProjectsAndMapsProps {
  projects: ProjectRecord[];
  onCreateProject: (proj: ProjectRecord) => void;
  onUpdateProjectStatus: (
    projectId: string,
    status: ProjectRecord['status']
  ) => void;
  currentUserName: string;
  onLogActivity: (operation: string, module: 'workspace') => void;
}

const DEFAULT_WIDGETS: DashboardWidgetConfig[] = [
  { widgetId: 'project_health', title: 'Overall Project Health & Status', visible: true, order: 1 },
  { widgetId: 'completion_rate', title: 'Task Completion Rate', visible: true, order: 2 },
  { widgetId: 'priority_breakdown', title: 'Task Priority Distribution', visible: true, order: 3 },
  { widgetId: 'task_board', title: 'Drag-and-Drop Task Board', visible: true, order: 4 },
  { widgetId: 'gantt_timeline', title: 'Project Gantt Timeline', visible: true, order: 5 },
  { widgetId: 'assigned_workloads', title: 'Assigned Team Workloads', visible: true, order: 6 },
  { widgetId: 'upcoming_milestones', title: 'Upcoming Milestones & Tasks', visible: true, order: 7 },
  { widgetId: 'shared_doc', title: 'Live Collaborative Specification Editor', visible: true, order: 8 },
  { widgetId: 'team_chat', title: 'In-App Team Messaging Channel', visible: true, order: 9 }
];

export const ProjectsAndMaps: React.FC<ProjectsAndMapsProps> = ({
  projects,
  onCreateProject,
  onUpdateProjectStatus,
  currentUserName,
  onLogActivity
}) => {
  const [selectedProjectId, setSelectedProjectId] = useState<string>(
    projects[0]?.projectId || 'proj_lorin_core'
  );
  const [activeSubView, setActiveSubView] = useState<
    'dashboard' | 'tasks_collab' | 'gantt_timeline' | 'spatial_maps'
  >('dashboard');

  // Customizable Dashboard Widgets State
  const [widgets, setWidgets] = useState<DashboardWidgetConfig[]>(DEFAULT_WIDGETS);
  const [showWidgetCustomizer, setShowWidgetCustomizer] = useState(false);

  // Real-Time WebSocket (/collab) State
  const [wsConnected, setWsConnected] = useState(false);
  const [participants, setParticipants] = useState<
    Array<{ userId: string; name: string; color: string }>
  >([]);
  const [sharedDocument, setSharedDocument] = useState<string>(
    '# Shared Engineering Specification\nConnecting to real-time collaboration server...'
  );
  const [tasks, setTasks] = useState<ProjectTask[]>([]);
  const [teamMessages, setTeamMessages] = useState<
    Array<{
      id: string;
      projectId: string;
      senderName: string;
      roleLabel: string;
      content: string;
      timestampLabel: string;
    }>
  >([]);

  // Task Prioritization Filter & Sort State
  const [priorityFilter, setPriorityFilter] = useState<'ALL' | TaskPriority>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | TaskStatus>('ALL');
  const [sortBy, setSortBy] = useState<'manual' | 'priority_desc' | 'priority_asc' | 'status' | 'due_date'>(
    'priority_desc'
  );
  const [activeCommentTaskId, setActiveCommentTaskId] = useState<string | null>(null);
  const [newCommentDraft, setNewCommentDraft] = useState('');

  // New Task Form State
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskAssignee, setNewTaskAssignee] = useState('Nolan (Strategist)');
  const [newTaskPriority, setNewTaskPriority] = useState<TaskPriority>('High');
  const [newTaskMilestone, setNewTaskMilestone] = useState('Phase 2 — Core Delivery');
  const [newTaskStartDate, setNewTaskStartDate] = useState('2026-11-20');
  const [newTaskDueDate, setNewTaskDueDate] = useState('2026-11-26');
  const [newTaskHours, setNewTaskHours] = useState(4);

  // In-App Team Messaging Draft
  const [teamChatDraft, setTeamChatDraft] = useState('');

  // New Project Modal
  const [showNewProjectForm, setShowNewProjectForm] = useState(false);
  const [newProjName, setNewProjName] = useState('');
  const [newProjDesc, setNewProjDesc] = useState('');

  // Google Maps Grounding State
  const [mapsQuery, setMapsQuery] = useState(
    'Research laboratories, robotics hubs, and renewable energy sites near Palo Alto, CA'
  );
  const [mapsLoading, setMapsLoading] = useState(false);
  const [mapsSummary, setMapsSummary] = useState<string | null>(null);
  const [mapsLinks, setMapsLinks] = useState<
    Array<{ title: string; uri: string; sourceType: string }>
  >([]);
  const [selectedCoordinates, setSelectedCoordinates] = useState<{
    lat: number;
    lng: number;
    label: string;
  }>({
    lat: 37.4419,
    lng: -122.143,
    label: 'LORIN Spatial Telemetry Reference — Palo Alto Research Sector'
  });

  const collabWsRef = useRef<WebSocket | null>(null);

  // Connect to Real-Time Collaboration Server (/collab)
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}/collab`);
    collabWsRef.current = ws;

    ws.onopen = () => {
      setWsConnected(true);
      ws.send(
        JSON.stringify({
          type: 'collab:join',
          projectId: selectedProjectId,
          userId: `user_${currentUserName.replace(/\s+/g, '_').toLowerCase()}`,
          userName: currentUserName,
          color: '#66E3CB'
        })
      );
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'collab:init') {
          setSharedDocument(msg.sharedDocument || '');
          setTasks(Array.isArray(msg.tasks) ? msg.tasks : []);
          setTeamMessages(Array.isArray(msg.teamMessages) ? msg.teamMessages : []);
          setParticipants(Array.isArray(msg.participants) ? msg.participants : []);
        } else if (msg.type === 'collab:presence') {
          setParticipants(Array.isArray(msg.participants) ? msg.participants : []);
        } else if (msg.type === 'collab:doc:updated') {
          setSharedDocument(msg.content || '');
        } else if (msg.type === 'collab:tasks:synced') {
          setTasks(Array.isArray(msg.tasks) ? msg.tasks : []);
        } else if (msg.type === 'collab:chat:Added' && msg.message) {
          setTeamMessages((prev) => {
            if (prev.some((m) => m.id === msg.message.id)) return prev;
            return [...prev, msg.message];
          });
        }
      } catch {
        // Ignore malformed socket message
      }
    };

    ws.onclose = () => {
      setWsConnected(false);
    };

    return () => {
      ws.close();
    };
  }, [selectedProjectId, currentUserName]);

  const activeProject =
    projects.find((p) => p.projectId === selectedProjectId) || projects[0];

  const sortedTasks = sortAndFilterProjectTasks(tasks, {
    priorityFilter,
    statusFilter,
    sortBy
  });

  const dashboardMetrics = computeProjectDashboardMetrics(tasks);

  const visibleWidgets = [...widgets]
    .filter((w) => w.visible)
    .sort((a, b) => a.order - b.order);

  // Real-time Shared Document Edit Handler
  const handleSharedDocChange = (nextContent: string) => {
    setSharedDocument(nextContent);
    if (collabWsRef.current?.readyState === WebSocket.OPEN) {
      collabWsRef.current.send(
        JSON.stringify({
          type: 'collab:doc:update',
          content: nextContent,
          updatedBy: currentUserName
        })
      );
    }
  };

  // Create Prioritized Task with Schedule Dates
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    const safeStart = newTaskStartDate || '2026-11-20';
    const safeDue =
      newTaskDueDate && newTaskDueDate >= safeStart ? newTaskDueDate : safeStart;
    const created: ProjectTask = {
      taskId: `task_${Date.now()}`,
      projectId: selectedProjectId,
      title: newTaskTitle.trim(),
      assignee: newTaskAssignee,
      priority: newTaskPriority,
      status: 'todo',
      milestone: newTaskMilestone,
      startDate: safeStart,
      dueDate: safeDue,
      dueDateLabel: `Due ${safeDue.slice(5)}`,
      estimatedHours: Number(newTaskHours) || 4,
      order: tasks.length,
      comments: []
    };
    setTasks((prev) => [...prev, created]);
    if (collabWsRef.current?.readyState === WebSocket.OPEN) {
      collabWsRef.current.send(
        JSON.stringify({
          type: 'collab:task:create',
          task: created
        })
      );
    }
    setNewTaskTitle('');
    onLogActivity(
      `Created ${created.priority}-priority task "${created.title}" (${safeStart} → ${safeDue})`,
      'workspace'
    );
  };

  // Update Task Priority, Status, or Schedule Dates
  const handleUpdateTaskField = (
    taskId: string,
    updates: Partial<
      Pick<ProjectTask, 'priority' | 'status' | 'startDate' | 'dueDate' | 'dueDateLabel'>
    >
  ) => {
    setTasks((prev) =>
      prev.map((t) => (t.taskId === taskId ? { ...t, ...updates } : t))
    );
    if (collabWsRef.current?.readyState === WebSocket.OPEN) {
      collabWsRef.current.send(
        JSON.stringify({
          type: 'collab:task:update',
          taskId,
          updates
        })
      );
    }
  };

  // Reorder or Move Tasks across Status Columns / Priority Tiers via Drag-and-Drop
  const handleReorderOrMoveTasks = (nextTasks: ProjectTask[], summary: string) => {
    setTasks(nextTasks);
    if (collabWsRef.current?.readyState === WebSocket.OPEN) {
      collabWsRef.current.send(
        JSON.stringify({
          type: 'collab:tasks:reorder',
          tasks: nextTasks.map((t) => ({
            taskId: t.taskId,
            status: t.status,
            priority: t.priority,
            order: t.order ?? 0
          }))
        })
      );
    }
    onLogActivity(summary, 'workspace');
  };

  // Add Task-Specific Comment
  const handleAddTaskComment = (e: React.FormEvent, taskId: string) => {
    e.preventDefault();
    if (!newCommentDraft.trim()) return;
    const comment = {
      commentId: `cmt_${Date.now()}`,
      taskId,
      authorName: currentUserName,
      content: newCommentDraft.trim(),
      createdAtLabel: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
    setTasks((prev) =>
      prev.map((t) =>
        t.taskId === taskId ? { ...t, comments: [...t.comments, comment] } : t
      )
    );
    if (collabWsRef.current?.readyState === WebSocket.OPEN) {
      collabWsRef.current.send(
        JSON.stringify({
          type: 'collab:comment:create',
          taskId,
          comment
        })
      );
    }
    setNewCommentDraft('');
  };

  // Send In-App Team Chat Message
  const handleSendTeamChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teamChatDraft.trim()) return;
    const msg = {
      id: `tm_${Date.now()}`,
      projectId: selectedProjectId,
      senderName: currentUserName,
      roleLabel: 'Project Lead',
      content: teamChatDraft.trim(),
      timestampLabel: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
    setTeamMessages((prev) => [...prev, msg]);
    if (collabWsRef.current?.readyState === WebSocket.OPEN) {
      collabWsRef.current.send(
        JSON.stringify({
          type: 'collab:chat:message',
          message: msg
        })
      );
    }
    setTeamChatDraft('');
  };

  // Dashboard Widget Customizer Controls
  const toggleWidgetVisibility = (widgetId: DashboardWidgetConfig['widgetId']) => {
    setWidgets((prev) =>
      prev.map((w) => (w.widgetId === widgetId ? { ...w, visible: !w.visible } : w))
    );
  };

  const moveWidgetOrder = (
    widgetId: DashboardWidgetConfig['widgetId'],
    direction: 'up' | 'down'
  ) => {
    setWidgets((prev) => {
      const sorted = [...prev].sort((a, b) => a.order - b.order);
      const idx = sorted.findIndex((w) => w.widgetId === widgetId);
      if (idx === -1) return prev;
      const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
      if (swapIdx < 0 || swapIdx >= sorted.length) return prev;
      const tempOrder = sorted[idx].order;
      sorted[idx] = { ...sorted[idx], order: sorted[swapIdx].order };
      sorted[swapIdx] = { ...sorted[swapIdx], order: tempOrder };
      return sorted;
    });
  };

  const handleCreateNewProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjName.trim()) return;
    const created: ProjectRecord = {
      projectId: `proj_${Date.now()}`,
      ownerId: 'local_owner',
      name: newProjName.trim().slice(0, 120),
      description:
        newProjDesc.trim().slice(0, 2000) ||
        'Engineering project workspace with real-time task prioritization.',
      status: 'active',
      objectives: ['Define milestone deliverables', 'Assign task priorities'],
      updatedAtLabel: 'Created just now'
    };
    onCreateProject(created);
    setSelectedProjectId(created.projectId);
    setNewProjName('');
    setNewProjDesc('');
    setShowNewProjectForm(false);
  };

  const handleRunMapsGrounding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mapsQuery.trim() || mapsLoading) return;
    setMapsLoading(true);
    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: mapsQuery,
          model: 'gemini-3.8-flash',
          useMapsGrounding: true,
          latLng: {
            latitude: selectedCoordinates.lat,
            longitude: selectedCoordinates.lng
          }
        })
      });
      const data = await res.json();
      if (res.ok) {
        setMapsSummary(data.text);
        setMapsLinks(data.groundingLinks || []);
        onLogActivity('Executed Google Maps Grounding spatial query', 'workspace');
      }
    } finally {
      setMapsLoading(false);
    }
  };

  const clientMapsApiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

  return (
    <div className="space-y-5">
      {/* Top Project Bar & View Switcher */}
      <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <FolderGit2 className="w-5 h-5 text-[#66E3CB]" />
            <div>
              <h1 className="text-base font-semibold text-slate-100">
                Project Management, Real-Time Collaboration & Spatial Maps
              </h1>
              <p className="text-xs text-slate-400">
                Live WebSocket Sync:{' '}
                <span className="font-mono text-[#66E3CB]">
                  {wsConnected ? 'CONNECTED (/collab)' : 'RECONNECTING'}
                </span>{' '}
                · {participants.length} Active Session(s)
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value)}
              aria-label="Select Active Project"
              className="bg-[#0B0F14] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 w-full sm:w-auto max-w-full truncate"
            >
              {projects.map((p) => (
                <option key={p.projectId} value={p.projectId}>
                  {p.name} ({p.status})
                </option>
              ))}
            </select>

            {activeProject && activeProject.status !== 'Archived' && (
              <select
                value={activeProject.status}
                onChange={(e) =>
                  onUpdateProjectStatus(
                    activeProject.projectId,
                    e.target.value as ProjectRecord['status']
                  )
                }
                aria-label="Project Status"
                className="bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-2 text-xs text-[#A9B8FF]"
              >
                <option value="planning">Status: planning</option>
                <option value="active">Status: active</option>
                <option value="review">Status: review</option>
                <option value="Archived">Status: Archived (Lock)</option>
              </select>
            )}

            <button
              type="button"
              onClick={() => setShowNewProjectForm((prev) => !prev)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Project</span>
            </button>
          </div>
        </div>

        {/* Sub-Navigation Tabs + Customize Dashboard Toggle */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'dashboard', label: 'Customizable Project Dashboard', icon: LayoutDashboard },
              { id: 'gantt_timeline', label: 'Gantt Timeline', icon: CalendarRange },
              { id: 'tasks_collab', label: 'Task Prioritization & Live Collaboration', icon: Users },
              { id: 'spatial_maps', label: 'Google Maps Spatial Reconnaissance', icon: MapPin }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveSubView(tab.id as any)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                    activeSubView === tab.id
                      ? 'bg-[#17212C] text-[#66E3CB] border border-[#66E3CB]/40'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {activeSubView === 'dashboard' && (
            <button
              type="button"
              onClick={() => setShowWidgetCustomizer((prev) => !prev)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs text-[#A9B8FF] border border-slate-700 cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>
                {showWidgetCustomizer ? 'Close Widget Customizer' : 'Customize Dashboard Widgets'}
              </span>
            </button>
          )}
        </div>

        {showNewProjectForm && (
          <form
            onSubmit={handleCreateNewProject}
            className="p-4 bg-[#0B0F14] border border-slate-800 rounded-xl space-y-3"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={newProjName}
                onChange={(e) => setNewProjName(e.target.value)}
                placeholder="New Project Name (1..120 chars)"
                className="bg-[#17212C] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
                required
              />
              <input
                type="text"
                value={newProjDesc}
                onChange={(e) => setNewProjDesc(e.target.value)}
                placeholder="Project Description"
                className="bg-[#17212C] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowNewProjectForm(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs cursor-pointer"
              >
                Create Project
              </button>
            </div>
          </form>
        )}

        {/* Personalized Dashboard Widget Customizer Drawer */}
        {showWidgetCustomizer && activeSubView === 'dashboard' && (
          <div className="p-4 bg-[#0B0F14] border border-[#A9B8FF]/30 rounded-xl space-y-2.5">
            <div className="text-xs font-semibold text-[#A9B8FF]">
              Select & Arrange Personalized Dashboard Widgets
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {[...widgets]
                .sort((a, b) => a.order - b.order)
                .map((w) => (
                  <div
                    key={w.widgetId}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-[#17212C] border border-slate-700 text-xs"
                  >
                    <button
                      type="button"
                      onClick={() => toggleWidgetVisibility(w.widgetId)}
                      className="flex items-center gap-2 text-left text-slate-200 cursor-pointer"
                    >
                      {w.visible ? (
                        <Eye className="w-3.5 h-3.5 text-[#66E3CB]" />
                      ) : (
                        <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                      )}
                      <span className={w.visible ? 'text-slate-100' : 'text-slate-500 line-through'}>
                        {w.title}
                      </span>
                    </button>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => moveWidgetOrder(w.widgetId, 'up')}
                        title="Move widget up"
                        className="p-1 rounded bg-[#0B0F14] text-slate-400 hover:text-white cursor-pointer"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={() => moveWidgetOrder(w.widgetId, 'down')}
                        title="Move widget down"
                        className="p-1 rounded bg-[#0B0F14] text-slate-400 hover:text-white cursor-pointer"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>

      {/* SUBVIEW 1: CUSTOMIZABLE PROJECT DASHBOARD */}
      {activeSubView === 'dashboard' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-5">
          {visibleWidgets.map((widget) => {
            if (widget.widgetId === 'project_health') {
              return (
                <div
                  key={widget.widgetId}
                  className="lg:col-span-4 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-3"
                >
                  <div className="text-xs font-semibold text-slate-400">
                    {widget.title}
                  </div>
                  <div className="flex items-baseline justify-between">
                    <div className="text-3xl font-mono font-bold text-[#66E3CB]">
                      {dashboardMetrics.healthScore}/100
                    </div>
                    <span className="text-xs font-mono text-[#A9B8FF]">
                      {dashboardMetrics.healthStatus}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    {dashboardMetrics.highPriorityOpenCount} open High-priority task(s) ·
                    Project status: <strong className="text-slate-200">{activeProject?.status}</strong>
                  </p>
                </div>
              );
            }

            if (widget.widgetId === 'completion_rate') {
              return (
                <div
                  key={widget.widgetId}
                  className="lg:col-span-4 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-3"
                >
                  <div className="text-xs font-semibold text-slate-400">
                    {widget.title}
                  </div>
                  <div className="flex items-baseline justify-between">
                    <div className="text-3xl font-mono font-bold text-slate-100">
                      {dashboardMetrics.completionRatePercent}%
                    </div>
                    <span className="text-xs text-slate-400 font-mono">
                      {dashboardMetrics.completedTasks}/{dashboardMetrics.totalTasks} tasks done
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#66E3CB] transition-all"
                      style={{ width: `${dashboardMetrics.completionRatePercent}%` }}
                    />
                  </div>
                </div>
              );
            }

            if (widget.widgetId === 'priority_breakdown') {
              return (
                <div
                  key={widget.widgetId}
                  className="lg:col-span-4 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-3"
                >
                  <div className="text-xs font-semibold text-slate-400">
                    {widget.title}
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <div className="p-2.5 rounded-lg bg-[#0B0F14] border border-red-500/30">
                      <div className="text-[11px] text-red-300">High Priority</div>
                      <div className="text-xl font-mono font-bold text-slate-100">
                        {dashboardMetrics.priorityCounts.High}
                      </div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-[#0B0F14] border border-[#E8BE78]/30">
                      <div className="text-[11px] text-[#E8BE78]">Medium</div>
                      <div className="text-xl font-mono font-bold text-slate-100">
                        {dashboardMetrics.priorityCounts.Medium}
                      </div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-[#0B0F14] border border-[#66E3CB]/30">
                      <div className="text-[11px] text-[#66E3CB]">Low</div>
                      <div className="text-xl font-mono font-bold text-slate-100">
                        {dashboardMetrics.priorityCounts.Low}
                      </div>
                    </div>
                  </div>
                </div>
              );
            }

            if (widget.widgetId === 'task_board') {
              return (
                <div key={widget.widgetId} className="lg:col-span-12">
                  <TaskDragBoard
                    tasks={tasks}
                    onReorderOrMoveTasks={handleReorderOrMoveTasks}
                    onUpdateTaskField={handleUpdateTaskField}
                    onOpenComments={(taskId) => {
                      setActiveCommentTaskId(taskId);
                      setActiveSubView('tasks_collab');
                    }}
                  />
                </div>
              );
            }

            if (widget.widgetId === 'gantt_timeline') {
              return (
                <div key={widget.widgetId} className="lg:col-span-12">
                  <ProjectGanttTimeline
                    tasks={tasks}
                    onUpdateTask={handleUpdateTaskField}
                    compact
                  />
                </div>
              );
            }

            if (widget.widgetId === 'assigned_workloads') {
              return (
                <div
                  key={widget.widgetId}
                  className="lg:col-span-6 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-3"
                >
                  <div className="text-xs font-semibold text-slate-300">
                    {widget.title}
                  </div>
                  <div className="space-y-2">
                    {dashboardMetrics.workloadByAssignee.map((w) => (
                      <div
                        key={w.assignee}
                        className="flex items-center justify-between p-2.5 rounded-lg bg-[#0B0F14] border border-slate-800 text-xs"
                      >
                        <span className="font-medium text-slate-200">{w.assignee}</span>
                        <span className="font-mono text-[#A9B8FF]">
                          {w.taskCount} task(s) · {w.hours}h est.
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            }

            if (widget.widgetId === 'upcoming_milestones') {
              return (
                <div
                  key={widget.widgetId}
                  className="lg:col-span-6 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-300">
                      {widget.title}
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveSubView('tasks_collab')}
                      className="text-xs text-[#66E3CB] hover:underline cursor-pointer"
                    >
                      Manage All Priorities →
                    </button>
                  </div>
                  <div className="space-y-2">
                    {sortedTasks.slice(0, 4).map((t) => (
                      <div
                        key={t.taskId}
                        className="flex items-center justify-between p-2.5 rounded-lg bg-[#0B0F14] border border-slate-800 text-xs"
                      >
                        <div className="truncate pr-2">
                          <div className="font-medium text-slate-200 truncate">
                            {t.title}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {t.milestone} · {t.assignee}
                          </div>
                        </div>
                        <span
                          className={`font-mono text-[11px] font-semibold shrink-0 ${
                            t.priority === 'High'
                              ? 'text-red-400'
                              : t.priority === 'Medium'
                              ? 'text-[#E8BE78]'
                              : 'text-[#66E3CB]'
                          }`}
                        >
                          {t.priority}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            }

            if (widget.widgetId === 'shared_doc') {
              return (
                <div
                  key={widget.widgetId}
                  className="lg:col-span-7 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                      <FileEdit className="w-4 h-4 text-[#66E3CB]" />
                      <span>{widget.title}</span>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">
                      Synced via /collab WebSocket
                    </span>
                  </div>
                  <textarea
                    value={sharedDocument}
                    onChange={(e) => handleSharedDocChange(e.target.value)}
                    rows={7}
                    aria-label="Shared Collaborative Specification Editor"
                    className="w-full bg-[#0B0F14] border border-slate-800 rounded-lg p-3 font-mono text-xs text-slate-100 focus:outline-none focus:border-[#66E3CB]"
                  />
                </div>
              );
            }

            if (widget.widgetId === 'team_chat') {
              return (
                <div
                  key={widget.widgetId}
                  className="lg:col-span-5 bg-[#111821] border border-slate-800/80 rounded-xl p-5 flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                        <MessageSquare className="w-4 h-4 text-[#A9B8FF]" />
                        <span>{widget.title}</span>
                      </div>
                      <span className="text-[11px] text-slate-400">
                        {teamMessages.length} msgs
                      </span>
                    </div>

                    <div className="h-40 overflow-y-auto bg-[#0B0F14] border border-slate-800 rounded-lg p-3 space-y-2 text-xs">
                      {teamMessages.map((tm) => (
                        <div key={tm.id} className="space-y-0.5">
                          <div className="flex items-center justify-between text-[11px] text-slate-400">
                            <strong className="text-[#66E3CB]">{tm.senderName}</strong>
                            <span>{tm.timestampLabel}</span>
                          </div>
                          <p className="text-slate-200">{tm.content}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <form onSubmit={handleSendTeamChat} className="flex gap-2">
                    <input
                      type="text"
                      value={teamChatDraft}
                      onChange={(e) => setTeamChatDraft(e.target.value)}
                      placeholder="Message project team..."
                      className="flex-1 bg-[#17212C] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100"
                    />
                    <button
                      type="submit"
                      className="px-3 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>
              );
            }

            return null;
          })}
        </div>
      )}

      {/* SUBVIEW 2: TASK PRIORITIZATION, COMMENT THREADS & SHARED COLLABORATION */}
      {activeSubView === 'tasks_collab' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left 8 Columns: Task Prioritization Matrix & Task-Specific Comment Threads */}
          <div className="lg:col-span-8 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">
                  Project Task Prioritization & Comment Threads
                </h2>
                <p className="text-xs text-slate-400">
                  Set High / Medium / Low priorities, filter workloads, and collaborate inside task-specific threads
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs">
                <select
                  value={priorityFilter}
                  onChange={(e) => setPriorityFilter(e.target.value as any)}
                  aria-label="Filter by Task Priority"
                  className="bg-[#0B0F14] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
                >
                  <option value="ALL">All Priorities</option>
                  <option value="High">High Priority Only</option>
                  <option value="Medium">Medium Priority Only</option>
                  <option value="Low">Low Priority Only</option>
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  aria-label="Filter by Task Status"
                  className="bg-[#0B0F14] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="todo">To Do</option>
                  <option value="in_progress">In Progress</option>
                  <option value="done">Done</option>
                </select>

                <button
                  type="button"
                  onClick={() =>
                    setSortBy((prev) =>
                      prev === 'priority_desc' ? 'priority_asc' : 'priority_desc'
                    )
                  }
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#17212C] border border-slate-700 text-slate-200 cursor-pointer"
                >
                  <ArrowUpDown className="w-3.5 h-3.5 text-[#66E3CB]" />
                  <span>
                    Sort: {sortBy === 'priority_desc' ? 'High → Low' : 'Low → High'}
                  </span>
                </button>
              </div>
            </div>

            {/* Create Task Form with Priority, Assignee & Schedule Dates */}
            <form
              onSubmit={handleAddTask}
              className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 p-3.5 rounded-xl bg-[#0B0F14] border border-slate-800"
            >
              <input
                type="text"
                value={newTaskTitle}
                onChange={(e) => setNewTaskTitle(e.target.value)}
                placeholder="New engineering task title..."
                className="sm:col-span-6 bg-[#17212C] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100"
                required
              />
              <input
                type="text"
                value={newTaskAssignee}
                onChange={(e) => setNewTaskAssignee(e.target.value)}
                placeholder="Assignee"
                aria-label="New Task Assignee"
                className="sm:col-span-3 bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100"
              />
              <select
                value={newTaskPriority}
                onChange={(e) => setNewTaskPriority(e.target.value as TaskPriority)}
                aria-label="New Task Priority"
                className="sm:col-span-3 bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100"
              >
                <option value="High">Priority: High</option>
                <option value="Medium">Priority: Medium</option>
                <option value="Low">Priority: Low</option>
              </select>
              <label className="sm:col-span-4 flex items-center gap-2 bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-400">
                <span className="shrink-0">Start</span>
                <input
                  type="date"
                  value={newTaskStartDate}
                  onChange={(e) => setNewTaskStartDate(e.target.value)}
                  aria-label="Task Start Date"
                  className="w-full bg-transparent font-mono tabular-nums text-slate-100 focus:outline-none"
                />
              </label>
              <label className="sm:col-span-4 flex items-center gap-2 bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-400">
                <span className="shrink-0">Due</span>
                <input
                  type="date"
                  value={newTaskDueDate}
                  min={newTaskStartDate}
                  onChange={(e) => setNewTaskDueDate(e.target.value)}
                  aria-label="Task Due Date"
                  className="w-full bg-transparent font-mono tabular-nums text-slate-100 focus:outline-none"
                />
              </label>
              <button
                type="submit"
                className="sm:col-span-4 inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Scheduled Task</span>
              </button>
            </form>

            {/* Prioritized Task List */}
            <div className="space-y-3">
              {sortedTasks.map((task) => {
                const isCommentOpen = activeCommentTaskId === task.taskId;
                return (
                  <div
                    key={task.taskId}
                    className="p-4 rounded-xl bg-[#0B0F14] border border-slate-800/90 space-y-3"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="text-sm font-semibold text-slate-100">
                          {task.title}
                        </div>
                        <div className="text-xs text-slate-400 font-mono tabular-nums">
                          Assignee: <strong className="text-slate-200 font-sans">{task.assignee}</strong> ·
                          Schedule: {task.startDate || 'TBD'} → {task.dueDate || 'TBD'} · {task.estimatedHours}h
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {/* Priority Selector */}
                        <select
                          value={task.priority}
                          onChange={(e) =>
                            handleUpdateTaskField(task.taskId, {
                              priority: e.target.value as TaskPriority
                            })
                          }
                          aria-label={`Priority for ${task.title}`}
                          className={`rounded-lg px-2.5 py-1 text-xs font-mono font-semibold border cursor-pointer ${
                            task.priority === 'High'
                              ? 'bg-red-950/50 border-red-500/40 text-red-300'
                              : task.priority === 'Medium'
                              ? 'bg-[#E8BE78]/15 border-[#E8BE78]/40 text-[#E8BE78]'
                              : 'bg-[#66E3CB]/15 border-[#66E3CB]/40 text-[#66E3CB]'
                          }`}
                        >
                          <option value="High">Priority: High</option>
                          <option value="Medium">Priority: Medium</option>
                          <option value="Low">Priority: Low</option>
                        </select>

                        {/* Status Selector */}
                        <select
                          value={task.status}
                          onChange={(e) =>
                            handleUpdateTaskField(task.taskId, {
                              status: e.target.value as TaskStatus
                            })
                          }
                          aria-label={`Status for ${task.title}`}
                          className="bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 cursor-pointer"
                        >
                          <option value="todo">To Do</option>
                          <option value="in_progress">In Progress</option>
                          <option value="done">Done</option>
                        </select>

                        {/* Comment Thread Toggle */}
                        <button
                          type="button"
                          onClick={() =>
                            setActiveCommentTaskId(isCommentOpen ? null : task.taskId)
                          }
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs text-[#A9B8FF] border border-slate-700 cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Comments ({task.comments.length})</span>
                        </button>
                      </div>
                    </div>

                    {/* Task-Specific Comment Thread */}
                    {isCommentOpen && (
                      <div className="pt-3 border-t border-slate-800 space-y-2.5">
                        <div className="space-y-1.5 max-h-40 overflow-y-auto">
                          {task.comments.length === 0 ? (
                            <div className="text-xs text-slate-500">
                              No comments on this task yet. Start the thread below.
                            </div>
                          ) : (
                            task.comments.map((c) => (
                              <div
                                key={c.commentId}
                                className="p-2.5 rounded-lg bg-[#17212C]/70 text-xs space-y-0.5"
                              >
                                <div className="flex items-center justify-between text-[11px] text-slate-400">
                                  <strong className="text-[#66E3CB]">
                                    {c.authorName}
                                  </strong>
                                  <span>{c.createdAtLabel}</span>
                                </div>
                                <div className="text-slate-200">{c.content}</div>
                              </div>
                            ))
                          )}
                        </div>

                        <form
                          onSubmit={(e) => handleAddTaskComment(e, task.taskId)}
                          className="flex gap-2"
                        >
                          <input
                            type="text"
                            value={newCommentDraft}
                            onChange={(e) => setNewCommentDraft(e.target.value)}
                            placeholder="Add a task-specific comment..."
                            className="flex-1 bg-[#17212C] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100"
                          />
                          <button
                            type="submit"
                            className="px-3 py-1.5 rounded-lg bg-[#A9B8FF] text-[#0B0F14] font-semibold text-xs cursor-pointer"
                          >
                            Post Comment
                          </button>
                        </form>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right 4 Columns: Shared Document & Team Messaging */}
          <div className="lg:col-span-4 space-y-5">
            <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <FileEdit className="w-3.5 h-3.5 text-[#66E3CB]" />
                  <span>Shared Live Specification</span>
                </h3>
                <span className="text-[11px] font-mono text-[#66E3CB]">Live Sync</span>
              </div>
              <textarea
                value={sharedDocument}
                onChange={(e) => handleSharedDocChange(e.target.value)}
                rows={8}
                className="w-full bg-[#0B0F14] border border-slate-800 rounded-lg p-3 font-mono text-xs text-slate-100"
              />
            </div>

            <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-4 space-y-3">
              <h3 className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-[#A9B8FF]" />
                <span>In-App Team Messaging</span>
              </h3>
              <div className="h-48 overflow-y-auto bg-[#0B0F14] border border-slate-800 rounded-lg p-3 space-y-2 text-xs">
                {teamMessages.map((tm) => (
                  <div key={tm.id} className="space-y-0.5">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <strong className="text-[#66E3CB]">{tm.senderName}</strong>
                      <span>{tm.timestampLabel}</span>
                    </div>
                    <p className="text-slate-200">{tm.content}</p>
                  </div>
                ))}
              </div>
              <form onSubmit={handleSendTeamChat} className="flex gap-2">
                <input
                  type="text"
                  value={teamChatDraft}
                  onChange={(e) => setTeamChatDraft(e.target.value)}
                  placeholder="Send message to project team..."
                  className="flex-1 bg-[#17212C] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs cursor-pointer"
                >
                  Send
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* SUBVIEW 2B: DEDICATED GANTT TIMELINE & SCHEDULE VIEW */}
      {activeSubView === 'gantt_timeline' && (
        <div className="space-y-5">
          <ProjectGanttTimeline
            tasks={tasks}
            onUpdateTask={handleUpdateTaskField}
          />
          <TaskDragBoard
            tasks={tasks}
            onReorderOrMoveTasks={handleReorderOrMoveTasks}
            onUpdateTaskField={handleUpdateTaskField}
            onOpenComments={(taskId) => {
              setActiveCommentTaskId(taskId);
              setActiveSubView('tasks_collab');
            }}
          />
        </div>
      )}

      {/* SUBVIEW 3: GOOGLE MAPS PLATFORM SPATIAL EXPLORER & MAPS GROUNDING */}
      {activeSubView === 'spatial_maps' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-slate-100">
                  Google Maps Platform Spatial Explorer
                </h2>
                <p className="text-xs text-slate-400">
                  Coordinates: {selectedCoordinates.lat.toFixed(4)}° N,{' '}
                  {selectedCoordinates.lng.toFixed(4)}° W
                </p>
              </div>
              <div className="flex gap-1.5">
                {[
                  { label: 'Palo Alto Lab', lat: 37.4419, lng: -122.143 },
                  { label: 'MIT Robotics', lat: 42.3601, lng: -71.0942 },
                  { label: 'ETH Zurich', lat: 47.3769, lng: 8.5417 }
                ].map((loc) => (
                  <button
                    key={loc.label}
                    type="button"
                    onClick={() =>
                      setSelectedCoordinates({
                        lat: loc.lat,
                        lng: loc.lng,
                        label: loc.label
                      })
                    }
                    className="px-2.5 py-1 rounded bg-[#17212C] hover:bg-slate-800 text-xs text-slate-200 border border-slate-700 cursor-pointer"
                  >
                    {loc.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="h-80 rounded-xl overflow-hidden border border-slate-800 bg-[#0B0F14]">
              {clientMapsApiKey ? (
                <APIProvider apiKey={clientMapsApiKey}>
                  <GoogleMap
                    defaultZoom={13}
                    center={{
                      lat: selectedCoordinates.lat,
                      lng: selectedCoordinates.lng
                    }}
                    mapId="DEMO_MAP_ID"
                    internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                    style={{ width: '100%', height: '100%' }}
                  >
                    <AdvancedMarker
                      position={{
                        lat: selectedCoordinates.lat,
                        lng: selectedCoordinates.lng
                      }}
                    >
                      <Pin
                        background="#66E3CB"
                        borderColor="#0B0F14"
                        glyphColor="#0B0F14"
                      />
                    </AdvancedMarker>
                  </GoogleMap>
                </APIProvider>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center space-y-2">
                  <MapPin className="w-8 h-8 text-[#66E3CB]" />
                  <div className="text-sm font-semibold text-slate-100">
                    {selectedCoordinates.label}
                  </div>
                  <div className="text-xs font-mono text-[#A9B8FF]">
                    LAT {selectedCoordinates.lat.toFixed(4)} · LNG{' '}
                    {selectedCoordinates.lng.toFixed(4)}
                  </div>
                  <p className="text-xs text-slate-400 max-w-md">
                    Configure <code className="text-[#66E3CB]">VITE_GOOGLE_MAPS_API_KEY</code> in
                    the Google Maps Settings Panel to enable interactive client-side vector tiles,
                    or run a server-side Gemini Maps Grounding query on the right.
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-5 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-100">
              Gemini Google Maps Grounding (gemini-3.8-flash)
            </h3>
            <form onSubmit={handleRunMapsGrounding} className="space-y-2.5">
              <textarea
                value={mapsQuery}
                onChange={(e) => setMapsQuery(e.target.value)}
                rows={3}
                className="w-full bg-[#0B0F14] border border-slate-800 rounded-lg p-3 text-xs text-slate-100"
              />
              <button
                type="submit"
                disabled={mapsLoading}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs cursor-pointer"
              >
                {mapsLoading ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <MapPin className="w-3.5 h-3.5" />
                )}
                <span>Run Grounded Spatial Reconnaissance</span>
              </button>
            </form>

            {mapsSummary && (
              <div className="p-3.5 rounded-lg bg-[#0B0F14] border border-slate-800 space-y-2 text-xs">
                <div className="text-slate-200 whitespace-pre-wrap leading-relaxed">
                  {mapsSummary}
                </div>
                {mapsLinks.length > 0 && (
                  <div className="pt-2 border-t border-slate-800 flex flex-wrap gap-2">
                    {mapsLinks.map((l, idx) => (
                      <a
                        key={idx}
                        href={l.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[#A9B8FF] hover:text-[#66E3CB] underline"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>{l.title}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
