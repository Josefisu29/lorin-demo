import React, { useState } from 'react';
import {
  FileText,
  Upload,
  Search,
  GitCompare,
  HardDrive,
  CheckCircle2,
  AlertCircle,
  GraduationCap,
  Trash2,
  Download,
  Share2
} from 'lucide-react';
import {
  chunkDocumentText,
  retrieveRelevantChunks,
  compareDocuments
} from '../utils/lorinLogic';
import {
  getCachedDriveToken,
  refreshDriveTokenInteractive
} from '../lib/firebase';
import type { KnowledgeDocumentRecord } from '../data/seedData';

interface KnowledgeVaultProps {
  documents: KnowledgeDocumentRecord[];
  onAddDocument: (doc: KnowledgeDocumentRecord) => void;
  onDeleteDocument: (documentId: string) => void;
  onGenerateCourseFromDoc: (doc: KnowledgeDocumentRecord) => void;
  onLogActivity: (operation: string, module: 'vault' | 'integrations') => void;
}

interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime?: string;
}

export const KnowledgeVault: React.FC<KnowledgeVaultProps> = ({
  documents,
  onAddDocument,
  onDeleteDocument,
  onGenerateCourseFromDoc,
  onLogActivity
}) => {
  const [selectedDocId, setSelectedDocId] = useState<string>(
    documents[0]?.documentId || ''
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [compareDocAId, setCompareDocAId] = useState<string>(
    documents[0]?.documentId || ''
  );
  const [compareDocBId, setCompareDocBId] = useState<string>(
    documents[1]?.documentId || documents[0]?.documentId || ''
  );
  const [showComparePanel, setShowComparePanel] = useState(false);

  // New Document Modal / Form
  const [newFilename, setNewFilename] = useState('');
  const [newCollection, setNewCollection] = useState('Core Architecture');
  const [newContent, setNewContent] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // Google Drive Integration State
  const [driveFiles, setDriveFiles] = useState<DriveFileItem[]>([]);
  const [driveLoading, setDriveLoading] = useState(false);
  const [driveStatusMsg, setDriveStatusMsg] = useState<string | null>(null);
  const [pendingExportDoc, setPendingExportDoc] =
    useState<KnowledgeDocumentRecord | null>(null);

  const selectedDoc =
    documents.find((d) => d.documentId === selectedDocId) || documents[0];

  const allChunks = documents.flatMap((d) =>
    chunkDocumentText(d.documentId, d.filename, d.extractedText)
  );

  const searchHits = searchQuery.trim()
    ? retrieveRelevantChunks(searchQuery, allChunks, 5)
    : [];

  const selectedDocChunks = selectedDoc
    ? chunkDocumentText(
        selectedDoc.documentId,
        selectedDoc.filename,
        selectedDoc.extractedText
      )
    : [];

  const docA = documents.find((d) => d.documentId === compareDocAId) || documents[0];
  const docB = documents.find((d) => d.documentId === compareDocBId) || documents[1] || documents[0];
  const comparisonResult =
    docA && docB
      ? compareDocuments(
          docA.filename,
          docA.extractedText,
          docB.filename,
          docB.extractedText
        )
      : null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = typeof reader.result === 'string' ? reader.result : '';
      const newDoc: KnowledgeDocumentRecord = {
        documentId: `doc_${Date.now()}`,
        filename: file.name.slice(0, 200),
        format: file.name.split('.').pop()?.toUpperCase() || 'TXT',
        size: file.size,
        collectionName: 'Uploaded Specifications',
        processingStatus: 'Indexed',
        extractedText: text.slice(0, 50000) || `Indexed file: ${file.name}`,
        tags: ['uploaded', 'rag-indexed'],
        updatedAtLabel: 'Indexed just now'
      };
      onAddDocument(newDoc);
      setSelectedDocId(newDoc.documentId);
      onLogActivity(`Indexed document "${newDoc.filename}" into Knowledge Vault`, 'vault');
    };
    reader.readAsText(file);
  };

  const handleCreateCustomDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFilename.trim() || !newContent.trim()) return;
    const newDoc: KnowledgeDocumentRecord = {
      documentId: `doc_${Date.now()}`,
      filename: newFilename.trim().slice(0, 200),
      format: 'Markdown',
      size: newContent.length,
      collectionName: newCollection.trim() || 'Core Architecture',
      processingStatus: 'Indexed',
      extractedText: newContent.trim().slice(0, 50000),
      tags: ['custom', 'verified'],
      updatedAtLabel: 'Indexed just now'
    };
    onAddDocument(newDoc);
    setSelectedDocId(newDoc.documentId);
    setNewFilename('');
    setNewContent('');
    setShowAddForm(false);
    onLogActivity(`Created & indexed "${newDoc.filename}"`, 'vault');
  };

  // Google Drive Read-Only File Listing
  const handleBrowseGoogleDrive = async () => {
    setDriveLoading(true);
    setDriveStatusMsg(null);
    try {
      let token = getCachedDriveToken();
      if (!token) {
        token = await refreshDriveTokenInteractive();
      }
      if (!token) {
        throw new Error('Google Drive authorization required. Sign in with Google first.');
      }

      const params = new URLSearchParams({
        pageSize: '8',
        fields: 'files(id,name,mimeType,modifiedTime)',
        q: 'trashed = false'
      });

      const response = await fetch(
        `https://www.googleapis.com/drive/v3/files?${params.toString()}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error?.message || 'Failed to list Google Drive files');
      }
      setDriveFiles(data.files || []);
      setDriveStatusMsg(`Loaded ${(data.files || []).length} files from Google Drive.`);
      onLogActivity('Listed files from Google Drive (drive.readonly)', 'integrations');
    } catch (err: any) {
      setDriveStatusMsg(err?.message || 'Unable to connect to Google Drive.');
    } finally {
      setDriveLoading(false);
    }
  };

  // Import text/doc from Google Drive into Knowledge Vault
  const handleImportDriveFile = async (file: DriveFileItem) => {
    setDriveLoading(true);
    setDriveStatusMsg(null);
    try {
      const token = getCachedDriveToken() || (await refreshDriveTokenInteractive());
      if (!token) throw new Error('Missing Google Drive token.');

      const isGoogleDoc = file.mimeType.startsWith('application/vnd.google-apps.');
      const endpoint = isGoogleDoc
        ? `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/plain`
        : `https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`;

      const res = await fetch(endpoint, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const text = await res.text();
      if (!res.ok) throw new Error('Could not read file content from Google Drive.');

      const imported: KnowledgeDocumentRecord = {
        documentId: `doc_drive_${Date.now()}`,
        filename: file.name.slice(0, 200),
        format: 'Drive Import',
        size: text.length,
        collectionName: 'Google Drive Sync',
        processingStatus: 'Indexed',
        extractedText: text.slice(0, 50000),
        tags: ['google-drive', 'imported'],
        updatedAtLabel: 'Imported just now'
      };
      onAddDocument(imported);
      setSelectedDocId(imported.documentId);
      setDriveStatusMsg(`Imported "${file.name}" into Knowledge Vault.`);
      onLogActivity(`Imported "${file.name}" from Google Drive`, 'integrations');
    } catch (err: any) {
      setDriveStatusMsg(err?.message || 'Drive import failed.');
    } finally {
      setDriveLoading(false);
    }
  };

  // Confirmed Export to Google Drive (drive.file)
  const executeConfirmedDriveExport = async () => {
    if (!pendingExportDoc) return;
    const docToExport = pendingExportDoc;
    setPendingExportDoc(null);
    setDriveLoading(true);
    setDriveStatusMsg(null);

    try {
      const token = getCachedDriveToken() || (await refreshDriveTokenInteractive());
      if (!token) throw new Error('Google Drive access token unavailable.');

      const metadata = {
        name: docToExport.filename,
        mimeType: 'text/markdown'
      };
      const form = new FormData();
      form.append(
        'metadata',
        new Blob([JSON.stringify(metadata)], { type: 'application/json' })
      );
      form.append(
        'file',
        new Blob([docToExport.extractedText], { type: 'text/markdown' })
      );

      const res = await fetch(
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: form
        }
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error?.message || 'Drive export failed');

      setDriveStatusMsg(`Exported "${data.name}" to Google Drive successfully.`);
      onLogActivity(`Exported "${docToExport.filename}" to Google Drive`, 'integrations');
    } catch (err: any) {
      setDriveStatusMsg(err?.message || 'Drive export failed.');
    } finally {
      setDriveLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Bar: Semantic Search, Upload, Diff Comparison & Google Drive Controls */}
      <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-base font-semibold text-slate-100">
              Knowledge Vault AI & RAG Citation Engine
            </h1>
            <p className="text-xs text-slate-400">
              Deterministic document chunking, passage-level citation retrieval, cross-version diffing, and Google Drive sync
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs hover:bg-[#52cdb5] cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload File (MD/TXT/JSON/CSV)</span>
              <input
                type="file"
                accept=".md,.txt,.json,.csv,.ts,.js,.py"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            <button
              type="button"
              onClick={() => setShowAddForm((prev) => !prev)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs font-medium text-slate-200 border border-slate-700 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-[#A9B8FF]" />
              <span>Create Specification Note</span>
            </button>

            <button
              type="button"
              onClick={() => setShowComparePanel((prev) => !prev)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs font-medium text-[#E8BE78] border border-[#E8BE78]/30 cursor-pointer"
            >
              <GitCompare className="w-3.5 h-3.5" />
              <span>{showComparePanel ? 'Hide Diff Engine' : 'Compare 2 Documents'}</span>
            </button>

            <button
              type="button"
              onClick={handleBrowseGoogleDrive}
              disabled={driveLoading}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#17212C] hover:bg-slate-800 text-xs font-medium text-[#66E3CB] border border-[#66E3CB]/30 cursor-pointer"
            >
              <HardDrive className="w-3.5 h-3.5" />
              <span>{driveLoading ? 'Syncing Drive...' : 'Browse Google Drive'}</span>
            </button>
          </div>
        </div>

        {/* Semantic Retrieval Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Test RAG passage retrieval across all indexed documents (e.g., 'What is the heatsink derating threshold at 72°C?')..."
            className="w-full bg-[#0B0F14] border border-slate-800 rounded-lg pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#66E3CB]"
          />
        </div>

        {/* Live Retrieval Results */}
        {searchQuery.trim() && (
          <div className="p-4 bg-[#0B0F14] border border-slate-800 rounded-xl space-y-2.5">
            <div className="text-xs font-semibold text-[#66E3CB]">
              Top Retrieved RAG Passages ({searchHits.length} matches)
            </div>
            {searchHits.length === 0 ? (
              <div className="text-xs text-slate-400">
                No matching chunks found for "{searchQuery}".
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {searchHits.map((hit) => (
                  <div
                    key={hit.chunk.chunkId}
                    className="p-3 rounded-lg bg-[#17212C] border border-slate-700/80 space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-mono text-[#66E3CB] font-semibold">
                        {hit.chunk.filename} (Chunk #{hit.chunk.chunkIndex + 1})
                      </span>
                      <span className="font-mono text-[#A9B8FF]">
                        Score: {hit.relevanceScore}
                      </span>
                    </div>
                    <p className="text-xs text-slate-200 leading-relaxed">
                      {hit.chunk.content}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Create Note Form */}
        {showAddForm && (
          <form
            onSubmit={handleCreateCustomDocument}
            className="p-4 bg-[#0B0F14] border border-slate-800 rounded-xl space-y-3"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={newFilename}
                onChange={(e) => setNewFilename(e.target.value)}
                placeholder="Document filename (e.g., Security_Audit_Notes.md)"
                className="bg-[#17212C] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
                required
              />
              <input
                type="text"
                value={newCollection}
                onChange={(e) => setNewCollection(e.target.value)}
                placeholder="Collection name"
                className="bg-[#17212C] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
              />
            </div>
            <textarea
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              rows={4}
              placeholder="Paste specification text, research notes, or architecture documentation to chunk & index..."
              className="w-full bg-[#17212C] border border-slate-700 rounded-lg p-3 text-xs text-slate-100"
              required
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs cursor-pointer"
              >
                Index Document
              </button>
            </div>
          </form>
        )}

        {/* Document Comparison Engine */}
        {showComparePanel && comparisonResult && (
          <div className="p-4 bg-[#0B0F14] border border-[#E8BE78]/40 rounded-xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-xs font-semibold text-[#E8BE78]">
                Differential Document Comparison
              </h3>
              <div className="flex items-center gap-2 text-xs">
                <select
                  value={compareDocAId}
                  onChange={(e) => setCompareDocAId(e.target.value)}
                  className="bg-[#17212C] border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-200"
                >
                  {documents.map((d) => (
                    <option key={d.documentId} value={d.documentId}>
                      Doc A: {d.filename}
                    </option>
                  ))}
                </select>
                <span className="text-slate-500">vs</span>
                <select
                  value={compareDocBId}
                  onChange={(e) => setCompareDocBId(e.target.value)}
                  className="bg-[#17212C] border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-200"
                >
                  {documents.map((d) => (
                    <option key={d.documentId} value={d.documentId}>
                      Doc B: {d.filename}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-[#17212C]">
                <div className="text-slate-400">Conceptual Similarity</div>
                <div className="text-lg font-mono font-semibold text-[#66E3CB] mt-0.5">
                  {Math.round(comparisonResult.similarityRatio * 100)}%
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  +{comparisonResult.lineAdditions} lines added / -{comparisonResult.lineRemovals} removed
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#17212C]">
                <div className="text-slate-400 mb-1">Unique Terms in {comparisonResult.docAName}</div>
                <div className="font-mono text-[11px] text-[#A9B8FF]">
                  {comparisonResult.uniqueToA.join(', ') || 'None'}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#17212C]">
                <div className="text-slate-400 mb-1">Unique Terms in {comparisonResult.docBName}</div>
                <div className="font-mono text-[11px] text-[#E8BE78]">
                  {comparisonResult.uniqueToB.join(', ') || 'None'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Google Drive Status & File Browser */}
        {(driveStatusMsg || driveFiles.length > 0) && (
          <div className="p-4 bg-[#0B0F14] border border-slate-800 rounded-xl space-y-2.5">
            {driveStatusMsg && (
              <div className="text-xs text-[#66E3CB] flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{driveStatusMsg}</span>
              </div>
            )}
            {driveFiles.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                {driveFiles.map((df) => (
                  <div
                    key={df.id}
                    className="p-2.5 rounded-lg bg-[#17212C] border border-slate-700/80 flex flex-col justify-between gap-2"
                  >
                    <div>
                      <div className="text-xs font-medium text-slate-200 truncate">
                        {df.name}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {df.mimeType}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleImportDriveFile(df)}
                      className="inline-flex items-center justify-center gap-1 px-2 py-1 rounded bg-[#66E3CB]/15 text-[#66E3CB] hover:bg-[#66E3CB]/25 text-[11px] font-medium cursor-pointer"
                    >
                      <Download className="w-3 h-3" />
                      <span>Import to Vault</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Vault Grid: Document Repository List + Selected Document Chunk Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-4 bg-[#111821] border border-slate-800/80 rounded-xl p-4 space-y-2.5">
          <h2 className="text-sm font-semibold text-slate-200">
            Indexed Repository ({documents.length})
          </h2>
          <div className="space-y-2">
            {documents.map((doc) => {
              const isSelected = doc.documentId === selectedDoc?.documentId;
              return (
                <div
                  key={doc.documentId}
                  onClick={() => setSelectedDocId(doc.documentId)}
                  className={`p-3 rounded-lg border transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-[#17212C] border-[#66E3CB]/40'
                      : 'bg-[#0B0F14]/60 border-slate-800/80 hover:bg-[#17212C]/50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="text-xs font-semibold text-slate-100 truncate">
                      {doc.filename}
                    </div>
                    <span className="text-[11px] font-mono text-[#66E3CB]">
                      {doc.processingStatus}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                    <span>{doc.collectionName}</span>
                    <span className="font-mono">{(doc.size / 1024).toFixed(1)} KB</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Chunk & Citation Inspector */}
        <div className="lg:col-span-8 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
          {selectedDoc ? (
            <>
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <h2 className="text-base font-semibold text-slate-100">
                    {selectedDoc.filename}
                  </h2>
                  <p className="text-xs text-slate-400">
                    Collection: {selectedDoc.collectionName} · {selectedDocChunks.length} indexed RAG chunks
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onGenerateCourseFromDoc(selectedDoc)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#A9B8FF]/15 text-[#A9B8FF] hover:bg-[#A9B8FF]/25 text-xs font-medium cursor-pointer"
                  >
                    <GraduationCap className="w-3.5 h-3.5" />
                    <span>Generate Course in Learning Lab</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPendingExportDoc(selectedDoc)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#17212C] hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5 text-[#66E3CB]" />
                    <span>Export to Google Drive</span>
                  </button>

                  {documents.length > 1 && (
                    <button
                      type="button"
                      onClick={() => onDeleteDocument(selectedDoc.documentId)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-800/50 text-xs cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                <div className="text-xs font-semibold text-slate-300">
                  Deterministic RAG Chunks (600-char window / 100-char overlap)
                </div>
                <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
                  {selectedDocChunks.map((chunk) => (
                    <div
                      key={chunk.chunkId}
                      className="p-3.5 rounded-lg bg-[#0B0F14] border border-slate-800/90 space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                        <span className="text-[#66E3CB]">
                          Chunk #{chunk.chunkIndex + 1} ({chunk.chunkId})
                        </span>
                        <span>
                          Offsets {chunk.startOffset}..{chunk.endOffset} (~{chunk.tokenEstimate} tokens)
                        </span>
                      </div>
                      <p className="text-xs text-slate-200 whitespace-pre-wrap leading-relaxed">
                        {chunk.content}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="text-xs text-slate-400">
              Select or upload a document to inspect its RAG chunks.
            </div>
          )}
        </div>
      </div>

      {/* Mandatory Owner Confirmation Modal before External Google Drive Write */}
      {pendingExportDoc && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-[#111821] border border-slate-700 rounded-xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-[#E8BE78] shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm font-semibold text-slate-100">
                  Confirm Google Drive Export (Lena Guardian Gate)
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  You are about to create a new file{' '}
                  <strong className="font-mono text-[#66E3CB]">
                    {pendingExportDoc.filename}
                  </strong>{' '}
                  in your connected Google Drive account using the{' '}
                  <code className="text-[#A9B8FF]">drive.file</code> scope.
                </p>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPendingExportDoc(null)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executeConfirmedDriveExport}
                className="px-4 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs cursor-pointer"
              >
                Approve & Export to Drive
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
