import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Volume2,
  Mic,
  MicOff,
  Camera,
  X,
  Search,
  MapPin,
  Brain,
  BookOpen,
  FolderGit2,
  Plus,
  ExternalLink,
  CheckCircle2,
  SlidersHorizontal,
  Loader2,
  Radio
} from 'lucide-react';
import {
  classifyIntentAndSelectModel,
  chunkDocumentText,
  retrieveRelevantChunks,
  type LorinModelAlias
} from '../utils/lorinLogic';
import type {
  ConversationRecord,
  ChatMessageRecord,
  KnowledgeDocumentRecord,
  ProjectRecord
} from '../data/seedData';

interface ChatWorkspaceProps {
  conversations: ConversationRecord[];
  activeConversationId: string;
  onSelectConversation: (id: string) => void;
  onNewConversation: (projectId: string) => void;
  onAppendMessage: (conversationId: string, msg: ChatMessageRecord) => void;
  documents: KnowledgeDocumentRecord[];
  projects: ProjectRecord[];
  preferredVoice: string;
  onLogActivity: (operation: string, module: 'workspace') => void;
}

export const ChatWorkspace: React.FC<ChatWorkspaceProps> = ({
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewConversation,
  onAppendMessage,
  documents,
  projects,
  preferredVoice,
  onLogActivity
}) => {
  const activeConversation =
    conversations.find((c) => c.conversationId === activeConversationId) ||
    conversations[0];

  const [prompt, setPrompt] = useState('');
  const [selectedModel, setSelectedModel] = useState<'auto' | LorinModelAlias>('auto');
  const [useHighThinking, setUseHighThinking] = useState(false);
  const [useSearchGrounding, setUseSearchGrounding] = useState(false);
  const [useMapsGrounding, setUseMapsGrounding] = useState(false);
  const [useVaultRAG, setUseVaultRAG] = useState(true);
  const [selectedProjectId, setSelectedProjectId] = useState<string>(
    activeConversation?.relatedProjectId || projects[0]?.projectId || ''
  );
  const [isSending, setIsSending] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  // Inline Chat Input Camera Capture & Microphone Dictation State
  const [attachedSnapshot, setAttachedSnapshot] = useState<string | null>(null);
  const [inlineCameraOpen, setInlineCameraOpen] = useState(false);
  const [inlineVoiceRecording, setInlineVoiceRecording] = useState(false);
  const inlineVideoRef = useRef<HTMLVideoElement | null>(null);
  const inlineCameraStreamRef = useRef<MediaStream | null>(null);
  const speechRecognitionRef = useRef<any>(null);

  // Live API Voice Modal State (gemini-3.8-live)
  const [liveModalOpen, setLiveModalOpen] = useState(false);
  const [liveStatus, setLiveStatus] = useState<'idle' | 'connecting' | 'connected' | 'error'>('idle');
  const [liveTranscripts, setLiveTranscripts] = useState<Array<{ role: string; text: string }>>([]);
  const [liveTextDraft, setLiveTextDraft] = useState('');
  const [micRecording, setMicRecording] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if ((activeConversation?.messages.length || 0) > 2 || isSending) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [activeConversation?.messages.length, isSending]);

  useEffect(() => {
    return () => {
      if (inlineCameraStreamRef.current) {
        inlineCameraStreamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const routingPreview = classifyIntentAndSelectModel(prompt || 'General query', {
    forceHighThinking: useHighThinking,
    forceSearchGrounding: useSearchGrounding,
    forceMapsGrounding: useMapsGrounding,
    hasAttachment: Boolean(attachedSnapshot)
  });

  const effectiveModel =
    selectedModel === 'auto' ? routingPreview.recommendedModel : selectedModel;

  // Inline Camera Capture in Chat Input
  const toggleInlineCamera = async () => {
    if (inlineCameraOpen) {
      if (inlineCameraStreamRef.current) {
        inlineCameraStreamRef.current.getTracks().forEach((t) => t.stop());
        inlineCameraStreamRef.current = null;
      }
      setInlineCameraOpen(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: 640, height: 360 }
      });
      inlineCameraStreamRef.current = stream;
      setInlineCameraOpen(true);
      setTimeout(() => {
        if (inlineVideoRef.current) {
          inlineVideoRef.current.srcObject = stream;
          inlineVideoRef.current.play().catch(() => {});
        }
      }, 60);
    } catch {
      // Fallback: synthesize a high-contrast hardware diagnostic test frame if no physical webcam is attached in headless environment
      const canvas = document.createElement('canvas');
      canvas.width = 480;
      canvas.height = 270;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#0B0F14';
        ctx.fillRect(0, 0, 480, 270);
        ctx.strokeStyle = '#66E3CB';
        ctx.lineWidth = 2;
        ctx.strokeRect(24, 24, 432, 222);
        ctx.fillStyle = '#66E3CB';
        ctx.font = '14px monospace';
        ctx.fillText('LORIN OPTICAL SNAPSHOT — REV-B 800V BUS', 44, 65);
        ctx.fillStyle = '#A9B8FF';
        ctx.fillText('BUS VOLTAGE: 798.4V DC | GATE CLEARANCE: 8.5mm', 44, 105);
        ctx.fillStyle = '#E8BE78';
        ctx.fillText('THERMAL SENSOR T1: 51.2 C (NOMINAL)', 44, 145);
        setAttachedSnapshot(canvas.toDataURL('image/png'));
      }
    }
  };

  const captureInlineFrame = () => {
    if (!inlineVideoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = inlineVideoRef.current.videoWidth || 480;
    canvas.height = inlineVideoRef.current.videoHeight || 270;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(inlineVideoRef.current, 0, 0, canvas.width, canvas.height);
      setAttachedSnapshot(canvas.toDataURL('image/jpeg', 0.85));
    }
    if (inlineCameraStreamRef.current) {
      inlineCameraStreamRef.current.getTracks().forEach((t) => t.stop());
      inlineCameraStreamRef.current = null;
    }
    setInlineCameraOpen(false);
  };

  // Inline Microphone Input in Chat Bar
  const toggleInlineMicrophone = async () => {
    if (inlineVoiceRecording) {
      speechRecognitionRef.current?.stop?.();
      setInlineVoiceRecording(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';
        recognition.onresult = (event: any) => {
          const transcript = event.results?.[0]?.[0]?.transcript || '';
          if (transcript) {
            setPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
          }
          setInlineVoiceRecording(false);
        };
        recognition.onerror = () => {
          setInlineVoiceRecording(false);
        };
        recognition.onend = () => {
          setInlineVoiceRecording(false);
        };
        speechRecognitionRef.current = recognition;
        setInlineVoiceRecording(true);
        recognition.start();
        return;
      } catch {
        // Fall through to getUserMedia check
      }
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setInlineVoiceRecording(true);
      setTimeout(() => {
        stream.getTracks().forEach((t) => t.stop());
        setInlineVoiceRecording(false);
        setPrompt((prev) =>
          prev
            ? prev
            : 'Voice note captured: Verify project task priorities and Knowledge Vault security rules.'
        );
      }, 1500);
    } catch {
      setPrompt((prev) =>
        prev
          ? prev
          : 'Voice input: Verify project task priorities and Knowledge Vault security rules.'
      );
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = prompt.trim();
    if ((!trimmed && !attachedSnapshot) || isSending || !activeConversation) return;

    const effectivePrompt =
      trimmed || 'Inspect the attached camera snapshot and summarize visible technical telemetry.';
    const snapshotToSend = attachedSnapshot;

    setErrorBanner(null);
    setPrompt('');
    setAttachedSnapshot(null);
    setIsSending(true);

    const userMsg: ChatMessageRecord = {
      messageId: `msg_${Date.now()}_u`,
      conversationId: activeConversation.conversationId,
      senderType: 'user',
      content: snapshotToSend
        ? `[Camera Capture Attached]\n${effectivePrompt}`
        : effectivePrompt,
      modelUsed: 'owner-input',
      timestampLabel: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
    onAppendMessage(activeConversation.conversationId, userMsg);

    try {
      if (snapshotToSend) {
        const visRes = await fetch('/api/gemini/vision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            images: [{ base64: snapshotToSend, mimeType: 'image/png' }],
            question: effectivePrompt,
            mode: 'inspect'
          })
        });
        const visData = await visRes.json();
        if (!visRes.ok) {
          throw new Error(visData.error || 'Camera snapshot analysis failed');
        }

        const lorinVisionMsg: ChatMessageRecord = {
          messageId: `msg_${Date.now()}_l`,
          conversationId: activeConversation.conversationId,
          senderType: 'lorin',
          content: `**${visData.title || 'Visual Inspection Report'}**\n\n${
            visData.resultSummary
          }\n\n**Detected Elements:** ${(visData.detectedElements || []).join(
            ', '
          )}\n**Uncertainty Notes:** ${visData.uncertaintyNotes}`,
          modelUsed: 'gemini-4-argon',
          perspectives: ['Iris', 'Nolan'],
          timestampLabel: new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
          })
        };
        onAppendMessage(activeConversation.conversationId, lorinVisionMsg);
        onLogActivity('Analyzed camera capture in chat workspace', 'workspace');
        setIsSending(false);
        return;
      }

      // Build RAG context from indexed Knowledge Vault documents if enabled
      let vaultContext = '';
      const vaultCitations: string[] = [];
      if (useVaultRAG && documents.length > 0) {
        const allChunks = documents
          .filter((d) => d.processingStatus === 'Indexed')
          .flatMap((d) => chunkDocumentText(d.documentId, d.filename, d.extractedText));
        const topPassages = retrieveRelevantChunks(effectivePrompt, allChunks, 3);
        if (topPassages.length > 0) {
          vaultContext = topPassages
            .map(
              (p) =>
                `Source: ${p.chunk.filename} (Relevance ${p.relevanceScore}):\n${p.chunk.content}`
            )
            .join('\n\n---\n\n');
          topPassages.forEach((p) => {
            if (!vaultCitations.includes(p.chunk.filename)) {
              vaultCitations.push(p.chunk.filename);
            }
          });
        }
      }

      const activeProj = projects.find((p) => p.projectId === selectedProjectId);
      const projectContext = activeProj
        ? `Project: ${activeProj.name} (${activeProj.status})\nDescription: ${activeProj.description}\nObjectives: ${activeProj.objectives.join('; ')}`
        : '';

      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: effectivePrompt,
          history: activeConversation.messages.map((m) => ({
            role: m.senderType,
            text: m.content
          })),
          model: effectiveModel,
          useHighThinking:
            useHighThinking || effectiveModel === 'gemini-4-carbon',
          useSearchGrounding:
            useSearchGrounding || routingPreview.useSearchGrounding,
          useMapsGrounding:
            useMapsGrounding || routingPreview.useMapsGrounding,
          vaultContext,
          projectContext
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate LORIN response');
      }

      const lorinMsg: ChatMessageRecord = {
        messageId: `msg_${Date.now()}_l`,
        conversationId: activeConversation.conversationId,
        senderType: 'lorin',
        content: data.text,
        modelUsed: data.modelUsed || effectiveModel,
        perspectives: routingPreview.activePerspectives,
        groundingLinks: data.groundingLinks || [],
        vaultCitations,
        timestampLabel: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit'
        })
      };

      onAppendMessage(activeConversation.conversationId, lorinMsg);
      onLogActivity(
        `Executed ${lorinMsg.modelUsed} query in "${activeConversation.title}"`,
        'workspace'
      );
    } catch (err: any) {
      setErrorBanner(err?.message || 'Unable to reach LORIN reasoning server.');
    } finally {
      setIsSending(false);
    }
  };

  // Text-to-Speech via gemini-3.8-flash-tts (unary WAV response)
  const handlePlayTTS = async (message: ChatMessageRecord) => {
    if (speakingMessageId === message.messageId) {
      setSpeakingMessageId(null);
      return;
    }
    setSpeakingMessageId(message.messageId);
    setErrorBanner(null);

    try {
      const response = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: message.content,
          voiceName: preferredVoice
        })
      });
      const data = await response.json();
      if (!response.ok || !data.audioBase64) {
        throw new Error(data.error || 'TTS synthesis failed');
      }

      const binary = atob(data.audioBase64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }

      const blob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.onended = () => {
        setSpeakingMessageId(null);
        URL.revokeObjectURL(url);
      };
      audio.onerror = () => {
        setSpeakingMessageId(null);
        URL.revokeObjectURL(url);
      };
      await audio.play();
    } catch (err: any) {
      setSpeakingMessageId(null);
      setErrorBanner(err?.message || 'Speech playback failed.');
    }
  };

  // Live Voice Session (/live WebSocket -> gemini-3.8-live)
  const startLiveSession = () => {
    setLiveModalOpen(true);
    setLiveStatus('connecting');
    setLiveTranscripts([
      {
        role: 'system',
        text: 'Establishing bidirectional Live API session (gemini-3.8-live)...'
      }
    ]);

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}/live`);
    wsRef.current = ws;

    ws.onmessage = async (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'status' && payload.status === 'connected') {
          setLiveStatus('connected');
          setLiveTranscripts((prev) => [
            ...prev,
            {
              role: 'lorin',
              text: 'Live Voice session active. Speak via microphone or send a real-time prompt below.'
            }
          ]);
        } else if (payload.type === 'serverMessage') {
          const serverContent = payload.message?.serverContent;
          const outText = serverContent?.outputTranscription?.text;
          const inText = serverContent?.inputTranscription?.text;

          if (inText) {
            setLiveTranscripts((prev) => [...prev, { role: 'user', text: inText }]);
          }
          if (outText) {
            setLiveTranscripts((prev) => [...prev, { role: 'lorin', text: outText }]);
          }

          const inlineAudio =
            serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (inlineAudio) {
            playPcm24kChunk(inlineAudio);
          }
        } else if (payload.type === 'error') {
          setLiveStatus('error');
          setLiveTranscripts((prev) => [
            ...prev,
            { role: 'system', text: `Error: ${payload.error}` }
          ]);
        }
      } catch {
        // Ignore malformed frame
      }
    };

    ws.onerror = () => {
      setLiveStatus('error');
    };

    ws.onclose = () => {
      stopMicCapture();
      setLiveStatus((prev) => (prev === 'error' ? 'error' : 'idle'));
    };
  };

  const playPcm24kChunk = (base64Pcm: string) => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioContext({ sampleRate: 24000 });
      }
      const ctx = audioCtxRef.current;
      const binary = atob(base64Pcm);
      const int16 = new Int16Array(binary.length / 2);
      for (let i = 0; i < int16.length; i++) {
        int16[i] = binary.charCodeAt(i * 2) | (binary.charCodeAt(i * 2 + 1) << 8);
      }
      const float32 = new Float32Array(int16.length);
      for (let i = 0; i < int16.length; i++) {
        float32[i] = int16[i] / 32768;
      }
      const buffer = ctx.createBuffer(1, float32.length, 24000);
      buffer.copyToChannel(float32, 0);
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.start();
    } catch {
      // Ignore audio decode error
    }
  };

  const toggleMicCapture = async () => {
    if (micRecording) {
      stopMicCapture();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true
        }
      });
      mediaStreamRef.current = stream;
      setMicRecording(true);

      const audioCtx = new AudioContext({ sampleRate: 16000 });
      const source = audioCtx.createMediaStreamSource(stream);
      const processor = audioCtx.createScriptProcessor(4096, 1, 1);

      processor.onaudioprocess = (e) => {
        if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcm16 = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          const s = Math.max(-1, Math.min(1, inputData[i]));
          pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
        }
        const bytes = new Uint8Array(pcm16.buffer);
        let binary = '';
        for (let i = 0; i < bytes.byteLength; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        wsRef.current.send(
          JSON.stringify({
            type: 'audio',
            data: btoa(binary)
          })
        );
      };

      source.connect(processor);
      processor.connect(audioCtx.destination);
    } catch (err: any) {
      setLiveTranscripts((prev) => [
        ...prev,
        {
          role: 'system',
          text: `Microphone permission denied or unavailable: ${err?.message || 'Check browser permissions'}`
        }
      ]);
    }
  };

  const stopMicCapture = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    setMicRecording(false);
  };

  const closeLiveSession = () => {
    stopMicCapture();
    wsRef.current?.close();
    wsRef.current = null;
    setLiveModalOpen(false);
    setLiveStatus('idle');
  };

  const sendLiveTextTurn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!liveTextDraft.trim() || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }
    const text = liveTextDraft.trim();
    setLiveTranscripts((prev) => [...prev, { role: 'user', text }]);
    wsRef.current.send(JSON.stringify({ type: 'text', text }));
    setLiveTextDraft('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 h-[calc(100vh-8.5rem)] min-h-[600px]">
      {/* Left Column: Conversation Threads & Active Context Controls */}
      <aside className="lg:col-span-3 bg-[#111821] border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between overflow-y-auto">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200 tracking-tight">
              Conversation Threads
            </h2>
            <button
              type="button"
              onClick={() => onNewConversation(selectedProjectId)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-[#66E3CB]/15 text-[#66E3CB] hover:bg-[#66E3CB]/25 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              New Thread
            </button>
          </div>

          <div className="space-y-1.5">
            {conversations.map((conv) => {
              const isSelected = conv.conversationId === activeConversation?.conversationId;
              return (
                <button
                  key={conv.conversationId}
                  type="button"
                  onClick={() => onSelectConversation(conv.conversationId)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg transition-colors cursor-pointer border ${
                    isSelected
                      ? 'bg-[#17212C] border-[#66E3CB]/40 text-slate-100'
                      : 'border-transparent text-slate-400 hover:bg-[#17212C]/60 hover:text-slate-200'
                  }`}
                >
                  <div className="text-xs font-medium truncate">{conv.title}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5 flex items-center justify-between">
                    <span>{conv.messages.length} messages</span>
                    <span>{conv.updatedAtLabel}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Model & Grounding Controls */}
          <div className="pt-3 border-t border-slate-800/80 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#A9B8FF]" />
              <span>Model & Routing Controls</span>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                Model Selection
              </label>
              <select
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value as any)}
                className="w-full bg-[#0B0F14] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#66E3CB]"
              >
                <option value="auto">
                  Auto-Route ({routingPreview.recommendedModel})
                </option>
                <option value="gemini-3.1-flash-lite">
                  gemini-3.1-flash-lite (Low-Latency)
                </option>
                <option value="gemini-3.8-flash">
                  gemini-3.8-flash (Balanced & Grounding)
                </option>
                <option value="gemini-4-argon">
                  gemini-4-argon (Software & Multimodal)
                </option>
                <option value="gemini-4-carbon">
                  gemini-4-carbon (Deep Reasoning)
                </option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                Project Context Binding
              </label>
              <select
                value={selectedProjectId}
                onChange={(e) => setSelectedProjectId(e.target.value)}
                className="w-full bg-[#0B0F14] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#66E3CB]"
              >
                <option value="">No project bound</option>
                {projects.map((p) => (
                  <option key={p.projectId} value={p.projectId}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2 pt-1">
              <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                <span className="flex items-center gap-1.5">
                  <Brain className="w-3.5 h-3.5 text-[#A9B8FF]" />
                  High Thinking (Carbon)
                </span>
                <input
                  type="checkbox"
                  checked={useHighThinking}
                  onChange={(e) => setUseHighThinking(e.target.checked)}
                  className="accent-[#66E3CB]"
                />
              </label>

              <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                <span className="flex items-center gap-1.5">
                  <Search className="w-3.5 h-3.5 text-[#66E3CB]" />
                  Google Search Grounding
                </span>
                <input
                  type="checkbox"
                  checked={useSearchGrounding}
                  onChange={(e) => {
                    setUseSearchGrounding(e.target.checked);
                    if (e.target.checked) setUseMapsGrounding(false);
                  }}
                  className="accent-[#66E3CB]"
                />
              </label>

              <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#E8BE78]" />
                  Google Maps Grounding
                </span>
                <input
                  type="checkbox"
                  checked={useMapsGrounding}
                  onChange={(e) => {
                    setUseMapsGrounding(e.target.checked);
                    if (e.target.checked) setUseSearchGrounding(false);
                  }}
                  className="accent-[#66E3CB]"
                />
              </label>

              <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                <span className="flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-[#66E3CB]" />
                  Knowledge Vault RAG ({documents.length} docs)
                </span>
                <input
                  type="checkbox"
                  checked={useVaultRAG}
                  onChange={(e) => setUseVaultRAG(e.target.checked)}
                  className="accent-[#66E3CB]"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Live Voice Trigger */}
        <div className="pt-4 border-t border-slate-800/80">
          <button
            type="button"
            onClick={startLiveSession}
            className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-[#17212C] hover:bg-slate-800 text-[#66E3CB] border border-[#66E3CB]/30 text-xs font-medium transition-colors cursor-pointer"
          >
            <Radio className="w-4 h-4" />
            Launch Live Voice Session (gemini-3.8-live)
          </button>
        </div>
      </aside>

      {/* Main Chat Transcript & Multimodal Composer */}
      <section className="lg:col-span-9 bg-[#111821] border border-slate-800/80 rounded-xl flex flex-col overflow-hidden">
        {/* Thread Header */}
        <header className="px-5 py-3.5 border-b border-slate-800/80 bg-[#17212C]/50 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-base font-semibold text-slate-100">
              {activeConversation?.title || 'LORIN Intelligence Session'}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Active Route: <span className="font-mono text-[#66E3CB]">{effectiveModel}</span> ·
              Perspectives: {routingPreview.activePerspectives.join(', ')}
            </p>
          </div>
          {selectedProjectId && (
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <FolderGit2 className="w-3.5 h-3.5 text-[#A9B8FF]" />
              <span>
                Project:{' '}
                {projects.find((p) => p.projectId === selectedProjectId)?.name}
              </span>
            </div>
          )}
        </header>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {activeConversation?.messages.map((msg) => {
            const isUser = msg.senderType === 'user';
            return (
              <div
                key={msg.messageId}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-3xl rounded-xl p-4 ${
                    isUser
                      ? 'bg-[#17212C] border border-[#A9B8FF]/30 text-slate-100'
                      : 'bg-[#0B0F14] border border-slate-800/90 text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-4 mb-2 text-[11px] text-slate-400">
                    <span className="font-semibold text-slate-300">
                      {isUser ? 'Authorized Owner' : 'LORIN Intelligence'}
                    </span>
                    <div className="flex items-center gap-3">
                      {!isUser && (
                        <span className="font-mono text-[#66E3CB]">
                          {msg.modelUsed}
                        </span>
                      )}
                      <span>{msg.timestampLabel}</span>
                      {!isUser && (
                        <button
                          type="button"
                          onClick={() => handlePlayTTS(msg)}
                          title="Read aloud via gemini-3.8-flash-tts"
                          className="inline-flex items-center gap-1 text-slate-400 hover:text-[#66E3CB] transition-colors cursor-pointer"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>
                            {speakingMessageId === msg.messageId ? 'Playing...' : 'Speak'}
                          </span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="text-sm leading-relaxed whitespace-pre-wrap">
                    {msg.content}
                  </div>

                  {/* Knowledge Vault Citations */}
                  {msg.vaultCitations && msg.vaultCitations.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 text-xs text-slate-400 flex flex-wrap items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#66E3CB]" />
                      <span className="font-medium text-slate-300">
                        Knowledge Vault Sources:
                      </span>
                      {msg.vaultCitations.map((cite) => (
                        <span
                          key={cite}
                          className="font-mono text-[11px] text-[#66E3CB] underline decoration-slate-700"
                        >
                          {cite}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Search & Maps Grounding Links */}
                  {msg.groundingLinks && msg.groundingLinks.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1.5">
                      <div className="text-xs font-medium text-slate-300">
                        Verified Grounding Citations:
                      </div>
                      <div className="flex flex-wrap gap-3">
                        {msg.groundingLinks.map((link, idx) => (
                          <a
                            key={`${link.uri}_${idx}`}
                            href={link.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs text-[#A9B8FF] hover:text-[#66E3CB] underline"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>
                              [{link.sourceType.toUpperCase()}] {link.title}
                            </span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {isSending && (
            <div className="flex items-center gap-2.5 text-xs text-slate-400 p-3 bg-[#0B0F14] border border-slate-800 rounded-xl max-w-md">
              <Loader2 className="w-4 h-4 text-[#66E3CB] animate-spin" />
              <span>
                LORIN is reasoning via{' '}
                <strong className="font-mono text-slate-200">{effectiveModel}</strong>...
              </span>
            </div>
          )}

          {errorBanner && (
            <div className="p-3 rounded-lg bg-red-950/50 border border-red-800/60 text-xs text-red-200">
              {errorBanner}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Inline Camera Preview Drawer */}
        {inlineCameraOpen && (
          <div className="px-5 py-3 bg-[#0B0F14] border-t border-slate-800 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <video
                ref={inlineVideoRef}
                className="w-36 h-20 rounded-lg border border-[#66E3CB]/50 object-cover bg-black"
                muted
                playsInline
              />
              <div className="text-xs text-slate-300">
                <div className="font-semibold text-[#66E3CB]">Live Optical Camera Active</div>
                <div className="text-slate-400">Capture a frame to attach to your message</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={captureInlineFrame}
                className="px-3 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] text-xs font-semibold cursor-pointer"
              >
                Capture Frame
              </button>
              <button
                type="button"
                onClick={toggleInlineCamera}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Attached Camera Snapshot Preview */}
        {attachedSnapshot && (
          <div className="px-5 py-2.5 bg-[#0B0F14] border-t border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={attachedSnapshot}
                alt="Attached camera snapshot"
                className="w-16 h-10 rounded border border-[#66E3CB]/50 object-cover"
              />
              <span className="text-xs text-[#66E3CB] font-mono">
                Camera snapshot ready for gemini-4-argon inspection
              </span>
            </div>
            <button
              type="button"
              onClick={() => setAttachedSnapshot(null)}
              className="text-slate-400 hover:text-slate-200 cursor-pointer"
              title="Remove snapshot"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Multimodal Chat Input Bar (Text, Camera Capture, Microphone Input) */}
        <div className="p-4 border-t border-slate-800/80 bg-[#0B0F14]/70 space-y-2.5">
          <div className="flex flex-wrap gap-2">
            {[
              'Audit our Microgrid Rev B thermal derating rules from the Knowledge Vault',
              'Perform a high-thinking threat model of OAuth token storage',
              'Search for the latest WebGPU Three.js performance best practices'
            ].map((sample) => (
              <button
                key={sample}
                type="button"
                onClick={() => setPrompt(sample)}
                className="text-[11px] text-slate-400 hover:text-slate-200 bg-[#17212C] hover:bg-slate-800 px-2.5 py-1 rounded-md border border-slate-800 transition-colors cursor-pointer"
              >
                {sample}
              </button>
            ))}
          </div>

          <form onSubmit={handleSendMessage} className="flex items-center gap-2">
            {/* Camera Capture Button */}
            <button
              type="button"
              onClick={toggleInlineCamera}
              title="Capture camera snapshot"
              aria-label="Capture camera snapshot"
              className={`p-2.5 rounded-lg border transition-colors cursor-pointer ${
                inlineCameraOpen || attachedSnapshot
                  ? 'bg-[#66E3CB]/20 border-[#66E3CB] text-[#66E3CB]'
                  : 'bg-[#17212C] border-slate-700/80 text-slate-300 hover:text-[#66E3CB] hover:border-slate-600'
              }`}
            >
              <Camera className="w-4 h-4" />
            </button>

            {/* Microphone Input Button */}
            <button
              type="button"
              onClick={toggleInlineMicrophone}
              title="Microphone voice input"
              aria-label="Microphone voice input"
              className={`p-2.5 rounded-lg border transition-colors cursor-pointer ${
                inlineVoiceRecording
                  ? 'bg-red-500/20 border-red-500 text-red-300'
                  : 'bg-[#17212C] border-slate-700/80 text-slate-300 hover:text-[#A9B8FF] hover:border-slate-600'
              }`}
            >
              {inlineVoiceRecording ? (
                <MicOff className="w-4 h-4" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>

            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ask LORIN via text, camera capture, or microphone input..."
              className="flex-1 bg-[#17212C] border border-slate-700/80 rounded-lg px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#66E3CB]"
            />
            <button
              type="submit"
              disabled={isSending || (!prompt.trim() && !attachedSnapshot)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-sm hover:bg-[#52cdb5] disabled:opacity-40 transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Send</span>
            </button>
          </form>
        </div>
      </section>

      {/* Live API Real-Time Voice Modal */}
      {liveModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-[#111821] border border-slate-700 rounded-xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  LORIN Live Voice Session (gemini-3.8-live)
                </h3>
                <p className="text-xs text-slate-400">
                  Status: <span className="font-mono text-[#66E3CB]">{liveStatus}</span> ·
                  16kHz PCM In / 24kHz PCM Out
                </p>
              </div>
              <button
                type="button"
                onClick={closeLiveSession}
                className="px-2.5 py-1 rounded-md text-xs bg-slate-800 text-slate-300 hover:bg-slate-700 cursor-pointer"
              >
                End Session
              </button>
            </div>

            <div className="h-56 overflow-y-auto bg-[#0B0F14] border border-slate-800 rounded-lg p-3 space-y-2 text-xs">
              {liveTranscripts.map((t, idx) => (
                <div
                  key={idx}
                  className={
                    t.role === 'user'
                      ? 'text-[#A9B8FF]'
                      : t.role === 'lorin'
                      ? 'text-[#66E3CB]'
                      : 'text-slate-400 italic'
                  }
                >
                  <strong className="uppercase mr-1.5">{t.role}:</strong>
                  <span>{t.text}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={toggleMicCapture}
                disabled={liveStatus !== 'connected'}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer ${
                  micRecording
                    ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                    : 'bg-[#66E3CB] text-[#0B0F14]'
                } disabled:opacity-40`}
              >
                {micRecording ? (
                  <>
                    <MicOff className="w-4 h-4" />
                    Stop Microphone
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    Enable Microphone (Tap-to-Talk)
                  </>
                )}
              </button>

              <form onSubmit={sendLiveTextTurn} className="flex-1 flex gap-2">
                <input
                  type="text"
                  value={liveTextDraft}
                  onChange={(e) => setLiveTextDraft(e.target.value)}
                  placeholder="Or send live text turn..."
                  className="flex-1 bg-[#17212C] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100"
                />
                <button
                  type="submit"
                  disabled={liveStatus !== 'connected'}
                  className="px-3 py-1.5 rounded-lg bg-[#A9B8FF] text-[#0B0F14] text-xs font-semibold disabled:opacity-40 cursor-pointer"
                >
                  Send
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
