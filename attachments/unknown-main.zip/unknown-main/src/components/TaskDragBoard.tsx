import React, { useState } from 'react';
import {
  GripVertical,
  ArrowUp,
  ArrowDown,
  MessageSquare,
  Calendar,
  Columns3
} from 'lucide-react';
import {
  reorderAndMoveProjectTask,
  type ProjectTask,
  type TaskPriority,
  type TaskStatus
} from '../utils/lorinLogic';

interface TaskDragBoardProps {
  tasks: ProjectTask[];
  onReorderOrMoveTasks: (nextTasks: ProjectTask[], summary: string) => void;
  onUpdateTaskField: (
    taskId: string,
    updates: Partial<Pick<ProjectTask, 'priority' | 'status'>>
  ) => void;
  onOpenComments?: (taskId: string) => void;
}

const STATUS_COLUMNS: Array<{ id: TaskStatus; label: string; description: string }> = [
  { id: 'todo', label: 'To Do', description: 'Queued deliverables' },
  { id: 'in_progress', label: 'In Progress', description: 'Active engineering work' },
  { id: 'done', label: 'Done', description: 'Verified & completed' }
];

const PRIORITY_COLUMNS: Array<{ id: TaskPriority; label: string; textClass: string }> = [
  { id: 'High', label: 'High Priority', textClass: 'text-red-400' },
  { id: 'Medium', label: 'Medium Priority', textClass: 'text-[#E8BE78]' },
  { id: 'Low', label: 'Low Priority', textClass: 'text-[#66E3CB]' }
];

const PRIORITY_TIERS: TaskPriority[] = ['High', 'Medium', 'Low'];

export const TaskDragBoard: React.FC<TaskDragBoardProps> = ({
  tasks,
  onReorderOrMoveTasks,
  onUpdateTaskField,
  onOpenComments
}) => {
  const [groupMode, setGroupMode] = useState<'status' | 'priority'>('status');
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);
  const [dragOverPriorityZone, setDragOverPriorityZone] = useState<string | null>(null);
  const [dragOverCard, setDragOverCard] = useState<{
    taskId: string;
    position: 'before' | 'after';
  } | null>(null);

  const orderedTasks = [...tasks].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const resetDragState = () => {
    setDraggedTaskId(null);
    setDragOverColumn(null);
    setDragOverPriorityZone(null);
    setDragOverCard(null);
  };

  const handleDragStart = (e: React.DragEvent, taskId: string) => {
    setDraggedTaskId(taskId);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', taskId);
  };

  const resolveDraggedId = (e: React.DragEvent): string | null => {
    return draggedTaskId || e.dataTransfer.getData('text/plain') || null;
  };

  const handleDropOnStatusColumn = (
    e: React.DragEvent,
    targetStatus: TaskStatus,
    targetPriority?: TaskPriority
  ) => {
    e.preventDefault();
    e.stopPropagation();
    const id = resolveDraggedId(e);
    if (!id) {
      resetDragState();
      return;
    }

    const dragged = tasks.find((t) => t.taskId === id);
    if (!dragged) {
      resetDragState();
      return;
    }

    const nextTasks = reorderAndMoveProjectTask(orderedTasks, id, {
      status: targetStatus,
      priority: targetPriority
    });

    const summary = targetPriority
      ? `Moved "${dragged.title}" to ${targetStatus.replace('_', ' ')} with ${targetPriority} priority`
      : `Moved "${dragged.title}" to ${targetStatus.replace('_', ' ')}`;

    onReorderOrMoveTasks(nextTasks, summary);
    resetDragState();
  };

  const handleDropOnPriorityColumn = (e: React.DragEvent, targetPriority: TaskPriority) => {
    e.preventDefault();
    e.stopPropagation();
    const id = resolveDraggedId(e);
    if (!id) {
      resetDragState();
      return;
    }

    const dragged = tasks.find((t) => t.taskId === id);
    if (!dragged) {
      resetDragState();
      return;
    }

    const nextTasks = reorderAndMoveProjectTask(orderedTasks, id, {
      priority: targetPriority
    });

    onReorderOrMoveTasks(
      nextTasks,
      `Updated "${dragged.title}" priority to ${targetPriority} via drag-and-drop`
    );
    resetDragState();
  };

  const handleDropOnTaskCard = (
    e: React.DragEvent,
    targetTask: ProjectTask,
    position: 'before' | 'after'
  ) => {
    e.preventDefault();
    e.stopPropagation();
    const id = resolveDraggedId(e);
    if (!id || id === targetTask.taskId) {
      resetDragState();
      return;
    }

    const dragged = tasks.find((t) => t.taskId === id);
    if (!dragged) {
      resetDragState();
      return;
    }

    const nextTasks = reorderAndMoveProjectTask(orderedTasks, id, {
      status: groupMode === 'status' ? targetTask.status : dragged.status,
      priority: groupMode === 'priority' ? targetTask.priority : dragged.priority,
      targetTaskId: targetTask.taskId,
      insertPosition: position
    });

    const summary =
      groupMode === 'status'
        ? `Reordered "${dragged.title}" ${position} "${targetTask.title}" in ${targetTask.status.replace('_', ' ')}`
        : `Reordered "${dragged.title}" ${position} "${targetTask.title}" (${targetTask.priority} priority)`;

    onReorderOrMoveTasks(nextTasks, summary);
    resetDragState();
  };

  const handleKeyboardShift = (
    columnTasks: ProjectTask[],
    task: ProjectTask,
    direction: 'up' | 'down'
  ) => {
    const idx = columnTasks.findIndex((t) => t.taskId === task.taskId);
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (idx === -1 || swapIdx < 0 || swapIdx >= columnTasks.length) return;
    const targetTask = columnTasks[swapIdx];
    const nextTasks = reorderAndMoveProjectTask(orderedTasks, task.taskId, {
      status: task.status,
      priority: task.priority,
      targetTaskId: targetTask.taskId,
      insertPosition: direction === 'up' ? 'before' : 'after'
    });
    onReorderOrMoveTasks(nextTasks, `Reordered "${task.title}" ${direction}`);
  };

  const renderTaskCard = (task: ProjectTask, columnTasks: ProjectTask[], idxInCol: number) => {
    const isBeingDragged = draggedTaskId === task.taskId;
    const isDropBefore =
      dragOverCard?.taskId === task.taskId && dragOverCard.position === 'before';
    const isDropAfter =
      dragOverCard?.taskId === task.taskId && dragOverCard.position === 'after';

    return (
      <div
        key={task.taskId}
        draggable
        data-testid={`draggable-task-${task.taskId}`}
        onDragStart={(e) => handleDragStart(e, task.taskId)}
        onDragEnd={resetDragState}
        onDragOver={(e) => {
          e.preventDefault();
          e.stopPropagation();
          const rect = e.currentTarget.getBoundingClientRect();
          const midY = rect.top + rect.height / 2;
          const pos: 'before' | 'after' = e.clientY < midY ? 'before' : 'after';
          setDragOverCard({ taskId: task.taskId, position: pos });
        }}
        onDragLeave={() => {
          setDragOverCard((prev) => (prev?.taskId === task.taskId ? null : prev));
        }}
        onDrop={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const pos: 'before' | 'after' =
            e.clientY < rect.top + rect.height / 2 ? 'before' : 'after';
          handleDropOnTaskCard(e, task, pos);
        }}
        className={`relative p-3 rounded-lg bg-[#0B0F14] border transition-all cursor-grab active:cursor-grabbing space-y-2 ${
          isBeingDragged
            ? 'opacity-45 border-[#66E3CB] scale-[0.99]'
            : 'border-slate-800 hover:border-slate-700'
        }`}
      >
        {/* Crisp Drag Insertion Line Indicator */}
        {isDropBefore && !isBeingDragged && (
          <div
            className="absolute -top-1.5 left-2 right-2 h-0.5 bg-[#66E3CB] rounded-full pointer-events-none"
            aria-hidden="true"
          />
        )}
        {isDropAfter && !isBeingDragged && (
          <div
            className="absolute -bottom-1.5 left-2 right-2 h-0.5 bg-[#66E3CB] rounded-full pointer-events-none"
            aria-hidden="true"
          />
        )}

        <div className="flex items-start justify-between gap-2">
          <div className="flex items-start gap-2 min-w-0">
            <GripVertical
              className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5"
              aria-hidden="true"
            />
            <div className="min-w-0">
              <div className="text-xs font-semibold text-slate-100 leading-snug">
                {task.title}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 truncate">
                {task.assignee} · {task.estimatedHours}h
              </div>
            </div>
          </div>

          {/* Accessible Keyboard Reorder Controls */}
          <div className="flex items-center gap-0.5 shrink-0">
            <button
              type="button"
              disabled={idxInCol === 0}
              onClick={() => handleKeyboardShift(columnTasks, task, 'up')}
              aria-label={`Move ${task.title} up`}
              className="p-1 rounded text-slate-500 hover:text-slate-200 disabled:opacity-25 cursor-pointer"
            >
              <ArrowUp className="w-3 h-3" />
            </button>
            <button
              type="button"
              disabled={idxInCol === columnTasks.length - 1}
              onClick={() => handleKeyboardShift(columnTasks, task, 'down')}
              aria-label={`Move ${task.title} down`}
              className="p-1 rounded text-slate-500 hover:text-slate-200 disabled:opacity-25 cursor-pointer"
            >
              <ArrowDown className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Unboxed Tabular Schedule & Priority Metadata Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-slate-800/70 text-[11px]">
          <div className="flex items-center gap-1.5 font-mono tabular-nums text-slate-400">
            <Calendar className="w-3 h-3 text-slate-500" aria-hidden="true" />
            <span>
              {task.startDate ? task.startDate.slice(5) : 'TBD'} →{' '}
              {task.dueDate ? task.dueDate.slice(5) : 'TBD'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={task.priority}
              onChange={(e) =>
                onUpdateTaskField(task.taskId, {
                  priority: e.target.value as TaskPriority
                })
              }
              aria-label={`Priority for ${task.title}`}
              className={`bg-transparent text-[11px] font-mono font-semibold cursor-pointer focus:outline-none ${
                task.priority === 'High'
                  ? 'text-red-400'
                  : task.priority === 'Medium'
                  ? 'text-[#E8BE78]'
                  : 'text-[#66E3CB]'
              }`}
            >
              <option value="High" className="bg-[#111821] text-red-300">
                High
              </option>
              <option value="Medium" className="bg-[#111821] text-[#E8BE78]">
                Medium
              </option>
              <option value="Low" className="bg-[#111821] text-[#66E3CB]">
                Low
              </option>
            </select>

            {onOpenComments && (
              <button
                type="button"
                onClick={() => onOpenComments(task.taskId)}
                className="inline-flex items-center gap-1 text-slate-400 hover:text-[#A9B8FF] font-mono tabular-nums cursor-pointer"
                title="Open task comments"
              >
                <MessageSquare className="w-3 h-3" />
                <span>{task.comments.length}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
            <Columns3 className="w-4 h-4 text-[#66E3CB]" />
            <span>Interactive Drag-and-Drop Task Board</span>
          </div>
          <p className="text-xs text-slate-400">
            Drag tasks to reorder vertically, move across status columns, or drop onto a High / Medium / Low priority tier inside any column.
          </p>
        </div>

        {/* Column Grouping Switch */}
        <div
          className="flex items-center gap-1 p-0.5 bg-[#0B0F14] border border-slate-800 rounded-lg"
          role="group"
          aria-label="Board column grouping mode"
        >
          <button
            type="button"
            onClick={() => setGroupMode('status')}
            className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
              groupMode === 'status'
                ? 'bg-[#17212C] text-[#66E3CB]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Status Columns
          </button>
          <button
            type="button"
            onClick={() => setGroupMode('priority')}
            className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
              groupMode === 'priority'
                ? 'bg-[#17212C] text-[#A9B8FF]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Priority Columns
          </button>
        </div>
      </div>

      {/* STATUS COLUMNS MODE (with per-column High / Medium / Low priority drop targets) */}
      {groupMode === 'status' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {STATUS_COLUMNS.map((col) => {
            const colTasks = orderedTasks.filter((t) => t.status === col.id);
            const isColHighlighted = dragOverColumn === col.id;

            return (
              <div
                key={col.id}
                data-testid={`status-column-${col.id}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOverColumn(col.id);
                }}
                onDragLeave={() => {
                  setDragOverColumn((prev) => (prev === col.id ? null : prev));
                }}
                onDrop={(e) => handleDropOnStatusColumn(e, col.id)}
                className={`rounded-xl p-3.5 border transition-colors flex flex-col gap-3 min-h-[260px] ${
                  isColHighlighted
                    ? 'bg-[#17212C]/80 border-[#66E3CB]/60'
                    : 'bg-[#0B0F14]/55 border-slate-800/80'
                }`}
              >
                {/* Column Header */}
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                  <div>
                    <div className="text-xs font-semibold text-slate-100">{col.label}</div>
                    <div className="text-[11px] text-slate-500">{col.description}</div>
                  </div>
                  <span className="text-xs font-mono tabular-nums text-slate-400">
                    {colTasks.length}
                  </span>
                </div>

                {/* Priority Quick-Drop Targets inside each Status Column */}
                <div
                  className="grid grid-cols-3 gap-1.5"
                  aria-label={`Set priority when dropping into ${col.label}`}
                >
                  {PRIORITY_TIERS.map((prio) => {
                    const zoneKey = `${col.id}:${prio}`;
                    const isZoneActive = dragOverPriorityZone === zoneKey;
                    const colorClasses =
                      prio === 'High'
                        ? isZoneActive
                          ? 'border-red-400 bg-red-500/20 text-red-200'
                          : 'border-slate-800 text-red-400/80 hover:border-red-500/40'
                        : prio === 'Medium'
                        ? isZoneActive
                          ? 'border-[#E8BE78] bg-[#E8BE78]/20 text-[#FDE6B8]'
                          : 'border-slate-800 text-[#E8BE78]/80 hover:border-[#E8BE78]/40'
                        : isZoneActive
                        ? 'border-[#66E3CB] bg-[#66E3CB]/20 text-[#CCFBF1]'
                        : 'border-slate-800 text-[#66E3CB]/80 hover:border-[#66E3CB]/40';

                    return (
                      <div
                        key={zoneKey}
                        data-testid={`priority-dropzone-${col.id}-${prio}`}
                        onDragOver={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setDragOverColumn(col.id);
                          setDragOverPriorityZone(zoneKey);
                        }}
                        onDragLeave={() => {
                          setDragOverPriorityZone((prev) => (prev === zoneKey ? null : prev));
                        }}
                        onDrop={(e) => handleDropOnStatusColumn(e, col.id, prio)}
                        className={`px-2 py-1.5 rounded-md border border-dashed text-center text-[10px] font-mono transition-colors ${colorClasses} ${
                          draggedTaskId ? 'opacity-100' : 'opacity-70'
                        }`}
                      >
                        Drop {prio}
                      </div>
                    );
                  })}
                </div>

                {/* Task Cards in Column */}
                <div className="space-y-2.5 flex-1">
                  {colTasks.length === 0 ? (
                    <div className="h-24 rounded-lg border border-dashed border-slate-800 flex items-center justify-center text-xs text-slate-500 text-center px-3">
                      Drag a task here to move it to {col.label}
                    </div>
                  ) : (
                    colTasks.map((task, idx) => renderTaskCard(task, colTasks, idx))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* PRIORITY COLUMNS MODE */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {PRIORITY_COLUMNS.map((col) => {
            const colTasks = orderedTasks.filter((t) => t.priority === col.id);
            const isColHighlighted = dragOverColumn === col.id;

            return (
              <div
                key={col.id}
                data-testid={`priority-column-${col.id}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOverColumn(col.id);
                }}
                onDragLeave={() => {
                  setDragOverColumn((prev) => (prev === col.id ? null : prev));
                }}
                onDrop={(e) => handleDropOnPriorityColumn(e, col.id)}
                className={`rounded-xl p-3.5 border transition-colors flex flex-col gap-3 min-h-[260px] ${
                  isColHighlighted
                    ? 'bg-[#17212C]/80 border-[#A9B8FF]/60'
                    : 'bg-[#0B0F14]/55 border-slate-800/80'
                }`}
              >
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                  <div className={`text-xs font-semibold ${col.textClass}`}>{col.label}</div>
                  <span className="text-xs font-mono tabular-nums text-slate-400">
                    {colTasks.length}
                  </span>
                </div>

                <div className="space-y-2.5 flex-1">
                  {colTasks.length === 0 ? (
                    <div className="h-24 rounded-lg border border-dashed border-slate-800 flex items-center justify-center text-xs text-slate-500 text-center px-3">
                      Drag a task here to set {col.label}
                    </div>
                  ) : (
                    colTasks.map((task, idx) => renderTaskCard(task, colTasks, idx))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
