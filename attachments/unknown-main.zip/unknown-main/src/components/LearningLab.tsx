import React, { useState } from 'react';
import {
  GraduationCap,
  Play,
  CheckCircle2,
  XCircle,
  Code2,
  Sparkles,
  BookOpen,
  Loader2,
  Award
} from 'lucide-react';
import {
  evaluateQuizSubmission,
  calculateUpdatedLearningPathMetrics,
  type QuizSubmissionEvaluation
} from '../utils/lorinLogic';
import type { LearningPathRecord } from '../data/seedData';

interface LearningLabProps {
  learningPaths: LearningPathRecord[];
  onUpdateLearningPath: (updated: LearningPathRecord) => void;
  onAddLearningPath: (newPath: LearningPathRecord) => void;
  onLogActivity: (operation: string, module: 'learning') => void;
}

export const LearningLab: React.FC<LearningLabProps> = ({
  learningPaths,
  onUpdateLearningPath,
  onAddLearningPath,
  onLogActivity
}) => {
  const [selectedPathId, setSelectedPathId] = useState<string>(
    learningPaths[0]?.learningPathId || ''
  );
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [quizEvaluation, setQuizEvaluation] =
    useState<QuizSubmissionEvaluation | null>(null);

  // Coding Lab State
  const activePath =
    learningPaths.find((p) => p.learningPathId === selectedPathId) ||
    learningPaths[0];
  const [codeDraft, setCodeDraft] = useState<string>(
    activePath?.starterCode || ''
  );
  const [codeOutput, setCodeOutput] = useState<string>('');
  const [codeVerified, setCodeVerified] = useState<boolean | null>(null);

  // Course Generator State
  const [customTopic, setCustomTopic] = useState('');
  const [customLevel, setCustomLevel] = useState<
    'beginner' | 'intermediate' | 'advanced'
  >('intermediate');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleSelectPath = (path: LearningPathRecord) => {
    setSelectedPathId(path.learningPathId);
    setSelectedAnswers({});
    setQuizEvaluation(null);
    setCodeDraft(path.starterCode);
    setCodeOutput('');
    setCodeVerified(null);
  };

  const handleSubmitQuiz = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePath) return;

    const evalResult = evaluateQuizSubmission(
      activePath.quizQuestions,
      selectedAnswers,
      70
    );
    setQuizEvaluation(evalResult);

    const updatedMetrics = calculateUpdatedLearningPathMetrics(
      activePath.completedLessons,
      activePath.totalLessons,
      activePath.averageScore,
      evalResult.scorePercentage,
      evalResult.passed
    );

    onUpdateLearningPath({
      ...activePath,
      completedLessons: updatedMetrics.completedLessons,
      averageScore: updatedMetrics.averageScore,
      status: updatedMetrics.status
    });

    onLogActivity(
      `Submitted quiz for "${activePath.title}" (Score: ${evalResult.scorePercentage}%)`,
      'learning'
    );
  };

  const handleRunSandboxedCode = () => {
    if (!activePath) return;
    const logs: string[] = [];
    const customConsole = {
      log: (...args: unknown[]) =>
        logs.push(
          args
            .map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a)))
            .join(' ')
        ),
      error: (...args: unknown[]) =>
        logs.push(`ERROR: ${args.map(String).join(' ')}`)
    };

    try {
      const fn = new Function('console', `"use strict";\n${codeDraft}`);
      fn(customConsole);
      const output = logs.join('\n') || '(Executed with no console output)';
      setCodeOutput(output);
      const passed = output.includes(activePath.expectedOutputSubstring);
      setCodeVerified(passed);
      onLogActivity(
        `Executed Coding Lab exercise in "${activePath.title}" (${passed ? 'Passed' : 'Ran'})`,
        'learning'
      );
    } catch (err: any) {
      setCodeOutput(`Runtime Error: ${err?.message || String(err)}`);
      setCodeVerified(false);
    }
  };

  const handleGenerateCustomCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTopic.trim() || isGenerating) return;
    setIsGenerating(true);

    try {
      const res = await fetch('/api/gemini/learning-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: customTopic.trim(),
          targetLevel: customLevel
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to generate course');

      const created: LearningPathRecord = {
        learningPathId: `path_${Date.now()}`,
        title: data.title || customTopic.trim(),
        subject: data.subject || 'Custom Engineering Track',
        targetLevel: customLevel,
        status: 'active',
        completedLessons: 0,
        totalLessons: 3,
        averageScore: 0,
        conceptOverview: data.conceptOverview || '',
        keyTakeaways: Array.isArray(data.keyTakeaways) ? data.keyTakeaways : [],
        workedExample: data.workedExample || '',
        codingPrompt: data.codingPrompt || '',
        starterCode: data.starterCode || '// Write your solution here\n',
        expectedOutputSubstring: data.expectedOutputSubstring || '',
        quizQuestions: Array.isArray(data.quizQuestions) ? data.quizQuestions : []
      };

      onAddLearningPath(created);
      handleSelectPath(created);
      setCustomTopic('');
      onLogActivity(`Generated personalized course "${created.title}"`, 'learning');
    } catch {
      // Ignore error
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Left Sidebar: Learning Paths & AI Course Generator */}
      <aside className="lg:col-span-4 bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-5">
        <div>
          <h1 className="text-base font-semibold text-slate-100">
            AI Learning Laboratory
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Adaptive engineering curricula, verification quizzes, and sandboxed JS laboratory
          </p>
        </div>

        {/* Custom Course Generator */}
        <form
          onSubmit={handleGenerateCustomCourse}
          className="p-3.5 rounded-xl bg-[#0B0F14] border border-slate-800 space-y-2.5"
        >
          <div className="text-xs font-semibold text-[#66E3CB] flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Synthesize New Learning Path</span>
          </div>
          <input
            type="text"
            value={customTopic}
            onChange={(e) => setCustomTopic(e.target.value)}
            placeholder="Topic (e.g., WebSockets & CRDT State Sync)"
            className="w-full bg-[#17212C] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-100"
          />
          <div className="flex items-center gap-2">
            <select
              value={customLevel}
              onChange={(e) => setCustomLevel(e.target.value as any)}
              className="flex-1 bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
            >
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
            <button
              type="submit"
              disabled={isGenerating || !customTopic.trim()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs disabled:opacity-40 cursor-pointer"
            >
              {isGenerating ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <GraduationCap className="w-3.5 h-3.5" />
              )}
              <span>Generate</span>
            </button>
          </div>
        </form>

        {/* Active Learning Tracks */}
        <div className="space-y-2.5">
          <div className="text-xs font-semibold text-slate-300">
            Enrolled Learning Tracks ({learningPaths.length})
          </div>
          {learningPaths.map((path) => {
            const isSelected = path.learningPathId === activePath?.learningPathId;
            const progressPct = Math.round(
              (path.completedLessons / Math.max(1, path.totalLessons)) * 100
            );
            return (
              <button
                key={path.learningPathId}
                type="button"
                onClick={() => handleSelectPath(path)}
                className={`w-full text-left p-3.5 rounded-xl border transition-colors cursor-pointer space-y-2 ${
                  isSelected
                    ? 'bg-[#17212C] border-[#66E3CB]/50'
                    : 'bg-[#0B0F14]/70 border-slate-800 hover:bg-[#17212C]/50'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="text-xs font-semibold text-slate-100">
                    {path.title}
                  </div>
                  <span className="text-[11px] font-mono text-[#A9B8FF] uppercase">
                    {path.targetLevel}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>
                    Lessons: {path.completedLessons}/{path.totalLessons}
                  </span>
                  <span className="font-mono text-[#66E3CB]">
                    Avg Score: {path.averageScore}%
                  </span>
                </div>

                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#66E3CB] transition-all"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
              </button>
            );
          })}
        </div>
      </aside>

      {/* Main Content: Interactive Lesson, Coding Sandbox, and Verification Quiz */}
      <section className="lg:col-span-8 space-y-5">
        {activePath && (
          <>
            {/* Lesson Concept & Worked Example */}
            <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <span className="text-xs font-mono text-[#66E3CB]">
                    {activePath.subject} · {activePath.status.toUpperCase()}
                  </span>
                  <h2 className="text-lg font-semibold text-slate-100 mt-0.5">
                    {activePath.title}
                  </h2>
                </div>
                <div className="flex items-center gap-2 text-xs text-[#E8BE78] font-mono">
                  <Award className="w-4 h-4" />
                  <span>Mastery Score: {activePath.averageScore}%</span>
                </div>
              </div>

              <p className="text-sm text-slate-200 leading-relaxed">
                {activePath.conceptOverview}
              </p>

              <div className="space-y-1.5">
                <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-[#A9B8FF]" />
                  <span>Core Engineering Takeaways:</span>
                </div>
                <ul className="text-xs text-slate-300 list-disc list-inside space-y-1">
                  {activePath.keyTakeaways.map((item, idx) => (
                    <li key={idx}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-[#0B0F14] border border-slate-800 rounded-lg p-3.5">
                <div className="text-[11px] font-mono text-slate-400 mb-1.5">
                  Worked Reference Implementation:
                </div>
                <pre className="text-xs font-mono text-[#66E3CB] overflow-x-auto">
                  {activePath.workedExample}
                </pre>
              </div>
            </div>

            {/* Interactive Coding Laboratory */}
            <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-[#A9B8FF]" />
                  <h3 className="text-sm font-semibold text-slate-100">
                    Sandboxed Coding Laboratory
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={handleRunSandboxedCode}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs hover:bg-[#52cdb5] cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Run & Verify Code</span>
                </button>
              </div>

              <p className="text-xs text-slate-300">{activePath.codingPrompt}</p>

              <textarea
                value={codeDraft}
                onChange={(e) => setCodeDraft(e.target.value)}
                rows={6}
                className="w-full bg-[#0B0F14] border border-slate-800 rounded-lg p-3 font-mono text-xs text-slate-100 focus:outline-none focus:border-[#66E3CB]"
              />

              {codeOutput && (
                <div className="p-3 rounded-lg bg-[#0B0F14] border border-slate-800 flex items-center justify-between">
                  <pre className="text-xs font-mono text-slate-200">{codeOutput}</pre>
                  {codeVerified !== null && (
                    <span
                      className={`text-xs font-semibold flex items-center gap-1 ${
                        codeVerified ? 'text-[#66E3CB]' : 'text-[#E8BE78]'
                      }`}
                    >
                      {codeVerified ? (
                        <>
                          <CheckCircle2 className="w-4 h-4" />
                          Expected Output Verified
                        </>
                      ) : (
                        'Output differs from target'
                      )}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Verification Quiz (Answers Hidden Until Submitted per LORIN Spec Part 4.4) */}
            <form
              onSubmit={handleSubmitQuiz}
              className="bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-semibold text-slate-100">
                  Comprehension Verification Quiz (Answers Hidden Until Submission)
                </h3>
                {quizEvaluation && (
                  <span
                    className={`text-xs font-mono font-semibold ${
                      quizEvaluation.passed ? 'text-[#66E3CB]' : 'text-red-400'
                    }`}
                  >
                    Score: {quizEvaluation.scorePercentage}% (
                    {quizEvaluation.correctCount}/{quizEvaluation.totalQuestions})
                  </span>
                )}
              </div>

              <div className="space-y-4">
                {activePath.quizQuestions.map((q, qIdx) => {
                  const feedback = quizEvaluation?.feedbackPerQuestion.find(
                    (f) => f.questionId === q.id
                  );
                  return (
                    <div
                      key={q.id}
                      className="p-4 rounded-lg bg-[#0B0F14] border border-slate-800 space-y-2.5"
                    >
                      <div className="text-xs font-semibold text-slate-200">
                        {qIdx + 1}. {q.question}
                      </div>
                      <div className="space-y-1.5">
                        {q.options.map((opt, optIdx) => (
                          <label
                            key={optIdx}
                            className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer py-1"
                          >
                            <input
                              type="radio"
                              name={`quiz_${q.id}`}
                              checked={selectedAnswers[q.id] === optIdx}
                              onChange={() =>
                                setSelectedAnswers((prev) => ({
                                  ...prev,
                                  [q.id]: optIdx
                                }))
                              }
                              className="accent-[#66E3CB]"
                            />
                            <span>{opt}</span>
                          </label>
                        ))}
                      </div>

                      {feedback && (
                        <div
                          className={`mt-2 p-2.5 rounded border text-xs flex items-start gap-2 ${
                            feedback.isCorrect
                              ? 'bg-[#66E3CB]/10 border-[#66E3CB]/30 text-[#66E3CB]'
                              : 'bg-red-950/40 border-red-800/50 text-red-200'
                          }`}
                        >
                          {feedback.isCorrect ? (
                            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                          ) : (
                            <XCircle className="w-4 h-4 shrink-0 mt-0.5" />
                          )}
                          <div>{feedback.explanation}</div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#A9B8FF] text-[#0B0F14] font-semibold text-xs hover:bg-[#93a5ff] cursor-pointer"
                >
                  Submit Quiz & Update Mastery Progress
                </button>
              </div>
            </form>
          </>
        )}
      </section>
    </div>
  );
};
