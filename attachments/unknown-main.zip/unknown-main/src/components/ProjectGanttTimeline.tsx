import React, { useMemo, useState } from 'react';
import { CalendarRange, Clock, AlertTriangle, CheckCircle2, X } from 'lucide-react';
import {
  computeGanttTimelineLayout,
  type ProjectTask,
  type TaskPriority,
  type TaskStatus
} from '../utils/lorinLogic';

interface ProjectGanttTimelineProps {
  tasks: ProjectTask[];
  onUpdateTask: (
    taskId: string,
    updates: Partial<Pick<ProjectTask, 'priority' | 'status' | 'startDate' | 'dueDate' | 'dueDateLabel'>>
  ) => void;
  compact?: boolean;
}

const STATUS_LABELS: Record<TaskStatus, string> = {
  todo: 'To Do',
  in_progress: 'In Progress',
  done: 'Done'
};

function formatFriendlyDueLabel(dueIso: string, status: TaskStatus): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dueIso)) return dueIso;
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const [, m, d] = dueIso.split('-').map(Number);
  const shortDate = `${months[(m || 1) - 1]} ${d}`;
  return status === 'done' ? `${shortDate} (Done)` : `Due ${shortDate}`;
}

export const ProjectGanttTimeline: React.FC<ProjectGanttTimelineProps> = ({
  tasks,
  onUpdateTask,
  compact = false
}) => {
  const [zoomLevel, setZoomLevel] = useState<'compact' | 'standard' | 'detailed'>('standard');
  const [priorityFilter, setPriorityFilter] = useState<'ALL' | TaskPriority>('ALL');
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);

  const filteredTasks = useMemo(() => {
    const ordered = [...tasks].sort((a, b) => {
      const dateCmp = (a.startDate || '').localeCompare(b.startDate || '');
      return dateCmp !== 0 ? dateCmp : (a.order ?? 0) - (b.order ?? 0);
    });
    if (priorityFilter === 'ALL') return ordered;
    return ordered.filter((t) => t.priority === priorityFilter);
  }, [tasks, priorityFilter]);

  // Anchor "today" to the real browser date in ISO UTC
  const todayIso = useMemo(() => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }, []);

  const layout = useMemo(
    () => computeGanttTimelineLayout(filteredTasks, todayIso),
    [filteredTasks, todayIso]
  );

  const selectedTask = useMemo(
    () => tasks.find((t) => t.taskId === selectedTaskId) || null,
    [tasks, selectedTaskId]
  );

  const minGridWidthPx = useMemo(() => {
    const pxPerDay = zoomLevel === 'compact' ? 38 : zoomLevel === 'detailed' ? 76 : 54;
    return Math.max(540, layout.totalDays * pxPerDay);
  }, [layout.totalDays, zoomLevel]);

  const tickStep = layout.totalDays > 24 ? 3 : layout.totalDays > 14 ? 2 : 1;

  return (
    <div className="bg-[#111821] border border-slate-800/80 rounded-xl p-5 space-y-4">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
            <CalendarRange className="w-4 h-4 text-[#66E3CB]" />
            <span>Project Gantt Timeline</span>
          </div>
          <p className="text-xs text-slate-400 font-mono tabular-nums">
            Window: {layout.timelineStartIso} → {layout.timelineEndIso} ({layout.totalDays} days) · Click any bar to adjust start or due dates
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Priority Filter Segmented Control */}
          <div
            className="flex items-center gap-1 p-0.5 bg-[#0B0F14] border border-slate-800 rounded-lg"
            role="group"
            aria-label="Filter Gantt tasks by priority"
          >
            {(['ALL', 'High', 'Medium', 'Low'] as const).map((level) => (
              <button
                key={level}
                type="button"
                onClick={() => setPriorityFilter(level)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                  priorityFilter === level
                    ? 'bg-[#17212C] text-[#66E3CB]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {level === 'ALL' ? 'All' : level}
              </button>
            ))}
          </div>

          {/* Scale Zoom Control */}
          <div
            className="flex items-center gap-1 p-0.5 bg-[#0B0F14] border border-slate-800 rounded-lg"
            role="group"
            aria-label="Gantt timeline zoom level"
          >
            {(['compact', 'standard', 'detailed'] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setZoomLevel(mode)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium capitalize whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                  zoomLevel === mode
                    ? 'bg-[#17212C] text-[#A9B8FF]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Legend Row (unboxed text, semantic indicator swatches + explicit labels) */}
      <div className="flex flex-wrap items-center gap-x-5 gap-y-1.5 text-xs text-slate-400">
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-xs bg-red-400/80" aria-hidden="true" />
          <span>High Priority</span>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-xs bg-[#E8BE78]/85" aria-hidden="true" />
          <span>Medium Priority</span>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-xs bg-[#66E3CB]/80" aria-hidden="true" />
          <span>Low Priority</span>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500/75" aria-hidden="true" />
          <span>Completed</span>
        </span>
        {layout.todayOffsetPercent !== null && (
          <span className="inline-flex items-center gap-1.5 text-[#A9B8FF] font-mono tabular-nums">
            <span className="w-3 h-0.5 bg-[#A9B8FF]" aria-hidden="true" />
            <span>Today ({todayIso})</span>
          </span>
        )}
      </div>

      {/* Empty State */}
      {layout.bars.length === 0 ? (
        <div className="p-8 rounded-lg bg-[#0B0F14] border border-slate-800 text-center space-y-2">
          <p className="text-sm font-medium text-slate-200">
            No scheduled tasks match this filter.
          </p>
          <p className="text-xs text-slate-400">
            Create a task with start and due dates or switch the priority filter back to All.
          </p>
          {priorityFilter !== 'ALL' && (
            <button
              type="button"
              onClick={() => setPriorityFilter('ALL')}
              className="mt-1 px-3 py-1.5 rounded-lg bg-[#17212C] border border-slate-700 text-xs text-[#66E3CB] cursor-pointer"
            >
              Show All Tasks
            </button>
          )}
        </div>
      ) : (
        /* Split Scrollable Gantt Canvas */
        <div className="border border-slate-800 rounded-lg overflow-hidden bg-[#0B0F14]">
          <div className="overflow-x-auto">
            <div
              className="min-w-[780px]"
              style={{ minWidth: `${260 + minGridWidthPx}px` }}
            >
              {/* Timeline Axis Header */}
              <div className="grid grid-cols-[260px_1fr] border-b border-slate-800 bg-[#111821]">
                <div className="px-3.5 py-2.5 text-xs font-semibold text-slate-300 border-r border-slate-800">
                  Task & Schedule
                </div>
                <div className="relative h-9 select-none">
                  {layout.ticks.map((tick, idx) => {
                    const showLabel = idx % tickStep === 0 && idx < layout.ticks.length - 1;
                    return (
                      <div
                        key={tick.isoDate}
                        className={`absolute top-0 bottom-0 border-l ${
                          tick.isWeekend ? 'border-slate-800/50 bg-slate-900/35' : 'border-slate-800/70'
                        }`}
                        style={{
                          left: `${tick.offsetPercent}%`,
                          width: `${100 / layout.totalDays}%`
                        }}
                      >
                        {showLabel && (
                          <span className="block pl-1.5 pt-2 text-[11px] font-mono tabular-nums text-slate-400 whitespace-nowrap">
                            {tick.label}
                          </span>
                        )}
                      </div>
                    );
                  })}

                  {layout.todayOffsetPercent !== null && (
                    <div
                      className="absolute top-0 bottom-0 w-px bg-[#A9B8FF] z-10 pointer-events-none"
                      style={{ left: `${layout.todayOffsetPercent}%` }}
                      title={`Today: ${todayIso}`}
                    />
                  )}
                </div>
              </div>

              {/* Task Rows */}
              <div className="divide-y divide-slate-800/70">
                {layout.bars.map((bar) => {
                  const { task } = bar;
                  const isSelected = selectedTaskId === task.taskId;

                  const barColorClass =
                    task.status === 'done'
                      ? 'bg-emerald-500/25 border-emerald-400/70 text-emerald-100 hover:bg-emerald-500/35'
                      : task.priority === 'High'
                      ? 'bg-red-500/25 border-red-400/80 text-red-100 hover:bg-red-500/35'
                      : task.priority === 'Medium'
                      ? 'bg-[#E8BE78]/20 border-[#E8BE78]/80 text-[#FDE6B8] hover:bg-[#E8BE78]/30'
                      : 'bg-[#66E3CB]/20 border-[#66E3CB]/80 text-[#CCFBF1] hover:bg-[#66E3CB]/30';

                  return (
                    <div
                      key={task.taskId}
                      className={`grid grid-cols-[260px_1fr] transition-colors ${
                        isSelected ? 'bg-[#17212C]/70' : 'hover:bg-[#111821]/60'
                      }`}
                    >
                      {/* Left Task Info Cell */}
                      <button
                        type="button"
                        onClick={() =>
                          setSelectedTaskId(isSelected ? null : task.taskId)
                        }
                        className="px-3.5 py-2.5 border-r border-slate-800 text-left space-y-1 cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#66E3CB]"
                      >
                        <div className="text-xs font-medium text-slate-100 truncate">
                          {task.title}
                        </div>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono tabular-nums truncate">
                          <span
                            className={
                              task.priority === 'High'
                                ? 'text-red-400'
                                : task.priority === 'Medium'
                                ? 'text-[#E8BE78]'
                                : 'text-[#66E3CB]'
                            }
                          >
                            {task.priority}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{STATUS_LABELS[task.status]}</span>
                          <span aria-hidden="true">·</span>
                          <span>
                            {bar.startIso.slice(5)}→{bar.endIso.slice(5)}
                          </span>
                        </div>
                      </button>

                      {/* Right Timeline Grid Track */}
                      <div className={`relative ${compact ? 'h-12' : 'h-14'} flex items-center`}>
                        {/* Background vertical day grid lines */}
                        {layout.ticks.slice(0, -1).map((tick) => (
                          <div
                            key={`${task.taskId}_${tick.isoDate}`}
                            className={`absolute top-0 bottom-0 border-l pointer-events-none ${
                              tick.isWeekend
                                ? 'border-slate-800/35 bg-slate-900/30'
                                : 'border-slate-800/45'
                            }`}
                            style={{
                              left: `${tick.offsetPercent}%`,
                              width: `${100 / layout.totalDays}%`
                            }}
                          />
                        ))}

                        {/* Today Reference Line */}
                        {layout.todayOffsetPercent !== null && (
                          <div
                            className="absolute top-0 bottom-0 w-px bg-[#A9B8FF]/80 z-10 pointer-events-none"
                            style={{ left: `${layout.todayOffsetPercent}%` }}
                          />
                        )}

                        {/* Interactive Gantt Task Bar */}
                        <button
                          type="button"
                          onClick={() =>
                            setSelectedTaskId(isSelected ? null : task.taskId)
                          }
                          title={`${task.title} (${bar.startIso} to ${bar.endIso} · ${bar.durationDays}d · ${task.priority} priority)`}
                          style={{
                            left: `${bar.leftPercent}%`,
                            width: `${bar.widthPercent}%`
                          }}
                          className={`absolute z-20 h-8 rounded-md border px-2.5 flex items-center justify-between gap-2 text-xs font-medium cursor-pointer transition-colors overflow-hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#66E3CB] ${barColorClass} ${
                            isSelected ? 'ring-1 ring-white/70' : ''
                          }`}
                        >
                          <span className="truncate font-medium">
                            {task.assignee.split(' ')[0]} · {bar.durationDays}d
                          </span>
                          <span className="inline-flex items-center gap-1 font-mono text-[10px] tabular-nums shrink-0 opacity-90">
                            {task.status === 'done' ? (
                              <CheckCircle2 className="w-3 h-3 text-emerald-300" />
                            ) : bar.isOverdue ? (
                              <AlertTriangle className="w-3 h-3 text-red-300" />
                            ) : (
                              <Clock className="w-3 h-3 opacity-75" />
                            )}
                            <span>{bar.isOverdue ? 'Overdue' : STATUS_LABELS[task.status]}</span>
                          </span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Inline Selected Task Schedule Inspector */}
      {selectedTask && (
        <div className="p-4 rounded-xl bg-[#0B0F14] border border-[#66E3CB]/35 space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-xs font-semibold text-[#66E3CB]">
                Adjust Task Schedule & Status
              </div>
              <div className="text-sm font-medium text-slate-100 mt-0.5">
                {selectedTask.title}
              </div>
              <div className="text-xs text-slate-400">
                {selectedTask.assignee} · {selectedTask.milestone} · {selectedTask.estimatedHours}h est.
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSelectedTaskId(null)}
              aria-label="Close schedule inspector"
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#17212C] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <label className="space-y-1 text-xs">
              <span className="text-slate-400 block">Start Date</span>
              <input
                type="date"
                value={selectedTask.startDate || ''}
                onChange={(e) => {
                  const nextStart = e.target.value;
                  if (!nextStart) return;
                  const nextDue =
                    selectedTask.dueDate && selectedTask.dueDate >= nextStart
                      ? selectedTask.dueDate
                      : nextStart;
                  onUpdateTask(selectedTask.taskId, {
                    startDate: nextStart,
                    dueDate: nextDue,
                    dueDateLabel: formatFriendlyDueLabel(nextDue, selectedTask.status)
                  });
                }}
                className="w-full bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-mono tabular-nums text-slate-100"
              />
            </label>

            <label className="space-y-1 text-xs">
              <span className="text-slate-400 block">Due Date</span>
              <input
                type="date"
                value={selectedTask.dueDate || ''}
                min={selectedTask.startDate || undefined}
                onChange={(e) => {
                  const nextDue = e.target.value;
                  if (!nextDue) return;
                  const nextStart =
                    selectedTask.startDate && selectedTask.startDate <= nextDue
                      ? selectedTask.startDate
                      : nextDue;
                  onUpdateTask(selectedTask.taskId, {
                    startDate: nextStart,
                    dueDate: nextDue,
                    dueDateLabel: formatFriendlyDueLabel(nextDue, selectedTask.status)
                  });
                }}
                className="w-full bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-mono tabular-nums text-slate-100"
              />
            </label>

            <label className="space-y-1 text-xs">
              <span className="text-slate-400 block">Priority Level</span>
              <select
                value={selectedTask.priority}
                onChange={(e) =>
                  onUpdateTask(selectedTask.taskId, {
                    priority: e.target.value as TaskPriority
                  })
                }
                className="w-full bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100"
              >
                <option value="High">High Priority</option>
                <option value="Medium">Medium Priority</option>
                <option value="Low">Low Priority</option>
              </select>
            </label>

            <label className="space-y-1 text-xs">
              <span className="text-slate-400 block">Status</span>
              <select
                value={selectedTask.status}
                onChange={(e) => {
                  const nextStatus = e.target.value as TaskStatus;
                  onUpdateTask(selectedTask.taskId, {
                    status: nextStatus,
                    dueDateLabel: formatFriendlyDueLabel(selectedTask.dueDate, nextStatus)
                  });
                }}
                className="w-full bg-[#17212C] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100"
              >
                <option value="todo">To Do</option>
                <option value="in_progress">In Progress</option>
                <option value="done">Done</option>
              </select>
            </label>
          </div>
        </div>
      )}
    </div>
  );
};
