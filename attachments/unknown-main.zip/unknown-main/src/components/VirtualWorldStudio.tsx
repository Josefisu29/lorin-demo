import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  Sparkles,
  Undo2,
  Redo2,
  Download,
  ChevronDown,
  ChevronUp,
  Plus,
  RotateCcw,
  Loader2,
  Sliders
} from 'lucide-react';
import {
  validateSceneSpec,
  applyNaturalLanguageSceneEdit,
  type VirtualWorldSceneSpec,
  type VirtualWorldObjectSpec
} from '../utils/lorinLogic';
import { INITIAL_WORLD_PRESETS } from '../data/seedData';

interface VirtualWorldStudioProps {
  activeScene: VirtualWorldSceneSpec;
  onUpdateScene: (scene: VirtualWorldSceneSpec) => void;
  onLogActivity: (operation: string, module: 'world') => void;
}

/**
 * Procedural Composite 3D Subject Builders (4–9 sub-parts per THREE.Group)
 * Following Three.js & Ultra-Mode Spatial Craft guidelines (zero bare single primitives).
 */
function buildCompositeArchetypeGroup(spec: VirtualWorldObjectSpec): THREE.Group {
  const group = new THREE.Group();
  group.name = spec.id;
  group.userData = { spec };

  const darkMetal = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.82,
    roughness: 0.28
  });
  const brushedSteel = new THREE.MeshStandardMaterial({
    color: 0x64748b,
    metalness: 0.88,
    roughness: 0.22
  });
  const mattePolymer = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    metalness: 0.15,
    roughness: 0.75
  });
  const accentEmissive = new THREE.MeshStandardMaterial({
    color: new THREE.Color(spec.accentColor || '#66E3CB'),
    emissive: new THREE.Color(spec.accentColor || '#66E3CB'),
    emissiveIntensity: 0.55,
    metalness: 0.3,
    roughness: 0.2
  });
  const glassSurface = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(spec.accentColor || '#66E3CB'),
    metalness: 0.1,
    roughness: 0.12,
    transmission: 0.45,
    transparent: true,
    opacity: 0.82
  });

  if (spec.archetype === 'research_workstation') {
    // 1. Desk tabletop
    const top = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.08, 1.05), darkMetal);
    top.position.set(0, 0.78, 0);
    group.add(top);

    // 2 & 3. Left & Right cantilevered legs
    const legGeo = new THREE.BoxGeometry(0.1, 0.76, 0.85);
    const leftLeg = new THREE.Mesh(legGeo, brushedSteel);
    leftLeg.position.set(-0.92, 0.38, 0);
    const rightLeg = new THREE.Mesh(legGeo, brushedSteel);
    rightLeg.position.set(0.92, 0.38, 0);
    group.add(leftLeg, rightLeg);

    // 4. Dual monitor riser arm
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.42, 16), brushedSteel);
    arm.position.set(0, 1.02, -0.32);
    group.add(arm);

    // 5 & 6. Dual angled widescreen displays
    const monGeo = new THREE.BoxGeometry(0.82, 0.46, 0.04);
    const monLeft = new THREE.Mesh(monGeo, mattePolymer);
    monLeft.position.set(-0.44, 1.18, -0.26);
    monLeft.rotation.y = 0.22;
    const monRight = new THREE.Mesh(monGeo, mattePolymer);
    monRight.position.set(0.44, 1.18, -0.26);
    monRight.rotation.y = -0.22;
    group.add(monLeft, monRight);

    // 7. Glowing telemetry screen face
    const screenFace = new THREE.Mesh(new THREE.PlaneGeometry(0.76, 0.4), accentEmissive);
    screenFace.position.set(-0.43, 1.18, -0.235);
    screenFace.rotation.y = 0.22;
    group.add(screenFace);

    // 8. Tactile keyboard deck
    const kb = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.025, 0.2), brushedSteel);
    kb.position.set(0, 0.83, 0.18);
    group.add(kb);
  } else if (spec.archetype === 'assistant_robot') {
    // 1. Mobility base chassis
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.52, 0.24, 24), darkMetal);
    base.position.set(0, 0.14, 0);
    group.add(base);

    // 2. Drive ring trim
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.48, 0.03, 12, 32), accentEmissive);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, 0.14, 0);
    group.add(ring);

    // 3. Articulated torso column
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.32, 0.92, 20), brushedSteel);
    torso.position.set(0, 0.72, 0);
    group.add(torso);

    // 4. Sensor head dome
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 24, 18), darkMetal);
    head.position.set(0, 1.32, 0);
    group.add(head);

    // 5. Optical visor band
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.1, 0.26), accentEmissive);
    visor.position.set(0, 1.34, 0.14);
    group.add(visor);

    // 6 & 7. Dual manipulator arms
    const armGeo = new THREE.CylinderGeometry(0.05, 0.04, 0.56, 12);
    const armL = new THREE.Mesh(armGeo, brushedSteel);
    armL.position.set(-0.34, 0.84, 0.12);
    armL.rotation.x = 0.45;
    const armR = new THREE.Mesh(armGeo, brushedSteel);
    armR.position.set(0.34, 0.84, 0.12);
    armR.rotation.x = 0.45;
    group.add(armL, armR);
  } else if (spec.archetype === 'holographic_array') {
    // 1. Octagonal emitter pedestal
    const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.35, 0.36, 8), darkMetal);
    pedestal.position.set(0, 0.18, 0);
    group.add(pedestal);

    // 2. Emitter lens ring
    const lensRing = new THREE.Mesh(new THREE.TorusGeometry(0.88, 0.05, 16, 40), accentEmissive);
    lensRing.rotation.x = Math.PI / 2;
    lensRing.position.set(0, 0.38, 0);
    group.add(lensRing);

    // 3. Floating icosahedron core
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.48, 1), glassSurface);
    core.position.set(0, 1.35, 0);
    core.name = 'animated_holo_core';
    group.add(core);

    // 4 & 5. Gyroscopic containment rings
    const gyro1 = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.025, 12, 48), accentEmissive);
    gyro1.position.set(0, 1.35, 0);
    gyro1.rotation.x = 0.6;
    gyro1.name = 'animated_gyro_1';
    const gyro2 = new THREE.Mesh(new THREE.TorusGeometry(0.88, 0.02, 12, 48), brushedSteel);
    gyro2.position.set(0, 1.35, 0);
    gyro2.rotation.y = 0.8;
    gyro2.name = 'animated_gyro_2';
    group.add(gyro1, gyro2);
  } else if (spec.archetype === 'solar_collector') {
    // 1. Concrete anchor pad
    const pad = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.14, 1.2), mattePolymer);
    pad.position.set(0, 0.07, 0);
    group.add(pad);

    // 2. Vertical azimuth mast
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 1.35, 16), brushedSteel);
    mast.position.set(0, 0.8, 0);
    group.add(mast);

    // 3. Elevation gimbal housing
    const gimbal = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.24, 0.32), darkMetal);
    gimbal.position.set(0, 1.48, 0);
    group.add(gimbal);

    // 4. Tilted photovoltaic panel frame
    const panelGroup = new THREE.Group();
    panelGroup.position.set(0, 1.56, 0);
    panelGroup.rotation.x = 0.42;

    const frame = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.06, 1.5), brushedSteel);
    const cells = new THREE.Mesh(new THREE.BoxGeometry(2.28, 0.07, 1.38), darkMetal);
    const busbarStrip = new THREE.Mesh(new THREE.BoxGeometry(2.26, 0.08, 0.06), accentEmissive);
    panelGroup.add(frame, cells, busbarStrip);
    group.add(panelGroup);
  } else if (spec.archetype === 'network_rack') {
    // 1. Tall server cabinet enclosure
    const cabinet = new THREE.Mesh(new THREE.BoxGeometry(1.1, 2.3, 1.15), mattePolymer);
    cabinet.position.set(0, 1.15, 0);
    group.add(cabinet);

    // 2 & 3. Brushed aluminum side pillars
    const pillarGeo = new THREE.BoxGeometry(0.08, 2.32, 0.08);
    const pL = new THREE.Mesh(pillarGeo, brushedSteel);
    pL.position.set(-0.52, 1.16, 0.55);
    const pR = new THREE.Mesh(pillarGeo, brushedSteel);
    pR.position.set(0.52, 1.16, 0.55);
    group.add(pL, pR);

    // 4, 5, 6, 7. Blade server LED status strips
    for (let i = 0; i < 4; i++) {
      const bladeLed = new THREE.Mesh(
        new THREE.BoxGeometry(0.84, 0.05, 0.04),
        accentEmissive
      );
      bladeLed.position.set(0, 0.55 + i * 0.42, 0.58);
      group.add(bladeLed);
    }
  } else {
    // observation_column
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 0.3, 16), darkMetal);
    base.position.set(0, 0.15, 0);
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.28, 1.8, 16), brushedSteel);
    shaft.position.set(0, 1.2, 0);
    const beacon = new THREE.Mesh(new THREE.OctahedronGeometry(0.28, 0), accentEmissive);
    beacon.position.set(0, 2.3, 0);
    beacon.name = 'animated_holo_core';
    const collar = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.03, 12, 24), darkMetal);
    collar.rotation.x = Math.PI / 2;
    collar.position.set(0, 2.0, 0);
    group.add(base, shaft, beacon, collar);
  }

  group.position.set(spec.position[0], spec.position[1], spec.position[2]);
  group.rotation.y = spec.rotationY;
  group.scale.setScalar(spec.scale);

  group.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      child.castShadow = true;
      child.receiveShadow = true;
    }
  });

  return group;
}

export const VirtualWorldStudio: React.FC<VirtualWorldStudioProps> = ({
  activeScene,
  onUpdateScene,
  onLogActivity
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const objectRootRef = useRef<THREE.Group | null>(null);
  const keyLightRef = useRef<THREE.DirectionalLight | null>(null);

  const [historyStack, setHistoryStack] = useState<VirtualWorldSceneSpec[]>([
    activeScene
  ]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>(
    activeScene.objects[0]?.id || null
  );
  const [nlCommand, setNlCommand] = useState('');
  const [statusMessage, setStatusMessage] = useState<string>(
    'PBR 3D Studio Ready — Click any assembly to inspect or enter a natural-language command below.'
  );
  const [isGeneratingWorld, setIsGeneratingWorld] = useState(false);
  const [dockCollapsed, setDockCollapsed] = useState(false);

  const pushSceneState = useCallback(
    (nextScene: VirtualWorldSceneSpec, summaryMsg?: string) => {
      const validated = validateSceneSpec(nextScene);
      setHistoryStack((prev) => {
        const sliced = prev.slice(0, historyIndex + 1);
        return [...sliced, validated];
      });
      setHistoryIndex((prev) => prev + 1);
      onUpdateScene(validated);
      if (summaryMsg) setStatusMessage(summaryMsg);
    },
    [historyIndex, onUpdateScene]
  );

  // Initialize Three.js WebGL Viewport & PMREM RoomEnvironment
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 960;
    const height = container.clientHeight || 600;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0f14);
    scene.fog = new THREE.FogExp2(0x0b0f14, activeScene.fogDensity || 0.016);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 160);
    camera.position.set(0, 6.8, 12.5);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;

    // Detect software GL (SwiftShader / llvmpipe) per ultra-mode games_3d.md
    const gl = renderer.getContext();
    const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
    const rendererStr = debugInfo
      ? String(gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL))
      : '';
    const isSoftwareGl = /SwiftShader|llvmpipe|Software/i.test(rendererStr);

    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // PMREM Procedural Studio Reflections (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    // Warm/Cool Three-Point Lighting Setup
    const hemiLight = new THREE.HemisphereLight(0xa9b8ff, 0x17212c, 0.85);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(
      0xfff3e0,
      activeScene.keyLightIntensity || 2.4
    );
    keyLight.position.set(9, 15, 8);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.0005;
    scene.add(keyLight);
    keyLightRef.current = keyLight;

    const rimLight = new THREE.DirectionalLight(0x66e3cb, 0.9);
    rimLight.position.set(-10, 8, -9);
    scene.add(rimLight);

    // Ground Receiver Plane & Spatial Reference Grid
    const floorGeo = new THREE.PlaneGeometry(64, 64);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x0d131a,
      metalness: 0.35,
      roughness: 0.72
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    const grid = new THREE.GridHelper(32, 32, 0x66e3cb, 0x1e293b);
    grid.position.y = 0.01;
    scene.add(grid);

    const objectRoot = new THREE.Group();
    scene.add(objectRoot);
    objectRootRef.current = objectRoot;

    // OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 - 0.03;
    controls.minDistance = 3;
    controls.maxDistance = 34;
    controls.target.set(0, 1.1, 0);
    controls.update();

    // Raycaster for Interactive Object Selection
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const handlePointerDown = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(pointer, camera);
      const intersects = raycaster.intersectObjects(objectRoot.children, true);
      if (intersects.length > 0) {
        let curr: THREE.Object3D | null = intersects[0].object;
        while (curr && curr.parent !== objectRoot) {
          curr = curr.parent;
        }
        if (curr && curr.userData?.spec) {
          const pickedSpec = curr.userData.spec as VirtualWorldObjectSpec;
          setSelectedObjectId(pickedSpec.id);
          setStatusMessage(
            `Selected "${pickedSpec.name}" [${pickedSpec.archetype}] — ${pickedSpec.interactiveLabel}`
          );
        }
      }
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDown);

    // ResizeObserver for responsive container sizing
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = entry.contentRect.width;
        const h = entry.contentRect.height;
        if (w > 0 && h > 0) {
          camera.aspect = w / h;
          camera.updateProjectionMatrix();
          renderer.setSize(w, h);
        }
      }
    });
    resizeObserver.observe(container);

    let animFrameId = 0;
    const startTime = performance.now();

    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const elapsed = (performance.now() - startTime) * 0.001;

      objectRoot.traverse((obj) => {
        if (obj.name === 'animated_holo_core') {
          obj.rotation.y = elapsed * 0.85;
          obj.position.y = 1.35 + Math.sin(elapsed * 2.1) * 0.06;
        } else if (obj.name === 'animated_gyro_1') {
          obj.rotation.z = elapsed * 0.6;
        } else if (obj.name === 'animated_gyro_2') {
          obj.rotation.x = -elapsed * 0.5;
        }
      });

      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animFrameId);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      controls.dispose();
      envTarget.dispose();
      renderer.dispose();
    };
  }, []);

  // Sync Scene Specification to Three.js Object Hierarchy
  useEffect(() => {
    const scene = sceneRef.current;
    const objectRoot = objectRootRef.current;
    if (!scene || !objectRoot) return;

    const bgHex =
      activeScene.environmentPreset === 'solar_array'
        ? 0x0f1722
        : activeScene.environmentPreset === 'observatory'
        ? 0x070b12
        : activeScene.environmentPreset === 'classroom'
        ? 0x101824
        : 0x0b0f14;

    scene.background = new THREE.Color(bgHex);
    scene.fog = new THREE.FogExp2(bgHex, activeScene.fogDensity || 0.016);

    if (keyLightRef.current) {
      keyLightRef.current.intensity = activeScene.keyLightIntensity || 2.4;
    }

    // Clear previous meshes cleanly
    while (objectRoot.children.length > 0) {
      const child = objectRoot.children[0];
      objectRoot.remove(child);
    }

    for (const objSpec of activeScene.objects) {
      const group = buildCompositeArchetypeGroup(objSpec);
      objectRoot.add(group);
    }
  }, [activeScene]);

  const handleApplyLocalNaturalLanguageCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nlCommand.trim()) return;
    const { updatedScene, summary } = applyNaturalLanguageSceneEdit(
      activeScene,
      nlCommand
    );
    pushSceneState(updatedScene, summary);
    setNlCommand('');
    onLogActivity(`Edited 3D scene via command: "${summary}"`, 'world');
  };

  const handleSynthesizeWithGemini = async () => {
    if (!nlCommand.trim() || isGeneratingWorld) return;
    setIsGeneratingWorld(true);
    setStatusMessage('Synthesizing 3D spatial layout with gemini-3.8-flash...');
    try {
      const res = await fetch('/api/gemini/world-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: nlCommand.trim() })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Scene synthesis failed');

      const validated = validateSceneSpec({
        ...data,
        worldId: `world_${Date.now()}`
      });
      pushSceneState(
        validated,
        `Generated "${validated.name}" (${validated.objects.length} composite assemblies).`
      );
      setNlCommand('');
      onLogActivity(`Synthesized 3D world "${validated.name}" via Gemini`, 'world');
    } catch {
      const { updatedScene, summary } = applyNaturalLanguageSceneEdit(
        activeScene,
        nlCommand
      );
      pushSceneState(updatedScene, summary);
    } finally {
      setIsGeneratingWorld(false);
    }
  };

  const handleUndo = () => {
    if (historyIndex <= 0) return;
    const nextIdx = historyIndex - 1;
    setHistoryIndex(nextIdx);
    onUpdateScene(historyStack[nextIdx]);
    setStatusMessage('Reverted to previous scene state.');
  };

  const handleRedo = () => {
    if (historyIndex >= historyStack.length - 1) return;
    const nextIdx = historyIndex + 1;
    setHistoryIndex(nextIdx);
    onUpdateScene(historyStack[nextIdx]);
    setStatusMessage('Restored scene state.');
  };

  const handleExportSceneJson = () => {
    const blob = new Blob([JSON.stringify(activeScene, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activeScene.name.replace(/\s+/g, '_')}.scene.json`;
    a.click();
    URL.revokeObjectURL(url);
    onLogActivity(`Exported 3D scene specification "${activeScene.name}"`, 'world');
  };

  const selectedObj =
    activeScene.objects.find((o) => o.id === selectedObjectId) ||
    activeScene.objects[0];

  return (
    <div className="relative w-full h-[calc(100vh-8.5rem)] min-h-[600px] rounded-xl overflow-hidden border border-slate-800 bg-[#0B0F14]">
      {/* Full-Viewport 3D WebGL Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top-Left Compact Scene Header & Environment Preset Selector (No backdrop-filter over WebGL) */}
      <div className="absolute top-3.5 left-3.5 z-10 bg-[#111821]/95 border border-slate-800 rounded-xl p-3.5 max-w-md shadow-xl space-y-2">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h1 className="text-sm font-semibold text-slate-100">
              {activeScene.name}
            </h1>
            <p className="text-[11px] text-slate-400 font-mono">
              Preset: {activeScene.environmentPreset} · {activeScene.objects.length} Composite Assemblies
            </p>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={handleUndo}
              disabled={historyIndex <= 0}
              title="Undo"
              className="p-1.5 rounded bg-[#17212C] text-slate-300 hover:text-[#66E3CB] disabled:opacity-35 cursor-pointer"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleRedo}
              disabled={historyIndex >= historyStack.length - 1}
              title="Redo"
              className="p-1.5 rounded bg-[#17212C] text-slate-300 hover:text-[#66E3CB] disabled:opacity-35 cursor-pointer"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleExportSceneJson}
              title="Export Scene JSON"
              className="p-1.5 rounded bg-[#17212C] text-slate-300 hover:text-[#66E3CB] cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {(
            ['laboratory', 'solar_array', 'observatory', 'classroom'] as const
          ).map((presetKey) => (
            <button
              key={presetKey}
              type="button"
              onClick={() =>
                pushSceneState(
                  INITIAL_WORLD_PRESETS[presetKey],
                  `Loaded ${presetKey} spatial preset.`
                )
              }
              className={`px-2.5 py-1 rounded text-[11px] font-medium cursor-pointer border ${
                activeScene.environmentPreset === presetKey
                  ? 'bg-[#66E3CB]/20 border-[#66E3CB] text-[#66E3CB]'
                  : 'bg-[#17212C] border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              {presetKey.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Top-Right Selected Assembly Inspector */}
      {selectedObj && (
        <div className="absolute top-3.5 right-3.5 z-10 bg-[#111821]/95 border border-slate-800 rounded-xl p-3.5 w-72 shadow-xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono text-[#66E3CB] uppercase">
              Inspector · {selectedObj.archetype}
            </span>
            <Sliders className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <div className="text-xs font-semibold text-slate-100">
            {selectedObj.name}
          </div>
          <div className="text-[11px] text-slate-400">
            {selectedObj.interactiveLabel}
          </div>
          <div className="grid grid-cols-3 gap-1.5 text-[11px] font-mono text-slate-300 pt-1">
            <div className="bg-[#0B0F14] px-2 py-1 rounded">
              X: {selectedObj.position[0]}
            </div>
            <div className="bg-[#0B0F14] px-2 py-1 rounded">
              Y: {selectedObj.position[1]}
            </div>
            <div className="bg-[#0B0F14] px-2 py-1 rounded">
              Z: {selectedObj.position[2]}
            </div>
          </div>
        </div>
      )}

      {/* Collapsible Bottom Control Dock (Strictly solid high-opacity bg-[#111821]/95, no backdrop-filter) */}
      <div className="absolute bottom-3.5 left-3.5 right-3.5 z-10 bg-[#111821]/95 border border-slate-800 rounded-xl shadow-2xl">
        <div className="px-4 py-2 border-b border-slate-800/80 flex items-center justify-between">
          <span className="text-xs text-slate-300 truncate">{statusMessage}</span>
          <button
            type="button"
            onClick={() => setDockCollapsed((prev) => !prev)}
            className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            <span>{dockCollapsed ? 'Expand Controls' : 'Collapse Dock'}</span>
            {dockCollapsed ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </button>
        </div>

        {!dockCollapsed && (
          <div className="p-3.5 space-y-2.5">
            <div className="flex flex-wrap items-center gap-2">
              {[
                { label: '+ Assistant Robot', cmd: 'add an assistant robot' },
                { label: '+ Research Desk', cmd: 'add a research workstation' },
                { label: '+ Holographic Core', cmd: 'add a holographic core' },
                { label: '+ Solar Collector', cmd: 'add a solar collector' },
                { label: '+ Server Rack', cmd: 'add a server rack' },
                { label: 'Remove Last', cmd: 'remove last object' }
              ].map((btn) => (
                <button
                  key={btn.label}
                  type="button"
                  onClick={() => {
                    const { updatedScene, summary } = applyNaturalLanguageSceneEdit(
                      activeScene,
                      btn.cmd
                    );
                    pushSceneState(updatedScene, summary);
                  }}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#17212C] hover:bg-slate-800 text-xs text-slate-200 border border-slate-700 cursor-pointer"
                >
                  <Plus className="w-3 h-3 text-[#66E3CB]" />
                  <span>{btn.label}</span>
                </button>
              ))}
            </div>

            <form
              onSubmit={handleApplyLocalNaturalLanguageCommand}
              className="flex flex-wrap items-center gap-2"
            >
              <input
                type="text"
                value={nlCommand}
                onChange={(e) => setNlCommand(e.target.value)}
                placeholder="Natural-language scene command (e.g., 'Add an assistant robot and make lighting brighter' or 'Create a deep-sky observatory')..."
                className="flex-1 min-w-[240px] bg-[#0B0F14] border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#66E3CB]"
              />
              <button
                type="submit"
                disabled={!nlCommand.trim()}
                className="px-3.5 py-2 rounded-lg bg-[#66E3CB] text-[#0B0F14] font-semibold text-xs hover:bg-[#52cdb5] disabled:opacity-40 cursor-pointer"
              >
                Apply Instant Edit
              </button>
              <button
                type="button"
                onClick={handleSynthesizeWithGemini}
                disabled={!nlCommand.trim() || isGeneratingWorld}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#A9B8FF] text-[#0B0F14] font-semibold text-xs hover:bg-[#93a5ff] disabled:opacity-40 cursor-pointer"
              >
                {isGeneratingWorld ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>Synthesize Full World (Gemini)</span>
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
