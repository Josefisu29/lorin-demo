import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  classifyIntentAndSelectModel,
  chunkDocumentText,
  retrieveRelevantChunks,
  compareDocuments,
  evaluateQuizSubmission,
  calculateUpdatedLearningPathMetrics,
  validateSceneSpec,
  applyNaturalLanguageSceneEdit,
  sortAndFilterProjectTasks,
  reorderAndMoveProjectTask,
  computeGanttTimelineLayout,
  computeProjectDashboardMetrics,
  evaluateFirestoreRuleInvariant,
  type ProjectTask
} from './lorinLogic.ts';

describe('LORIN Pure Domain Logic & Security Rules Test Suite', () => {
  describe('1. Intent Classification & Model Routing', () => {
    it('routes deep architectural & security audit queries to gemini-4-carbon with High Thinking', () => {
      const res = classifyIntentAndSelectModel(
        'Perform a formal security audit and threat model of our distributed microservice architecture'
      );
      assert.equal(res.recommendedModel, 'gemini-4-carbon');
      assert.equal(res.useHighThinking, true);
      assert.ok(res.activePerspectives.includes('Lena'));
      assert.ok(res.activePerspectives.includes('Nolan'));
    });

    it('routes live web research queries to gemini-3.8-flash with Google Search Grounding', () => {
      const res = classifyIntentAndSelectModel(
        'Search for the latest 2026 official docs on WebGPU browser support and cite sources'
      );
      assert.equal(res.recommendedModel, 'gemini-3.8-flash');
      assert.equal(res.useSearchGrounding, true);
      assert.equal(res.useMapsGrounding, false);
    });

    it('routes geospatial & location queries to gemini-3.8-flash with Google Maps Grounding', () => {
      const res = classifyIntentAndSelectModel(
        'Show coordinates and transit directions to research laboratories nearby'
      );
      assert.equal(res.recommendedModel, 'gemini-3.8-flash');
      assert.equal(res.useMapsGrounding, true);
      assert.equal(res.useSearchGrounding, false);
    });

    it('routes software engineering & attachment tasks to gemini-4-argon', () => {
      const codeRes = classifyIntentAndSelectModel(
        'Refactor this TypeScript React component and add unit test assertions'
      );
      assert.equal(codeRes.recommendedModel, 'gemini-4-argon');

      const visionRes = classifyIntentAndSelectModel('What is broken on this PCB?', {
        hasAttachment: true
      });
      assert.equal(visionRes.recommendedModel, 'gemini-4-argon');
      assert.equal(visionRes.intent, 'vision_multimodal');
    });

    it('routes short conversational greetings to low-latency gemini-3.1-flash-lite', () => {
      const res = classifyIntentAndSelectModel('Good morning LORIN, ready to begin.');
      assert.equal(res.recommendedModel, 'gemini-3.1-flash-lite');
    });
  });

  describe('2. Knowledge Vault RAG Chunking, Retrieval & Diff Comparison', () => {
    const sampleDoc = [
      'LORIN Security Architecture Overview.',
      'All private credentials and API keys must remain strictly on the backend Express server.',
      'Firestore collections enforce owner-scoped access and split-collection PII isolation.',
      'The Virtual World Studio renders composite PBR Three.js groups with RoomEnvironment reflections.'
    ].join('\n\n');

    it('chunks document text deterministically and preserves boundaries', () => {
      const chunks = chunkDocumentText('doc_1', 'security_spec.md', sampleDoc, 140, 30);
      assert.ok(chunks.length >= 2);
      assert.equal(chunks[0].documentId, 'doc_1');
      assert.equal(chunks[0].filename, 'security_spec.md');
      assert.ok(chunks[0].tokenEstimate > 5);
    });

    it('throws if maxChunkChars <= overlapChars', () => {
      assert.throws(() => chunkDocumentText('doc_1', 'a.txt', 'hello world', 50, 50));
    });

    it('retrieves and ranks relevant chunks with matched terms', () => {
      const chunks = chunkDocumentText('doc_1', 'security_spec.md', sampleDoc, 120, 20);
      const hits = retrieveRelevantChunks('How does Firestore enforce PII isolation?', chunks, 3);
      assert.ok(hits.length >= 1);
      assert.ok(hits[0].matchedTerms.includes('firestore') || hits[0].matchedTerms.includes('isolation'));
    });

    it('compares two documents and computes similarity and line diffs', () => {
      const cmp = compareDocuments(
        'v1.md',
        'Line one security policy\nLine two backend auth',
        'v2.md',
        'Line one security policy\nLine three zero trust rules'
      );
      assert.ok(cmp.sharedConcepts.includes('security'));
      assert.equal(cmp.lineAdditions, 1);
      assert.equal(cmp.lineRemovals, 1);
      assert.ok(cmp.similarityRatio > 0 && cmp.similarityRatio < 1);
    });
  });

  describe('3. AI Learning Laboratory Grading & Progress', () => {
    const questions = [
      {
        id: 'q1',
        question: 'Which model handles high-thinking architectural reasoning?',
        options: ['gemini-3.1-flash-lite', 'gemini-4-carbon', 'gemini-3.8-flash-tts'],
        correctIndex: 1,
        explanation: 'gemini-4-carbon supports ThinkingLevel.HIGH for deep reasoning.'
      },
      {
        id: 'q2',
        question: 'Where are Gemini API keys stored?',
        options: ['localStorage', 'Server-side environment variables', 'URL query params'],
        correctIndex: 1,
        explanation: 'Keys must stay strictly server-side.'
      }
    ];

    it('grades quiz submissions accurately and computes pass/fail status', () => {
      const passResult = evaluateQuizSubmission(questions, { q1: 1, q2: 1 });
      assert.equal(passResult.scorePercentage, 100);
      assert.equal(passResult.passed, true);

      const failResult = evaluateQuizSubmission(questions, { q1: 0, q2: 1 });
      assert.equal(failResult.scorePercentage, 50);
      assert.equal(failResult.passed, false);
    });

    it('updates learning path completion status when all lessons are finished', () => {
      const updated = calculateUpdatedLearningPathMetrics(3, 4, 80, 100, true);
      assert.equal(updated.completedLessons, 4);
      assert.equal(updated.status, 'completed');
      assert.equal(updated.averageScore, 85);
    });
  });

  describe('4. Virtual World Studio Scene Validation & Natural Language Edits', () => {
    it('clamps out-of-bounds positions, scales, and validates presets', () => {
      const validated = validateSceneSpec({
        name: 'Test Lab',
        environmentPreset: 'laboratory',
        objects: [
          {
            id: 'o1',
            name: 'Overscaled Unit',
            archetype: 'assistant_robot',
            position: [999, -20, 4],
            rotationY: 0,
            scale: 99,
            accentColor: '#66E3CB',
            interactiveLabel: 'Robot'
          }
        ]
      });
      assert.equal(validated.objects[0].position[0], 24);
      assert.equal(validated.objects[0].position[1], 0);
      assert.equal(validated.objects[0].scale, 2.5);
    });

    it('applies natural language scene commands to add composite objects and switch presets', () => {
      const initial = validateSceneSpec({ name: 'Base Scene', objects: [] });
      const { updatedScene, summary } = applyNaturalLanguageSceneEdit(
        initial,
        'Switch to observatory and add an assistant robot and a holographic core'
      );
      assert.equal(updatedScene.environmentPreset, 'observatory');
      assert.equal(updatedScene.objects.length, 2);
      assert.ok(summary.includes('observatory'));
    });
  });

  describe('5. Project Management Task Prioritization, Drag-and-Drop & Gantt Timeline', () => {
    const sampleTasks: ProjectTask[] = [
      {
        taskId: 't1',
        projectId: 'proj_lorin_core',
        title: 'Write unit tests',
        assignee: 'Iris',
        priority: 'Low',
        status: 'done',
        milestone: 'M1',
        startDate: '2026-11-15',
        dueDate: '2026-11-18',
        dueDateLabel: 'Nov 18',
        estimatedHours: 4,
        order: 0,
        comments: []
      },
      {
        taskId: 't2',
        projectId: 'proj_lorin_core',
        title: 'Audit Firestore rules',
        assignee: 'Lena',
        priority: 'High',
        status: 'in_progress',
        milestone: 'M1',
        startDate: '2026-11-18',
        dueDate: '2026-11-22',
        dueDateLabel: 'Nov 22',
        estimatedHours: 8,
        order: 1,
        comments: []
      },
      {
        taskId: 't3',
        projectId: 'proj_lorin_core',
        title: 'Optimize PMREM reflections',
        assignee: 'Nolan',
        priority: 'Medium',
        status: 'todo',
        milestone: 'M2',
        startDate: '2026-11-21',
        dueDate: '2026-11-27',
        dueDateLabel: 'Nov 27',
        estimatedHours: 6,
        order: 2,
        comments: []
      }
    ];

    it('sorts tasks by priority (High -> Medium -> Low) and filters by priority level', () => {
      const sorted = sortAndFilterProjectTasks(sampleTasks, { sortBy: 'priority_desc' });
      assert.equal(sorted[0].priority, 'High');
      assert.equal(sorted[1].priority, 'Medium');
      assert.equal(sorted[2].priority, 'Low');

      const highOnly = sortAndFilterProjectTasks(sampleTasks, { priorityFilter: 'High' });
      assert.equal(highOnly.length, 1);
      assert.equal(highOnly[0].taskId, 't2');
    });

    it('computes project dashboard completion rate, priority breakdown, and health metrics', () => {
      const metrics = computeProjectDashboardMetrics(sampleTasks);
      assert.equal(metrics.totalTasks, 3);
      assert.equal(metrics.completedTasks, 1);
      assert.equal(metrics.completionRatePercent, 33);
      assert.equal(metrics.priorityCounts.High, 1);
      assert.equal(metrics.highPriorityOpenCount, 1);
      assert.equal(metrics.workloadByAssignee.length, 3);
    });

    it('reorders tasks and updates status & priority via drag-and-drop helper', () => {
      const moved = reorderAndMoveProjectTask(sampleTasks, 't3', {
        status: 'in_progress',
        priority: 'High',
        targetTaskId: 't2',
        insertPosition: 'before'
      });
      assert.equal(moved.length, 3);
      const t3Index = moved.findIndex((t) => t.taskId === 't3');
      const t2Index = moved.findIndex((t) => t.taskId === 't2');
      assert.ok(t3Index < t2Index);
      assert.equal(moved[t3Index].status, 'in_progress');
      assert.equal(moved[t3Index].priority, 'High');
      assert.deepEqual(
        moved.map((t) => t.order),
        [0, 1, 2]
      );
    });

    it('computes normalized Gantt timeline bar geometry, duration days, and overdue flags', () => {
      const layout = computeGanttTimelineLayout(sampleTasks, '2026-11-23');
      assert.equal(layout.bars.length, 3);
      assert.ok(layout.totalDays >= 12);
      assert.ok(layout.todayOffsetPercent !== null && layout.todayOffsetPercent > 0 && layout.todayOffsetPercent < 100);

      const t1Bar = layout.bars.find((b) => b.task.taskId === 't1')!;
      const t2Bar = layout.bars.find((b) => b.task.taskId === 't2')!;
      const t3Bar = layout.bars.find((b) => b.task.taskId === 't3')!;

      assert.equal(t1Bar.durationDays, 4);
      assert.equal(t1Bar.isOverdue, false); // done task is never overdue
      assert.equal(t2Bar.isOverdue, true); // in_progress due Nov 22 vs ref Nov 23
      assert.equal(t3Bar.isActiveToday, true); // Nov 21..27 includes Nov 23
      assert.ok(t1Bar.leftPercent < t2Bar.leftPercent);
      assert.ok(t2Bar.leftPercent < t3Bar.leftPercent);
    });
  });

  describe('6. Firestore Security Rules — The Dirty Dozen Adversarial Payloads', () => {
    const now = '2026-11-11T12:00:00.000Z';
    const validProject = {
      projectId: 'proj_101',
      ownerId: 'user_alice',
      name: 'LORIN Core System',
      description: 'Private engineering intelligence system',
      status: 'active',
      objectives: ['Complete Phase 1 security validation'],
      createdAt: now,
      updatedAt: now
    };

    it('1. Blocks unauthenticated access across collections', () => {
      const res = evaluateFirestoreRuleInvariant('projects', 'get', 'proj_101', null, {
        auth: null,
        requestTimeIso: now
      });
      assert.equal(res.allowed, false);
    });

    it('2. Blocks writes from unverified email accounts (email_verified == false)', () => {
      const res = evaluateFirestoreRuleInvariant('projects', 'create', 'proj_101', validProject, {
        auth: { uid: 'user_alice', emailVerified: false },
        requestTimeIso: now
      });
      assert.equal(res.allowed, false);
      assert.ok(res.reason.includes('email_verified'));
    });

    it('3. Blocks undeclared extra fields (hasOnly schema enforcement)', () => {
      const res = evaluateFirestoreRuleInvariant(
        'projects',
        'create',
        'proj_101',
        { ...validProject, isAdmin: true },
        { auth: { uid: 'user_alice', emailVerified: true }, requestTimeIso: now }
      );
      assert.equal(res.allowed, false);
    });

    it('4. Blocks string buffer overflow beyond blueprint maxLength', () => {
      const res = evaluateFirestoreRuleInvariant(
        'projects',
        'create',
        'proj_101',
        { ...validProject, name: 'X'.repeat(121) },
        { auth: { uid: 'user_alice', emailVerified: true }, requestTimeIso: now }
      );
      assert.equal(res.allowed, false);
    });

    it('5. Blocks path-to-data parity mismatch (projectId != docId)', () => {
      const res = evaluateFirestoreRuleInvariant(
        'projects',
        'create',
        'proj_999',
        validProject,
        { auth: { uid: 'user_alice', emailVerified: true }, requestTimeIso: now }
      );
      assert.equal(res.allowed, false);
    });

    it('6. Blocks ownership hijacking (ownerId != request.auth.uid)', () => {
      const res = evaluateFirestoreRuleInvariant(
        'projects',
        'create',
        'proj_101',
        { ...validProject, ownerId: 'user_bob' },
        { auth: { uid: 'user_alice', emailVerified: true }, requestTimeIso: now }
      );
      assert.equal(res.allowed, false);
    });

    it('7. Blocks forged timestamps (createdAt != request.time)', () => {
      const res = evaluateFirestoreRuleInvariant(
        'projects',
        'create',
        'proj_101',
        { ...validProject, createdAt: '2020-01-01T00:00:00.000Z' },
        { auth: { uid: 'user_alice', emailVerified: true }, requestTimeIso: now }
      );
      assert.equal(res.allowed, false);
    });

    it('8. Blocks modifications to terminal Archived projects (State Machine lock)', () => {
      const res = evaluateFirestoreRuleInvariant(
        'projects',
        'update',
        'proj_101',
        { ...validProject, name: 'Renamed' },
        {
          auth: { uid: 'user_alice', emailVerified: true },
          requestTimeIso: now,
          existingDoc: { ...validProject, status: 'Archived' }
        }
      );
      assert.equal(res.allowed, false);
      assert.ok(res.reason.includes('Archived'));
    });

    it('9. Blocks mutating immutable createdAt or ownerId on update', () => {
      const res = evaluateFirestoreRuleInvariant(
        'projects',
        'update',
        'proj_101',
        { ...validProject, createdAt: '2025-01-01T00:00:00.000Z' },
        {
          auth: { uid: 'user_alice', emailVerified: true },
          requestTimeIso: now,
          existingDoc: validProject
        }
      );
      assert.equal(res.allowed, false);
    });

    it('10. Blocks user profile enumeration (allow list: if false on /users)', () => {
      const res = evaluateFirestoreRuleInvariant('users', 'list', '', null, {
        auth: { uid: 'user_alice', emailVerified: true },
        requestTimeIso: now
      });
      assert.equal(res.allowed, false);
    });

    it('11. Blocks subcollection message creation if parent conversation is owned by another user', () => {
      const res = evaluateFirestoreRuleInvariant(
        'messages',
        'create',
        'msg_1',
        { messageId: 'msg_1' },
        {
          auth: { uid: 'user_alice', emailVerified: true },
          requestTimeIso: now,
          parentDoc: { conversationId: 'conv_1', ownerId: 'user_bob' }
        }
      );
      assert.equal(res.allowed, false);
    });

    it('12. Blocks malformed document IDs containing path traversal characters', () => {
      const res = evaluateFirestoreRuleInvariant(
        'projects',
        'create',
        '../bad$id',
        validProject,
        { auth: { uid: 'user_alice', emailVerified: true }, requestTimeIso: now }
      );
      assert.equal(res.allowed, false);
    });
  });
});
