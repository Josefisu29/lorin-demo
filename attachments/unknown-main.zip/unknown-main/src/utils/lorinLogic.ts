/**
 * Pure domain logic and security invariant validators for LORIN
 * Unified Multimodal AI Intelligence, Knowledge, Learning and Virtual Creation Platform
 */

export type LorinModelAlias =
  | 'gemini-3.1-flash-lite'
  | 'gemini-3.8-flash'
  | 'gemini-4-argon'
  | 'gemini-4-carbon'
  | 'gemini-3.8-flash-tts'
  | 'gemini-3.8-live'
  | 'gemini-omni-1.2-flash';

export type SpecialistPerspective = 'Lena' | 'Owen' | 'Riley' | 'Iris' | 'Nolan';

export type TaskPriority = 'High' | 'Medium' | 'Low';
export type TaskStatus = 'todo' | 'in_progress' | 'done';

export interface TaskComment {
  commentId: string;
  taskId: string;
  authorName: string;
  content: string;
  createdAtLabel: string;
}

export interface ProjectTask {
  taskId: string;
  projectId: string;
  title: string;
  assignee: string;
  priority: TaskPriority;
  status: TaskStatus;
  milestone: string;
  startDate: string; // ISO YYYY-MM-DD
  dueDate: string; // ISO YYYY-MM-DD
  dueDateLabel: string;
  estimatedHours: number;
  order?: number;
  comments: TaskComment[];
}

export interface GanttBarLayout {
  task: ProjectTask;
  startIso: string;
  endIso: string;
  durationDays: number;
  leftPercent: number;
  widthPercent: number;
  isOverdue: boolean;
  isActiveToday: boolean;
}

export interface GanttTimelineTick {
  isoDate: string;
  label: string;
  offsetPercent: number;
  isWeekend: boolean;
}

export interface GanttTimelineLayout {
  timelineStartIso: string;
  timelineEndIso: string;
  totalDays: number;
  todayOffsetPercent: number | null;
  ticks: GanttTimelineTick[];
  bars: GanttBarLayout[];
}

export interface DashboardWidgetConfig {
  widgetId:
    | 'completion_rate'
    | 'priority_breakdown'
    | 'upcoming_milestones'
    | 'assigned_workloads'
    | 'project_health'
    | 'task_board'
    | 'gantt_timeline'
    | 'shared_doc'
    | 'team_chat';
  title: string;
  visible: boolean;
  order: number;
}

export interface ProjectDashboardMetrics {
  totalTasks: number;
  completedTasks: number;
  inProgressTasks: number;
  todoTasks: number;
  completionRatePercent: number;
  highPriorityOpenCount: number;
  priorityCounts: Record<TaskPriority, number>;
  workloadByAssignee: Array<{ assignee: string; hours: number; taskCount: number }>;
  healthScore: number;
  healthStatus: 'Optimal' | 'Attention Required' | 'At Risk';
}

export interface IntentClassificationResult {
  intent:
    | 'quick_conversational'
    | 'deep_reasoning'
    | 'software_engineering'
    | 'research_search'
    | 'spatial_maps'
    | 'vision_multimodal'
    | 'world_generation';
  recommendedModel: LorinModelAlias;
  useHighThinking: boolean;
  useSearchGrounding: boolean;
  useMapsGrounding: boolean;
  activePerspectives: SpecialistPerspective[];
  rationale: string;
}

export interface DocumentChunk {
  chunkId: string;
  documentId: string;
  filename: string;
  chunkIndex: number;
  content: string;
  startOffset: number;
  endOffset: number;
  tokenEstimate: number;
}

export interface RetrievedPassage {
  chunk: DocumentChunk;
  relevanceScore: number;
  matchedTerms: string[];
}

export interface DocumentComparisonResult {
  docAName: string;
  docBName: string;
  sharedConcepts: string[];
  uniqueToA: string[];
  uniqueToB: string[];
  similarityRatio: number;
  lineAdditions: number;
  lineRemovals: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizSubmissionEvaluation {
  totalQuestions: number;
  correctCount: number;
  scorePercentage: number;
  passed: boolean;
  feedbackPerQuestion: Array<{
    questionId: string;
    selectedIndex: number;
    correctIndex: number;
    isCorrect: boolean;
    explanation: string;
  }>;
}

export interface VirtualWorldObjectSpec {
  id: string;
  name: string;
  archetype:
    | 'research_workstation'
    | 'assistant_robot'
    | 'holographic_array'
    | 'solar_collector'
    | 'network_rack'
    | 'observation_column';
  position: [number, number, number];
  rotationY: number;
  scale: number;
  accentColor: string;
  interactiveLabel: string;
}

export interface VirtualWorldSceneSpec {
  worldId: string;
  name: string;
  description: string;
  environmentPreset: 'laboratory' | 'classroom' | 'observatory' | 'solar_array';
  fogDensity: number;
  keyLightIntensity: number;
  objects: VirtualWorldObjectSpec[];
}

/**
 * 1. Intent Classification & Model Routing (LORIN Spec Part 3 & Feature Blocks)
 */
export function classifyIntentAndSelectModel(
  prompt: string,
  options?: {
    forceHighThinking?: boolean;
    forceSearchGrounding?: boolean;
    forceMapsGrounding?: boolean;
    hasAttachment?: boolean;
  }
): IntentClassificationResult {
  const normalized = prompt.trim().toLowerCase();

  if (options?.hasAttachment) {
    return {
      intent: 'vision_multimodal',
      recommendedModel: 'gemini-4-argon',
      useHighThinking: false,
      useSearchGrounding: false,
      useMapsGrounding: false,
      activePerspectives: ['Iris', 'Nolan'],
      rationale: 'Multimodal visual/video attachment routed to gemini-4-argon for detailed structural inspection.'
    };
  }

  if (
    options?.forceMapsGrounding ||
    /\b(map|nearby|coordinates|latitude|longitude|directions|location|transit|geospatial|route to|near me)\b/i.test(
      normalized
    )
  ) {
    return {
      intent: 'spatial_maps',
      recommendedModel: 'gemini-3.8-flash',
      useHighThinking: false,
      useSearchGrounding: false,
      useMapsGrounding: true,
      activePerspectives: ['Iris', 'Owen'],
      rationale: 'Geospatial and place query routed to gemini-3.8-flash with Google Maps Grounding.'
    };
  }

  if (
    options?.forceSearchGrounding ||
    /\b(latest|current news|recent|2025|2026|cite sources|verify online|live web|search for|official docs)\b/i.test(
      normalized
    )
  ) {
    return {
      intent: 'research_search',
      recommendedModel: 'gemini-3.8-flash',
      useHighThinking: false,
      useSearchGrounding: true,
      useMapsGrounding: false,
      activePerspectives: ['Iris', 'Lena'],
      rationale: 'Live verification and evidence retrieval routed to gemini-3.8-flash with Google Search Grounding.'
    };
  }

  if (
    options?.forceHighThinking ||
    /\b(architecture|security audit|threat model|theorem|prove|complex system|trade-offs|formal verification|deep analysis|design a distributed)\b/i.test(
      normalized
    )
  ) {
    return {
      intent: 'deep_reasoning',
      recommendedModel: 'gemini-4-carbon',
      useHighThinking: true,
      useSearchGrounding: false,
      useMapsGrounding: false,
      activePerspectives: ['Nolan', 'Lena', 'Iris'],
      rationale: 'High-complexity architectural or security analysis routed to gemini-4-carbon with ThinkingLevel.HIGH.'
    };
  }

  if (
    /\b(refactor|typescript|python|sql|react|three\.js|firestore|bug|compile|function|unit test|implement|endpoint|regex)\b/i.test(
      normalized
    )
  ) {
    return {
      intent: 'software_engineering',
      recommendedModel: 'gemini-4-argon',
      useHighThinking: false,
      useSearchGrounding: false,
      useMapsGrounding: false,
      activePerspectives: ['Nolan', 'Lena', 'Owen'],
      rationale: 'Software engineering & code synthesis routed to gemini-4-argon.'
    };
  }

  if (normalized.length < 48 && !normalized.includes('?')) {
    return {
      intent: 'quick_conversational',
      recommendedModel: 'gemini-3.1-flash-lite',
      useHighThinking: false,
      useSearchGrounding: false,
      useMapsGrounding: false,
      activePerspectives: ['Riley'],
      rationale: 'Low-latency conversational exchange routed to gemini-3.1-flash-lite.'
    };
  }

  return {
    intent: 'quick_conversational',
    recommendedModel: 'gemini-3.8-flash',
    useHighThinking: false,
    useSearchGrounding: false,
    useMapsGrounding: false,
    activePerspectives: ['Riley', 'Owen'],
    rationale: 'Balanced general intelligence query routed to gemini-3.8-flash.'
  };
}

/**
 * 2. Knowledge Vault RAG Chunking & Retrieval (LORIN Spec Part 4 Module 3)
 */
export function chunkDocumentText(
  documentId: string,
  filename: string,
  rawText: string,
  maxChunkChars = 600,
  overlapChars = 100
): DocumentChunk[] {
  const cleaned = rawText.replace(/\r\n/g, '\n').trim();
  if (!cleaned) return [];

  if (maxChunkChars <= overlapChars) {
    throw new Error('maxChunkChars must be strictly greater than overlapChars');
  }

  const chunks: DocumentChunk[] = [];
  let cursor = 0;
  let chunkIndex = 0;

  while (cursor < cleaned.length) {
    let end = Math.min(cursor + maxChunkChars, cleaned.length);
    if (end < cleaned.length) {
      const newlineBreak = cleaned.lastIndexOf('\n', end);
      const sentenceBreak = cleaned.lastIndexOf('. ', end);
      const spaceBreak = cleaned.lastIndexOf(' ', end);
      const minAcceptableBreak = cursor + Math.floor(maxChunkChars * 0.5);

      if (newlineBreak >= minAcceptableBreak) {
        end = newlineBreak + 1;
      } else if (sentenceBreak >= minAcceptableBreak) {
        end = sentenceBreak + 2;
      } else if (spaceBreak >= minAcceptableBreak) {
        end = spaceBreak + 1;
      }
    }

    const slice = cleaned.slice(cursor, end).trim();
    if (slice.length > 0) {
      chunks.push({
        chunkId: `${documentId}_chunk_${chunkIndex}`,
        documentId,
        filename,
        chunkIndex,
        content: slice,
        startOffset: cursor,
        endOffset: end,
        tokenEstimate: Math.ceil(slice.length / 4)
      });
      chunkIndex++;
    }

    if (end >= cleaned.length) break;
    cursor = Math.max(cursor + 1, end - overlapChars);
  }

  return chunks;
}

const STOP_WORDS = new Set([
  'the',
  'and',
  'for',
  'with',
  'that',
  'this',
  'from',
  'are',
  'was',
  'were',
  'have',
  'has',
  'had',
  'what',
  'how',
  'why',
  'when',
  'where',
  'who',
  'into',
  'about',
  'your',
  'can',
  'will'
]);

export function tokenizeSearchTerms(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9_\-\s]/g, ' ')
    .split(/\s+/)
    .filter((token) => token.length >= 3 && !STOP_WORDS.has(token));
}

export function retrieveRelevantChunks(
  query: string,
  chunks: DocumentChunk[],
  topK = 4
): RetrievedPassage[] {
  const queryTerms = Array.from(new Set(tokenizeSearchTerms(query)));
  if (queryTerms.length === 0 || chunks.length === 0) return [];

  const scored: RetrievedPassage[] = [];

  for (const chunk of chunks) {
    const contentLower = chunk.content.toLowerCase();
    const filenameLower = chunk.filename.toLowerCase();
    const matchedTerms: string[] = [];
    let rawScore = 0;

    for (const term of queryTerms) {
      let occurrences = 0;
      let pos = contentLower.indexOf(term);
      while (pos !== -1) {
        occurrences++;
        pos = contentLower.indexOf(term, pos + term.length);
      }

      if (occurrences > 0) {
        matchedTerms.push(term);
        rawScore += 2.0 + Math.min(occurrences - 1, 4) * 0.65;
      }
      if (filenameLower.includes(term)) {
        if (!matchedTerms.includes(term)) matchedTerms.push(term);
        rawScore += 1.5;
      }
    }

    if (matchedTerms.length > 0) {
      const coverageBonus = (matchedTerms.length / queryTerms.length) * 3.0;
      const relevanceScore = Number((rawScore + coverageBonus).toFixed(2));
      scored.push({
        chunk,
        relevanceScore,
        matchedTerms
      });
    }
  }

  return scored
    .sort((a, b) => b.relevanceScore - a.relevanceScore)
    .slice(0, Math.max(1, topK));
}

export function compareDocuments(
  docAName: string,
  docAText: string,
  docBName: string,
  docBText: string
): DocumentComparisonResult {
  const termsA = new Set(tokenizeSearchTerms(docAText));
  const termsB = new Set(tokenizeSearchTerms(docBText));

  const sharedConcepts: string[] = [];
  const uniqueToA: string[] = [];
  const uniqueToB: string[] = [];

  for (const t of termsA) {
    if (termsB.has(t)) sharedConcepts.push(t);
    else uniqueToA.push(t);
  }
  for (const t of termsB) {
    if (!termsA.has(t)) uniqueToB.push(t);
  }

  const unionSize = termsA.size + termsB.size - sharedConcepts.length;
  const similarityRatio =
    unionSize === 0 ? 1 : Number((sharedConcepts.length / unionSize).toFixed(2));

  const linesA = new Set(
    docAText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean)
  );
  const linesB = new Set(
    docBText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean)
  );

  let lineAdditions = 0;
  let lineRemovals = 0;
  for (const l of linesB) {
    if (!linesA.has(l)) lineAdditions++;
  }
  for (const l of linesA) {
    if (!linesB.has(l)) lineRemovals++;
  }

  return {
    docAName,
    docBName,
    sharedConcepts: sharedConcepts.slice(0, 18),
    uniqueToA: uniqueToA.slice(0, 14),
    uniqueToB: uniqueToB.slice(0, 14),
    similarityRatio,
    lineAdditions,
    lineRemovals
  };
}

/**
 * 3. AI Learning Laboratory Quiz Grading & Progress Calculation (LORIN Spec Part 4 Module 4)
 */
export function evaluateQuizSubmission(
  questions: QuizQuestion[],
  selectedAnswers: Record<string, number>,
  passingThresholdPercent = 70
): QuizSubmissionEvaluation {
  if (questions.length === 0) {
    return {
      totalQuestions: 0,
      correctCount: 0,
      scorePercentage: 0,
      passed: false,
      feedbackPerQuestion: []
    };
  }

  let correctCount = 0;
  const feedbackPerQuestion = questions.map((q) => {
    const selectedIndex =
      typeof selectedAnswers[q.id] === 'number' ? selectedAnswers[q.id] : -1;
    const isCorrect = selectedIndex === q.correctIndex;
    if (isCorrect) correctCount++;
    return {
      questionId: q.id,
      selectedIndex,
      correctIndex: q.correctIndex,
      isCorrect,
      explanation: q.explanation
    };
  });

  const scorePercentage = Math.round((correctCount / questions.length) * 100);
  return {
    totalQuestions: questions.length,
    correctCount,
    scorePercentage,
    passed: scorePercentage >= passingThresholdPercent,
    feedbackPerQuestion
  };
}

export function calculateUpdatedLearningPathMetrics(
  currentCompletedLessons: number,
  totalLessons: number,
  previousAverageScore: number,
  newQuizScore: number,
  isNewLessonCompletion: boolean
): {
  completedLessons: number;
  averageScore: number;
  status: 'active' | 'completed';
} {
  const safeTotal = Math.max(1, Math.min(500, totalLessons));
  const nextCompleted = isNewLessonCompletion
    ? Math.min(safeTotal, currentCompletedLessons + 1)
    : Math.min(safeTotal, currentCompletedLessons);

  const clampedScore = Math.max(0, Math.min(100, newQuizScore));
  const weightCount = Math.max(1, currentCompletedLessons);
  const rawNewAvg =
    currentCompletedLessons === 0
      ? clampedScore
      : (previousAverageScore * weightCount + clampedScore) / (weightCount + 1);

  const averageScore = Math.round(Math.max(0, Math.min(100, rawNewAvg)));
  const status: 'active' | 'completed' =
    nextCompleted >= safeTotal ? 'completed' : 'active';

  return {
    completedLessons: nextCompleted,
    averageScore,
    status
  };
}

/**
 * 4. Virtual World Studio Scene Validation & Natural Language Editing (LORIN Spec Part 4 Module 5)
 */
const VALID_ARCHETYPES = new Set<VirtualWorldObjectSpec['archetype']>([
  'research_workstation',
  'assistant_robot',
  'holographic_array',
  'solar_collector',
  'network_rack',
  'observation_column'
]);

export function validateSceneSpec(spec: Partial<VirtualWorldSceneSpec>): VirtualWorldSceneSpec {
  const validEnv =
    spec.environmentPreset &&
    ['laboratory', 'classroom', 'observatory', 'solar_array'].includes(spec.environmentPreset)
      ? spec.environmentPreset
      : 'laboratory';

  const rawObjects = Array.isArray(spec.objects) ? spec.objects.slice(0, 60) : [];
  const sanitizedObjects: VirtualWorldObjectSpec[] = rawObjects.map((obj, idx) => {
    const archetype = VALID_ARCHETYPES.has(obj.archetype)
      ? obj.archetype
      : 'research_workstation';
    const px = Number.isFinite(obj.position?.[0])
      ? Math.max(-24, Math.min(24, obj.position[0]))
      : (idx % 4) * 3 - 4.5;
    const py = Number.isFinite(obj.position?.[1])
      ? Math.max(0, Math.min(12, obj.position[1]))
      : 0;
    const pz = Number.isFinite(obj.position?.[2])
      ? Math.max(-24, Math.min(24, obj.position[2]))
      : Math.floor(idx / 4) * 3 - 3;

    return {
      id: obj.id && typeof obj.id === 'string' ? obj.id : `obj_${idx + 1}`,
      name:
        obj.name && typeof obj.name === 'string'
          ? obj.name.slice(0, 80)
          : `Unit ${idx + 1}`,
      archetype,
      position: [Number(px.toFixed(2)), Number(py.toFixed(2)), Number(pz.toFixed(2))],
      rotationY: Number.isFinite(obj.rotationY) ? Number(obj.rotationY) : 0,
      scale: Number.isFinite(obj.scale)
        ? Math.max(0.4, Math.min(2.5, Number(obj.scale)))
        : 1,
      accentColor:
        typeof obj.accentColor === 'string' && /^#[0-9A-Fa-f]{6}$/.test(obj.accentColor)
          ? obj.accentColor
          : '#66E3CB',
      interactiveLabel:
        typeof obj.interactiveLabel === 'string' && obj.interactiveLabel.trim()
          ? obj.interactiveLabel.slice(0, 140)
          : 'Interactive telemetry node'
    };
  });

  return {
    worldId: spec.worldId || 'world_default',
    name: (spec.name || 'LORIN Spatial Research Laboratory').slice(0, 120),
    description: (
      spec.description ||
      'Interactive 3D research environment with composite hardware assemblies and telemetry inspection.'
    ).slice(0, 1000),
    environmentPreset: validEnv,
    fogDensity:
      typeof spec.fogDensity === 'number'
        ? Math.max(0.005, Math.min(0.06, spec.fogDensity))
        : 0.018,
    keyLightIntensity:
      typeof spec.keyLightIntensity === 'number'
        ? Math.max(0.5, Math.min(4.0, spec.keyLightIntensity))
        : 2.2,
    objects: sanitizedObjects
  };
}

export function applyNaturalLanguageSceneEdit(
  scene: VirtualWorldSceneSpec,
  command: string
): { updatedScene: VirtualWorldSceneSpec; summary: string } {
  const lower = command.trim().toLowerCase();
  const nextObjects = [...scene.objects];
  let environmentPreset = scene.environmentPreset;
  let keyLightIntensity = scene.keyLightIntensity;
  const actions: string[] = [];

  if (lower.includes('observatory')) {
    environmentPreset = 'observatory';
    actions.push('switched environment preset to observatory');
  } else if (lower.includes('solar')) {
    environmentPreset = 'solar_array';
    actions.push('switched environment preset to solar_array');
  } else if (lower.includes('classroom')) {
    environmentPreset = 'classroom';
    actions.push('switched environment preset to classroom');
  } else if (lower.includes('laboratory') || lower.includes('lab')) {
    environmentPreset = 'laboratory';
    actions.push('switched environment preset to laboratory');
  }

  if (lower.includes('brighter') || lower.includes('increase light')) {
    keyLightIntensity = Math.min(4.0, Number((keyLightIntensity + 0.6).toFixed(2)));
    actions.push(`increased key light intensity to ${keyLightIntensity}`);
  } else if (lower.includes('dimmer') || lower.includes('darker')) {
    keyLightIntensity = Math.max(0.6, Number((keyLightIntensity - 0.6).toFixed(2)));
    actions.push(`decreased key light intensity to ${keyLightIntensity}`);
  }

  const addArchetype = (
    archetype: VirtualWorldObjectSpec['archetype'],
    label: string,
    accentColor: string
  ) => {
    const idx = nextObjects.length + 1;
    const angle = idx * 1.15;
    const radius = 3.2 + (idx % 3) * 1.6;
    const x = Number((Math.cos(angle) * radius).toFixed(2));
    const z = Number((Math.sin(angle) * radius).toFixed(2));
    nextObjects.push({
      id: `obj_${Date.now()}_${idx}`,
      name: `${label} #${idx}`,
      archetype,
      position: [x, 0, z],
      rotationY: Number((-angle).toFixed(2)),
      scale: 1,
      accentColor,
      interactiveLabel: `${label} deployed via natural-language command`
    });
    actions.push(`added ${label} at [${x}, 0, ${z}]`);
  };

  if (lower.includes('robot') || lower.includes('drone') || lower.includes('assistant')) {
    addArchetype('assistant_robot', 'Autonomous Assistant Unit', '#66E3CB');
  }
  if (lower.includes('workstation') || lower.includes('desk') || lower.includes('terminal')) {
    addArchetype('research_workstation', 'Dual-Monitor Research Desk', '#A9B8FF');
  }
  if (lower.includes('hologram') || lower.includes('holographic') || lower.includes('core')) {
    addArchetype('holographic_array', 'Holographic Projection Core', '#66E3CB');
  }
  if (lower.includes('solar panel') || lower.includes('collector')) {
    addArchetype('solar_collector', 'Photovoltaic Tracking Array', '#E8BE78');
  }
  if (lower.includes('rack') || lower.includes('server')) {
    addArchetype('network_rack', 'Quantum Compute Server Rack', '#A9B8FF');
  }
  if (lower.includes('column') || lower.includes('pillar') || lower.includes('sensor')) {
    addArchetype('observation_column', 'Atmospheric Sensor Column', '#E8BE78');
  }

  if (lower.includes('remove last') || lower.includes('delete last')) {
    if (nextObjects.length > 1) {
      const removed = nextObjects.pop();
      actions.push(`removed ${removed?.name}`);
    }
  }

  if (actions.length === 0) {
    addArchetype('holographic_array', 'Synthesized Spatial Node', '#66E3CB');
  }

  const updatedScene = validateSceneSpec({
    ...scene,
    environmentPreset,
    keyLightIntensity,
    objects: nextObjects
  });

  return {
    updatedScene,
    summary: `Applied scene updates: ${actions.join('; ')}.`
  };
}

/**
 * 5. Project Management Task Prioritization & Dashboard Metrics
 */
const PRIORITY_WEIGHT: Record<TaskPriority, number> = {
  High: 3,
  Medium: 2,
  Low: 1
};

export function sortAndFilterProjectTasks(
  tasks: ProjectTask[],
  options?: {
    priorityFilter?: 'ALL' | TaskPriority;
    statusFilter?: 'ALL' | TaskStatus;
    sortBy?: 'manual' | 'priority_desc' | 'priority_asc' | 'status' | 'due_date';
  }
): ProjectTask[] {
  const priorityFilter = options?.priorityFilter || 'ALL';
  const statusFilter = options?.statusFilter || 'ALL';
  const sortBy = options?.sortBy || 'priority_desc';

  const filtered = tasks.filter((t) => {
    if (priorityFilter !== 'ALL' && t.priority !== priorityFilter) return false;
    if (statusFilter !== 'ALL' && t.status !== statusFilter) return false;
    return true;
  });

  if (sortBy === 'manual') {
    return [...filtered].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  }

  return [...filtered].sort((a, b) => {
    if (sortBy === 'priority_desc') {
      const diff = PRIORITY_WEIGHT[b.priority] - PRIORITY_WEIGHT[a.priority];
      return diff !== 0 ? diff : (a.order ?? 0) - (b.order ?? 0);
    }
    if (sortBy === 'priority_asc') {
      const diff = PRIORITY_WEIGHT[a.priority] - PRIORITY_WEIGHT[b.priority];
      return diff !== 0 ? diff : (a.order ?? 0) - (b.order ?? 0);
    }
    if (sortBy === 'due_date') {
      return (a.dueDate || '9999-12-31').localeCompare(b.dueDate || '9999-12-31');
    }
    return a.status.localeCompare(b.status);
  });
}

/**
 * Reorders a task or moves it across status columns / priority levels via drag-and-drop.
 * Produces a deterministic array with normalized sequential `order` indices.
 */
export function reorderAndMoveProjectTask(
  tasks: ProjectTask[],
  draggedTaskId: string,
  target: {
    status?: TaskStatus;
    priority?: TaskPriority;
    targetTaskId?: string;
    insertPosition?: 'before' | 'after';
  }
): ProjectTask[] {
  const draggedIndex = tasks.findIndex((t) => t.taskId === draggedTaskId);
  if (draggedIndex === -1) return tasks;

  const original = tasks[draggedIndex];
  const updatedTask: ProjectTask = {
    ...original,
    status: target.status ?? original.status,
    priority: target.priority ?? original.priority
  };

  const remaining = tasks.filter((t) => t.taskId !== draggedTaskId);

  let insertIndex = remaining.length;
  if (target.targetTaskId && target.targetTaskId !== draggedTaskId) {
    const targetIdx = remaining.findIndex((t) => t.taskId === target.targetTaskId);
    if (targetIdx !== -1) {
      insertIndex = target.insertPosition === 'after' ? targetIdx + 1 : targetIdx;
    }
  } else if (target.status) {
    // Append at the end of the target status group when dropped into empty column space
    let lastInStatus = -1;
    remaining.forEach((t, idx) => {
      if (t.status === target.status) lastInStatus = idx;
    });
    if (lastInStatus !== -1) {
      insertIndex = lastInStatus + 1;
    }
  }

  const nextList = [
    ...remaining.slice(0, insertIndex),
    updatedTask,
    ...remaining.slice(insertIndex)
  ];

  return nextList.map((task, idx) => ({
    ...task,
    order: idx
  }));
}

const MS_PER_DAY = 24 * 60 * 60 * 1000;

function parseIsoUtcDate(iso: string | undefined, fallbackMs: number): number {
  if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return fallbackMs;
  const [y, m, d] = iso.split('-').map(Number);
  const utc = Date.UTC(y, m - 1, d);
  return Number.isFinite(utc) ? utc : fallbackMs;
}

function formatIsoUtcDate(ms: number): string {
  const dt = new Date(ms);
  const y = dt.getUTCFullYear();
  const m = String(dt.getUTCMonth() + 1).padStart(2, '0');
  const d = String(dt.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function formatShortMonthDay(ms: number): string {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const dt = new Date(ms);
  return `${months[dt.getUTCMonth()]} ${dt.getUTCDate()}`;
}

/**
 * Computes normalized Gantt chart coordinates, day ticks, overdue status, and Today indicator
 * for a list of project tasks based on their startDate and dueDate.
 */
export function computeGanttTimelineLayout(
  tasks: ProjectTask[],
  referenceDateIso?: string
): GanttTimelineLayout {
  const now = new Date();
  const defaultTodayMs = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  const todayMs = parseIsoUtcDate(referenceDateIso, defaultTodayMs);

  if (tasks.length === 0) {
    const startMs = todayMs - 2 * MS_PER_DAY;
    const endMs = todayMs + 12 * MS_PER_DAY;
    const totalDays = 14;
    const ticks: GanttTimelineTick[] = [];
    for (let i = 0; i <= totalDays; i++) {
      const tickMs = startMs + i * MS_PER_DAY;
      const dow = new Date(tickMs).getUTCDay();
      ticks.push({
        isoDate: formatIsoUtcDate(tickMs),
        label: formatShortMonthDay(tickMs),
        offsetPercent: Number(((i / totalDays) * 100).toFixed(2)),
        isWeekend: dow === 0 || dow === 6
      });
    }
    return {
      timelineStartIso: formatIsoUtcDate(startMs),
      timelineEndIso: formatIsoUtcDate(endMs),
      totalDays,
      todayOffsetPercent: Number((((todayMs - startMs) / (totalDays * MS_PER_DAY)) * 100).toFixed(2)),
      ticks,
      bars: []
    };
  }

  let minMs = Infinity;
  let maxMs = -Infinity;

  const normalizedRanges = tasks.map((task, idx) => {
    const fallbackStart = todayMs + (idx - 1) * 2 * MS_PER_DAY;
    const startMs = parseIsoUtcDate(task.startDate, fallbackStart);
    const rawEndMs = parseIsoUtcDate(task.dueDate, startMs + 3 * MS_PER_DAY);
    const endMs = rawEndMs >= startMs ? rawEndMs : startMs;

    if (startMs < minMs) minMs = startMs;
    if (endMs > maxMs) maxMs = endMs;

    return { task, startMs, endMs };
  });

  // Add 1 day padding on start and 2 days on end for breathing room
  const windowStartMs = minMs - 1 * MS_PER_DAY;
  const windowEndMs = Math.max(maxMs + 2 * MS_PER_DAY, windowStartMs + 10 * MS_PER_DAY);
  const totalDays = Math.max(1, Math.round((windowEndMs - windowStartMs) / MS_PER_DAY));
  const totalSpanMs = totalDays * MS_PER_DAY;

  const ticks: GanttTimelineTick[] = [];
  for (let i = 0; i <= totalDays; i++) {
    const tickMs = windowStartMs + i * MS_PER_DAY;
    const dow = new Date(tickMs).getUTCDay();
    ticks.push({
      isoDate: formatIsoUtcDate(tickMs),
      label: formatShortMonthDay(tickMs),
      offsetPercent: Number(((i / totalDays) * 100).toFixed(2)),
      isWeekend: dow === 0 || dow === 6
    });
  }

  const todayOffsetRaw = ((todayMs - windowStartMs) / totalSpanMs) * 100;
  const todayOffsetPercent =
    todayOffsetRaw >= 0 && todayOffsetRaw <= 100
      ? Number(todayOffsetRaw.toFixed(2))
      : null;

  const bars: GanttBarLayout[] = normalizedRanges.map(({ task, startMs, endMs }) => {
    const durationDays = Math.max(1, Math.round((endMs - startMs) / MS_PER_DAY) + 1);
    const leftPercent = Number((((startMs - windowStartMs) / totalSpanMs) * 100).toFixed(2));
    const widthPercent = Number(
      Math.max((durationDays / totalDays) * 100, 100 / totalDays).toFixed(2)
    );
    const isOverdue = task.status !== 'done' && endMs < todayMs;
    const isActiveToday = startMs <= todayMs && endMs >= todayMs;

    return {
      task,
      startIso: formatIsoUtcDate(startMs),
      endIso: formatIsoUtcDate(endMs),
      durationDays,
      leftPercent,
      widthPercent: Math.min(100 - leftPercent, widthPercent),
      isOverdue,
      isActiveToday
    };
  });

  return {
    timelineStartIso: formatIsoUtcDate(windowStartMs),
    timelineEndIso: formatIsoUtcDate(windowEndMs),
    totalDays,
    todayOffsetPercent,
    ticks,
    bars
  };
}

export function computeProjectDashboardMetrics(
  tasks: ProjectTask[]
): ProjectDashboardMetrics {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t) => t.status === 'done').length;
  const inProgressTasks = tasks.filter((t) => t.status === 'in_progress').length;
  const todoTasks = tasks.filter((t) => t.status === 'todo').length;

  const completionRatePercent =
    totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

  const priorityCounts: Record<TaskPriority, number> = {
    High: 0,
    Medium: 0,
    Low: 0
  };
  let highPriorityOpenCount = 0;

  const workloadMap = new Map<string, { hours: number; taskCount: number }>();

  for (const t of tasks) {
    priorityCounts[t.priority] = (priorityCounts[t.priority] || 0) + 1;
    if (t.priority === 'High' && t.status !== 'done') {
      highPriorityOpenCount++;
    }
    const prev = workloadMap.get(t.assignee) || { hours: 0, taskCount: 0 };
    workloadMap.set(t.assignee, {
      hours: prev.hours + (t.estimatedHours || 0),
      taskCount: prev.taskCount + 1
    });
  }

  const workloadByAssignee = Array.from(workloadMap.entries()).map(
    ([assignee, stats]) => ({
      assignee,
      hours: stats.hours,
      taskCount: stats.taskCount
    })
  );

  const penalty = highPriorityOpenCount * 10;
  const rawHealth = Math.min(100, Math.max(20, 70 + Math.round(completionRatePercent * 0.3) - penalty));
  const healthStatus: ProjectDashboardMetrics['healthStatus'] =
    rawHealth >= 80
      ? 'Optimal'
      : rawHealth >= 55
      ? 'Attention Required'
      : 'At Risk';

  return {
    totalTasks,
    completedTasks,
    inProgressTasks,
    todoTasks,
    completionRatePercent,
    highPriorityOpenCount,
    priorityCounts,
    workloadByAssignee,
    healthScore: rawHealth,
    healthStatus
  };
}

/**
 * 6. Firestore Security Rule Invariant Evaluator (Tests the 8 Pillars & Dirty Dozen)
 * Mirrors /firestore.rules logic for unit testing and pre-write client validation.
 */
export interface SimulatedRuleContext {
  auth: {
    uid: string;
    emailVerified: boolean;
  } | null;
  requestTimeIso: string;
  existingDoc?: Record<string, unknown> | null;
  parentDoc?: Record<string, unknown> | null;
}

export function evaluateFirestoreRuleInvariant(
  collection:
    | 'users'
    | 'users_private'
    | 'projects'
    | 'conversations'
    | 'messages'
    | 'documents'
    | 'learning_paths'
    | 'vision_analyses'
    | 'virtual_worlds'
    | 'activity_logs'
    | 'unknown_collection',
  operation: 'get' | 'list' | 'create' | 'update' | 'delete',
  docId: string,
  incomingData: Record<string, unknown> | null,
  ctx: SimulatedRuleContext
): { allowed: boolean; reason: string } {
  if (collection === 'unknown_collection') {
    return { allowed: false, reason: 'Pillar 1: Default-Deny on unknown collections' };
  }

  if (!ctx.auth) {
    return { allowed: false, reason: 'Unauthenticated request denied' };
  }

  const isValidId =
    typeof docId === 'string' &&
    docId.length >= 1 &&
    docId.length <= 128 &&
    /^[a-zA-Z0-9_-]+$/.test(docId);

  if (operation !== 'list' && !isValidId) {
    return { allowed: false, reason: 'Pillar 7: Invalid document ID format or length' };
  }

  if (operation === 'list') {
    if (collection === 'users' || collection === 'users_private') {
      return { allowed: false, reason: 'Pillar 2: User profile enumeration is forbidden' };
    }
    if (ctx.existingDoc && ctx.existingDoc.ownerId !== ctx.auth.uid) {
      return { allowed: false, reason: 'Pillar 2: List query must filter by ownerId == request.auth.uid' };
    }
    return { allowed: true, reason: 'Allowed owner-scoped list' };
  }

  if (operation === 'get') {
    if (collection === 'users' || collection === 'users_private') {
      return docId === ctx.auth.uid
        ? { allowed: true, reason: 'Owner read allowed' }
        : { allowed: false, reason: 'Cannot read another user profile or private info' };
    }
    if (!ctx.existingDoc || ctx.existingDoc.ownerId !== ctx.auth.uid) {
      return { allowed: false, reason: 'Resource ownerId mismatch' };
    }
    if (collection === 'messages') {
      if (!ctx.parentDoc || ctx.parentDoc.ownerId !== ctx.auth.uid) {
        return { allowed: false, reason: 'Pillar 8: Parent conversation ownerId mismatch' };
      }
    }
    return { allowed: true, reason: 'Owner get allowed' };
  }

  // Write operations require verified email (Pillar 2)
  if (!ctx.auth.emailVerified) {
    return { allowed: false, reason: 'Pillar 2: Write operations require email_verified == true' };
  }

  if (operation === 'delete') {
    if (collection === 'users' || collection === 'users_private' || collection === 'activity_logs') {
      return { allowed: false, reason: 'Delete is forbidden on audit/profile collections' };
    }
    if (!ctx.existingDoc || ctx.existingDoc.ownerId !== ctx.auth.uid) {
      return { allowed: false, reason: 'Cannot delete non-owned resource' };
    }
    return { allowed: true, reason: 'Owner delete allowed' };
  }

  if (!incomingData || typeof incomingData !== 'object') {
    return { allowed: false, reason: 'Missing incoming payload' };
  }

  // Create & Update schema + state checks
  if (collection === 'projects') {
    const allowedKeys = [
      'projectId',
      'ownerId',
      'name',
      'description',
      'status',
      'objectives',
      'createdAt',
      'updatedAt'
    ];
    const keys = Object.keys(incomingData);
    if (
      !allowedKeys.every((k) => keys.includes(k)) ||
      !keys.every((k) => allowedKeys.includes(k))
    ) {
      return { allowed: false, reason: 'Pillar 3: Schema key mismatch (extra or missing fields)' };
    }
    if (incomingData.projectId !== docId) {
      return { allowed: false, reason: 'Pillar 6: Path-to-Data parity violation on projectId' };
    }
    if (incomingData.ownerId !== ctx.auth.uid) {
      return { allowed: false, reason: 'Pillar 6: ownerId must match request.auth.uid' };
    }
    if (
      typeof incomingData.name !== 'string' ||
      incomingData.name.length < 1 ||
      incomingData.name.length > 120
    ) {
      return { allowed: false, reason: 'Pillar 3: name length out of bounds (1..120)' };
    }
    if (
      typeof incomingData.description !== 'string' ||
      incomingData.description.length > 2000
    ) {
      return { allowed: false, reason: 'Pillar 3: description length out of bounds (<=2000)' };
    }
    if (!['planning', 'active', 'review', 'Archived'].includes(String(incomingData.status))) {
      return { allowed: false, reason: 'Pillar 4: Invalid project status enum' };
    }
    if (
      !Array.isArray(incomingData.objectives) ||
      incomingData.objectives.length > 10 ||
      (incomingData.objectives.length > 0 &&
        (typeof incomingData.objectives[0] !== 'string' ||
          incomingData.objectives[0].length > 300))
    ) {
      return { allowed: false, reason: 'Pillar 3: objectives list bounds or element validation failed' };
    }

    if (operation === 'create') {
      if (
        incomingData.createdAt !== ctx.requestTimeIso ||
        incomingData.updatedAt !== ctx.requestTimeIso
      ) {
        return { allowed: false, reason: 'Pillar 5: Timestamps must equal request.time on create' };
      }
      return { allowed: true, reason: 'Valid project create' };
    }

    if (operation === 'update') {
      if (!ctx.existingDoc || ctx.existingDoc.ownerId !== ctx.auth.uid) {
        return { allowed: false, reason: 'Not owner of existing project' };
      }
      if (ctx.existingDoc.status === 'Archived') {
        return { allowed: false, reason: 'Pillar 4: Terminal state lock (Archived projects cannot be modified)' };
      }
      if (
        incomingData.projectId !== ctx.existingDoc.projectId ||
        incomingData.ownerId !== ctx.existingDoc.ownerId ||
        incomingData.createdAt !== ctx.existingDoc.createdAt
      ) {
        return { allowed: false, reason: 'Pillar 5: Immutable identity or createdAt modified on update' };
      }
      if (incomingData.updatedAt !== ctx.requestTimeIso) {
        return { allowed: false, reason: 'Pillar 5: updatedAt must equal request.time on update' };
      }
      return { allowed: true, reason: 'Valid project update' };
    }
  }

  if (collection === 'messages') {
    if (operation === 'update') {
      return { allowed: false, reason: 'Messages are immutable after creation' };
    }
    if (!ctx.parentDoc || ctx.parentDoc.ownerId !== ctx.auth.uid) {
      return { allowed: false, reason: 'Pillar 8: Parent conversation must exist and belong to caller' };
    }
    return { allowed: true, reason: 'Valid message create' };
  }

  return { allowed: true, reason: 'Valid operation' };
}
