import type {
  QuizQuestion,
  VirtualWorldSceneSpec
} from '../utils/lorinLogic';

export interface ProjectRecord {
  projectId: string;
  ownerId: string;
  name: string;
  description: string;
  status: 'planning' | 'active' | 'review' | 'Archived';
  objectives: string[];
  updatedAtLabel: string;
}

export interface ChatMessageRecord {
  messageId: string;
  conversationId: string;
  senderType: 'user' | 'lorin';
  content: string;
  modelUsed: string;
  perspectives?: string[];
  groundingLinks?: Array<{
    title: string;
    uri: string;
    sourceType: 'web' | 'maps';
  }>;
  vaultCitations?: string[];
  timestampLabel: string;
}

export interface ConversationRecord {
  conversationId: string;
  title: string;
  status: 'active' | 'archived';
  relatedProjectId: string;
  updatedAtLabel: string;
  messages: ChatMessageRecord[];
}

export interface KnowledgeDocumentRecord {
  documentId: string;
  filename: string;
  format: string;
  size: number;
  collectionName: string;
  processingStatus: 'Uploading' | 'Processing' | 'Indexed' | 'Failed';
  extractedText: string;
  tags: string[];
  updatedAtLabel: string;
}

export interface LearningPathRecord {
  learningPathId: string;
  title: string;
  subject: string;
  targetLevel: 'beginner' | 'intermediate' | 'advanced';
  status: 'active' | 'completed';
  completedLessons: number;
  totalLessons: number;
  averageScore: number;
  conceptOverview: string;
  keyTakeaways: string[];
  workedExample: string;
  codingPrompt: string;
  starterCode: string;
  expectedOutputSubstring: string;
  quizQuestions: QuizQuestion[];
}

export interface VisionAnalysisRecord {
  analysisId: string;
  title: string;
  question: string;
  resultSummary: string;
  uncertaintyNotes: string;
  detectedElements: string[];
  recommendedScenePreset: 'laboratory' | 'classroom' | 'observatory' | 'solar_array';
  createdAtLabel: string;
}

export const INITIAL_PROJECTS: ProjectRecord[] = [
  {
    projectId: 'proj_lorin_core',
    ownerId: 'local_owner',
    name: 'LORIN Private Intelligence Architecture',
    description:
      'Unified private-first multimodal intelligence platform integrating reasoning, visual inspection, RAG Knowledge Vault, adaptive learning, and PBR 3D spatial synthesis.',
    status: 'active',
    objectives: [
      'Enforce server-side Gemini API proxy isolation and Firestore 8-Pillar security rules',
      'Maintain strict identity separation between private LORIN and public platforms',
      'Verify RAG document chunk citations and 3D scene specification schemas'
    ],
    updatedAtLabel: 'Updated 12m ago'
  },
  {
    projectId: 'proj_autonomous_grid',
    ownerId: 'local_owner',
    name: 'Microgrid Telemetry & Spatial Twin',
    description:
      'Real-time photovoltaic array diagnostics paired with a Three.js spatial twin and automated anomaly triage.',
    status: 'review',
    objectives: [
      'Validate inverter thermal load thresholds under peak irradiance',
      'Reconstruct solar collector field layout inside Virtual World Studio',
      'Audit Modbus-TCP gateway access permissions'
    ],
    updatedAtLabel: 'Updated 2h ago'
  },
  {
    projectId: 'proj_zero_trust_vault',
    ownerId: 'local_owner',
    name: 'Zero-Trust Document Governance Pipeline',
    description:
      'Document ingestion, deterministic chunking, and cross-version policy diff analysis with Google Drive synchronization.',
    status: 'planning',
    objectives: [
      'Enforce mandatory owner confirmation prior to external Drive exports',
      'Benchmark chunk overlap retrieval precision across technical specifications'
    ],
    updatedAtLabel: 'Updated 1d ago'
  }
];

export const INITIAL_DOCUMENTS: KnowledgeDocumentRecord[] = [
  {
    documentId: 'doc_lorin_master_arch',
    filename: 'LORIN_System_Security_Architecture_v2.md',
    format: 'Markdown',
    size: 18420,
    collectionName: 'Core Architecture',
    processingStatus: 'Indexed',
    tags: ['security', 'architecture', 'firestore', 'gemini'],
    updatedAtLabel: 'Indexed today',
    extractedText: `LORIN Unified Master Intelligence System — Security & Architecture Reference.

1. Identity Separation & Private-First Boundaries
LORIN operates strictly as the authorized owner's private engineering partner and research system. Private Knowledge Vault documents, project context, and owner credentials remain isolated inside the private environment.

2. Five Specialist Reasoning Perspectives
- Lena (Guardian): Evaluates authentication, authorization, OWASP attack surfaces, split-collection PII isolation, and high-impact approval gates.
- Owen (Coordinator): Manages task sequencing, project dependencies, and distinguishes proposed work from verified execution.
- Riley (Companion): Adapts technical explanations, interactive courses, and voice interactions to the owner's learning goals.
- Iris (Investigator): Verifies primary documentation, grounds live claims via Google Search and Google Maps, and flags uncertainty explicitly.
- Nolan (Strategist): Designs maintainable full-stack architectures, deterministic state machines, and Three.js spatial simulations.

3. Firestore Eight-Pillar Security Model
All persistent collections enforce Default-Deny fallback, verified-email write gates, strict hasAll/hasOnly schema blueprints, bounded string/list lengths, terminal state locks on Archived projects, and server-timestamp enforcement.`
  },
  {
    documentId: 'doc_microgrid_spec',
    filename: 'Autonomous_Solar_Microgrid_Spec_RevB.md',
    format: 'Markdown',
    size: 14280,
    collectionName: 'Hardware & Telemetry',
    processingStatus: 'Indexed',
    tags: ['microgrid', 'solar', 'telemetry', 'threejs'],
    updatedAtLabel: 'Indexed yesterday',
    extractedText: `Autonomous Solar Microgrid Specification — Revision B.

1. Photovoltaic Collector Array Topology
Each dual-axis solar collector assembly operates at a nominal 800V DC bus voltage with maximum power point tracking (MPPT) efficiency of 98.6%. Array rows must maintain a minimum 3.2-meter spatial clearance to eliminate inter-row shading during winter solstice angles.

2. Thermal & Inverter Protection Thresholds
SiC (Silicon Carbide) central inverters are rated for continuous operation up to 65°C heatsink temperature. At 72°C, active liquid-cooling pumps step to 100% duty cycle and output power derates linearly at 2.5% per degree Celsius.

3. Telemetry & Spatial Twin Mapping
Every collector node streams 1Hz telemetry frames containing array azimuth, elevation tilt, DC bus voltage, and thermal fault flags to the LORIN Virtual World Studio for spatial inspection.`
  },
  {
    documentId: 'doc_microgrid_spec_revA',
    filename: 'Autonomous_Solar_Microgrid_Spec_RevA.md',
    format: 'Markdown',
    size: 11900,
    collectionName: 'Hardware & Telemetry',
    processingStatus: 'Indexed',
    tags: ['microgrid', 'legacy', 'comparison'],
    updatedAtLabel: 'Indexed 3d ago',
    extractedText: `Autonomous Solar Microgrid Specification — Revision A (Legacy).

1. Photovoltaic Collector Array Topology
Each single-axis solar collector assembly operates at a nominal 600V DC bus voltage with MPPT efficiency of 96.4%. Array rows maintain a 2.5-meter spatial clearance.

2. Thermal & Inverter Protection Thresholds
IGBT central inverters are rated for continuous operation up to 55°C heatsink temperature. Forced-air fans engage at 60°C.

3. Telemetry Mapping
Collector nodes poll every 15 seconds over RS-485 serial links without spatial 3D visualization.`
  }
];

export const INITIAL_CONVERSATIONS: ConversationRecord[] = [
  {
    conversationId: 'conv_arch_review',
    title: 'LORIN Security & Multimodal Routing Audit',
    status: 'active',
    relatedProjectId: 'proj_lorin_core',
    updatedAtLabel: 'Active now',
    messages: [
      {
        messageId: 'msg_init_1',
        conversationId: 'conv_arch_review',
        senderType: 'user',
        content:
          'Summarize how LORIN routes tasks across specialist models and how Knowledge Vault citations work.',
        modelUsed: 'user-input',
        timestampLabel: '09:40'
      },
      {
        messageId: 'msg_init_2',
        conversationId: 'conv_arch_review',
        senderType: 'lorin',
        content: `LORIN coordinates task routing across dedicated model tiers while maintaining one unified engineering identity:

1. **Deep Architectural & Security Reasoning (\`gemini-4-carbon\` + \`ThinkingLevel.HIGH\`)**: Activated for threat modeling, distributed systems design, and formal verification where Lena (Guardian) and Nolan (Strategist) evaluate trade-offs thoroughly.
2. **Software Engineering & Multimodal Inspection (\`gemini-4-argon\`)**: Handles TypeScript/React/Three.js implementation, PCB and diagram inspection, multi-image comparison, and video timeline analysis.
3. **Live Grounded Research & Spatial Intelligence (\`gemini-3.8-flash\`)**: Integrates Google Search Grounding for verifiable web citations and Google Maps Grounding for real-world coordinates and place reconnaissance.
4. **Low-Latency Dialogue & Voice (\`gemini-3.1-flash-lite\`, \`gemini-3.8-flash-tts\`, \`gemini-3.8-live\`)**: Provides rapid conversational responses, unary WAV speech synthesis, and bidirectional PCM live voice sessions.

Whenever you enable **Knowledge Vault Grounding**, LORIN chunks and scores your indexed documents deterministically, injects the top matching passages into the server-side prompt as untrusted data, and attaches explicit source filename citations to the response.`,
        modelUsed: 'gemini-3.8-flash',
        perspectives: ['Nolan', 'Lena', 'Iris'],
        vaultCitations: ['LORIN_System_Security_Architecture_v2.md'],
        timestampLabel: '09:41'
      }
    ]
  }
];

export const INITIAL_LEARNING_PATHS: LearningPathRecord[] = [
  {
    learningPathId: 'path_zero_trust_eng',
    title: 'Zero-Trust Cloud & Firestore Security Engineering',
    subject: 'Security Architecture',
    targetLevel: 'advanced',
    status: 'active',
    completedLessons: 2,
    totalLessons: 4,
    averageScore: 92,
    conceptOverview:
      'Production security requires backend-enforced authorization boundaries. Client-side UI checks improve ergonomics, but database security rules and server proxies are the true enforcement perimeter.',
    keyTakeaways: [
      'Enforce Default-Deny (`allow read, write: if false;`) at the root of `firestore.rules`.',
      'Separate public profile metadata (`/users/{userId}`) from sensitive PII (`/users/{userId}/private/info`).',
      'Validate exact schema keys (`hasAll` + `hasOnly`), string length bounds, and server timestamps (`request.time`) on every write.',
      'Lock terminal states (such as `Archived` projects) so historical records cannot be tampered with.'
    ],
    workedExample: `// Enforcing immutable identity & server timestamp on Firestore update:
allow update: if isVerifiedUser()
  && existing().ownerId == request.auth.uid
  && existing().status != 'Archived'
  && incoming().ownerId == existing().ownerId
  && incoming().createdAt == existing().createdAt
  && incoming().updatedAt == request.time;`,
    codingPrompt:
      'Write a JavaScript function `isPayloadBounded(name, objectives)` that returns `true` only if `name` is a non-empty string <= 120 chars and `objectives` is an array of at most 10 strings. Log the result of `isPayloadBounded("LORIN Core", ["Audit rules", "Run tests"])`.',
    starterCode: `function isPayloadBounded(name, objectives) {
  const validName = typeof name === 'string' && name.length >= 1 && name.length <= 120;
  const validObjectives = Array.isArray(objectives) && objectives.length <= 10;
  return validName && validObjectives;
}

console.log("Validation passed:", isPayloadBounded("LORIN Core", ["Audit rules", "Run tests"]));`,
    expectedOutputSubstring: 'Validation passed: true',
    quizQuestions: [
      {
        id: 'zt_q1',
        question:
          'Why does LORIN isolate user email and preferences into `/users/{userId}/private/info` instead of storing them on `/users/{userId}`?',
        options: [
          'Because Firestore documents cannot store strings longer than 50 characters',
          'Because Firestore rules apply at the whole-document level; split-collection isolation prevents PII leakage if public profile reads are ever broadened',
          'To reduce CSS bundle size in the browser'
        ],
        correctIndex: 1,
        explanation:
          'Firestore cannot filter individual fields on a read operation. Splitting public and private fields into separate documents guarantees zero field-level PII leakage.'
      },
      {
        id: 'zt_q2',
        question:
          'What happens if a client attempts to update a project whose existing `status` is `"Archived"`?',
        options: [
          'The update succeeds but logs a warning in the console',
          'The Firestore rule `existing().status != "Archived"` rejects the write at the database engine level',
          'The project is automatically duplicated'
        ],
        correctIndex: 1,
        explanation:
          'Pillar 4 (State Machine & Terminal State Lock) enforces `existing().status != "Archived"` on update, preventing tampering with finalized records.'
      },
      {
        id: 'zt_q3',
        question:
          'How should client applications interact with the `@google/genai` SDK in LORIN?',
        options: [
          'Import `@google/genai` directly in React components with a hardcoded key',
          'Send requests to `/api/gemini/*` backend routes in `server.ts` where `process.env.GEMINI_API_KEY` is protected',
          'Store the API key in `localStorage`'
        ],
        correctIndex: 1,
        explanation:
          'All Gemini API calls execute exclusively on the server in `server.ts` so credentials are never exposed to the browser.'
      }
    ]
  },
  {
    learningPathId: 'path_spatial_threejs',
    title: 'Physical-Based 3D Spatial Computing with Three.js',
    subject: '3D Graphics & Simulation',
    targetLevel: 'intermediate',
    status: 'active',
    completedLessons: 1,
    totalLessons: 3,
    averageScore: 88,
    conceptOverview:
      'High-craft Three.js environments combine ACES Filmic tone mapping, PMREM environment reflections (`RoomEnvironment`), warm/cool directional + hemisphere lighting, and multi-part `THREE.Group` assemblies.',
    keyTakeaways: [
      'Always pair `MeshStandardMaterial` / `MeshPhysicalMaterial` with a PMREM environment map so metallic surfaces reflect realistic light.',
      'Construct focal objects as composite `THREE.Group` hierarchies (3–12 sub-meshes) rather than single bare primitives.',
      'Dispose geometries, materials, and render targets on React unmount to prevent GPU memory leaks.'
    ],
    workedExample: `// Generating procedural studio reflections for PBR materials:
const pmremGenerator = new THREE.PMREMGenerator(renderer);
scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
pmremGenerator.dispose();`,
    codingPrompt:
      'Compute the 3D Euclidean distance between two telemetry nodes at `[0, 0, 0]` and `[3, 4, 12]` and log `"Distance: 13"`.',
    starterCode: `function distance3D(a, b) {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const dz = b[2] - a[2];
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

console.log("Distance:", distance3D([0, 0, 0], [3, 4, 12]));`,
    expectedOutputSubstring: 'Distance: 13',
    quizQuestions: [
      {
        id: 'sp_q1',
        question:
          'What happens to a `MeshStandardMaterial` with `metalness: 0.85` if `scene.environment` is left `null`?',
        options: [
          'It renders muddily or nearly black because metallic surfaces rely on environment reflections',
          'It automatically downloads an HDRI from the web',
          'It converts itself into `MeshBasicMaterial`'
        ],
        correctIndex: 0,
        explanation:
          'Metallic PBR surfaces reflect their environment; without `scene.environment` (such as `RoomEnvironment`), high-metalness meshes have nothing to reflect.'
      },
      {
        id: 'sp_q2',
        question:
          'Why should HTML overlays positioned over a WebGL canvas avoid `backdrop-filter: blur(...)`?',
        options: [
          'Because CSS blur changes the camera field of view',
          'Because `backdrop-filter` forces an extra GPU readback of the WebGL framebuffer every frame, degrading frame pacing',
          'Because Three.js disables HTML pointer events'
        ],
        correctIndex: 1,
        explanation:
          'Using `backdrop-filter` over an active WebGL canvas triggers costly per-frame compositor readbacks. Solid high-opacity surfaces (`bg-[#111821]/95`) are much faster.'
      }
    ]
  }
];

export const INITIAL_VISION_ANALYSES: VisionAnalysisRecord[] = [
  {
    analysisId: 'vis_pcb_inverter',
    title: 'SiC Inverter Driver Board Thermal & Component Inspection',
    question: 'Check gate driver clearances, visible busbar solder joints, and silkscreen markings.',
    resultSummary:
      'High-voltage DC link busbars (J1/J2) exhibit uniform solder wetting across all 6 phase legs. Isolated gate-driver ICs (U4–U9) maintain an 8.5mm creepage slot across the polyimide isolation barrier. Silkscreen rev stamp indicates "REV-B 800V".',
    uncertaintyNotes:
      'Backside thermal interface material (TIM) coverage beneath the SiC MOSFET module cannot be verified from a top-down optical frame; recommend cross-checking heatsink thermistors under load.',
    detectedElements: [
      'SiC 3-Phase Bridge Module',
      '8.5mm High-Voltage Creepage Slot',
      'Isolated Gate Driver Array (U4-U9)',
      'DC Bus Film Capacitor Bank',
      'Optical Fault Status LEDs'
    ],
    recommendedScenePreset: 'laboratory',
    createdAtLabel: 'Saved 3h ago'
  }
];

export const INITIAL_WORLD_PRESETS: Record<
  'laboratory' | 'classroom' | 'observatory' | 'solar_array',
  VirtualWorldSceneSpec
> = {
  laboratory: {
    worldId: 'world_lab_alpha',
    name: 'LORIN Autonomous Robotics & Holographic Lab',
    description:
      'Primary spatial engineering studio featuring dual-monitor research desks, holographic projection core, autonomous assistant robot, and quantum compute server racks.',
    environmentPreset: 'laboratory',
    fogDensity: 0.016,
    keyLightIntensity: 2.4,
    objects: [
      {
        id: 'obj_core_1',
        name: 'Central Holographic Projection Core',
        archetype: 'holographic_array',
        position: [0, 0, 0],
        rotationY: 0,
        scale: 1.15,
        accentColor: '#66E3CB',
        interactiveLabel: 'Active Neural & Spatial Telemetry Projector (98.4% coherence)'
      },
      {
        id: 'obj_desk_1',
        name: 'Primary Systems Engineering Desk',
        archetype: 'research_workstation',
        position: [-4.2, 0, -2.4],
        rotationY: 0.55,
        scale: 1.0,
        accentColor: '#A9B8FF',
        interactiveLabel: 'Nolan Architecture Workstation — Dual Curved Displays'
      },
      {
        id: 'obj_desk_2',
        name: 'Security & Audit Terminal',
        archetype: 'research_workstation',
        position: [4.2, 0, -2.4],
        rotationY: -0.55,
        scale: 1.0,
        accentColor: '#E8BE78',
        interactiveLabel: 'Lena Guardian Security Console — Zero-Trust Monitor'
      },
      {
        id: 'obj_robot_1',
        name: 'LORIN Field Inspection Unit R-01',
        archetype: 'assistant_robot',
        position: [-2.2, 0, 2.8],
        rotationY: 2.4,
        scale: 1.0,
        accentColor: '#66E3CB',
        interactiveLabel: 'Autonomous Mobile Manipulator & Optical Sensor Unit'
      },
      {
        id: 'obj_rack_1',
        name: 'Private Model Inference Rack A1',
        archetype: 'network_rack',
        position: [-5.5, 0, -5.5],
        rotationY: 0.3,
        scale: 1.1,
        accentColor: '#A9B8FF',
        interactiveLabel: 'Local Weight Vault & High-Density NVMe Storage'
      },
      {
        id: 'obj_rack_2',
        name: 'Knowledge Vault Vector Node A2',
        archetype: 'network_rack',
        position: [5.5, 0, -5.5],
        rotationY: -0.3,
        scale: 1.1,
        accentColor: '#66E3CB',
        interactiveLabel: 'Encrypted Document Index & Retrieval Cluster'
      },
      {
        id: 'obj_col_1',
        name: 'Environmental LiDAR Calibration Pillar',
        archetype: 'observation_column',
        position: [2.8, 0, 3.2],
        rotationY: -2.1,
        scale: 1.0,
        accentColor: '#E8BE78',
        interactiveLabel: 'Precision Spatial Reference Beacon'
      }
    ]
  },
  solar_array: {
    worldId: 'world_solar_twin',
    name: 'Microgrid Photovoltaic Spatial Twin (Rev B)',
    description:
      'Spatial digital twin of the 800V DC autonomous solar microgrid with dual-axis tracking collectors, telemetry beacons, and field inspection robot.',
    environmentPreset: 'solar_array',
    fogDensity: 0.012,
    keyLightIntensity: 3.1,
    objects: [
      {
        id: 'sol_1',
        name: 'Dual-Axis Collector Array North-1',
        archetype: 'solar_collector',
        position: [-4.5, 0, -3.2],
        rotationY: 0.2,
        scale: 1.15,
        accentColor: '#E8BE78',
        interactiveLabel: '800V DC Bus | MPPT 98.6% | Heatsink 49°C'
      },
      {
        id: 'sol_2',
        name: 'Dual-Axis Collector Array North-2',
        archetype: 'solar_collector',
        position: [0, 0, -3.2],
        rotationY: 0.2,
        scale: 1.15,
        accentColor: '#E8BE78',
        interactiveLabel: '800V DC Bus | MPPT 98.4% | Heatsink 51°C'
      },
      {
        id: 'sol_3',
        name: 'Dual-Axis Collector Array North-3',
        archetype: 'solar_collector',
        position: [4.5, 0, -3.2],
        rotationY: 0.2,
        scale: 1.15,
        accentColor: '#E8BE78',
        interactiveLabel: '800V DC Bus | MPPT 98.7% | Heatsink 48°C'
      },
      {
        id: 'sol_holo',
        name: 'Irradiance & Load Forecasting Core',
        archetype: 'holographic_array',
        position: [0, 0, 1.8],
        rotationY: 0,
        scale: 1.0,
        accentColor: '#66E3CB',
        interactiveLabel: 'Real-Time Microgrid Dispatch Controller'
      },
      {
        id: 'sol_robot',
        name: 'Thermographic Inspection Rover',
        archetype: 'assistant_robot',
        position: [-3.0, 0, 2.4],
        rotationY: 1.8,
        scale: 1.0,
        accentColor: '#66E3CB',
        interactiveLabel: 'IR Camera Sweep Active — Zero Hotspots Detected'
      },
      {
        id: 'sol_rack',
        name: 'SiC Central Inverter & BMS Cabinet',
        archetype: 'network_rack',
        position: [4.8, 0, 2.2],
        rotationY: -1.1,
        scale: 1.1,
        accentColor: '#A9B8FF',
        interactiveLabel: 'Liquid-Cooled SiC Inverter Cabinet — Nominal'
      }
    ]
  },
  observatory: {
    worldId: 'world_obs_deep',
    name: 'Orbital & Deep-Sky Telemetry Observatory',
    description:
      'High-altitude sensor array and holographic sky-mapping studio for orbital mechanics and RF spectrum analysis.',
    environmentPreset: 'observatory',
    fogDensity: 0.014,
    keyLightIntensity: 2.0,
    objects: [
      {
        id: 'obs_core',
        name: 'Celestial Coordinate Projection Core',
        archetype: 'holographic_array',
        position: [0, 0, 0],
        rotationY: 0,
        scale: 1.3,
        accentColor: '#A9B8FF',
        interactiveLabel: 'Ephemeris & Satellite Constellation Tracker'
      },
      {
        id: 'obs_col_1',
        name: 'Optical Interferometer Pillar West',
        archetype: 'observation_column',
        position: [-4.5, 0, -2.5],
        rotationY: 0.6,
        scale: 1.2,
        accentColor: '#66E3CB',
        interactiveLabel: 'Adaptive Optics Wavefront Sensor W1'
      },
      {
        id: 'obs_col_2',
        name: 'Optical Interferometer Pillar East',
        archetype: 'observation_column',
        position: [4.5, 0, -2.5],
        rotationY: -0.6,
        scale: 1.2,
        accentColor: '#66E3CB',
        interactiveLabel: 'Adaptive Optics Wavefront Sensor E1'
      },
      {
        id: 'obs_desk',
        name: 'Spectroscopy Control Console',
        archetype: 'research_workstation',
        position: [0, 0, 4.0],
        rotationY: 3.14,
        scale: 1.05,
        accentColor: '#E8BE78',
        interactiveLabel: 'Iris Investigator Deep-Sky Signal Analyzer'
      }
    ]
  },
  classroom: {
    worldId: 'world_classroom_sim',
    name: 'Interactive Systems Engineering Seminar Studio',
    description:
      'Collaborative spatial classroom with central holographic demonstration podium and student engineering workstations.',
    environmentPreset: 'classroom',
    fogDensity: 0.015,
    keyLightIntensity: 2.6,
    objects: [
      {
        id: 'cls_podium',
        name: 'Instructor Holographic Demonstration Stage',
        archetype: 'holographic_array',
        position: [0, 0, -3.5],
        rotationY: 0,
        scale: 1.15,
        accentColor: '#66E3CB',
        interactiveLabel: 'Riley Companion Interactive Architecture Model'
      },
      {
        id: 'cls_desk_1',
        name: 'Lab Station Alpha',
        archetype: 'research_workstation',
        position: [-3.6, 0, 1.5],
        rotationY: 0.25,
        scale: 0.95,
        accentColor: '#A9B8FF',
        interactiveLabel: 'Distributed Systems Simulation Terminal 01'
      },
      {
        id: 'cls_desk_2',
        name: 'Lab Station Beta',
        archetype: 'research_workstation',
        position: [0, 0, 2.2],
        rotationY: 0,
        scale: 0.95,
        accentColor: '#66E3CB',
        interactiveLabel: 'Security Rules Verification Terminal 02'
      },
      {
        id: 'cls_desk_3',
        name: 'Lab Station Gamma',
        archetype: 'research_workstation',
        position: [3.6, 0, 1.5],
        rotationY: -0.25,
        scale: 0.95,
        accentColor: '#E8BE78',
        interactiveLabel: 'Three.js Shader & PBR Material Terminal 03'
      },
      {
        id: 'cls_bot',
        name: 'Teaching Assistant Robot Riley-Unit',
        archetype: 'assistant_robot',
        position: [2.8, 0, -2.5],
        rotationY: -0.7,
        scale: 0.95,
        accentColor: '#66E3CB',
        interactiveLabel: 'Interactive Lab Demonstrator'
      }
    ]
  }
};
