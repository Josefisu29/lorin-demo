import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  type User
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  serverTimestamp
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write'
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): FirestoreErrorInfo {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData.map((provider) => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL
        })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo;
}

// Validate connection to Firestore on boot
async function verifyFirestoreConnectivity() {
  try {
    await getDocFromServer(doc(db, 'users', '_connectivity_probe_'));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes('the client is offline')
    ) {
      console.error('Please check your Firebase configuration. Client appears offline.');
    }
  }
}
verifyFirestoreConnectivity();

// Google Workspace OAuth token management (strictly in-memory per workspace-integration skill)
let cachedDriveAccessToken: string | null = null;
let tokenExpiryTime = 0;

const DRIVE_SCOPES = [
  'https://www.googleapis.com/auth/drive.readonly',
  'https://www.googleapis.com/auth/drive.file'
];

export function getCachedDriveToken(): string | null {
  if (cachedDriveAccessToken && Date.now() < tokenExpiryTime - 300_000) {
    return cachedDriveAccessToken;
  }
  return null;
}

export async function signInWithGoogleAndDrive(): Promise<{
  user: User;
  driveAccessToken: string | null;
}> {
  const provider = new GoogleAuthProvider();
  DRIVE_SCOPES.forEach((scope) => provider.addScope(scope));

  const result = await signInWithPopup(auth, provider);
  const credential = GoogleAuthProvider.credentialFromResult(result);
  const accessToken = credential?.accessToken || null;

  if (accessToken) {
    cachedDriveAccessToken = accessToken;
    tokenExpiryTime = Date.now() + 3600 * 1000;
  }

  await ensureUserProfileInitialized(result.user);

  return {
    user: result.user,
    driveAccessToken: accessToken
  };
}

export async function refreshDriveTokenInteractive(): Promise<string | null> {
  if (cachedDriveAccessToken && Date.now() < tokenExpiryTime - 300_000) {
    return cachedDriveAccessToken;
  }
  const provider = new GoogleAuthProvider();
  DRIVE_SCOPES.forEach((scope) => provider.addScope(scope));
  if (auth.currentUser?.email) {
    provider.setCustomParameters({
      login_hint: auth.currentUser.email
    });
  }
  const result = await signInWithPopup(auth, provider);
  const credential = GoogleAuthProvider.credentialFromResult(result);
  cachedDriveAccessToken = credential?.accessToken || null;
  tokenExpiryTime = Date.now() + 3600 * 1000;
  return cachedDriveAccessToken;
}

export async function signOutLorin(): Promise<void> {
  cachedDriveAccessToken = null;
  tokenExpiryTime = 0;
  await firebaseSignOut(auth);
}

export async function ensureUserProfileInitialized(user: User): Promise<void> {
  if (!user.emailVerified) return;
  const userRef = doc(db, 'users', user.uid);
  const privateRef = doc(db, 'users', user.uid, 'private', 'info');

  try {
    const existing = await getDoc(userRef);
    if (!existing.exists()) {
      await setDoc(userRef, {
        userId: user.uid,
        displayName: (user.displayName || 'Authorized Owner').slice(0, 100),
        ...(user.photoURL ? { photoURL: user.photoURL.slice(0, 500) } : {}),
        accountStatus: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }

    const existingPrivate = await getDoc(privateRef);
    if (!existingPrivate.exists() && user.email) {
      await setDoc(privateRef, {
        userId: user.uid,
        email: user.email.slice(0, 254),
        theme: 'dark',
        preferredVoice: 'Kore',
        learningLevel: 'intermediate',
        updatedAt: serverTimestamp()
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
  }
}

export {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  onSnapshot,
  serverTimestamp,
  onAuthStateChanged,
  type User
};
