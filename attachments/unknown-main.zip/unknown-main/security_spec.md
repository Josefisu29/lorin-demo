# LORIN Security Specification — Phase 0 Payload-First Security TDD

## 1. Data Invariants

1. **Default-Deny Catch-All**: All paths not explicitly matched are denied for both `read` and `write`.
2. **Verified Authentication**: Every write operation requires `request.auth != null && request.auth.token.email_verified == true`.
3. **Path Variable Hardening (`isValidId`)**: All document IDs (`userId`, `projectId`, `conversationId`, `messageId`, `documentId`, `learningPathId`, `analysisId`, `worldId`, `activityId`) must be strings `<= 128` chars matching `^[a-zA-Z0-9_\-]+$`.
4. **PII Split Collection Isolation**: Email addresses and personal preferences are isolated in `/users/{userId}/private/{docId}` (`docId == 'info'`) and readable/writable strictly by the owner (`request.auth.uid == userId`).
5. **Relational Master Gate on Subcollections**: `/conversations/{conversationId}/messages/{messageId}` requires verifying the parent `/conversations/{conversationId}` exists and `get(...).data.ownerId == request.auth.uid`.
6. **Strict Keys & Anti-Update-Gap**: Every `create` and `update` invokes `isValid[Entity](incoming())`, enforcing `hasAll`/`hasOnly` keys, string length limits, bounded arrays (`<= 10`), and exact enum membership.
7. **Temporal Integrity & Immortality**: `createdAt == request.time` on `create`; `createdAt == existing().createdAt` and `ownerId == existing().ownerId` on `update`; `updatedAt == request.time` on `update`.
8. **Terminal State Locking**: Once a `Project` reaches `status == 'Archived'` or a `LearningPath` reaches `status == 'completed'`, subsequent updates are rejected.
9. **Secure List Queries**: Every `allow list` rule enforces `resource.data.ownerId == request.auth.uid` without `get()`/`exists()` inside `list`.

---

## 2. The "Dirty Dozen" Payloads (Designed to Break Identity, Integrity, and State)

1. **Payload 1 (Identity Spoofing on Project Create)**: Authenticated user `uid_alice` creates `/projects/proj_1` with `ownerId: "uid_bob"`. -> `PERMISSION_DENIED`
2. **Payload 2 (Unverified Email Write)**: User with `email_verified: false` attempts to create `/projects/proj_1`. -> `PERMISSION_DENIED`
3. **Payload 3 (Shadow Field Injection on Conversation Update)**: Owner updates `/conversations/conv_1` adding unauthorized field `isAdmin: true`. -> `PERMISSION_DENIED`
4. **Payload 4 (PII Leak Across Users)**: Authenticated user `uid_mallory` attempts `get` on `/users/uid_alice/private/info`. -> `PERMISSION_DENIED`
5. **Payload 5 (ID Poisoning Attack)**: User attempts to create `/projects/invalid$id!with*spaces` failing `isValidId`. -> `PERMISSION_DENIED`
6. **Payload 6 (Orphaned Subcollection Write)**: User attempts to create `/conversations/nonexistent_conv/messages/msg_1` where parent conversation does not exist or belongs to another user. -> `PERMISSION_DENIED`
7. **Payload 7 (Terminal State Mutation)**: User attempts to update `/projects/proj_archived` when `existing().status == 'Archived'`. -> `PERMISSION_DENIED`
8. **Payload 8 (Timestamp Forgery)**: User sends a client-fabricated `createdAt` timestamp != `request.time` on `/documents/doc_1`. -> `PERMISSION_DENIED`
9. **Payload 9 (Immortal Field Mutation)**: User attempts to mutate `ownerId` or `createdAt` during an `update` on `/virtual_worlds/world_1`. -> `PERMISSION_DENIED`
10. **Payload 10 (Unbounded Array Overflow)**: User attempts to create `/projects/proj_2` with `objectives` array containing 25 items (`> 10` limit). -> `PERMISSION_DENIED`
11. **Payload 11 (Value Poisoning on Whitelisted Update Key)**: User updates `name` on `/projects/proj_1` with a 5,000-character string (`> 120` maxLength) or boolean. -> `PERMISSION_DENIED`
12. **Payload 12 (Cross-Tenant List Scraping)**: User `uid_mallory` runs an unconstrained `list` query on `/documents` without filtering `ownerId == request.auth.uid`. -> `PERMISSION_DENIED`
